import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/UserGuideModal.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { X, BookOpen, Sparkles, FileText, Share2, BarChart3, PlayCircle, CheckCircle2, ShieldCheck, HelpCircle, ChevronRight, QrCode, Sliders, Layers } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/UserGuideModal.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function UserGuideModal({ isOpen = false, onClose = () => {}, onStartTour = () => {} }) {
	_s();
	const [activeTab, setActiveTab] = useState("overview");
	if (!isOpen) return null;
	const tabs = [
		{
			id: "overview",
			label: "Ringkasan Cepat",
			icon: BookOpen
		},
		{
			id: "builder",
			label: "Editor Formulir & Kuis",
			icon: FileText
		},
		{
			id: "ai",
			label: "Kecerdasan AI",
			icon: Sparkles
		},
		{
			id: "sharing",
			label: "Membagikan & Ujian",
			icon: Share2
		},
		{
			id: "analytics",
			label: "Respons & Penilaian",
			icon: BarChart3
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 select-none animate-in fade-in duration-200",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity cursor-pointer",
			onClick: onClose
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200/80 dark:border-slate-800 w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden z-10 animate-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/50",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-2xl bg-teal-50 dark:bg-teal-950/60 flex items-center justify-center text-[#00897B] dark:text-teal-400 border border-teal-200/60 dark:border-teal-800/60 shadow-xs",
							children: /* @__PURE__ */ _jsxDEV(BookOpen, { size: 20 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2",
							children: ["Panduan Pengguna FormUp", /* @__PURE__ */ _jsxDEV("span", {
								className: "px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 dark:bg-teal-900/60 text-teal-700 dark:text-teal-300",
								children: "Bantuan"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 55,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400",
							children: "Pelajari cara memaksimalkan fitur formulir, kuis interaktif, dan evaluasi otomatis."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onClose,
						className: "p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer",
						title: "Tutup Modal (Esc)",
						children: /* @__PURE__ */ _jsxDEV(X, { size: 20 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1.5 px-6 pt-3 border-b border-slate-100 dark:border-slate-800 overflow-x-auto no-scrollbar bg-white dark:bg-slate-900",
					children: tabs.map((tab) => {
						const Icon = tab.icon;
						const isActive = activeTab === tab.id;
						return /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setActiveTab(tab.id),
							className: `flex items-center gap-2 px-3.5 py-2.5 text-xs font-bold rounded-t-xl border-b-2 whitespace-nowrap transition-all cursor-pointer ${isActive ? "border-teal-600 text-teal-600 dark:border-teal-400 dark:text-teal-400 bg-teal-50/40 dark:bg-teal-950/30" : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50"}`,
							children: [/* @__PURE__ */ _jsxDEV(Icon, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: tab.label }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 33
							}, this)]
						}, tab.id, true, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 29
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto p-6 text-slate-700 dark:text-slate-300 text-sm space-y-4",
					children: [
						activeTab === "overview" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 rounded-2xl bg-gradient-to-br from-teal-500/10 via-emerald-500/5 to-transparent border border-teal-500/20",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-slate-900 dark:text-white text-base mb-1 flex items-center gap-2",
									children: "🚀 Selamat Datang di FormUp!"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-600 dark:text-slate-300 leading-relaxed",
									children: "FormUp dirancang untuk mempermudah siapa saja membuat formulir pendaftaran, survei kepuasan, hingga kuis & ujian online terstruktur dengan sistem penilaian instan."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-1.5",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 text-teal-600 dark:text-teal-400 font-bold text-xs uppercase tracking-wide",
											children: [/* @__PURE__ */ _jsxDEV(FileText, { size: 16 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 114,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "1. Buat Formulir" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 115,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 113,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed",
											children: [
												"Pilih ",
												/* @__PURE__ */ _jsxDEV("b", { children: "Buat Formulir Baru" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 118,
													columnNumber: 47
												}, this),
												" atau manfaatkan ",
												/* @__PURE__ */ _jsxDEV("b", { children: "Buat dengan AI" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 118,
													columnNumber: 89
												}, this),
												" untuk menyusun pertanyaan kuis secara otomatis dalam hitungan detik."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 117,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 112,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-1.5",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-bold text-xs uppercase tracking-wide",
											children: [/* @__PURE__ */ _jsxDEV(Share2, { size: 16 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 124,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "2. Bagikan & Ujian" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 125,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 123,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed",
											children: [
												"Sebarkan link formulir, unduh QR Code, atau aktifkan ",
												/* @__PURE__ */ _jsxDEV("b", { children: "Mode Ujian" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 128,
													columnNumber: 94
												}, this),
												" untuk mengunci layar dan mendeteksi kecurangan responden secara langsung."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 127,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 122,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-1.5",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-xs uppercase tracking-wide",
											children: [/* @__PURE__ */ _jsxDEV(BarChart3, { size: 16 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 134,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "3. Pantau Respons" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 135,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 133,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed",
											children: [
												"Buka tab ",
												/* @__PURE__ */ _jsxDEV("b", { children: "Respons" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 138,
													columnNumber: 50
												}, this),
												" untuk melihat submission, skor otomatis PG, analisis jawaban, hingga ekspor data ke Excel atau CSV."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 137,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-1.5",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 text-amber-600 dark:text-amber-400 font-bold text-xs uppercase tracking-wide",
											children: [/* @__PURE__ */ _jsxDEV(Sliders, { size: 16 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 144,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "4. Evaluasi Fleksibel" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 145,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 143,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed",
											children: "Gunakan fitur koreksi manual essay, bantuan penilaian holistik Gemini AI, atau penyesuaian skor massal untuk nilai akhir."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 147,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 142,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 25
						}, this),
						activeTab === "builder" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 text-xs leading-relaxed",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-bold text-slate-900 dark:text-white text-sm",
								children: "Fitur Utama Editor Formulir"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("ul", {
								className: "space-y-2.5",
								children: [
									/* @__PURE__ */ _jsxDEV("li", {
										className: "flex items-start gap-2.5",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
											size: 16,
											className: "text-teal-600 dark:text-teal-400 shrink-0 mt-0.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 162,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-900 dark:text-white",
											children: "Ragam Tipe Pertanyaan:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 164,
											columnNumber: 41
										}, this), " Mendukung Pilihan Ganda, Checkbox, Dropdown, Jawaban Singkat, Paragraf/Essay, hingga Skala Linear & Upload File."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 163,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("li", {
										className: "flex items-start gap-2.5",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
											size: 16,
											className: "text-teal-600 dark:text-teal-400 shrink-0 mt-0.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 168,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-900 dark:text-white",
											children: "Format Kaya (WYSIWYG & KaTeX):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 170,
											columnNumber: 41
										}, this), " Tambahkan teks tebal, miring, rumus matematika KaTeX, hingga blok kode pemrograman langsung di soal."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 169,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("li", {
										className: "flex items-start gap-2.5",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
											size: 16,
											className: "text-teal-600 dark:text-teal-400 shrink-0 mt-0.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 174,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-900 dark:text-white",
											children: "Sistem Kuis & Kunci Jawaban:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 176,
											columnNumber: 41
										}, this), " Tentukan kunci jawaban yang benar dan bobot poin per soal untuk penilaian otomatis."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 175,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("li", {
										className: "flex items-start gap-2.5",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
											size: 16,
											className: "text-teal-600 dark:text-teal-400 shrink-0 mt-0.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 180,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-900 dark:text-white",
											children: "Pengaturan Pintar:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 182,
											columnNumber: 41
										}, this), " Acak urutan soal, batas waktu pengerjaan (timer otomatis), batasi 1 kali pengisian, dan kustomisasi pesan terima kasih."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 181,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 179,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 25
						}, this),
						activeTab === "ai" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 text-xs leading-relaxed",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-2xl bg-teal-50/50 dark:bg-teal-950/40 border border-teal-200/60 dark:border-teal-800/60 flex items-start gap-3",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
										size: 22,
										className: "text-teal-600 dark:text-teal-400 shrink-0 mt-0.5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 192,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-slate-900 dark:text-white text-sm",
											children: "Pembuat Formulir Otomatis dengan AI"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 194,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-600 dark:text-slate-300",
											children: [
												"Cukup ketik topik atau deskripsikan kebutuhan kuis Anda (contoh: ",
												/* @__PURE__ */ _jsxDEV("i", { children: "\"Buat 5 soal pilihan ganda tentang Hukum Newton untuk kelas 10 SMA\"" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 196,
													columnNumber: 106
												}, this),
												"), dan FormUp AI akan menyusun soal, opsi pilihan, serta kunci jawabannya secara instan."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 195,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 191,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-slate-900 dark:text-white text-sm",
									children: "Langkah Menggunakan AI Builder:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 201,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("ol", {
									className: "list-decimal list-inside space-y-2 text-slate-600 dark:text-slate-300",
									children: [
										/* @__PURE__ */ _jsxDEV("li", { children: [
											"Klik tombol ",
											/* @__PURE__ */ _jsxDEV("b", { children: "\"Buat dengan AI\"" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 203,
												columnNumber: 49
											}, this),
											" di dashboard atau menu utama."
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 203,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: "Ketik topik materi atau upload file acuan dokumen/silabus." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 204,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: "Pilih jumlah soal dan tingkat kesulitan yang diinginkan." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 205,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [
											"Klik ",
											/* @__PURE__ */ _jsxDEV("b", { children: "Generate" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 206,
												columnNumber: 42
											}, this),
											", preview hasilnya, lalu klik ",
											/* @__PURE__ */ _jsxDEV("b", { children: "Simpan ke Form Builder" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 206,
												columnNumber: 87
											}, this),
											" untuk mengedit lebih lanjut."
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 206,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 25
						}, this),
						activeTab === "sharing" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 text-xs leading-relaxed",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-bold text-slate-900 dark:text-white text-sm",
								children: "Distribusi & Mode Pengawasan Ujian"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-start gap-3",
									children: [/* @__PURE__ */ _jsxDEV(QrCode, {
										size: 18,
										className: "text-teal-600 dark:text-teal-400 shrink-0 mt-0.5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 218,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
										className: "text-slate-900 dark:text-white",
										children: "QR Code & Link Publik:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 220,
										columnNumber: 41
									}, this), " Bagikan tautan langsung atau unduh gambar QR Code formulir untuk ditempel pada poster, ruang kelas, atau media sosial."] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 219,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 217,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-start gap-3",
									children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
										size: 18,
										className: "text-amber-600 dark:text-amber-400 shrink-0 mt-0.5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 225,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
										className: "text-slate-900 dark:text-white",
										children: "Mode Ujian Aman:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 41
									}, this), " Memaksa layar penuh (fullscreen), memblokir pindah tab, mencegah copy-paste dan inspect element, serta mencatat log pelanggaran secara real-time."] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 226,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 224,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 25
						}, this),
						activeTab === "analytics" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 text-xs leading-relaxed",
							children: [
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-slate-900 dark:text-white text-sm",
									children: "Rekap Nilai & Analisis Jawaban"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 236,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-600 dark:text-slate-400",
									children: [
										"Semua respons yang dikirimkan oleh audiens akan tercatat rapi di halaman ",
										/* @__PURE__ */ _jsxDEV("b", { children: "Respons" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 240,
											columnNumber: 106
										}, this),
										". Anda dapat:"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("ul", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-2",
											children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
												size: 15,
												className: "text-teal-600 dark:text-teal-400 shrink-0 mt-0.5"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 244,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("b", { children: "Koreksi Jawaban Essay:" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 245,
												columnNumber: 43
											}, this), " Nilai jawaban uraian siswa dan berikan catatan evaluasi secara manual atau bantuan AI."] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 245,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 243,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-2",
											children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
												size: 15,
												className: "text-teal-600 dark:text-teal-400 shrink-0 mt-0.5"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 248,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("b", { children: "Penyesuaian Skor Massal:" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 249,
												columnNumber: 43
											}, this), " Tambahkan nilai bonus atau normalisasi batas nilai kelulusan sekaligus."] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 249,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 247,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-2",
											children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
												size: 15,
												className: "text-teal-600 dark:text-teal-400 shrink-0 mt-0.5"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 252,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("b", { children: "Ekspor Data:" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 253,
												columnNumber: 43
											}, this), " Unduh lembar jawaban ke format Microsoft Excel (.xlsx) atau CSV untuk arsip."] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 253,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 242,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 235,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-900/50",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => {
							onClose();
							onStartTour();
						},
						className: "inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer w-full sm:w-auto justify-center",
						children: [/* @__PURE__ */ _jsxDEV(PlayCircle, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 270,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Mulai Tur Interaktif (Spotlight)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 271,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onClose,
						className: "px-5 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer w-full sm:w-auto",
						children: "Tutup Panduan"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 274,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 261,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 9
	}, this);
}
_s(UserGuideModal, "chU/96YDf6tpLdqvgqS2ZL+A4Bo=");
_c = UserGuideModal;
var _c;
$RefreshReg$(_c, "UserGuideModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/UserGuideModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/UserGuideModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/UserGuideModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/UserGuideModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FDSSxHQUNBLFVBQ0EsVUFDQSxVQUNBLFFBQ0EsV0FDQSxZQUNBLGNBQ0EsYUFDQSxZQUNBLGNBQ0EsUUFDQSxTQUNBLGNBQ0c7Ozs7QUFFUCxlQUFlLFNBQVMsZUFBZSxFQUNuQyxTQUFTLE9BQ1QsZ0JBQWdCLENBQUMsR0FDakIsb0JBQW9CLENBQUMsS0FDdEI7O0NBQ0MsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsVUFBVTtDQUVyRCxJQUFJLENBQUMsUUFBUSxPQUFPO0NBRXBCLE1BQU0sT0FBTztFQUNUO0dBQUUsSUFBSTtHQUFZLE9BQU87R0FBbUIsTUFBTTtFQUFTO0VBQzNEO0dBQUUsSUFBSTtHQUFXLE9BQU87R0FBMEIsTUFBTTtFQUFTO0VBQ2pFO0dBQUUsSUFBSTtHQUFNLE9BQU87R0FBaUIsTUFBTTtFQUFTO0VBQ25EO0dBQUUsSUFBSTtHQUFXLE9BQU87R0FBc0IsTUFBTTtFQUFPO0VBQzNEO0dBQUUsSUFBSTtHQUFhLE9BQU87R0FBdUIsTUFBTTtFQUFVO0NBQ3JFO0NBRUEsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBRUksd0JBQUMsT0FBRDtHQUNJLFdBQVU7R0FDVixTQUFTO0VBQ1o7Ozs7WUFHRCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1gsd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7TUFDcEI7Ozs7Z0JBQ0wsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQXdHLDJCQUVwRyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBa0g7T0FFNUg7Ozs7ZUFDTjs7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZDO01BRXZEOzs7O2NBQ0Y7Ozs7Y0FDSjs7Ozs7ZUFFTCx3QkFBQyxVQUFEO01BQ0ksTUFBSztNQUNMLFNBQVM7TUFDVCxXQUFVO01BQ1YsT0FBTTtnQkFFTix3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztLQUNWOzs7O2FBQ1A7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1YsS0FBSyxLQUFLLFFBQVE7TUFDZixNQUFNLE9BQU8sSUFBSTtNQUNqQixNQUFNLFdBQVcsY0FBYyxJQUFJO01BQ25DLE9BQ0ksd0JBQUMsVUFBRDtPQUVJLE1BQUs7T0FDTCxlQUFlLGFBQWEsSUFBSSxFQUFFO09BQ2xDLFdBQVcsbUlBQ1AsV0FDTSw0R0FDQTtpQkFQZCxDQVVJLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7aUJBQ2pCLHdCQUFDLFFBQUQsWUFBTyxJQUFJLE1BQVk7Ozs7ZUFDbkI7U0FYQyxJQUFJOzs7O2FBV0w7S0FFaEIsQ0FBQztJQUNBOzs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDSyxjQUFjLGNBQ1gsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFrRjtRQUU1Rjs7OztrQkFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkQ7UUFFdkU7Ozs7Z0JBQ0Y7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0ksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7cUJBQ3JCLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7bUJBQzNCOzs7OztvQkFDTCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUEwRTtZQUNoRSx3QkFBQyxLQUFELFlBQUcscUJBQXFCOzs7OztZQUFDO1lBQWlCLHdCQUFDLEtBQUQsWUFBRyxpQkFBaUI7Ozs7O1lBQUM7V0FDdEU7Ozs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7OztxQkFDbkIsd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OzttQkFDN0I7Ozs7O29CQUNMLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiO1lBQTBFO1lBQ2pCLHdCQUFDLEtBQUQsWUFBRyxhQUFhOzs7OztZQUFDO1dBQ3ZFOzs7OztrQkFDRjs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7cUJBQ3RCLHdCQUFDLFFBQUQsWUFBTSxvQkFBdUI7Ozs7bUJBQzVCOzs7OztvQkFDTCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUEwRTtZQUM3RCx3QkFBQyxLQUFELFlBQUcsVUFBVTs7Ozs7WUFBQztXQUN4Qjs7Ozs7a0JBQ0Y7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7O3FCQUNwQix3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O21CQUNoQzs7Ozs7b0JBQ0wsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQTZEO1VBRXZFOzs7O2tCQUNGOzs7Ozs7UUFDSjs7Ozs7ZUFDSjs7Ozs7O01BR1IsY0FBYyxhQUNYLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW1EO09BRTdEOzs7O2lCQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkO1NBQ0ksd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FDSSx3QkFBQyxjQUFEO1dBQWMsTUFBTTtXQUFJLFdBQVU7VUFBb0Q7Ozs7b0JBQ3RGLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxVQUFEO1dBQVEsV0FBVTtxQkFBaUM7VUFBOEI7Ozs7b0JBQUMsbUhBQ2pGOzs7O2tCQUNMOzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNJLHdCQUFDLGNBQUQ7V0FBYyxNQUFNO1dBQUksV0FBVTtVQUFvRDs7OztvQkFDdEYsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO3FCQUFpQztVQUFzQzs7OztvQkFBQyx1R0FDekY7Ozs7a0JBQ0w7Ozs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0ksd0JBQUMsY0FBRDtXQUFjLE1BQU07V0FBSSxXQUFVO1VBQW9EOzs7O29CQUN0Rix3QkFBQyxPQUFELGFBQ0ksd0JBQUMsVUFBRDtXQUFRLFdBQVU7cUJBQWlDO1VBQW9DOzs7O29CQUFDLHNGQUN2Rjs7OztrQkFDTDs7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FDSSx3QkFBQyxjQUFEO1dBQWMsTUFBTTtXQUFJLFdBQVU7VUFBb0Q7Ozs7b0JBQ3RGLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxVQUFEO1dBQVEsV0FBVTtxQkFBaUM7VUFBMEI7Ozs7b0JBQUMsMEhBQzdFOzs7O2tCQUNMOzs7Ozs7UUFDSjs7Ozs7ZUFDSDs7Ozs7O01BR1IsY0FBYyxRQUNYLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxVQUFEO1VBQVUsTUFBTTtVQUFJLFdBQVU7U0FBb0Q7Ozs7bUJBQ2xGLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQW1EO1VBQXVDOzs7O29CQUN4Ryx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUFrRDtZQUNtQix3QkFBQyxLQUFELFlBQUcsd0VBQXNFOzs7OztZQUFDO1dBQzVJOzs7OztrQkFDRjs7Ozs7aUJBQ0o7Ozs7OztRQUVMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtRDtRQUFtQzs7Ozs7UUFDcEcsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFDSSx3QkFBQyxNQUFEO1dBQUk7V0FBWSx3QkFBQyxLQUFELFlBQUcscUJBQW1COzs7OztXQUFDO1VBQWtDOzs7OztVQUN6RSx3QkFBQyxNQUFELFlBQUksNkRBQThEOzs7OztVQUNsRSx3QkFBQyxNQUFELFlBQUksMkRBQTREOzs7OztVQUNoRSx3QkFBQyxNQUFEO1dBQUk7V0FBSyx3QkFBQyxLQUFELFlBQUcsV0FBVzs7Ozs7V0FBQztXQUE4Qix3QkFBQyxLQUFELFlBQUcseUJBQXlCOzs7OztXQUFDO1VBQWlDOzs7OztTQUNwSDs7Ozs7O09BQ0g7Ozs7OztNQUdSLGNBQWMsYUFDWCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFtRDtPQUU3RDs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsUUFBRDtVQUFRLE1BQU07VUFBSSxXQUFVO1NBQW9EOzs7O21CQUNoRix3QkFBQyxPQUFELGFBQ0ksd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQWlDO1NBQThCOzs7O21CQUFDLHlIQUNqRjs7OztpQkFDSjs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxhQUFEO1VBQWEsTUFBTTtVQUFJLFdBQVU7U0FBc0Q7Ozs7bUJBQ3ZGLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxVQUFEO1VBQVEsV0FBVTtvQkFBaUM7U0FBd0I7Ozs7bUJBQUMsb0pBQzNFOzs7O2lCQUNKOzs7OztnQkFDSjs7Ozs7ZUFDSjs7Ozs7O01BR1IsY0FBYyxlQUNYLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0ksd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW1EO1FBRTdEOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQWtEO1VBQzJCLHdCQUFDLEtBQUQsWUFBRyxVQUFVOzs7OztVQUFDO1NBQ3hGOzs7Ozs7UUFDSCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZDtVQUNJLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFkLENBQ0ksd0JBQUMsY0FBRDtZQUFjLE1BQU07WUFBSSxXQUFVO1dBQW9EOzs7O3FCQUN0Rix3QkFBQyxRQUFELGFBQU0sd0JBQUMsS0FBRCxZQUFHLHlCQUF5Qjs7OztxQkFBQyx5RkFBNkY7Ozs7bUJBQ2hJOzs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBZCxDQUNJLHdCQUFDLGNBQUQ7WUFBYyxNQUFNO1lBQUksV0FBVTtXQUFvRDs7OztxQkFDdEYsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLEtBQUQsWUFBRywyQkFBMkI7Ozs7cUJBQUMsMEVBQThFOzs7O21CQUNuSDs7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWQsQ0FDSSx3QkFBQyxjQUFEO1lBQWMsTUFBTTtZQUFJLFdBQVU7V0FBb0Q7Ozs7cUJBQ3RGLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxLQUFELFlBQUcsZUFBZTs7OztxQkFBQywrRUFBbUY7Ozs7bUJBQzVHOzs7Ozs7U0FDSjs7Ozs7O09BQ0g7Ozs7OztLQUVSOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsVUFBRDtNQUNJLE1BQUs7TUFDTCxlQUFlO09BQ1gsUUFBUTtPQUNSLFlBQVk7TUFDaEI7TUFDQSxXQUFVO2dCQU5kLENBUUksd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7OztnQkFDdkIsd0JBQUMsUUFBRCxZQUFNLG1DQUFzQzs7OztjQUN4Qzs7Ozs7ZUFFUix3QkFBQyxVQUFEO01BQ0ksTUFBSztNQUNMLFNBQVM7TUFDVCxXQUFVO2dCQUNiO0tBRU87Ozs7YUFDUDs7Ozs7O0dBQ0o7Ozs7O1VBQ0o7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlVzZXJHdWlkZU1vZGFsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICAgIFgsIFxuICAgIEJvb2tPcGVuLCBcbiAgICBTcGFya2xlcywgXG4gICAgRmlsZVRleHQsIFxuICAgIFNoYXJlMiwgXG4gICAgQmFyQ2hhcnQzLCBcbiAgICBQbGF5Q2lyY2xlLCBcbiAgICBDaGVja0NpcmNsZTIsIFxuICAgIFNoaWVsZENoZWNrLCBcbiAgICBIZWxwQ2lyY2xlLFxuICAgIENoZXZyb25SaWdodCxcbiAgICBRckNvZGUsXG4gICAgU2xpZGVycyxcbiAgICBMYXllcnNcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVXNlckd1aWRlTW9kYWwoe1xuICAgIGlzT3BlbiA9IGZhbHNlLFxuICAgIG9uQ2xvc2UgPSAoKSA9PiB7fSxcbiAgICBvblN0YXJ0VG91ciA9ICgpID0+IHt9XG59KSB7XG4gICAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKCdvdmVydmlldycpO1xuXG4gICAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgdGFicyA9IFtcbiAgICAgICAgeyBpZDogJ292ZXJ2aWV3JywgbGFiZWw6ICdSaW5na2FzYW4gQ2VwYXQnLCBpY29uOiBCb29rT3BlbiB9LFxuICAgICAgICB7IGlkOiAnYnVpbGRlcicsIGxhYmVsOiAnRWRpdG9yIEZvcm11bGlyICYgS3VpcycsIGljb246IEZpbGVUZXh0IH0sXG4gICAgICAgIHsgaWQ6ICdhaScsIGxhYmVsOiAnS2VjZXJkYXNhbiBBSScsIGljb246IFNwYXJrbGVzIH0sXG4gICAgICAgIHsgaWQ6ICdzaGFyaW5nJywgbGFiZWw6ICdNZW1iYWdpa2FuICYgVWppYW4nLCBpY29uOiBTaGFyZTIgfSxcbiAgICAgICAgeyBpZDogJ2FuYWx5dGljcycsIGxhYmVsOiAnUmVzcG9ucyAmIFBlbmlsYWlhbicsIGljb246IEJhckNoYXJ0MyB9LFxuICAgIF07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgc206cC02IHNlbGVjdC1ub25lIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgIHsvKiBCYWNrZHJvcCAqL31cbiAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1zbGF0ZS05MDAvNjAgYmFja2Ryb3AtYmx1ci14cyB0cmFuc2l0aW9uLW9wYWNpdHkgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICB7LyogTW9kYWwgQm94ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTN4bCBzaGFkb3ctMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB3LWZ1bGwgbWF4LXctM3hsIG1heC1oLVs5MHZoXSBmbGV4IGZsZXgtY29sIG92ZXJmbG93LWhpZGRlbiB6LTEwIGFuaW1hdGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgICB7LyogTW9kYWwgSGVhZGVyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS01IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTkwMC81MFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLTJ4bCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwIGJvcmRlciBib3JkZXItdGVhbC0yMDAvNjAgZGFyazpib3JkZXItdGVhbC04MDAvNjAgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJvb2tPcGVuIHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGFuZHVhbiBQZW5nZ3VuYSBGb3JtVXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBiZy10ZWFsLTEwMCBkYXJrOmJnLXRlYWwtOTAwLzYwIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYW50dWFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZWxhamFyaSBjYXJhIG1lbWFrc2ltYWxrYW4gZml0dXIgZm9ybXVsaXIsIGt1aXMgaW50ZXJha3RpZiwgZGFuIGV2YWx1YXNpIG90b21hdGlzLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlR1dHVwIE1vZGFsIChFc2MpXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MjB9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFRhYiBOYXZpZ2F0aW9uICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC02IHB0LTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgb3ZlcmZsb3cteC1hdXRvIG5vLXNjcm9sbGJhciBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7dGFicy5tYXAoKHRhYikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IHRhYi5pY29uO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBhY3RpdmVUYWIgPT09IHRhYi5pZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3RhYi5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYih0YWIuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zLjUgcHktMi41IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtdC14bCBib3JkZXItYi0yIHdoaXRlc3BhY2Utbm93cmFwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci10ZWFsLTYwMCB0ZXh0LXRlYWwtNjAwIGRhcms6Ym9yZGVyLXRlYWwtNDAwIGRhcms6dGV4dC10ZWFsLTQwMCBiZy10ZWFsLTUwLzQwIGRhcms6YmctdGVhbC05NTAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC81MCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3RhYi5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBNb2RhbCBDb250ZW50IEJvZHkgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNiB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRleHQtc20gc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdvdmVydmlldycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXRlYWwtNTAwLzEwIHZpYS1lbWVyYWxkLTUwMC81IHRvLXRyYW5zcGFyZW50IGJvcmRlciBib3JkZXItdGVhbC01MDAvMjBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdGV4dC1iYXNlIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCfmoAgU2VsYW1hdCBEYXRhbmcgZGkgRm9ybVVwIVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGb3JtVXAgZGlyYW5jYW5nIHVudHVrIG1lbXBlcm11ZGFoIHNpYXBhIHNhamEgbWVtYnVhdCBmb3JtdWxpciBwZW5kYWZ0YXJhbiwgc3VydmVpIGtlcHVhc2FuLCBoaW5nZ2Ega3VpcyAmIHVqaWFuIG9ubGluZSB0ZXJzdHJ1a3R1ciBkZW5nYW4gc2lzdGVtIHBlbmlsYWlhbiBpbnN0YW4uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMy41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBmb250LWJvbGQgdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4xLiBCdWF0IEZvcm11bGlyPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGlsaWggPGI+QnVhdCBGb3JtdWxpciBCYXJ1PC9iPiBhdGF1IG1hbmZhYXRrYW4gPGI+QnVhdCBkZW5nYW4gQUk8L2I+IHVudHVrIG1lbnl1c3VuIHBlcnRhbnlhYW4ga3VpcyBzZWNhcmEgb3RvbWF0aXMgZGFsYW0gaGl0dW5nYW4gZGV0aWsuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWluZGlnby02MDAgZGFyazp0ZXh0LWluZGlnby00MDAgZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hhcmUyIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjIuIEJhZ2lrYW4gJiBVamlhbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlYmFya2FuIGxpbmsgZm9ybXVsaXIsIHVuZHVoIFFSIENvZGUsIGF0YXUgYWt0aWZrYW4gPGI+TW9kZSBVamlhbjwvYj4gdW50dWsgbWVuZ3VuY2kgbGF5YXIgZGFuIG1lbmRldGVrc2kga2VjdXJhbmdhbiByZXNwb25kZW4gc2VjYXJhIGxhbmdzdW5nLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyQ2hhcnQzIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjMuIFBhbnRhdSBSZXNwb25zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQnVrYSB0YWIgPGI+UmVzcG9uczwvYj4gdW50dWsgbWVsaWhhdCBzdWJtaXNzaW9uLCBza29yIG90b21hdGlzIFBHLCBhbmFsaXNpcyBqYXdhYmFuLCBoaW5nZ2EgZWtzcG9yIGRhdGEga2UgRXhjZWwgYXRhdSBDU1YuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwIGZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNsaWRlcnMgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+NC4gRXZhbHVhc2kgRmxla3NpYmVsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR3VuYWthbiBmaXR1ciBrb3Jla3NpIG1hbnVhbCBlc3NheSwgYmFudHVhbiBwZW5pbGFpYW4gaG9saXN0aWsgR2VtaW5pIEFJLCBhdGF1IHBlbnllc3VhaWFuIHNrb3IgbWFzc2FsIHVudHVrIG5pbGFpIGFraGlyLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdidWlsZGVyJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRml0dXIgVXRhbWEgRWRpdG9yIEZvcm11bGlyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5SYWdhbSBUaXBlIFBlcnRhbnlhYW46PC9zdHJvbmc+IE1lbmR1a3VuZyBQaWxpaGFuIEdhbmRhLCBDaGVja2JveCwgRHJvcGRvd24sIEphd2FiYW4gU2luZ2thdCwgUGFyYWdyYWYvRXNzYXksIGhpbmdnYSBTa2FsYSBMaW5lYXIgJiBVcGxvYWQgRmlsZS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPkZvcm1hdCBLYXlhIChXWVNJV1lHICYgS2FUZVgpOjwvc3Ryb25nPiBUYW1iYWhrYW4gdGVrcyB0ZWJhbCwgbWlyaW5nLCBydW11cyBtYXRlbWF0aWthIEthVGVYLCBoaW5nZ2EgYmxvayBrb2RlIHBlbXJvZ3JhbWFuIGxhbmdzdW5nIGRpIHNvYWwuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5TaXN0ZW0gS3VpcyAmIEt1bmNpIEphd2FiYW46PC9zdHJvbmc+IFRlbnR1a2FuIGt1bmNpIGphd2FiYW4geWFuZyBiZW5hciBkYW4gYm9ib3QgcG9pbiBwZXIgc29hbCB1bnR1ayBwZW5pbGFpYW4gb3RvbWF0aXMuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5QZW5nYXR1cmFuIFBpbnRhcjo8L3N0cm9uZz4gQWNhayB1cnV0YW4gc29hbCwgYmF0YXMgd2FrdHUgcGVuZ2VyamFhbiAodGltZXIgb3RvbWF0aXMpLCBiYXRhc2kgMSBrYWxpIHBlbmdpc2lhbiwgZGFuIGt1c3RvbWlzYXNpIHBlc2FuIHRlcmltYSBrYXNpaC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnYWknICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IHRleHQteHMgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctdGVhbC01MC81MCBkYXJrOmJnLXRlYWwtOTUwLzQwIGJvcmRlciBib3JkZXItdGVhbC0yMDAvNjAgZGFyazpib3JkZXItdGVhbC04MDAvNjAgZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MjJ9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0ZXh0LXNtXCI+UGVtYnVhdCBGb3JtdWxpciBPdG9tYXRpcyBkZW5nYW4gQUk8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEN1a3VwIGtldGlrIHRvcGlrIGF0YXUgZGVza3JpcHNpa2FuIGtlYnV0dWhhbiBrdWlzIEFuZGEgKGNvbnRvaDogPGk+XCJCdWF0IDUgc29hbCBwaWxpaGFuIGdhbmRhIHRlbnRhbmcgSHVrdW0gTmV3dG9uIHVudHVrIGtlbGFzIDEwIFNNQVwiPC9pPiksIGRhbiBGb3JtVXAgQUkgYWthbiBtZW55dXN1biBzb2FsLCBvcHNpIHBpbGloYW4sIHNlcnRhIGt1bmNpIGphd2FiYW5ueWEgc2VjYXJhIGluc3Rhbi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0ZXh0LXNtXCI+TGFuZ2thaCBNZW5nZ3VuYWthbiBBSSBCdWlsZGVyOjwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9sIGNsYXNzTmFtZT1cImxpc3QtZGVjaW1hbCBsaXN0LWluc2lkZSBzcGFjZS15LTIgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+S2xpayB0b21ib2wgPGI+XCJCdWF0IGRlbmdhbiBBSVwiPC9iPiBkaSBkYXNoYm9hcmQgYXRhdSBtZW51IHV0YW1hLjwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5LZXRpayB0b3BpayBtYXRlcmkgYXRhdSB1cGxvYWQgZmlsZSBhY3VhbiBkb2t1bWVuL3NpbGFidXMuPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlBpbGloIGp1bWxhaCBzb2FsIGRhbiB0aW5na2F0IGtlc3VsaXRhbiB5YW5nIGRpaW5naW5rYW4uPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPktsaWsgPGI+R2VuZXJhdGU8L2I+LCBwcmV2aWV3IGhhc2lsbnlhLCBsYWx1IGtsaWsgPGI+U2ltcGFuIGtlIEZvcm0gQnVpbGRlcjwvYj4gdW50dWsgbWVuZ2VkaXQgbGViaWggbGFuanV0LjwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdzaGFyaW5nJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGlzdHJpYnVzaSAmIE1vZGUgUGVuZ2F3YXNhbiBVamlhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLXhsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UXJDb2RlIHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlFSIENvZGUgJiBMaW5rIFB1Ymxpazo8L3N0cm9uZz4gQmFnaWthbiB0YXV0YW4gbGFuZ3N1bmcgYXRhdSB1bmR1aCBnYW1iYXIgUVIgQ29kZSBmb3JtdWxpciB1bnR1ayBkaXRlbXBlbCBwYWRhIHBvc3RlciwgcnVhbmcga2VsYXMsIGF0YXUgbWVkaWEgc29zaWFsLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+TW9kZSBVamlhbiBBbWFuOjwvc3Ryb25nPiBNZW1ha3NhIGxheWFyIHBlbnVoIChmdWxsc2NyZWVuKSwgbWVtYmxva2lyIHBpbmRhaCB0YWIsIG1lbmNlZ2FoIGNvcHktcGFzdGUgZGFuIGluc3BlY3QgZWxlbWVudCwgc2VydGEgbWVuY2F0YXQgbG9nIHBlbGFuZ2dhcmFuIHNlY2FyYSByZWFsLXRpbWUuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnYW5hbHl0aWNzJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVrYXAgTmlsYWkgJiBBbmFsaXNpcyBKYXdhYmFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlbXVhIHJlc3BvbnMgeWFuZyBkaWtpcmlta2FuIG9sZWggYXVkaWVucyBha2FuIHRlcmNhdGF0IHJhcGkgZGkgaGFsYW1hbiA8Yj5SZXNwb25zPC9iPi4gQW5kYSBkYXBhdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxNX0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjxiPktvcmVrc2kgSmF3YWJhbiBFc3NheTo8L2I+IE5pbGFpIGphd2FiYW4gdXJhaWFuIHNpc3dhIGRhbiBiZXJpa2FuIGNhdGF0YW4gZXZhbHVhc2kgc2VjYXJhIG1hbnVhbCBhdGF1IGJhbnR1YW4gQUkuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxNX0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjxiPlBlbnllc3VhaWFuIFNrb3IgTWFzc2FsOjwvYj4gVGFtYmFoa2FuIG5pbGFpIGJvbnVzIGF0YXUgbm9ybWFsaXNhc2kgYmF0YXMgbmlsYWkga2VsdWx1c2FuIHNla2FsaWd1cy48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezE1fSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+PGI+RWtzcG9yIERhdGE6PC9iPiBVbmR1aCBsZW1iYXIgamF3YWJhbiBrZSBmb3JtYXQgTWljcm9zb2Z0IEV4Y2VsICgueGxzeCkgYXRhdSBDU1YgdW50dWsgYXJzaXAuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBNb2RhbCBGb290ZXIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJnLXNsYXRlLTUwLzUwIGRhcms6Ymctc2xhdGUtOTAwLzUwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblN0YXJ0VG91cigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIuNSBiZy1ncmFkaWVudC10by1yIGZyb20tdGVhbC02MDAgdG8tZW1lcmFsZC02MDAgaG92ZXI6ZnJvbS10ZWFsLTcwMCBob3Zlcjp0by1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHJvdW5kZWQteGwgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsIGFjdGl2ZTpzY2FsZS05NSBjdXJzb3ItcG9pbnRlciB3LWZ1bGwgc206dy1hdXRvIGp1c3RpZnktY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFBsYXlDaXJjbGUgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NdWxhaSBUdXIgSW50ZXJha3RpZiAoU3BvdGxpZ2h0KTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciB3LWZ1bGwgc206dy1hdXRvXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgVHV0dXAgUGFuZHVhblxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuIl19