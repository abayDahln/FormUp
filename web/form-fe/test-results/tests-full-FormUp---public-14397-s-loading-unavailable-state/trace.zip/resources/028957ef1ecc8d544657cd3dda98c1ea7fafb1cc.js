import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/Register.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { register } from "/src/services/apiService.js";
import { FileText, ArrowRight, User, Mail, Lock, Calendar, Loader2, Eye, EyeOff } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/Register.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const EMOJI_REGEX = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{1F1E6}-\u{1F1FF}\u{2190}-\u{21FF}\u{2B00}-\u{2BFF}\uFE0F]/gu;
const NAME_REGEX = /^[a-zA-Z\s.'-]+$/;
const USERNAME_REGEX = /^[a-zA-Z0-9_.]+$/;
const Register = () => {
	_s();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [fullname, setFullname] = useState("");
	const [username, setUsername] = useState("");
	const [birthdate, setBirthdate] = useState("");
	const [confirmPassword, setConfirmPassword] = useState("");
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(false);
	// State untuk toggle visibilitas password
	const [showPassword, setShowPassword] = useState(false);
	const [showConfirmPassword, setShowConfirmPassword] = useState(false);
	const navigate = useNavigate();
	const handleRegister = async (e) => {
		e.preventDefault();
		setError("");
		const trimmedFullname = fullname.trim();
		const trimmedUsername = username.trim();
		if (EMOJI_REGEX.test(trimmedFullname) || EMOJI_REGEX.test(trimmedUsername)) {
			setError("Nama dan username tidak boleh mengandung emoji.");
			return;
		}
		if (!NAME_REGEX.test(trimmedFullname)) {
			setError("Nama lengkap hanya boleh berisi huruf, spasi, titik, apostrof, dan strip.");
			return;
		}
		if (!USERNAME_REGEX.test(trimmedUsername)) {
			setError("Username hanya boleh berisi huruf, angka, titik, dan underscore (tanpa spasi/simbol).");
			return;
		}
		if (password !== confirmPassword) {
			setError("Password dan Konfirmasi Password tidak cocok.");
			return;
		}
		if (password.length < 8) {
			setError("Password minimal 8 karakter.");
			return;
		}
		setLoading(true);
		const result = await register(trimmedFullname, trimmedUsername, email.trim(), password, birthdate);
		setLoading(false);
		if (result.ok && result.status === 200) {
			navigate("/verify", { state: {
				fullname: trimmedFullname,
				username: trimmedUsername,
				email: email.trim(),
				password,
				birthdate
			} });
		} else {
			setError(result.message || "Registrasi gagal. Silakan coba lagi.");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "h-screen max-h-screen w-full bg-[#004D4E] flex items-center justify-center p-4 sm:p-6 lg:p-12 relative overflow-hidden select-none touch-none",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute inset-0 pointer-events-none",
				style: { background: "linear-gradient(200deg, #2ED8C3 0%, #0FA89E 35%, #018081 75%, #004D4E 100%)" }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute pointer-events-none rounded-full",
				style: {
					width: "clamp(350px, 45vw, 750px)",
					height: "clamp(350px, 45vw, 750px)",
					top: "-10%",
					left: "-10%",
					background: "linear-gradient(-143deg, #2ED8C3 0%, rgba(10, 95, 110, 0.7) 100%)",
					opacity: .6,
					zIndex: 1
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute pointer-events-none rounded-full",
				style: {
					width: "clamp(350px, 45vw, 750px)",
					height: "clamp(350px, 45vw, 750px)",
					bottom: "-10%",
					right: "-10%",
					background: "linear-gradient(135deg, #2ED8C3 0%, rgba(10, 29, 93, 0.7) 100%)",
					opacity: .8,
					zIndex: 1
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative z-10 w-full max-w-6xl flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12 my-auto",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "w-full lg:w-1/2 text-white space-y-4 text-center lg:text-left",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-tight text-white",
						children: "Mulai Bersama FormUp"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-base sm:text-lg text-white/95 font-medium leading-relaxed max-w-lg mx-auto lg:mx-0",
						children: "Daftar akun gratis dan buat berbagai formulir, survei, serta ujian daring dengan mudah."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 113,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "w-full lg:w-1/2 max-w-lg",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "w-full bg-black/40 backdrop-blur-[20px] border border-white/10 rounded-[28px] p-6 sm:p-10 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-2xl sm:text-3xl font-bold text-white tracking-tight",
								children: "Buat Akun Baru"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs sm:text-sm font-medium text-white/70 mt-1",
								children: "Lengkapi data di bawah ini untuk memulai"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 25
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 21
							}, this),
							error && /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3.5 bg-red-500/20 border border-red-500/30 rounded-xl",
								children: /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-bold text-red-300 text-center",
									children: error
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("form", {
								onSubmit: handleRegister,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-white/90 mb-1.5",
											children: "Nama Lengkap"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 147,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: [/* @__PURE__ */ _jsxDEV(User, {
												size: 16,
												className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 151,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												placeholder: "Nama Lengkap",
												value: fullname,
												onChange: (e) => {
													const val = e.target.value;
													// Hanya izinkan huruf, spasi, titik, apostrof, strip
													if (/^[a-zA-Z\s.'-]*$/.test(val)) setFullname(val);
												},
												required: true,
												className: "w-full pl-10 pr-3.5 py-3 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 152,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 150,
											columnNumber: 33
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 146,
											columnNumber: 29
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-white/90 mb-1.5",
											children: "Username"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 168,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												placeholder: "username",
												value: username,
												onChange: (e) => {
													const val = e.target.value;
													if (/^[a-zA-Z0-9_.]*$/.test(val)) setUsername(val);
												},
												required: true,
												className: "w-full px-3.5 py-3 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 172,
												columnNumber: 37
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 171,
											columnNumber: 33
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 167,
											columnNumber: 29
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 145,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-white/90 mb-1.5",
											children: "Email"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 189,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: [/* @__PURE__ */ _jsxDEV(Mail, {
												size: 16,
												className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 193,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "email",
												placeholder: "nama@email.com",
												value: email,
												onChange: (e) => setEmail(e.target.value),
												required: true,
												className: "w-full pl-10 pr-3.5 py-3 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 194,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 192,
											columnNumber: 33
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 188,
											columnNumber: 29
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-white/90 mb-1.5",
											children: "Tanggal Lahir"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 206,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: /* @__PURE__ */ _jsxDEV("input", {
												type: "date",
												value: birthdate,
												onChange: (e) => setBirthdate(e.target.value),
												required: true,
												className: "w-full px-3.5 py-3 rounded-xl border border-white/10 bg-black/30 text-white font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner [color-scheme:dark]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 210,
												columnNumber: 37
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 209,
											columnNumber: 33
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 205,
											columnNumber: 29
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-white/90 mb-1.5",
											children: "Password"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 223,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: [
												/* @__PURE__ */ _jsxDEV(Lock, {
													size: 16,
													className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 227,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: showPassword ? "text" : "password",
													placeholder: "Min. 8 karakter",
													value: password,
													onChange: (e) => setPassword(e.target.value),
													required: true,
													className: "w-full pl-10 pr-10 py-3 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 228,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setShowPassword(!showPassword),
													className: "absolute right-3.5 top-1/2 -translate-y-1/2 text-white/50 hover:text-white transition-colors cursor-pointer p-0.5 focus:outline-none",
													tabIndex: "-1",
													children: showPassword ? /* @__PURE__ */ _jsxDEV(EyeOff, { size: 16 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 242,
														columnNumber: 57
													}, this) : /* @__PURE__ */ _jsxDEV(Eye, { size: 16 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 242,
														columnNumber: 80
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 236,
													columnNumber: 37
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 226,
											columnNumber: 33
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 222,
											columnNumber: 29
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-white/90 mb-1.5",
											children: "Ulangi Password"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 248,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: [
												/* @__PURE__ */ _jsxDEV(Lock, {
													size: 16,
													className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 252,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: showConfirmPassword ? "text" : "password",
													placeholder: "Ulangi password",
													value: confirmPassword,
													onChange: (e) => setConfirmPassword(e.target.value),
													required: true,
													className: "w-full pl-10 pr-10 py-3 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 253,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setShowConfirmPassword(!showConfirmPassword),
													className: "absolute right-3.5 top-1/2 -translate-y-1/2 text-white/50 hover:text-white transition-colors cursor-pointer p-0.5 focus:outline-none",
													tabIndex: "-1",
													children: showConfirmPassword ? /* @__PURE__ */ _jsxDEV(EyeOff, { size: 16 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 267,
														columnNumber: 64
													}, this) : /* @__PURE__ */ _jsxDEV(Eye, { size: 16 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 267,
														columnNumber: 87
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 261,
													columnNumber: 37
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 33
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 247,
											columnNumber: 29
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 221,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										disabled: loading,
										className: "w-full mt-4 py-3.5 px-6 bg-[#0FA89E] hover:bg-[#0d968d] active:scale-[0.98] text-white font-bold rounded-full shadow-[0_6px_20px_rgba(15,168,158,0.4)] transition-all duration-200 text-xs sm:text-sm tracking-wide disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center gap-2",
										children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
											size: 16,
											className: "animate-spin"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 280,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Mendaftarkan Akun..." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 281,
											columnNumber: 37
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 279,
											columnNumber: 33
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("span", { children: "Daftar Sekarang" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 285,
											columnNumber: 37
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 284,
											columnNumber: 33
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 25
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-center pt-3 border-t border-white/10",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-medium text-white/70",
									children: "Sudah punya akun? "
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 292,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV(Link, {
									to: "/login",
									className: "text-xs font-bold text-[#2ED8C3] hover:underline transition-all",
									children: "Masuk ke Sini"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 293,
									columnNumber: 25
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 291,
								columnNumber: 21
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 72,
		columnNumber: 13
	}, this);
};
_s(Register, "QsALrVC5X6Ma5NPSdBc5N8LWA6w=", false, function() {
	return [useNavigate];
});
_c = Register;
export default Register;
var _c;
$RefreshReg$(_c, "Register");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/Register.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/Register.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/Register.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/Register.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLFVBQVUsWUFBWSxNQUFNLE1BQU0sTUFBTSxVQUFVLFNBQVMsS0FBSyxjQUFjOzs7O0FBRXZGLE1BQU0sY0FBYztBQUNwQixNQUFNLGFBQWE7QUFDbkIsTUFBTSxpQkFBaUI7QUFFdkIsTUFBTSxpQkFBaUI7O0NBQ25CLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBQ3pELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLOztDQUc1QyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQVMsS0FBSztDQUVwRSxNQUFNLFdBQVcsWUFBWTtDQUU3QixNQUFNLGlCQUFpQixPQUFPLE1BQU07RUFDcEMsRUFBRSxlQUFlO0VBQ2pCLFNBQVMsRUFBRTtFQUVYLE1BQU0sa0JBQWtCLFNBQVMsS0FBSztFQUN0QyxNQUFNLGtCQUFrQixTQUFTLEtBQUs7RUFFdEMsSUFBSSxZQUFZLEtBQUssZUFBZSxLQUFLLFlBQVksS0FBSyxlQUFlLEdBQUc7R0FDeEUsU0FBUyxpREFBaUQ7R0FDMUQ7RUFDSjtFQUVBLElBQUksQ0FBQyxXQUFXLEtBQUssZUFBZSxHQUFHO0dBQ25DLFNBQVMsMkVBQTJFO0dBQ3BGO0VBQ0o7RUFFQSxJQUFJLENBQUMsZUFBZSxLQUFLLGVBQWUsR0FBRztHQUN2QyxTQUFTLHVGQUF1RjtHQUNoRztFQUNKO0VBRUEsSUFBSSxhQUFhLGlCQUFpQjtHQUM5QixTQUFTLCtDQUErQztHQUN4RDtFQUNKO0VBRUEsSUFBSSxTQUFTLFNBQVMsR0FBRztHQUNyQixTQUFTLDhCQUE4QjtHQUN2QztFQUNKO0VBRUEsV0FBVyxJQUFJO0VBQ2YsTUFBTSxTQUFTLE1BQU0sU0FBUyxpQkFBaUIsaUJBQWlCLE1BQU0sS0FBSyxHQUFHLFVBQVUsU0FBUztFQUNqRyxXQUFXLEtBQUs7RUFFaEIsSUFBSSxPQUFPLE1BQU0sT0FBTyxXQUFXLEtBQUs7R0FDcEMsU0FBUyxXQUFXLEVBQ2hCLE9BQU87SUFBRSxVQUFVO0lBQWlCLFVBQVU7SUFBaUIsT0FBTyxNQUFNLEtBQUs7SUFBRztJQUFVO0dBQVUsRUFDNUcsQ0FBQztFQUNMLE9BQU87R0FDSCxTQUFTLE9BQU8sV0FBVyxzQ0FBc0M7RUFDckU7Q0FDSjtDQUVJLE9BQ1Esd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVKLHdCQUFDLE9BQUQ7SUFDSSxXQUFVO0lBQ1YsT0FBTyxFQUNILFlBQVksOEVBQ2hCO0dBQ0g7Ozs7O0dBR0Qsd0JBQUMsT0FBRDtJQUNJLFdBQVU7SUFDVixPQUFPO0tBQ0gsT0FBTztLQUNQLFFBQVE7S0FDUixLQUFLO0tBQ0wsTUFBTTtLQUNOLFlBQVk7S0FDWixTQUFTO0tBQ1QsUUFBUTtJQUNaO0dBQ0g7Ozs7O0dBR0Qsd0JBQUMsT0FBRDtJQUNJLFdBQVU7SUFDVixPQUFPO0tBQ0gsT0FBTztLQUNQLFFBQVE7S0FDUixRQUFRO0tBQ1IsT0FBTztLQUNQLFlBQVk7S0FDWixTQUFTO0tBQ1QsUUFBUTtJQUNaO0dBQ0g7Ozs7O0dBR0Qsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUdJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FLSSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBcUY7S0FFL0Y7Ozs7ZUFDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBMEY7S0FFcEc7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNYLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUEyRDtPQUVyRTs7OztpQkFDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBb0Q7T0FFOUQ7Ozs7ZUFDRjs7Ozs7T0FFSixTQUNHLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNYLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE4QztRQUFTOzs7OztPQUNuRTs7Ozs7T0FHVCx3QkFBQyxRQUFEO1FBQU0sVUFBVTtRQUFnQixXQUFVO2tCQUExQztTQUNJLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFtRDtVQUU3RDs7OztvQkFDUCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLE1BQUQ7WUFBTSxNQUFNO1lBQUksV0FBVTtXQUFnRjs7OztxQkFDMUcsd0JBQUMsU0FBRDtZQUNJLE1BQUs7WUFDTCxhQUFZO1lBQ1osT0FBTztZQUNQLFdBQVcsTUFBTTthQUNiLE1BQU0sTUFBTSxFQUFFLE9BQU87O2FBRXJCLElBQUksbUJBQW1CLEtBQUssR0FBRyxHQUFHLFlBQVksR0FBRztZQUNyRDtZQUNBO1lBQ0EsV0FBVTtXQUNiOzs7O21CQUNBOzs7OztrQkFDSjs7OztvQkFFTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQW1EO1VBRTdEOzs7O29CQUNQLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNYLHdCQUFDLFNBQUQ7WUFDSSxNQUFLO1lBQ0wsYUFBWTtZQUNaLE9BQU87WUFDUCxXQUFXLE1BQU07YUFDYixNQUFNLE1BQU0sRUFBRSxPQUFPO2FBQ3JCLElBQUksbUJBQW1CLEtBQUssR0FBRyxHQUFHLFlBQVksR0FBRztZQUNyRDtZQUNBO1lBQ0EsV0FBVTtXQUNiOzs7OztVQUNBOzs7O2tCQUNKOzs7O2tCQUNKOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBbUQ7VUFFN0Q7Ozs7b0JBQ1Asd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxNQUFEO1lBQU0sTUFBTTtZQUFJLFdBQVU7V0FBZ0Y7Ozs7cUJBQzFHLHdCQUFDLFNBQUQ7WUFDSSxNQUFLO1lBQ0wsYUFBWTtZQUNaLE9BQU87WUFDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztZQUN4QztZQUNBLFdBQVU7V0FDYjs7OzttQkFDQTs7Ozs7a0JBQ0o7Ozs7b0JBRUwsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFtRDtVQUU3RDs7OztvQkFDUCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWCx3QkFBQyxTQUFEO1lBQ0ksTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztZQUM1QztZQUNBLFdBQVU7V0FDYjs7Ozs7VUFDQTs7OztrQkFDSjs7OztrQkFDSjs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQW1EO1VBRTdEOzs7O29CQUNQLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0ksd0JBQUMsTUFBRDthQUFNLE1BQU07YUFBSSxXQUFVO1lBQWdGOzs7OztZQUMxRyx3QkFBQyxTQUFEO2FBQ0ksTUFBTSxlQUFlLFNBQVM7YUFDOUIsYUFBWTthQUNaLE9BQU87YUFDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sS0FBSzthQUMzQzthQUNBLFdBQVU7WUFDYjs7Ozs7WUFDRCx3QkFBQyxVQUFEO2FBQ0ksTUFBSzthQUNMLGVBQWUsZ0JBQWdCLENBQUMsWUFBWTthQUM1QyxXQUFVO2FBQ1YsVUFBUzt1QkFFUixlQUFlLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7d0JBQUksd0JBQUMsS0FBRCxFQUFLLE1BQU0sR0FBSzs7Ozs7WUFDbkQ7Ozs7O1dBQ1A7Ozs7O2tCQUNKOzs7O29CQUVMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBbUQ7VUFFN0Q7Ozs7b0JBQ1Asd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDSSx3QkFBQyxNQUFEO2FBQU0sTUFBTTthQUFJLFdBQVU7WUFBZ0Y7Ozs7O1lBQzFHLHdCQUFDLFNBQUQ7YUFDSSxNQUFNLHNCQUFzQixTQUFTO2FBQ3JDLGFBQVk7YUFDWixPQUFPO2FBQ1AsV0FBVyxNQUFNLG1CQUFtQixFQUFFLE9BQU8sS0FBSzthQUNsRDthQUNBLFdBQVU7WUFDYjs7Ozs7WUFDRCx3QkFBQyxVQUFEO2FBQ0ksTUFBSzthQUNMLGVBQWUsdUJBQXVCLENBQUMsbUJBQW1CO2FBQzFELFdBQVU7YUFDVixVQUFTO3VCQUVSLHNCQUFzQix3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7O3dCQUFJLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7O1lBQzFEOzs7OztXQUNQOzs7OztrQkFDSjs7OztrQkFDSjs7Ozs7O1NBRUwsd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxVQUFVO1VBQ1YsV0FBVTtvQkFFVCxVQUNHLGdEQUNJLHdCQUFDLFNBQUQ7V0FBUyxNQUFNO1dBQUksV0FBVTtVQUFnQjs7OztvQkFDN0Msd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztrQkFDbEM7Ozs7cUJBRUYsK0NBQ0ksd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OzttQkFDN0I7Ozs7O1NBRUY7Ozs7O1FBQ047Ozs7OztPQUVOLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW9DO1FBQXdCOzs7O2tCQUM1RSx3QkFBQyxNQUFEO1NBQ0ksSUFBRztTQUNILFdBQVU7bUJBQ2I7UUFFSzs7OztnQkFDTDs7Ozs7O01BRUo7Ozs7OztJQUNKOzs7O1lBQ0o7Ozs7OztFQUNKOzs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlZ2lzdGVyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyByZWdpc3RlciB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgRmlsZVRleHQsIEFycm93UmlnaHQsIFVzZXIsIE1haWwsIExvY2ssIENhbGVuZGFyLCBMb2FkZXIyLCBFeWUsIEV5ZU9mZiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmNvbnN0IEVNT0pJX1JFR0VYID0gL1tcXHV7MUYzMDB9LVxcdXsxRkFGRn1cXHV7MjYwMH0tXFx1ezI3QkZ9XFx1ezFGMUU2fS1cXHV7MUYxRkZ9XFx1ezIxOTB9LVxcdXsyMUZGfVxcdXsyQjAwfS1cXHV7MkJGRn1cXHVGRTBGXS9ndTtcbmNvbnN0IE5BTUVfUkVHRVggPSAvXlthLXpBLVpcXHMuJy1dKyQvO1xuY29uc3QgVVNFUk5BTUVfUkVHRVggPSAvXlthLXpBLVowLTlfLl0rJC87XG5cbmNvbnN0IFJlZ2lzdGVyID0gKCkgPT4ge1xuICAgIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtmdWxsbmFtZSwgc2V0RnVsbG5hbWVdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtiaXJ0aGRhdGUsIHNldEJpcnRoZGF0ZV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2NvbmZpcm1QYXNzd29yZCwgc2V0Q29uZmlybVBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICAvLyBTdGF0ZSB1bnR1ayB0b2dnbGUgdmlzaWJpbGl0YXMgcGFzc3dvcmRcbiAgICBjb25zdCBbc2hvd1Bhc3N3b3JkLCBzZXRTaG93UGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtzaG93Q29uZmlybVBhc3N3b3JkLCBzZXRTaG93Q29uZmlybVBhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICAgIGNvbnN0IGhhbmRsZVJlZ2lzdGVyID0gYXN5bmMgKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0RXJyb3IoJycpO1xuXG4gICAgY29uc3QgdHJpbW1lZEZ1bGxuYW1lID0gZnVsbG5hbWUudHJpbSgpO1xuICAgIGNvbnN0IHRyaW1tZWRVc2VybmFtZSA9IHVzZXJuYW1lLnRyaW0oKTtcblxuICAgIGlmIChFTU9KSV9SRUdFWC50ZXN0KHRyaW1tZWRGdWxsbmFtZSkgfHwgRU1PSklfUkVHRVgudGVzdCh0cmltbWVkVXNlcm5hbWUpKSB7XG4gICAgICAgIHNldEVycm9yKCdOYW1hIGRhbiB1c2VybmFtZSB0aWRhayBib2xlaCBtZW5nYW5kdW5nIGVtb2ppLicpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKCFOQU1FX1JFR0VYLnRlc3QodHJpbW1lZEZ1bGxuYW1lKSkge1xuICAgICAgICBzZXRFcnJvcignTmFtYSBsZW5na2FwIGhhbnlhIGJvbGVoIGJlcmlzaSBodXJ1Ziwgc3Bhc2ksIHRpdGlrLCBhcG9zdHJvZiwgZGFuIHN0cmlwLicpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKCFVU0VSTkFNRV9SRUdFWC50ZXN0KHRyaW1tZWRVc2VybmFtZSkpIHtcbiAgICAgICAgc2V0RXJyb3IoJ1VzZXJuYW1lIGhhbnlhIGJvbGVoIGJlcmlzaSBodXJ1ZiwgYW5na2EsIHRpdGlrLCBkYW4gdW5kZXJzY29yZSAodGFucGEgc3Bhc2kvc2ltYm9sKS4nKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChwYXNzd29yZCAhPT0gY29uZmlybVBhc3N3b3JkKSB7XG4gICAgICAgIHNldEVycm9yKCdQYXNzd29yZCBkYW4gS29uZmlybWFzaSBQYXNzd29yZCB0aWRhayBjb2Nvay4nKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChwYXNzd29yZC5sZW5ndGggPCA4KSB7XG4gICAgICAgIHNldEVycm9yKCdQYXNzd29yZCBtaW5pbWFsIDgga2FyYWt0ZXIuJyk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlZ2lzdGVyKHRyaW1tZWRGdWxsbmFtZSwgdHJpbW1lZFVzZXJuYW1lLCBlbWFpbC50cmltKCksIHBhc3N3b3JkLCBiaXJ0aGRhdGUpO1xuICAgIHNldExvYWRpbmcoZmFsc2UpO1xuXG4gICAgaWYgKHJlc3VsdC5vayAmJiByZXN1bHQuc3RhdHVzID09PSAyMDApIHtcbiAgICAgICAgbmF2aWdhdGUoJy92ZXJpZnknLCB7XG4gICAgICAgICAgICBzdGF0ZTogeyBmdWxsbmFtZTogdHJpbW1lZEZ1bGxuYW1lLCB1c2VybmFtZTogdHJpbW1lZFVzZXJuYW1lLCBlbWFpbDogZW1haWwudHJpbSgpLCBwYXNzd29yZCwgYmlydGhkYXRlIH1cbiAgICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgc2V0RXJyb3IocmVzdWx0Lm1lc3NhZ2UgfHwgJ1JlZ2lzdHJhc2kgZ2FnYWwuIFNpbGFrYW4gY29iYSBsYWdpLicpO1xuICAgIH1cbn07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLXNjcmVlbiBtYXgtaC1zY3JlZW4gdy1mdWxsIGJnLVsjMDA0RDRFXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgc206cC02IGxnOnAtMTIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHNlbGVjdC1ub25lIHRvdWNoLW5vbmVcIj4gICBcbiAgICAgICAgey8qIEJhY2tncm91bmQgR3JhZGllbiBVdGFtYSAqL31cbiAgICAgICAgPGRpdiBcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgcG9pbnRlci1ldmVudHMtbm9uZVwiXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQoMjAwZGVnLCAjMkVEOEMzIDAlLCAjMEZBODlFIDM1JSwgIzAxODA4MSA3NSUsICMwMDRENEUgMTAwJSknXG4gICAgICAgICAgICB9fVxuICAgICAgICAvPlxuXG4gICAgICAgIHsvKiBCdWxhdGFuIEdyYWRpZW4gS2lyaSBBdGFzICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBwb2ludGVyLWV2ZW50cy1ub25lIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIHdpZHRoOiAnY2xhbXAoMzUwcHgsIDQ1dncsIDc1MHB4KScsXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAnY2xhbXAoMzUwcHgsIDQ1dncsIDc1MHB4KScsXG4gICAgICAgICAgICAgICAgdG9wOiAnLTEwJScsXG4gICAgICAgICAgICAgICAgbGVmdDogJy0xMCUnLFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQoLTE0M2RlZywgIzJFRDhDMyAwJSwgcmdiYSgxMCwgOTUsIDExMCwgMC43KSAxMDAlKScsXG4gICAgICAgICAgICAgICAgb3BhY2l0eTogMC42LFxuICAgICAgICAgICAgICAgIHpJbmRleDogMVxuICAgICAgICAgICAgfX1cbiAgICAgICAgLz5cblxuICAgICAgICB7LyogQnVsYXRhbiBHcmFkaWVuIEthbmFuIEJhd2FoICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBwb2ludGVyLWV2ZW50cy1ub25lIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIHdpZHRoOiAnY2xhbXAoMzUwcHgsIDQ1dncsIDc1MHB4KScsXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAnY2xhbXAoMzUwcHgsIDQ1dncsIDc1MHB4KScsXG4gICAgICAgICAgICAgICAgYm90dG9tOiAnLTEwJScsXG4gICAgICAgICAgICAgICAgcmlnaHQ6ICctMTAlJyxcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzJFRDhDMyAwJSwgcmdiYSgxMCwgMjksIDkzLCAwLjcpIDEwMCUpJyxcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjgsXG4gICAgICAgICAgICAgICAgekluZGV4OiAxXG4gICAgICAgICAgICB9fVxuICAgICAgICAvPlxuXG4gICAgICAgIHsvKiBDb250YWluZXIgVXRhbWEgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCB3LWZ1bGwgbWF4LXctNnhsIGZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtOCBsZzpnYXAtMTIgbXktYXV0b1wiPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogTGVmdCBzaWRlIGJyYW5kaW5nICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbGc6dy0xLzIgdGV4dC13aGl0ZSBzcGFjZS15LTQgdGV4dC1jZW50ZXIgbGc6dGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHgtNCBweS0yIGJnLXdoaXRlLzEwIGJhY2tkcm9wLWJsdXItbWQgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci13aGl0ZS8yMFwiPlxuICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17MjB9IGNsYXNzTmFtZT1cInRleHQtWyMyRUQ4QzNdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSB0cmFja2luZy13aWRlXCI+Rm9ybVVwIFJlZ2lzdHJhdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIHNtOnRleHQtNXhsIGxnOnRleHQtNnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCBsZWFkaW5nLXRpZ2h0IHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgTXVsYWkgQmVyc2FtYSBGb3JtVXBcbiAgICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBzbTp0ZXh0LWxnIHRleHQtd2hpdGUvOTUgZm9udC1tZWRpdW0gbGVhZGluZy1yZWxheGVkIG1heC13LWxnIG14LWF1dG8gbGc6bXgtMFwiPlxuICAgICAgICAgICAgICAgICAgICBEYWZ0YXIgYWt1biBncmF0aXMgZGFuIGJ1YXQgYmVyYmFnYWkgZm9ybXVsaXIsIHN1cnZlaSwgc2VydGEgdWppYW4gZGFyaW5nIGRlbmdhbiBtdWRhaC5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFJpZ2h0IHNpZGUgZm9ybSBjYXJkICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbGc6dy0xLzIgbWF4LXctbGdcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy1ibGFjay80MCBiYWNrZHJvcC1ibHVyLVsyMHB4XSBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHJvdW5kZWQtWzI4cHhdIHAtNiBzbTpwLTEwIHNoYWRvdy1bMF84cHhfMzJweF8wX3JnYmEoMCwwLDAsMC4zNyldIHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIHNtOnRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQnVhdCBBa3VuIEJhcnVcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZS83MCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTGVuZ2thcGkgZGF0YSBkaSBiYXdhaCBpbmkgdW50dWsgbWVtdWxhaVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1yZWQtNTAwLzIwIGJvcmRlciBib3JkZXItcmVkLTUwMC8zMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1yZWQtMzAwIHRleHQtY2VudGVyXCI+e2Vycm9yfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVSZWdpc3Rlcn0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTMuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZS85MCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5hbWEgTGVuZ2thcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlciBzaXplPXsxNn0gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtd2hpdGUvNTAgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOYW1hIExlbmdrYXBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmdWxsbmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gZS50YXJnZXQudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEhhbnlhIGl6aW5rYW4gaHVydWYsIHNwYXNpLCB0aXRpaywgYXBvc3Ryb2YsIHN0cmlwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgvXlthLXpBLVpcXHMuJy1dKiQvLnRlc3QodmFsKSkgc2V0RnVsbG5hbWUodmFsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTEwIHByLTMuNSBweS0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCBiZy1ibGFjay8zMCB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyOnRleHQtd2hpdGUvNDAgZm9udC1tZWRpdW0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJnLWJsYWNrLzUwIGZvY3VzOmJvcmRlci1bIzJFRDhDM10gZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctWyMyRUQ4QzNdIHRleHQteHMgc206dGV4dC1zbSB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctaW5uZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUvOTAgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBVc2VybmFtZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ1c2VybmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKC9eW2EtekEtWjAtOV8uXSokLy50ZXN0KHZhbCkpIHNldFVzZXJuYW1lKHZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItd2hpdGUvMTAgYmctYmxhY2svMzAgdGV4dC13aGl0ZSBwbGFjZWhvbGRlcjp0ZXh0LXdoaXRlLzQwIGZvbnQtbWVkaXVtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy1ibGFjay81MCBmb2N1czpib3JkZXItWyMyRUQ4QzNdIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLVsjMkVEOEMzXSB0ZXh0LXhzIHNtOnRleHQtc20gdHJhbnNpdGlvbi1hbGwgc2hhZG93LWlubmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMy41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlLzkwIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW1haWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1haWwgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMy41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXdoaXRlLzUwIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIm5hbWFAZW1haWwuY29tXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTAgcHItMy41IHB5LTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIGJnLWJsYWNrLzMwIHRleHQtd2hpdGUgcGxhY2Vob2xkZXI6dGV4dC13aGl0ZS80MCBmb250LW1lZGl1bSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6YmctYmxhY2svNTAgZm9jdXM6Ym9yZGVyLVsjMkVEOEMzXSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzJFRDhDM10gdGV4dC14cyBzbTp0ZXh0LXNtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1pbm5lclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZS85MCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhbmdnYWwgTGFoaXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtiaXJ0aGRhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCaXJ0aGRhdGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCBiZy1ibGFjay8zMCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy1ibGFjay81MCBmb2N1czpib3JkZXItWyMyRUQ4QzNdIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLVsjMkVEOEMzXSB0ZXh0LXhzIHNtOnRleHQtc20gdHJhbnNpdGlvbi1hbGwgc2hhZG93LWlubmVyIFtjb2xvci1zY2hlbWU6ZGFya11cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUvOTAgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXNzd29yZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9jayBzaXplPXsxNn0gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtd2hpdGUvNTAgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPXtzaG93UGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1pbi4gOCBrYXJha3RlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTEwIHByLTEwIHB5LTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIGJnLWJsYWNrLzMwIHRleHQtd2hpdGUgcGxhY2Vob2xkZXI6dGV4dC13aGl0ZS80MCBmb250LW1lZGl1bSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6YmctYmxhY2svNTAgZm9jdXM6Ym9yZGVyLVsjMkVEOEMzXSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzJFRDhDM10gdGV4dC14cyBzbTp0ZXh0LXNtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1pbm5lclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQYXNzd29yZCghc2hvd1Bhc3N3b3JkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtd2hpdGUvNTAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBwLTAuNSBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhYkluZGV4PVwiLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93UGFzc3dvcmQgPyA8RXllT2ZmIHNpemU9ezE2fSAvPiA6IDxFeWUgc2l6ZT17MTZ9IC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlLzkwIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVWxhbmdpIFBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2NrIHNpemU9ezE2fSBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC13aGl0ZS81MCBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dDb25maXJtUGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlVsYW5naSBwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpcm1QYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbmZpcm1QYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTAgcHItMTAgcHktMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItd2hpdGUvMTAgYmctYmxhY2svMzAgdGV4dC13aGl0ZSBwbGFjZWhvbGRlcjp0ZXh0LXdoaXRlLzQwIGZvbnQtbWVkaXVtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy1ibGFjay81MCBmb2N1czpib3JkZXItWyMyRUQ4QzNdIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLVsjMkVEOEMzXSB0ZXh0LXhzIHNtOnRleHQtc20gdHJhbnNpdGlvbi1hbGwgc2hhZG93LWlubmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0NvbmZpcm1QYXNzd29yZCghc2hvd0NvbmZpcm1QYXNzd29yZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMy41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXdoaXRlLzUwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgcC0wLjUgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJJbmRleD1cIi0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd0NvbmZpcm1QYXNzd29yZCA/IDxFeWVPZmYgc2l6ZT17MTZ9IC8+IDogPEV5ZSBzaXplPXsxNn0gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtdC00IHB5LTMuNSBweC02IGJnLVsjMEZBODlFXSBob3ZlcjpiZy1bIzBkOTY4ZF0gYWN0aXZlOnNjYWxlLVswLjk4XSB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLWZ1bGwgc2hhZG93LVswXzZweF8yMHB4X3JnYmEoMTUsMTY4LDE1OCwwLjQpXSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgdGV4dC14cyBzbTp0ZXh0LXNtIHRyYWNraW5nLXdpZGUgZGlzYWJsZWQ6b3BhY2l0eS02MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NZW5kYWZ0YXJrYW4gQWt1bi4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkRhZnRhciBTZWthcmFuZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwdC0zIGJvcmRlci10IGJvcmRlci13aGl0ZS8xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlLzcwXCI+U3VkYWggcHVueWEgYWt1bj8gPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9sb2dpblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1bIzJFRDhDM10gaG92ZXI6dW5kZXJsaW5lIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNYXN1ayBrZSBTaW5pXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4pO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUmVnaXN0ZXI7Il19