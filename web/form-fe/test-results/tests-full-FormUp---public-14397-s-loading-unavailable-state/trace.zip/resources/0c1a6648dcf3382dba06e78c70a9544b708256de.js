import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Sidebar.jsx");const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import { LayoutDashboard, Folder, MessageSquare, LayoutTemplate, History, LogOut, Shield, Bot, Sparkles, X } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate, useLocation, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { getLocalUser, clearSession } from "/src/services/apiService.js";
import logo from "/src/assets/logo.png?import";
import ConfirmModal from "/src/components/ui/ConfirmModal.jsx";
import UserGuideModal from "/src/components/ui/UserGuideModal.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/layout/Sidebar.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function Sidebar({ onStartTour = null, isOpen = false, onClose = () => {} }) {
	_s();
	const navigate = useNavigate();
	const location = useLocation();
	const user = getLocalUser();
	const [guideModalOpen, setGuideModalOpen] = useState(false);
	const [confirmNav, setConfirmNav] = useState({
		isOpen: false,
		action: null,
		message: ""
	});
	const navigateWithConfirm = (path) => {
		if (window.__formBuilderDirty === true) {
			setConfirmNav({
				isOpen: true,
				message: "Ada perubahan yang belum disimpan. Yakin ingin meninggalkan halaman ini?",
				action: () => {
					navigate(path);
					onClose();
				}
			});
			return;
		}
		navigate(path);
		onClose();
	};
	const handleLogout = () => {
		if (window.__formBuilderDirty === true) {
			setConfirmNav({
				isOpen: true,
				message: "Ada perubahan yang belum disimpan. Yakin ingin keluar?",
				action: () => {
					clearSession();
					navigate("/login", { replace: true });
				}
			});
			return;
		}
		clearSession();
		navigate("/login", { replace: true });
	};
	const menuItems = [
		{
			path: "/dashboard",
			icon: LayoutDashboard,
			label: "Dashboard"
		},
		{
			path: "/my-forms",
			icon: Folder,
			label: "Formulir Saya"
		},
		{
			path: "/responses",
			icon: MessageSquare,
			label: "Respons"
		},
		{
			path: "/templates",
			icon: LayoutTemplate,
			label: "Templat"
		},
		{
			path: "/history",
			icon: History,
			label: "Riwayat"
		}
	];
	const userRole = (user?.role || "").toUpperCase();
	if (userRole === "ADMIN" || userRole === "SUPER_ADMIN") {
		menuItems.push({
			path: "/admin",
			icon: Shield,
			label: "Kontrol Admin"
		});
	}
	const isAiChatActive = location.pathname.startsWith("/ai-chat");
	const renderSidebarContent = () => /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col h-full p-4 sm:p-6 overflow-hidden",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between shrink-0 mb-6",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: "/dashboard",
					onClick: onClose,
					className: "flex items-center gap-3 group",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "p-2.5 bg-white/15 dark:bg-white/10 rounded-xl group-hover:bg-white/25 transition-all",
						children: /* @__PURE__ */ _jsxDEV("img", {
							src: logo,
							alt: "FormUp Logo",
							className: "w-6 h-6 object-contain"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold tracking-tight leading-none text-white",
						children: "FormUp"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 25
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					type: "button",
					className: "md:hidden p-1.5 rounded-lg bg-white/10 text-teal-100 hover:text-white cursor-pointer active:scale-95 transition-transform",
					children: /* @__PURE__ */ _jsxDEV(X, { size: 20 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("nav", {
				className: "flex-1 space-y-1.5 overflow-y-auto min-h-0 pr-1 custom-scrollbar",
				"data-tour": "sidebar-nav",
				children: menuItems.map((item) => {
					const Icon = item.icon;
					const isActive = location.pathname.startsWith(item.path);
					return /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => navigateWithConfirm(item.path),
						className: `w-full flex items-center gap-3 px-4 py-3 font-bold text-sm rounded-xl transition-all cursor-pointer ${isActive ? "bg-white/20 dark:bg-teal-600/30 text-white shadow-xs border border-white/20 dark:border-teal-500/40" : "text-teal-100/80 dark:text-slate-300 hover:bg-white/10 dark:hover:bg-slate-800/80 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Icon, {
							size: 18,
							className: isActive ? "text-teal-200 dark:text-teal-300" : "text-teal-200/70 dark:text-slate-400"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.label }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 29
						}, this)]
					}, item.path, true, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 25
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "pt-4 mt-auto shrink-0 space-y-2 border-t border-white/10 dark:border-slate-800",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => navigateWithConfirm("/ai-chat"),
					className: `w-full flex items-center gap-3 px-4 py-3 font-bold text-sm rounded-xl transition-all cursor-pointer ${isAiChatActive ? "bg-white/20 dark:bg-teal-600/30 text-white shadow-xs border border-white/20 dark:border-teal-500/40" : "text-teal-100/80 dark:text-slate-300 hover:bg-white/10 dark:hover:bg-slate-800/80 hover:text-white"}`,
					children: [/* @__PURE__ */ _jsxDEV(Bot, {
						size: 18,
						className: isAiChatActive ? "text-teal-200 dark:text-teal-300" : "text-teal-200/70 dark:text-slate-400"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "AI Assistant" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 131,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: handleLogout,
					className: "w-full flex items-center gap-3 px-4 py-3 font-bold text-sm text-teal-100 hover:text-white hover:bg-white/10 dark:text-red-400 dark:hover:bg-red-950/30 dark:hover:text-red-300 rounded-xl transition-all cursor-pointer",
					children: [/* @__PURE__ */ _jsxDEV(LogOut, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Keluar" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 151,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 130,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 77,
		columnNumber: 9
	}, this);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("aside", {
			className: "w-64 bg-[#005B52] dark:bg-slate-900 border-r border-[#004D46] dark:border-slate-800 text-white hidden md:flex shrink-0 h-screen sticky top-0 z-40 overflow-hidden",
			children: renderSidebarContent()
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 166,
			columnNumber: 13
		}, this),
		isOpen && /* @__PURE__ */ _jsxDEV("div", {
			onClick: onClose,
			className: "fixed inset-0 bg-black/60 z-50 md:hidden backdrop-blur-xs transition-opacity"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 172,
			columnNumber: 17
		}, this),
		/* @__PURE__ */ _jsxDEV("aside", {
			className: `
                    fixed top-0 left-0 bottom-0 w-72 max-w-[85vw] bg-[#005B52] dark:bg-slate-900 text-white z-50 md:hidden
                    transform transition-transform duration-300 ease-in-out shadow-2xl h-[100dvh]
                    ${isOpen ? "translate-x-0" : "-translate-x-full"}
                `,
			children: renderSidebarContent()
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 177,
			columnNumber: 13
		}, this),
		/* @__PURE__ */ _jsxDEV(UserGuideModal, {
			isOpen: guideModalOpen,
			onClose: () => setGuideModalOpen(false),
			onStartTour: () => {
				setGuideModalOpen(false);
				if (onStartTour) {
					onStartTour();
				} else if (window.__startFormUpTour) {
					window.__startFormUpTour();
				}
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 188,
			columnNumber: 13
		}, this),
		/* @__PURE__ */ _jsxDEV(ConfirmModal, {
			isOpen: confirmNav.isOpen,
			onClose: () => setConfirmNav({
				isOpen: false,
				action: null,
				message: ""
			}),
			onConfirm: () => {
				const action = confirmNav.action;
				setConfirmNav({
					isOpen: false,
					action: null,
					message: ""
				});
				if (action) action();
			},
			title: "Perubahan Belum Disimpan",
			message: confirmNav.message,
			variant: "danger",
			confirmText: "Ya, Lanjutkan"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 200,
			columnNumber: 13
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 164,
		columnNumber: 9
	}, this);
}
_s(Sidebar, "oZiAMPg3WEI2+t3ckWwxa+QWKXU=", false, function() {
	return [useNavigate, useLocation];
});
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Sidebar.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/layout/Sidebar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/layout/Sidebar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/layout/Sidebar.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDSSxpQkFDQSxRQUNBLGVBQ0EsZ0JBQ0EsU0FDQSxRQUNBLFFBQ0EsS0FDQSxVQUNBLFNBQ0c7QUFDUCxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGFBQWEsYUFBYSxZQUFZO0FBQy9DLFNBQVMsY0FBYyxvQkFBb0I7QUFDM0MsT0FBTyxVQUFVO0FBQ2pCLE9BQU8sa0JBQWtCO0FBQ3pCLE9BQU8sb0JBQW9COzs7O0FBRTNCLGVBQWUsU0FBUyxRQUFRLEVBQUUsY0FBYyxNQUFNLFNBQVMsT0FBTyxnQkFBZ0IsQ0FBQyxLQUFLOztDQUN4RixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLE9BQU8sYUFBYTtDQUMxQixNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEtBQUs7Q0FDMUQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVM7RUFBRSxRQUFRO0VBQU8sUUFBUTtFQUFNLFNBQVM7Q0FBRyxDQUFDO0NBRXpGLE1BQU0sdUJBQXVCLFNBQVM7RUFDbEMsSUFBSSxPQUFPLHVCQUF1QixNQUFNO0dBQ3BDLGNBQWM7SUFDVixRQUFRO0lBQ1IsU0FBUztJQUNULGNBQWM7S0FDVixTQUFTLElBQUk7S0FDYixRQUFRO0lBQ1o7R0FDSixDQUFDO0dBQ0Q7RUFDSjtFQUVBLFNBQVMsSUFBSTtFQUNiLFFBQVE7Q0FDWjtDQUVBLE1BQU0scUJBQXFCO0VBQ3ZCLElBQUksT0FBTyx1QkFBdUIsTUFBTTtHQUNwQyxjQUFjO0lBQ1YsUUFBUTtJQUNSLFNBQVM7SUFDVCxjQUFjO0tBQ1YsYUFBYTtLQUNiLFNBQVMsVUFBVSxFQUFFLFNBQVMsS0FBSyxDQUFDO0lBQ3hDO0dBQ0osQ0FBQztHQUNEO0VBQ0o7RUFFQSxhQUFhO0VBQ2IsU0FBUyxVQUFVLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDeEM7Q0FFQSxNQUFNLFlBQVk7RUFDZDtHQUFFLE1BQU07R0FBYyxNQUFNO0dBQWlCLE9BQU87RUFBWTtFQUNoRTtHQUFFLE1BQU07R0FBYSxNQUFNO0dBQVEsT0FBTztFQUFnQjtFQUMxRDtHQUFFLE1BQU07R0FBYyxNQUFNO0dBQWUsT0FBTztFQUFVO0VBQzVEO0dBQUUsTUFBTTtHQUFjLE1BQU07R0FBZ0IsT0FBTztFQUFVO0VBQzdEO0dBQUUsTUFBTTtHQUFZLE1BQU07R0FBUyxPQUFPO0VBQVU7Q0FDeEQ7Q0FFQSxNQUFNLFlBQVksTUFBTSxRQUFRLEdBQUUsQ0FBRSxZQUFZO0NBQ2hELElBQUksYUFBYSxXQUFXLGFBQWEsZUFBZTtFQUNwRCxVQUFVLEtBQUs7R0FBRSxNQUFNO0dBQVUsTUFBTTtHQUFRLE9BQU87RUFBZ0IsQ0FBQztDQUMzRTtDQUVBLE1BQU0saUJBQWlCLFNBQVMsU0FBUyxXQUFXLFVBQVU7Q0FFOUQsTUFBTSw2QkFDRix3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUksd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO0tBQWEsU0FBUztLQUFTLFdBQVU7ZUFBbEQsQ0FDSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWCx3QkFBQyxPQUFEO09BQUssS0FBSztPQUFNLEtBQUk7T0FBYyxXQUFVO01BQTBCOzs7OztLQUNyRTs7OztlQUNMLHdCQUFDLE9BQUQsWUFDSSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZ0U7S0FBVTs7OztjQUN2Rjs7OzthQUNIOzs7OztjQUVOLHdCQUFDLFVBQUQ7S0FDSSxTQUFTO0tBQ1QsTUFBSztLQUNMLFdBQVU7ZUFFVix3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztJQUNWOzs7O1lBQ1A7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQW1FLGFBQVU7Y0FDdkYsVUFBVSxLQUFLLFNBQVM7S0FDckIsTUFBTSxPQUFPLEtBQUs7S0FDbEIsTUFBTSxXQUFXLFNBQVMsU0FBUyxXQUFXLEtBQUssSUFBSTtLQUV2RCxPQUNJLHdCQUFDLFVBQUQ7TUFFSSxNQUFLO01BQ0wsZUFBZSxvQkFBb0IsS0FBSyxJQUFJO01BQzVDLFdBQVcsdUdBQ1AsV0FDTSx3R0FDQTtnQkFQZCxDQVVJLHdCQUFDLE1BQUQ7T0FDSSxNQUFNO09BQ04sV0FDSSxXQUNNLHFDQUNBO01BRWI7Ozs7Z0JBQ0Qsd0JBQUMsUUFBRCxZQUFPLEtBQUssTUFBWTs7OztjQUNwQjtRQWxCQyxLQUFLOzs7O1lBa0JOO0lBRWhCLENBQUM7R0FDQTs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsVUFBRDtLQUNJLE1BQUs7S0FDTCxlQUFlLG9CQUFvQixVQUFVO0tBQzdDLFdBQVcsdUdBQ1AsaUJBQ00sd0dBQ0E7ZUFOZCxDQVNJLHdCQUFDLEtBQUQ7TUFDSSxNQUFNO01BQ04sV0FDSSxpQkFDTSxxQ0FDQTtLQUViOzs7O2VBQ0Qsd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7O2FBQ3BCOzs7OztjQUVSLHdCQUFDLFVBQUQ7S0FDSSxNQUFLO0tBQ0wsU0FBUztLQUNULFdBQVU7ZUFIZCxDQUtJLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7ZUFDbkIsd0JBQUMsUUFBRCxZQUFNLFNBQVk7Ozs7YUFDZDs7Ozs7WUFDUDs7Ozs7O0VBQ0o7Ozs7OztDQUdULE9BQ0k7RUFFSSx3QkFBQyxTQUFEO0dBQU8sV0FBVTthQUNaLHFCQUFxQjtFQUNuQjs7Ozs7RUFHTixVQUNHLHdCQUFDLE9BQUQ7R0FDSSxTQUFTO0dBQ1QsV0FBVTtFQUNiOzs7OztFQUVMLHdCQUFDLFNBQUQ7R0FDSSxXQUFXOzs7c0JBR0wsU0FBUyxrQkFBa0Isb0JBQW9COzthQUdwRCxxQkFBcUI7RUFDbkI7Ozs7O0VBR1Asd0JBQUMsZ0JBQUQ7R0FDSSxRQUFRO0dBQ1IsZUFBZSxrQkFBa0IsS0FBSztHQUN0QyxtQkFBbUI7SUFDZixrQkFBa0IsS0FBSztJQUN2QixJQUFJLGFBQWE7S0FDYixZQUFZO0lBQ2hCLE9BQU8sSUFBSSxPQUFPLG1CQUFtQjtLQUNqQyxPQUFPLGtCQUFrQjtJQUM3QjtHQUNKO0VBQ0g7Ozs7O0VBQ0Qsd0JBQUMsY0FBRDtHQUNJLFFBQVEsV0FBVztHQUNuQixlQUFlLGNBQWM7SUFBRSxRQUFRO0lBQU8sUUFBUTtJQUFNLFNBQVM7R0FBRyxDQUFDO0dBQ3pFLGlCQUFpQjtJQUNiLE1BQU0sU0FBUyxXQUFXO0lBQzFCLGNBQWM7S0FBRSxRQUFRO0tBQU8sUUFBUTtLQUFNLFNBQVM7SUFBRyxDQUFDO0lBQzFELElBQUksUUFBUSxPQUFPO0dBQ3ZCO0dBQ0EsT0FBTTtHQUNOLFNBQVMsV0FBVztHQUNwQixTQUFRO0dBQ1IsYUFBWTtFQUNmOzs7OztDQUNIOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNpZGViYXIuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7ICBcbiAgICBMYXlvdXREYXNoYm9hcmQsIFxuICAgIEZvbGRlciwgXG4gICAgTWVzc2FnZVNxdWFyZSwgXG4gICAgTGF5b3V0VGVtcGxhdGUsIFxuICAgIEhpc3RvcnksXG4gICAgTG9nT3V0LFxuICAgIFNoaWVsZCxcbiAgICBCb3QsXG4gICAgU3BhcmtsZXMsXG4gICAgWFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlTG9jYXRpb24sIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IGdldExvY2FsVXNlciwgY2xlYXJTZXNzaW9uIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgbG9nbyBmcm9tICcuLi8uLi9hc3NldHMvbG9nby5wbmcnO1xuaW1wb3J0IENvbmZpcm1Nb2RhbCBmcm9tICcuLi91aS9Db25maXJtTW9kYWwnO1xuaW1wb3J0IFVzZXJHdWlkZU1vZGFsIGZyb20gJy4uL3VpL1VzZXJHdWlkZU1vZGFsJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2lkZWJhcih7IG9uU3RhcnRUb3VyID0gbnVsbCwgaXNPcGVuID0gZmFsc2UsIG9uQ2xvc2UgPSAoKSA9PiB7fSB9KSB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgICBjb25zdCB1c2VyID0gZ2V0TG9jYWxVc2VyKCk7XG4gICAgY29uc3QgW2d1aWRlTW9kYWxPcGVuLCBzZXRHdWlkZU1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2NvbmZpcm1OYXYsIHNldENvbmZpcm1OYXZdID0gdXNlU3RhdGUoeyBpc09wZW46IGZhbHNlLCBhY3Rpb246IG51bGwsIG1lc3NhZ2U6ICcnIH0pO1xuXG4gICAgY29uc3QgbmF2aWdhdGVXaXRoQ29uZmlybSA9IChwYXRoKSA9PiB7XG4gICAgICAgIGlmICh3aW5kb3cuX19mb3JtQnVpbGRlckRpcnR5ID09PSB0cnVlKSB7XG4gICAgICAgICAgICBzZXRDb25maXJtTmF2KHtcbiAgICAgICAgICAgICAgICBpc09wZW46IHRydWUsXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogJ0FkYSBwZXJ1YmFoYW4geWFuZyBiZWx1bSBkaXNpbXBhbi4gWWFraW4gaW5naW4gbWVuaW5nZ2Fsa2FuIGhhbGFtYW4gaW5pPycsXG4gICAgICAgICAgICAgICAgYWN0aW9uOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKHBhdGgpO1xuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgbmF2aWdhdGUocGF0aCk7XG4gICAgICAgIG9uQ2xvc2UoKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xuICAgICAgICBpZiAod2luZG93Ll9fZm9ybUJ1aWxkZXJEaXJ0eSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgc2V0Q29uZmlybU5hdih7XG4gICAgICAgICAgICAgICAgaXNPcGVuOiB0cnVlLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdBZGEgcGVydWJhaGFuIHlhbmcgYmVsdW0gZGlzaW1wYW4uIFlha2luIGluZ2luIGtlbHVhcj8nLFxuICAgICAgICAgICAgICAgIGFjdGlvbjogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjbGVhclNlc3Npb24oKTtcbiAgICAgICAgICAgICAgICAgICAgbmF2aWdhdGUoJy9sb2dpbicsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjbGVhclNlc3Npb24oKTtcbiAgICAgICAgbmF2aWdhdGUoJy9sb2dpbicsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgbWVudUl0ZW1zID0gW1xuICAgICAgICB7IHBhdGg6ICcvZGFzaGJvYXJkJywgaWNvbjogTGF5b3V0RGFzaGJvYXJkLCBsYWJlbDogJ0Rhc2hib2FyZCcgfSxcbiAgICAgICAgeyBwYXRoOiAnL215LWZvcm1zJywgaWNvbjogRm9sZGVyLCBsYWJlbDogJ0Zvcm11bGlyIFNheWEnIH0sXG4gICAgICAgIHsgcGF0aDogJy9yZXNwb25zZXMnLCBpY29uOiBNZXNzYWdlU3F1YXJlLCBsYWJlbDogJ1Jlc3BvbnMnIH0sXG4gICAgICAgIHsgcGF0aDogJy90ZW1wbGF0ZXMnLCBpY29uOiBMYXlvdXRUZW1wbGF0ZSwgbGFiZWw6ICdUZW1wbGF0JyB9LFxuICAgICAgICB7IHBhdGg6ICcvaGlzdG9yeScsIGljb246IEhpc3RvcnksIGxhYmVsOiAnUml3YXlhdCcgfSxcbiAgICBdO1xuXG4gICAgY29uc3QgdXNlclJvbGUgPSAodXNlcj8ucm9sZSB8fCAnJykudG9VcHBlckNhc2UoKTtcbiAgICBpZiAodXNlclJvbGUgPT09ICdBRE1JTicgfHwgdXNlclJvbGUgPT09ICdTVVBFUl9BRE1JTicpIHtcbiAgICAgICAgbWVudUl0ZW1zLnB1c2goeyBwYXRoOiAnL2FkbWluJywgaWNvbjogU2hpZWxkLCBsYWJlbDogJ0tvbnRyb2wgQWRtaW4nIH0pO1xuICAgIH1cblxuICAgIGNvbnN0IGlzQWlDaGF0QWN0aXZlID0gbG9jYXRpb24ucGF0aG5hbWUuc3RhcnRzV2l0aCgnL2FpLWNoYXQnKTtcblxuICAgIGNvbnN0IHJlbmRlclNpZGViYXJDb250ZW50ID0gKCkgPT4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaC1mdWxsIHAtNCBzbTpwLTYgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICB7LyogSGVhZGVyIChUZXJrdW5jaSBkaSBhdGFzKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNocmluay0wIG1iLTZcIj5cbiAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9kYXNoYm9hcmRcIiBvbkNsaWNrPXtvbkNsb3NlfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMi41IGJnLXdoaXRlLzE1IGRhcms6Ymctd2hpdGUvMTAgcm91bmRlZC14bCBncm91cC1ob3ZlcjpiZy13aGl0ZS8yNSB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2xvZ299IGFsdD1cIkZvcm1VcCBMb2dvXCIgY2xhc3NOYW1lPVwidy02IGgtNiBvYmplY3QtY29udGFpblwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdHJhY2tpbmctdGlnaHQgbGVhZGluZy1ub25lIHRleHQtd2hpdGVcIj5Gb3JtVXA8L2gxPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L0xpbms+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfSBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1kOmhpZGRlbiBwLTEuNSByb3VuZGVkLWxnIGJnLXdoaXRlLzEwIHRleHQtdGVhbC0xMDAgaG92ZXI6dGV4dC13aGl0ZSBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MjB9IC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE5hdmlnYXNpIFV0YW1hIChIYW55YSBhcmVhIGluaSB5YW5nIGRhcGF0IGRpLXNjcm9sbCBqaWthIGxheWFyIHRlcmxhbHUgcGVuZGVrKSAqL31cbiAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleC0xIHNwYWNlLXktMS41IG92ZXJmbG93LXktYXV0byBtaW4taC0wIHByLTEgY3VzdG9tLXNjcm9sbGJhclwiIGRhdGEtdG91cj1cInNpZGViYXItbmF2XCI+XG4gICAgICAgICAgICAgICAge21lbnVJdGVtcy5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IGl0ZW0uaWNvbjtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBsb2NhdGlvbi5wYXRobmFtZS5zdGFydHNXaXRoKGl0ZW0ucGF0aCk7XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ucGF0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZVdpdGhDb25maXJtKGl0ZW0ucGF0aCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTQgcHktMyBmb250LWJvbGQgdGV4dC1zbSByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZS8yMCBkYXJrOmJnLXRlYWwtNjAwLzMwIHRleHQtd2hpdGUgc2hhZG93LXhzIGJvcmRlciBib3JkZXItd2hpdGUvMjAgZGFyazpib3JkZXItdGVhbC01MDAvNDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXRlYWwtMTAwLzgwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctd2hpdGUvMTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvODAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsxOH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC10ZWFsLTIwMCBkYXJrOnRleHQtdGVhbC0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC10ZWFsLTIwMC83MCBkYXJrOnRleHQtc2xhdGUtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvbmF2PlxuXG4gICAgICAgICAgICB7LyogQm90dG9tIFNlY3Rpb24gKEFJIEFzc2lzdGFudCAmIExvZ291dCAtIFRlcmt1bmNpIGRpIGJhd2FoKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBtdC1hdXRvIHNocmluay0wIHNwYWNlLXktMiBib3JkZXItdCBib3JkZXItd2hpdGUvMTAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGVXaXRoQ29uZmlybSgnL2FpLWNoYXQnKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTQgcHktMyBmb250LWJvbGQgdGV4dC1zbSByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0FpQ2hhdEFjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlLzIwIGRhcms6YmctdGVhbC02MDAvMzAgdGV4dC13aGl0ZSBzaGFkb3cteHMgYm9yZGVyIGJvcmRlci13aGl0ZS8yMCBkYXJrOmJvcmRlci10ZWFsLTUwMC80MCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXRlYWwtMTAwLzgwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctd2hpdGUvMTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvODAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8Qm90XG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsxOH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBaUNoYXRBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC10ZWFsLTIwMCBkYXJrOnRleHQtdGVhbC0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtdGVhbC0yMDAvNzAgZGFyazp0ZXh0LXNsYXRlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QUkgQXNzaXN0YW50PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTG9nb3V0fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNCBweS0zIGZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtdGVhbC0xMDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy13aGl0ZS8xMCBkYXJrOnRleHQtcmVkLTQwMCBkYXJrOmhvdmVyOmJnLXJlZC05NTAvMzAgZGFyazpob3Zlcjp0ZXh0LXJlZC0zMDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8TG9nT3V0IHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5LZWx1YXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICB7LyogMS4gU2lkZWJhciBEZXNrdG9wICovfVxuICAgICAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInctNjQgYmctWyMwMDVCNTJdIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1yIGJvcmRlci1bIzAwNEQ0Nl0gZGFyazpib3JkZXItc2xhdGUtODAwIHRleHQtd2hpdGUgaGlkZGVuIG1kOmZsZXggc2hyaW5rLTAgaC1zY3JlZW4gc3RpY2t5IHRvcC0wIHotNDAgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAge3JlbmRlclNpZGViYXJDb250ZW50KCl9XG4gICAgICAgICAgICA8L2FzaWRlPlxuXG4gICAgICAgICAgICB7LyogMi4gRHJhd2VyIE1vYmlsZSAmIEJhY2tkcm9wICovfVxuICAgICAgICAgICAge2lzT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay82MCB6LTUwIG1kOmhpZGRlbiBiYWNrZHJvcC1ibHVyLXhzIHRyYW5zaXRpb24tb3BhY2l0eVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8YXNpZGUgXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgXG4gICAgICAgICAgICAgICAgICAgIGZpeGVkIHRvcC0wIGxlZnQtMCBib3R0b20tMCB3LTcyIG1heC13LVs4NXZ3XSBiZy1bIzAwNUI1Ml0gZGFyazpiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSB6LTUwIG1kOmhpZGRlblxuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm0gdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0IHNoYWRvdy0yeGwgaC1bMTAwZHZoXVxuICAgICAgICAgICAgICAgICAgICAke2lzT3BlbiA/ICd0cmFuc2xhdGUteC0wJyA6ICctdHJhbnNsYXRlLXgtZnVsbCd9XG4gICAgICAgICAgICAgICAgYH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7cmVuZGVyU2lkZWJhckNvbnRlbnQoKX1cbiAgICAgICAgICAgIDwvYXNpZGU+XG5cbiAgICAgICAgICAgIHsvKiBNb2RhbHMgKi99XG4gICAgICAgICAgICA8VXNlckd1aWRlTW9kYWxcbiAgICAgICAgICAgICAgICBpc09wZW49e2d1aWRlTW9kYWxPcGVufVxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEd1aWRlTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBvblN0YXJ0VG91cj17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRHdWlkZU1vZGFsT3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvblN0YXJ0VG91cikge1xuICAgICAgICAgICAgICAgICAgICAgICAgb25TdGFydFRvdXIoKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICh3aW5kb3cuX19zdGFydEZvcm1VcFRvdXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5fX3N0YXJ0Rm9ybVVwVG91cigpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8Q29uZmlybU1vZGFsXG4gICAgICAgICAgICAgICAgaXNPcGVuPXtjb25maXJtTmF2LmlzT3Blbn1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRDb25maXJtTmF2KHsgaXNPcGVuOiBmYWxzZSwgYWN0aW9uOiBudWxsLCBtZXNzYWdlOiAnJyB9KX1cbiAgICAgICAgICAgICAgICBvbkNvbmZpcm09eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYWN0aW9uID0gY29uZmlybU5hdi5hY3Rpb247XG4gICAgICAgICAgICAgICAgICAgIHNldENvbmZpcm1OYXYoeyBpc09wZW46IGZhbHNlLCBhY3Rpb246IG51bGwsIG1lc3NhZ2U6ICcnIH0pO1xuICAgICAgICAgICAgICAgICAgICBpZiAoYWN0aW9uKSBhY3Rpb24oKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIHRpdGxlPVwiUGVydWJhaGFuIEJlbHVtIERpc2ltcGFuXCJcbiAgICAgICAgICAgICAgICBtZXNzYWdlPXtjb25maXJtTmF2Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgdmFyaWFudD1cImRhbmdlclwiXG4gICAgICAgICAgICAgICAgY29uZmlybVRleHQ9XCJZYSwgTGFuanV0a2FuXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgIDwvPlxuICAgICk7XG59Il19