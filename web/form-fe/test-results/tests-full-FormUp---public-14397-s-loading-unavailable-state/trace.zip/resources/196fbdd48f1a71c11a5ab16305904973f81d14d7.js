import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/AIFormBuilderModal.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { Sparkles, X, Loader2, Key, Check, Eye, EyeOff, ExternalLink, ShieldCheck, AlertCircle, CheckCircle2, RotateCcw, Clock, Calculator, Code, ChevronDown, ChevronUp, FileText, Cpu, Layers } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import { getGeminiApiKeys, executeWithApiKeyFailover, AVAILABLE_MODELS, safeJsonParse } from "/src/services/aiService.js";
import { createForm, saveQuestions } from "/src/services/apiService.js";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/AIFormBuilderModal.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function AIFormBuilderModal({ isOpen, onClose, onFormCreated }) {
	_s();
	const [prompt, setPrompt] = useState("");
	const [contextText, setContextText] = useState("");
	const [formCount, setFormCount] = useState(1);
	const [questionCount, setQuestionCount] = useState(5);
	const [typePreference, setTypePreference] = useState("2");
	const [difficulty, setDifficulty] = useState("Sedang");
	const [selectedModel, setSelectedModel] = useState("gemini-3.6-flash");
	const [includeMath, setIncludeMath] = useState(false);
	const [includeCode, setIncludeCode] = useState(false);
	const [showAdvanced, setShowAdvanced] = useState(false);
	// Global Stacked API Keys
	const [apiKeys, setApiKeys] = useState(() => getGeminiApiKeys());
	// Status
	const [generating, setGenerating] = useState(false);
	const [creating, setCreating] = useState(false);
	const [error, setError] = useState("");
	const [status, setStatus] = useState("");
	const [elapsed, setElapsed] = useState(0);
	const [previews, setPreviews] = useState(null);
	const [activePreviewIdx, setActivePreviewIdx] = useState(0);
	const timerRef = useRef(null);
	useEffect(() => {
		if (!isOpen) return;
		setPrompt("");
		setContextText("");
		setError("");
		setStatus("");
		setPreviews(null);
		setActivePreviewIdx(0);
		setElapsed(0);
		setFormCount(1);
		setQuestionCount(5);
		setTypePreference("2");
		setDifficulty("Sedang");
		setIncludeMath(false);
		setIncludeCode(false);
		setShowAdvanced(false);
		setApiKeys(getGeminiApiKeys());
	}, [isOpen]);
	useEffect(() => {
		if (generating || creating) {
			setElapsed(0);
			timerRef.current = setInterval(() => setElapsed((prev) => prev + 1), 1e3);
		} else {
			if (timerRef.current) clearInterval(timerRef.current);
		}
		return () => {
			if (timerRef.current) clearInterval(timerRef.current);
		};
	}, [generating, creating]);
	if (!isOpen) return null;
	const generateSingleForm = async (targetIndex, total, currentApiKey) => {
		const mathCodeInstructions = [];
		if (includeMath) mathCodeInstructions.push("- Untuk rumus matematika/fisika, gunakan format LaTeX inline $...$ atau blok $$...$$");
		if (includeCode) mathCodeInstructions.push("- Untuk kode program, gunakan format ```bahasa\\nkode\\n```");
		const typeDescription = {
			"1": "Semua soal bertipe Essay / Isian Singkat (typeId: 1, sertakan kunci/contoh jawaban di correctAnswer).",
			"2": "Semua soal bertipe Pilihan Ganda (typeId: 2, sediakan 4 pilihan jawaban di options di mana tepat SATU bernilai isCorrect: true).",
			"3": "Semua soal bertipe Checkbox / Pilihan Majemuk (typeId: 3, sediakan 4-5 opsi di mana ada minimal 2 bernilai isCorrect: true).",
			"5": "Semua soal bertipe Benar / Salah (typeId: 5, correctAnswer diisi \"Benar\" atau \"Salah\").",
			"mixed": "Variasi campuran antara Pilihan Ganda (typeId: 2), Benar/Salah (typeId: 5), dan Essay (typeId: 1)."
		}[typePreference] || "Pilihan Ganda (typeId: 2)";
		let extraContext = "";
		if (contextText && contextText.trim()) {
			extraContext = `\nMateri Referensi Tambahan:\n"""\n${contextText.trim()}\n"""\n`;
		}
		const promptText = `
PERAN & BATASAN KERAS: Anda adalah asisten pembuat formulir dan soal ujian pendidikan FormUp. Anda HANYA membuat kuis dan soal untuk keperluan edukasi.

Buatlah 1 formulir lengkap dengan ${questionCount} butir soal ${total > 1 ? `(Paket/Variasi ke-${targetIndex + 1} dari total ${total} paket)` : ""} berdasarkan panduan berikut:
- **Topik / Deskripsi:** ${prompt.trim()}
- **Tingkat Kesulitan:** ${difficulty}
- **Bentuk Soal:** ${typeDescription}
- **Bahasa:** Bahasa Indonesia baku yang baik
${extraContext}
${mathCodeInstructions.length > 0 ? mathCodeInstructions.join("\n") : ""}

**FORMAT KELUARAN WAJIB (JSON OBJECT):**
Kembalikan HANYA format JSON valid berikut tanpa teks pengantar atau penutup:
{
  "title": "${total > 1 ? `Judul Formulir (Paket ${targetIndex + 1})` : "Judul Formulir Lengkap"}",
  "description": "Deskripsi singkat mengenai formulir/kuis ini",
  "questions": [
    {
      "question": "Teks pertanyaan lengkap",
      "typeId": 2,
      "isRequired": true,
      "isScorable": true,
      "correctAnswer": "Kunci jawaban jika ada",
      "options": [
        {"optionText": "Pilihan A", "isCorrect": false},
        {"optionText": "Pilihan B", "isCorrect": true},
        {"optionText": "Pilihan C", "isCorrect": false},
        {"optionText": "Pilihan D", "isCorrect": false}
      ]
    }
  ]
}
`.trim();
		const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${selectedModel}:generateContent?key=${currentApiKey}`;
		const controller = new AbortController();
		const timeoutId = setTimeout(() => controller.abort(), 6e4);
		const resp = await fetch(endpoint, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			signal: controller.signal,
			body: JSON.stringify({
				contents: [{ parts: [{ text: promptText }] }],
				generationConfig: {
					responseMimeType: "application/json",
					temperature: .7
				}
			})
		});
		clearTimeout(timeoutId);
		if (!resp.ok) {
			const errData = await resp.json().catch(() => ({}));
			const errMsg = errData.error?.message || `HTTP ${resp.status}`;
			if (resp.status === 429) throw new Error(`Rate limit tercapai untuk model ${selectedModel}. Coba pilih Gemini 3.6 Flash Lite.`);
			if (resp.status === 400 || resp.status === 403) throw new Error(`API Key tidak valid atau akses ditolak. (${errMsg})`);
			if (resp.status >= 500) throw new Error(`Server AI Studio tidak tersedia (Error ${resp.status}). Coba lagi nanti.`);
			throw new Error(`Gagal memanggil AI: ${errMsg}`);
		}
		const data = await resp.json();
		let text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
		let parsed;
		try {
			parsed = safeJsonParse(text);
		} catch {
			throw new Error("AI mengembalikan format JSON yang tidak valid. Coba ulangi pembuatan.");
		}
		if (!parsed || !parsed.title || !Array.isArray(parsed.questions)) throw new Error("Format JSON dari AI tidak valid");
		return parsed;
	};
	const handleGenerate = async () => {
		const keys = getGeminiApiKeys();
		if (keys.length === 0) {
			setError("API Key Gemini belum diatur. Silakan atur API Key di menu AI Assistant Chat terlebih dahulu.");
			return;
		}
		if (!prompt.trim() && !contextText.trim()) {
			setError("Tulis deskripsi atau materi form yang ingin dibuat.");
			return;
		}
		setError("");
		setGenerating(true);
		const countToGenerate = Math.min(Math.max(parseInt(formCount, 10) || 1, 1), 5);
		const results = [];
		try {
			await executeWithApiKeyFailover(async (activeApiKey) => {
				for (let i = 0; i < countToGenerate; i++) {
					setStatus(`Menyusun formulir ${i + 1} dari ${countToGenerate} dengan ${selectedModel}...`);
					const formRes = await generateSingleForm(i, countToGenerate, activeApiKey);
					results.push(formRes);
				}
				return { ok: true };
			});
			if (results.length > 0) {
				setStatus("Selesai! Tinjau hasil sebelum disimpan.");
				setPreviews(results);
				setActivePreviewIdx(0);
			}
		} catch (err) {
			setError(err?.name === "AbortError" ? "Permintaan AI melewati batas waktu 60 detik. Silakan coba lagi." : err.message || "Terjadi kesalahan saat memproses formulir.");
		} finally {
			setGenerating(false);
		}
	};
	const handleCreateForms = async () => {
		if (!previews || previews.length === 0) return;
		setCreating(true);
		setError("");
		let lastCreatedId = null;
		try {
			for (let fIdx = 0; fIdx < previews.length; fIdx++) {
				const currentPreview = previews[fIdx];
				setStatus(`Menyimpan formulir ${fIdx + 1} dari ${previews.length}: "${currentPreview.title}"...`);
				const formRes = await createForm({
					title: currentPreview.title,
					description: currentPreview.description || ""
				});
				if (!formRes.ok || !formRes.data?.id) throw new Error(formRes.message || `Gagal menyimpan form ${fIdx + 1}`);
				const newId = formRes.data.id;
				lastCreatedId = newId;
				if (currentPreview.questions && currentPreview.questions.length > 0) {
					await saveQuestions(newId, currentPreview.questions.map((q, i) => ({
						typeId: parseInt(q.typeId, 10) || 2,
						question: q.question || "",
						questionFormat: "text",
						questionOrder: i + 1,
						isRequired: q.isRequired !== false,
						correctAnswer: q.correctAnswer || null,
						points: null,
						options: (q.options || []).map((o) => ({
							optionText: String(o.optionText || ""),
							isCorrect: Boolean(o.isCorrect)
						}))
					})));
				}
			}
			onClose();
			if (onFormCreated && lastCreatedId) onFormCreated(lastCreatedId);
		} catch (err) {
			setError("Gagal membuat form: " + err.message);
		} finally {
			setCreating(false);
		}
	};
	const currentPreview = previews ? previews[activePreviewIdx] : null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xs",
			onClick: onClose
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 250,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-teal-500/10 via-emerald-500/5 to-transparent",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-400 text-white flex items-center justify-center shadow-md",
							children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 20 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 257,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 256,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-extrabold text-slate-900 dark:text-white",
							children: "Buat Form dengan AI"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 260,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400",
							children: "Deskripsikan form & materi, AI menyusun judul, deskripsi, & butir soal."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 261,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 259,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 255,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [apiKeys.length > 0 ? /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline-flex items-center gap-1 px-2.5 py-1 bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 rounded-xl text-xs font-bold border border-teal-200 dark:border-teal-800",
							children: [
								/* @__PURE__ */ _jsxDEV(ShieldCheck, {
									size: 12,
									className: "text-teal-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 267,
									columnNumber: 33
								}, this),
								apiKeys.length,
								" API Key"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 29
						}, this) : /* @__PURE__ */ _jsxDEV(Link, {
							to: "/ai-chat",
							className: "inline-flex items-center gap-1 px-2.5 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 hover:bg-amber-100 rounded-xl text-xs font-bold border border-amber-200 dark:border-amber-800 transition-colors",
							children: [/* @__PURE__ */ _jsxDEV(Key, { size: 12 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 33
							}, this), " Atur Key"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 271,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							className: "p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 278,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 264,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 254,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto p-6 space-y-4",
					children: [
						apiKeys.length === 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 rounded-2xl flex items-center justify-between gap-3 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-amber-800 dark:text-amber-300 font-medium",
								children: [/* @__PURE__ */ _jsxDEV(Key, {
									size: 15,
									className: "text-amber-600 shrink-0"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 289,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "API Key Gemini belum diatur. Silakan atur di AI Assistant Chat." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 290,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: "/ai-chat",
								className: "px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold shrink-0 transition-colors inline-flex items-center gap-1",
								children: ["Atur di AI Chat ", /* @__PURE__ */ _jsxDEV(ExternalLink, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 296,
									columnNumber: 49
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 287,
							columnNumber: 25
						}, this),
						error && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900 rounded-2xl flex items-start gap-2.5 text-xs text-red-700 dark:text-red-300",
							children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
								size: 15,
								className: "shrink-0 mt-0.5"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: error }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 304,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 302,
							columnNumber: 25
						}, this),
						!previews ? /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-xs font-extrabold text-slate-800 dark:text-slate-200",
										children: ["Deskripsi / Topik Formulir ", /* @__PURE__ */ _jsxDEV("span", {
											className: "text-red-500",
											children: "*"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 313,
											columnNumber: 64
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 312,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("textarea", {
										rows: 3,
										value: prompt,
										onChange: (e) => setPrompt(e.target.value),
										placeholder: "Contoh: Kuis Ujian Akhir Semester Fisika SMA Kelas 11 materi Termodinamika & Gelombang Bunyi.",
										className: "w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]",
										disabled: generating
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 315,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1",
												children: [/* @__PURE__ */ _jsxDEV(Cpu, {
													size: 12,
													className: "text-teal-600"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 330,
													columnNumber: 41
												}, this), " Model AI"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 329,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("select", {
												value: selectedModel,
												onChange: (e) => setSelectedModel(e.target.value),
												disabled: generating,
												className: "w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium",
												children: AVAILABLE_MODELS.map((m) => /* @__PURE__ */ _jsxDEV("option", {
													value: m.id,
													children: [
														m.name,
														" (",
														m.badge,
														")"
													]
												}, m.id, true, {
													fileName: _jsxFileName,
													lineNumber: 339,
													columnNumber: 45
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 332,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 328,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-[11px] font-bold text-slate-700 dark:text-slate-300",
												children: "Kesulitan"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 346,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("select", {
												value: difficulty,
												onChange: (e) => setDifficulty(e.target.value),
												disabled: generating,
												className: "w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Mudah",
														children: "Mudah"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 353,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Sedang",
														children: "Sedang"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 354,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Sulit",
														children: "Sulit (HOTS)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 355,
														columnNumber: 41
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 347,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 345,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-[11px] font-bold text-slate-700 dark:text-slate-300",
												children: "Tipe Soal"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 361,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("select", {
												value: typePreference,
												onChange: (e) => setTypePreference(e.target.value),
												disabled: generating,
												className: "w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "2",
														children: "Pilihan Ganda (PG)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 368,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "1",
														children: "Essay / Isian"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 369,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "5",
														children: "Benar / Salah"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 370,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "3",
														children: "Checkbox / Majemuk"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 371,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "mixed",
														children: "Campuran"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 372,
														columnNumber: 41
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 362,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 360,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 326,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1",
											children: [/* @__PURE__ */ _jsxDEV(Layers, {
												size: 12,
												className: "text-teal-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 381,
												columnNumber: 41
											}, this), " Jumlah Form Dibuat"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 380,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1.5",
											children: [
												1,
												2,
												3,
												5
											].map((cnt) => /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setFormCount(cnt),
												disabled: generating,
												className: `flex-1 py-1.5 text-xs font-bold rounded-xl border transition-all cursor-pointer ${formCount === cnt ? "bg-teal-600 text-white border-teal-600 shadow-xs" : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-teal-400"}`,
												children: [
													cnt,
													" ",
													cnt > 1 ? "Paket" : "Form"
												]
											}, cnt, true, {
												fileName: _jsxFileName,
												lineNumber: 385,
												columnNumber: 45
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 383,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 379,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1",
											children: [/* @__PURE__ */ _jsxDEV(FileText, {
												size: 12,
												className: "text-teal-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 404,
												columnNumber: 41
											}, this), " Soal per Form"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 403,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1.5",
											children: [
												5,
												10,
												15,
												20
											].map((cnt) => /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setQuestionCount(cnt),
												disabled: generating,
												className: `flex-1 py-1.5 text-xs font-bold rounded-xl border transition-all cursor-pointer ${questionCount === cnt ? "bg-teal-600 text-white border-teal-600 shadow-xs" : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-teal-400"}`,
												children: cnt
											}, cnt, false, {
												fileName: _jsxFileName,
												lineNumber: 408,
												columnNumber: 45
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 406,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 402,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 378,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 flex-wrap pt-1",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-slate-400 dark:text-slate-500 font-medium",
											children: "Sertakan:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 428,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setIncludeMath((prev) => !prev),
											disabled: generating,
											className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer disabled:opacity-50 ${includeMath ? "bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border-teal-300 dark:border-teal-700" : "bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-teal-300 hover:text-teal-600"}`,
											children: [
												/* @__PURE__ */ _jsxDEV(Calculator, { size: 13 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 439,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("span", { children: "Rumus (KaTeX)" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 440,
													columnNumber: 37
												}, this),
												includeMath && /* @__PURE__ */ _jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-teal-500 shrink-0" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 441,
													columnNumber: 53
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 429,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setIncludeCode((prev) => !prev),
											disabled: generating,
											className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer disabled:opacity-50 ${includeCode ? "bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-indigo-300 dark:border-indigo-700" : "bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-300 hover:text-indigo-600"}`,
											children: [
												/* @__PURE__ */ _jsxDEV(Code, { size: 13 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 453,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("span", { children: "Code Block" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 454,
													columnNumber: 37
												}, this),
												includeCode && /* @__PURE__ */ _jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 455,
													columnNumber: 53
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 443,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 427,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-1",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowAdvanced(!showAdvanced),
										className: "flex items-center gap-1.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-teal-600 transition-colors cursor-pointer",
										children: [showAdvanced ? /* @__PURE__ */ _jsxDEV(ChevronUp, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 466,
											columnNumber: 53
										}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 466,
											columnNumber: 79
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Opsi Tambahan: Sisipkan Materi / Teks Rujukan (B8)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 467,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 461,
										columnNumber: 33
									}, this), showAdvanced && /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-2 space-y-1.5 animate-in fade-in duration-200",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-slate-400 dark:text-slate-500",
											children: "Tempel rangkuman materi, silabus, atau bahan ajar. AI akan membuat soal spesifik berdasarkan materi ini:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 471,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("textarea", {
											rows: 4,
											value: contextText,
											onChange: (e) => setContextText(e.target.value),
											placeholder: "Tempel teks materi, modul ajar, atau referensi bacaan di sini...",
											className: "w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500",
											disabled: generating
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 474,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 470,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 460,
									columnNumber: 29
								}, this),
								generating && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-800 flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV(Loader2, {
										size: 22,
										className: "animate-spin text-[#00897B] shrink-0"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 488,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs font-extrabold text-teal-900 dark:text-teal-100",
										children: status
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 490,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-teal-600 dark:text-teal-400 flex items-center gap-1 mt-0.5",
										children: [
											/* @__PURE__ */ _jsxDEV(Clock, { size: 11 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 492,
												columnNumber: 45
											}, this),
											" ",
											elapsed,
											" detik"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 491,
										columnNumber: 41
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 489,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 487,
									columnNumber: 33
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 309,
							columnNumber: 25
						}, this) : 
						// Preview Mode (B6)
/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs font-extrabold text-slate-800 dark:text-slate-200",
										children: "✨ Form Siap Ditinjau"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 503,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-400",
										children: [previews.length, " formulir dihasilkan"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 504,
										columnNumber: 37
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 502,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setPreviews(null),
										className: "text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1 cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 511,
											columnNumber: 37
										}, this), " Buat Ulang"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 506,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 501,
									columnNumber: 29
								}, this),
								previews.length > 1 && /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5 overflow-x-auto pb-1",
									children: previews.map((p, idx) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setActivePreviewIdx(idx),
										className: `px-3 py-1.5 text-xs font-bold rounded-xl border transition-all cursor-pointer whitespace-nowrap ${activePreviewIdx === idx ? "bg-teal-600 text-white border-teal-600 shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700"}`,
										children: [
											"Paket ",
											idx + 1,
											": ",
											p.title.slice(0, 18),
											"..."
										]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 519,
										columnNumber: 41
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 517,
									columnNumber: 33
								}, this),
								currentPreview && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 bg-teal-50/50 dark:bg-teal-950/30 border border-teal-200/60 dark:border-teal-800/60 rounded-2xl space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-extrabold text-slate-900 dark:text-white",
										children: currentPreview.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 538,
										columnNumber: 41
									}, this), currentPreview.description && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-500 dark:text-slate-400",
										children: currentPreview.description
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 540,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 537,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 max-h-64 overflow-y-auto pr-1",
									children: currentPreview.questions?.map((q, i) => {
										const typeLabels = {
											1: "Essay",
											2: "Pilihan Ganda",
											3: "Checkbox",
											5: "Benar/Salah"
										};
										const typeColors = {
											1: "bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300",
											2: "bg-teal-50 text-teal-700 dark:bg-teal-950/50 dark:text-teal-300",
											3: "bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300",
											5: "bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300"
										};
										return /* @__PURE__ */ _jsxDEV("div", {
											className: "p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200/70 dark:border-slate-700 space-y-1.5",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-start gap-2",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] font-extrabold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-1.5 py-0.5 rounded shrink-0",
														children: i + 1
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 555,
														columnNumber: 57
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: `text-[10px] font-extrabold px-1.5 py-0.5 rounded shrink-0 ${typeColors[q.typeId] || "bg-slate-100 text-slate-600"}`,
														children: typeLabels[q.typeId] || "Soal"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 556,
														columnNumber: 57
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 554,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-xs font-bold text-slate-800 dark:text-slate-100 leading-relaxed pl-2",
													children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: q.question }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 559,
														columnNumber: 57
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 558,
													columnNumber: 53
												}, this),
												q.options && q.options.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
													className: "pl-2 grid grid-cols-2 gap-1",
													children: q.options.map((o, oi) => /* @__PURE__ */ _jsxDEV("div", {
														className: `text-[11px] px-2 py-0.5 rounded-lg flex items-start gap-1 ${o.isCorrect ? "bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 font-bold" : "text-slate-600 dark:text-slate-400"}`,
														children: [
															/* @__PURE__ */ _jsxDEV("span", {
																className: "shrink-0",
																children: [String.fromCharCode(65 + oi), "."]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 565,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: o.optionText }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 566,
																columnNumber: 75
															}, this) }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 566,
																columnNumber: 69
															}, this),
															o.isCorrect && /* @__PURE__ */ _jsxDEV("span", {
																className: "text-emerald-500 shrink-0",
																children: "✓"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 567,
																columnNumber: 85
															}, this)
														]
													}, oi, true, {
														fileName: _jsxFileName,
														lineNumber: 564,
														columnNumber: 65
													}, this))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 562,
													columnNumber: 57
												}, this)
											]
										}, i, true, {
											fileName: _jsxFileName,
											lineNumber: 553,
											columnNumber: 49
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 543,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 536,
									columnNumber: 33
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 500,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 285,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs text-slate-400",
						children: apiKeys.length > 0 ? /* @__PURE__ */ _jsxDEV("span", {
							className: "text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1",
							children: [
								/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 13 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 587,
									columnNumber: 33
								}, this),
								" ",
								apiKeys.length,
								" API Key Aktif"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 586,
							columnNumber: 29
						}, this) : /* @__PURE__ */ _jsxDEV("span", {
							className: "text-amber-600 font-bold",
							children: "⚠ Harap atur API Key di Chat AI"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 590,
							columnNumber: 29
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 584,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							className: "px-4 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 rounded-xl cursor-pointer",
							children: "Batal"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 594,
							columnNumber: 25
						}, this), !previews ? /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleGenerate,
							disabled: generating || !prompt.trim() && !contextText.trim(),
							className: "px-6 py-2.5 bg-[#00897B] hover:bg-[#00796B] text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer disabled:opacity-60",
							children: generating ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV(Loader2, {
									size: 14,
									className: "animate-spin"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 605,
									columnNumber: 39
								}, this),
								" ",
								status || `Membuat... (${elapsed}s)`
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 605,
								columnNumber: 37
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV(Sparkles, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 607,
									columnNumber: 39
								}, this),
								" Generate ",
								formCount > 1 ? `${formCount} Paket Form` : "Form"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 607,
								columnNumber: 37
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 598,
							columnNumber: 29
						}, this) : /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleCreateForms,
							disabled: creating,
							className: "px-6 py-2.5 bg-[#00897B] hover:bg-[#00796B] text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer disabled:opacity-60",
							children: creating ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV(Loader2, {
									size: 14,
									className: "animate-spin"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 618,
									columnNumber: 39
								}, this),
								" Menyimpan Form (",
								elapsed,
								"s)..."
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 618,
								columnNumber: 37
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 620,
									columnNumber: 39
								}, this),
								" Simpan ",
								previews.length > 1 ? `${previews.length} Form Ini` : "Form Ini"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 620,
								columnNumber: 37
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 611,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 593,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 583,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 251,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 249,
		columnNumber: 9
	}, this);
}
_s(AIFormBuilderModal, "+BOv/dOPSiO04n0oT9p+Oi04sMI=");
_c = AIFormBuilderModal;
var _c;
$RefreshReg$(_c, "AIFormBuilderModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/AIFormBuilderModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/AIFormBuilderModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/AIFormBuilderModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/AIFormBuilderModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsY0FBYztBQUM1QyxTQUFTLFlBQVk7QUFDckIsU0FDSSxVQUFVLEdBQUcsU0FBUyxLQUFLLE9BQU8sS0FBSyxRQUFRLGNBQy9DLGFBQWEsYUFBYSxjQUFjLFdBQVcsT0FDbkQsWUFBWSxNQUFNLGFBQWEsV0FBVyxVQUFVLEtBQUssY0FDdEQ7QUFDUCxTQUNJLGtCQUNBLDJCQUNBLGtCQUNBLHFCQUNHO0FBQ1AsU0FBUyxZQUFZLHFCQUFxQjtBQUMxQyxPQUFPLHlCQUF5Qjs7OztBQUVoQyxlQUFlLFNBQVMsbUJBQW1CLEVBQUUsUUFBUSxTQUFTLGlCQUFpQjs7Q0FDM0UsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEVBQUU7Q0FDdkMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDO0NBQzVDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLENBQUM7Q0FDcEQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxHQUFHO0NBQ3hELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLFFBQVE7Q0FDckQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsa0JBQWtCO0NBQ3JFLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLOztDQUd0RCxNQUFNLENBQUMsU0FBUyxjQUFjLGVBQWUsaUJBQWlCLENBQUM7O0NBRy9ELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEtBQUs7Q0FDOUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEVBQUU7Q0FDdkMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLENBQUM7Q0FDeEMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLElBQUk7Q0FDN0MsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxDQUFDO0NBRTFELE1BQU0sV0FBVyxPQUFPLElBQUk7Q0FFNUIsZ0JBQWdCO0VBQ1osSUFBSSxDQUFDLFFBQVE7RUFDYixVQUFVLEVBQUU7RUFDWixlQUFlLEVBQUU7RUFDakIsU0FBUyxFQUFFO0VBQ1gsVUFBVSxFQUFFO0VBQ1osWUFBWSxJQUFJO0VBQ2hCLG9CQUFvQixDQUFDO0VBQ3JCLFdBQVcsQ0FBQztFQUNaLGFBQWEsQ0FBQztFQUNkLGlCQUFpQixDQUFDO0VBQ2xCLGtCQUFrQixHQUFHO0VBQ3JCLGNBQWMsUUFBUTtFQUN0QixlQUFlLEtBQUs7RUFDcEIsZUFBZSxLQUFLO0VBQ3BCLGdCQUFnQixLQUFLO0VBQ3JCLFdBQVcsaUJBQWlCLENBQUM7Q0FDakMsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUVYLGdCQUFnQjtFQUNaLElBQUksY0FBYyxVQUFVO0dBQ3hCLFdBQVcsQ0FBQztHQUNaLFNBQVMsVUFBVSxrQkFBa0IsWUFBVyxTQUFRLE9BQU8sQ0FBQyxHQUFHLEdBQUk7RUFDM0UsT0FBTztHQUNILElBQUksU0FBUyxTQUFTLGNBQWMsU0FBUyxPQUFPO0VBQ3hEO0VBQ0EsYUFBYTtHQUNULElBQUksU0FBUyxTQUFTLGNBQWMsU0FBUyxPQUFPO0VBQ3hEO0NBQ0osR0FBRyxDQUFDLFlBQVksUUFBUSxDQUFDO0NBRXpCLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsTUFBTSxxQkFBcUIsT0FBTyxhQUFhLE9BQU8sa0JBQWtCO0VBQ3BFLE1BQU0sdUJBQXVCLENBQUM7RUFDOUIsSUFBSSxhQUFhLHFCQUFxQixLQUFLLHNGQUFzRjtFQUNqSSxJQUFJLGFBQWEscUJBQXFCLEtBQUssNkRBQTZEO0VBRXhHLE1BQU0sa0JBQWtCO0dBQ3BCLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxTQUFTO0VBQ2IsRUFBRSxtQkFBbUI7RUFFckIsSUFBSSxlQUFlO0VBQ25CLElBQUksZUFBZSxZQUFZLEtBQUssR0FBRztHQUNuQyxlQUFlLHNDQUFzQyxZQUFZLEtBQUssRUFBRTtFQUM1RTtFQUVBLE1BQU0sYUFBYTs7O29DQUdTLGNBQWMsY0FBYyxRQUFRLElBQUkscUJBQXFCLGNBQWMsRUFBRSxjQUFjLE1BQU0sV0FBVyxHQUFHOzJCQUN4SCxPQUFPLEtBQUssRUFBRTsyQkFDZCxXQUFXO3FCQUNqQixnQkFBZ0I7O0VBRW5DLGFBQWE7RUFDYixxQkFBcUIsU0FBUyxJQUFJLHFCQUFxQixLQUFLLElBQUksSUFBSSxHQUFHOzs7OztjQUszRCxRQUFRLElBQUkseUJBQXlCLGNBQWMsRUFBRSxLQUFLLHlCQUF5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBa0IvRixLQUFLO0VBRUMsTUFBTSxXQUFXLDJEQUEyRCxjQUFjLHVCQUF1QjtFQUNqSCxNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7RUFDdkMsTUFBTSxZQUFZLGlCQUFpQixXQUFXLE1BQU0sR0FBRyxHQUFLO0VBQzVELE1BQU0sT0FBTyxNQUFNLE1BQU0sVUFBVTtHQUMvQixRQUFRO0dBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7R0FDOUMsUUFBUSxXQUFXO0dBQ25CLE1BQU0sS0FBSyxVQUFVO0lBQ2pCLFVBQVUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLE1BQU0sV0FBVyxDQUFDLEVBQUUsQ0FBQztJQUM1QyxrQkFBa0I7S0FBRSxrQkFBa0I7S0FBb0IsYUFBYTtJQUFJO0dBQy9FLENBQUM7RUFDTCxDQUFDO0VBQ0QsYUFBYSxTQUFTO0VBRXRCLElBQUksQ0FBQyxLQUFLLElBQUk7R0FDVixNQUFNLFVBQVUsTUFBTSxLQUFLLEtBQUssQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFO0dBQ2xELE1BQU0sU0FBUyxRQUFRLE9BQU8sV0FBVyxRQUFRLEtBQUs7R0FDdEQsSUFBSSxLQUFLLFdBQVcsS0FBSyxNQUFNLElBQUksTUFBTSxtQ0FBbUMsY0FBYyxvQ0FBb0M7R0FDOUgsSUFBSSxLQUFLLFdBQVcsT0FBTyxLQUFLLFdBQVcsS0FBSyxNQUFNLElBQUksTUFBTSw0Q0FBNEMsT0FBTyxFQUFFO0dBQ3JILElBQUksS0FBSyxVQUFVLEtBQUssTUFBTSxJQUFJLE1BQU0sMENBQTBDLEtBQUssT0FBTyxvQkFBb0I7R0FDbEgsTUFBTSxJQUFJLE1BQU0sdUJBQXVCLFFBQVE7RUFDbkQ7RUFFQSxNQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUs7RUFDN0IsSUFBSSxPQUFPLEtBQUssYUFBYSxFQUFFLEVBQUUsU0FBUyxRQUFRLEVBQUUsRUFBRSxRQUFRO0VBQzlELElBQUk7RUFDSixJQUFJO0dBQ0EsU0FBUyxjQUFjLElBQUk7RUFDL0IsUUFBUTtHQUNKLE1BQU0sSUFBSSxNQUFNLHVFQUF1RTtFQUMzRjtFQUNBLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxTQUFTLENBQUMsTUFBTSxRQUFRLE9BQU8sU0FBUyxHQUFHLE1BQU0sSUFBSSxNQUFNLGlDQUFpQztFQUNuSCxPQUFPO0NBQ1g7Q0FFQSxNQUFNLGlCQUFpQixZQUFZO0VBQy9CLE1BQU0sT0FBTyxpQkFBaUI7RUFDOUIsSUFBSSxLQUFLLFdBQVcsR0FBRztHQUNuQixTQUFTLDhGQUE4RjtHQUN2RztFQUNKO0VBQ0EsSUFBSSxDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsWUFBWSxLQUFLLEdBQUc7R0FDdkMsU0FBUyxxREFBcUQ7R0FDOUQ7RUFDSjtFQUVBLFNBQVMsRUFBRTtFQUNYLGNBQWMsSUFBSTtFQUNsQixNQUFNLGtCQUFrQixLQUFLLElBQUksS0FBSyxJQUFJLFNBQVMsV0FBVyxFQUFFLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUM3RSxNQUFNLFVBQVUsQ0FBQztFQUVqQixJQUFJO0dBQ0EsTUFBTSwwQkFBMEIsT0FBTyxpQkFBaUI7SUFDcEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGlCQUFpQixLQUFLO0tBQ3RDLFVBQVUscUJBQXFCLElBQUksRUFBRSxRQUFRLGdCQUFnQixVQUFVLGNBQWMsSUFBSTtLQUN6RixNQUFNLFVBQVUsTUFBTSxtQkFBbUIsR0FBRyxpQkFBaUIsWUFBWTtLQUN6RSxRQUFRLEtBQUssT0FBTztJQUN4QjtJQUNBLE9BQU8sRUFBRSxJQUFJLEtBQUs7R0FDdEIsQ0FBQztHQUVELElBQUksUUFBUSxTQUFTLEdBQUc7SUFDcEIsVUFBVSx5Q0FBeUM7SUFDbkQsWUFBWSxPQUFPO0lBQ25CLG9CQUFvQixDQUFDO0dBQ3pCO0VBQ0osU0FBUyxLQUFLO0dBQ1YsU0FBUyxLQUFLLFNBQVMsZUFDakIsb0VBQ0MsSUFBSSxXQUFXLDRDQUE2QztFQUN2RSxVQUFVO0dBQ04sY0FBYyxLQUFLO0VBQ3ZCO0NBQ0o7Q0FFQSxNQUFNLG9CQUFvQixZQUFZO0VBQ2xDLElBQUksQ0FBQyxZQUFZLFNBQVMsV0FBVyxHQUFHO0VBQ3hDLFlBQVksSUFBSTtFQUNoQixTQUFTLEVBQUU7RUFDWCxJQUFJLGdCQUFnQjtFQUVwQixJQUFJO0dBQ0EsS0FBSyxJQUFJLE9BQU8sR0FBRyxPQUFPLFNBQVMsUUFBUSxRQUFRO0lBQy9DLE1BQU0saUJBQWlCLFNBQVM7SUFDaEMsVUFBVSxzQkFBc0IsT0FBTyxFQUFFLFFBQVEsU0FBUyxPQUFPLEtBQUssZUFBZSxNQUFNLEtBQUs7SUFDaEcsTUFBTSxVQUFVLE1BQU0sV0FBVztLQUM3QixPQUFPLGVBQWU7S0FDdEIsYUFBYSxlQUFlLGVBQWU7SUFDL0MsQ0FBQztJQUNELElBQUksQ0FBQyxRQUFRLE1BQU0sQ0FBQyxRQUFRLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxRQUFRLFdBQVcsd0JBQXdCLE9BQU8sR0FBRztJQUMzRyxNQUFNLFFBQVEsUUFBUSxLQUFLO0lBQzNCLGdCQUFnQjtJQUVoQixJQUFJLGVBQWUsYUFBYSxlQUFlLFVBQVUsU0FBUyxHQUFHO0tBQ2pFLE1BQU0sY0FBYyxPQUFPLGVBQWUsVUFBVSxLQUFLLEdBQUcsT0FBTztNQUMvRCxRQUFRLFNBQVMsRUFBRSxRQUFRLEVBQUUsS0FBSztNQUNsQyxVQUFVLEVBQUUsWUFBWTtNQUN4QixnQkFBZ0I7TUFDaEIsZUFBZSxJQUFJO01BQ25CLFlBQVksRUFBRSxlQUFlO01BQzdCLGVBQWUsRUFBRSxpQkFBaUI7TUFDbEMsUUFBUTtNQUNSLFVBQVUsRUFBRSxXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUksT0FBTTtPQUNqQyxZQUFZLE9BQU8sRUFBRSxjQUFjLEVBQUU7T0FDckMsV0FBVyxRQUFRLEVBQUUsU0FBUztNQUNsQyxFQUFFO0tBQ04sRUFBRSxDQUFDO0lBQ1A7R0FDSjtHQUNBLFFBQVE7R0FDUixJQUFJLGlCQUFpQixlQUFlLGNBQWMsYUFBYTtFQUNuRSxTQUFTLEtBQUs7R0FDVixTQUFTLHlCQUF5QixJQUFJLE9BQU87RUFDakQsVUFBVTtHQUNOLFlBQVksS0FBSztFQUNyQjtDQUNKO0NBRUEsTUFBTSxpQkFBaUIsV0FBVyxTQUFTLG9CQUFvQjtDQUUvRCxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDSSx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFrRSxTQUFTO0VBQVU7Ozs7WUFDcEcsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUdJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNYLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O01BQ3BCOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBMEQ7TUFBdUI7Ozs7Z0JBQy9GLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE2QztNQUEwRTs7OztjQUNuSTs7OztjQUNKOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ssUUFBUSxTQUFTLElBQ2Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCO1FBQ0ksd0JBQUMsYUFBRDtTQUFhLE1BQU07U0FBSSxXQUFVO1FBQWlCOzs7OztRQUNqRCxRQUFRO1FBQU87T0FDZDs7Ozs7aUJBRU4sd0JBQUMsTUFBRDtPQUNJLElBQUc7T0FDSCxXQUFVO2lCQUZkLENBSUksd0JBQUMsS0FBRCxFQUFLLE1BQU0sR0FBSzs7OztpQkFBQyxXQUNmOzs7OztnQkFFVix3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFNBQVM7T0FBUyxXQUFVO2lCQUM5Qyx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztNQUNWOzs7O2NBQ1A7Ozs7O2FBQ0o7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDSyxRQUFRLFdBQVcsS0FDaEIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLEtBQUQ7U0FBSyxNQUFNO1NBQUksV0FBVTtRQUEyQjs7OztrQkFDcEQsd0JBQUMsUUFBRCxZQUFNLGtFQUFxRTs7OztnQkFDMUU7Ozs7O2lCQUNMLHdCQUFDLE1BQUQ7UUFDSSxJQUFHO1FBQ0gsV0FBVTtrQkFGZCxDQUdDLG9CQUNtQix3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O2dCQUN2Qzs7Ozs7ZUFDTDs7Ozs7O01BR1IsU0FDRyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLGFBQUQ7UUFBYSxNQUFNO1FBQUksV0FBVTtPQUFtQjs7OztpQkFDcEQsd0JBQUMsUUFBRCxZQUFPLE1BQVk7Ozs7ZUFDbEI7Ozs7OztNQUdSLENBQUMsV0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUVJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWpCLENBQTZFLCtCQUM5Qyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZTtVQUFPOzs7O2tCQUM5RDs7Ozs7bUJBQ1Asd0JBQUMsWUFBRDtVQUNJLE1BQU07VUFDTixPQUFPO1VBQ1AsV0FBVSxNQUFLLFVBQVUsRUFBRSxPQUFPLEtBQUs7VUFDdkMsYUFBWTtVQUNaLFdBQVU7VUFDVixVQUFVO1NBQ2I7Ozs7aUJBQ0E7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBRUksd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBakIsQ0FDSSx3QkFBQyxLQUFEO2FBQUssTUFBTTthQUFJLFdBQVU7WUFBaUI7Ozs7c0JBQUMsV0FDeEM7Ozs7O3FCQUNQLHdCQUFDLFVBQUQ7WUFDSSxPQUFPO1lBQ1AsV0FBVSxNQUFLLGlCQUFpQixFQUFFLE9BQU8sS0FBSztZQUM5QyxVQUFVO1lBQ1YsV0FBVTtzQkFFVCxpQkFBaUIsS0FBSSxNQUNsQix3QkFBQyxVQUFEO2FBQW1CLE9BQU8sRUFBRTt1QkFBNUI7Y0FBaUMsRUFBRTtjQUFLO2NBQUcsRUFBRTtjQUFNO2FBQVM7ZUFBL0MsRUFBRTs7OzttQkFBNkMsQ0FDL0Q7V0FDRzs7OzttQkFDUDs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBMkQ7V0FBZ0I7Ozs7cUJBQzVGLHdCQUFDLFVBQUQ7WUFDSSxPQUFPO1lBQ1AsV0FBVSxNQUFLLGNBQWMsRUFBRSxPQUFPLEtBQUs7WUFDM0MsVUFBVTtZQUNWLFdBQVU7c0JBSmQ7YUFNSSx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBUTthQUFhOzs7OzthQUNuQyx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBUzthQUFjOzs7OzthQUNyQyx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBUTthQUFvQjs7Ozs7WUFDdEM7Ozs7O21CQUNQOzs7Ozs7VUFHTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUEyRDtXQUFnQjs7OztxQkFDNUYsd0JBQUMsVUFBRDtZQUNJLE9BQU87WUFDUCxXQUFVLE1BQUssa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1lBQy9DLFVBQVU7WUFDVixXQUFVO3NCQUpkO2FBTUksd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQUk7YUFBMEI7Ozs7O2FBQzVDLHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUFJO2FBQXFCOzs7OzthQUN2Qyx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBSTthQUFxQjs7Ozs7YUFDdkMsd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQUk7YUFBMEI7Ozs7O2FBQzVDLHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUFRO2FBQWdCOzs7OztZQUNsQzs7Ozs7bUJBQ1A7Ozs7OztTQUNKOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0ksd0JBQUMsUUFBRDtZQUFRLE1BQU07WUFBSSxXQUFVO1dBQWlCOzs7O3FCQUFDLHFCQUMzQzs7Ozs7b0JBQ1Asd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1Y7WUFBQztZQUFHO1lBQUc7WUFBRztXQUFDLENBQUMsQ0FBQyxLQUFJLFFBQ2Qsd0JBQUMsVUFBRDtZQUVJLE1BQUs7WUFDTCxlQUFlLGFBQWEsR0FBRztZQUMvQixVQUFVO1lBQ1YsV0FBVyxtRkFDUCxjQUFjLE1BQ1IscURBQ0E7c0JBUmQ7YUFXSzthQUFJO2FBQUUsTUFBTSxJQUFJLFVBQVU7WUFDdkI7Y0FYQzs7OztrQkFXRCxDQUNYO1VBQ0E7Ozs7a0JBQ0o7Ozs7O21CQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0ksd0JBQUMsVUFBRDtZQUFVLE1BQU07WUFBSSxXQUFVO1dBQWlCOzs7O3FCQUFDLGdCQUM3Qzs7Ozs7b0JBQ1Asd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1Y7WUFBQztZQUFHO1lBQUk7WUFBSTtXQUFFLENBQUMsQ0FBQyxLQUFJLFFBQ2pCLHdCQUFDLFVBQUQ7WUFFSSxNQUFLO1lBQ0wsZUFBZSxpQkFBaUIsR0FBRztZQUNuQyxVQUFVO1lBQ1YsV0FBVyxtRkFDUCxrQkFBa0IsTUFDWixxREFDQTtzQkFHVDtXQUNHLEdBWEM7Ozs7a0JBV0QsQ0FDWDtVQUNBOzs7O2tCQUNKOzs7OztpQkFDSjs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDSSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNkQ7VUFBZTs7Ozs7VUFDNUYsd0JBQUMsVUFBRDtXQUNJLE1BQUs7V0FDTCxlQUFlLGdCQUFlLFNBQVEsQ0FBQyxJQUFJO1dBQzNDLFVBQVU7V0FDVixXQUFXLCtIQUNQLGNBQ00seUdBQ0E7cUJBUGQ7WUFVSSx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztZQUN2Qix3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7OztZQUN4QixlQUFlLHdCQUFDLFFBQUQsRUFBTSxXQUFVLGdEQUFpRDs7Ozs7V0FDN0U7Ozs7OztVQUNSLHdCQUFDLFVBQUQ7V0FDSSxNQUFLO1dBQ0wsZUFBZSxnQkFBZSxTQUFRLENBQUMsSUFBSTtXQUMzQyxVQUFVO1dBQ1YsV0FBVywrSEFDUCxjQUNNLHFIQUNBO3FCQVBkO1lBVUksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7WUFDakIsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7OztZQUNyQixlQUFlLHdCQUFDLFFBQUQsRUFBTSxXQUFVLGtEQUFtRDs7Ozs7V0FDL0U7Ozs7OztTQUNQOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsQ0FBQyxZQUFZO1VBQzVDLFdBQVU7b0JBSGQsQ0FLSyxlQUFlLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7cUJBQUksd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7OztvQkFDbEUsd0JBQUMsUUFBRCxZQUFNLHFEQUF3RDs7OztrQkFDMUQ7Ozs7O21CQUNQLGdCQUNHLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWlEO1VBRTNEOzs7O29CQUNILHdCQUFDLFlBQUQ7V0FDSSxNQUFNO1dBQ04sT0FBTztXQUNQLFdBQVUsTUFBSyxlQUFlLEVBQUUsT0FBTyxLQUFLO1dBQzVDLGFBQVk7V0FDWixXQUFVO1dBQ1YsVUFBVTtVQUNiOzs7O2tCQUNBOzs7OztpQkFFUjs7Ozs7O1FBRUosY0FDRyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLFNBQUQ7VUFBUyxNQUFNO1VBQUksV0FBVTtTQUF3Qzs7OzttQkFDckUsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUEyRDtTQUFVOzs7O21CQUNsRix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYjtXQUNJLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7O1dBQUM7V0FBRTtXQUFRO1VBQzlCOzs7OztpQkFDRjs7OztpQkFDSjs7Ozs7O09BRVI7Ozs7Ozs7QUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUE0RDtTQUF1Qjs7OzttQkFDaEcsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWIsQ0FBMkMsU0FBUyxRQUFPLHNCQUF1Qjs7Ozs7aUJBQ2pGOzs7O21CQUNMLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxZQUFZLElBQUk7VUFDL0IsV0FBVTtvQkFIZCxDQUtJLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7b0JBQUMsYUFDbkI7Ozs7O2lCQUNQOzs7Ozs7UUFHSixTQUFTLFNBQVMsS0FDZix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDVixTQUFTLEtBQUssR0FBRyxRQUNkLHdCQUFDLFVBQUQ7VUFFSSxNQUFLO1VBQ0wsZUFBZSxvQkFBb0IsR0FBRztVQUN0QyxXQUFXLG1HQUNQLHFCQUFxQixNQUNmLHFEQUNBO29CQVBkO1dBU0M7V0FDVSxNQUFNO1dBQUU7V0FBRyxFQUFFLE1BQU0sTUFBTSxHQUFHLEVBQUU7V0FBRTtVQUNuQztZQVZDOzs7O2dCQVVELENBQ1g7UUFDQTs7Ozs7UUFHUixrQkFDRyxnREFDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF5RCxlQUFlO1NBQVM7Ozs7bUJBQzdGLGVBQWUsZUFDWix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBOEMsZUFBZTtTQUFlOzs7O2lCQUU1Rjs7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1YsZUFBZSxXQUFXLEtBQUssR0FBRyxNQUFNO1VBQ3JDLE1BQU0sYUFBYTtXQUFFLEdBQUc7V0FBUyxHQUFHO1dBQWlCLEdBQUc7V0FBWSxHQUFHO1VBQWM7VUFDckYsTUFBTSxhQUFhO1dBQ2YsR0FBRztXQUNILEdBQUc7V0FDSCxHQUFHO1dBQ0gsR0FBRztVQUNQO1VBQ0EsT0FDSSx3QkFBQyxPQUFEO1dBQWEsV0FBVTtxQkFBdkI7WUFDSSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNJLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUErSCxJQUFJO2FBQVE7Ozs7dUJBQzNKLHdCQUFDLFFBQUQ7Y0FBTSxXQUFXLDZEQUE2RCxXQUFXLEVBQUUsV0FBVzt3QkFBa0MsV0FBVyxFQUFFLFdBQVc7YUFBYTs7OztxQkFDNUs7Ozs7OztZQUNMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUNYLHdCQUFDLHFCQUFELEVBQXFCLFNBQVMsRUFBRSxTQUFXOzs7OztZQUMxQzs7Ozs7WUFDSixFQUFFLFdBQVcsRUFBRSxRQUFRLFNBQVMsS0FDN0Isd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQ1YsRUFBRSxRQUFRLEtBQUssR0FBRyxPQUNmLHdCQUFDLE9BQUQ7Y0FBYyxXQUFXLDZEQUE2RCxFQUFFLFlBQVksMEZBQTBGO3dCQUE5TDtlQUNJLHdCQUFDLFFBQUQ7Z0JBQU0sV0FBVTswQkFBaEIsQ0FBNEIsT0FBTyxhQUFhLEtBQUssRUFBRSxHQUFFLEdBQU87Ozs7OztlQUNoRSx3QkFBQyxRQUFELFlBQU0sd0JBQUMscUJBQUQsRUFBcUIsU0FBUyxFQUFFLFdBQWE7Ozs7d0JBQU87Ozs7O2VBQ3pELEVBQUUsYUFBYSx3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQTRCO2VBQU87Ozs7O2NBQ2xFO2dCQUpLOzs7O29CQUlMLENBQ1I7WUFDQTs7Ozs7V0FFUjthQW5CSzs7OztpQkFtQkw7U0FFYixDQUFDO1FBQ0E7Ozs7Z0JBQ1A7Ozs7O09BRUw7Ozs7OztLQUVSOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1YsUUFBUSxTQUFTLElBQ2Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCO1FBQ0ksd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7Ozs7UUFBQztRQUFFLFFBQVE7UUFBTztPQUN6Qzs7Ozs7aUJBRU4sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTJCO01BQXFDOzs7OztLQUVuRjs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxTQUFTO09BQVMsV0FBVTtpQkFBa0g7TUFFNUo7Ozs7Z0JBQ1AsQ0FBQyxXQUNFLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsU0FBUztPQUNULFVBQVUsY0FBZSxDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsWUFBWSxLQUFLO09BQzdELFdBQVU7aUJBRVQsYUFDRztRQUFFLHdCQUFDLFNBQUQ7U0FBUyxNQUFNO1NBQUksV0FBVTtRQUFnQjs7Ozs7UUFBQztRQUFFLFVBQVUsZUFBZSxRQUFRO09BQU07Ozs7a0JBRXpGO1FBQUUsd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7UUFBQztRQUFXLFlBQVksSUFBSSxHQUFHLFVBQVUsZUFBZTtPQUFTOzs7OztNQUV4Rjs7OztpQkFFUix3QkFBQyxVQUFEO09BQ0ksTUFBSztPQUNMLFNBQVM7T0FDVCxVQUFVO09BQ1YsV0FBVTtpQkFFVCxXQUNHO1FBQUUsd0JBQUMsU0FBRDtTQUFTLE1BQU07U0FBSSxXQUFVO1FBQWdCOzs7OztRQUFDO1FBQWtCO1FBQVE7T0FBTzs7OztrQkFFakY7UUFBRSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OztRQUFDO1FBQVMsU0FBUyxTQUFTLElBQUksR0FBRyxTQUFTLE9BQU8sYUFBYTtPQUFhOzs7OztNQUV4Rzs7OztjQUVYOzs7OzthQUNKOzs7Ozs7R0FDSjs7Ozs7VUFDSjs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQUlGb3JtQnVpbGRlck1vZGFsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQge1xuICAgIFNwYXJrbGVzLCBYLCBMb2FkZXIyLCBLZXksIENoZWNrLCBFeWUsIEV5ZU9mZiwgRXh0ZXJuYWxMaW5rLFxuICAgIFNoaWVsZENoZWNrLCBBbGVydENpcmNsZSwgQ2hlY2tDaXJjbGUyLCBSb3RhdGVDY3csIENsb2NrLFxuICAgIENhbGN1bGF0b3IsIENvZGUsIENoZXZyb25Eb3duLCBDaGV2cm9uVXAsIEZpbGVUZXh0LCBDcHUsIExheWVyc1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHtcbiAgICBnZXRHZW1pbmlBcGlLZXlzLFxuICAgIGV4ZWN1dGVXaXRoQXBpS2V5RmFpbG92ZXIsXG4gICAgQVZBSUxBQkxFX01PREVMUyxcbiAgICBzYWZlSnNvblBhcnNlXG59IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FpU2VydmljZSc7XG5pbXBvcnQgeyBjcmVhdGVGb3JtLCBzYXZlUXVlc3Rpb25zIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgUmljaENvbnRlbnRSZW5kZXJlciBmcm9tICcuLi8uLi91dGlscy9SaWNoQ29udGVudFJlbmRlcmVyJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQUlGb3JtQnVpbGRlck1vZGFsKHsgaXNPcGVuLCBvbkNsb3NlLCBvbkZvcm1DcmVhdGVkIH0pIHtcbiAgICBjb25zdCBbcHJvbXB0LCBzZXRQcm9tcHRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtjb250ZXh0VGV4dCwgc2V0Q29udGV4dFRleHRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtmb3JtQ291bnQsIHNldEZvcm1Db3VudF0gPSB1c2VTdGF0ZSgxKTsgLy8gQjU6IDEtNSBmb3Jtc1xuICAgIGNvbnN0IFtxdWVzdGlvbkNvdW50LCBzZXRRdWVzdGlvbkNvdW50XSA9IHVzZVN0YXRlKDUpO1xuICAgIGNvbnN0IFt0eXBlUHJlZmVyZW5jZSwgc2V0VHlwZVByZWZlcmVuY2VdID0gdXNlU3RhdGUoJzInKTtcbiAgICBjb25zdCBbZGlmZmljdWx0eSwgc2V0RGlmZmljdWx0eV0gPSB1c2VTdGF0ZSgnU2VkYW5nJyk7XG4gICAgY29uc3QgW3NlbGVjdGVkTW9kZWwsIHNldFNlbGVjdGVkTW9kZWxdID0gdXNlU3RhdGUoJ2dlbWluaS0zLjYtZmxhc2gnKTtcbiAgICBjb25zdCBbaW5jbHVkZU1hdGgsIHNldEluY2x1ZGVNYXRoXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbaW5jbHVkZUNvZGUsIHNldEluY2x1ZGVDb2RlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbc2hvd0FkdmFuY2VkLCBzZXRTaG93QWR2YW5jZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgLy8gR2xvYmFsIFN0YWNrZWQgQVBJIEtleXNcbiAgICBjb25zdCBbYXBpS2V5cywgc2V0QXBpS2V5c10gPSB1c2VTdGF0ZSgoKSA9PiBnZXRHZW1pbmlBcGlLZXlzKCkpO1xuXG4gICAgLy8gU3RhdHVzXG4gICAgY29uc3QgW2dlbmVyYXRpbmcsIHNldEdlbmVyYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtjcmVhdGluZywgc2V0Q3JlYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2VsYXBzZWQsIHNldEVsYXBzZWRdID0gdXNlU3RhdGUoMCk7XG4gICAgY29uc3QgW3ByZXZpZXdzLCBzZXRQcmV2aWV3c10gPSB1c2VTdGF0ZShudWxsKTsgLy8gQXJyYXkgb2YgZm9ybSBwcmV2aWV3IG9iamVjdHNcbiAgICBjb25zdCBbYWN0aXZlUHJldmlld0lkeCwgc2V0QWN0aXZlUHJldmlld0lkeF0gPSB1c2VTdGF0ZSgwKTtcblxuICAgIGNvbnN0IHRpbWVyUmVmID0gdXNlUmVmKG51bGwpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFpc09wZW4pIHJldHVybjtcbiAgICAgICAgc2V0UHJvbXB0KCcnKTtcbiAgICAgICAgc2V0Q29udGV4dFRleHQoJycpO1xuICAgICAgICBzZXRFcnJvcignJyk7XG4gICAgICAgIHNldFN0YXR1cygnJyk7XG4gICAgICAgIHNldFByZXZpZXdzKG51bGwpO1xuICAgICAgICBzZXRBY3RpdmVQcmV2aWV3SWR4KDApO1xuICAgICAgICBzZXRFbGFwc2VkKDApO1xuICAgICAgICBzZXRGb3JtQ291bnQoMSk7XG4gICAgICAgIHNldFF1ZXN0aW9uQ291bnQoNSk7XG4gICAgICAgIHNldFR5cGVQcmVmZXJlbmNlKCcyJyk7XG4gICAgICAgIHNldERpZmZpY3VsdHkoJ1NlZGFuZycpO1xuICAgICAgICBzZXRJbmNsdWRlTWF0aChmYWxzZSk7XG4gICAgICAgIHNldEluY2x1ZGVDb2RlKGZhbHNlKTtcbiAgICAgICAgc2V0U2hvd0FkdmFuY2VkKGZhbHNlKTtcbiAgICAgICAgc2V0QXBpS2V5cyhnZXRHZW1pbmlBcGlLZXlzKCkpO1xuICAgIH0sIFtpc09wZW5dKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChnZW5lcmF0aW5nIHx8IGNyZWF0aW5nKSB7XG4gICAgICAgICAgICBzZXRFbGFwc2VkKDApO1xuICAgICAgICAgICAgdGltZXJSZWYuY3VycmVudCA9IHNldEludGVydmFsKCgpID0+IHNldEVsYXBzZWQocHJldiA9PiBwcmV2ICsgMSksIDEwMDApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKHRpbWVyUmVmLmN1cnJlbnQpIGNsZWFySW50ZXJ2YWwodGltZXJSZWYuY3VycmVudCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGlmICh0aW1lclJlZi5jdXJyZW50KSBjbGVhckludGVydmFsKHRpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgICB9O1xuICAgIH0sIFtnZW5lcmF0aW5nLCBjcmVhdGluZ10pO1xuXG4gICAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgZ2VuZXJhdGVTaW5nbGVGb3JtID0gYXN5bmMgKHRhcmdldEluZGV4LCB0b3RhbCwgY3VycmVudEFwaUtleSkgPT4ge1xuICAgICAgICBjb25zdCBtYXRoQ29kZUluc3RydWN0aW9ucyA9IFtdO1xuICAgICAgICBpZiAoaW5jbHVkZU1hdGgpIG1hdGhDb2RlSW5zdHJ1Y3Rpb25zLnB1c2goJy0gVW50dWsgcnVtdXMgbWF0ZW1hdGlrYS9maXNpa2EsIGd1bmFrYW4gZm9ybWF0IExhVGVYIGlubGluZSAkLi4uJCBhdGF1IGJsb2sgJCQuLi4kJCcpO1xuICAgICAgICBpZiAoaW5jbHVkZUNvZGUpIG1hdGhDb2RlSW5zdHJ1Y3Rpb25zLnB1c2goJy0gVW50dWsga29kZSBwcm9ncmFtLCBndW5ha2FuIGZvcm1hdCBgYGBiYWhhc2FcXFxcbmtvZGVcXFxcbmBgYCcpO1xuXG4gICAgICAgIGNvbnN0IHR5cGVEZXNjcmlwdGlvbiA9IHtcbiAgICAgICAgICAgICcxJzogJ1NlbXVhIHNvYWwgYmVydGlwZSBFc3NheSAvIElzaWFuIFNpbmdrYXQgKHR5cGVJZDogMSwgc2VydGFrYW4ga3VuY2kvY29udG9oIGphd2FiYW4gZGkgY29ycmVjdEFuc3dlcikuJyxcbiAgICAgICAgICAgICcyJzogJ1NlbXVhIHNvYWwgYmVydGlwZSBQaWxpaGFuIEdhbmRhICh0eXBlSWQ6IDIsIHNlZGlha2FuIDQgcGlsaWhhbiBqYXdhYmFuIGRpIG9wdGlvbnMgZGkgbWFuYSB0ZXBhdCBTQVRVIGJlcm5pbGFpIGlzQ29ycmVjdDogdHJ1ZSkuJyxcbiAgICAgICAgICAgICczJzogJ1NlbXVhIHNvYWwgYmVydGlwZSBDaGVja2JveCAvIFBpbGloYW4gTWFqZW11ayAodHlwZUlkOiAzLCBzZWRpYWthbiA0LTUgb3BzaSBkaSBtYW5hIGFkYSBtaW5pbWFsIDIgYmVybmlsYWkgaXNDb3JyZWN0OiB0cnVlKS4nLFxuICAgICAgICAgICAgJzUnOiAnU2VtdWEgc29hbCBiZXJ0aXBlIEJlbmFyIC8gU2FsYWggKHR5cGVJZDogNSwgY29ycmVjdEFuc3dlciBkaWlzaSBcIkJlbmFyXCIgYXRhdSBcIlNhbGFoXCIpLicsXG4gICAgICAgICAgICAnbWl4ZWQnOiAnVmFyaWFzaSBjYW1wdXJhbiBhbnRhcmEgUGlsaWhhbiBHYW5kYSAodHlwZUlkOiAyKSwgQmVuYXIvU2FsYWggKHR5cGVJZDogNSksIGRhbiBFc3NheSAodHlwZUlkOiAxKS4nLFxuICAgICAgICB9W3R5cGVQcmVmZXJlbmNlXSB8fCAnUGlsaWhhbiBHYW5kYSAodHlwZUlkOiAyKSc7XG5cbiAgICAgICAgbGV0IGV4dHJhQ29udGV4dCA9ICcnO1xuICAgICAgICBpZiAoY29udGV4dFRleHQgJiYgY29udGV4dFRleHQudHJpbSgpKSB7XG4gICAgICAgICAgICBleHRyYUNvbnRleHQgPSBgXFxuTWF0ZXJpIFJlZmVyZW5zaSBUYW1iYWhhbjpcXG5cIlwiXCJcXG4ke2NvbnRleHRUZXh0LnRyaW0oKX1cXG5cIlwiXCJcXG5gO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcHJvbXB0VGV4dCA9IGBcblBFUkFOICYgQkFUQVNBTiBLRVJBUzogQW5kYSBhZGFsYWggYXNpc3RlbiBwZW1idWF0IGZvcm11bGlyIGRhbiBzb2FsIHVqaWFuIHBlbmRpZGlrYW4gRm9ybVVwLiBBbmRhIEhBTllBIG1lbWJ1YXQga3VpcyBkYW4gc29hbCB1bnR1ayBrZXBlcmx1YW4gZWR1a2FzaS5cblxuQnVhdGxhaCAxIGZvcm11bGlyIGxlbmdrYXAgZGVuZ2FuICR7cXVlc3Rpb25Db3VudH0gYnV0aXIgc29hbCAke3RvdGFsID4gMSA/IGAoUGFrZXQvVmFyaWFzaSBrZS0ke3RhcmdldEluZGV4ICsgMX0gZGFyaSB0b3RhbCAke3RvdGFsfSBwYWtldClgIDogJyd9IGJlcmRhc2Fya2FuIHBhbmR1YW4gYmVyaWt1dDpcbi0gKipUb3BpayAvIERlc2tyaXBzaToqKiAke3Byb21wdC50cmltKCl9XG4tICoqVGluZ2thdCBLZXN1bGl0YW46KiogJHtkaWZmaWN1bHR5fVxuLSAqKkJlbnR1ayBTb2FsOioqICR7dHlwZURlc2NyaXB0aW9ufVxuLSAqKkJhaGFzYToqKiBCYWhhc2EgSW5kb25lc2lhIGJha3UgeWFuZyBiYWlrXG4ke2V4dHJhQ29udGV4dH1cbiR7bWF0aENvZGVJbnN0cnVjdGlvbnMubGVuZ3RoID4gMCA/IG1hdGhDb2RlSW5zdHJ1Y3Rpb25zLmpvaW4oJ1xcbicpIDogJyd9XG5cbioqRk9STUFUIEtFTFVBUkFOIFdBSklCIChKU09OIE9CSkVDVCk6KipcbktlbWJhbGlrYW4gSEFOWUEgZm9ybWF0IEpTT04gdmFsaWQgYmVyaWt1dCB0YW5wYSB0ZWtzIHBlbmdhbnRhciBhdGF1IHBlbnV0dXA6XG57XG4gIFwidGl0bGVcIjogXCIke3RvdGFsID4gMSA/IGBKdWR1bCBGb3JtdWxpciAoUGFrZXQgJHt0YXJnZXRJbmRleCArIDF9KWAgOiAnSnVkdWwgRm9ybXVsaXIgTGVuZ2thcCd9XCIsXG4gIFwiZGVzY3JpcHRpb25cIjogXCJEZXNrcmlwc2kgc2luZ2thdCBtZW5nZW5haSBmb3JtdWxpci9rdWlzIGluaVwiLFxuICBcInF1ZXN0aW9uc1wiOiBbXG4gICAge1xuICAgICAgXCJxdWVzdGlvblwiOiBcIlRla3MgcGVydGFueWFhbiBsZW5na2FwXCIsXG4gICAgICBcInR5cGVJZFwiOiAyLFxuICAgICAgXCJpc1JlcXVpcmVkXCI6IHRydWUsXG4gICAgICBcImlzU2NvcmFibGVcIjogdHJ1ZSxcbiAgICAgIFwiY29ycmVjdEFuc3dlclwiOiBcIkt1bmNpIGphd2FiYW4gamlrYSBhZGFcIixcbiAgICAgIFwib3B0aW9uc1wiOiBbXG4gICAgICAgIHtcIm9wdGlvblRleHRcIjogXCJQaWxpaGFuIEFcIiwgXCJpc0NvcnJlY3RcIjogZmFsc2V9LFxuICAgICAgICB7XCJvcHRpb25UZXh0XCI6IFwiUGlsaWhhbiBCXCIsIFwiaXNDb3JyZWN0XCI6IHRydWV9LFxuICAgICAgICB7XCJvcHRpb25UZXh0XCI6IFwiUGlsaWhhbiBDXCIsIFwiaXNDb3JyZWN0XCI6IGZhbHNlfSxcbiAgICAgICAge1wib3B0aW9uVGV4dFwiOiBcIlBpbGloYW4gRFwiLCBcImlzQ29ycmVjdFwiOiBmYWxzZX1cbiAgICAgIF1cbiAgICB9XG4gIF1cbn1cbmAudHJpbSgpO1xuXG4gICAgICAgIGNvbnN0IGVuZHBvaW50ID0gYGh0dHBzOi8vZ2VuZXJhdGl2ZWxhbmd1YWdlLmdvb2dsZWFwaXMuY29tL3YxYmV0YS9tb2RlbHMvJHtzZWxlY3RlZE1vZGVsfTpnZW5lcmF0ZUNvbnRlbnQ/a2V5PSR7Y3VycmVudEFwaUtleX1gO1xuICAgICAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgICBjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSwgNjAwMDApO1xuICAgICAgICBjb25zdCByZXNwID0gYXdhaXQgZmV0Y2goZW5kcG9pbnQsIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgIGNvbnRlbnRzOiBbeyBwYXJ0czogW3sgdGV4dDogcHJvbXB0VGV4dCB9XSB9XSxcbiAgICAgICAgICAgICAgICBnZW5lcmF0aW9uQ29uZmlnOiB7IHJlc3BvbnNlTWltZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJywgdGVtcGVyYXR1cmU6IDAuNyB9XG4gICAgICAgICAgICB9KVxuICAgICAgICB9KTtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG5cbiAgICAgICAgaWYgKCFyZXNwLm9rKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJEYXRhID0gYXdhaXQgcmVzcC5qc29uKCkuY2F0Y2goKCkgPT4gKHt9KSk7XG4gICAgICAgICAgICBjb25zdCBlcnJNc2cgPSBlcnJEYXRhLmVycm9yPy5tZXNzYWdlIHx8IGBIVFRQICR7cmVzcC5zdGF0dXN9YDtcbiAgICAgICAgICAgIGlmIChyZXNwLnN0YXR1cyA9PT0gNDI5KSB0aHJvdyBuZXcgRXJyb3IoYFJhdGUgbGltaXQgdGVyY2FwYWkgdW50dWsgbW9kZWwgJHtzZWxlY3RlZE1vZGVsfS4gQ29iYSBwaWxpaCBHZW1pbmkgMy42IEZsYXNoIExpdGUuYCk7XG4gICAgICAgICAgICBpZiAocmVzcC5zdGF0dXMgPT09IDQwMCB8fCByZXNwLnN0YXR1cyA9PT0gNDAzKSB0aHJvdyBuZXcgRXJyb3IoYEFQSSBLZXkgdGlkYWsgdmFsaWQgYXRhdSBha3NlcyBkaXRvbGFrLiAoJHtlcnJNc2d9KWApO1xuICAgICAgICAgICAgaWYgKHJlc3Auc3RhdHVzID49IDUwMCkgdGhyb3cgbmV3IEVycm9yKGBTZXJ2ZXIgQUkgU3R1ZGlvIHRpZGFrIHRlcnNlZGlhIChFcnJvciAke3Jlc3Auc3RhdHVzfSkuIENvYmEgbGFnaSBuYW50aS5gKTtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgR2FnYWwgbWVtYW5nZ2lsIEFJOiAke2Vyck1zZ31gKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwLmpzb24oKTtcbiAgICAgICAgbGV0IHRleHQgPSBkYXRhLmNhbmRpZGF0ZXM/LlswXT8uY29udGVudD8ucGFydHM/LlswXT8udGV4dCB8fCAnJztcbiAgICAgICAgbGV0IHBhcnNlZDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHBhcnNlZCA9IHNhZmVKc29uUGFyc2UodGV4dCk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdBSSBtZW5nZW1iYWxpa2FuIGZvcm1hdCBKU09OIHlhbmcgdGlkYWsgdmFsaWQuIENvYmEgdWxhbmdpIHBlbWJ1YXRhbi4nKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXBhcnNlZCB8fCAhcGFyc2VkLnRpdGxlIHx8ICFBcnJheS5pc0FycmF5KHBhcnNlZC5xdWVzdGlvbnMpKSB0aHJvdyBuZXcgRXJyb3IoJ0Zvcm1hdCBKU09OIGRhcmkgQUkgdGlkYWsgdmFsaWQnKTtcbiAgICAgICAgcmV0dXJuIHBhcnNlZDtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlR2VuZXJhdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGtleXMgPSBnZXRHZW1pbmlBcGlLZXlzKCk7XG4gICAgICAgIGlmIChrZXlzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgc2V0RXJyb3IoJ0FQSSBLZXkgR2VtaW5pIGJlbHVtIGRpYXR1ci4gU2lsYWthbiBhdHVyIEFQSSBLZXkgZGkgbWVudSBBSSBBc3Npc3RhbnQgQ2hhdCB0ZXJsZWJpaCBkYWh1bHUuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFwcm9tcHQudHJpbSgpICYmICFjb250ZXh0VGV4dC50cmltKCkpIHtcbiAgICAgICAgICAgIHNldEVycm9yKCdUdWxpcyBkZXNrcmlwc2kgYXRhdSBtYXRlcmkgZm9ybSB5YW5nIGluZ2luIGRpYnVhdC4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHNldEVycm9yKCcnKTtcbiAgICAgICAgc2V0R2VuZXJhdGluZyh0cnVlKTtcbiAgICAgICAgY29uc3QgY291bnRUb0dlbmVyYXRlID0gTWF0aC5taW4oTWF0aC5tYXgocGFyc2VJbnQoZm9ybUNvdW50LCAxMCkgfHwgMSwgMSksIDUpO1xuICAgICAgICBjb25zdCByZXN1bHRzID0gW107XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGV4ZWN1dGVXaXRoQXBpS2V5RmFpbG92ZXIoYXN5bmMgKGFjdGl2ZUFwaUtleSkgPT4ge1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnRUb0dlbmVyYXRlOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0U3RhdHVzKGBNZW55dXN1biBmb3JtdWxpciAke2kgKyAxfSBkYXJpICR7Y291bnRUb0dlbmVyYXRlfSBkZW5nYW4gJHtzZWxlY3RlZE1vZGVsfS4uLmApO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmb3JtUmVzID0gYXdhaXQgZ2VuZXJhdGVTaW5nbGVGb3JtKGksIGNvdW50VG9HZW5lcmF0ZSwgYWN0aXZlQXBpS2V5KTtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0cy5wdXNoKGZvcm1SZXMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGlmIChyZXN1bHRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBzZXRTdGF0dXMoJ1NlbGVzYWkhIFRpbmphdSBoYXNpbCBzZWJlbHVtIGRpc2ltcGFuLicpO1xuICAgICAgICAgICAgICAgIHNldFByZXZpZXdzKHJlc3VsdHMpO1xuICAgICAgICAgICAgICAgIHNldEFjdGl2ZVByZXZpZXdJZHgoMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgc2V0RXJyb3IoZXJyPy5uYW1lID09PSAnQWJvcnRFcnJvcidcbiAgICAgICAgICAgICAgICA/ICdQZXJtaW50YWFuIEFJIG1lbGV3YXRpIGJhdGFzIHdha3R1IDYwIGRldGlrLiBTaWxha2FuIGNvYmEgbGFnaS4nXG4gICAgICAgICAgICAgICAgOiAoZXJyLm1lc3NhZ2UgfHwgJ1RlcmphZGkga2VzYWxhaGFuIHNhYXQgbWVtcHJvc2VzIGZvcm11bGlyLicpKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldEdlbmVyYXRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNyZWF0ZUZvcm1zID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIXByZXZpZXdzIHx8IHByZXZpZXdzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAgICAgICBzZXRDcmVhdGluZyh0cnVlKTtcbiAgICAgICAgc2V0RXJyb3IoJycpO1xuICAgICAgICBsZXQgbGFzdENyZWF0ZWRJZCA9IG51bGw7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGZvciAobGV0IGZJZHggPSAwOyBmSWR4IDwgcHJldmlld3MubGVuZ3RoOyBmSWR4KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50UHJldmlldyA9IHByZXZpZXdzW2ZJZHhdO1xuICAgICAgICAgICAgICAgIHNldFN0YXR1cyhgTWVueWltcGFuIGZvcm11bGlyICR7ZklkeCArIDF9IGRhcmkgJHtwcmV2aWV3cy5sZW5ndGh9OiBcIiR7Y3VycmVudFByZXZpZXcudGl0bGV9XCIuLi5gKTtcbiAgICAgICAgICAgICAgICBjb25zdCBmb3JtUmVzID0gYXdhaXQgY3JlYXRlRm9ybSh7XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiBjdXJyZW50UHJldmlldy50aXRsZSxcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGN1cnJlbnRQcmV2aWV3LmRlc2NyaXB0aW9uIHx8ICcnXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgaWYgKCFmb3JtUmVzLm9rIHx8ICFmb3JtUmVzLmRhdGE/LmlkKSB0aHJvdyBuZXcgRXJyb3IoZm9ybVJlcy5tZXNzYWdlIHx8IGBHYWdhbCBtZW55aW1wYW4gZm9ybSAke2ZJZHggKyAxfWApO1xuICAgICAgICAgICAgICAgIGNvbnN0IG5ld0lkID0gZm9ybVJlcy5kYXRhLmlkO1xuICAgICAgICAgICAgICAgIGxhc3RDcmVhdGVkSWQgPSBuZXdJZDtcblxuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50UHJldmlldy5xdWVzdGlvbnMgJiYgY3VycmVudFByZXZpZXcucXVlc3Rpb25zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgc2F2ZVF1ZXN0aW9ucyhuZXdJZCwgY3VycmVudFByZXZpZXcucXVlc3Rpb25zLm1hcCgocSwgaSkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGVJZDogcGFyc2VJbnQocS50eXBlSWQsIDEwKSB8fCAyLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb246IHEucXVlc3Rpb24gfHwgJycsXG4gICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbkZvcm1hdDogJ3RleHQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25PcmRlcjogaSArIDEsXG4gICAgICAgICAgICAgICAgICAgICAgICBpc1JlcXVpcmVkOiBxLmlzUmVxdWlyZWQgIT09IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29ycmVjdEFuc3dlcjogcS5jb3JyZWN0QW5zd2VyIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBwb2ludHM6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zOiAocS5vcHRpb25zIHx8IFtdKS5tYXAobyA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvblRleHQ6IFN0cmluZyhvLm9wdGlvblRleHQgfHwgJycpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdDogQm9vbGVhbihvLmlzQ29ycmVjdClcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgICAgICAgICAgfSkpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICBpZiAob25Gb3JtQ3JlYXRlZCAmJiBsYXN0Q3JlYXRlZElkKSBvbkZvcm1DcmVhdGVkKGxhc3RDcmVhdGVkSWQpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHNldEVycm9yKCdHYWdhbCBtZW1idWF0IGZvcm06ICcgKyBlcnIubWVzc2FnZSk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRDcmVhdGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgY3VycmVudFByZXZpZXcgPSBwcmV2aWV3cyA/IHByZXZpZXdzW2FjdGl2ZVByZXZpZXdJZHhdIDogbnVsbDtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLXNsYXRlLTkwMC82MCBkYXJrOmJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXIteHNcIiBvbkNsaWNrPXtvbkNsb3NlfSAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgdy1mdWxsIG1heC13LTJ4bCBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sIG1heC1oLVs5MHZoXSB6LTEwXCI+XG5cbiAgICAgICAgICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1ncmFkaWVudC10by1yIGZyb20tdGVhbC01MDAvMTAgdmlhLWVtZXJhbGQtNTAwLzUgdG8tdHJhbnNwYXJlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS10ZWFsLTYwMCB0by1lbWVyYWxkLTQwMCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1tZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPkJ1YXQgRm9ybSBkZW5nYW4gQUk8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPkRlc2tyaXBzaWthbiBmb3JtICYgbWF0ZXJpLCBBSSBtZW55dXN1biBqdWR1bCwgZGVza3JpcHNpLCAmIGJ1dGlyIHNvYWwuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YXBpS2V5cy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTEgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgc2l6ZT17MTJ9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXBpS2V5cy5sZW5ndGh9IEFQSSBLZXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL2FpLWNoYXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTEgYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNjAgdGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCBob3ZlcjpiZy1hbWJlci0xMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEtleSBzaXplPXsxMn0gLz4gQXR1ciBLZXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25DbG9zZX0gY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDb250ZW50ICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBwLTYgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgIHthcGlLZXlzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzUwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1hbWJlci04MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8S2V5IHNpemU9ezE1fSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTYwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkFQSSBLZXkgR2VtaW5pIGJlbHVtIGRpYXR1ci4gU2lsYWthbiBhdHVyIGRpIEFJIEFzc2lzdGFudCBDaGF0Ljwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9haS1jaGF0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIGZvbnQtYm9sZCBzaHJpbmstMCB0cmFuc2l0aW9uLWNvbG9ycyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQXR1ciBkaSBBSSBDaGF0IDxFeHRlcm5hbExpbmsgc2l6ZT17MTJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC82MCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTkwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yLjUgdGV4dC14cyB0ZXh0LXJlZC03MDAgZGFyazp0ZXh0LXJlZC0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgc2l6ZT17MTV9IGNsYXNzTmFtZT1cInNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2Vycm9yfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIHshcHJldmlld3MgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEZXNrcmlwc2kgLyBUb3BpayBGb3JtICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGVza3JpcHNpIC8gVG9waWsgRm9ybXVsaXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Byb21wdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFByb21wdChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNvbnRvaDogS3VpcyBVamlhbiBBa2hpciBTZW1lc3RlciBGaXNpa2EgU01BIEtlbGFzIDExIG1hdGVyaSBUZXJtb2RpbmFtaWthICYgR2Vsb21iYW5nIEJ1bnlpLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCB0ZXh0LXhzIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtnZW5lcmF0aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEI2OiBNb2RlbCBTZWxlY3RvciAmIERpZmZpY3VsdHkgJiBGb3JtIENvdW50cyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1vZGVsIEFJICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENwdSBzaXplPXsxMn0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMFwiIC8+IE1vZGVsIEFJXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZE1vZGVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNlbGVjdGVkTW9kZWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtnZW5lcmF0aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMCBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge0FWQUlMQUJMRV9NT0RFTFMubWFwKG0gPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bS5pZH0gdmFsdWU9e20uaWR9PnttLm5hbWV9ICh7bS5iYWRnZX0pPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRpbmdrYXQgS2VzdWxpdGFuICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+S2VzdWxpdGFuPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGlmZmljdWx0eX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXREaWZmaWN1bHR5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDAgZm9udC1tZWRpdW1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNdWRhaFwiPk11ZGFoPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNlZGFuZ1wiPlNlZGFuZzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTdWxpdFwiPlN1bGl0IChIT1RTKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBUaXBlIFNvYWwgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5UaXBlIFNvYWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0eXBlUHJlZmVyZW5jZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRUeXBlUHJlZmVyZW5jZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2dlbmVyYXRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMlwiPlBpbGloYW4gR2FuZGEgKFBHKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIxXCI+RXNzYXkgLyBJc2lhbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCI1XCI+QmVuYXIgLyBTYWxhaDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIzXCI+Q2hlY2tib3ggLyBNYWplbXVrPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm1peGVkXCI+Q2FtcHVyYW48L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCNTogSnVtbGFoIEZvcm0gJiBKdW1sYWggU29hbCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMYXllcnMgc2l6ZT17MTJ9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDBcIiAvPiBKdW1sYWggRm9ybSBEaWJ1YXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7WzEsIDIsIDMsIDVdLm1hcChjbnQgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2NudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Rm9ybUNvdW50KGNudCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtQ291bnQgPT09IGNudFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy10ZWFsLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci10ZWFsLTYwMCBzaGFkb3cteHMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ym9yZGVyLXRlYWwtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjbnR9IHtjbnQgPiAxID8gJ1Bha2V0JyA6ICdGb3JtJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBzaXplPXsxMn0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMFwiIC8+IFNvYWwgcGVyIEZvcm1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7WzUsIDEwLCAxNSwgMjBdLm1hcChjbnQgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2NudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UXVlc3Rpb25Db3VudChjbnQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2dlbmVyYXRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcHktMS41IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgYm9yZGVyIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25Db3VudCA9PT0gY250XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXRlYWwtNjAwIHRleHQtd2hpdGUgYm9yZGVyLXRlYWwtNjAwIHNoYWRvdy14cydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3Zlcjpib3JkZXItdGVhbC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogS2FUZVggJiBDb2RlIFRvZ2dsZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcCBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW1cIj5TZXJ0YWthbjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW5jbHVkZU1hdGgocHJldiA9PiAhcHJldil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluY2x1ZGVNYXRoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMCBib3JkZXItdGVhbC0zMDAgZGFyazpib3JkZXItdGVhbC03MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXRlYWwtMzAwIGhvdmVyOnRleHQtdGVhbC02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhbGN1bGF0b3Igc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SdW11cyAoS2FUZVgpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2luY2x1ZGVNYXRoICYmIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy10ZWFsLTUwMCBzaHJpbmstMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJbmNsdWRlQ29kZShwcmV2ID0+ICFwcmV2KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtnZW5lcmF0aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5jbHVkZUNvZGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctaW5kaWdvLTUwIGRhcms6YmctaW5kaWdvLTk1MC82MCB0ZXh0LWluZGlnby03MDAgZGFyazp0ZXh0LWluZGlnby0zMDAgYm9yZGVyLWluZGlnby0zMDAgZGFyazpib3JkZXItaW5kaWdvLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBob3Zlcjpib3JkZXItaW5kaWdvLTMwMCBob3Zlcjp0ZXh0LWluZGlnby02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvZGUgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Db2RlIEJsb2NrPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2luY2x1ZGVDb2RlICYmIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1pbmRpZ28tNTAwIHNocmluay0wXCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEI4OiBNYXRlcmkgUmVmZXJlbnNpIFRhbWJhaGFuIChBY2NvcmRpb24pICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZHZhbmNlZCghc2hvd0FkdmFuY2VkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dBZHZhbmNlZCA/IDxDaGV2cm9uVXAgc2l6ZT17MTR9IC8+IDogPENoZXZyb25Eb3duIHNpemU9ezE0fSAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk9wc2kgVGFtYmFoYW46IFNpc2lwa2FuIE1hdGVyaSAvIFRla3MgUnVqdWthbiAoQjgpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dBZHZhbmNlZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgc3BhY2UteS0xLjUgYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVtcGVsIHJhbmdrdW1hbiBtYXRlcmksIHNpbGFidXMsIGF0YXUgYmFoYW4gYWphci4gQUkgYWthbiBtZW1idWF0IHNvYWwgc3Blc2lmaWsgYmVyZGFzYXJrYW4gbWF0ZXJpIGluaTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb250ZXh0VGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Q29udGV4dFRleHQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRlbXBlbCB0ZWtzIG1hdGVyaSwgbW9kdWwgYWphciwgYXRhdSByZWZlcmVuc2kgYmFjYWFuIGRpIHNpbmkuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIuNSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2VuZXJhdGluZyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC81MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsyMn0gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHRleHQtWyMwMDg5N0JdIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWV4dHJhYm9sZCB0ZXh0LXRlYWwtOTAwIGRhcms6dGV4dC10ZWFsLTEwMFwiPntzdGF0dXN9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvY2sgc2l6ZT17MTF9IC8+IHtlbGFwc2VkfSBkZXRpa1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBQcmV2aWV3IE1vZGUgKEI2KVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+4pyoIEZvcm0gU2lhcCBEaXRpbmphdTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+e3ByZXZpZXdzLmxlbmd0aH0gZm9ybXVsaXIgZGloYXNpbGthbjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UHJldmlld3MobnVsbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IHNpemU9ezEzfSAvPiBCdWF0IFVsYW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE11bHRpLWZvcm0gVGFiIFNlbGVjdG9yIGlmID4gMSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJldmlld3MubGVuZ3RoID4gMSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBvdmVyZmxvdy14LWF1dG8gcGItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ByZXZpZXdzLm1hcCgocCwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVByZXZpZXdJZHgoaWR4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZVByZXZpZXdJZHggPT09IGlkeFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXRlYWwtNjAwIHRleHQtd2hpdGUgYm9yZGVyLXRlYWwtNjAwIHNoYWRvdy14cydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYWtldCB7aWR4ICsgMX06IHtwLnRpdGxlLnNsaWNlKDAsIDE4KX0uLi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRQcmV2aWV3ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXRlYWwtNTAvNTAgZGFyazpiZy10ZWFsLTk1MC8zMCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwLzYwIGRhcms6Ym9yZGVyLXRlYWwtODAwLzYwIHJvdW5kZWQtMnhsIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e2N1cnJlbnRQcmV2aWV3LnRpdGxlfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFByZXZpZXcuZGVzY3JpcHRpb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj57Y3VycmVudFByZXZpZXcuZGVzY3JpcHRpb259PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1heC1oLTY0IG92ZXJmbG93LXktYXV0byBwci0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRQcmV2aWV3LnF1ZXN0aW9ucz8ubWFwKChxLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHR5cGVMYWJlbHMgPSB7IDE6ICdFc3NheScsIDI6ICdQaWxpaGFuIEdhbmRhJywgMzogJ0NoZWNrYm94JywgNTogJ0JlbmFyL1NhbGFoJyB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0eXBlQ29sb3JzID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMTogJ2JnLWJsdWUtNTAgdGV4dC1ibHVlLTcwMCBkYXJrOmJnLWJsdWUtOTUwLzUwIGRhcms6dGV4dC1ibHVlLTMwMCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAyOiAnYmctdGVhbC01MCB0ZXh0LXRlYWwtNzAwIGRhcms6YmctdGVhbC05NTAvNTAgZGFyazp0ZXh0LXRlYWwtMzAwJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDM6ICdiZy1pbmRpZ28tNTAgdGV4dC1pbmRpZ28tNzAwIGRhcms6YmctaW5kaWdvLTk1MC81MCBkYXJrOnRleHQtaW5kaWdvLTMwMCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA1OiAnYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgZGFyazpiZy1hbWJlci05NTAvNTAgZGFyazp0ZXh0LWFtYmVyLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJwLTMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcHgtMS41IHB5LTAuNSByb3VuZGVkIHNocmluay0wXCI+e2kgKyAxfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgcHgtMS41IHB5LTAuNSByb3VuZGVkIHNocmluay0wICR7dHlwZUNvbG9yc1txLnR5cGVJZF0gfHwgJ2JnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTYwMCd9YH0+e3R5cGVMYWJlbHNbcS50eXBlSWRdIHx8ICdTb2FsJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGxlYWRpbmctcmVsYXhlZCBwbC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e3EucXVlc3Rpb259IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Eub3B0aW9ucyAmJiBxLm9wdGlvbnMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtMiBncmlkIGdyaWQtY29scy0yIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS5vcHRpb25zLm1hcCgobywgb2kpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17b2l9IGNsYXNzTmFtZT17YHRleHQtWzExcHhdIHB4LTIgcHktMC41IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1zdGFydCBnYXAtMSAke28uaXNDb3JyZWN0ID8gJ2JnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC81MCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCBmb250LWJvbGQnIDogJ3RleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaHJpbmstMFwiPntTdHJpbmcuZnJvbUNoYXJDb2RlKDY1ICsgb2kpfS48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e28ub3B0aW9uVGV4dH0gLz48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvLmlzQ29ycmVjdCAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNTAwIHNocmluay0wXCI+4pyTPC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YXBpS2V5cy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezEzfSAvPiB7YXBpS2V5cy5sZW5ndGh9IEFQSSBLZXkgQWt0aWZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYW1iZXItNjAwIGZvbnQtYm9sZFwiPuKaoCBIYXJhcCBhdHVyIEFQSSBLZXkgZGkgQ2hhdCBBSTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtvbkNsb3NlfSBjbGFzc05hbWU9XCJweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYXRhbFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICB7IXByZXZpZXdzID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUdlbmVyYXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZyB8fCAoIXByb21wdC50cmltKCkgJiYgIWNvbnRleHRUZXh0LnRyaW0oKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IGJnLVsjMDA4OTdCXSBob3ZlcjpiZy1bIzAwNzk2Ql0gdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dlbmVyYXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PjxMb2FkZXIyIHNpemU9ezE0fSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW5cIiAvPiB7c3RhdHVzIHx8IGBNZW1idWF0Li4uICgke2VsYXBzZWR9cylgfTwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD48U3BhcmtsZXMgc2l6ZT17MTR9IC8+IEdlbmVyYXRlIHtmb3JtQ291bnQgPiAxID8gYCR7Zm9ybUNvdW50fSBQYWtldCBGb3JtYCA6ICdGb3JtJ308Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ3JlYXRlRm9ybXN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjcmVhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3JlYXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PjxMb2FkZXIyIHNpemU9ezE0fSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW5cIiAvPiBNZW55aW1wYW4gRm9ybSAoe2VsYXBzZWR9cykuLi48Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+PENoZWNrQ2lyY2xlMiBzaXplPXsxNH0gLz4gU2ltcGFuIHtwcmV2aWV3cy5sZW5ndGggPiAxID8gYCR7cHJldmlld3MubGVuZ3RofSBGb3JtIEluaWAgOiAnRm9ybSBJbmknfTwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==