import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/AIGeneratorModal.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { Sparkles, X, Loader2, CheckCircle2, Key, BookOpen, Check, AlertCircle, Code, Calculator, RotateCcw, Eye, EyeOff, ExternalLink, ShieldCheck, Cpu, Clock, ChevronDown, ChevronUp, FileText } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import { generateQuestionsWithAI, streamGenerateQuestionsWithAI, getGeminiApiKeys, AVAILABLE_MODELS } from "/src/services/aiService.js";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/AIGeneratorModal.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function AIGeneratorModal({ isOpen, onClose, onAddQuestions, formTitle = "" }) {
	_s();
	const [step, setStep] = useState("config");
	const [topic, setTopic] = useState(formTitle || "");
	const [contextText, setContextText] = useState("");
	const [count, setCount] = useState(5);
	const [typePreference, setTypePreference] = useState("2");
	const [difficulty, setDifficulty] = useState("Sedang");
	const [includeMath, setIncludeMath] = useState(false);
	const [includeCode, setIncludeCode] = useState(false);
	const [showAdvanced, setShowAdvanced] = useState(false);
	const [selectedModel, setSelectedModel] = useState("gemini-3.6-flash");
	// Global Stacked API Keys (Configured in AI Assistant)
	const [apiKeys, setApiKeys] = useState(() => getGeminiApiKeys());
	// Generation state & Friendly status
	const [generating, setGenerating] = useState(false);
	const [statusMessage, setStatusMessage] = useState("");
	const [elapsedSeconds, setElapsedSeconds] = useState(0);
	const [error, setError] = useState(null);
	const [generatedQuestions, setGeneratedQuestions] = useState([]);
	const [selectedIndices, setSelectedIndices] = useState([]);
	const [resultInfo, setResultInfo] = useState({
		model: "",
		time: ""
	});
	const timerIntervalRef = useRef(null);
	useEffect(() => {
		if (isOpen) {
			setStep("config");
			setError(null);
			setStatusMessage("");
			setElapsedSeconds(0);
			const savedKeys = getGeminiApiKeys();
			setApiKeys(savedKeys);
			if (!topic && formTitle) setTopic(formTitle);
		}
	}, [isOpen, formTitle]);
	// Timer counter when generating
	useEffect(() => {
		if (generating) {
			setElapsedSeconds(0);
			timerIntervalRef.current = setInterval(() => {
				setElapsedSeconds((prev) => prev + 1);
			}, 1e3);
		} else {
			if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
		}
		return () => {
			if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
		};
	}, [generating]);
	if (!isOpen) return null;
	const handleGenerate = async (e) => {
		if (e) e.preventDefault();
		const currentKeys = getGeminiApiKeys();
		if (currentKeys.length === 0) {
			setError("API Key Gemini belum diatur. Silakan tambahkan API Key di menu AI Assistant Chat terlebih dahulu.");
			return;
		}
		if (!topic.trim() && !contextText.trim()) {
			setError("Harap masukkan topik/materi soal yang ingin dibuat.");
			return;
		}
		setError(null);
		setGenerating(true);
		setStatusMessage("Menghubungkan ke Google AI Studio...");
		setGeneratedQuestions([]);
		setSelectedIndices([]);
		await streamGenerateQuestionsWithAI({
			topic: topic.trim(),
			contextText: contextText.trim(),
			count: parseInt(count, 10) || 5,
			typePreference,
			difficulty,
			includeMath,
			includeCode,
			selectedModel,
			customApiKey: currentKeys[0]
		}, (question) => {
			// B9: Live stream question into preview list
			setGeneratedQuestions((prev) => {
				const next = [...prev, question];
				setSelectedIndices(next.map((_, i) => i));
				return next;
			});
			setStep("preview");
		}, (statusMsg) => {
			setStatusMessage(statusMsg);
		}, (doneRes) => {
			setGenerating(false);
			if (doneRes.ok) {
				setResultInfo({
					model: doneRes.modelUsed,
					time: doneRes.elapsedSec
				});
			} else {
				if (generatedQuestions.length === 0) {
					setError(doneRes.message || "Gagal membuat soal. Periksa kembali koneksi atau API Key Anda.");
				}
			}
		});
	};
	const toggleSelect = (index) => {
		setSelectedIndices((prev) => prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]);
	};
	const toggleSelectAll = () => {
		if (selectedIndices.length === generatedQuestions.length) {
			setSelectedIndices([]);
		} else {
			setSelectedIndices(generatedQuestions.map((_, i) => i));
		}
	};
	const handleImportToForm = () => {
		const selected = generatedQuestions.filter((_, i) => selectedIndices.includes(i));
		if (selected.length === 0) return;
		onAddQuestions(selected);
		onClose();
	};
	const typeLabels = {
		1: "Isian Singkat / Essay",
		2: "Pilihan Ganda",
		3: "Pilihan Majemuk (Checkbox)",
		5: "Benar / Salah"
	};
	const maskKey = (key) => {
		if (!key || key.length < 8) return "****";
		return `${key.substring(0, 6)}...${key.substring(key.length - 4)}`;
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xs transition-opacity",
			onClick: onClose
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 181,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-teal-500/10 via-emerald-500/5 to-transparent",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-2xl bg-[#00897B] text-white flex items-center justify-center shadow-md shadow-teal-500/20",
							children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 20 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2",
							children: "Buat Soal Otomatis dengan AI"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400",
							children: "Bantu guru & siswa membuat butir soal kuis secara instan dan rapi."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 199,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 195,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [apiKeys.length > 0 ? /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline-flex items-center gap-1.5 px-3 py-1 bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 rounded-xl text-xs font-bold border border-teal-200 dark:border-teal-800",
							children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
								size: 13,
								className: "text-teal-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [apiKeys.length, " API Key Aktif"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 29
						}, this) : /* @__PURE__ */ _jsxDEV(Link, {
							to: "/ai-chat",
							className: "inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 hover:bg-amber-100 rounded-xl text-xs font-bold border border-amber-200 dark:border-amber-800 transition-colors",
							children: [/* @__PURE__ */ _jsxDEV(Key, { size: 13 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Atur Key di AI Chat" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							className: "p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto p-6 space-y-5",
					children: [
						apiKeys.length === 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 rounded-2xl flex items-center justify-between gap-3 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-amber-800 dark:text-amber-300 font-medium",
								children: [/* @__PURE__ */ _jsxDEV(Key, {
									size: 16,
									className: "text-amber-600 shrink-0"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 235,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "API Key Gemini belum diatur. Silakan atur API Key di menu AI Assistant Chat." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 236,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: "/ai-chat",
								className: "px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold shrink-0 transition-colors inline-flex items-center gap-1",
								children: ["Atur di AI Chat ", /* @__PURE__ */ _jsxDEV(ExternalLink, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 242,
									columnNumber: 49
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 238,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 233,
							columnNumber: 25
						}, this),
						error && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900 rounded-2xl flex items-start gap-2.5 text-xs text-red-700 dark:text-red-300",
							children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
								size: 16,
								className: "shrink-0 mt-0.5"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-bold",
									children: "Perhatian"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 251,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-0.5",
									children: error
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 252,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 250,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 248,
							columnNumber: 25
						}, this),
						step === "config" ? /* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleGenerate,
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-xs font-extrabold text-slate-800 dark:text-slate-200 flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ _jsxDEV(BookOpen, {
												size: 14,
												className: "text-teal-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 263,
												columnNumber: 37
											}, this),
											"Materi / Topik Soal ",
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-red-500",
												children: "*"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 264,
												columnNumber: 57
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 262,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: topic,
										onChange: (e) => setTopic(e.target.value),
										placeholder: "Contoh: Fotosintesis, Hukum Newton, Tata Surya, Pemrograman Web Dasar...",
										className: "w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B] font-medium",
										required: true,
										disabled: generating
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 266,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 261,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-xs font-bold text-slate-700 dark:text-slate-300",
												children: "Jumlah Soal"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 282,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 rounded-xl",
												children: [
													3,
													5,
													10,
													15
												].map((num) => /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													disabled: generating,
													onClick: () => setCount(num),
													className: `flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${count === num ? "bg-white dark:bg-slate-700 text-[#00897B] dark:text-teal-300 shadow-xs" : "text-slate-500 hover:text-slate-900 dark:text-slate-400"}`,
													children: num
												}, num, false, {
													fileName: _jsxFileName,
													lineNumber: 287,
													columnNumber: 45
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 285,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 281,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-xs font-bold text-slate-700 dark:text-slate-300",
												children: "Bentuk Soal"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 306,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("select", {
												value: typePreference,
												onChange: (e) => setTypePreference(e.target.value),
												disabled: generating,
												className: "w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-[#00897B]",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "2",
														children: "Pilihan Ganda (A, B, C, D)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 315,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "1",
														children: "Isian Singkat / Essay"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 316,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "5",
														children: "Benar / Salah (True/False)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 317,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "3",
														children: "Pilihan Majemuk (Checkbox)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 318,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "mixed",
														children: "Campuran (Bervariasi)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 319,
														columnNumber: 41
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 309,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 305,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-xs font-bold text-slate-700 dark:text-slate-300",
												children: "Tingkat Kesulitan"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 325,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("select", {
												value: difficulty,
												onChange: (e) => setDifficulty(e.target.value),
												disabled: generating,
												className: "w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-[#00897B]",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Mudah",
														children: "Mudah (Dasar)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 334,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Sedang",
														children: "Sedang (Standar)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 335,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Sulit (HOTS)",
														children: "Sulit (Penalaran / HOTS)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 336,
														columnNumber: 41
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 328,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 324,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 278,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5 pt-1",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Cpu, {
												size: 14,
												className: "text-teal-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 345,
												columnNumber: 41
											}, this), " Model Google Gemini"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-slate-400",
											children: "Dari Google AI Studio"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 347,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: selectedModel,
										onChange: (e) => setSelectedModel(e.target.value),
										disabled: generating,
										className: "w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-[#00897B]",
										children: AVAILABLE_MODELS.map((m) => /* @__PURE__ */ _jsxDEV("option", {
											value: m.id,
											children: [
												m.name,
												" — ",
												m.desc
											]
										}, m.id, true, {
											fileName: _jsxFileName,
											lineNumber: 356,
											columnNumber: 41
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 349,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 342,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 border-t border-slate-100 dark:border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowAdvanced(!showAdvanced),
										className: "text-xs font-bold text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1 cursor-pointer",
										children: [
											/* @__PURE__ */ _jsxDEV(FileText, { size: 13 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 370,
												columnNumber: 37
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: showAdvanced ? "Tutup Opsi Tambahan" : "Tambah Catatan / Teks Materi Referensi (Opsional)" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 371,
												columnNumber: 37
											}, this),
											showAdvanced ? /* @__PURE__ */ _jsxDEV(ChevronUp, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 372,
												columnNumber: 53
											}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 372,
												columnNumber: 79
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 365,
										columnNumber: 33
									}, this), showAdvanced && /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-3 space-y-3 p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-xs font-bold text-slate-700 dark:text-slate-300",
												children: "Tempel Teks / Rangkuman Buku:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 378,
												columnNumber: 45
											}, this), /* @__PURE__ */ _jsxDEV("textarea", {
												value: contextText,
												onChange: (e) => setContextText(e.target.value),
												rows: 3,
												disabled: generating,
												placeholder: "Tempelkan teks modul atau rangkuman di sini agar soal dibuat persis dari materi ini...",
												className: "w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 381,
												columnNumber: 45
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 377,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-wrap gap-4 pt-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 dark:text-slate-300",
												children: [/* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: includeMath,
													onChange: (e) => setIncludeMath(e.target.checked),
													disabled: generating,
													className: "w-4 h-4 rounded text-teal-600 focus:ring-teal-500 border-slate-300"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 393,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(Calculator, {
														size: 13,
														className: "text-amber-500"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 401,
														columnNumber: 53
													}, this), " Rumus Matematika (LaTeX)"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 400,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 392,
												columnNumber: 45
											}, this), /* @__PURE__ */ _jsxDEV("label", {
												className: "flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 dark:text-slate-300",
												children: [/* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: includeCode,
													onChange: (e) => setIncludeCode(e.target.checked),
													disabled: generating,
													className: "w-4 h-4 rounded text-teal-600 focus:ring-teal-500 border-slate-300"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 405,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(Code, {
														size: 13,
														className: "text-sky-500"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 413,
														columnNumber: 53
													}, this), " Kode Pemrograman"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 412,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 404,
												columnNumber: 45
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 391,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 376,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 364,
									columnNumber: 29
								}, this),
								generating && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-800/80 flex items-center gap-3.5 animate-in fade-in",
									children: [/* @__PURE__ */ _jsxDEV(Loader2, {
										size: 24,
										className: "animate-spin text-[#00897B] dark:text-teal-400 shrink-0"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 424,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 min-w-0",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-extrabold text-teal-900 dark:text-teal-100",
											children: statusMessage || "Sedang membuat soal..."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 426,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-teal-700 dark:text-teal-300 mt-0.5 flex items-center gap-2",
											children: [
												/* @__PURE__ */ _jsxDEV("span", { children: ["Model: ", /* @__PURE__ */ _jsxDEV("b", {
													className: "font-semibold",
													children: selectedModel
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 430,
													columnNumber: 58
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 430,
													columnNumber: 45
												}, this),
												/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 431,
													columnNumber: 45
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ _jsxDEV(Clock, { size: 11 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 433,
															columnNumber: 49
														}, this),
														" ",
														elapsedSeconds,
														" detik"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 432,
													columnNumber: 45
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 429,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 425,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 423,
									columnNumber: 33
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 258,
							columnNumber: 25
						}, this) : 
						/* Preview Soal yang Dibuat */
/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-800 dark:text-slate-200",
										children: [
											"✨ ",
											generatedQuestions.length,
											" Soal Berhasil Dibuat"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 446,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold",
										children: [
											resultInfo.time,
											" detik • ",
											resultInfo.model
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 449,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 445,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: toggleSelectAll,
									className: "text-xs text-teal-700 dark:text-teal-400 font-bold hover:underline cursor-pointer",
									children: selectedIndices.length === generatedQuestions.length ? "Batal Pilih Semua" : "Pilih Semua"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 453,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 444,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3 max-h-[50vh] overflow-y-auto pr-1",
								children: generatedQuestions.map((q, idx) => {
									const isSelected = selectedIndices.includes(idx);
									return /* @__PURE__ */ _jsxDEV("div", {
										onClick: () => toggleSelect(idx),
										className: `p-4 rounded-2xl border transition-all cursor-pointer ${isSelected ? "bg-white dark:bg-slate-800 border-teal-500 dark:border-teal-400 shadow-sm ring-1 ring-teal-500/20" : "bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-60"}`,
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-3",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: isSelected,
												onChange: () => toggleSelect(idx),
												onClick: (e) => e.stopPropagation(),
												className: "w-4 h-4 mt-1 rounded text-teal-600 focus:ring-teal-500 border-slate-300 cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 476,
												columnNumber: 49
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex-1 min-w-0 space-y-2",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "text-[11px] font-extrabold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200",
															children: ["Nomor ", idx + 1]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 485,
															columnNumber: 57
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "text-[11px] font-bold px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800",
															children: typeLabels[q.typeId] || "Pilihan Ganda"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 488,
															columnNumber: 57
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 484,
														columnNumber: 53
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "text-xs sm:text-sm font-bold text-slate-900 dark:text-white leading-relaxed",
														children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: q.question }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 494,
															columnNumber: 57
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 493,
														columnNumber: 53
													}, this),
													[2, 3].includes(q.typeId) && q.options?.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
														className: "grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1",
														children: q.options.map((opt, oIdx) => /* @__PURE__ */ _jsxDEV("div", {
															className: `px-3 py-1.5 rounded-xl text-xs flex items-center gap-2 ${opt.isCorrect ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold border border-emerald-300 dark:border-emerald-800" : "bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"}`,
															children: [
																/* @__PURE__ */ _jsxDEV("span", {
																	className: "shrink-0 w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200",
																	children: String.fromCharCode(65 + oIdx)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 509,
																	columnNumber: 69
																}, this),
																/* @__PURE__ */ _jsxDEV("span", {
																	className: "truncate flex-1",
																	children: opt.optionText
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 512,
																	columnNumber: 69
																}, this),
																opt.isCorrect && /* @__PURE__ */ _jsxDEV(Check, {
																	size: 12,
																	className: "text-emerald-600 shrink-0"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 513,
																	columnNumber: 87
																}, this)
															]
														}, oIdx, true, {
															fileName: _jsxFileName,
															lineNumber: 501,
															columnNumber: 65
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 499,
														columnNumber: 57
													}, this),
													q.typeId === 5 && /* @__PURE__ */ _jsxDEV("div", {
														className: "text-xs text-slate-600 dark:text-slate-400 pt-1",
														children: ["Kunci Jawaban: ", /* @__PURE__ */ _jsxDEV("span", {
															className: "font-bold text-teal-700 dark:text-teal-300",
															children: q.correctAnswer || "Benar"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 521,
															columnNumber: 76
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 520,
														columnNumber: 57
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 483,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 475,
											columnNumber: 45
										}, this)
									}, idx, false, {
										fileName: _jsxFileName,
										lineNumber: 466,
										columnNumber: 41
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 462,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 443,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 231,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between",
					children: step === "config" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs text-slate-400 dark:text-slate-500",
						children: apiKeys.length > 0 ? /* @__PURE__ */ _jsxDEV("span", {
							className: "flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300 font-bold",
							children: [
								/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 13 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 542,
									columnNumber: 41
								}, this),
								" ",
								apiKeys.length,
								" API Key Aktif"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 541,
							columnNumber: 37
						}, this) : /* @__PURE__ */ _jsxDEV("span", {
							className: "text-amber-700 dark:text-amber-300 font-bold",
							children: "⚠️ Harap atur API Key di Chat AI"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 545,
							columnNumber: 37
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 539,
						columnNumber: 29
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							disabled: generating,
							className: "px-4 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all cursor-pointer disabled:opacity-50",
							children: "Batal"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 551,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleGenerate,
							disabled: generating || !topic.trim() && !contextText.trim(),
							className: "px-6 py-2.5 bg-[#00897B] hover:bg-[#00796B] text-white rounded-xl text-xs font-bold shadow-md shadow-teal-500/20 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed",
							children: generating ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
								size: 15,
								className: "animate-spin"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 567,
								columnNumber: 45
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
								"Sedang Membuat (",
								elapsedSeconds,
								"s)..."
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 568,
								columnNumber: 45
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 566,
								columnNumber: 41
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Sparkles, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 572,
								columnNumber: 45
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
								"Buat ",
								count,
								" Soal Sekarang"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 573,
								columnNumber: 45
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 571,
								columnNumber: 41
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 559,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 550,
						columnNumber: 29
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 538,
						columnNumber: 25
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setStep("config"),
						className: "px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer",
						children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 586,
							columnNumber: 33
						}, this), " Buat Ulang"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 581,
						columnNumber: 29
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							className: "px-4 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all cursor-pointer",
							children: "Batal"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 589,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleImportToForm,
							disabled: selectedIndices.length === 0,
							className: "px-6 py-2.5 bg-[#00897B] hover:bg-[#00796B] text-white rounded-xl text-xs font-bold shadow-md shadow-teal-500/20 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50",
							children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 602,
								columnNumber: 37
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
								"Masukkan ",
								selectedIndices.length,
								" Soal ke Formulir"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 603,
								columnNumber: 37
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 596,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 588,
						columnNumber: 29
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 580,
						columnNumber: 25
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 536,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 187,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 179,
		columnNumber: 9
	}, this);
}
_s(AIGeneratorModal, "7bzzfBg8GT8sGH02Bs+NjZVKmrI=");
_c = AIGeneratorModal;
var _c;
$RefreshReg$(_c, "AIGeneratorModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/AIGeneratorModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/AIGeneratorModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/AIGeneratorModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/AIGeneratorModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsY0FBYztBQUM1QyxTQUFTLFlBQVk7QUFDckIsU0FDSSxVQUNBLEdBQ0EsU0FDQSxjQUNBLEtBQ0EsVUFDQSxPQUNBLGFBQ0EsTUFDQSxZQUNBLFdBQ0EsS0FDQSxRQUNBLGNBQ0EsYUFDQSxLQUNBLE9BQ0EsYUFDQSxXQUNBLGdCQUNHO0FBQ1AsU0FDSSx5QkFDQSwrQkFDQSxrQkFDQSx3QkFDRztBQUNQLE9BQU8seUJBQXlCOzs7O0FBRWhDLGVBQWUsU0FBUyxpQkFBaUIsRUFBRSxRQUFRLFNBQVMsZ0JBQWdCLFlBQVksTUFBTTs7Q0FDMUYsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLFFBQVE7Q0FDekMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLGFBQWEsRUFBRTtDQUNsRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxDQUFDO0NBQ3BDLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsR0FBRztDQUN4RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxRQUFRO0NBQ3JELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLGtCQUFrQjs7Q0FHckUsTUFBTSxDQUFDLFNBQVMsY0FBYyxlQUFlLGlCQUFpQixDQUFDOztDQUcvRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEVBQUU7Q0FDckQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxDQUFDO0NBQ3RELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxJQUFJO0NBQ3ZDLE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsQ0FBQyxDQUFDO0NBQy9ELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsQ0FBQyxDQUFDO0NBQ3pELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTO0VBQUUsT0FBTztFQUFJLE1BQU07Q0FBRyxDQUFDO0NBRXBFLE1BQU0sbUJBQW1CLE9BQU8sSUFBSTtDQUVwQyxnQkFBZ0I7RUFDWixJQUFJLFFBQVE7R0FDUixRQUFRLFFBQVE7R0FDaEIsU0FBUyxJQUFJO0dBQ2IsaUJBQWlCLEVBQUU7R0FDbkIsa0JBQWtCLENBQUM7R0FDbkIsTUFBTSxZQUFZLGlCQUFpQjtHQUNuQyxXQUFXLFNBQVM7R0FDcEIsSUFBSSxDQUFDLFNBQVMsV0FBVyxTQUFTLFNBQVM7RUFDL0M7Q0FDSixHQUFHLENBQUMsUUFBUSxTQUFTLENBQUM7O0NBR3RCLGdCQUFnQjtFQUNaLElBQUksWUFBWTtHQUNaLGtCQUFrQixDQUFDO0dBQ25CLGlCQUFpQixVQUFVLGtCQUFrQjtJQUN6QyxtQkFBa0IsU0FBUSxPQUFPLENBQUM7R0FDdEMsR0FBRyxHQUFJO0VBQ1gsT0FBTztHQUNILElBQUksaUJBQWlCLFNBQVMsY0FBYyxpQkFBaUIsT0FBTztFQUN4RTtFQUNBLGFBQWE7R0FDVCxJQUFJLGlCQUFpQixTQUFTLGNBQWMsaUJBQWlCLE9BQU87RUFDeEU7Q0FDSixHQUFHLENBQUMsVUFBVSxDQUFDO0NBRWYsSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixNQUFNLGlCQUFpQixPQUFPLE1BQU07RUFDaEMsSUFBSSxHQUFHLEVBQUUsZUFBZTtFQUV4QixNQUFNLGNBQWMsaUJBQWlCO0VBQ3JDLElBQUksWUFBWSxXQUFXLEdBQUc7R0FDMUIsU0FBUyxtR0FBbUc7R0FDNUc7RUFDSjtFQUVBLElBQUksQ0FBQyxNQUFNLEtBQUssS0FBSyxDQUFDLFlBQVksS0FBSyxHQUFHO0dBQ3RDLFNBQVMscURBQXFEO0dBQzlEO0VBQ0o7RUFFQSxTQUFTLElBQUk7RUFDYixjQUFjLElBQUk7RUFDbEIsaUJBQWlCLHNDQUFzQztFQUN2RCxzQkFBc0IsQ0FBQyxDQUFDO0VBQ3hCLG1CQUFtQixDQUFDLENBQUM7RUFFckIsTUFBTSw4QkFDRjtHQUNJLE9BQU8sTUFBTSxLQUFLO0dBQ2xCLGFBQWEsWUFBWSxLQUFLO0dBQzlCLE9BQU8sU0FBUyxPQUFPLEVBQUUsS0FBSztHQUM5QjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsY0FBYyxZQUFZO0VBQzlCLElBQ0MsYUFBYTs7R0FFVix1QkFBc0IsU0FBUTtJQUMxQixNQUFNLE9BQU8sQ0FBQyxHQUFHLE1BQU0sUUFBUTtJQUMvQixtQkFBbUIsS0FBSyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUM7SUFDeEMsT0FBTztHQUNYLENBQUM7R0FDRCxRQUFRLFNBQVM7RUFDckIsSUFDQyxjQUFjO0dBQ1gsaUJBQWlCLFNBQVM7RUFDOUIsSUFDQyxZQUFZO0dBQ1QsY0FBYyxLQUFLO0dBQ25CLElBQUksUUFBUSxJQUFJO0lBQ1osY0FBYztLQUFFLE9BQU8sUUFBUTtLQUFXLE1BQU0sUUFBUTtJQUFXLENBQUM7R0FDeEUsT0FBTztJQUNILElBQUksbUJBQW1CLFdBQVcsR0FBRztLQUNqQyxTQUFTLFFBQVEsV0FBVyxnRUFBZ0U7SUFDaEc7R0FDSjtFQUNKLENBQ0o7Q0FDSjtDQUVBLE1BQU0sZ0JBQWdCLFVBQVU7RUFDNUIsb0JBQW1CLFNBQ2YsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFFBQU8sTUFBSyxNQUFNLEtBQUssSUFBSSxDQUFDLEdBQUcsTUFBTSxLQUFLLENBQzFFO0NBQ0o7Q0FFQSxNQUFNLHdCQUF3QjtFQUMxQixJQUFJLGdCQUFnQixXQUFXLG1CQUFtQixRQUFRO0dBQ3RELG1CQUFtQixDQUFDLENBQUM7RUFDekIsT0FBTztHQUNILG1CQUFtQixtQkFBbUIsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0VBQzFEO0NBQ0o7Q0FFQSxNQUFNLDJCQUEyQjtFQUM3QixNQUFNLFdBQVcsbUJBQW1CLFFBQVEsR0FBRyxNQUFNLGdCQUFnQixTQUFTLENBQUMsQ0FBQztFQUNoRixJQUFJLFNBQVMsV0FBVyxHQUFHO0VBQzNCLGVBQWUsUUFBUTtFQUN2QixRQUFRO0NBQ1o7Q0FFQSxNQUFNLGFBQWE7RUFDZixHQUFHO0VBQ0gsR0FBRztFQUNILEdBQUc7RUFDSCxHQUFHO0NBQ1A7Q0FFQSxNQUFNLFdBQVcsUUFBUTtFQUNyQixJQUFJLENBQUMsT0FBTyxJQUFJLFNBQVMsR0FBRyxPQUFPO0VBQ25DLE9BQU8sR0FBRyxJQUFJLFVBQVUsR0FBRyxDQUFDLEVBQUUsS0FBSyxJQUFJLFVBQVUsSUFBSSxTQUFTLENBQUM7Q0FDbkU7Q0FFQSxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFSSx3QkFBQyxPQUFEO0dBQ0ksV0FBVTtHQUNWLFNBQVM7RUFDWjs7OztZQUdELHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFHSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztNQUNwQjs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWtGO01BRTVGOzs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE2QztNQUV2RDs7OztjQUNGOzs7O2NBQ0o7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSyxRQUFRLFNBQVMsSUFDZCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FDSSx3QkFBQyxhQUFEO1FBQWEsTUFBTTtRQUFJLFdBQVU7T0FBaUI7Ozs7aUJBQ2xELHdCQUFDLFFBQUQsYUFBTyxRQUFRLFFBQU8sZ0JBQW9COzs7O2VBQ3hDOzs7OztpQkFFTix3QkFBQyxNQUFEO09BQ0ksSUFBRztPQUNILFdBQVU7aUJBRmQsQ0FJSSx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7O2lCQUNoQix3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O2VBQzdCOzs7OztnQkFFVix3QkFBQyxVQUFEO09BQ0ksTUFBSztPQUNMLFNBQVM7T0FDVCxXQUFVO2lCQUVWLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O01BQ1Y7Ozs7Y0FDUDs7Ozs7YUFDSjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNLLFFBQVEsV0FBVyxLQUNoQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsS0FBRDtTQUFLLE1BQU07U0FBSSxXQUFVO1FBQTJCOzs7O2tCQUNwRCx3QkFBQyxRQUFELFlBQU0sK0VBQWtGOzs7O2dCQUN2Rjs7Ozs7aUJBQ0wsd0JBQUMsTUFBRDtRQUNJLElBQUc7UUFDSCxXQUFVO2tCQUZkLENBR0Msb0JBQ21CLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7Z0JBQ3ZDOzs7OztlQUNMOzs7Ozs7TUFHUixTQUNHLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsYUFBRDtRQUFhLE1BQU07UUFBSSxXQUFVO09BQW1COzs7O2lCQUNwRCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFZO1FBQVk7Ozs7a0JBQ3JDLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFVO1FBQVM7Ozs7Z0JBQy9COzs7OztlQUNKOzs7Ozs7TUFHUixTQUFTLFdBQ04sd0JBQUMsUUFBRDtPQUFNLFVBQVU7T0FBZ0IsV0FBVTtpQkFBMUM7UUFHSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQjtXQUNJLHdCQUFDLFVBQUQ7WUFBVSxNQUFNO1lBQUksV0FBVTtXQUFpQjs7Ozs7V0FBQztXQUM1Qix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBZTtXQUFPOzs7OztVQUN2RDs7Ozs7bUJBQ1Asd0JBQUMsU0FBRDtVQUNJLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7VUFDeEMsYUFBWTtVQUNaLFdBQVU7VUFDVjtVQUNBLFVBQVU7U0FDYjs7OztpQkFDQTs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFHSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUF1RDtXQUVqRTs7OztxQkFDUCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDVjthQUFDO2FBQUc7YUFBRzthQUFJO1lBQUUsQ0FBQyxDQUFDLEtBQUksUUFDaEIsd0JBQUMsVUFBRDthQUVJLE1BQUs7YUFDTCxVQUFVO2FBQ1YsZUFBZSxTQUFTLEdBQUc7YUFDM0IsV0FBVyw0RUFDUCxVQUFVLE1BQ0osMkVBQ0E7dUJBR1Q7WUFDRyxHQVhDOzs7O21CQVdELENBQ1g7V0FDQTs7OzttQkFDSjs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBdUQ7V0FFakU7Ozs7cUJBQ1Asd0JBQUMsVUFBRDtZQUNJLE9BQU87WUFDUCxXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1lBQ2pELFVBQVU7WUFDVixXQUFVO3NCQUpkO2FBTUksd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQUk7YUFBa0M7Ozs7O2FBQ3BELHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUFJO2FBQTZCOzs7OzthQUMvQyx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBSTthQUFrQzs7Ozs7YUFDcEQsd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQUk7YUFBa0M7Ozs7O2FBQ3BELHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUFRO2FBQTZCOzs7OztZQUMvQzs7Ozs7bUJBQ1A7Ozs7OztVQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXVEO1dBRWpFOzs7O3FCQUNQLHdCQUFDLFVBQUQ7WUFDSSxPQUFPO1lBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7WUFDN0MsVUFBVTtZQUNWLFdBQVU7c0JBSmQ7YUFNSSx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBUTthQUFxQjs7Ozs7YUFDM0Msd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQVM7YUFBd0I7Ozs7O2FBQy9DLHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUFlO2FBQWdDOzs7OztZQUN6RDs7Ozs7bUJBQ1A7Ozs7OztTQUNKOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUNJLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUNJLHdCQUFDLEtBQUQ7WUFBSyxNQUFNO1lBQUksV0FBVTtXQUFpQjs7OztxQkFBQyxzQkFDekM7Ozs7O29CQUNOLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE2QjtVQUEyQjs7OztrQkFDckU7Ozs7O21CQUNQLHdCQUFDLFVBQUQ7VUFDSSxPQUFPO1VBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztVQUNoRCxVQUFVO1VBQ1YsV0FBVTtvQkFFVCxpQkFBaUIsS0FBSSxNQUNsQix3QkFBQyxVQUFEO1dBQW1CLE9BQU8sRUFBRTtxQkFBNUI7WUFDSyxFQUFFO1lBQUs7WUFBSSxFQUFFO1dBQ1Y7YUFGSyxFQUFFOzs7O2lCQUVQLENBQ1g7U0FDRzs7OztpQkFDUDs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxVQUFEO1VBQ0ksTUFBSztVQUNMLGVBQWUsZ0JBQWdCLENBQUMsWUFBWTtVQUM1QyxXQUFVO29CQUhkO1dBS0ksd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7V0FDckIsd0JBQUMsUUFBRCxZQUFPLGVBQWUsd0JBQXdCLG9EQUEwRDs7Ozs7V0FDdkcsZUFBZSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O3NCQUFJLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O1VBQzlEOzs7OzttQkFFUCxnQkFDRyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXVEO1dBRWpFOzs7O3FCQUNQLHdCQUFDLFlBQUQ7WUFDSSxPQUFPO1lBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7WUFDOUMsTUFBTTtZQUNOLFVBQVU7WUFDVixhQUFZO1lBQ1osV0FBVTtXQUNiOzs7O21CQUNBOzs7OztvQkFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUFqQixDQUNJLHdCQUFDLFNBQUQ7YUFDSSxNQUFLO2FBQ0wsU0FBUzthQUNULFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxPQUFPO2FBQ2hELFVBQVU7YUFDVixXQUFVO1lBQ2I7Ozs7c0JBQ0Qsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQ0ksd0JBQUMsWUFBRDtjQUFZLE1BQU07Y0FBSSxXQUFVO2FBQWtCOzs7O3VCQUFDLDJCQUNqRDs7Ozs7b0JBQ0g7Ozs7O3FCQUNQLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUFqQixDQUNJLHdCQUFDLFNBQUQ7YUFDSSxNQUFLO2FBQ0wsU0FBUzthQUNULFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxPQUFPO2FBQ2hELFVBQVU7YUFDVixXQUFVO1lBQ2I7Ozs7c0JBQ0Qsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQ0ksd0JBQUMsTUFBRDtjQUFNLE1BQU07Y0FBSSxXQUFVO2FBQWdCOzs7O3VCQUFDLG1CQUN6Qzs7Ozs7b0JBQ0g7Ozs7O21CQUNOOzs7OztrQkFDSjs7Ozs7aUJBRVI7Ozs7OztRQUdKLGNBQ0csd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxTQUFEO1VBQVMsTUFBTTtVQUFJLFdBQVU7U0FBMkQ7Ozs7bUJBQ3hGLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1IsaUJBQWlCO1VBQ25COzs7O29CQUNILHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiO1lBQ0ksd0JBQUMsUUFBRCxhQUFNLFdBQU8sd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWlCO1lBQWlCOzs7O29CQUFPOzs7OztZQUNuRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7WUFDYix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FDSSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztjQUFDO2NBQUU7Y0FBZTthQUNsQzs7Ozs7O1dBQ1A7Ozs7O2tCQUNGOzs7OztpQkFDSjs7Ozs7O09BR1A7Ozs7Ozs7QUFHTix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEI7V0FBdUU7V0FDaEUsbUJBQW1CO1dBQU87VUFDM0I7Ozs7O21CQUNOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUNLLFdBQVc7V0FBSztXQUFVLFdBQVc7VUFDcEM7Ozs7O2lCQUNMOzs7OztrQkFDTCx3QkFBQyxVQUFEO1NBQ0ksTUFBSztTQUNMLFNBQVM7U0FDVCxXQUFVO21CQUVULGdCQUFnQixXQUFXLG1CQUFtQixTQUFTLHNCQUFzQjtRQUMxRTs7OztnQkFDUDs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1YsbUJBQW1CLEtBQUssR0FBRyxRQUFRO1NBQ2hDLE1BQU0sYUFBYSxnQkFBZ0IsU0FBUyxHQUFHO1NBQy9DLE9BQ0ksd0JBQUMsT0FBRDtVQUVJLGVBQWUsYUFBYSxHQUFHO1VBQy9CLFdBQVcsd0RBQ1AsYUFDTSxzR0FDQTtvQkFHVix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFNBQUQ7WUFDSSxNQUFLO1lBQ0wsU0FBUztZQUNULGdCQUFnQixhQUFhLEdBQUc7WUFDaEMsVUFBVSxNQUFNLEVBQUUsZ0JBQWdCO1lBQ2xDLFdBQVU7V0FDYjs7OztxQkFDRCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNJLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQWhCLENBQXNJLFVBQzNILE1BQU0sQ0FDWDs7Ozs7d0JBQ04sd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQ1gsV0FBVyxFQUFFLFdBQVc7Y0FDdkI7Ozs7c0JBQ0w7Ozs7OzthQUVMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUNYLHdCQUFDLHFCQUFELEVBQXFCLFNBQVMsRUFBRSxTQUFXOzs7OzthQUMxQzs7Ozs7YUFHSixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLE1BQU0sS0FBSyxFQUFFLFNBQVMsU0FBUyxLQUM5Qyx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFDVixFQUFFLFFBQVEsS0FBSyxLQUFLLFNBQ2pCLHdCQUFDLE9BQUQ7ZUFFSSxXQUFXLDBEQUNQLElBQUksWUFDRSw0SUFDQTt5QkFMZDtnQkFRSSx3QkFBQyxRQUFEO2lCQUFNLFdBQVU7MkJBQ1gsT0FBTyxhQUFhLEtBQUssSUFBSTtnQkFDNUI7Ozs7O2dCQUNOLHdCQUFDLFFBQUQ7aUJBQU0sV0FBVTsyQkFBbUIsSUFBSTtnQkFBaUI7Ozs7O2dCQUN2RCxJQUFJLGFBQWEsd0JBQUMsT0FBRDtpQkFBTyxNQUFNO2lCQUFJLFdBQVU7Z0JBQTZCOzs7OztlQUN6RTtpQkFaSTs7OztxQkFZSixDQUNSO2FBQ0E7Ozs7O2FBR1IsRUFBRSxXQUFXLEtBQ1Ysd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FBaUUsbUJBQzlDLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUE4QyxFQUFFLGlCQUFpQjtjQUFjOzs7O3NCQUM3Rzs7Ozs7O1lBRVI7Ozs7O21CQUNKOzs7Ozs7U0FDSixHQTNESTs7OztnQkEyREo7UUFFYixDQUFDO09BQ0E7Ozs7ZUFDSjs7Ozs7O0tBR1I7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1YsU0FBUyxXQUNOLGdEQUNJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNWLFFBQVEsU0FBUyxJQUNkLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQjtRQUNJLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O1FBQUM7UUFBRSxRQUFRO1FBQU87T0FDekM7Ozs7O2lCQUVOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUErQztNQUV6RDs7Ozs7S0FFVDs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsVUFBRDtPQUNJLE1BQUs7T0FDTCxTQUFTO09BQ1QsVUFBVTtPQUNWLFdBQVU7aUJBQ2I7TUFFTzs7OztnQkFDUix3QkFBQyxVQUFEO09BQ0ksTUFBSztPQUNMLFNBQVM7T0FDVCxVQUFVLGNBQWUsQ0FBQyxNQUFNLEtBQUssS0FBSyxDQUFDLFlBQVksS0FBSztPQUM1RCxXQUFVO2lCQUVULGFBQ0csZ0RBQ0ksd0JBQUMsU0FBRDtRQUFTLE1BQU07UUFBSSxXQUFVO09BQWdCOzs7O2lCQUM3Qyx3QkFBQyxRQUFEO1FBQU07UUFBaUI7UUFBZTtPQUFXOzs7O2VBQ25EOzs7O2tCQUVGLGdEQUNJLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7aUJBQ3JCLHdCQUFDLFFBQUQ7UUFBTTtRQUFNO1FBQU07T0FBb0I7Ozs7ZUFDeEM7Ozs7O01BRUY7Ozs7Y0FDUDs7Ozs7YUFDUDs7OztnQkFFRixnREFDSSx3QkFBQyxVQUFEO01BQ0ksTUFBSztNQUNMLGVBQWUsUUFBUSxRQUFRO01BQy9CLFdBQVU7Z0JBSGQsQ0FLSSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O2dCQUFDLGFBQ25COzs7OztlQUNSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsVUFBRDtPQUNJLE1BQUs7T0FDTCxTQUFTO09BQ1QsV0FBVTtpQkFDYjtNQUVPOzs7O2dCQUNSLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsU0FBUztPQUNULFVBQVUsZ0JBQWdCLFdBQVc7T0FDckMsV0FBVTtpQkFKZCxDQU1JLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7aUJBQ3pCLHdCQUFDLFFBQUQ7UUFBTTtRQUFVLGdCQUFnQjtRQUFPO09BQXVCOzs7O2VBQzFEOzs7OztjQUNQOzs7OzthQUNQOzs7OztJQUVMOzs7OztHQUVKOzs7OztVQUNKOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBSUdlbmVyYXRvck1vZGFsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQge1xuICAgIFNwYXJrbGVzLFxuICAgIFgsXG4gICAgTG9hZGVyMixcbiAgICBDaGVja0NpcmNsZTIsXG4gICAgS2V5LFxuICAgIEJvb2tPcGVuLFxuICAgIENoZWNrLFxuICAgIEFsZXJ0Q2lyY2xlLFxuICAgIENvZGUsXG4gICAgQ2FsY3VsYXRvcixcbiAgICBSb3RhdGVDY3csXG4gICAgRXllLFxuICAgIEV5ZU9mZixcbiAgICBFeHRlcm5hbExpbmssXG4gICAgU2hpZWxkQ2hlY2ssXG4gICAgQ3B1LFxuICAgIENsb2NrLFxuICAgIENoZXZyb25Eb3duLFxuICAgIENoZXZyb25VcCxcbiAgICBGaWxlVGV4dFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHtcbiAgICBnZW5lcmF0ZVF1ZXN0aW9uc1dpdGhBSSxcbiAgICBzdHJlYW1HZW5lcmF0ZVF1ZXN0aW9uc1dpdGhBSSxcbiAgICBnZXRHZW1pbmlBcGlLZXlzLFxuICAgIEFWQUlMQUJMRV9NT0RFTFNcbn0gZnJvbSAnLi4vLi4vc2VydmljZXMvYWlTZXJ2aWNlJztcbmltcG9ydCBSaWNoQ29udGVudFJlbmRlcmVyIGZyb20gJy4uLy4uL3V0aWxzL1JpY2hDb250ZW50UmVuZGVyZXInO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBSUdlbmVyYXRvck1vZGFsKHsgaXNPcGVuLCBvbkNsb3NlLCBvbkFkZFF1ZXN0aW9ucywgZm9ybVRpdGxlID0gJycgfSkge1xuICAgIGNvbnN0IFtzdGVwLCBzZXRTdGVwXSA9IHVzZVN0YXRlKCdjb25maWcnKTsgLy8gJ2NvbmZpZycgfCAncHJldmlldydcbiAgICBjb25zdCBbdG9waWMsIHNldFRvcGljXSA9IHVzZVN0YXRlKGZvcm1UaXRsZSB8fCAnJyk7XG4gICAgY29uc3QgW2NvbnRleHRUZXh0LCBzZXRDb250ZXh0VGV4dF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZSg1KTtcbiAgICBjb25zdCBbdHlwZVByZWZlcmVuY2UsIHNldFR5cGVQcmVmZXJlbmNlXSA9IHVzZVN0YXRlKCcyJyk7IC8vICcyJyA9IE1DUSwgJzEnID0gRXNzYXksICc1JyA9IFQvRiwgJzMnID0gQ2hlY2tib3gsICdtaXhlZCcgPSBNaXhlZFxuICAgIGNvbnN0IFtkaWZmaWN1bHR5LCBzZXREaWZmaWN1bHR5XSA9IHVzZVN0YXRlKCdTZWRhbmcnKTtcbiAgICBjb25zdCBbaW5jbHVkZU1hdGgsIHNldEluY2x1ZGVNYXRoXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbaW5jbHVkZUNvZGUsIHNldEluY2x1ZGVDb2RlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbc2hvd0FkdmFuY2VkLCBzZXRTaG93QWR2YW5jZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtzZWxlY3RlZE1vZGVsLCBzZXRTZWxlY3RlZE1vZGVsXSA9IHVzZVN0YXRlKCdnZW1pbmktMy42LWZsYXNoJyk7XG5cbiAgICAvLyBHbG9iYWwgU3RhY2tlZCBBUEkgS2V5cyAoQ29uZmlndXJlZCBpbiBBSSBBc3Npc3RhbnQpXG4gICAgY29uc3QgW2FwaUtleXMsIHNldEFwaUtleXNdID0gdXNlU3RhdGUoKCkgPT4gZ2V0R2VtaW5pQXBpS2V5cygpKTtcblxuICAgIC8vIEdlbmVyYXRpb24gc3RhdGUgJiBGcmllbmRseSBzdGF0dXNcbiAgICBjb25zdCBbZ2VuZXJhdGluZywgc2V0R2VuZXJhdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3N0YXR1c01lc3NhZ2UsIHNldFN0YXR1c01lc3NhZ2VdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtlbGFwc2VkU2Vjb25kcywgc2V0RWxhcHNlZFNlY29uZHNdID0gdXNlU3RhdGUoMCk7XG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbZ2VuZXJhdGVkUXVlc3Rpb25zLCBzZXRHZW5lcmF0ZWRRdWVzdGlvbnNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtzZWxlY3RlZEluZGljZXMsIHNldFNlbGVjdGVkSW5kaWNlc10gPSB1c2VTdGF0ZShbXSk7XG4gICAgY29uc3QgW3Jlc3VsdEluZm8sIHNldFJlc3VsdEluZm9dID0gdXNlU3RhdGUoeyBtb2RlbDogJycsIHRpbWU6ICcnIH0pO1xuXG4gICAgY29uc3QgdGltZXJJbnRlcnZhbFJlZiA9IHVzZVJlZihudWxsKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpc09wZW4pIHtcbiAgICAgICAgICAgIHNldFN0ZXAoJ2NvbmZpZycpO1xuICAgICAgICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICAgICAgICBzZXRTdGF0dXNNZXNzYWdlKCcnKTtcbiAgICAgICAgICAgIHNldEVsYXBzZWRTZWNvbmRzKDApO1xuICAgICAgICAgICAgY29uc3Qgc2F2ZWRLZXlzID0gZ2V0R2VtaW5pQXBpS2V5cygpO1xuICAgICAgICAgICAgc2V0QXBpS2V5cyhzYXZlZEtleXMpO1xuICAgICAgICAgICAgaWYgKCF0b3BpYyAmJiBmb3JtVGl0bGUpIHNldFRvcGljKGZvcm1UaXRsZSk7XG4gICAgICAgIH1cbiAgICB9LCBbaXNPcGVuLCBmb3JtVGl0bGVdKTtcblxuICAgIC8vIFRpbWVyIGNvdW50ZXIgd2hlbiBnZW5lcmF0aW5nXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGdlbmVyYXRpbmcpIHtcbiAgICAgICAgICAgIHNldEVsYXBzZWRTZWNvbmRzKDApO1xuICAgICAgICAgICAgdGltZXJJbnRlcnZhbFJlZi5jdXJyZW50ID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldEVsYXBzZWRTZWNvbmRzKHByZXYgPT4gcHJldiArIDEpO1xuICAgICAgICAgICAgfSwgMTAwMCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAodGltZXJJbnRlcnZhbFJlZi5jdXJyZW50KSBjbGVhckludGVydmFsKHRpbWVySW50ZXJ2YWxSZWYuY3VycmVudCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGlmICh0aW1lckludGVydmFsUmVmLmN1cnJlbnQpIGNsZWFySW50ZXJ2YWwodGltZXJJbnRlcnZhbFJlZi5jdXJyZW50KTtcbiAgICAgICAgfTtcbiAgICB9LCBbZ2VuZXJhdGluZ10pO1xuXG4gICAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgaGFuZGxlR2VuZXJhdGUgPSBhc3luYyAoZSkgPT4ge1xuICAgICAgICBpZiAoZSkgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBcbiAgICAgICAgY29uc3QgY3VycmVudEtleXMgPSBnZXRHZW1pbmlBcGlLZXlzKCk7XG4gICAgICAgIGlmIChjdXJyZW50S2V5cy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHNldEVycm9yKCdBUEkgS2V5IEdlbWluaSBiZWx1bSBkaWF0dXIuIFNpbGFrYW4gdGFtYmFoa2FuIEFQSSBLZXkgZGkgbWVudSBBSSBBc3Npc3RhbnQgQ2hhdCB0ZXJsZWJpaCBkYWh1bHUuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXRvcGljLnRyaW0oKSAmJiAhY29udGV4dFRleHQudHJpbSgpKSB7XG4gICAgICAgICAgICBzZXRFcnJvcignSGFyYXAgbWFzdWtrYW4gdG9waWsvbWF0ZXJpIHNvYWwgeWFuZyBpbmdpbiBkaWJ1YXQuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRFcnJvcihudWxsKTtcbiAgICAgICAgc2V0R2VuZXJhdGluZyh0cnVlKTtcbiAgICAgICAgc2V0U3RhdHVzTWVzc2FnZSgnTWVuZ2h1YnVuZ2thbiBrZSBHb29nbGUgQUkgU3R1ZGlvLi4uJyk7XG4gICAgICAgIHNldEdlbmVyYXRlZFF1ZXN0aW9ucyhbXSk7XG4gICAgICAgIHNldFNlbGVjdGVkSW5kaWNlcyhbXSk7XG5cbiAgICAgICAgYXdhaXQgc3RyZWFtR2VuZXJhdGVRdWVzdGlvbnNXaXRoQUkoXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdG9waWM6IHRvcGljLnRyaW0oKSxcbiAgICAgICAgICAgICAgICBjb250ZXh0VGV4dDogY29udGV4dFRleHQudHJpbSgpLFxuICAgICAgICAgICAgICAgIGNvdW50OiBwYXJzZUludChjb3VudCwgMTApIHx8IDUsXG4gICAgICAgICAgICAgICAgdHlwZVByZWZlcmVuY2UsXG4gICAgICAgICAgICAgICAgZGlmZmljdWx0eSxcbiAgICAgICAgICAgICAgICBpbmNsdWRlTWF0aCxcbiAgICAgICAgICAgICAgICBpbmNsdWRlQ29kZSxcbiAgICAgICAgICAgICAgICBzZWxlY3RlZE1vZGVsLFxuICAgICAgICAgICAgICAgIGN1c3RvbUFwaUtleTogY3VycmVudEtleXNbMF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgKHF1ZXN0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gQjk6IExpdmUgc3RyZWFtIHF1ZXN0aW9uIGludG8gcHJldmlldyBsaXN0XG4gICAgICAgICAgICAgICAgc2V0R2VuZXJhdGVkUXVlc3Rpb25zKHByZXYgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXh0ID0gWy4uLnByZXYsIHF1ZXN0aW9uXTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJbmRpY2VzKG5leHQubWFwKChfLCBpKSA9PiBpKSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXh0O1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHNldFN0ZXAoJ3ByZXZpZXcnKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAoc3RhdHVzTXNnKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0U3RhdHVzTWVzc2FnZShzdGF0dXNNc2cpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIChkb25lUmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0R2VuZXJhdGluZyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgaWYgKGRvbmVSZXMub2spIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0UmVzdWx0SW5mbyh7IG1vZGVsOiBkb25lUmVzLm1vZGVsVXNlZCwgdGltZTogZG9uZVJlcy5lbGFwc2VkU2VjIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChnZW5lcmF0ZWRRdWVzdGlvbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcihkb25lUmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbWJ1YXQgc29hbC4gUGVyaWtzYSBrZW1iYWxpIGtvbmVrc2kgYXRhdSBBUEkgS2V5IEFuZGEuJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIGNvbnN0IHRvZ2dsZVNlbGVjdCA9IChpbmRleCkgPT4ge1xuICAgICAgICBzZXRTZWxlY3RlZEluZGljZXMocHJldiA9PlxuICAgICAgICAgICAgcHJldi5pbmNsdWRlcyhpbmRleCkgPyBwcmV2LmZpbHRlcihpID0+IGkgIT09IGluZGV4KSA6IFsuLi5wcmV2LCBpbmRleF1cbiAgICAgICAgKTtcbiAgICB9O1xuXG4gICAgY29uc3QgdG9nZ2xlU2VsZWN0QWxsID0gKCkgPT4ge1xuICAgICAgICBpZiAoc2VsZWN0ZWRJbmRpY2VzLmxlbmd0aCA9PT0gZ2VuZXJhdGVkUXVlc3Rpb25zLmxlbmd0aCkge1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWRJbmRpY2VzKFtdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkSW5kaWNlcyhnZW5lcmF0ZWRRdWVzdGlvbnMubWFwKChfLCBpKSA9PiBpKSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlSW1wb3J0VG9Gb3JtID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBzZWxlY3RlZCA9IGdlbmVyYXRlZFF1ZXN0aW9ucy5maWx0ZXIoKF8sIGkpID0+IHNlbGVjdGVkSW5kaWNlcy5pbmNsdWRlcyhpKSk7XG4gICAgICAgIGlmIChzZWxlY3RlZC5sZW5ndGggPT09IDApIHJldHVybjtcbiAgICAgICAgb25BZGRRdWVzdGlvbnMoc2VsZWN0ZWQpO1xuICAgICAgICBvbkNsb3NlKCk7XG4gICAgfTtcblxuICAgIGNvbnN0IHR5cGVMYWJlbHMgPSB7XG4gICAgICAgIDE6ICdJc2lhbiBTaW5na2F0IC8gRXNzYXknLFxuICAgICAgICAyOiAnUGlsaWhhbiBHYW5kYScsXG4gICAgICAgIDM6ICdQaWxpaGFuIE1hamVtdWsgKENoZWNrYm94KScsXG4gICAgICAgIDU6ICdCZW5hciAvIFNhbGFoJ1xuICAgIH07XG5cbiAgICBjb25zdCBtYXNrS2V5ID0gKGtleSkgPT4ge1xuICAgICAgICBpZiAoIWtleSB8fCBrZXkubGVuZ3RoIDwgOCkgcmV0dXJuICcqKioqJztcbiAgICAgICAgcmV0dXJuIGAke2tleS5zdWJzdHJpbmcoMCwgNil9Li4uJHtrZXkuc3Vic3RyaW5nKGtleS5sZW5ndGggLSA0KX1gO1xuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICAgIHsvKiBCYWNrZHJvcCAqL31cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLXNsYXRlLTkwMC82MCBkYXJrOmJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXIteHMgdHJhbnNpdGlvbi1vcGFjaXR5XCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgey8qIE1vZGFsIERpYWxvZyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHctZnVsbCBtYXgtdy0yeGwgc2hhZG93LTJ4bCBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBtYXgtaC1bOTB2aF0gei0xMFwiPlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgU2VkZXJoYW5hICYgUmFtYWggKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJnLWdyYWRpZW50LXRvLXIgZnJvbS10ZWFsLTUwMC8xMCB2aWEtZW1lcmFsZC01MDAvNSB0by10cmFuc3BhcmVudFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLTJ4bCBiZy1bIzAwODk3Ql0gdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbWQgc2hhZG93LXRlYWwtNTAwLzIwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJ1YXQgU29hbCBPdG9tYXRpcyBkZW5nYW4gQUlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYW50dSBndXJ1ICYgc2lzd2EgbWVtYnVhdCBidXRpciBzb2FsIGt1aXMgc2VjYXJhIGluc3RhbiBkYW4gcmFwaS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FwaUtleXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIHNpemU9ezEzfSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2FwaUtleXMubGVuZ3RofSBBUEkgS2V5IEFrdGlmPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvYWktY2hhdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMSBiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC82MCB0ZXh0LWFtYmVyLTcwMCBkYXJrOnRleHQtYW1iZXItMzAwIGhvdmVyOmJnLWFtYmVyLTEwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGJvcmRlciBib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8S2V5IHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BdHVyIEtleSBkaSBBSSBDaGF0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQm9keSBDb250ZW50ICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBwLTYgc3BhY2UteS01XCI+XG4gICAgICAgICAgICAgICAgICAgIHthcGlLZXlzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzUwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1hbWJlci04MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8S2V5IHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTYwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkFQSSBLZXkgR2VtaW5pIGJlbHVtIGRpYXR1ci4gU2lsYWthbiBhdHVyIEFQSSBLZXkgZGkgbWVudSBBSSBBc3Npc3RhbnQgQ2hhdC48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvYWktY2hhdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHRleHQtd2hpdGUgcm91bmRlZC14bCBmb250LWJvbGQgc2hyaW5rLTAgdHJhbnNpdGlvbi1jb2xvcnMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEF0dXIgZGkgQUkgQ2hhdCA8RXh0ZXJuYWxMaW5rIHNpemU9ezEyfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC82MCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTkwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yLjUgdGV4dC14cyB0ZXh0LXJlZC03MDAgZGFyazp0ZXh0LXJlZC0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+UGVyaGF0aWFuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0wLjVcIj57ZXJyb3J9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAge3N0ZXAgPT09ICdjb25maWcnID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUdlbmVyYXRlfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVG9waWsgLyBNYXRlcmkgU29hbCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJvb2tPcGVuIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1hdGVyaSAvIFRvcGlrIFNvYWwgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dG9waWN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRvcGljKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ29udG9oOiBGb3Rvc2ludGVzaXMsIEh1a3VtIE5ld3RvbiwgVGF0YSBTdXJ5YSwgUGVtcm9ncmFtYW4gV2ViIERhc2FyLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtMnhsIHRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXSBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2dlbmVyYXRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUGVuZ2F0dXJhbiBVdGFtYTogSnVtbGFoIFNvYWwsIEJlbnR1ayBTb2FsLCBLZXN1bGl0YW4gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogSnVtbGFoIFNvYWwgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSnVtbGFoIFNvYWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBwLTEgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7WzMsIDUsIDEwLCAxNV0ubWFwKG51bSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17bnVtfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENvdW50KG51bSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcHktMS41IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3VudCA9PT0gbnVtXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIGRhcms6Ymctc2xhdGUtNzAwIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTMwMCBzaGFkb3cteHMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEJlbnR1ayBTb2FsICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJlbnR1ayBTb2FsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0eXBlUHJlZmVyZW5jZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFR5cGVQcmVmZXJlbmNlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjJcIj5QaWxpaGFuIEdhbmRhIChBLCBCLCBDLCBEKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIxXCI+SXNpYW4gU2luZ2thdCAvIEVzc2F5PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjVcIj5CZW5hciAvIFNhbGFoIChUcnVlL0ZhbHNlKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIzXCI+UGlsaWhhbiBNYWplbXVrIChDaGVja2JveCk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibWl4ZWRcIj5DYW1wdXJhbiAoQmVydmFyaWFzaSk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVGluZ2thdCBLZXN1bGl0YW4gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGluZ2thdCBLZXN1bGl0YW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RpZmZpY3VsdHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREaWZmaWN1bHR5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk11ZGFoXCI+TXVkYWggKERhc2FyKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTZWRhbmdcIj5TZWRhbmcgKFN0YW5kYXIpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlN1bGl0IChIT1RTKVwiPlN1bGl0IChQZW5hbGFyYW4gLyBIT1RTKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBpbGloYW4gTW9kZWwgQUkgR29vZ2xlIFN0dWRpbyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41IHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENwdSBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMFwiIC8+IE1vZGVsIEdvb2dsZSBHZW1pbmlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+RGFyaSBHb29nbGUgQUkgU3R1ZGlvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNb2RlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRNb2RlbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMi41IGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtBVkFJTEFCTEVfTU9ERUxTLm1hcChtID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bS5pZH0gdmFsdWU9e20uaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS5uYW1lfSDigJQge20uZGVzY31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBPcHNpIFRhbWJhaGFuIC8gUmVmZXJlbnNpIFRla3MgKENvbGxhcHNpYmxlKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWR2YW5jZWQoIXNob3dBZHZhbmNlZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTQwMCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57c2hvd0FkdmFuY2VkID8gJ1R1dHVwIE9wc2kgVGFtYmFoYW4nIDogJ1RhbWJhaCBDYXRhdGFuIC8gVGVrcyBNYXRlcmkgUmVmZXJlbnNpIChPcHNpb25hbCknfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93QWR2YW5jZWQgPyA8Q2hldnJvblVwIHNpemU9ezE0fSAvPiA6IDxDaGV2cm9uRG93biBzaXplPXsxNH0gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93QWR2YW5jZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHNwYWNlLXktMyBwLTMuNSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVtcGVsIFRla3MgLyBSYW5na3VtYW4gQnVrdTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29udGV4dFRleHR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbnRleHRUZXh0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2VuZXJhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVGVtcGVsa2FuIHRla3MgbW9kdWwgYXRhdSByYW5na3VtYW4gZGkgc2luaSBhZ2FyIHNvYWwgZGlidWF0IHBlcnNpcyBkYXJpIG1hdGVyaSBpbmkuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTQgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2luY2x1ZGVNYXRofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW5jbHVkZU1hdGgoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2dlbmVyYXRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCByb3VuZGVkIHRleHQtdGVhbC02MDAgZm9jdXM6cmluZy10ZWFsLTUwMCBib3JkZXItc2xhdGUtMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYWxjdWxhdG9yIHNpemU9ezEzfSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTUwMFwiIC8+IFJ1bXVzIE1hdGVtYXRpa2EgKExhVGVYKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2luY2x1ZGVDb2RlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW5jbHVkZUNvZGUoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2dlbmVyYXRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCByb3VuZGVkIHRleHQtdGVhbC02MDAgZm9jdXM6cmluZy10ZWFsLTUwMCBib3JkZXItc2xhdGUtMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDb2RlIHNpemU9ezEzfSBjbGFzc05hbWU9XCJ0ZXh0LXNreS01MDBcIiAvPiBLb2RlIFBlbXJvZ3JhbWFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBMb2FkaW5nIFN0YXR1cyBTZWRlcmhhbmEgJiBKZWxhcyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2VuZXJhdGluZyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC81MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwLzgwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zLjUgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsyNH0gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWV4dHJhYm9sZCB0ZXh0LXRlYWwtOTAwIGRhcms6dGV4dC10ZWFsLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzTWVzc2FnZSB8fCAnU2VkYW5nIG1lbWJ1YXQgc29hbC4uLid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwIG10LTAuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Nb2RlbDogPGIgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPntzZWxlY3RlZE1vZGVsfTwvYj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKAojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDbG9jayBzaXplPXsxMX0gLz4ge2VsYXBzZWRTZWNvbmRzfSBkZXRpa1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIC8qIFByZXZpZXcgU29hbCB5YW5nIERpYnVhdCAqL1xuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDinKgge2dlbmVyYXRlZFF1ZXN0aW9ucy5sZW5ndGh9IFNvYWwgQmVyaGFzaWwgRGlidWF0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC0xMDAgZGFyazpiZy1lbWVyYWxkLTk1MCB0ZXh0LWVtZXJhbGQtODAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0SW5mby50aW1lfSBkZXRpayDigKIge3Jlc3VsdEluZm8ubW9kZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVNlbGVjdEFsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC00MDAgZm9udC1ib2xkIGhvdmVyOnVuZGVybGluZSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEluZGljZXMubGVuZ3RoID09PSBnZW5lcmF0ZWRRdWVzdGlvbnMubGVuZ3RoID8gJ0JhdGFsIFBpbGloIFNlbXVhJyA6ICdQaWxpaCBTZW11YSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgbWF4LWgtWzUwdmhdIG92ZXJmbG93LXktYXV0byBwci0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZW5lcmF0ZWRRdWVzdGlvbnMubWFwKChxLCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBzZWxlY3RlZEluZGljZXMuaW5jbHVkZXMoaWR4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2VsZWN0KGlkeCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXItdGVhbC01MDAgZGFyazpib3JkZXItdGVhbC00MDAgc2hhZG93LXNtIHJpbmctMSByaW5nLXRlYWwtNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIG9wYWNpdHktNjAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHRvZ2dsZVNlbGVjdChpZHgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgbXQtMSByb3VuZGVkIHRleHQtdGVhbC02MDAgZm9jdXM6cmluZy10ZWFsLTUwMCBib3JkZXItc2xhdGUtMzAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm9tb3Ige2lkeCArIDF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0eXBlTGFiZWxzW3EudHlwZUlkXSB8fCAnUGlsaWhhbiBHYW5kYSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e3EucXVlc3Rpb259IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUGlsaWhhbiBKYXdhYmFuICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtbMiwgM10uaW5jbHVkZXMocS50eXBlSWQpICYmIHEub3B0aW9ucz8ubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMS41IHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtxLm9wdGlvbnMubWFwKChvcHQsIG9JZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17b0lkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHQuaXNDb3JyZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIHRleHQtZW1lcmFsZC04MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwIGZvbnQtYm9sZCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMzAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNocmluay0wIHctNCBoLTQgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1N0cmluZy5mcm9tQ2hhckNvZGUoNjUgKyBvSWR4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBmbGV4LTFcIj57b3B0Lm9wdGlvblRleHR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0LmlzQ29ycmVjdCAmJiA8Q2hlY2sgc2l6ZT17MTJ9IGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDAgc2hyaW5rLTBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EudHlwZUlkID09PSA1ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgS3VuY2kgSmF3YWJhbjogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwXCI+e3EuY29ycmVjdEFuc3dlciB8fCAnQmVuYXInfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBGb290ZXIgVG9tYm9sIEFrc2kgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIHtzdGVwID09PSAnY29uZmlnJyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FwaUtleXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxM30gLz4ge2FwaUtleXMubGVuZ3RofSBBUEkgS2V5IEFrdGlmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTcwMCBkYXJrOnRleHQtYW1iZXItMzAwIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKaoO+4jyBIYXJhcCBhdHVyIEFQSSBLZXkgZGkgQ2hhdCBBSVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2dlbmVyYXRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYXRhbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVHZW5lcmF0ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtnZW5lcmF0aW5nIHx8ICghdG9waWMudHJpbSgpICYmICFjb250ZXh0VGV4dC50cmltKCkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LW1kIHNoYWRvdy10ZWFsLTUwMC8yMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTYwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZW5lcmF0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIHNpemU9ezE1fSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TZWRhbmcgTWVtYnVhdCAoe2VsYXBzZWRTZWNvbmRzfXMpLi4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkJ1YXQge2NvdW50fSBTb2FsIFNla2FyYW5nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RlcCgnY29uZmlnJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBzaXplPXsxNH0gLz4gQnVhdCBVbGFuZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhdGFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUltcG9ydFRvRm9ybX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZWxlY3RlZEluZGljZXMubGVuZ3RoID09PSAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LW1kIHNoYWRvdy10ZWFsLTUwMC8yMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk1hc3Vra2FuIHtzZWxlY3RlZEluZGljZXMubGVuZ3RofSBTb2FsIGtlIEZvcm11bGlyPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==