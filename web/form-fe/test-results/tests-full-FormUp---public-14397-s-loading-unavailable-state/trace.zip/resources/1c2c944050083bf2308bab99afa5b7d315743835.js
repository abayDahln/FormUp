import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/ImportQuestionsModal.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { X, Upload, FileUp, Loader2, AlertCircle, CheckCircle2, Download, AlertTriangle, FileSpreadsheet, FileText, File } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import { previewImportQuestions, templateDownloadUrl } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ImportQuestionsModal.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const ACCEPT_FORMATS = ".xlsx,.xls,.csv,.pdf,.docx";
const MAX_DISPLAY_ROWS = 100;
const typeNameMap = {
	1: "Essay",
	2: "Pilihan Ganda",
	3: "Checkbox",
	4: "DateTime",
	5: "Benar/Salah"
};
function formatTypeName(typeId) {
	if (!typeId) return "-";
	if (typeof typeId === "string" && typeId.toLowerCase in typeNameMap) return typeNameMap[typeId.toLowerCase()];
	const id = parseInt(typeId, 10);
	return typeNameMap[id] || (typeof typeId === "string" ? typeId : `Tipe ${typeId}`);
}
function getFileIcon(fileName) {
	const ext = (fileName || "").split(".").pop().toLowerCase();
	if ([
		"xlsx",
		"xls",
		"csv"
	].includes(ext)) return /* @__PURE__ */ _jsxDEV(FileSpreadsheet, {
		size: 18,
		className: "text-emerald-600"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 54
	}, this);
	if (ext === "docx") return /* @__PURE__ */ _jsxDEV(FileText, {
		size: 18,
		className: "text-blue-600"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 32
	}, this);
	if (ext === "pdf") return /* @__PURE__ */ _jsxDEV(FileText, {
		size: 18,
		className: "text-red-600"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 42,
		columnNumber: 31
	}, this);
	return /* @__PURE__ */ _jsxDEV(File, {
		size: 18,
		className: "text-slate-500"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 12
	}, this);
}
function buildErrorMap(errors) {
	const map = new Map();
	if (!Array.isArray(errors)) return map;
	errors.forEach((err) => {
		const row = err.rowNumber ?? err.row ?? err.row_number;
		if (row == null) return;
		if (!map.has(row)) map.set(row, []);
		map.get(row).push(err);
	});
	return map;
}
export default function ImportQuestionsModal({ isOpen, onClose, formId, hasResponses, onImported }) {
	_s();
	const [file, setFile] = useState(null);
	const [dragOver, setDragOver] = useState(false);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const [preview, setPreview] = useState(null);
	const [committing, setCommitting] = useState(false);
	const fileInputRef = useRef(null);
	useEffect(() => {
		if (isOpen) {
			setFile(null);
			setError(null);
			setPreview(null);
			setLoading(false);
			setCommitting(false);
		}
	}, [isOpen]);
	if (!isOpen) return null;
	const handleSelectFile = (e) => {
		const f = e.target.files?.[0];
		if (!f) return;
		setFile(f);
		setError(null);
		setPreview(null);
		void handlePreview(f);
		if (fileInputRef.current) fileInputRef.current.value = "";
	};
	const handleDrop = (e) => {
		e.preventDefault();
		setDragOver(false);
		const f = e.dataTransfer?.files?.[0];
		if (!f) return;
		setFile(f);
		setError(null);
		setPreview(null);
		void handlePreview(f);
	};
	const handlePreview = async (f) => {
		if (!formId) return;
		setLoading(true);
		setError(null);
		try {
			const res = await previewImportQuestions(formId, f);
			if (res.ok) {
				setPreview(res.data || {});
			} else {
				setError(res.message || "Gagal memproses preview file.");
				setPreview(null);
			}
		} catch (e) {
			console.error("[Import Preview Error]:", e);
			setError("Terjadi kesalahan jaringan saat membaca file.");
			setPreview(null);
		} finally {
			setLoading(false);
		}
	};
	const handleCommit = async () => {
		if (!file || !formId) return;
		setCommitting(true);
		setError(null);
		try {
			// Preview is read-only. Return the parsed rows to the builder so
			// the normal explicit Save action remains the only commit path.
			if (typeof onImported === "function") onImported({
				...preview || {},
				questions: previewRows,
				totalImported: previewRows.length
			});
			if (preview) {
				onClose();
			}
		} catch (e) {
			console.error("[Import Commit Error]:", e);
			setError("Terjadi kesalahan jaringan saat menyimpan hasil import.");
		} finally {
			setCommitting(false);
		}
	};
	const previewRows = preview?.questions ? Array.isArray(preview.questions) ? preview.questions : Object.values(preview.questions) : [];
	const errorMap = buildErrorMap(preview?.errors || preview?.validationErrors || []);
	const totalRows = preview?.totalRows ?? previewRows.length;
	const successCount = preview?.successCount ?? previewRows.length - errorMap.size;
	const errorCount = preview?.errorCount ?? errorMap.size;
	const blocked = !!hasResponses;
	const canCommit = !blocked && preview && successCount > 0 && !loading && !committing;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-[120] flex items-center justify-center p-4 sm:p-6 animate-fadeIn",
		role: "dialog",
		"aria-modal": "true",
		"aria-labelledby": "import-questions-modal-title",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "absolute inset-0 bg-black/50 backdrop-blur-sm",
			onClick: onClose
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 154,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative z-10 w-full max-w-5xl max-h-[88vh] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-200 dark:border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 text-white flex items-center justify-center shadow-xs",
							children: /* @__PURE__ */ _jsxDEV(Upload, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							id: "import-questions-modal-title",
							className: "text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight",
							children: "Import Soal dari File"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-500 dark:text-slate-400",
							children: "Mendukung .xlsx, .xls, .csv, .pdf, .docx — preview dulu sebelum disimpan"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onClose,
						disabled: committing || loading,
						className: "p-2 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all disabled:opacity-40 cursor-pointer",
						title: "Tutup",
						children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto px-5 sm:px-6 py-4 space-y-4",
					children: [
						error && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 rounded-xl flex items-start gap-2.5 animate-fadeIn",
							children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
								size: 16,
								className: "text-red-600 dark:text-red-400 mt-0.5 shrink-0"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 text-xs text-red-800 dark:text-red-300 font-medium",
								children: error
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 25
						}, this),
						blocked && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 rounded-xl flex items-start gap-2.5 animate-fadeIn",
							children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, {
								size: 16,
								className: "text-red-600 dark:text-red-400 mt-0.5 shrink-0"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 text-xs text-red-800 dark:text-red-300 font-medium",
								children: [
									"Formulir ini sudah memiliki ",
									/* @__PURE__ */ _jsxDEV("b", { children: hasResponses }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 61
									}, this),
									" respons responden. Untuk menjaga integritas data, penambahan / import soal baru sudah dikunci. Anda dapat menduplikasi formulir ini lalu mengimpor ke salinan yang baru."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-2",
							children: "Download Template (opsional):"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap gap-2",
							children: [
								"csv",
								"xlsx",
								"docx"
							].map((fmt) => /* @__PURE__ */ _jsxDEV("a", {
								href: templateDownloadUrl(fmt),
								download: true,
								className: "inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-[11px] font-bold transition-all",
								children: [
									/* @__PURE__ */ _jsxDEV(Download, { size: 12 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 212,
										columnNumber: 37
									}, this),
									"Template .",
									fmt.toUpperCase()
								]
							}, fmt, true, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 33
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 25
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							onDragOver: (e) => {
								e.preventDefault();
								setDragOver(true);
							},
							onDragLeave: () => setDragOver(false),
							onDrop: handleDrop,
							className: `border-2 border-dashed rounded-2xl p-6 sm:p-8 text-center transition-all cursor-pointer ${dragOver ? "border-blue-500 bg-blue-50 dark:bg-blue-950/30" : "border-slate-300 dark:border-slate-700 hover:border-blue-400 hover:bg-slate-50 dark:hover:bg-slate-800/50"}`,
							onClick: () => fileInputRef.current && fileInputRef.current.click(),
							children: [/* @__PURE__ */ _jsxDEV("input", {
								ref: fileInputRef,
								type: "file",
								accept: ACCEPT_FORMATS,
								className: "hidden",
								onChange: handleSelectFile,
								disabled: loading || committing
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 229,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: `w-12 h-12 rounded-2xl flex items-center justify-center ${dragOver ? "bg-blue-500 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-400"}`,
										children: /* @__PURE__ */ _jsxDEV(FileUp, { size: 22 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 239,
											columnNumber: 33
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 238,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs font-bold text-slate-700 dark:text-slate-200",
										children: file ? file.name : "Klik untuk pilih atau drag-drop file di sini"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 242,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5",
										children: file ? `${(file.size / 1024).toFixed(1)} KB` : "Format yang didukung: .xlsx, .xls, .csv, .pdf, .docx"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 245,
										columnNumber: 33
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 241,
										columnNumber: 29
									}, this),
									file && /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-2 inline-flex items-center gap-2 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xs",
										children: [getFileIcon(file.name), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-semibold text-slate-700 dark:text-slate-200",
											children: file.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 252,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 250,
										columnNumber: 33
									}, this),
									loading && /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-3 inline-flex items-center gap-2 px-3 py-1.5 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 rounded-lg",
										children: [/* @__PURE__ */ _jsxDEV(Loader2, {
											size: 13,
											className: "animate-spin text-blue-600 dark:text-blue-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 257,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-bold text-blue-700 dark:text-blue-300",
											children: "Membaca dan memproses file..."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 258,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 256,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 219,
							columnNumber: 21
						}, this),
						preview && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800 animate-fadeIn",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-700",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] uppercase font-extrabold text-slate-400 tracking-wider",
											children: "Total Baris"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 268,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-lg font-black text-slate-900 dark:text-white mt-0.5",
											children: totalRows
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 269,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 267,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-100 dark:border-emerald-900/50",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] uppercase font-extrabold text-emerald-600 dark:text-emerald-400 tracking-wider",
											children: "Berhasil Dibaca"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 272,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-lg font-black text-emerald-700 dark:text-emerald-300 mt-0.5",
											children: successCount
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 273,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 271,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: `p-3 rounded-xl border ${errorCount > 0 ? "bg-red-50 dark:bg-red-950/30 border-red-100 dark:border-red-900/50" : "bg-slate-50 dark:bg-slate-800/60 border-slate-100 dark:border-slate-700"}`,
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: `text-[10px] uppercase font-extrabold tracking-wider ${errorCount > 0 ? "text-red-600 dark:text-red-400" : "text-slate-400"}`,
											children: "Baris Error"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 276,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: `text-lg font-black mt-0.5 ${errorCount > 0 ? "text-red-700 dark:text-red-300" : "text-slate-900 dark:text-white"}`,
											children: errorCount
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 277,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 275,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 bg-blue-50 dark:bg-blue-950/30 rounded-xl border border-blue-100 dark:border-blue-900/50",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] uppercase font-extrabold text-blue-600 dark:text-blue-400 tracking-wider",
											children: "Akan Diimport"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 280,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-lg font-black text-blue-700 dark:text-blue-300 mt-0.5",
											children: preview?.totalImported ?? successCount
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 281,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 279,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 266,
								columnNumber: 29
							}, this), previewRows.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
								className: "rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] font-extrabold text-slate-700 dark:text-slate-200",
										children: ["Preview Hasil Parsing", previewRows.length > MAX_DISPLAY_ROWS ? ` (${MAX_DISPLAY_ROWS} dari ${previewRows.length} ditampilkan)` : ""]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 288,
										columnNumber: 41
									}, this), errorMap.size > 0 && /* @__PURE__ */ _jsxDEV("span", {
										className: "inline-flex items-center gap-1 px-2 py-0.5 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 rounded-md text-[10px] font-bold",
										children: [
											/* @__PURE__ */ _jsxDEV(AlertCircle, { size: 10 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 293,
												columnNumber: 49
											}, this),
											" ",
											errorMap.size,
											" baris bermasalah"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 292,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 287,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "max-h-80 overflow-auto",
									children: /* @__PURE__ */ _jsxDEV("table", {
										className: "w-full text-left border-collapse min-w-[720px]",
										children: [/* @__PURE__ */ _jsxDEV("thead", {
											className: "sticky top-0 bg-slate-100 dark:bg-slate-800 z-10",
											children: /* @__PURE__ */ _jsxDEV("tr", { children: [
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-3 py-2 text-[10px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider w-14",
													children: "No"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 301,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-3 py-2 text-[10px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider",
													children: "Soal"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 302,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-3 py-2 text-[10px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider w-28",
													children: "Tipe"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 303,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-3 py-2 text-[10px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider w-36",
													children: "Kunci Jawaban"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 304,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-3 py-2 text-[10px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider w-20",
													children: "Bobot"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 305,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-3 py-2 text-[10px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider w-52",
													children: "Catatan / Error"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 306,
													columnNumber: 53
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 300,
												columnNumber: 49
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 299,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: previewRows.slice(0, MAX_DISPLAY_ROWS).map((row, i) => {
											const rowNum = row.rowNumber ?? row.row ?? row.row_number ?? (preview?.errors?.length ? null : i + 1);
											const hasErr = rowNum != null && errorMap.has(rowNum);
											const errList = rowNum != null ? errorMap.get(rowNum) || [] : [];
											const qText = row.question ?? row.Question ?? row.questionText ?? "";
											const displayQ = typeof qText === "string" ? qText.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").slice(0, 200) : "";
											const keyText = row.correctAnswer ?? row.correct_answer ?? row.kunciJawaban ?? row.answer ?? "-";
											const displayKey = Array.isArray(keyText) ? keyText.join(", ") : typeof keyText === "string" ? keyText.slice(0, 80) : String(keyText ?? "-");
											return /* @__PURE__ */ _jsxDEV("tr", {
												className: `border-t border-slate-100 dark:border-slate-800 ${hasErr ? "bg-red-50 dark:bg-red-950/20" : "hover:bg-slate-50 dark:hover:bg-slate-800/30"}`,
												children: [
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-3 py-2 text-[11px] font-bold text-slate-500 dark:text-slate-400 align-top",
														children: row.questionOrder ?? row.order ?? row.rowNumber ?? i + 1
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 323,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-3 py-2 text-[11px] text-slate-800 dark:text-slate-200 align-top",
														children: displayQ || /* @__PURE__ */ _jsxDEV("span", {
															className: "text-slate-400 italic",
															children: "(kosong)"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 327,
															columnNumber: 78
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 326,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-3 py-2 text-[11px] text-slate-700 dark:text-slate-300 align-top",
														children: formatTypeName(row.typeId ?? row.type_id ?? row.type)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 329,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-3 py-2 text-[11px] text-slate-700 dark:text-slate-300 align-top font-semibold",
														children: displayKey
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 332,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-3 py-2 text-[11px] text-slate-700 dark:text-slate-300 align-top",
														children: row.points ?? row.Points ?? row.bobot ?? row.weight ?? "-"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 335,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-3 py-2 align-top",
														children: hasErr ? /* @__PURE__ */ _jsxDEV("div", {
															className: "space-y-1",
															children: errList.map((err, j) => /* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-start gap-1",
																children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
																	size: 11,
																	className: "text-red-600 dark:text-red-400 mt-0.5 shrink-0"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 343,
																	columnNumber: 81
																}, this), /* @__PURE__ */ _jsxDEV("div", { children: [err.field && /* @__PURE__ */ _jsxDEV("span", {
																	className: "font-bold text-[10px] text-red-700 dark:text-red-300",
																	children: [
																		"[",
																		err.field,
																		"] "
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 345,
																	columnNumber: 99
																}, this), /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-[10px] text-red-700 dark:text-red-300",
																	children: err.message || err.Message || "Data tidak valid"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 346,
																	columnNumber: 85
																}, this)] }, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 344,
																	columnNumber: 81
																}, this)]
															}, j, true, {
																fileName: _jsxFileName,
																lineNumber: 342,
																columnNumber: 77
															}, this))
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 340,
															columnNumber: 69
														}, this) : /* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-1 text-emerald-700 dark:text-emerald-400",
															children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 11 }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 353,
																columnNumber: 73
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																className: "text-[10px] font-bold",
																children: "OK"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 354,
																columnNumber: 73
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 352,
															columnNumber: 69
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 338,
														columnNumber: 61
													}, this)
												]
											}, row._key ?? i, true, {
												fileName: _jsxFileName,
												lineNumber: 319,
												columnNumber: 57
											}, this);
										}) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 309,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 298,
										columnNumber: 41
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 297,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 286,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 265,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between gap-3 px-5 sm:px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/80",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-[11px] text-slate-500 dark:text-slate-400",
						children: !preview ? "Pilih file untuk melihat preview." : "Periksa hasil preview, klik Import Sekarang untuk menyimpan ke database."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 371,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							disabled: committing || loading,
							className: "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 transition-all disabled:opacity-50 cursor-pointer",
							children: "Batal"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 375,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleCommit,
							disabled: !canCommit,
							className: `px-5 py-2 rounded-xl text-xs font-bold text-white shadow-xs flex items-center gap-2 transition-all cursor-pointer ${canCommit ? "bg-gradient-to-r from-blue-600 to-indigo-500 hover:from-blue-700 hover:to-indigo-600 active:scale-[0.98]" : "bg-slate-300 dark:bg-slate-700 text-slate-500 cursor-not-allowed"} disabled:cursor-not-allowed`,
							children: committing ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
								size: 13,
								className: "animate-spin"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 394,
								columnNumber: 37
							}, this), "Menyimpan..."] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 393,
								columnNumber: 33
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Upload, { size: 13 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 399,
								columnNumber: 37
							}, this), "Import Sekarang"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 398,
								columnNumber: 33
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 383,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 374,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 370,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 155,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 153,
		columnNumber: 9
	}, this);
}
_s(ImportQuestionsModal, "yqJCwUZdoFT3hLZ9tKMDE2KjGcQ=");
_c = ImportQuestionsModal;
var _c;
$RefreshReg$(_c, "ImportQuestionsModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/ImportQuestionsModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ImportQuestionsModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ImportQuestionsModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ImportQuestionsModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsY0FBYztBQUM1QyxTQUNJLEdBQ0EsUUFDQSxRQUNBLFNBQ0EsYUFDQSxjQUNBLFVBQ0EsZUFDQSxpQkFDQSxVQUNBLFlBQ0c7QUFDUCxTQUNJLHdCQUNBLDJCQUNHOzs7O0FBRVAsTUFBTSxpQkFBaUI7QUFDdkIsTUFBTSxtQkFBbUI7QUFFekIsTUFBTSxjQUFjO0NBQ2hCLEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0FBQ1A7QUFFQSxTQUFTLGVBQWUsUUFBUTtDQUM1QixJQUFJLENBQUMsUUFBUSxPQUFPO0NBQ3BCLElBQUksT0FBTyxXQUFXLFlBQVksT0FBTyxlQUFlLGFBQWEsT0FBTyxZQUFZLE9BQU8sWUFBWTtDQUMzRyxNQUFNLEtBQUssU0FBUyxRQUFRLEVBQUU7Q0FDOUIsT0FBTyxZQUFZLFFBQVEsT0FBTyxXQUFXLFdBQVcsU0FBUyxRQUFRO0FBQzdFO0FBRUEsU0FBUyxZQUFZLFVBQVU7Q0FDM0IsTUFBTSxPQUFPLFlBQVksR0FBRSxDQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsWUFBWTtDQUMxRCxJQUFJO0VBQUM7RUFBUTtFQUFPO0NBQUssQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLE9BQU8sd0JBQUMsaUJBQUQ7RUFBaUIsTUFBTTtFQUFJLFdBQVU7Q0FBb0I7Ozs7O0NBQzFHLElBQUksUUFBUSxRQUFRLE9BQU8sd0JBQUMsVUFBRDtFQUFVLE1BQU07RUFBSSxXQUFVO0NBQWlCOzs7OztDQUMxRSxJQUFJLFFBQVEsT0FBTyxPQUFPLHdCQUFDLFVBQUQ7RUFBVSxNQUFNO0VBQUksV0FBVTtDQUFnQjs7Ozs7Q0FDeEUsT0FBTyx3QkFBQyxNQUFEO0VBQU0sTUFBTTtFQUFJLFdBQVU7Q0FBa0I7Ozs7O0FBQ3ZEO0FBRUEsU0FBUyxjQUFjLFFBQVE7Q0FDM0IsTUFBTSxNQUFNLElBQUksSUFBSTtDQUNwQixJQUFJLENBQUMsTUFBTSxRQUFRLE1BQU0sR0FBRyxPQUFPO0NBQ25DLE9BQU8sU0FBUSxRQUFPO0VBQ2xCLE1BQU0sTUFBTSxJQUFJLGFBQWEsSUFBSSxPQUFPLElBQUk7RUFDNUMsSUFBSSxPQUFPLE1BQU07RUFDakIsSUFBSSxDQUFDLElBQUksSUFBSSxHQUFHLEdBQUcsSUFBSSxJQUFJLEtBQUssQ0FBQyxDQUFDO0VBQ2xDLElBQUksSUFBSSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDekIsQ0FBQztDQUNELE9BQU87QUFDWDtBQUVBLGVBQWUsU0FBUyxxQkFBcUIsRUFBRSxRQUFRLFNBQVMsUUFBUSxjQUFjLGNBQWM7O0NBQ2hHLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxJQUFJO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBQzlDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxJQUFJO0NBQ3ZDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxlQUFlLE9BQU8sSUFBSTtDQUVoQyxnQkFBZ0I7RUFDWixJQUFJLFFBQVE7R0FDUixRQUFRLElBQUk7R0FDWixTQUFTLElBQUk7R0FDYixXQUFXLElBQUk7R0FDZixXQUFXLEtBQUs7R0FDaEIsY0FBYyxLQUFLO0VBQ3ZCO0NBQ0osR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUVYLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsTUFBTSxvQkFBb0IsTUFBTTtFQUM1QixNQUFNLElBQUksRUFBRSxPQUFPLFFBQVE7RUFDM0IsSUFBSSxDQUFDLEdBQUc7RUFDUixRQUFRLENBQUM7RUFDVCxTQUFTLElBQUk7RUFDYixXQUFXLElBQUk7RUFDZixLQUFLLGNBQWMsQ0FBQztFQUNwQixJQUFJLGFBQWEsU0FBUyxhQUFhLFFBQVEsUUFBUTtDQUMzRDtDQUVBLE1BQU0sY0FBYyxNQUFNO0VBQ3RCLEVBQUUsZUFBZTtFQUNqQixZQUFZLEtBQUs7RUFDakIsTUFBTSxJQUFJLEVBQUUsY0FBYyxRQUFRO0VBQ2xDLElBQUksQ0FBQyxHQUFHO0VBQ1IsUUFBUSxDQUFDO0VBQ1QsU0FBUyxJQUFJO0VBQ2IsV0FBVyxJQUFJO0VBQ2YsS0FBSyxjQUFjLENBQUM7Q0FDeEI7Q0FFQSxNQUFNLGdCQUFnQixPQUFPLE1BQU07RUFDL0IsSUFBSSxDQUFDLFFBQVE7RUFDYixXQUFXLElBQUk7RUFDZixTQUFTLElBQUk7RUFDYixJQUFJO0dBQ0EsTUFBTSxNQUFNLE1BQU0sdUJBQXVCLFFBQVEsQ0FBQztHQUNsRCxJQUFJLElBQUksSUFBSTtJQUNSLFdBQVcsSUFBSSxRQUFRLENBQUMsQ0FBQztHQUM3QixPQUFPO0lBQ0gsU0FBUyxJQUFJLFdBQVcsK0JBQStCO0lBQ3ZELFdBQVcsSUFBSTtHQUNuQjtFQUNKLFNBQVMsR0FBRztHQUNSLFFBQVEsTUFBTSwyQkFBMkIsQ0FBQztHQUMxQyxTQUFTLCtDQUErQztHQUN4RCxXQUFXLElBQUk7RUFDbkIsVUFBVTtHQUNOLFdBQVcsS0FBSztFQUNwQjtDQUNKO0NBRUEsTUFBTSxlQUFlLFlBQVk7RUFDN0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRO0VBQ3RCLGNBQWMsSUFBSTtFQUNsQixTQUFTLElBQUk7RUFDYixJQUFJOzs7R0FHQSxJQUFJLE9BQU8sZUFBZSxZQUFZLFdBQVc7SUFDN0MsR0FBSSxXQUFXLENBQUM7SUFDaEIsV0FBVztJQUNYLGVBQWUsWUFBWTtHQUMvQixDQUFDO0dBQ0QsSUFBSSxTQUFTO0lBQ1QsUUFBUTtHQUNaO0VBQ0osU0FBUyxHQUFHO0dBQ1IsUUFBUSxNQUFNLDBCQUEwQixDQUFDO0dBQ3pDLFNBQVMseURBQXlEO0VBQ3RFLFVBQVU7R0FDTixjQUFjLEtBQUs7RUFDdkI7Q0FDSjtDQUVBLE1BQU0sY0FBZSxTQUFTLFlBQWMsTUFBTSxRQUFRLFFBQVEsU0FBUyxJQUFJLFFBQVEsWUFBWSxPQUFPLE9BQU8sUUFBUSxTQUFTLElBQUssQ0FBQztDQUN4SSxNQUFNLFdBQVcsY0FBYyxTQUFTLFVBQVUsU0FBUyxvQkFBb0IsQ0FBQyxDQUFDO0NBQ2pGLE1BQU0sWUFBWSxTQUFTLGFBQWEsWUFBWTtDQUNwRCxNQUFNLGVBQWUsU0FBUyxnQkFBaUIsWUFBWSxTQUFTLFNBQVM7Q0FDN0UsTUFBTSxhQUFhLFNBQVMsY0FBYyxTQUFTO0NBQ25ELE1BQU0sVUFBVSxDQUFDLENBQUM7Q0FDbEIsTUFBTSxZQUFZLENBQUMsV0FBVyxXQUFZLGVBQWUsS0FBTSxDQUFDLFdBQVcsQ0FBQztDQUU1RSxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQW1GLE1BQUs7RUFBUyxjQUFXO0VBQU8sbUJBQWdCO1lBQWxKLENBQ0ksd0JBQUMsT0FBRDtHQUFLLFdBQVU7R0FBZ0QsU0FBUztFQUFVOzs7O1lBQ2xGLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztNQUNsQjs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtPQUFJLElBQUc7T0FBK0IsV0FBVTtpQkFBb0Y7TUFFaEk7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWlEO01BRTNEOzs7O2NBQ0Y7Ozs7Y0FDSjs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0ksTUFBSztNQUNMLFNBQVM7TUFDVCxVQUFVLGNBQWM7TUFDeEIsV0FBVTtNQUNWLE9BQU07Z0JBRU4sd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7S0FDVjs7OzthQUNQOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0ssU0FDRyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLGFBQUQ7UUFBYSxNQUFNO1FBQUksV0FBVTtPQUFrRDs7OztpQkFDbkYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1Y7T0FDQTs7OztlQUNKOzs7Ozs7TUFHUixXQUNHLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsZUFBRDtRQUFlLE1BQU07UUFBSSxXQUFVO09BQWtEOzs7O2lCQUNyRix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUEyRTtTQUMzQyx3QkFBQyxLQUFELFlBQUksYUFBZ0I7Ozs7O1NBQUM7UUFDaEQ7Ozs7O2VBQ0o7Ozs7OztNQUdULHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBZ0U7TUFFMUU7Ozs7Z0JBQ0gsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1Y7UUFBQztRQUFPO1FBQVE7T0FBTSxDQUFDLENBQUMsS0FBSSxRQUN6Qix3QkFBQyxLQUFEO1FBRUksTUFBTSxvQkFBb0IsR0FBRztRQUM3QjtRQUNBLFdBQVU7a0JBSmQ7U0FNSSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztTQUFDO1NBQ1gsSUFBSSxZQUFZO1FBQzVCO1VBUE07Ozs7Y0FPTixDQUNOO01BQ0E7Ozs7Y0FDSjs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQ0ksYUFBYSxNQUFNO1FBQUUsRUFBRSxlQUFlO1FBQUcsWUFBWSxJQUFJO09BQUc7T0FDNUQsbUJBQW1CLFlBQVksS0FBSztPQUNwQyxRQUFRO09BQ1IsV0FBVywyRkFBMkYsV0FDaEcsbURBQ0E7T0FFTixlQUFlLGFBQWEsV0FBVyxhQUFhLFFBQVEsTUFBTTtpQkFSdEUsQ0FVSSx3QkFBQyxTQUFEO1FBQ0ksS0FBSztRQUNMLE1BQUs7UUFDTCxRQUFRO1FBQ1IsV0FBVTtRQUNWLFVBQVU7UUFDVixVQUFVLFdBQVc7T0FDeEI7Ozs7aUJBQ0Qsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVywwREFBMEQsV0FBVywyQkFBMkI7b0JBQzVHLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7O1NBQ2xCOzs7OztTQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDUixPQUFPLEtBQUssT0FBTztTQUNyQjs7OzttQkFDSCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDUixPQUFPLElBQUksS0FBSyxPQUFPLEtBQUksQ0FBRSxRQUFRLENBQUMsRUFBRSxPQUFPO1NBQ2pEOzs7O2lCQUNGOzs7OztTQUNKLFFBQ0csd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSyxZQUFZLEtBQUssSUFBSSxHQUN0Qix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZ0UsS0FBSztVQUFXOzs7O2tCQUMvRjs7Ozs7O1NBRVIsV0FDRyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLFNBQUQ7V0FBUyxNQUFNO1dBQUksV0FBVTtVQUFpRDs7OztvQkFDOUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlEO1VBQW1DOzs7O2tCQUMzRzs7Ozs7O1FBRVI7Ozs7O2VBQ0o7Ozs7OztNQUVKLFdBQ0csd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNJLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXFFO1VBQWM7Ozs7b0JBQ2hHLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUE0RDtVQUFhOzs7O2tCQUNyRjs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBNkY7VUFBa0I7Ozs7b0JBQzVILHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFvRTtVQUFnQjs7OztrQkFDaEc7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFXLHlCQUF5QixhQUFhLElBQUksdUVBQXVFO29CQUFqSSxDQUNJLHdCQUFDLEtBQUQ7V0FBRyxXQUFXLHVEQUF1RCxhQUFhLElBQUksbUNBQW1DO3FCQUFvQjtVQUFjOzs7O29CQUMzSix3QkFBQyxLQUFEO1dBQUcsV0FBVyw2QkFBNkIsYUFBYSxJQUFJLG1DQUFtQztxQkFBcUM7VUFBYzs7OztrQkFDako7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXVGO1VBQWdCOzs7O29CQUNwSCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBOEQsU0FBUyxpQkFBaUI7VUFBZ0I7Ozs7a0JBQ3BIOzs7Ozs7UUFDSjs7Ozs7aUJBRUosWUFBWSxTQUFTLEtBQ2xCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYixDQUE2RSx5QkFDbkQsWUFBWSxTQUFTLG1CQUFtQixLQUFLLGlCQUFpQixRQUFRLFlBQVksT0FBTyxpQkFBaUIsRUFDakk7Ozs7O21CQUNGLFNBQVMsT0FBTyxLQUNiLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUNJLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O1dBQUM7V0FBRSxTQUFTO1dBQUs7VUFDdkM7Ozs7O2lCQUVUOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWCx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBakIsQ0FDSSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFDYix3QkFBQyxNQUFEO1lBQ0ksd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQXdHO1lBQU07Ozs7O1lBQzVILHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFtRztZQUFROzs7OztZQUN6SCx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBd0c7WUFBUTs7Ozs7WUFDOUgsd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQXdHO1lBQWlCOzs7OztZQUN2SSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBd0c7WUFBUzs7Ozs7WUFDL0gsd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQXdHO1lBQW1COzs7OztXQUN6STs7Ozs7VUFDRDs7OztvQkFDUCx3QkFBQyxTQUFELFlBQ0ssWUFBWSxNQUFNLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxLQUFLLEtBQUssTUFBTTtXQUNwRCxNQUFNLFNBQVMsSUFBSSxhQUFhLElBQUksT0FBTyxJQUFJLGVBQWUsU0FBUyxRQUFRLFNBQVMsT0FBUSxJQUFJO1dBQ3BHLE1BQU0sU0FBUyxVQUFVLFFBQVEsU0FBUyxJQUFJLE1BQU07V0FDcEQsTUFBTSxVQUFVLFVBQVUsT0FBUSxTQUFTLElBQUksTUFBTSxLQUFLLENBQUMsSUFBSyxDQUFDO1dBQ2pFLE1BQU0sUUFBUSxJQUFJLFlBQVksSUFBSSxZQUFZLElBQUksZ0JBQWdCO1dBQ2xFLE1BQU0sV0FBVyxPQUFPLFVBQVUsV0FBVyxNQUFNLFFBQVEsWUFBWSxHQUFHLENBQUMsQ0FBQyxRQUFRLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHLEdBQUcsSUFBSTtXQUNqSCxNQUFNLFVBQVcsSUFBSSxpQkFBaUIsSUFBSSxrQkFBa0IsSUFBSSxnQkFBZ0IsSUFBSSxVQUFVO1dBQzlGLE1BQU0sYUFBYSxNQUFNLFFBQVEsT0FBTyxJQUFJLFFBQVEsS0FBSyxJQUFJLElBQUssT0FBTyxZQUFZLFdBQVcsUUFBUSxNQUFNLEdBQUcsRUFBRSxJQUFJLE9BQU8sV0FBVyxHQUFHO1dBQzVJLE9BQ0ksd0JBQUMsTUFBRDtZQUVJLFdBQVcsbURBQW1ELFNBQVMsaUNBQWlDO3NCQUY1RzthQUlJLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUNULElBQUksaUJBQWlCLElBQUksU0FBUyxJQUFJLGFBQWEsSUFBSTthQUN4RDs7Ozs7YUFDSix3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFDVCxZQUFZLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUF3QjtjQUFjOzs7OzthQUNuRTs7Ozs7YUFDSix3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFDVCxlQUFlLElBQUksVUFBVSxJQUFJLFdBQVcsSUFBSSxJQUFJO2FBQ3JEOzs7OzthQUNKLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUNUO2FBQ0Q7Ozs7O2FBQ0osd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1QsSUFBSSxVQUFVLElBQUksVUFBVSxJQUFJLFNBQVMsSUFBSSxVQUFVO2FBQ3hEOzs7OzthQUNKLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUNULFNBQ0csd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQ1YsUUFBUSxLQUFLLEtBQUssTUFDZix3QkFBQyxPQUFEO2dCQUFhLFdBQVU7MEJBQXZCLENBQ0ksd0JBQUMsYUFBRDtpQkFBYSxNQUFNO2lCQUFJLFdBQVU7Z0JBQWtEOzs7OzBCQUNuRix3QkFBQyxPQUFELGFBQ0ssSUFBSSxTQUFTLHdCQUFDLFFBQUQ7aUJBQU0sV0FBVTsyQkFBaEI7a0JBQXVFO2tCQUFFLElBQUk7a0JBQU07aUJBQVE7Ozs7OzBCQUN6Ryx3QkFBQyxRQUFEO2lCQUFNLFdBQVU7MkJBQThDLElBQUksV0FBVyxJQUFJLFdBQVc7Z0JBQXlCOzs7O3dCQUNwSDs7Ozt3QkFDSjtrQkFOSzs7OztzQkFNTCxDQUNSO2NBQ0E7Ozs7eUJBRUwsd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQWYsQ0FDSSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O3lCQUN6Qix3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQXdCO2VBQVE7Ozs7dUJBQy9DOzs7Ozs7YUFFVDs7Ozs7WUFDSjtjQXRDSyxJQUFJLFFBQVE7Ozs7a0JBc0NqQjtVQUVaLENBQUMsRUFDRTs7OztrQkFDSjs7Ozs7O1FBQ047Ozs7Z0JBQ0o7Ozs7O2VBRVI7Ozs7OztLQUVSOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1YsQ0FBQyxVQUFVLHNDQUFzQztLQUNqRDs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsVUFBRDtPQUNJLE1BQUs7T0FDTCxTQUFTO09BQ1QsVUFBVSxjQUFjO09BQ3hCLFdBQVU7aUJBQ2I7TUFFTzs7OztnQkFDUix3QkFBQyxVQUFEO09BQ0ksTUFBSztPQUNMLFNBQVM7T0FDVCxVQUFVLENBQUM7T0FDWCxXQUFXLHFIQUFxSCxZQUMxSCw2R0FDQSxtRUFDTDtpQkFFQSxhQUNHLGdEQUNJLHdCQUFDLFNBQUQ7UUFBUyxNQUFNO1FBQUksV0FBVTtPQUFnQjs7OztpQkFBQyxjQUVoRDs7OztrQkFFRixnREFDSSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7O2lCQUFDLGlCQUV0Qjs7Ozs7TUFFRjs7OztjQUNQOzs7OzthQUNKOzs7Ozs7R0FDSjs7Ozs7VUFDSjs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW1wb3J0UXVlc3Rpb25zTW9kYWwuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gICAgWCxcbiAgICBVcGxvYWQsXG4gICAgRmlsZVVwLFxuICAgIExvYWRlcjIsXG4gICAgQWxlcnRDaXJjbGUsXG4gICAgQ2hlY2tDaXJjbGUyLFxuICAgIERvd25sb2FkLFxuICAgIEFsZXJ0VHJpYW5nbGUsXG4gICAgRmlsZVNwcmVhZHNoZWV0LFxuICAgIEZpbGVUZXh0LFxuICAgIEZpbGVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7XG4gICAgcHJldmlld0ltcG9ydFF1ZXN0aW9ucyxcbiAgICB0ZW1wbGF0ZURvd25sb2FkVXJsXG59IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuXG5jb25zdCBBQ0NFUFRfRk9STUFUUyA9ICcueGxzeCwueGxzLC5jc3YsLnBkZiwuZG9jeCc7XG5jb25zdCBNQVhfRElTUExBWV9ST1dTID0gMTAwO1xuXG5jb25zdCB0eXBlTmFtZU1hcCA9IHtcbiAgICAxOiAnRXNzYXknLFxuICAgIDI6ICdQaWxpaGFuIEdhbmRhJyxcbiAgICAzOiAnQ2hlY2tib3gnLFxuICAgIDQ6ICdEYXRlVGltZScsXG4gICAgNTogJ0JlbmFyL1NhbGFoJyxcbn07XG5cbmZ1bmN0aW9uIGZvcm1hdFR5cGVOYW1lKHR5cGVJZCkge1xuICAgIGlmICghdHlwZUlkKSByZXR1cm4gJy0nO1xuICAgIGlmICh0eXBlb2YgdHlwZUlkID09PSAnc3RyaW5nJyAmJiB0eXBlSWQudG9Mb3dlckNhc2UgaW4gdHlwZU5hbWVNYXApIHJldHVybiB0eXBlTmFtZU1hcFt0eXBlSWQudG9Mb3dlckNhc2UoKV07XG4gICAgY29uc3QgaWQgPSBwYXJzZUludCh0eXBlSWQsIDEwKTtcbiAgICByZXR1cm4gdHlwZU5hbWVNYXBbaWRdIHx8ICh0eXBlb2YgdHlwZUlkID09PSAnc3RyaW5nJyA/IHR5cGVJZCA6IGBUaXBlICR7dHlwZUlkfWApO1xufVxuXG5mdW5jdGlvbiBnZXRGaWxlSWNvbihmaWxlTmFtZSkge1xuICAgIGNvbnN0IGV4dCA9IChmaWxlTmFtZSB8fCAnJykuc3BsaXQoJy4nKS5wb3AoKS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChbJ3hsc3gnLCAneGxzJywgJ2NzdiddLmluY2x1ZGVzKGV4dCkpIHJldHVybiA8RmlsZVNwcmVhZHNoZWV0IHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwXCIgLz47XG4gICAgaWYgKGV4dCA9PT0gJ2RvY3gnKSByZXR1cm4gPEZpbGVUZXh0IHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz47XG4gICAgaWYgKGV4dCA9PT0gJ3BkZicpIHJldHVybiA8RmlsZVRleHQgc2l6ZT17MTh9IGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiIC8+O1xuICAgIHJldHVybiA8RmlsZSBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIiAvPjtcbn1cblxuZnVuY3Rpb24gYnVpbGRFcnJvck1hcChlcnJvcnMpIHtcbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KGVycm9ycykpIHJldHVybiBtYXA7XG4gICAgZXJyb3JzLmZvckVhY2goZXJyID0+IHtcbiAgICAgICAgY29uc3Qgcm93ID0gZXJyLnJvd051bWJlciA/PyBlcnIucm93ID8/IGVyci5yb3dfbnVtYmVyO1xuICAgICAgICBpZiAocm93ID09IG51bGwpIHJldHVybjtcbiAgICAgICAgaWYgKCFtYXAuaGFzKHJvdykpIG1hcC5zZXQocm93LCBbXSk7XG4gICAgICAgIG1hcC5nZXQocm93KS5wdXNoKGVycik7XG4gICAgfSk7XG4gICAgcmV0dXJuIG1hcDtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW1wb3J0UXVlc3Rpb25zTW9kYWwoeyBpc09wZW4sIG9uQ2xvc2UsIGZvcm1JZCwgaGFzUmVzcG9uc2VzLCBvbkltcG9ydGVkIH0pIHtcbiAgICBjb25zdCBbZmlsZSwgc2V0RmlsZV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbZHJhZ092ZXIsIHNldERyYWdPdmVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbcHJldmlldywgc2V0UHJldmlld10gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbY29tbWl0dGluZywgc2V0Q29tbWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmKG51bGwpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGlzT3Blbikge1xuICAgICAgICAgICAgc2V0RmlsZShudWxsKTtcbiAgICAgICAgICAgIHNldEVycm9yKG51bGwpO1xuICAgICAgICAgICAgc2V0UHJldmlldyhudWxsKTtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgc2V0Q29tbWl0dGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9LCBbaXNPcGVuXSk7XG5cbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBoYW5kbGVTZWxlY3RGaWxlID0gKGUpID0+IHtcbiAgICAgICAgY29uc3QgZiA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgICAgIGlmICghZikgcmV0dXJuO1xuICAgICAgICBzZXRGaWxlKGYpO1xuICAgICAgICBzZXRFcnJvcihudWxsKTtcbiAgICAgICAgc2V0UHJldmlldyhudWxsKTtcbiAgICAgICAgdm9pZCBoYW5kbGVQcmV2aWV3KGYpO1xuICAgICAgICBpZiAoZmlsZUlucHV0UmVmLmN1cnJlbnQpIGZpbGVJbnB1dFJlZi5jdXJyZW50LnZhbHVlID0gJyc7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZURyb3AgPSAoZSkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHNldERyYWdPdmVyKGZhbHNlKTtcbiAgICAgICAgY29uc3QgZiA9IGUuZGF0YVRyYW5zZmVyPy5maWxlcz8uWzBdO1xuICAgICAgICBpZiAoIWYpIHJldHVybjtcbiAgICAgICAgc2V0RmlsZShmKTtcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICAgIHNldFByZXZpZXcobnVsbCk7XG4gICAgICAgIHZvaWQgaGFuZGxlUHJldmlldyhmKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlUHJldmlldyA9IGFzeW5jIChmKSA9PiB7XG4gICAgICAgIGlmICghZm9ybUlkKSByZXR1cm47XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHNldEVycm9yKG51bGwpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgcHJldmlld0ltcG9ydFF1ZXN0aW9ucyhmb3JtSWQsIGYpO1xuICAgICAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgICAgIHNldFByZXZpZXcocmVzLmRhdGEgfHwge30pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRFcnJvcihyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVtcHJvc2VzIHByZXZpZXcgZmlsZS4nKTtcbiAgICAgICAgICAgICAgICBzZXRQcmV2aWV3KG51bGwpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbSW1wb3J0IFByZXZpZXcgRXJyb3JdOicsIGUpO1xuICAgICAgICAgICAgc2V0RXJyb3IoJ1RlcmphZGkga2VzYWxhaGFuIGphcmluZ2FuIHNhYXQgbWVtYmFjYSBmaWxlLicpO1xuICAgICAgICAgICAgc2V0UHJldmlldyhudWxsKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNvbW1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFmaWxlIHx8ICFmb3JtSWQpIHJldHVybjtcbiAgICAgICAgc2V0Q29tbWl0dGluZyh0cnVlKTtcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyBQcmV2aWV3IGlzIHJlYWQtb25seS4gUmV0dXJuIHRoZSBwYXJzZWQgcm93cyB0byB0aGUgYnVpbGRlciBzb1xuICAgICAgICAgICAgLy8gdGhlIG5vcm1hbCBleHBsaWNpdCBTYXZlIGFjdGlvbiByZW1haW5zIHRoZSBvbmx5IGNvbW1pdCBwYXRoLlxuICAgICAgICAgICAgaWYgKHR5cGVvZiBvbkltcG9ydGVkID09PSAnZnVuY3Rpb24nKSBvbkltcG9ydGVkKHtcbiAgICAgICAgICAgICAgICAuLi4ocHJldmlldyB8fCB7fSksXG4gICAgICAgICAgICAgICAgcXVlc3Rpb25zOiBwcmV2aWV3Um93cyxcbiAgICAgICAgICAgICAgICB0b3RhbEltcG9ydGVkOiBwcmV2aWV3Um93cy5sZW5ndGgsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChwcmV2aWV3KSB7XG4gICAgICAgICAgICAgICAgb25DbG9zZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbSW1wb3J0IENvbW1pdCBFcnJvcl06JywgZSk7XG4gICAgICAgICAgICBzZXRFcnJvcignVGVyamFkaSBrZXNhbGFoYW4gamFyaW5nYW4gc2FhdCBtZW55aW1wYW4gaGFzaWwgaW1wb3J0LicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0Q29tbWl0dGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgcHJldmlld1Jvd3MgPSAocHJldmlldz8ucXVlc3Rpb25zKSA/IChBcnJheS5pc0FycmF5KHByZXZpZXcucXVlc3Rpb25zKSA/IHByZXZpZXcucXVlc3Rpb25zIDogT2JqZWN0LnZhbHVlcyhwcmV2aWV3LnF1ZXN0aW9ucykpIDogW107XG4gICAgY29uc3QgZXJyb3JNYXAgPSBidWlsZEVycm9yTWFwKHByZXZpZXc/LmVycm9ycyB8fCBwcmV2aWV3Py52YWxpZGF0aW9uRXJyb3JzIHx8IFtdKTtcbiAgICBjb25zdCB0b3RhbFJvd3MgPSBwcmV2aWV3Py50b3RhbFJvd3MgPz8gcHJldmlld1Jvd3MubGVuZ3RoO1xuICAgIGNvbnN0IHN1Y2Nlc3NDb3VudCA9IHByZXZpZXc/LnN1Y2Nlc3NDb3VudCA/PyAocHJldmlld1Jvd3MubGVuZ3RoIC0gZXJyb3JNYXAuc2l6ZSk7XG4gICAgY29uc3QgZXJyb3JDb3VudCA9IHByZXZpZXc/LmVycm9yQ291bnQgPz8gZXJyb3JNYXAuc2l6ZTtcbiAgICBjb25zdCBibG9ja2VkID0gISFoYXNSZXNwb25zZXM7XG4gICAgY29uc3QgY2FuQ29tbWl0ID0gIWJsb2NrZWQgJiYgcHJldmlldyAmJiAoc3VjY2Vzc0NvdW50ID4gMCkgJiYgIWxvYWRpbmcgJiYgIWNvbW1pdHRpbmc7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bMTIwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgc206cC02IGFuaW1hdGUtZmFkZUluXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgYXJpYS1sYWJlbGxlZGJ5PVwiaW1wb3J0LXF1ZXN0aW9ucy1tb2RhbC10aXRsZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzUwIGJhY2tkcm9wLWJsdXItc21cIiBvbkNsaWNrPXtvbkNsb3NlfSAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIHctZnVsbCBtYXgtdy01eGwgbWF4LWgtWzg4dmhdIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctMnhsIGZsZXggZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNSBzbTpweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNTAwIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgaWQ9XCJpbXBvcnQtcXVlc3Rpb25zLW1vZGFsLXRpdGxlXCIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIHNtOnRleHQtbGcgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEltcG9ydCBTb2FsIGRhcmkgRmlsZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNZW5kdWt1bmcgLnhsc3gsIC54bHMsIC5jc3YsIC5wZGYsIC5kb2N4IOKAlCBwcmV2aWV3IGR1bHUgc2ViZWx1bSBkaXNpbXBhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NvbW1pdHRpbmcgfHwgbG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLWxnIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tYWxsIGRpc2FibGVkOm9wYWNpdHktNDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJUdXR1cFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBweC01IHNtOnB4LTYgcHktNCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC8zMCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTkwMC81MCByb3VuZGVkLXhsIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNSBhbmltYXRlLWZhZGVJblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwIG10LTAuNSBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgdGV4dC14cyB0ZXh0LXJlZC04MDAgZGFyazp0ZXh0LXJlZC0zMDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAge2Jsb2NrZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTUwLzMwIGJvcmRlciBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtOTAwLzUwIHJvdW5kZWQteGwgZmxleCBpdGVtcy1zdGFydCBnYXAtMi41IGFuaW1hdGUtZmFkZUluXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCBkYXJrOnRleHQtcmVkLTQwMCBtdC0wLjUgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHRleHQteHMgdGV4dC1yZWQtODAwIGRhcms6dGV4dC1yZWQtMzAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZvcm11bGlyIGluaSBzdWRhaCBtZW1pbGlraSA8Yj57aGFzUmVzcG9uc2VzfTwvYj4gcmVzcG9ucyByZXNwb25kZW4uIFVudHVrIG1lbmphZ2EgaW50ZWdyaXRhcyBkYXRhLCBwZW5hbWJhaGFuIC8gaW1wb3J0IHNvYWwgYmFydSBzdWRhaCBkaWt1bmNpLiBBbmRhIGRhcGF0IG1lbmR1cGxpa2FzaSBmb3JtdWxpciBpbmkgbGFsdSBtZW5naW1wb3Iga2Ugc2FsaW5hbiB5YW5nIGJhcnUuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERvd25sb2FkIFRlbXBsYXRlIChvcHNpb25hbCk6XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1snY3N2JywgJ3hsc3gnLCAnZG9jeCddLm1hcChmbXQgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtmbXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXt0ZW1wbGF0ZURvd25sb2FkVXJsKGZtdCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHJvdW5kZWQteGwgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERvd25sb2FkIHNpemU9ezEyfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVtcGxhdGUgLntmbXQudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uRHJhZ092ZXI9eyhlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgc2V0RHJhZ092ZXIodHJ1ZSk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkRyYWdMZWF2ZT17KCkgPT4gc2V0RHJhZ092ZXIoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25Ecm9wPXtoYW5kbGVEcm9wfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCByb3VuZGVkLTJ4bCBwLTYgc206cC04IHRleHQtY2VudGVyIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7ZHJhZ092ZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItYmx1ZS01MDAgYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTUwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1ibHVlLTQwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC81MCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQgJiYgZmlsZUlucHV0UmVmLmN1cnJlbnQuY2xpY2soKX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmPXtmaWxlSW5wdXRSZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD17QUNDRVBUX0ZPUk1BVFN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0RmlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZyB8fCBjb21taXR0aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctMTIgaC0xMiByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciAke2RyYWdPdmVyID8gJ2JnLWJsdWUtNTAwIHRleHQtd2hpdGUnIDogJ2JnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTQwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVXAgc2l6ZT17MjJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbGUgPyBmaWxlLm5hbWUgOiAnS2xpayB1bnR1ayBwaWxpaCBhdGF1IGRyYWctZHJvcCBmaWxlIGRpIHNpbmknfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsZSA/IGAkeyhmaWxlLnNpemUgLyAxMDI0KS50b0ZpeGVkKDEpfSBLQmAgOiAnRm9ybWF0IHlhbmcgZGlkdWt1bmc6IC54bHN4LCAueGxzLCAuY3N2LCAucGRmLCAuZG9jeCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0xLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0RmlsZUljb24oZmlsZS5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPntmaWxlLm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTEuNSBiZy1ibHVlLTUwIGRhcms6YmctYmx1ZS05NTAvMzAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCBkYXJrOmJvcmRlci1ibHVlLTkwMC81MCByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsxM30gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNzAwIGRhcms6dGV4dC1ibHVlLTMwMFwiPk1lbWJhY2EgZGFuIG1lbXByb3NlcyBmaWxlLi4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHtwcmV2aWV3ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgYW5pbWF0ZS1mYWRlSW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTQwMCB0cmFja2luZy13aWRlclwiPlRvdGFsIEJhcmlzPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJsYWNrIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBtdC0wLjVcIj57dG90YWxSb3dzfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC8zMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZW1lcmFsZC0xMDAgZGFyazpib3JkZXItZW1lcmFsZC05MDAvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWV4dHJhYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCB0cmFja2luZy13aWRlclwiPkJlcmhhc2lsIERpYmFjYTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ibGFjayB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCBtdC0wLjVcIj57c3VjY2Vzc0NvdW50fTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0zIHJvdW5kZWQteGwgYm9yZGVyICR7ZXJyb3JDb3VudCA+IDAgPyAnYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC8zMCBib3JkZXItcmVkLTEwMCBkYXJrOmJvcmRlci1yZWQtOTAwLzUwJyA6ICdiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2B0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1leHRyYWJvbGQgdHJhY2tpbmctd2lkZXIgJHtlcnJvckNvdW50ID4gMCA/ICd0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAnIDogJ3RleHQtc2xhdGUtNDAwJ31gfT5CYXJpcyBFcnJvcjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YHRleHQtbGcgZm9udC1ibGFjayBtdC0wLjUgJHtlcnJvckNvdW50ID4gMCA/ICd0ZXh0LXJlZC03MDAgZGFyazp0ZXh0LXJlZC0zMDAnIDogJ3RleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSd9YH0+e2Vycm9yQ291bnR9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTUwLzMwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ibHVlLTEwMCBkYXJrOmJvcmRlci1ibHVlLTkwMC81MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwIHRyYWNraW5nLXdpZGVyXCI+QWthbiBEaWltcG9ydDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ibGFjayB0ZXh0LWJsdWUtNzAwIGRhcms6dGV4dC1ibHVlLTMwMCBtdC0wLjVcIj57cHJldmlldz8udG90YWxJbXBvcnRlZCA/PyBzdWNjZXNzQ291bnR9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcmV2aWV3Um93cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMi41IGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJldmlldyBIYXNpbCBQYXJzaW5ne3ByZXZpZXdSb3dzLmxlbmd0aCA+IE1BWF9ESVNQTEFZX1JPV1MgPyBgICgke01BWF9ESVNQTEFZX1JPV1N9IGRhcmkgJHtwcmV2aWV3Um93cy5sZW5ndGh9IGRpdGFtcGlsa2FuKWAgOiAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9yTWFwLnNpemUgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIgcHktMC41IGJnLXJlZC0xMDAgZGFyazpiZy1yZWQtOTAwLzQwIHRleHQtcmVkLTcwMCBkYXJrOnRleHQtcmVkLTMwMCByb3VuZGVkLW1kIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezEwfSAvPiB7ZXJyb3JNYXAuc2l6ZX0gYmFyaXMgYmVybWFzYWxhaFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtaC04MCBvdmVyZmxvdy1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIG1pbi13LVs3MjBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cInN0aWNreSB0b3AtMCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgei0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdy0xNFwiPk5vPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtWzEwcHhdIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+U29hbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LVsxMHB4XSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB3LTI4XCI+VGlwZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LVsxMHB4XSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB3LTM2XCI+S3VuY2kgSmF3YWJhbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LVsxMHB4XSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB3LTIwXCI+Qm9ib3Q8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdy01MlwiPkNhdGF0YW4gLyBFcnJvcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJldmlld1Jvd3Muc2xpY2UoMCwgTUFYX0RJU1BMQVlfUk9XUykubWFwKChyb3csIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByb3dOdW0gPSByb3cucm93TnVtYmVyID8/IHJvdy5yb3cgPz8gcm93LnJvd19udW1iZXIgPz8gKHByZXZpZXc/LmVycm9ycz8ubGVuZ3RoID8gbnVsbCA6IChpICsgMSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGhhc0VyciA9IHJvd051bSAhPSBudWxsICYmIGVycm9yTWFwLmhhcyhyb3dOdW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGVyckxpc3QgPSByb3dOdW0gIT0gbnVsbCA/IChlcnJvck1hcC5nZXQocm93TnVtKSB8fCBbXSkgOiBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBxVGV4dCA9IHJvdy5xdWVzdGlvbiA/PyByb3cuUXVlc3Rpb24gPz8gcm93LnF1ZXN0aW9uVGV4dCA/PyAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkaXNwbGF5USA9IHR5cGVvZiBxVGV4dCA9PT0gJ3N0cmluZycgPyBxVGV4dC5yZXBsYWNlKC88W14+XSo+L2csICcgJykucmVwbGFjZSgvXFxzKy9nLCAnICcpLnNsaWNlKDAsIDIwMCkgOiAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBrZXlUZXh0ID0gKHJvdy5jb3JyZWN0QW5zd2VyID8/IHJvdy5jb3JyZWN0X2Fuc3dlciA/PyByb3cua3VuY2lKYXdhYmFuID8/IHJvdy5hbnN3ZXIgPz8gJy0nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkaXNwbGF5S2V5ID0gQXJyYXkuaXNBcnJheShrZXlUZXh0KSA/IGtleVRleHQuam9pbignLCAnKSA6ICh0eXBlb2Yga2V5VGV4dCA9PT0gJ3N0cmluZycgPyBrZXlUZXh0LnNsaWNlKDAsIDgwKSA6IFN0cmluZyhrZXlUZXh0ID8/ICctJykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0clxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtyb3cuX2tleSA/PyBpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgJHtoYXNFcnIgPyAnYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC8yMCcgOiAnaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvMzAnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgYWxpZ24tdG9wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jvdy5xdWVzdGlvbk9yZGVyID8/IHJvdy5vcmRlciA/PyByb3cucm93TnVtYmVyID8/IGkgKyAxfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBhbGlnbi10b3BcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGlzcGxheVEgfHwgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaXRhbGljXCI+KGtvc29uZyk8L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBhbGlnbi10b3BcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VHlwZU5hbWUocm93LnR5cGVJZCA/PyByb3cudHlwZV9pZCA/PyByb3cudHlwZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGFsaWduLXRvcCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Rpc3BsYXlLZXl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGFsaWduLXRvcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyb3cucG9pbnRzID8/IHJvdy5Qb2ludHMgPz8gcm93LmJvYm90ID8/IHJvdy53ZWlnaHQgPz8gJy0nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgYWxpZ24tdG9wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2hhc0VyciA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJMaXN0Lm1hcCgoZXJyLCBqKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2p9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezExfSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAgbXQtMC41IHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnIuZmllbGQgJiYgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWzEwcHhdIHRleHQtcmVkLTcwMCBkYXJrOnRleHQtcmVkLTMwMFwiPlt7ZXJyLmZpZWxkfV0gPC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtcmVkLTcwMCBkYXJrOnRleHQtcmVkLTMwMFwiPntlcnIubWVzc2FnZSB8fCBlcnIuTWVzc2FnZSB8fCAnRGF0YSB0aWRhayB2YWxpZCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezExfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkXCI+T0s8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHB4LTUgc206cHgtNiBweS00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTUwLzcwIGRhcms6Ymctc2xhdGUtOTAwLzgwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgeyFwcmV2aWV3ID8gJ1BpbGloIGZpbGUgdW50dWsgbWVsaWhhdCBwcmV2aWV3LicgOiAnUGVyaWtzYSBoYXNpbCBwcmV2aWV3LCBrbGlrIEltcG9ydCBTZWthcmFuZyB1bnR1ayBtZW55aW1wYW4ga2UgZGF0YWJhc2UuJ31cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjb21taXR0aW5nIHx8IGxvYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS01MCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQmF0YWxcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNvbW1pdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhbkNvbW1pdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC01IHB5LTIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke2NhbkNvbW1pdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTUwMCBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWluZGlnby02MDAgYWN0aXZlOnNjYWxlLVswLjk4XSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtMzAwIGRhcms6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtNTAwIGN1cnNvci1ub3QtYWxsb3dlZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZGB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbW1pdHRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsxM30gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1lbnlpbXBhbi4uLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEltcG9ydCBTZWthcmFuZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXX0=