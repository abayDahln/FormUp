import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/form-runner/FormRunnerPage.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useParams, useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { Clock, Lock, ArrowRight, ArrowLeft, AlertCircle, Send, Loader2, Maximize2, Sun, Moon, AlertTriangle, X, CheckCircle2, Bookmark, BookmarkCheck, Eye, LayoutGrid, Wifi, WifiOff } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import { getPublicFormByLink, getPublicFormQuestions, submitPublicFormResponse, submitFeedback, clearSession, assetUrl, getLocalUser, getFormById, getQuestions, getMyForms, postExamEvent, syncExamAnswers } from "/src/services/apiService.js";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
import ImageLightboxModal from "/src/components/ui/ImageLightboxModal.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-runner/FormRunnerPage.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function FormRunnerPage() {
	_s();
	const { formLink } = useParams();
	const navigate = useNavigate();
	const [searchParams] = useSearchParams();
	const isPreviewMode = searchParams.get("preview") === "true";
	const [form, setForm] = useState(null);
	const [questions, setQuestions] = useState([]);
	const [loading, setLoading] = useState(true);
	const [submitting, setSubmitting] = useState(false);
	const [error, setError] = useState("");
	const [validationToast, setValidationToast] = useState(null);
	const [tokenInput, setTokenInput] = useState("");
	const [tokenUnlocked, setTokenUnlocked] = useState(false);
	const [respondentName, setRespondentName] = useState("");
	// BUG-5 FIX: Keep respondentName in a ref so sendExamEvent doesn't need it
	// as a useCallback dependency — preventing session_start from re-firing on
	// every keystroke while the user types their name.
	const respondentNameRef = useRef("");
	// A-2: solid yellow ragu-ragu
	const [markedForReview, setMarkedForReview] = useState(new Set());
	// A-1: nav popup
	const [navPopupOpen, setNavPopupOpen] = useState(false);
	// FEAT-3: submit confirm
	const [submitConfirmOpen, setSubmitConfirmOpen] = useState(false);
	// B10: First dialog — warns about ragu-ragu questions before submit confirmation
	const [reviewWarningOpen, setReviewWarningOpen] = useState(false);
	// Exam mode monitoring & violation tracking (Server-side source of truth)
	const [tabSwitchCount, setTabSwitchCount] = useState(0);
	const [violationCount, setViolationCount] = useState(0);
	const [tabSwitchWarning, setTabSwitchWarning] = useState(false);
	const lastTabSwitchAtRef = useRef(0);
	// Persistent sessionId for exam mode (per formLink).
	// Kontrak dengan backend: event pertama dikirim TANPA sessionId
	// (null) agar server yang generate; ID balikan server disimpan dan
	// dipakai ulang. Jangan pre-generate UUID di klien — ID tak dikenal
	// tidak lagi diartikan sebagai "sesi di-reset".
	const getStoredSessionId = useCallback(() => {
		if (typeof window === "undefined") return null;
		try {
			return sessionStorage.getItem(`formup_exam_session_${formLink}`);
		} catch {
			return null;
		}
	}, [formLink]);
	const examSessionIdRef = useRef(null);
	if (!examSessionIdRef.current && typeof window !== "undefined") {
		examSessionIdRef.current = getStoredSessionId();
	}
	const [answers, setAnswers] = useState(() => {
		if (typeof window !== "undefined") {
			try {
				const cached = localStorage.getItem(`formup_cache_${formLink}`);
				if (cached) {
					const parsed = JSON.parse(cached);
					if (parsed && typeof parsed === "object") return parsed;
				}
			} catch {}
		}
		return {};
	});
	const answersRef = useRef(answers);
	const questionsRef = useRef(questions);
	const [currentStep, setCurrentStep] = useState(0);
	const [lightboxImage, setLightboxImage] = useState(null);
	const [reportModalOpen, setReportModalOpen] = useState(false);
	const [reportReason, setReportReason] = useState("PERTANYAAN_TIDAK_JELAS");
	const [reportDescription, setReportDescription] = useState("");
	const [submittingReport, setSubmittingReport] = useState(false);
	const [reportSuccess, setReportSuccess] = useState(false);
	const [reportError, setReportError] = useState("");
	const [timeLeft, setTimeLeft] = useState(null);
	const timerRef = useRef(null);
	const isSubmittingRef = useRef(false);
	const [isDarkMode, setIsDarkMode] = useState(() => {
		if (typeof window !== "undefined") {
			return document.documentElement.classList.contains("dark") || localStorage.getItem("theme") === "dark";
		}
		return false;
	});
	const toggleDarkMode = () => {
		setIsDarkMode((prev) => {
			const next = !prev;
			if (next) {
				document.documentElement.classList.add("dark");
				localStorage.setItem("theme", "dark");
			} else {
				document.documentElement.classList.remove("dark");
				localStorage.setItem("theme", "light");
			}
			return next;
		});
	};
	const currentUserRef = useRef(getLocalUser());
	const currentUser = currentUserRef.current;
	const examEventSeqRef = useRef(0);
	useEffect(() => {
		respondentNameRef.current = respondentName;
	}, [respondentName]);
	// Offline-First Mode: Track online/offline status and auto-sync
	const [isOnline, setIsOnline] = useState(() => typeof window !== "undefined" ? window.navigator.onLine : true);
	const [showRestoredToast, setShowRestoredToast] = useState(false);
	useEffect(() => {
		const handleOnline = () => {
			setIsOnline(true);
			setShowRestoredToast(true);
			setTimeout(() => setShowRestoredToast(false), 4e3);
			if (form && answers && Object.keys(answers).length > 0) {
				const sid = examSessionIdRef.current || getStoredSessionId();
				if (sid) {
					syncExamAnswers(formLink, sid, answers).catch(() => {});
				}
			}
		};
		const handleOffline = () => {
			setIsOnline(false);
		};
		window.addEventListener("online", handleOnline);
		window.addEventListener("offline", handleOffline);
		return () => {
			window.removeEventListener("online", handleOnline);
			window.removeEventListener("offline", handleOffline);
		};
	}, [
		form,
		answers,
		formLink,
		getStoredSessionId
	]);
	// auto-cache to local storage on answer change
	useEffect(() => {
		if (formLink && Object.keys(answers).length > 0) {
			try {
				localStorage.setItem(`formup_cache_${formLink}`, JSON.stringify(answers));
			} catch {}
		}
	}, [answers, formLink]);
	// B-2: apply theme
	useEffect(() => {
		if (!form) return;
		const root = document.documentElement;
		if (form.themePrimaryColor) root.style.setProperty("--form-primary", form.themePrimaryColor);
		if (form.themeBackgroundColor) root.style.setProperty("--form-bg", form.themeBackgroundColor);
		return () => {
			root.style.removeProperty("--form-primary");
			root.style.removeProperty("--form-bg");
		};
	}, [form]);
	const [isForceSubmitted, setIsForceSubmitted] = useState(false);
	const isForceSubmittedRef = useRef(false);
	// B12 Proctoring: Handle proctor force submit / session termination
	const handleForceSubmitTermination = useCallback((responseId = null) => {
		if (isForceSubmittedRef.current) return;
		isForceSubmittedRef.current = true;
		isSubmittingRef.current = true;
		if (timerRef.current) {
			clearInterval(timerRef.current);
			timerRef.current = null;
		}
		try {
			localStorage.removeItem(`formup_cache_${formLink}`);
			localStorage.removeItem(`formup_timer_deadline_${formLink}`);
			localStorage.removeItem(`formup_token_${formLink}`);
			if (responseId) {
				localStorage.setItem(`formup_submitted_${formLink}`, String(responseId));
			}
			sessionStorage.removeItem(`formup_exam_session_${formLink}`);
			sessionStorage.removeItem(`formup_violations_${formLink}`);
		} catch {}
		setIsForceSubmitted(true);
		if (responseId) {
			navigate(`/f/${formLink}/result/${responseId}`);
		}
	}, [formLink, navigate]);
	const sendExamEvent = useCallback(async (eventType) => {
		if (!form || isPreviewMode || form.isOwner) return;
		const isExam = form.isExamMode || form.detectTabSwitch;
		if (!isExam && !form.disableCopyPaste) return;
		if (isSubmittingRef.current || isForceSubmittedRef.current) return;
		const mySeq = ++examEventSeqRef.current;
		try {
			const sid = examSessionIdRef.current || getStoredSessionId();
			const payload = {
				sessionId: sid,
				respondentName: (respondentNameRef.current || "").trim() || currentUser?.fullname || "Anonim",
				type: eventType,
				occurredAt: new Date().toISOString()
			};
			const res = await postExamEvent(formLink, payload);
			const isTerminated = res.status === 410 || res.status === 409 || res.data?.isForceSubmitted || res.data?.isSubmitted || res.data?.status === "submitted" || res.data?.status === "force-submitted" || res.data?.status === "terminated";
			if (isTerminated) {
				const respId = res.data?.responseId || res.data?.id;
				handleForceSubmitTermination(respId);
				return;
			}
			if (res.ok && res.data) {
				if (res.data.sessionId) {
					examSessionIdRef.current = res.data.sessionId;
					try {
						sessionStorage.setItem(`formup_exam_session_${formLink}`, res.data.sessionId);
					} catch {}
				}
				if (typeof res.data.tabSwitchCount === "number") {
					setTabSwitchCount(res.data.tabSwitchCount);
				}
				if (typeof res.data.violationCount === "number") {
					setViolationCount(res.data.violationCount);
				}
				// Only show warning banner when an actual violation event occurs, not on presence (session_start / heartbeat)
				if (eventType !== "session_start" && eventType !== "heartbeat") {
					setTabSwitchWarning(true);
				}
				if (res.data.shouldAutoSubmit && !isSubmittingRef.current) {
					setTimeout(() => handleSubmit(null, true), 1e3);
				}
			}
		} catch (err) {
			console.warn("[ExamEvent] Background event report failed:", eventType, err);
		}
	}, [
		form,
		formLink,
		isPreviewMode,
		currentUser,
		handleForceSubmitTermination
	]);
	// Exam mode session presence: session_start and periodic heartbeat
	useEffect(() => {
		if (!form || isPreviewMode || form.isOwner) return;
		if (!form.isExamMode && !form.detectTabSwitch) return;
		if (form.requiresToken && !tokenUnlocked) return;
		// Start session on server
		sendExamEvent("session_start");
		// Periodic heartbeat every 30 seconds
		const heartbeatTimer = setInterval(() => {
			if (!isSubmittingRef.current) {
				sendExamEvent("heartbeat");
			}
		}, 3e4);
		return () => clearInterval(heartbeatTimer);
	}, [
		form,
		isPreviewMode,
		tokenUnlocked,
		sendExamEvent
	]);
	// Exam mode violation detection (Real-time incremental report, anti double-count)
	// BUG-2 FIX: Guard with tokenUnlocked so the visibilitychange / copy / paste
	// listeners are only attached AFTER the user has passed the token screen and
	// is actually on the question page.
	useEffect(() => {
		if (!form || isPreviewMode || form.isOwner || isForceSubmitted) return;
		// Do NOT attach violation listeners until the exam has actually started
		if (form.requiresToken && !tokenUnlocked) return;
		const isExam = form.isExamMode || form.detectTabSwitch;
		const disableCopy = form.disableCopyPaste || isExam;
		const handleVisibilityChange = () => {
			if (isForceSubmittedRef.current || isSubmittingRef.current) return;
			// Anti-double-count: ONLY report on hidden (leaving), never on visible (return)
			if (document.hidden && isExam) reportTabSwitch();
		};
		const reportTabSwitch = () => {
			if (!isExam || isForceSubmittedRef.current || isSubmittingRef.current) return;
			const now = Date.now();
			// blur and visibilitychange can describe the same tab switch.
			if (now - lastTabSwitchAtRef.current < 1e3) return;
			lastTabSwitchAtRef.current = now;
			sendExamEvent("tab_switch");
		};
		const handleWindowBlur = () => {
			if (document.hidden || isExam) reportTabSwitch();
		};
		const handleCopy = (e) => {
			if (isForceSubmittedRef.current || isSubmittingRef.current) return;
			if (disableCopy) {
				e.preventDefault();
				sendExamEvent("copy_attempt");
			}
		};
		const handlePaste = (e) => {
			if (isForceSubmittedRef.current || isSubmittingRef.current) return;
			if (disableCopy) {
				e.preventDefault();
				sendExamEvent("paste_attempt");
			}
		};
		const handleContextMenu = (e) => {
			if (isForceSubmittedRef.current || isSubmittingRef.current) return;
			if (disableCopy) {
				e.preventDefault();
				sendExamEvent("context_menu");
			}
		};
		if (isExam) {
			document.addEventListener("visibilitychange", handleVisibilityChange);
			window.addEventListener("blur", handleWindowBlur);
		}
		if (disableCopy) {
			document.addEventListener("copy", handleCopy);
			document.addEventListener("cut", handleCopy);
			document.addEventListener("paste", handlePaste);
			document.addEventListener("contextmenu", handleContextMenu);
		}
		return () => {
			if (isExam) {
				document.removeEventListener("visibilitychange", handleVisibilityChange);
				window.removeEventListener("blur", handleWindowBlur);
			}
			if (disableCopy) {
				document.removeEventListener("copy", handleCopy);
				document.removeEventListener("cut", handleCopy);
				document.removeEventListener("paste", handlePaste);
				document.removeEventListener("contextmenu", handleContextMenu);
			}
		};
	}, [
		form,
		isPreviewMode,
		tokenUnlocked,
		sendExamEvent,
		isForceSubmitted
	]);
	useEffect(() => {
		answersRef.current = answers;
	}, [answers]);
	useEffect(() => {
		questionsRef.current = questions;
	}, [questions]);
	// B12 Proctoring: Continuous background sync of draft answers for exam mode
	const syncInProgressRef = useRef(false);
	const lastSyncedHashRef = useRef("");
	const syncDraftAnswers = useCallback(async (customAnswers = null, forceCheck = false) => {
		if (!form || isPreviewMode || form.isOwner || isForceSubmittedRef.current) return;
		const isExam = form.isExamMode || form.detectTabSwitch;
		if (!isExam) return;
		if (form.requiresToken && !tokenUnlocked) return;
		if (isSubmittingRef.current || syncInProgressRef.current) return;
		const sid = examSessionIdRef.current || getStoredSessionId();
		if (!sid) return;
		const curAns = customAnswers || answersRef.current || {};
		const curQs = questionsRef.current?.length ? questionsRef.current : questions;
		// FIX (Force Submit tidak menghentikan responden): dulu fungsi ini
		// langsung berhenti kalau belum ada jawaban sama sekali, atau kalau
		// jawaban tidak berubah sejak sync terakhir. Akibatnya, responden yang
		// sedang diam/belum menjawab tidak pernah mengirim request apa pun ke
		// server, sehingga force-submit dari owner tidak pernah terdeteksi.
		// forceCheck=true (dipakai polling status berkala) melewati guard ini
		// supaya tetap ping server murni untuk mengecek status sesi — backend
		// tetap mengembalikan 400 "Sesi sudah disubmit" walau payload kosong,
		// karena pengecekan itu dilakukan SEBELUM backend mengecek isi jawaban.
		if (!forceCheck && (!curQs.length || Object.keys(curAns).length === 0)) return;
		const formattedAnswers = Object.entries(curAns).map(([questionId, value]) => {
			const q = curQs.find((item) => item.id === parseInt(questionId, 10));
			if (!q) return null;
			if (q.typeId === 2) {
				const p = parseInt(value, 10);
				return !isNaN(p) && p > 0 ? {
					questionId: q.id,
					optionId: p
				} : null;
			}
			if (q.typeId === 3) {
				const ids = Array.isArray(value) ? value.map((v) => parseInt(v, 10)).filter((id) => !isNaN(id) && id > 0) : [];
				return ids.length ? ids.map((id) => ({
					questionId: q.id,
					optionId: id
				})) : null;
			}
			if (q.typeId === 5) {
				const s = String(value || "").trim();
				return s ? {
					questionId: q.id,
					answerValue: s.toLowerCase() === "benar" || s.toLowerCase() === "true" ? "Benar" : "Salah"
				} : null;
			}
			const t = String(value || "").trim();
			return t ? {
				questionId: q.id,
				answerValue: t
			} : null;
		}).flat().filter(Boolean);
		if (!forceCheck && formattedAnswers.length === 0) return;
		const payloadHash = JSON.stringify(formattedAnswers);
		if (!forceCheck && payloadHash === lastSyncedHashRef.current) return;
		syncInProgressRef.current = true;
		try {
			const res = await syncExamAnswers(formLink, sid, {
				answers: formattedAnswers,
				respondentName: (respondentNameRef.current || "").trim() || currentUser?.fullname || "Anonim"
			});
			// FIX: backend membalikan 404 (bukan 410/409) dengan pesan
			// "Sesi sudah disubmit" saat sesi sudah di-force-submit — tambahkan
			// pengecekan itu, karena kondisi sebelumnya tidak pernah cocok.
			// Catatan: tidak ada lagi sinyal "reset" — reset pengawas hanya
			// berlaku untuk jawaban yang sudah disubmit dan tidak pernah
			// menghapus jawaban yang sedang dikerjakan, jadi 404 generik
			// tidak boleh me-reset state lokal.
			const isTerminated = res.status === 410 || res.status === 409 || res.status === 400 && /disubmit/i.test(res.message || "") || res.data?.isForceSubmitted || res.data?.isSubmitted || res.data?.status === "submitted" || res.data?.status === "force-submitted" || res.data?.status === "terminated";
			if (isTerminated) {
				const respId = res.data?.responseId || res.data?.id;
				handleForceSubmitTermination(respId);
				return;
			}
			if (res.ok) {
				lastSyncedHashRef.current = payloadHash;
			}
		} catch (err) {
			console.warn("[SyncAnswers] Background answer sync failed:", err);
		} finally {
			syncInProgressRef.current = false;
		}
	}, [
		form,
		isPreviewMode,
		tokenUnlocked,
		formLink,
		currentUser,
		getStoredSessionId,
		questions,
		handleForceSubmitTermination
	]);
	// Debounced sync answers on answer changes
	useEffect(() => {
		if (!form || isPreviewMode || form.isOwner) return;
		if (!form.isExamMode && !form.detectTabSwitch) return;
		if (form.requiresToken && !tokenUnlocked) return;
		const interval = setInterval(() => {
			if (!isSubmittingRef.current) {
				syncDraftAnswers(null, true);
			}
		}, 4e3);
		return () => clearInterval(interval);
	}, [
		form,
		isPreviewMode,
		tokenUnlocked,
		syncDraftAnswers
	]);
	// Periodic sync answers every 30 seconds
	useEffect(() => {
		if (!form || isPreviewMode || form.isOwner) return;
		if (!form.isExamMode && !form.detectTabSwitch) return;
		if (form.requiresToken && !tokenUnlocked) return;
		const interval = setInterval(() => {
			if (!isSubmittingRef.current) {
				syncDraftAnswers();
			}
		}, 3e4);
		return () => clearInterval(interval);
	}, [
		form,
		isPreviewMode,
		tokenUnlocked,
		syncDraftAnswers
	]);
	const loadQuestionsInternal = async (token) => {
		const res = await getPublicFormQuestions(formLink, {
			token,
			name: ""
		});
		if (res.ok && res.data) {
			const qList = res.data.questions || res.data || [];
			setQuestions(qList);
			questionsRef.current = qList;
			try {
				const cached = localStorage.getItem(`formup_cache_${formLink}`);
				if (cached) {
					const parsed = JSON.parse(cached);
					if (parsed && typeof parsed === "object") {
						setAnswers((prev) => {
							const next = {
								...parsed,
								...prev
							};
							answersRef.current = next;
							return next;
						});
					}
				}
			} catch {}
		}
	};
	const loadQuestions = async (token = null) => {
		const res = await getPublicFormQuestions(formLink, {
			token,
			name: respondentName
		});
		if (res.ok && res.data) {
			const qList = res.data.questions || res.data || [];
			setQuestions(qList);
			questionsRef.current = qList;
			try {
				const cached = localStorage.getItem(`formup_cache_${formLink}`);
				if (cached) {
					const parsed = JSON.parse(cached);
					if (parsed && typeof parsed === "object") {
						setAnswers((prev) => {
							const next = {
								...parsed,
								...prev
							};
							answersRef.current = next;
							return next;
						});
					}
				}
			} catch {}
		} else {
			setError(res.message || "Gagal memuat soal formulir.");
		}
	};
	useEffect(() => {
		const load = async () => {
			setLoading(true);
			setError("");
			// A-3: In preview mode, load draft/published form via owner endpoints
			if (isPreviewMode) {
				let targetFormId = searchParams.get("formId");
				if (!targetFormId) {
					try {
						const myFormsRes = await getMyForms();
						if (myFormsRes.ok && Array.isArray(myFormsRes.data)) {
							const found = myFormsRes.data.find((f) => f.formLink === formLink);
							if (found) targetFormId = found.id;
						}
					} catch {}
				}
				if (targetFormId) {
					try {
						const [formRes, questionsRes] = await Promise.all([getFormById(targetFormId), getQuestions(targetFormId)]);
						setLoading(false);
						if (formRes.ok && formRes.data) {
							setForm(formRes.data);
							setTokenUnlocked(true);
							if (currentUser?.fullname) setRespondentName(currentUser.fullname);
							const qList = Array.isArray(questionsRes.data) ? questionsRes.data : [];
							setQuestions(qList);
							questionsRef.current = qList;
							return;
						}
					} catch {}
				}
			}
			const res = await getPublicFormByLink(formLink);
			setLoading(false);
			if (res.status === 401) {
				clearSession();
				navigate("/login");
				return;
			}
			if (res.ok && res.data) {
				const f = res.data;
				setForm(f);
				if (currentUser?.fullname) setRespondentName(currentUser.fullname);
				// A-5: preview bypasses all gates
				if (isPreviewMode) {
					setTokenUnlocked(true);
					await loadQuestionsInternal(null);
					return;
				}
				const localSub = localStorage.getItem(`formup_submitted_${formLink}`);
				if (f.oneResponse && (f.alreadySubmitted || localSub)) return;
				let savedToken = "";
				try {
					savedToken = localStorage.getItem(`formup_token_${formLink}`) || "";
				} catch {}
				if (savedToken) setTokenInput(savedToken);
				if (!f.requiresToken) {
					setTokenUnlocked(true);
					await loadQuestions();
				} else if (savedToken) {
					const unlockRes = await getPublicFormQuestions(formLink, {
						token: savedToken,
						name: currentUser?.fullname || ""
					});
					if (unlockRes.ok && unlockRes.data) {
						setTokenUnlocked(true);
						const qList = unlockRes.data.questions || unlockRes.data || [];
						setQuestions(qList);
						questionsRef.current = qList;
					}
				}
				if (f.timerDuration && f.timerDuration > 0) {
					const timerDeadlineKey = `formup_timer_deadline_${formLink}`;
					const now = Date.now();
					let deadlineMs = parseInt(localStorage.getItem(timerDeadlineKey), 10);
					if (!deadlineMs || isNaN(deadlineMs)) {
						deadlineMs = now + f.timerDuration * 1e3;
						localStorage.setItem(timerDeadlineKey, String(deadlineMs));
					}
					setTimeLeft(Math.max(0, Math.ceil((deadlineMs - now) / 1e3)));
				}
			} else {
				setError(res.message || "Formulir tidak ditemukan atau belum dipublikasikan.");
			}
		};
		load();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [formLink, navigate]);
	useEffect(() => {
		if (!tokenUnlocked || !form?.timerDuration || form.timerDuration <= 0) return;
		const timerDeadlineKey = `formup_timer_deadline_${formLink}`;
		let stored = localStorage.getItem(timerDeadlineKey);
		let deadlineMs = stored ? parseInt(stored, 10) : null;
		const now = Date.now();
		if (!deadlineMs || isNaN(deadlineMs)) {
			deadlineMs = now + form.timerDuration * 1e3;
			localStorage.setItem(timerDeadlineKey, String(deadlineMs));
		}
		const checkTimer = () => {
			const remaining = Math.max(0, Math.ceil((deadlineMs - Date.now()) / 1e3));
			setTimeLeft(remaining);
			if (remaining <= 0) {
				if (timerRef.current) clearInterval(timerRef.current);
				if (!isSubmittingRef.current) handleSubmit(null, true);
			}
		};
		checkTimer();
		timerRef.current = setInterval(checkTimer, 1e3);
		return () => {
			if (timerRef.current) clearInterval(timerRef.current);
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [
		tokenUnlocked,
		form?.timerDuration,
		formLink
	]);
	// B13: Support HH:MM:SS for exams > 1 hour
	const formatTimer = (seconds) => {
		if (seconds >= 3600) {
			const h = Math.floor(seconds / 3600);
			const m = Math.floor(seconds % 3600 / 60);
			const s = seconds % 60;
			return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
		}
		const m = Math.floor(seconds / 60), s = seconds % 60;
		return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
	};
	const handleAnswerChange = (questionId, value) => {
		setAnswers((prev) => {
			const next = {
				...prev,
				[questionId]: value
			};
			answersRef.current = next;
			try {
				localStorage.setItem(`formup_cache_${formLink}`, JSON.stringify(next));
			} catch {}
			return next;
		});
	};
	const handleCheckboxChange = (questionId, optionId, checked) => {
		setAnswers((prev) => {
			const current = Array.isArray(prev[questionId]) ? prev[questionId] : [];
			const updated = checked ? [...current, optionId] : current.filter((id) => id !== optionId);
			const next = {
				...prev,
				[questionId]: updated
			};
			answersRef.current = next;
			try {
				localStorage.setItem(`formup_cache_${formLink}`, JSON.stringify(next));
			} catch {}
			return next;
		});
	};
	const handleUnlockToken = async (e) => {
		e.preventDefault();
		setError("");
		const token = tokenInput.trim();
		const res = await getPublicFormQuestions(formLink, {
			token,
			name: respondentName
		});
		if (res.ok && res.data) {
			try {
				localStorage.setItem(`formup_token_${formLink}`, token);
			} catch {}
			setTokenUnlocked(true);
			const qList = res.data.questions || res.data || [];
			setQuestions(qList);
			questionsRef.current = qList;
			try {
				const cached = localStorage.getItem(`formup_cache_${formLink}`);
				if (cached) {
					const parsed = JSON.parse(cached);
					if (parsed) {
						setAnswers(parsed);
						answersRef.current = parsed;
					}
				}
			} catch {}
		} else {
			setError(res.message || "Token sandi akses salah.");
		}
	};
	const showValidationAlert = (msg) => {
		setValidationToast(msg);
		setTimeout(() => setValidationToast(null), 4500);
	};
	const handleSubmit = async (e, isAuto = false, skipWarnings = false) => {
		if (e && typeof e.preventDefault === "function") e.preventDefault();
		if (isPreviewMode) {
			window.close();
			return;
		}
		// B10: First check for ragu-ragu questions (only for manual submit)
		if (!isAuto && !skipWarnings && markedForReview.size > 0 && !reviewWarningOpen && !submitConfirmOpen) {
			setReviewWarningOpen(true);
			return;
		}
		setSubmitConfirmOpen(false);
		if (isSubmittingRef.current) return;
		const currentQuestions = questionsRef.current?.length ? questionsRef.current : questions;
		const currentAnswers = answersRef.current || answers;
		if (!isAuto) {
			const unanswered = currentQuestions.filter((q) => {
				if (!q.isRequired) return false;
				const val = currentAnswers[q.id];
				return q.typeId === 3 ? !(Array.isArray(val) && val.length > 0) : !(val !== undefined && val !== null && String(val).trim().length > 0);
			});
			if (unanswered.length > 0) {
				const msg = `Ada ${unanswered.length} pertanyaan wajib yang belum dijawab.`;
				showValidationAlert(msg);
				setError(msg);
				const first = unanswered[0];
				const isStep = form?.formTypeId === 2;
				if (isStep) {
					const idx = currentQuestions.findIndex((q) => q.id === first.id);
					if (idx !== -1) setCurrentStep(idx);
				} else {
					const el = document.getElementById(`question-card-${first.id}`);
					if (el) {
						el.scrollIntoView({
							behavior: "smooth",
							block: "center"
						});
						el.classList.add("ring-2", "ring-red-400");
						setTimeout(() => el.classList.remove("ring-2", "ring-red-400"), 3500);
					}
				}
				return;
			}
		}
		isSubmittingRef.current = true;
		setSubmitting(true);
		if (timerRef.current) clearInterval(timerRef.current);
		setError("");
		setValidationToast(null);
		const formattedAnswers = Object.entries(currentAnswers).map(([questionId, value]) => {
			const q = currentQuestions.find((item) => item.id === parseInt(questionId, 10));
			if (!q) return null;
			if (q.typeId === 2) {
				const p = parseInt(value, 10);
				return !isNaN(p) && p > 0 ? {
					questionId: q.id,
					optionId: p
				} : null;
			}
			if (q.typeId === 3) {
				const ids = Array.isArray(value) ? value.map((v) => parseInt(v, 10)).filter((id) => !isNaN(id) && id > 0) : [];
				return ids.length ? ids.map((id) => ({
					questionId: q.id,
					optionId: id
				})) : null;
			}
			if (q.typeId === 5) {
				const s = String(value || "").trim();
				return s ? {
					questionId: q.id,
					answerValue: s.toLowerCase() === "benar" || s.toLowerCase() === "true" ? "Benar" : "Salah"
				} : null;
			}
			const t = String(value || "").trim();
			return t ? {
				questionId: q.id,
				answerValue: t
			} : null;
		}).flat().filter(Boolean);
		try {
			const res = await submitPublicFormResponse(formLink, {
				token: tokenInput ? tokenInput.trim() : null,
				respondentName: respondentName.trim() || "Anonim",
				isAutoSubmit: Boolean(isAuto),
				IsAutoSubmit: Boolean(isAuto),
				answers: formattedAnswers,
				examSessionId: examSessionIdRef.current || null,
				tabSwitchCount: typeof tabSwitchCount === "number" ? tabSwitchCount : null
			});
			const d = res.data;
			const responseId = d?.responseId || d?.id || (typeof d === "number" || typeof d === "string" ? d : null);
			if (res.ok && responseId) {
				try {
					localStorage.removeItem(`formup_cache_${formLink}`);
					localStorage.removeItem(`formup_timer_deadline_${formLink}`);
					localStorage.removeItem(`formup_token_${formLink}`);
					localStorage.setItem(`formup_submitted_${formLink}`, String(responseId));
					sessionStorage.removeItem(`formup_exam_session_${formLink}`);
					sessionStorage.removeItem(`formup_violations_${formLink}`);
				} catch {}
				navigate(`/f/${formLink}/result/${responseId}`, { state: { guestToken: d?.guestToken || null } });
			} else {
				isSubmittingRef.current = false;
				setSubmitting(false);
				const errText = res.message || "Gagal mengirimkan respons formulir.";
				setError(errText);
				showValidationAlert(errText);
			}
		} catch {
			isSubmittingRef.current = false;
			setSubmitting(false);
			const errText = "Terjadi kesalahan koneksi saat mengirim formulir.";
			setError(errText);
			showValidationAlert(errText);
		}
	};
	const handleSendReport = async (e) => {
		e.preventDefault();
		setReportError("");
		setSubmittingReport(true);
		const res = await submitFeedback(form?.id, {
			reason: reportReason,
			description: reportDescription.trim()
		});
		setSubmittingReport(false);
		if (res.ok) {
			setReportSuccess(true);
			setReportDescription("");
			setTimeout(() => {
				setReportModalOpen(false);
				setReportSuccess(false);
			}, 2500);
		} else setReportError(res.message || "Gagal mengirimkan laporan masalah.");
	};
	if (loading) return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center justify-center min-h-screen bg-[#F4F8F7] dark:bg-slate-950",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center space-y-2",
			children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin mx-auto text-[#00897B] dark:text-teal-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 764,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-slate-400 dark:text-slate-500 text-sm font-medium",
				children: "Memuat formulir..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 765,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 763,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 762,
		columnNumber: 9
	}, this);
	if (isForceSubmitted) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen flex items-center justify-center bg-[#F4F8F7] dark:bg-slate-950 p-4 font-sans text-slate-800 dark:text-slate-100",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-8 max-w-md w-full text-center space-y-5 shadow-xl",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-16 h-16 bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center mx-auto shadow-xs",
						children: /* @__PURE__ */ _jsxDEV(Lock, { size: 32 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 775,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 774,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-extrabold text-slate-900 dark:text-white",
							children: "Sesi Ujian Selesai"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 778,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400 leading-relaxed",
							children: "Sesi ujian Anda telah diselesaikan dan dikunci oleh pengawas. Semua jawaban draf Anda telah tersimpan dengan aman di sistem."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 781,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 777,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-2",
						children: /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => navigate("/"),
							className: "w-full py-3 bg-[#00897B] hover:bg-[#00796B] text-white font-bold rounded-xl text-xs shadow-sm transition-all cursor-pointer",
							children: "Kembali ke Beranda"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 786,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 785,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 773,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 772,
			columnNumber: 13
		}, this);
	}
	// A-5: skip locked screen in preview
	const localSubmittedId = typeof window !== "undefined" ? localStorage.getItem(`formup_submitted_${formLink}`) : null;
	if (!isPreviewMode && form && form.oneResponse && (form.alreadySubmitted || localSubmittedId)) {
		const previousId = form.previousResponseId || localSubmittedId;
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen flex items-center justify-center bg-[#F4F8F7] dark:bg-slate-950 p-4 font-sans text-slate-800 dark:text-slate-100",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-8 max-w-md w-full text-center space-y-5 shadow-xl",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-16 h-16 bg-amber-50 dark:bg-amber-950/60 text-amber-500 rounded-2xl flex items-center justify-center mx-auto shadow-xs",
						children: /* @__PURE__ */ _jsxDEV(Lock, { size: 30 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 806,
							columnNumber: 159
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 806,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-extrabold text-slate-900 dark:text-white",
							children: "Formulir Terkunci"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 808,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed",
							children: [
								"Anda sudah pernah mengerjakan formulir ",
								/* @__PURE__ */ _jsxDEV("b", { children: form.title }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 809,
									columnNumber: 138
								}, this),
								". Pembuat formulir membatasi pengisian hanya ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 kali pengerjaan" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 809,
									columnNumber: 202
								}, this),
								" per responden."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 809,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 807,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-2 flex flex-col gap-2.5",
						children: [previousId && form.showScore && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => navigate(`/f/${formLink}/result/${previousId}`),
							className: "w-full py-3 bg-[#00897B] hover:bg-[#00796B] text-white font-bold rounded-xl text-xs shadow-sm transition-all cursor-pointer",
							children: "Lihat Hasil Pengerjaan Sebelumnya"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 812,
							columnNumber: 58
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => navigate(currentUser?.id ? "/dashboard" : "/login"),
							className: "w-full py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded-xl text-xs transition-all cursor-pointer",
							children: ["Kembali ke ", currentUser?.id ? "Dashboard" : "Halaman Utama"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 813,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 811,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 805,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 804,
			columnNumber: 13
		}, this);
	}
	if (error && !form) return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen flex items-center justify-center bg-[#F4F8F7] dark:bg-slate-950 p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 max-w-md w-full text-center space-y-4 shadow-xl",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "w-14 h-14 bg-red-50 dark:bg-red-950/50 text-red-500 rounded-2xl flex items-center justify-center mx-auto",
					children: /* @__PURE__ */ _jsxDEV(AlertCircle, { size: 28 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 823,
						columnNumber: 139
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 823,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-bold text-slate-900 dark:text-white",
					children: "Formulir Tidak Tersedia"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 824,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 825,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 822,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 821,
		columnNumber: 9
	}, this);
	// A-5: skip token screen in preview
	if (!isPreviewMode && !tokenUnlocked) return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen flex items-center justify-center bg-[#F4F8F7] dark:bg-slate-950 p-4 font-sans text-slate-800 dark:text-slate-100",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-8 max-w-md w-full space-y-6 shadow-xl",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center space-y-2",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-14 h-14 bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400 rounded-2xl flex items-center justify-center mx-auto shadow-xs",
							children: /* @__PURE__ */ _jsxDEV(Lock, { size: 26 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 835,
								columnNumber: 176
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 835,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-extrabold text-slate-900 dark:text-white",
							children: "Formulir Membutuhkan Sandi Akses"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 836,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400 font-medium",
							children: "Masukkan token sandi yang diberikan oleh pembuat formulir untuk mulai mengisi."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 837,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 834,
					columnNumber: 17
				}, this),
				error && /* @__PURE__ */ _jsxDEV("div", {
					className: "px-4 py-2.5 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-xl text-xs font-bold text-red-600 dark:text-red-400",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 839,
					columnNumber: 27
				}, this),
				/* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleUnlockToken,
					className: "space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "password",
						required: true,
						value: tokenInput,
						onChange: (e) => setTokenInput(e.target.value),
						placeholder: "Masukkan token sandi...",
						className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-mono font-bold bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 841,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "w-full py-3 bg-[#00897B] hover:bg-[#00796B] text-white font-bold rounded-xl text-xs shadow-sm transition-all cursor-pointer",
						children: "Buka Formulir"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 842,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 840,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 833,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 832,
		columnNumber: 9
	}, this);
	const isStepLayout = form?.formTypeId === 2 || form?.settings?.formTypeId === 2;
	const currentQ = questions[currentStep];
	const totalSteps = questions.length;
	// FEAT-4: progress
	const answeredCount = questions.filter((q) => {
		const val = answers[q.id];
		return q.typeId === 3 ? Array.isArray(val) && val.length > 0 : val !== undefined && val !== null && String(val).trim().length > 0;
	}).length;
	const progressPercent = totalSteps > 0 ? Math.round(answeredCount / totalSteps * 100) : 0;
	// B-2: theme
	const primaryColor = form?.themePrimaryColor || "#00897B";
	const bgColor = form?.themeBackgroundColor;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `min-h-screen font-sans antialiased text-slate-800 dark:text-slate-100 ${questions.length > 0 ? "pt-16" : "py-8"} pb-8 px-4 sm:px-6 transition-colors`,
		style: { backgroundColor: bgColor || undefined },
		children: [
			questions.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed top-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 px-4 sm:px-8 py-2.5 shadow-xs transition-all",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: `${isStepLayout ? "max-w-4xl lg:max-w-5xl" : "max-w-3xl"} mx-auto flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5`,
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "truncate mr-3",
						children: [
							form?.title ? `${form.title} — ` : "",
							answeredCount,
							" dari ",
							totalSteps,
							" soal terjawab"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 870,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "shrink-0 font-mono",
						style: { color: primaryColor },
						children: [progressPercent, "%"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 871,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 869,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: `${isStepLayout ? "max-w-4xl lg:max-w-5xl" : "max-w-3xl"} mx-auto w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden`,
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "h-full rounded-full transition-all duration-300",
						style: {
							width: `${progressPercent}%`,
							backgroundColor: primaryColor
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 874,
						columnNumber: 25
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 873,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 868,
				columnNumber: 17
			}, this),
			!isOnline && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed top-14 sm:top-16 right-4 sm:right-6 z-50 bg-amber-500 text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2.5 max-w-sm border border-amber-400 font-bold text-xs animate-pulse",
				children: [/* @__PURE__ */ _jsxDEV(WifiOff, {
					size: 16,
					className: "shrink-0"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 882,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", { children: "Koneksi Terputus / Buruk" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 884,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-[10px] font-normal opacity-90",
					children: [answeredCount, " jawaban tersimpan aman di perangkat."]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 885,
					columnNumber: 25
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 883,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 881,
				columnNumber: 17
			}, this),
			isOnline && showRestoredToast && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed top-14 sm:top-16 right-4 sm:right-6 z-50 bg-emerald-600 text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2.5 max-w-sm border border-emerald-500 font-bold text-xs",
				children: [/* @__PURE__ */ _jsxDEV(Wifi, {
					size: 16,
					className: "shrink-0"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 893,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", { children: "Koneksi Pulih" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 895,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-[10px] font-normal opacity-90",
					children: "Semua jawaban berhasil disinkronisasi!"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 896,
					columnNumber: 25
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 894,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 892,
				columnNumber: 17
			}, this),
			tabSwitchWarning && (form?.detectTabSwitch || form?.isExamMode) && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-red-600 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 max-w-md w-[92vw]",
				children: [
					/* @__PURE__ */ _jsxDEV(AlertCircle, {
						size: 18,
						className: "shrink-0"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 904,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-extrabold",
							children: "Peringatan: Terdeteksi aktivitas keluar / pelanggaran mode ujian!"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 906,
							columnNumber: 25
						}, this), form.maxTabSwitch ? /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] opacity-90",
							children: [
								"Pindah Tab: ",
								tabSwitchCount,
								"/",
								form.maxTabSwitch,
								" ",
								violationCount > tabSwitchCount ? `• Total Pelanggaran: ${violationCount}` : ""
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 908,
							columnNumber: 29
						}, this) : /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] opacity-90",
							children: [
								"Pindah Tab: ",
								tabSwitchCount,
								" ",
								violationCount > tabSwitchCount ? `• Total Pelanggaran: ${violationCount}` : ""
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 910,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 905,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setTabSwitchWarning(false),
						className: "p-1 hover:bg-white/20 rounded cursor-pointer",
						children: /* @__PURE__ */ _jsxDEV(X, { size: 15 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 913,
							columnNumber: 129
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 913,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 903,
				columnNumber: 17
			}, this),
			validationToast && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed top-5 left-1/2 -translate-x-1/2 z-50 max-w-md w-[92vw] sm:w-auto bg-red-600 dark:bg-red-700 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center justify-between gap-3 border border-red-500 animate-in fade-in slide-in-from-top-3 duration-200",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
						size: 18,
						className: "shrink-0 text-white"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 920,
						columnNumber: 64
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs sm:text-sm font-bold",
						children: validationToast
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 920,
						columnNumber: 121
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 920,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setValidationToast(null),
					className: "p-1 text-white/80 hover:text-white rounded-lg cursor-pointer shrink-0",
					children: /* @__PURE__ */ _jsxDEV(X, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 921,
						columnNumber: 166
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 921,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 919,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: `${isStepLayout ? "max-w-4xl lg:max-w-5xl" : "max-w-3xl"} mx-auto space-y-6 transition-all`,
				children: [
					isPreviewMode && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 rounded-2xl px-4 py-3 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-amber-700 dark:text-amber-300 text-xs font-bold",
							children: [/* @__PURE__ */ _jsxDEV(Eye, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 930,
								columnNumber: 119
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Mode Preview — Jawaban tidak akan disimpan" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 930,
								columnNumber: 136
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 930,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => window.close(),
							className: "text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline cursor-pointer",
							children: "Tutup Preview"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 931,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 929,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between gap-3 flex-wrap",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: toggleDarkMode,
								className: "p-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 shadow-xs transition-all flex items-center gap-1.5 text-xs font-bold cursor-pointer",
								children: [isDarkMode ? /* @__PURE__ */ _jsxDEV(Sun, {
									size: 15,
									className: "text-amber-400"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 939,
									columnNumber: 43
								}, this) : /* @__PURE__ */ _jsxDEV(Moon, {
									size: 15,
									className: "text-teal-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 939,
									columnNumber: 90
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDarkMode ? "Mode Terang" : "Mode Gelap" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 940,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 938,
								columnNumber: 25
							}, this), !isPreviewMode && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setReportModalOpen(true),
								className: "p-2.5 rounded-2xl border border-amber-200 dark:border-amber-900/60 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 hover:bg-amber-100 shadow-xs transition-all flex items-center gap-1.5 text-xs font-bold cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 945,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Laporkan Masalah" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 945,
									columnNumber: 60
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 944,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 937,
							columnNumber: 21
						}, this), timeLeft !== null && /* @__PURE__ */ _jsxDEV("div", {
							className: `px-4 py-2 rounded-2xl shadow-lg border backdrop-blur-md flex items-center gap-2 font-mono font-bold text-xs sm:text-sm ${timeLeft <= 60 ? "bg-red-500/90 text-white border-red-400 animate-pulse" : timeLeft <= 300 ? "bg-amber-500/90 text-white border-amber-400" : "bg-slate-900/90 dark:bg-slate-800/90 text-teal-400 border-slate-700"}`,
							children: [/* @__PURE__ */ _jsxDEV(Clock, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 957,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Waktu: ", formatTimer(timeLeft)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 957,
								columnNumber: 48
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 950,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 936,
						columnNumber: 17
					}, this),
					timeLeft !== null && form?.timerDuration > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "w-full h-1 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden mb-4",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: `h-full rounded-full transition-all duration-1000 ${timeLeft <= 60 ? "bg-red-500" : timeLeft <= 300 ? "bg-amber-500" : "bg-teal-500"}`,
							style: { width: `${Math.max(0, timeLeft / form.timerDuration * 100)}%` }
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 965,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 964,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm",
						children: [form?.bannerImage && /* @__PURE__ */ _jsxDEV("div", {
							className: "w-full h-44 sm:h-56 relative bg-slate-100 dark:bg-slate-800 overflow-hidden",
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: assetUrl(form.bannerImage),
								alt: form.title,
								className: "w-full h-full object-cover"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 978,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 977,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 sm:p-8 space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("h1", {
									className: "text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight break-words",
									children: form?.title || "Formulir"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 983,
									columnNumber: 29
								}, this), form?.description && /* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 text-slate-600 dark:text-slate-300 text-sm leading-relaxed break-words break-all [overflow-wrap:anywhere]",
									children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: form.description }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 984,
										columnNumber: 179
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 984,
									columnNumber: 51
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 982,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pt-4 border-t border-slate-100 dark:border-slate-800 space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300 block",
									children: "Nama Anda (Opsional):"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 987,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: respondentName,
									onChange: (e) => setRespondentName(e.target.value),
									placeholder: "Masukkan nama lengkap Anda...",
									className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-semibold bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 988,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 986,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 981,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 975,
						columnNumber: 17
					}, this),
					error && /* @__PURE__ */ _jsxDEV("div", {
						className: "px-5 py-3.5 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-2xl text-xs font-bold text-red-600 dark:text-red-400 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 995,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: error }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 995,
							columnNumber: 50
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 994,
						columnNumber: 21
					}, this),
					isStepLayout && currentQ ? /* @__PURE__ */ _jsxDEV("div", {
						id: `question-card-${currentQ.id}`,
						className: "bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 sm:p-10 lg:p-12 shadow-sm space-y-8 transition-all",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2.5",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs sm:text-sm font-bold px-3.5 py-1.5 rounded-full",
										style: {
											backgroundColor: `${primaryColor}18`,
											color: primaryColor
										},
										children: [
											"Soal ",
											currentStep + 1,
											" dari ",
											totalSteps
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1004,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setNavPopupOpen(true),
										title: "Navigasi soal cepat",
										className: "p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all cursor-pointer",
										children: /* @__PURE__ */ _jsxDEV(LayoutGrid, { size: 15 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1009,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1008,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1003,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [currentQ.isRequired && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-red-500 bg-red-50 dark:bg-red-950/60 px-2.5 py-0.5 rounded-md",
										children: "Wajib"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1013,
										columnNumber: 57
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setMarkedForReview((prev) => {
											const next = new Set(prev);
											if (next.has(currentQ.id)) next.delete(currentQ.id);
											else next.add(currentQ.id);
											return next;
										}),
										className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${markedForReview.has(currentQ.id) ? "bg-yellow-400 dark:bg-yellow-500 text-white border-yellow-400 dark:border-yellow-500" : "bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-yellow-400"}`,
										children: [markedForReview.has(currentQ.id) ? /* @__PURE__ */ _jsxDEV(BookmarkCheck, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1022,
											columnNumber: 73
										}, this) : /* @__PURE__ */ _jsxDEV(Bookmark, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1022,
											columnNumber: 103
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: markedForReview.has(currentQ.id) ? "Ragu-ragu" : "Tandai" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1023,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1015,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1012,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1002,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-6",
								children: [
									currentQ.questionImage && /* @__PURE__ */ _jsxDEV("div", {
										className: "my-2 w-full max-w-2xl relative group/img overflow-hidden rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 p-2 shadow-xs mx-auto",
										children: [/* @__PURE__ */ _jsxDEV("img", {
											src: assetUrl(currentQ.questionImage),
											alt: "Gambar Soal",
											className: "max-h-96 sm:max-h-[440px] w-auto max-w-full rounded-xl object-contain mx-auto cursor-zoom-in",
											onClick: () => setLightboxImage({
												src: assetUrl(currentQ.questionImage),
												alt: "Gambar Soal"
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1031,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setLightboxImage({
												src: assetUrl(currentQ.questionImage),
												alt: "Gambar Soal"
											}),
											className: "absolute bottom-3 right-3 p-2 bg-slate-900/80 hover:bg-slate-900 text-white rounded-xl shadow-md text-xs font-bold flex items-center gap-1 opacity-0 group-hover/img:opacity-100 transition-opacity cursor-pointer",
											children: [/* @__PURE__ */ _jsxDEV(Maximize2, { size: 13 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1032,
												columnNumber: 378
											}, this), " Perbesar"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1032,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1030,
										columnNumber: 33
									}, this),
									currentQ.questionAudio && /* @__PURE__ */ _jsxDEV("div", {
										className: "my-2 max-w-md w-full bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs",
										children: /* @__PURE__ */ _jsxDEV("audio", {
											controls: true,
											src: assetUrl(currentQ.questionAudio),
											className: "w-full h-8 rounded-xl outline-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1037,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1036,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-base sm:text-lg lg:text-xl font-bold text-slate-900 dark:text-white leading-relaxed break-words break-all [overflow-wrap:anywhere]",
										children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: currentQ.question }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1041,
											columnNumber: 33
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1040,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pt-2",
										children: renderAnswerField(currentQ, answers, handleAnswerChange, handleCheckboxChange, primaryColor, setLightboxImage)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1043,
										columnNumber: 29
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1028,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setCurrentStep((prev) => Math.max(prev - 1, 0)),
									disabled: currentStep === 0,
									className: "px-4 py-2.5 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1048,
										columnNumber: 33
									}, this), " Sebelumnya"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1047,
									columnNumber: 29
								}, this), currentStep < totalSteps - 1 ? /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setCurrentStep((prev) => prev + 1),
									className: "px-5 py-2.5 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer",
									style: { backgroundColor: primaryColor },
									children: ["Selanjutnya ", /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1052,
										columnNumber: 49
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1051,
									columnNumber: 33
								}, this) : 
								// A-4: In preview mode, show "Selesai Preview" instead of submit
isPreviewMode ? /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => window.close(),
									className: "px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-2 cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(Eye, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1058,
										columnNumber: 41
									}, this), " Selesai Preview"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1057,
									columnNumber: 37
								}, this) : /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: (e) => handleSubmit(e, false),
									disabled: submitting,
									className: "px-6 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-teal-600 dark:hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-60",
									children: [
										/* @__PURE__ */ _jsxDEV(Send, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1062,
											columnNumber: 41
										}, this),
										" ",
										submitting ? "Mengirimkan..." : "Kirim Formulir"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1061,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1046,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1001,
						columnNumber: 21
					}, this) : 
					// ── SCROLL LAYOUT ──
/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: (e) => handleSubmit(e, false),
						className: "space-y-5",
						children: [questions.map((q, idx) => /* @__PURE__ */ _jsxDEV("div", {
							id: `question-card-${q.id}`,
							className: "bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-5 sm:p-8 shadow-sm space-y-4 transition-all",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-2.5",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "shrink-0 w-7 h-7 flex items-center justify-center rounded-xl text-xs font-bold text-white",
										style: { backgroundColor: primaryColor },
										children: idx + 1
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1074,
										columnNumber: 37
									}, this), q.isRequired && /* @__PURE__ */ _jsxDEV("span", {
										className: "shrink-0 text-[11px] font-extrabold text-red-500 bg-red-50 dark:bg-red-950/60 px-2 py-0.5 rounded-md",
										children: "Wajib"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1075,
										columnNumber: 54
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1073,
									columnNumber: 33
								}, this),
								q.questionImage && /* @__PURE__ */ _jsxDEV("div", {
									className: "my-2 w-full max-w-2xl relative group/img overflow-hidden rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 p-2 shadow-xs mx-auto",
									children: [/* @__PURE__ */ _jsxDEV("img", {
										src: assetUrl(q.questionImage),
										alt: "Gambar Soal",
										className: "max-h-96 sm:max-h-[440px] w-auto max-w-full rounded-xl object-contain mx-auto cursor-zoom-in",
										onClick: () => setLightboxImage({
											src: assetUrl(q.questionImage),
											alt: "Gambar Soal"
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1079,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setLightboxImage({
											src: assetUrl(q.questionImage),
											alt: "Gambar Soal"
										}),
										className: "absolute bottom-3 right-3 p-2 bg-slate-900/80 hover:bg-slate-900 text-white rounded-xl shadow-md text-xs font-bold flex items-center gap-1 opacity-0 group-hover/img:opacity-100 transition-opacity cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV(Maximize2, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1080,
											columnNumber: 375
										}, this), " Perbesar"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1080,
										columnNumber: 41
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1078,
									columnNumber: 37
								}, this),
								q.questionAudio && /* @__PURE__ */ _jsxDEV("div", {
									className: "my-2 max-w-md w-full bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs",
									children: /* @__PURE__ */ _jsxDEV("audio", {
										controls: true,
										src: assetUrl(q.questionAudio),
										className: "w-full h-8 rounded-xl outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1083,
										columnNumber: 201
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1083,
									columnNumber: 53
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-relaxed break-words break-all [overflow-wrap:anywhere]",
									children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: q.question }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1084,
										columnNumber: 175
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1084,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2",
									children: renderAnswerField(q, answers, handleAnswerChange, handleCheckboxChange, primaryColor, setLightboxImage)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1085,
									columnNumber: 33
								}, this)
							]
						}, q.id || idx, true, {
							fileName: _jsxFileName,
							lineNumber: 1072,
							columnNumber: 29
						}, this)), /* @__PURE__ */ _jsxDEV("div", {
							className: "pt-4 flex justify-end",
							children: isPreviewMode ? /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => window.close(),
								className: "w-full sm:w-auto px-8 py-3.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-2xl shadow-md transition-all text-sm flex items-center justify-center gap-2 cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(Eye, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1093,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Selesai Preview" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1094,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1091,
								columnNumber: 33
							}, this) : /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								disabled: submitting,
								className: "w-full sm:w-auto px-8 py-3.5 text-white font-bold rounded-2xl shadow-md transition-all text-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60",
								style: { backgroundColor: primaryColor },
								children: [/* @__PURE__ */ _jsxDEV(Send, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1100,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: submitting ? "Mengirimkan Respons..." : "Kirim Respons Formulir" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1101,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1097,
								columnNumber: 33
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1088,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1070,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 925,
				columnNumber: 13
			}, this),
			navPopupOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-black/50 backdrop-blur-xs",
					onClick: () => setNavPopupOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1112,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 max-w-sm w-full shadow-2xl z-10",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between mb-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(LayoutGrid, {
									size: 16,
									className: "text-teal-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1115,
									columnNumber: 118
								}, this), " Navigasi Soal"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1115,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setNavPopupOpen(false),
								className: "p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1116,
									columnNumber: 169
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1116,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1114,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3 mb-3 flex-wrap text-[11px] font-medium text-slate-500 dark:text-slate-400",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded bg-emerald-500 inline-block" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1119,
										columnNumber: 71
									}, this), " Terjawab"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1119,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded bg-slate-200 dark:bg-slate-700 inline-block" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1120,
										columnNumber: 71
									}, this), " Belum"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1120,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded bg-yellow-400 inline-block" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1121,
										columnNumber: 71
									}, this), " Ragu-ragu"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1121,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1118,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-5 gap-2",
							children: questions.map((q, qIdx) => {
								const isAnswered = (() => {
									const val = answers[q.id];
									return q.typeId === 3 ? Array.isArray(val) && val.length > 0 : val !== undefined && val !== null && String(val).trim().length > 0;
								})();
								const isActive = qIdx === currentStep;
								const isMarked = markedForReview.has(q.id);
								return /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setCurrentStep(qIdx);
										setNavPopupOpen(false);
									},
									className: `relative w-full aspect-square rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center ${isActive ? "text-white ring-2 ring-offset-1 ring-teal-500" : isMarked ? "bg-yellow-400 text-white" : isAnswered ? "bg-emerald-500 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
									style: isActive ? { backgroundColor: primaryColor } : {},
									children: [qIdx + 1, isMarked && !isActive && /* @__PURE__ */ _jsxDEV("span", { className: "absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-yellow-400 rounded-full border-2 border-white dark:border-slate-900" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1143,
										columnNumber: 45
									}, this)]
								}, q.id || qIdx, true, {
									fileName: _jsxFileName,
									lineNumber: 1129,
									columnNumber: 37
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1123,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1113,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1111,
				columnNumber: 17
			}, this),
			reportModalOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-black/60 backdrop-blur-xs",
					onClick: () => setReportModalOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1156,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4 z-10 animate-in fade-in zoom-in-95 duration-200",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-amber-500 font-extrabold text-sm",
							children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1159,
								columnNumber: 108
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Laporkan Masalah Formulir" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1159,
								columnNumber: 135
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1159,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setReportModalOpen(false),
							className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1160,
								columnNumber: 197
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1160,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1158,
						columnNumber: 25
					}, this), reportSuccess ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1163,
							columnNumber: 230
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Laporan masalah Anda telah terkirim. Terima kasih!" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1163,
							columnNumber: 256
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1163,
						columnNumber: 29
					}, this) : /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSendReport,
						className: "space-y-4",
						children: [
							reportError && /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-xl text-xs font-bold text-red-600 dark:text-red-400",
								children: reportError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1166,
								columnNumber: 49
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5",
								children: "Alasan Masalah"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1168,
								columnNumber: 37
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: reportReason,
								onChange: (e) => setReportReason(e.target.value),
								className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "PERTANYAAN_TIDAK_JELAS",
										children: "Pertanyaan tidak jelas / rancu"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1170,
										columnNumber: 41
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "KUNCI_JAWABAN_SALAH",
										children: "Kunci jawaban / opsi salah"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1171,
										columnNumber: 41
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "KENDALA_TEKNIS",
										children: "Kendala teknis / media tidak tampil"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1172,
										columnNumber: 41
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "KONTEN_TIDAK_PANTAS",
										children: "Konten tidak pantas"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1173,
										columnNumber: 41
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "LAINNYA",
										children: "Alasan lainnya"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1174,
										columnNumber: 41
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1169,
								columnNumber: 37
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1167,
								columnNumber: 33
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5",
								children: "Deskripsi Kendala (Opsional)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1178,
								columnNumber: 37
							}, this), /* @__PURE__ */ _jsxDEV("textarea", {
								rows: 3,
								value: reportDescription,
								onChange: (e) => setReportDescription(e.target.value),
								placeholder: "Ceritakan detail kendala yang dialami...",
								className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1179,
								columnNumber: 37
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1177,
								columnNumber: 33
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end gap-2 pt-1",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setReportModalOpen(false),
									className: "px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer",
									children: "Batal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1182,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: submittingReport,
									className: "px-5 py-2 bg-[#00897B] hover:bg-[#00796B] text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-60",
									children: [/* @__PURE__ */ _jsxDEV(Send, { size: 13 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1183,
										columnNumber: 252
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: submittingReport ? "Mengirim..." : "Kirim Laporan" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1183,
										columnNumber: 270
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1183,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1181,
								columnNumber: 33
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1165,
						columnNumber: 29
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1157,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1155,
				columnNumber: 17
			}, this),
			reviewWarningOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-black/60 backdrop-blur-xs",
					onClick: () => setReviewWarningOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1194,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl space-y-4 z-10",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-2.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-500",
								children: /* @__PURE__ */ _jsxDEV(Bookmark, { size: 20 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1197,
									columnNumber: 113
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1197,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("h3", {
								className: "text-base font-bold text-slate-900 dark:text-white",
								children: "Ada Soal Ragu-Ragu"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1198,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1196,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-slate-500 dark:text-slate-400",
							children: [
								"Kamu masih menandai ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold text-amber-600 dark:text-amber-400",
									children: [markedForReview.size, " soal"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1201,
									columnNumber: 49
								}, this),
								" sebagai ragu-ragu. Ingin meninjau dulu sebelum mengirim?"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1200,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setReviewWarningOpen(false);
									const firstMarkedId = [...markedForReview][0];
									if (firstMarkedId) {
										const el = document.getElementById(`question-card-${firstMarkedId}`);
										if (el) el.scrollIntoView({
											behavior: "smooth",
											block: "center"
										});
									}
								},
								className: "flex-1 px-4 py-2.5 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-950/60 text-amber-700 dark:text-amber-300 text-xs font-bold rounded-xl cursor-pointer",
								children: "Tinjau Soal Ragu-Ragu"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1204,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setReviewWarningOpen(false);
									handleSubmit(null, false, true);
								},
								className: "flex-1 px-4 py-2.5 text-white text-xs font-bold rounded-xl cursor-pointer",
								style: { backgroundColor: primaryColor },
								children: "Tetap Kirim"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1216,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1203,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1195,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1193,
				columnNumber: 17
			}, this),
			submitConfirmOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-black/60 backdrop-blur-xs",
					onClick: () => setSubmitConfirmOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1233,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl space-y-4 z-10",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-2.5 rounded-full bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400",
								children: /* @__PURE__ */ _jsxDEV(Send, { size: 20 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1236,
									columnNumber: 130
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1236,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("h3", {
								className: "text-base font-bold text-slate-900 dark:text-white",
								children: "Kirim Jawaban?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1237,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1235,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-slate-500 dark:text-slate-400",
							children: "Jawaban tidak dapat diubah setelah dikirim. Apakah Anda yakin?"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1239,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSubmitConfirmOpen(false),
								className: "flex-1 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl cursor-pointer",
								children: "Batal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1241,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => handleSubmit(null, false),
								className: "flex-1 px-4 py-2.5 text-white text-xs font-bold rounded-xl cursor-pointer",
								style: { backgroundColor: primaryColor },
								children: "Ya, Kirim"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1242,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1240,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1234,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1232,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV(ImageLightboxModal, {
				isOpen: !!lightboxImage,
				src: lightboxImage?.src,
				alt: lightboxImage?.alt,
				onClose: () => setLightboxImage(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1248,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 864,
		columnNumber: 9
	}, this);
}
_s(FormRunnerPage, "nwgKUDxjVU/CG1KXMrCZeOLYr+w=", false, function() {
	return [
		useParams,
		useNavigate,
		useSearchParams
	];
});
_c = FormRunnerPage;
function renderAnswerField(q, answers, handleAnswerChange, handleCheckboxChange, primaryColor = "#00897B", onOpenImage = null) {
	const val = answers[q.id];
	if (q.typeId === 1) return /* @__PURE__ */ _jsxDEV("textarea", {
		rows: 3,
		value: val || "",
		onChange: (e) => handleAnswerChange(q.id, e.target.value),
		placeholder: "Ketikkan jawaban Anda di sini...",
		className: "w-full border border-slate-200 dark:border-slate-700 rounded-2xl p-3.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 1257,
		columnNumber: 9
	}, this);
	if (q.typeId === 2) return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-2.5",
		children: (q.options || []).map((opt) => {
			const isSelected = String(val) === String(opt.id);
			const optImg = opt.optionImage || opt.image || opt.imageUrl;
			return /* @__PURE__ */ _jsxDEV("label", {
				className: `flex items-start gap-3 p-3.5 rounded-2xl border transition-all cursor-pointer ${isSelected ? "font-bold" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50"}`,
				style: isSelected ? {
					borderColor: primaryColor,
					backgroundColor: `${primaryColor}18`,
					color: primaryColor
				} : {},
				children: [/* @__PURE__ */ _jsxDEV("input", {
					type: "radio",
					name: `q_${q.id}`,
					value: opt.id,
					checked: isSelected,
					onChange: () => handleAnswerChange(q.id, opt.id),
					className: "w-4 h-4 cursor-pointer mt-0.5",
					style: { accentColor: primaryColor }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1268,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "text-xs sm:text-sm leading-relaxed flex-1 space-y-2",
					children: [optImg && /* @__PURE__ */ _jsxDEV("img", {
						src: assetUrl(optImg),
						alt: opt.optionText || "Gambar Opsi",
						className: "max-h-48 max-w-full rounded-xl object-contain border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-1 cursor-zoom-in",
						onClick: (event) => {
							event.preventDefault();
							event.stopPropagation();
							onOpenImage?.({
								src: assetUrl(optImg),
								alt: opt.optionText || "Gambar Opsi"
							});
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1271,
						columnNumber: 33
					}, this), /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: opt.optionText }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1282,
						columnNumber: 29
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1269,
					columnNumber: 25
				}, this)]
			}, opt.id, true, {
				fileName: _jsxFileName,
				lineNumber: 1266,
				columnNumber: 21
			}, this);
		})
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 1261,
		columnNumber: 9
	}, this);
	if (q.typeId === 3) {
		const selectedArr = Array.isArray(val) ? val : [];
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "space-y-2.5",
			children: (q.options || []).map((opt) => {
				const isChecked = selectedArr.includes(opt.id);
				const optImg = opt.optionImage || opt.image || opt.imageUrl;
				return /* @__PURE__ */ _jsxDEV("label", {
					className: `flex items-start gap-3 p-3.5 rounded-2xl border transition-all cursor-pointer ${isChecked ? "font-bold" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50"}`,
					style: isChecked ? {
						borderColor: primaryColor,
						backgroundColor: `${primaryColor}18`,
						color: primaryColor
					} : {},
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "checkbox",
						checked: isChecked,
						onChange: (e) => handleCheckboxChange(q.id, opt.id, e.target.checked),
						className: "w-4 h-4 rounded cursor-pointer mt-0.5",
						style: { accentColor: primaryColor }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1300,
						columnNumber: 29
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs sm:text-sm leading-relaxed flex-1 space-y-2",
						children: [optImg && /* @__PURE__ */ _jsxDEV("img", {
							src: assetUrl(optImg),
							alt: opt.optionText || "Gambar Opsi",
							className: "max-h-48 max-w-full rounded-xl object-contain border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-1 cursor-zoom-in",
							onClick: (event) => {
								event.preventDefault();
								event.stopPropagation();
								onOpenImage?.({
									src: assetUrl(optImg),
									alt: opt.optionText || "Gambar Opsi"
								});
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1303,
							columnNumber: 37
						}, this), /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: opt.optionText }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1314,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1301,
						columnNumber: 29
					}, this)]
				}, opt.id, true, {
					fileName: _jsxFileName,
					lineNumber: 1298,
					columnNumber: 25
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 1293,
			columnNumber: 13
		}, this);
	}
	if (q.typeId === 4) return /* @__PURE__ */ _jsxDEV("input", {
		type: q.includeTime ? "datetime-local" : "date",
		value: val || "",
		onChange: (e) => handleAnswerChange(q.id, e.target.value),
		className: "w-full max-w-xs border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-semibold bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 1324,
		columnNumber: 9
	}, this);
	if (q.typeId === 5) return /* @__PURE__ */ _jsxDEV("div", {
		className: "grid grid-cols-2 gap-3 max-w-sm",
		children: [{
			value: "Benar",
			label: "Benar"
		}, {
			value: "Salah",
			label: "Salah"
		}].map((choice) => {
			const isSelected = String(val) === choice.value;
			return /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => handleAnswerChange(q.id, choice.value),
				className: `py-3 px-4 rounded-2xl border text-xs font-bold transition-all cursor-pointer ${isSelected ? "text-white shadow-xs" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50"}`,
				style: isSelected ? {
					backgroundColor: primaryColor,
					borderColor: primaryColor
				} : {},
				children: choice.label
			}, choice.value, false, {
				fileName: _jsxFileName,
				lineNumber: 1337,
				columnNumber: 21
			}, this);
		})
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 1333,
		columnNumber: 9
	}, this);
	return null;
}
var _c;
$RefreshReg$(_c, "FormRunnerPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/form-runner/FormRunnerPage.jsx?t=1789530336151";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-runner/FormRunnerPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-runner/FormRunnerPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-runner/FormRunnerPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsUUFBUSxtQkFBbUI7QUFDekQsU0FBUyxXQUFXLGFBQWEsdUJBQXVCO0FBQ3hELFNBQ0ksT0FBTyxNQUFNLFlBQVksV0FDekIsYUFBYSxNQUFNLFNBQVMsV0FDNUIsS0FBSyxNQUFNLGVBQWUsR0FBRyxjQUFjLFVBQVUsZUFBZSxLQUNwRSxZQUFZLE1BQU0sZUFDZjtBQUNQLFNBQ0kscUJBQXFCLHdCQUF3QiwwQkFDN0MsZ0JBQWdCLGNBQWMsVUFBVSxjQUN4QyxhQUFhLGNBQWMsWUFBWSxlQUN2Qyx1QkFDRztBQUNQLE9BQU8seUJBQXlCO0FBQ2hDLE9BQU8sd0JBQXdCOzs7O0FBRS9CLGVBQWUsU0FBUyxpQkFBaUI7O0NBQ3JDLE1BQU0sRUFBRSxhQUFhLFVBQVU7Q0FDL0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLGdCQUFnQixnQkFBZ0I7Q0FDdkMsTUFBTSxnQkFBZ0IsYUFBYSxJQUFJLFNBQVMsTUFBTTtDQUV0RCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsSUFBSTtDQUNyQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDLENBQUM7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7Q0FFM0QsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLO0NBQ3hELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTs7OztDQUl2RCxNQUFNLG9CQUFvQixPQUFPLEVBQUU7O0NBR25DLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsSUFBSSxJQUFJLENBQUM7O0NBRWhFLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7O0NBRXRELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsS0FBSzs7Q0FFaEUsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxLQUFLOztDQUVoRSxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLENBQUM7Q0FDdEQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxDQUFDO0NBQ3RELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLHFCQUFxQixPQUFPLENBQUM7Ozs7OztDQU9uQyxNQUFNLHFCQUFxQixrQkFBa0I7RUFDekMsSUFBSSxPQUFPLFdBQVcsYUFBYSxPQUFPO0VBQzFDLElBQUk7R0FDQSxPQUFPLGVBQWUsUUFBUSx1QkFBdUIsVUFBVTtFQUNuRSxRQUFRO0dBQ0osT0FBTztFQUNYO0NBQ0osR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUNiLE1BQU0sbUJBQW1CLE9BQU8sSUFBSTtDQUNwQyxJQUFJLENBQUMsaUJBQWlCLFdBQVcsT0FBTyxXQUFXLGFBQWE7RUFDNUQsaUJBQWlCLFVBQVUsbUJBQW1CO0NBQ2xEO0NBRUEsTUFBTSxDQUFDLFNBQVMsY0FBYyxlQUFlO0VBQ3pDLElBQUksT0FBTyxXQUFXLGFBQWE7R0FDL0IsSUFBSTtJQUNBLE1BQU0sU0FBUyxhQUFhLFFBQVEsZ0JBQWdCLFVBQVU7SUFDOUQsSUFBSSxRQUFRO0tBQ1IsTUFBTSxTQUFTLEtBQUssTUFBTSxNQUFNO0tBQ2hDLElBQUksVUFBVSxPQUFPLFdBQVcsVUFBVSxPQUFPO0lBQ3JEO0dBQ0osUUFBUSxDQUFDO0VBQ2I7RUFDQSxPQUFPLENBQUM7Q0FDWixDQUFDO0NBQ0QsTUFBTSxhQUFhLE9BQU8sT0FBTztDQUNqQyxNQUFNLGVBQWUsT0FBTyxTQUFTO0NBRXJDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLENBQUM7Q0FDaEQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsSUFBSTtDQUV2RCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEtBQUs7Q0FDNUQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsd0JBQXdCO0NBQ3pFLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsRUFBRTtDQUM3RCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEtBQUs7Q0FDOUQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUN4RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBRWpELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxJQUFJO0NBQzdDLE1BQU0sV0FBVyxPQUFPLElBQUk7Q0FDNUIsTUFBTSxrQkFBa0IsT0FBTyxLQUFLO0NBRXBDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixlQUFlO0VBQy9DLElBQUksT0FBTyxXQUFXLGFBQWE7R0FDL0IsT0FBTyxTQUFTLGdCQUFnQixVQUFVLFNBQVMsTUFBTSxLQUFLLGFBQWEsUUFBUSxPQUFPLE1BQU07RUFDcEc7RUFDQSxPQUFPO0NBQ1gsQ0FBQztDQUVELE1BQU0sdUJBQXVCO0VBQ3pCLGVBQWMsU0FBUTtHQUNsQixNQUFNLE9BQU8sQ0FBQztHQUNkLElBQUksTUFBTTtJQUFFLFNBQVMsZ0JBQWdCLFVBQVUsSUFBSSxNQUFNO0lBQUcsYUFBYSxRQUFRLFNBQVMsTUFBTTtHQUFHLE9BQzlGO0lBQUUsU0FBUyxnQkFBZ0IsVUFBVSxPQUFPLE1BQU07SUFBRyxhQUFhLFFBQVEsU0FBUyxPQUFPO0dBQUc7R0FDbEcsT0FBTztFQUNYLENBQUM7Q0FDTDtDQUVBLE1BQU0saUJBQWlCLE9BQU8sYUFBYSxDQUFDO0NBQzVDLE1BQU0sY0FBYyxlQUFlO0NBRW5DLE1BQU0sa0JBQWtCLE9BQU8sQ0FBQztDQUVoQyxnQkFBZ0I7RUFBRSxrQkFBa0IsVUFBVTtDQUFnQixHQUFHLENBQUMsY0FBYyxDQUFDOztDQUdqRixNQUFNLENBQUMsVUFBVSxlQUFlLGVBQWUsT0FBTyxXQUFXLGNBQWMsT0FBTyxVQUFVLFNBQVMsSUFBSTtDQUM3RyxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FFaEUsZ0JBQWdCO0VBQ1osTUFBTSxxQkFBcUI7R0FDdkIsWUFBWSxJQUFJO0dBQ2hCLHFCQUFxQixJQUFJO0dBQ3pCLGlCQUFpQixxQkFBcUIsS0FBSyxHQUFHLEdBQUk7R0FDbEQsSUFBSSxRQUFRLFdBQVcsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsR0FBRztJQUNwRCxNQUFNLE1BQU0saUJBQWlCLFdBQVcsbUJBQW1CO0lBQzNELElBQUksS0FBSztLQUNMLGdCQUFnQixVQUFVLEtBQUssT0FBTyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDMUQ7R0FDSjtFQUNKO0VBQ0EsTUFBTSxzQkFBc0I7R0FDeEIsWUFBWSxLQUFLO0VBQ3JCO0VBRUEsT0FBTyxpQkFBaUIsVUFBVSxZQUFZO0VBQzlDLE9BQU8saUJBQWlCLFdBQVcsYUFBYTtFQUNoRCxhQUFhO0dBQ1QsT0FBTyxvQkFBb0IsVUFBVSxZQUFZO0dBQ2pELE9BQU8sb0JBQW9CLFdBQVcsYUFBYTtFQUN2RDtDQUNKLEdBQUc7RUFBQztFQUFNO0VBQVM7RUFBVTtDQUFrQixDQUFDOztDQUdoRCxnQkFBZ0I7RUFDWixJQUFJLFlBQVksT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsR0FBRztHQUM3QyxJQUFJO0lBQUUsYUFBYSxRQUFRLGdCQUFnQixZQUFZLEtBQUssVUFBVSxPQUFPLENBQUM7R0FBRyxRQUFRLENBQUM7RUFDOUY7Q0FDSixHQUFHLENBQUMsU0FBUyxRQUFRLENBQUM7O0NBR3RCLGdCQUFnQjtFQUNaLElBQUksQ0FBQyxNQUFNO0VBQ1gsTUFBTSxPQUFPLFNBQVM7RUFDdEIsSUFBSSxLQUFLLG1CQUFtQixLQUFLLE1BQU0sWUFBWSxrQkFBa0IsS0FBSyxpQkFBaUI7RUFDM0YsSUFBSSxLQUFLLHNCQUFzQixLQUFLLE1BQU0sWUFBWSxhQUFhLEtBQUssb0JBQW9CO0VBQzVGLGFBQWE7R0FBRSxLQUFLLE1BQU0sZUFBZSxnQkFBZ0I7R0FBRyxLQUFLLE1BQU0sZUFBZSxXQUFXO0VBQUc7Q0FDeEcsR0FBRyxDQUFDLElBQUksQ0FBQztDQUVULE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLHNCQUFzQixPQUFPLEtBQUs7O0NBR3hDLE1BQU0sK0JBQStCLGFBQWEsYUFBYSxTQUFTO0VBQ3BFLElBQUksb0JBQW9CLFNBQVM7RUFDakMsb0JBQW9CLFVBQVU7RUFDOUIsZ0JBQWdCLFVBQVU7RUFFMUIsSUFBSSxTQUFTLFNBQVM7R0FDbEIsY0FBYyxTQUFTLE9BQU87R0FDOUIsU0FBUyxVQUFVO0VBQ3ZCO0VBRUEsSUFBSTtHQUNBLGFBQWEsV0FBVyxnQkFBZ0IsVUFBVTtHQUNsRCxhQUFhLFdBQVcseUJBQXlCLFVBQVU7R0FDM0QsYUFBYSxXQUFXLGdCQUFnQixVQUFVO0dBQ2xELElBQUksWUFBWTtJQUNaLGFBQWEsUUFBUSxvQkFBb0IsWUFBWSxPQUFPLFVBQVUsQ0FBQztHQUMzRTtHQUNBLGVBQWUsV0FBVyx1QkFBdUIsVUFBVTtHQUMzRCxlQUFlLFdBQVcscUJBQXFCLFVBQVU7RUFDN0QsUUFBUSxDQUFDO0VBRVQsb0JBQW9CLElBQUk7RUFDeEIsSUFBSSxZQUFZO0dBQ1osU0FBUyxNQUFNLFNBQVMsVUFBVSxZQUFZO0VBQ2xEO0NBQ0osR0FBRyxDQUFDLFVBQVUsUUFBUSxDQUFDO0NBRXZCLE1BQU0sZ0JBQWdCLFlBQVksT0FBTyxjQUFjO0VBQ3ZELElBQUksQ0FBQyxRQUFRLGlCQUFpQixLQUFLLFNBQVM7RUFDNUMsTUFBTSxTQUFTLEtBQUssY0FBYyxLQUFLO0VBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxrQkFBa0I7RUFDdkMsSUFBSSxnQkFBZ0IsV0FBVyxvQkFBb0IsU0FBUztFQUU1RCxNQUFNLFFBQVEsRUFBRSxnQkFBZ0I7RUFFNUIsSUFBSTtHQUNBLE1BQU0sTUFBTSxpQkFBaUIsV0FBVyxtQkFBbUI7R0FDM0QsTUFBTSxVQUFVO0lBQ1osV0FBVztJQUNYLGlCQUFpQixrQkFBa0IsV0FBVyxHQUFFLENBQUUsS0FBSyxLQUFLLGFBQWEsWUFBWTtJQUNyRixNQUFNO0lBQ04sWUFBWSxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDdkM7R0FDQSxNQUFNLE1BQU0sTUFBTSxjQUFjLFVBQVUsT0FBTztHQUVqRCxNQUFNLGVBQWUsSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLE9BQ3RELElBQUksTUFBTSxvQkFBb0IsSUFBSSxNQUFNLGVBQ3hDLElBQUksTUFBTSxXQUFXLGVBQWUsSUFBSSxNQUFNLFdBQVcscUJBQ3pELElBQUksTUFBTSxXQUFXO0dBRXpCLElBQUksY0FBYztJQUNkLE1BQU0sU0FBUyxJQUFJLE1BQU0sY0FBYyxJQUFJLE1BQU07SUFDakQsNkJBQTZCLE1BQU07SUFDbkM7R0FDSjtHQUVBLElBQUksSUFBSSxNQUFNLElBQUksTUFBTTtJQUNwQixJQUFJLElBQUksS0FBSyxXQUFXO0tBQ3BCLGlCQUFpQixVQUFVLElBQUksS0FBSztLQUNwQyxJQUFJO01BQUUsZUFBZSxRQUFRLHVCQUF1QixZQUFZLElBQUksS0FBSyxTQUFTO0tBQUcsUUFBUSxDQUFDO0lBQ2xHO0lBQ0EsSUFBSSxPQUFPLElBQUksS0FBSyxtQkFBbUIsVUFBVTtLQUM3QyxrQkFBa0IsSUFBSSxLQUFLLGNBQWM7SUFDN0M7SUFDQSxJQUFJLE9BQU8sSUFBSSxLQUFLLG1CQUFtQixVQUFVO0tBQzdDLGtCQUFrQixJQUFJLEtBQUssY0FBYztJQUM3Qzs7SUFFQSxJQUFJLGNBQWMsbUJBQW1CLGNBQWMsYUFBYTtLQUM1RCxvQkFBb0IsSUFBSTtJQUM1QjtJQUNBLElBQUksSUFBSSxLQUFLLG9CQUFvQixDQUFDLGdCQUFnQixTQUFTO0tBQ3ZELGlCQUFpQixhQUFhLE1BQU0sSUFBSSxHQUFHLEdBQUk7SUFDbkQ7R0FDSjtFQUNKLFNBQVMsS0FBSztHQUNWLFFBQVEsS0FBSywrQ0FBK0MsV0FBVyxHQUFHO0VBQzlFO0NBQ0osR0FBRztFQUFDO0VBQU07RUFBVTtFQUFlO0VBQWE7Q0FBNEIsQ0FBQzs7Q0FHN0UsZ0JBQWdCO0VBQ1osSUFBSSxDQUFDLFFBQVEsaUJBQWlCLEtBQUssU0FBUztFQUM1QyxJQUFJLENBQUMsS0FBSyxjQUFjLENBQUMsS0FBSyxpQkFBaUI7RUFDL0MsSUFBSSxLQUFLLGlCQUFpQixDQUFDLGVBQWU7O0VBRzFDLGNBQWMsZUFBZTs7RUFHN0IsTUFBTSxpQkFBaUIsa0JBQWtCO0dBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsU0FBUztJQUMxQixjQUFjLFdBQVc7R0FDN0I7RUFDSixHQUFHLEdBQUs7RUFFUixhQUFhLGNBQWMsY0FBYztDQUM3QyxHQUFHO0VBQUM7RUFBTTtFQUFlO0VBQWU7Q0FBYSxDQUFDOzs7OztDQU10RCxnQkFBZ0I7RUFDWixJQUFJLENBQUMsUUFBUSxpQkFBaUIsS0FBSyxXQUFXLGtCQUFrQjs7RUFFaEUsSUFBSSxLQUFLLGlCQUFpQixDQUFDLGVBQWU7RUFFMUMsTUFBTSxTQUFTLEtBQUssY0FBYyxLQUFLO0VBQ3ZDLE1BQU0sY0FBYyxLQUFLLG9CQUFvQjtFQUU3QyxNQUFNLCtCQUErQjtHQUNqQyxJQUFJLG9CQUFvQixXQUFXLGdCQUFnQixTQUFTOztHQUU1RCxJQUFJLFNBQVMsVUFBVSxRQUFRLGdCQUFnQjtFQUNuRDtFQUVBLE1BQU0sd0JBQXdCO0dBQzFCLElBQUksQ0FBQyxVQUFVLG9CQUFvQixXQUFXLGdCQUFnQixTQUFTO0dBQ3ZFLE1BQU0sTUFBTSxLQUFLLElBQUk7O0dBRXJCLElBQUksTUFBTSxtQkFBbUIsVUFBVSxLQUFNO0dBQzdDLG1CQUFtQixVQUFVO0dBQzdCLGNBQWMsWUFBWTtFQUM5QjtFQUVBLE1BQU0seUJBQXlCO0dBQzNCLElBQUksU0FBUyxVQUFVLFFBQVEsZ0JBQWdCO0VBQ25EO0VBRUEsTUFBTSxjQUFjLE1BQU07R0FDdEIsSUFBSSxvQkFBb0IsV0FBVyxnQkFBZ0IsU0FBUztHQUM1RCxJQUFJLGFBQWE7SUFDYixFQUFFLGVBQWU7SUFDakIsY0FBYyxjQUFjO0dBQ2hDO0VBQ0o7RUFFQSxNQUFNLGVBQWUsTUFBTTtHQUN2QixJQUFJLG9CQUFvQixXQUFXLGdCQUFnQixTQUFTO0dBQzVELElBQUksYUFBYTtJQUNiLEVBQUUsZUFBZTtJQUNqQixjQUFjLGVBQWU7R0FDakM7RUFDSjtFQUVBLE1BQU0scUJBQXFCLE1BQU07R0FDN0IsSUFBSSxvQkFBb0IsV0FBVyxnQkFBZ0IsU0FBUztHQUM1RCxJQUFJLGFBQWE7SUFDYixFQUFFLGVBQWU7SUFDakIsY0FBYyxjQUFjO0dBQ2hDO0VBQ0o7RUFFQSxJQUFJLFFBQVE7R0FDUixTQUFTLGlCQUFpQixvQkFBb0Isc0JBQXNCO0dBQ3BFLE9BQU8saUJBQWlCLFFBQVEsZ0JBQWdCO0VBQ3BEO0VBQ0EsSUFBSSxhQUFhO0dBQ2IsU0FBUyxpQkFBaUIsUUFBUSxVQUFVO0dBQzVDLFNBQVMsaUJBQWlCLE9BQU8sVUFBVTtHQUMzQyxTQUFTLGlCQUFpQixTQUFTLFdBQVc7R0FDOUMsU0FBUyxpQkFBaUIsZUFBZSxpQkFBaUI7RUFDOUQ7RUFFQSxhQUFhO0dBQ1QsSUFBSSxRQUFRO0lBQ1IsU0FBUyxvQkFBb0Isb0JBQW9CLHNCQUFzQjtJQUN2RSxPQUFPLG9CQUFvQixRQUFRLGdCQUFnQjtHQUN2RDtHQUNBLElBQUksYUFBYTtJQUNiLFNBQVMsb0JBQW9CLFFBQVEsVUFBVTtJQUMvQyxTQUFTLG9CQUFvQixPQUFPLFVBQVU7SUFDOUMsU0FBUyxvQkFBb0IsU0FBUyxXQUFXO0lBQ2pELFNBQVMsb0JBQW9CLGVBQWUsaUJBQWlCO0dBQ2pFO0VBQ0o7Q0FDSixHQUFHO0VBQUM7RUFBTTtFQUFlO0VBQWU7RUFBZTtDQUFnQixDQUFDO0NBRXhFLGdCQUFnQjtFQUFFLFdBQVcsVUFBVTtDQUFTLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FDNUQsZ0JBQWdCO0VBQUUsYUFBYSxVQUFVO0NBQVcsR0FBRyxDQUFDLFNBQVMsQ0FBQzs7Q0FHbEUsTUFBTSxvQkFBb0IsT0FBTyxLQUFLO0NBQ3RDLE1BQU0sb0JBQW9CLE9BQU8sRUFBRTtDQUVuQyxNQUFNLG1CQUFtQixZQUFZLE9BQU8sZ0JBQWdCLE1BQU0sYUFBYSxVQUFVO0VBQ3pGLElBQUksQ0FBQyxRQUFRLGlCQUFpQixLQUFLLFdBQVcsb0JBQW9CLFNBQVM7RUFDM0UsTUFBTSxTQUFTLEtBQUssY0FBYyxLQUFLO0VBQ3ZDLElBQUksQ0FBQyxRQUFRO0VBQ2IsSUFBSSxLQUFLLGlCQUFpQixDQUFDLGVBQWU7RUFDMUMsSUFBSSxnQkFBZ0IsV0FBVyxrQkFBa0IsU0FBUztFQUUxRCxNQUFNLE1BQU0saUJBQWlCLFdBQVcsbUJBQW1CO0VBQzNELElBQUksQ0FBQyxLQUFLO0VBRVYsTUFBTSxTQUFTLGlCQUFpQixXQUFXLFdBQVcsQ0FBQztFQUN2RCxNQUFNLFFBQVEsYUFBYSxTQUFTLFNBQVMsYUFBYSxVQUFVOzs7Ozs7Ozs7O0VBV3BFLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxVQUFVLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxXQUFXLElBQUk7RUFFeEUsTUFBTSxtQkFBbUIsT0FBTyxRQUFRLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLFdBQVc7R0FDekUsTUFBTSxJQUFJLE1BQU0sTUFBSyxTQUFRLEtBQUssT0FBTyxTQUFTLFlBQVksRUFBRSxDQUFDO0dBQ2pFLElBQUksQ0FBQyxHQUFHLE9BQU87R0FDZixJQUFJLEVBQUUsV0FBVyxHQUFHO0lBQ2hCLE1BQU0sSUFBSSxTQUFTLE9BQU8sRUFBRTtJQUM1QixPQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxJQUFLO0tBQUUsWUFBWSxFQUFFO0tBQUksVUFBVTtJQUFFLElBQUk7R0FDdEU7R0FDQSxJQUFJLEVBQUUsV0FBVyxHQUFHO0lBQ2hCLE1BQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSSxNQUFLLFNBQVMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQU8sT0FBTSxDQUFDLE1BQU0sRUFBRSxLQUFLLEtBQUssQ0FBQyxJQUFJLENBQUM7SUFDekcsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFJLFFBQU87S0FBRSxZQUFZLEVBQUU7S0FBSSxVQUFVO0lBQUcsRUFBRSxJQUFJO0dBQzlFO0dBQ0EsSUFBSSxFQUFFLFdBQVcsR0FBRztJQUNoQixNQUFNLElBQUksT0FBTyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEtBQUs7SUFDbkMsT0FBTyxJQUFJO0tBQUUsWUFBWSxFQUFFO0tBQUksYUFBYyxFQUFFLFlBQVksTUFBTSxXQUFXLEVBQUUsWUFBWSxNQUFNLFNBQVUsVUFBVTtJQUFRLElBQUk7R0FDcEk7R0FDQSxNQUFNLElBQUksT0FBTyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEtBQUs7R0FDbkMsT0FBTyxJQUFJO0lBQUUsWUFBWSxFQUFFO0lBQUksYUFBYTtHQUFFLElBQUk7RUFDdEQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxPQUFPO0VBRXhCLElBQUksQ0FBQyxjQUFjLGlCQUFpQixXQUFXLEdBQUc7RUFFbEQsTUFBTSxjQUFjLEtBQUssVUFBVSxnQkFBZ0I7RUFDbkQsSUFBSSxDQUFDLGNBQWMsZ0JBQWdCLGtCQUFrQixTQUFTO0VBRTlELGtCQUFrQixVQUFVO0VBQzVCLElBQUk7R0FDQSxNQUFNLE1BQU0sTUFBTSxnQkFBZ0IsVUFBVSxLQUFLO0lBQzdDLFNBQVM7SUFDVCxpQkFBaUIsa0JBQWtCLFdBQVcsR0FBRSxDQUFFLEtBQUssS0FBSyxhQUFhLFlBQVk7R0FDekYsQ0FBQzs7Ozs7Ozs7R0FTRCxNQUFNLGVBQWUsSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLE9BQ3JELElBQUksV0FBVyxPQUFPLFlBQVksS0FBSyxJQUFJLFdBQVcsRUFBRSxLQUN6RCxJQUFJLE1BQU0sb0JBQW9CLElBQUksTUFBTSxlQUN4QyxJQUFJLE1BQU0sV0FBVyxlQUFlLElBQUksTUFBTSxXQUFXLHFCQUN6RCxJQUFJLE1BQU0sV0FBVztHQUV6QixJQUFJLGNBQWM7SUFDZCxNQUFNLFNBQVMsSUFBSSxNQUFNLGNBQWMsSUFBSSxNQUFNO0lBQ2pELDZCQUE2QixNQUFNO0lBQ25DO0dBQ0o7R0FFQSxJQUFJLElBQUksSUFBSTtJQUNSLGtCQUFrQixVQUFVO0dBQ2hDO0VBQ0osU0FBUyxLQUFLO0dBQ1YsUUFBUSxLQUFLLGdEQUFnRCxHQUFHO0VBQ3BFLFVBQVU7R0FDTixrQkFBa0IsVUFBVTtFQUNoQztDQUNKLEdBQUc7RUFBQztFQUFNO0VBQWU7RUFBZTtFQUFVO0VBQWE7RUFBb0I7RUFBVztDQUE0QixDQUFDOztDQUd2SCxnQkFBZ0I7RUFDaEIsSUFBSSxDQUFDLFFBQVEsaUJBQWlCLEtBQUssU0FBUztFQUM1QyxJQUFJLENBQUMsS0FBSyxjQUFjLENBQUMsS0FBSyxpQkFBaUI7RUFDL0MsSUFBSSxLQUFLLGlCQUFpQixDQUFDLGVBQWU7RUFFMUMsTUFBTSxXQUFXLGtCQUFrQjtHQUMvQixJQUFJLENBQUMsZ0JBQWdCLFNBQVM7SUFDMUIsaUJBQWlCLE1BQU0sSUFBSTtHQUMvQjtFQUNKLEdBQUcsR0FBSTtFQUVQLGFBQWEsY0FBYyxRQUFRO0NBQ3ZDLEdBQUc7RUFBQztFQUFNO0VBQWU7RUFBZTtDQUFnQixDQUFDOztDQUdyRCxnQkFBZ0I7RUFDWixJQUFJLENBQUMsUUFBUSxpQkFBaUIsS0FBSyxTQUFTO0VBQzVDLElBQUksQ0FBQyxLQUFLLGNBQWMsQ0FBQyxLQUFLLGlCQUFpQjtFQUMvQyxJQUFJLEtBQUssaUJBQWlCLENBQUMsZUFBZTtFQUUxQyxNQUFNLFdBQVcsa0JBQWtCO0dBQy9CLElBQUksQ0FBQyxnQkFBZ0IsU0FBUztJQUMxQixpQkFBaUI7R0FDckI7RUFDSixHQUFHLEdBQUs7RUFFUixhQUFhLGNBQWMsUUFBUTtDQUN2QyxHQUFHO0VBQUM7RUFBTTtFQUFlO0VBQWU7Q0FBZ0IsQ0FBQztDQUV6RCxNQUFNLHdCQUF3QixPQUFPLFVBQVU7RUFDM0MsTUFBTSxNQUFNLE1BQU0sdUJBQXVCLFVBQVU7R0FBRTtHQUFPLE1BQU07RUFBRyxDQUFDO0VBQ3RFLElBQUksSUFBSSxNQUFNLElBQUksTUFBTTtHQUNwQixNQUFNLFFBQVEsSUFBSSxLQUFLLGFBQWEsSUFBSSxRQUFRLENBQUM7R0FDakQsYUFBYSxLQUFLO0dBQ2xCLGFBQWEsVUFBVTtHQUN2QixJQUFJO0lBQ0EsTUFBTSxTQUFTLGFBQWEsUUFBUSxnQkFBZ0IsVUFBVTtJQUM5RCxJQUFJLFFBQVE7S0FDUixNQUFNLFNBQVMsS0FBSyxNQUFNLE1BQU07S0FDaEMsSUFBSSxVQUFVLE9BQU8sV0FBVyxVQUFVO01BQ3RDLFlBQVcsU0FBUTtPQUFFLE1BQU0sT0FBTztRQUFFLEdBQUc7UUFBUSxHQUFHO09BQUs7T0FBRyxXQUFXLFVBQVU7T0FBTSxPQUFPO01BQU0sQ0FBQztLQUN2RztJQUNKO0dBQ0osUUFBUSxDQUFDO0VBQ2I7Q0FDSjtDQUVBLE1BQU0sZ0JBQWdCLE9BQU8sUUFBUSxTQUFTO0VBQzFDLE1BQU0sTUFBTSxNQUFNLHVCQUF1QixVQUFVO0dBQUU7R0FBTyxNQUFNO0VBQWUsQ0FBQztFQUNsRixJQUFJLElBQUksTUFBTSxJQUFJLE1BQU07R0FDcEIsTUFBTSxRQUFRLElBQUksS0FBSyxhQUFhLElBQUksUUFBUSxDQUFDO0dBQ2pELGFBQWEsS0FBSztHQUNsQixhQUFhLFVBQVU7R0FDdkIsSUFBSTtJQUNBLE1BQU0sU0FBUyxhQUFhLFFBQVEsZ0JBQWdCLFVBQVU7SUFDOUQsSUFBSSxRQUFRO0tBQ1IsTUFBTSxTQUFTLEtBQUssTUFBTSxNQUFNO0tBQ2hDLElBQUksVUFBVSxPQUFPLFdBQVcsVUFBVTtNQUN0QyxZQUFXLFNBQVE7T0FBRSxNQUFNLE9BQU87UUFBRSxHQUFHO1FBQVEsR0FBRztPQUFLO09BQUcsV0FBVyxVQUFVO09BQU0sT0FBTztNQUFNLENBQUM7S0FDdkc7SUFDSjtHQUNKLFFBQVEsQ0FBQztFQUNiLE9BQU87R0FDSCxTQUFTLElBQUksV0FBVyw2QkFBNkI7RUFDekQ7Q0FDSjtDQUVBLGdCQUFnQjtFQUNaLE1BQU0sT0FBTyxZQUFZO0dBQ3JCLFdBQVcsSUFBSTtHQUNmLFNBQVMsRUFBRTs7R0FHWCxJQUFJLGVBQWU7SUFDZixJQUFJLGVBQWUsYUFBYSxJQUFJLFFBQVE7SUFDNUMsSUFBSSxDQUFDLGNBQWM7S0FDZixJQUFJO01BQ0EsTUFBTSxhQUFhLE1BQU0sV0FBVztNQUNwQyxJQUFJLFdBQVcsTUFBTSxNQUFNLFFBQVEsV0FBVyxJQUFJLEdBQUc7T0FDakQsTUFBTSxRQUFRLFdBQVcsS0FBSyxNQUFLLE1BQUssRUFBRSxhQUFhLFFBQVE7T0FDL0QsSUFBSSxPQUFPLGVBQWUsTUFBTTtNQUNwQztLQUNKLFFBQVEsQ0FBQztJQUNiO0lBRUEsSUFBSSxjQUFjO0tBQ2QsSUFBSTtNQUNBLE1BQU0sQ0FBQyxTQUFTLGdCQUFnQixNQUFNLFFBQVEsSUFBSSxDQUM5QyxZQUFZLFlBQVksR0FDeEIsYUFBYSxZQUFZLENBQzdCLENBQUM7TUFDRCxXQUFXLEtBQUs7TUFDaEIsSUFBSSxRQUFRLE1BQU0sUUFBUSxNQUFNO09BQzVCLFFBQVEsUUFBUSxJQUFJO09BQ3BCLGlCQUFpQixJQUFJO09BQ3JCLElBQUksYUFBYSxVQUFVLGtCQUFrQixZQUFZLFFBQVE7T0FDakUsTUFBTSxRQUFRLE1BQU0sUUFBUSxhQUFhLElBQUksSUFBSSxhQUFhLE9BQU8sQ0FBQztPQUN0RSxhQUFhLEtBQUs7T0FDbEIsYUFBYSxVQUFVO09BQ3ZCO01BQ0o7S0FDSixRQUFRLENBQUM7SUFDYjtHQUNKO0dBRUEsTUFBTSxNQUFNLE1BQU0sb0JBQW9CLFFBQVE7R0FDOUMsV0FBVyxLQUFLO0dBQ2hCLElBQUksSUFBSSxXQUFXLEtBQUs7SUFBRSxhQUFhO0lBQUcsU0FBUyxRQUFRO0lBQUc7R0FBUTtHQUN0RSxJQUFJLElBQUksTUFBTSxJQUFJLE1BQU07SUFDcEIsTUFBTSxJQUFJLElBQUk7SUFDZCxRQUFRLENBQUM7SUFDVCxJQUFJLGFBQWEsVUFBVSxrQkFBa0IsWUFBWSxRQUFROztJQUdqRSxJQUFJLGVBQWU7S0FDZixpQkFBaUIsSUFBSTtLQUNyQixNQUFNLHNCQUFzQixJQUFJO0tBQ2hDO0lBQ0o7SUFFQSxNQUFNLFdBQVcsYUFBYSxRQUFRLG9CQUFvQixVQUFVO0lBQ3BFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxvQkFBb0IsV0FBVztJQUV2RCxJQUFJLGFBQWE7SUFDakIsSUFBSTtLQUFFLGFBQWEsYUFBYSxRQUFRLGdCQUFnQixVQUFVLEtBQUs7SUFBSSxRQUFRLENBQUM7SUFDcEYsSUFBSSxZQUFZLGNBQWMsVUFBVTtJQUV4QyxJQUFJLENBQUMsRUFBRSxlQUFlO0tBQ2xCLGlCQUFpQixJQUFJO0tBQ3JCLE1BQU0sY0FBYztJQUN4QixPQUFPLElBQUksWUFBWTtLQUNuQixNQUFNLFlBQVksTUFBTSx1QkFBdUIsVUFBVTtNQUFFLE9BQU87TUFBWSxNQUFNLGFBQWEsWUFBWTtLQUFHLENBQUM7S0FDakgsSUFBSSxVQUFVLE1BQU0sVUFBVSxNQUFNO01BQ2hDLGlCQUFpQixJQUFJO01BQ3JCLE1BQU0sUUFBUSxVQUFVLEtBQUssYUFBYSxVQUFVLFFBQVEsQ0FBQztNQUM3RCxhQUFhLEtBQUs7TUFDbEIsYUFBYSxVQUFVO0tBQzNCO0lBQ0o7SUFFQSxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsZ0JBQWdCLEdBQUc7S0FDeEMsTUFBTSxtQkFBbUIseUJBQXlCO0tBQ2xELE1BQU0sTUFBTSxLQUFLLElBQUk7S0FDckIsSUFBSSxhQUFhLFNBQVMsYUFBYSxRQUFRLGdCQUFnQixHQUFHLEVBQUU7S0FDcEUsSUFBSSxDQUFDLGNBQWMsTUFBTSxVQUFVLEdBQUc7TUFDbEMsYUFBYSxNQUFPLEVBQUUsZ0JBQWdCO01BQ3RDLGFBQWEsUUFBUSxrQkFBa0IsT0FBTyxVQUFVLENBQUM7S0FDN0Q7S0FDQSxZQUFZLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxhQUFhLE9BQU8sR0FBSSxDQUFDLENBQUM7SUFDakU7R0FDSixPQUFPO0lBQ0gsU0FBUyxJQUFJLFdBQVcscURBQXFEO0dBQ2pGO0VBQ0o7RUFDQSxLQUFLOztDQUVULEdBQUcsQ0FBQyxVQUFVLFFBQVEsQ0FBQztDQUV2QixnQkFBZ0I7RUFDWixJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxpQkFBaUIsS0FBSyxpQkFBaUIsR0FBRztFQUN2RSxNQUFNLG1CQUFtQix5QkFBeUI7RUFDbEQsSUFBSSxTQUFTLGFBQWEsUUFBUSxnQkFBZ0I7RUFDbEQsSUFBSSxhQUFhLFNBQVMsU0FBUyxRQUFRLEVBQUUsSUFBSTtFQUNqRCxNQUFNLE1BQU0sS0FBSyxJQUFJO0VBQ3JCLElBQUksQ0FBQyxjQUFjLE1BQU0sVUFBVSxHQUFHO0dBQ2xDLGFBQWEsTUFBTyxLQUFLLGdCQUFnQjtHQUN6QyxhQUFhLFFBQVEsa0JBQWtCLE9BQU8sVUFBVSxDQUFDO0VBQzdEO0VBQ0EsTUFBTSxtQkFBbUI7R0FDckIsTUFBTSxZQUFZLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxhQUFhLEtBQUssSUFBSSxLQUFLLEdBQUksQ0FBQztHQUN6RSxZQUFZLFNBQVM7R0FDckIsSUFBSSxhQUFhLEdBQUc7SUFBRSxJQUFJLFNBQVMsU0FBUyxjQUFjLFNBQVMsT0FBTztJQUFHLElBQUksQ0FBQyxnQkFBZ0IsU0FBUyxhQUFhLE1BQU0sSUFBSTtHQUFHO0VBQ3pJO0VBQ0EsV0FBVztFQUNYLFNBQVMsVUFBVSxZQUFZLFlBQVksR0FBSTtFQUMvQyxhQUFhO0dBQUUsSUFBSSxTQUFTLFNBQVMsY0FBYyxTQUFTLE9BQU87RUFBRzs7Q0FFMUUsR0FBRztFQUFDO0VBQWUsTUFBTTtFQUFlO0NBQVEsQ0FBQzs7Q0FHakQsTUFBTSxlQUFlLFlBQVk7RUFDN0IsSUFBSSxXQUFXLE1BQU07R0FDakIsTUFBTSxJQUFJLEtBQUssTUFBTSxVQUFVLElBQUk7R0FDbkMsTUFBTSxJQUFJLEtBQUssTUFBTyxVQUFVLE9BQVEsRUFBRTtHQUMxQyxNQUFNLElBQUksVUFBVTtHQUNwQixPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUUsR0FBRyxFQUFFLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUUsR0FBRyxFQUFFLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUUsR0FBRztFQUNoRztFQUNBLE1BQU0sSUFBSSxLQUFLLE1BQU0sVUFBVSxFQUFFLEdBQUcsSUFBSSxVQUFVO0VBQ2xELE9BQU8sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRSxHQUFHLEVBQUUsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRSxHQUFHO0NBQ25FO0NBRUEsTUFBTSxzQkFBc0IsWUFBWSxVQUFVO0VBQzlDLFlBQVcsU0FBUTtHQUNmLE1BQU0sT0FBTztJQUFFLEdBQUc7S0FBTyxhQUFhO0dBQU07R0FDNUMsV0FBVyxVQUFVO0dBQ3JCLElBQUk7SUFBRSxhQUFhLFFBQVEsZ0JBQWdCLFlBQVksS0FBSyxVQUFVLElBQUksQ0FBQztHQUFHLFFBQVEsQ0FBQztHQUN2RixPQUFPO0VBQ1gsQ0FBQztDQUNMO0NBRUEsTUFBTSx3QkFBd0IsWUFBWSxVQUFVLFlBQVk7RUFDNUQsWUFBVyxTQUFRO0dBQ2YsTUFBTSxVQUFVLE1BQU0sUUFBUSxLQUFLLFdBQVcsSUFBSSxLQUFLLGNBQWMsQ0FBQztHQUN0RSxNQUFNLFVBQVUsVUFBVSxDQUFDLEdBQUcsU0FBUyxRQUFRLElBQUksUUFBUSxRQUFPLE9BQU0sT0FBTyxRQUFRO0dBQ3ZGLE1BQU0sT0FBTztJQUFFLEdBQUc7S0FBTyxhQUFhO0dBQVE7R0FDOUMsV0FBVyxVQUFVO0dBQ3JCLElBQUk7SUFBRSxhQUFhLFFBQVEsZ0JBQWdCLFlBQVksS0FBSyxVQUFVLElBQUksQ0FBQztHQUFHLFFBQVEsQ0FBQztHQUN2RixPQUFPO0VBQ1gsQ0FBQztDQUNMO0NBRUEsTUFBTSxvQkFBb0IsT0FBTyxNQUFNO0VBQ25DLEVBQUUsZUFBZTtFQUNqQixTQUFTLEVBQUU7RUFDWCxNQUFNLFFBQVEsV0FBVyxLQUFLO0VBQzlCLE1BQU0sTUFBTSxNQUFNLHVCQUF1QixVQUFVO0dBQUU7R0FBTyxNQUFNO0VBQWUsQ0FBQztFQUNsRixJQUFJLElBQUksTUFBTSxJQUFJLE1BQU07R0FDcEIsSUFBSTtJQUFFLGFBQWEsUUFBUSxnQkFBZ0IsWUFBWSxLQUFLO0dBQUcsUUFBUSxDQUFDO0dBQ3hFLGlCQUFpQixJQUFJO0dBQ3JCLE1BQU0sUUFBUSxJQUFJLEtBQUssYUFBYSxJQUFJLFFBQVEsQ0FBQztHQUNqRCxhQUFhLEtBQUs7R0FDbEIsYUFBYSxVQUFVO0dBQ3ZCLElBQUk7SUFDQSxNQUFNLFNBQVMsYUFBYSxRQUFRLGdCQUFnQixVQUFVO0lBQzlELElBQUksUUFBUTtLQUFFLE1BQU0sU0FBUyxLQUFLLE1BQU0sTUFBTTtLQUFHLElBQUksUUFBUTtNQUFFLFdBQVcsTUFBTTtNQUFHLFdBQVcsVUFBVTtLQUFRO0lBQUU7R0FDdEgsUUFBUSxDQUFDO0VBQ2IsT0FBTztHQUNILFNBQVMsSUFBSSxXQUFXLDBCQUEwQjtFQUN0RDtDQUNKO0NBRUEsTUFBTSx1QkFBdUIsUUFBUTtFQUFFLG1CQUFtQixHQUFHO0VBQUcsaUJBQWlCLG1CQUFtQixJQUFJLEdBQUcsSUFBSTtDQUFHO0NBRWxILE1BQU0sZUFBZSxPQUFPLEdBQUcsU0FBUyxPQUFPLGVBQWUsVUFBVTtFQUNwRSxJQUFJLEtBQUssT0FBTyxFQUFFLG1CQUFtQixZQUFZLEVBQUUsZUFBZTtFQUNsRSxJQUFJLGVBQWU7R0FBRSxPQUFPLE1BQU07R0FBRztFQUFROztFQUU3QyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixnQkFBZ0IsT0FBTyxLQUFLLENBQUMscUJBQXFCLENBQUMsbUJBQW1CO0dBQ2xHLHFCQUFxQixJQUFJO0dBQ3pCO0VBQ0o7RUFDQSxxQkFBcUIsS0FBSztFQUMxQixJQUFJLGdCQUFnQixTQUFTO0VBRTdCLE1BQU0sbUJBQW1CLGFBQWEsU0FBUyxTQUFTLGFBQWEsVUFBVTtFQUMvRSxNQUFNLGlCQUFpQixXQUFXLFdBQVc7RUFFN0MsSUFBSSxDQUFDLFFBQVE7R0FDVCxNQUFNLGFBQWEsaUJBQWlCLFFBQU8sTUFBSztJQUM1QyxJQUFJLENBQUMsRUFBRSxZQUFZLE9BQU87SUFDMUIsTUFBTSxNQUFNLGVBQWUsRUFBRTtJQUM3QixPQUFPLEVBQUUsV0FBVyxJQUFJLEVBQUUsTUFBTSxRQUFRLEdBQUcsS0FBSyxJQUFJLFNBQVMsS0FBSyxFQUFFLFFBQVEsYUFBYSxRQUFRLFFBQVEsT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTO0dBQ3pJLENBQUM7R0FDRCxJQUFJLFdBQVcsU0FBUyxHQUFHO0lBQ3ZCLE1BQU0sTUFBTSxPQUFPLFdBQVcsT0FBTztJQUNyQyxvQkFBb0IsR0FBRztJQUFHLFNBQVMsR0FBRztJQUN0QyxNQUFNLFFBQVEsV0FBVztJQUN6QixNQUFNLFNBQVMsTUFBTSxlQUFlO0lBQ3BDLElBQUksUUFBUTtLQUFFLE1BQU0sTUFBTSxpQkFBaUIsV0FBVSxNQUFLLEVBQUUsT0FBTyxNQUFNLEVBQUU7S0FBRyxJQUFJLFFBQVEsQ0FBQyxHQUFHLGVBQWUsR0FBRztJQUFHLE9BQzlHO0tBQUUsTUFBTSxLQUFLLFNBQVMsZUFBZSxpQkFBaUIsTUFBTSxJQUFJO0tBQUcsSUFBSSxJQUFJO01BQUUsR0FBRyxlQUFlO09BQUUsVUFBUztPQUFVLE9BQU07TUFBUyxDQUFDO01BQUcsR0FBRyxVQUFVLElBQUksVUFBUyxjQUFjO01BQUcsaUJBQWlCLEdBQUcsVUFBVSxPQUFPLFVBQVMsY0FBYyxHQUFHLElBQUk7S0FBRztJQUFFO0lBQy9QO0dBQ0o7RUFDSjtFQUVBLGdCQUFnQixVQUFVO0VBQzFCLGNBQWMsSUFBSTtFQUNsQixJQUFJLFNBQVMsU0FBUyxjQUFjLFNBQVMsT0FBTztFQUNwRCxTQUFTLEVBQUU7RUFBRyxtQkFBbUIsSUFBSTtFQUVyQyxNQUFNLG1CQUFtQixPQUFPLFFBQVEsY0FBYyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksV0FBVztHQUNqRixNQUFNLElBQUksaUJBQWlCLE1BQUssU0FBUSxLQUFLLE9BQU8sU0FBUyxZQUFZLEVBQUUsQ0FBQztHQUM1RSxJQUFJLENBQUMsR0FBRyxPQUFPO0dBQ2YsSUFBSSxFQUFFLFdBQVcsR0FBRztJQUFFLE1BQU0sSUFBSSxTQUFTLE9BQU8sRUFBRTtJQUFHLE9BQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUs7S0FBRSxZQUFZLEVBQUU7S0FBSSxVQUFVO0lBQUUsSUFBSTtHQUFNO0dBQzdILElBQUksRUFBRSxXQUFXLEdBQUc7SUFBRSxNQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUksTUFBSyxTQUFTLEdBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFPLE9BQU0sQ0FBQyxNQUFNLEVBQUUsS0FBSyxLQUFLLENBQUMsSUFBSSxDQUFDO0lBQUcsT0FBTyxJQUFJLFNBQVMsSUFBSSxLQUFJLFFBQU87S0FBRSxZQUFZLEVBQUU7S0FBSSxVQUFVO0lBQUcsRUFBRSxJQUFJO0dBQU07R0FDak4sSUFBSSxFQUFFLFdBQVcsR0FBRztJQUFFLE1BQU0sSUFBSSxPQUFPLFNBQU8sRUFBRSxDQUFDLENBQUMsS0FBSztJQUFHLE9BQU8sSUFBSTtLQUFFLFlBQVksRUFBRTtLQUFJLGFBQWMsRUFBRSxZQUFZLE1BQUksV0FBUyxFQUFFLFlBQVksTUFBSSxTQUFVLFVBQVU7SUFBUSxJQUFJO0dBQU07R0FDMUwsTUFBTSxJQUFJLE9BQU8sU0FBTyxFQUFFLENBQUMsQ0FBQyxLQUFLO0dBQUcsT0FBTyxJQUFJO0lBQUUsWUFBWSxFQUFFO0lBQUksYUFBYTtHQUFFLElBQUk7RUFDMUYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxPQUFPO0VBRXhCLElBQUk7R0FDQSxNQUFNLE1BQU0sTUFBTSx5QkFBeUIsVUFBVTtJQUNqRCxPQUFPLGFBQWEsV0FBVyxLQUFLLElBQUk7SUFDeEMsZ0JBQWdCLGVBQWUsS0FBSyxLQUFLO0lBQ3pDLGNBQWMsUUFBUSxNQUFNO0lBQUcsY0FBYyxRQUFRLE1BQU07SUFDM0QsU0FBUztJQUNULGVBQWUsaUJBQWlCLFdBQVc7SUFDM0MsZ0JBQWdCLE9BQU8sbUJBQW1CLFdBQVcsaUJBQWlCO0dBQzFFLENBQUM7R0FDRCxNQUFNLElBQUksSUFBSTtHQUNkLE1BQU0sYUFBYSxHQUFHLGNBQWMsR0FBRyxPQUFPLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxXQUFXLElBQUk7R0FDbkcsSUFBSSxJQUFJLE1BQU0sWUFBWTtJQUN0QixJQUFJO0tBQ0EsYUFBYSxXQUFXLGdCQUFnQixVQUFVO0tBQ2xELGFBQWEsV0FBVyx5QkFBeUIsVUFBVTtLQUMzRCxhQUFhLFdBQVcsZ0JBQWdCLFVBQVU7S0FDbEQsYUFBYSxRQUFRLG9CQUFvQixZQUFZLE9BQU8sVUFBVSxDQUFDO0tBQ3ZFLGVBQWUsV0FBVyx1QkFBdUIsVUFBVTtLQUMzRCxlQUFlLFdBQVcscUJBQXFCLFVBQVU7SUFDN0QsUUFBUSxDQUFDO0lBQ1QsU0FBUyxNQUFNLFNBQVMsVUFBVSxjQUFjLEVBQUUsT0FBTyxFQUFFLFlBQVksR0FBRyxjQUFjLEtBQUssRUFBRSxDQUFDO0dBQ3BHLE9BQU87SUFDSCxnQkFBZ0IsVUFBVTtJQUFPLGNBQWMsS0FBSztJQUNwRCxNQUFNLFVBQVUsSUFBSSxXQUFXO0lBQy9CLFNBQVMsT0FBTztJQUFHLG9CQUFvQixPQUFPO0dBQ2xEO0VBQ0osUUFBUTtHQUNKLGdCQUFnQixVQUFVO0dBQU8sY0FBYyxLQUFLO0dBQ3BELE1BQU0sVUFBVTtHQUNoQixTQUFTLE9BQU87R0FBRyxvQkFBb0IsT0FBTztFQUNsRDtDQUNKO0NBRUEsTUFBTSxtQkFBbUIsT0FBTyxNQUFNO0VBQ2xDLEVBQUUsZUFBZTtFQUFHLGVBQWUsRUFBRTtFQUFHLG9CQUFvQixJQUFJO0VBQ2hFLE1BQU0sTUFBTSxNQUFNLGVBQWUsTUFBTSxJQUFJO0dBQUUsUUFBUTtHQUFjLGFBQWEsa0JBQWtCLEtBQUs7RUFBRSxDQUFDO0VBQzFHLG9CQUFvQixLQUFLO0VBQ3pCLElBQUksSUFBSSxJQUFJO0dBQUUsaUJBQWlCLElBQUk7R0FBRyxxQkFBcUIsRUFBRTtHQUFHLGlCQUFpQjtJQUFFLG1CQUFtQixLQUFLO0lBQUcsaUJBQWlCLEtBQUs7R0FBRyxHQUFHLElBQUk7RUFBRyxPQUM1SSxlQUFlLElBQUksV0FBVyxvQ0FBb0M7Q0FDM0U7Q0FFQSxJQUFJLFNBQVMsT0FDVCx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNYLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDSSx3QkFBQyxTQUFELEVBQVMsV0FBVSxpRUFBa0U7Ozs7YUFDckYsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBeUQ7R0FBcUI7Ozs7V0FDMUY7Ozs7OztDQUNKOzs7OztDQUdULElBQUksa0JBQWtCO0VBQ2xCLE9BQ0ksd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0ksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1gsd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7S0FDaEI7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBd0Q7TUFFbEU7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZEO01BRXZFOzs7O2NBQ0Y7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNYLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsZUFBZSxTQUFTLEdBQUc7T0FDM0IsV0FBVTtpQkFDYjtNQUVPOzs7OztLQUNQOzs7OztJQUNKOzs7Ozs7RUFDSjs7Ozs7Q0FFYjs7Q0FHQSxNQUFNLG1CQUFtQixPQUFPLFdBQVcsY0FBYyxhQUFhLFFBQVEsb0JBQW9CLFVBQVUsSUFBSTtDQUNoSCxJQUFJLENBQUMsaUJBQWlCLFFBQVEsS0FBSyxnQkFBZ0IsS0FBSyxvQkFBb0IsbUJBQW1CO0VBQzNGLE1BQU0sYUFBYSxLQUFLLHNCQUFzQjtFQUM5QyxPQUNJLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1gsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUEySCx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztLQUFNOzs7OztLQUNqSyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUF3RDtNQUFxQjs7OztnQkFDM0Ysd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBMEU7UUFBdUMsd0JBQUMsS0FBRCxZQUFJLEtBQUssTUFBUzs7Ozs7UUFBQztRQUE2Qyx3QkFBQyxLQUFELFlBQUcsb0JBQW9COzs7OztRQUFDO09BQWtCOzs7OztjQUMxTjs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSyxjQUFjLEtBQUssYUFBYSx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLGVBQWUsU0FBUyxNQUFNLFNBQVMsVUFBVSxZQUFZO09BQUcsV0FBVTtpQkFBOEg7TUFBeUM7Ozs7Z0JBQ3hTLHdCQUFDLFVBQUQ7T0FBUSxNQUFLO09BQVMsZUFBZSxTQUFTLGFBQWEsS0FBSyxlQUFlLFFBQVE7T0FBRyxXQUFVO2lCQUFwRyxDQUE0UixlQUFZLGFBQWEsS0FBSyxjQUFjLGVBQXdCOzs7OztjQUMvVjs7Ozs7O0lBQ0o7Ozs7OztFQUNKOzs7OztDQUViO0NBRUEsSUFBSSxTQUFTLENBQUMsTUFBTSxPQUNoQix3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNYLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUEyRyx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztJQUFNOzs7OztJQUN4Six3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFtRDtJQUEyQjs7Ozs7SUFDNUYsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBOEM7SUFBUzs7Ozs7R0FDbkU7Ozs7OztDQUNKOzs7Ozs7Q0FJVCxJQUFJLENBQUMsaUJBQWlCLENBQUMsZUFBZSxPQUNsQyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNYLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQTRJLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O01BQU07Ozs7O01BQ2xMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUF3RDtNQUFvQzs7Ozs7TUFDMUcsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlEO01BQWlGOzs7OztLQUN0Sjs7Ozs7O0lBQ0osU0FBUyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFrSjtJQUFXOzs7OztJQUN0TCx3QkFBQyxRQUFEO0tBQU0sVUFBVTtLQUFtQixXQUFVO2VBQTdDLENBQ0ksd0JBQUMsU0FBRDtNQUFPLE1BQUs7TUFBVztNQUFTLE9BQU87TUFBWSxXQUFVLE1BQUssY0FBYyxFQUFFLE9BQU8sS0FBSztNQUFHLGFBQVk7TUFBMEIsV0FBVTtLQUEyTjs7OztlQUM1Vyx3QkFBQyxVQUFEO01BQVEsTUFBSztNQUFTLFdBQVU7Z0JBQThIO0tBQXFCOzs7O2FBQ2pMOzs7Ozs7R0FDTDs7Ozs7O0NBQ0o7Ozs7O0NBR1QsTUFBTSxlQUFlLE1BQU0sZUFBZSxLQUFLLE1BQU0sVUFBVSxlQUFlO0NBQzlFLE1BQU0sV0FBVyxVQUFVO0NBQzNCLE1BQU0sYUFBYSxVQUFVOztDQUc3QixNQUFNLGdCQUFnQixVQUFVLFFBQU8sTUFBSztFQUN4QyxNQUFNLE1BQU0sUUFBUSxFQUFFO0VBQ3RCLE9BQU8sRUFBRSxXQUFXLElBQUksTUFBTSxRQUFRLEdBQUcsS0FBSyxJQUFJLFNBQVMsSUFBSSxRQUFRLGFBQWEsUUFBUSxRQUFRLE9BQU8sR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUztDQUNwSSxDQUFDLENBQUMsQ0FBQztDQUNILE1BQU0sa0JBQWtCLGFBQWEsSUFBSSxLQUFLLE1BQU8sZ0JBQWdCLGFBQWMsR0FBRyxJQUFJOztDQUcxRixNQUFNLGVBQWUsTUFBTSxxQkFBcUI7Q0FDaEQsTUFBTSxVQUFVLE1BQU07Q0FFdEIsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVyx5RUFBeUUsVUFBVSxTQUFTLElBQUksVUFBVSxPQUFPO0VBQXVDLE9BQU8sRUFBRSxpQkFBaUIsV0FBVyxVQUFVO1lBQXZOO0dBR0ssVUFBVSxTQUFTLEtBQ2hCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFEO0tBQUssV0FBVyxHQUFHLGVBQWUsMkJBQTJCLFlBQVk7ZUFBekUsQ0FDSSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FBaUMsTUFBTSxRQUFRLEdBQUcsS0FBSyxNQUFNLE9BQU87T0FBSTtPQUFjO09BQU87T0FBVztNQUFvQjs7Ozs7ZUFDNUgsd0JBQUMsUUFBRDtNQUFNLFdBQVU7TUFBcUIsT0FBTyxFQUFFLE9BQU8sYUFBYTtnQkFBbEUsQ0FBc0UsaUJBQWdCLEdBQU87Ozs7O2FBQzVGOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLEdBQUcsZUFBZSwyQkFBMkIsWUFBWTtlQUNyRSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFrRCxPQUFPO09BQUUsT0FBTyxHQUFHLGdCQUFnQjtPQUFJLGlCQUFpQjtNQUFhO0tBQUk7Ozs7O0lBQ3pJOzs7O1lBQ0o7Ozs7OztHQUlSLENBQUMsWUFDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsU0FBRDtLQUFTLE1BQU07S0FBSSxXQUFVO0lBQVk7Ozs7Y0FDekMsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQsWUFBRywyQkFBMkI7Ozs7Y0FDOUIsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYixDQUFtRCxlQUFjLHVDQUF3Qzs7Ozs7WUFDeEc7Ozs7WUFDSjs7Ozs7O0dBSVIsWUFBWSxxQkFDVCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsTUFBRDtLQUFNLE1BQU07S0FBSSxXQUFVO0lBQVk7Ozs7Y0FDdEMsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQsWUFBRyxnQkFBZ0I7Ozs7Y0FDbkIsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBcUM7SUFBeUM7Ozs7WUFDMUY7Ozs7WUFDSjs7Ozs7O0dBSVIscUJBQXFCLE1BQU0sbUJBQW1CLE1BQU0sZUFDakQsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNJLHdCQUFDLGFBQUQ7TUFBYSxNQUFNO01BQUksV0FBVTtLQUFZOzs7OztLQUM3Qyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF5QjtNQUFvRTs7OztnQkFDekcsS0FBSyxlQUNGLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQXNDO1FBQWE7UUFBZTtRQUFFLEtBQUs7UUFBYTtRQUFFLGlCQUFpQixpQkFBaUIsd0JBQXdCLG1CQUFtQjtPQUFNOzs7OztpQkFFM0ssd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBc0M7UUFBYTtRQUFlO1FBQUUsaUJBQWlCLGlCQUFpQix3QkFBd0IsbUJBQW1CO09BQU07Ozs7O2NBRTFKOzs7Ozs7S0FDTCx3QkFBQyxVQUFEO01BQVEsZUFBZSxvQkFBb0IsS0FBSztNQUFHLFdBQVU7Z0JBQStDLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O0tBQVM7Ozs7O0lBQ2xJOzs7Ozs7R0FJUixtQkFDRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUEyQyx3QkFBQyxhQUFEO01BQWEsTUFBTTtNQUFJLFdBQVU7S0FBdUI7Ozs7ZUFBQyx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBZ0M7S0FBc0I7Ozs7YUFBTTs7Ozs7Y0FDaEwsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxlQUFlLG1CQUFtQixJQUFJO0tBQUcsV0FBVTtlQUF3RSx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztJQUFTOzs7O1lBQ3ZLOzs7Ozs7R0FHVCx3QkFBQyxPQUFEO0lBQUssV0FBVyxHQUFHLGVBQWUsMkJBQTJCLFlBQVk7Y0FBekU7S0FHSyxpQkFDRyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQThGLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7aUJBQUMsd0JBQUMsUUFBRCxZQUFNLDZDQUFnRDs7OztlQUFNOzs7OztnQkFDM0ssd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxlQUFlLE9BQU8sTUFBTTtPQUFHLFdBQVU7aUJBQXNGO01BQXFCOzs7O2NBQ3pLOzs7Ozs7S0FJVCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxTQUFTO1FBQWdCLFdBQVU7a0JBQXpELENBQ0ssYUFBYSx3QkFBQyxLQUFEO1NBQUssTUFBTTtTQUFJLFdBQVU7UUFBa0I7Ozs7bUJBQUksd0JBQUMsTUFBRDtTQUFNLE1BQU07U0FBSSxXQUFVO1FBQWlCOzs7O2tCQUN4Ryx3QkFBQyxRQUFELFlBQU8sYUFBYSxnQkFBZ0IsYUFBbUI7Ozs7Z0JBQ25EOzs7OztpQkFFUCxDQUFDLGlCQUNFLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsZUFBZSxtQkFBbUIsSUFBSTtRQUFHLFdBQVU7a0JBQXpFLENBQ0ksd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7OztrQkFBQyx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2dCQUNuRDs7Ozs7ZUFFWDs7Ozs7Z0JBQ0osYUFBYSxRQUNWLHdCQUFDLE9BQUQ7T0FBSyxXQUFXLDBIQUNaLFlBQVksS0FDTiwwREFDQSxZQUFZLE1BQ1osZ0RBQ0E7aUJBTFYsQ0FPSSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7O2lCQUFDLHdCQUFDLFFBQUQsYUFBTSxXQUFRLFlBQVksUUFBUSxDQUFROzs7O2VBQzVEOzs7OztjQUVSOzs7Ozs7S0FHSixhQUFhLFFBQVEsTUFBTSxnQkFBZ0IsS0FDeEMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1gsd0JBQUMsT0FBRDtPQUNJLFdBQVcsb0RBQ1AsWUFBWSxLQUFLLGVBQWUsWUFBWSxNQUFNLGlCQUFpQjtPQUV2RSxPQUFPLEVBQUUsT0FBTyxHQUFHLEtBQUssSUFBSSxHQUFJLFdBQVcsS0FBSyxnQkFBaUIsR0FBRyxFQUFFLEdBQUc7TUFDNUU7Ozs7O0tBQ0E7Ozs7O0tBSVQsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSyxNQUFNLGVBQ0gsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1gsd0JBQUMsT0FBRDtRQUFLLEtBQUssU0FBUyxLQUFLLFdBQVc7UUFBRyxLQUFLLEtBQUs7UUFBTyxXQUFVO09BQThCOzs7OztNQUM5Rjs7OztnQkFFVCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWlHLE1BQU0sU0FBUztRQUFlOzs7O2tCQUM1SSxNQUFNLGVBQWUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWlILHdCQUFDLHFCQUFELEVBQXFCLFNBQVMsS0FBSyxZQUFjOzs7OztRQUFNOzs7O2dCQUM1TTs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNkQ7UUFBNEI7Ozs7a0JBQzFHLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQU8sT0FBTztTQUFnQixXQUFVLE1BQUssa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1NBQUcsYUFBWTtTQUFnQyxXQUFVO1FBQXlOOzs7O2dCQUMxVzs7Ozs7ZUFDSjs7Ozs7Y0FDSjs7Ozs7O0tBRUosU0FDRyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7Z0JBQUMsd0JBQUMsUUFBRCxZQUFPLE1BQVk7Ozs7Y0FDM0M7Ozs7OztLQUlSLGdCQUFnQixXQUNiLHdCQUFDLE9BQUQ7TUFBSyxJQUFJLGlCQUFpQixTQUFTO01BQU0sV0FBVTtnQkFBbkQ7T0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsUUFBRDtVQUFNLFdBQVU7VUFBMEQsT0FBTztXQUFFLGlCQUFpQixHQUFHLGFBQWE7V0FBSyxPQUFPO1VBQWE7b0JBQTdJO1dBQWdKO1dBQ3RJLGNBQWM7V0FBRTtXQUFPO1VBQzNCOzs7OzttQkFFTix3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLGVBQWUsZ0JBQWdCLElBQUk7VUFBRyxPQUFNO1VBQXNCLFdBQVU7b0JBQzlGLHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7O1NBQ25COzs7O2lCQUNQOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNLLFNBQVMsY0FBYyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUY7U0FBVzs7OzttQkFFMUksd0JBQUMsVUFBRDtVQUFRLE1BQUs7VUFDVCxlQUFlLG9CQUFtQixTQUFRO1dBQUUsTUFBTSxPQUFPLElBQUksSUFBSSxJQUFJO1dBQUcsSUFBSSxLQUFLLElBQUksU0FBUyxFQUFFLEdBQUcsS0FBSyxPQUFPLFNBQVMsRUFBRTtnQkFBUSxLQUFLLElBQUksU0FBUyxFQUFFO1dBQUcsT0FBTztVQUFNLENBQUM7VUFDdkssV0FBVywyR0FDUCxnQkFBZ0IsSUFBSSxTQUFTLEVBQUUsSUFDekIseUZBQ0E7b0JBTGQsQ0FPSyxnQkFBZ0IsSUFBSSxTQUFTLEVBQUUsSUFBSSx3QkFBQyxlQUFELEVBQWUsTUFBTSxHQUFLOzs7O3FCQUFJLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7b0JBQ3ZGLHdCQUFDLFFBQUQsWUFBTyxnQkFBZ0IsSUFBSSxTQUFTLEVBQUUsSUFBSSxjQUFjLFNBQWU7Ozs7a0JBQ25FOzs7OztpQkFDUDs7Ozs7Z0JBQ0o7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0ssU0FBUyxpQkFDTix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQ7V0FBSyxLQUFLLFNBQVMsU0FBUyxhQUFhO1dBQUcsS0FBSTtXQUFjLFdBQVU7V0FBK0YsZUFBZSxpQkFBaUI7WUFBRSxLQUFLLFNBQVMsU0FBUyxhQUFhO1lBQUcsS0FBSztXQUFjLENBQUM7VUFBSTs7OztvQkFDeFEsd0JBQUMsVUFBRDtXQUFRLE1BQUs7V0FBUyxlQUFlLGlCQUFpQjtZQUFFLEtBQUssU0FBUyxTQUFTLGFBQWE7WUFBRyxLQUFLO1dBQWMsQ0FBQztXQUFHLFdBQVU7cUJBQWhJLENBQXFWLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7cUJBQUMsV0FBaUI7Ozs7O2tCQUM1WDs7Ozs7O1NBRVIsU0FBUyxpQkFDTix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWCx3QkFBQyxTQUFEO1dBQU87V0FBUyxLQUFLLFNBQVMsU0FBUyxhQUFhO1dBQUcsV0FBVTtVQUFzQzs7Ozs7U0FDdEc7Ozs7O1NBRVQsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1gsd0JBQUMscUJBQUQsRUFBcUIsU0FBUyxTQUFTLFNBQVc7Ozs7O1NBQ2pEOzs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFRLGtCQUFrQixVQUFVLFNBQVMsb0JBQW9CLHNCQUFzQixjQUFjLGdCQUFnQjtTQUFPOzs7OztRQUMxSTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLGVBQWUsZ0JBQWUsU0FBUSxLQUFLLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQztTQUFHLFVBQVUsZ0JBQWdCO1NBQUcsV0FBVTttQkFBM0gsQ0FDSSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O21CQUFDLGFBQ25COzs7OztrQkFDUCxjQUFjLGFBQWEsSUFDeEIsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxlQUFlLGdCQUFlLFNBQVEsT0FBTyxDQUFDO1NBQUcsV0FBVTtTQUF5RyxPQUFPLEVBQUUsaUJBQWlCLGFBQWE7bUJBQWpPLENBQW9PLGdCQUNwTix3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7O2lCQUMvQjs7Ozs7OztBQUdSLGdCQUNJLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsZUFBZSxPQUFPLE1BQU07U0FBRyxXQUFVO21CQUEvRCxDQUNJLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7bUJBQUMsa0JBQ2I7Ozs7O21CQUVSLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsVUFBVSxNQUFNLGFBQWEsR0FBRyxLQUFLO1NBQUcsVUFBVTtTQUFZLFdBQVU7bUJBQTlGO1VBQ0ksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7VUFBQztVQUFFLGFBQWEsbUJBQW1CO1NBQ2hEOzs7OztnQkFHZjs7Ozs7O01BQ0o7Ozs7Ozs7QUFHTCx3QkFBQyxRQUFEO01BQU0sV0FBVyxNQUFNLGFBQWEsR0FBRyxLQUFLO01BQUcsV0FBVTtnQkFBekQsQ0FDSyxVQUFVLEtBQUssR0FBRyxRQUNmLHdCQUFDLE9BQUQ7T0FBdUIsSUFBSSxpQkFBaUIsRUFBRTtPQUFNLFdBQVU7aUJBQTlEO1FBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtVQUE0RixPQUFPLEVBQUUsaUJBQWlCLGFBQWE7b0JBQUksTUFBTTtTQUFROzs7O21CQUNwSyxFQUFFLGNBQWMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXVHO1NBQVc7Ozs7aUJBQ2xKOzs7Ozs7UUFDSixFQUFFLGlCQUNDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsT0FBRDtVQUFLLEtBQUssU0FBUyxFQUFFLGFBQWE7VUFBRyxLQUFJO1VBQWMsV0FBVTtVQUErRixlQUFlLGlCQUFpQjtXQUFFLEtBQUssU0FBUyxFQUFFLGFBQWE7V0FBRyxLQUFLO1VBQWMsQ0FBQztTQUFJOzs7O21CQUMxUCx3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLGVBQWUsaUJBQWlCO1dBQUUsS0FBSyxTQUFTLEVBQUUsYUFBYTtXQUFHLEtBQUs7VUFBYyxDQUFDO1VBQUcsV0FBVTtvQkFBekgsQ0FBOFUsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OztvQkFBQyxXQUFpQjs7Ozs7aUJBQ3JYOzs7Ozs7UUFFUixFQUFFLGlCQUFpQix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBcUksd0JBQUMsU0FBRDtVQUFPO1VBQVMsS0FBSyxTQUFTLEVBQUUsYUFBYTtVQUFHLFdBQVU7U0FBc0M7Ozs7O1FBQU07Ozs7O1FBQzlRLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUErSCx3QkFBQyxxQkFBRCxFQUFxQixTQUFTLEVBQUUsU0FBVzs7Ozs7UUFBTTs7Ozs7UUFDL0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQVEsa0JBQWtCLEdBQUcsU0FBUyxvQkFBb0Isc0JBQXNCLGNBQWMsZ0JBQWdCO1FBQU87Ozs7O09BQ25JO1NBZEssRUFBRSxNQUFNOzs7O2FBY2IsQ0FDUixHQUNELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUVWLGdCQUNHLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsZUFBZSxPQUFPLE1BQU07UUFDOUMsV0FBVTtrQkFEZCxDQUVJLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7a0JBQ2hCLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7Z0JBQ3ZCOzs7OztrQkFFUix3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFVBQVU7UUFDNUIsV0FBVTtRQUNWLE9BQU8sRUFBRSxpQkFBaUIsYUFBYTtrQkFGM0MsQ0FHSSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2tCQUNqQix3QkFBQyxRQUFELFlBQU8sYUFBYSwyQkFBMkIseUJBQStCOzs7O2dCQUMxRTs7Ozs7O01BRVg7Ozs7Y0FDSDs7Ozs7O0lBRVQ7Ozs7OztHQUdKLGdCQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUE2QyxlQUFlLGdCQUFnQixLQUFLO0lBQUk7Ozs7Y0FDcEcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FBeUYsd0JBQUMsWUFBRDtTQUFZLE1BQU07U0FBSSxXQUFVO1FBQWlCOzs7O2tCQUFDLGdCQUFrQjs7Ozs7aUJBQzdKLHdCQUFDLFVBQUQ7UUFBUSxlQUFlLGdCQUFnQixLQUFLO1FBQUcsV0FBVTtrQkFBbUYsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7T0FBUzs7OztlQUNsSzs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDSSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBMEMsd0JBQUMsUUFBRCxFQUFNLFdBQVUsOENBQStDOzs7O21CQUFDLFdBQWU7Ozs7OztRQUN6SCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBMEMsd0JBQUMsUUFBRCxFQUFNLFdBQVUsOERBQStEOzs7O21CQUFDLFFBQVk7Ozs7OztRQUN0SSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBMEMsd0JBQUMsUUFBRCxFQUFNLFdBQVUsNkNBQThDOzs7O21CQUFDLFlBQWdCOzs7Ozs7T0FDeEg7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNWLFVBQVUsS0FBSyxHQUFHLFNBQVM7UUFDeEIsTUFBTSxvQkFBb0I7U0FBRSxNQUFNLE1BQU0sUUFBUSxFQUFFO1NBQUssT0FBTyxFQUFFLFdBQVcsSUFBSSxNQUFNLFFBQVEsR0FBRyxLQUFLLElBQUksU0FBUyxJQUFJLFFBQVEsYUFBYSxRQUFRLFFBQVEsT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTO1FBQUcsRUFBQyxDQUFFO1FBQzdMLE1BQU0sV0FBVyxTQUFTO1FBQzFCLE1BQU0sV0FBVyxnQkFBZ0IsSUFBSSxFQUFFLEVBQUU7UUFDekMsT0FDSSx3QkFBQyxVQUFEO1NBQTJCLE1BQUs7U0FDNUIsZUFBZTtVQUFFLGVBQWUsSUFBSTtVQUFHLGdCQUFnQixLQUFLO1NBQUc7U0FDL0QsV0FBVyw2SEFDUCxXQUNNLGtEQUNBLFdBQ0EsNkJBQ0EsYUFDQSw4QkFDQTtTQUVWLE9BQU8sV0FBVyxFQUFFLGlCQUFpQixhQUFhLElBQUksQ0FBQzttQkFYM0QsQ0FZSyxPQUFPLEdBQ1AsWUFBWSxDQUFDLFlBQ1Ysd0JBQUMsUUFBRCxFQUFNLFdBQVUsa0hBQW1IOzs7O2lCQUVuSTtXQWhCSyxFQUFFLE1BQU07Ozs7ZUFnQmI7T0FFaEIsQ0FBQztNQUNBOzs7OztLQUNKOzs7OztZQUNKOzs7Ozs7R0FJUixtQkFDRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBNkMsZUFBZSxtQkFBbUIsS0FBSztJQUFJOzs7O2NBQ3ZHLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQStFLHdCQUFDLGVBQUQsRUFBZSxNQUFNLEdBQUs7Ozs7aUJBQUMsd0JBQUMsUUFBRCxZQUFNLDRCQUErQjs7OztlQUFNOzs7OztnQkFDckosd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxlQUFlLG1CQUFtQixLQUFLO09BQUcsV0FBVTtpQkFBOEYsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7TUFBUzs7OztjQUM5TDs7Ozs7ZUFDSixnQkFDRyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUF5TSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O2dCQUFDLHdCQUFDLFFBQUQsWUFBTSxxREFBd0Q7Ozs7Y0FBTTs7Ozs7Z0JBRXZTLHdCQUFDLFFBQUQ7TUFBTSxVQUFVO01BQWtCLFdBQVU7Z0JBQTVDO09BQ0ssZUFBZSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBMEk7T0FBaUI7Ozs7O09BQzFMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBb0U7T0FBcUI7Ozs7aUJBQzFHLHdCQUFDLFVBQUQ7UUFBUSxPQUFPO1FBQWMsV0FBVSxNQUFLLGdCQUFnQixFQUFFLE9BQU8sS0FBSztRQUFHLFdBQVU7a0JBQXZGO1NBQ0ksd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQXlCO1NBQXNDOzs7OztTQUM3RSx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBc0I7U0FBa0M7Ozs7O1NBQ3RFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFpQjtTQUEyQzs7Ozs7U0FDMUUsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQXNCO1NBQTJCOzs7OztTQUMvRCx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBVTtTQUFzQjs7Ozs7UUFDMUM7Ozs7O2VBQ1A7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFvRTtPQUFtQzs7OztpQkFDeEgsd0JBQUMsWUFBRDtRQUFVLE1BQU07UUFBRyxPQUFPO1FBQW1CLFdBQVUsTUFBSyxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7UUFBRyxhQUFZO1FBQTJDLFdBQVU7T0FBaU07Ozs7ZUFDblc7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLGVBQWUsbUJBQW1CLEtBQUs7U0FBRyxXQUFVO21CQUFtTDtRQUFhOzs7O2tCQUMxUSx3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLFVBQVU7U0FBa0IsV0FBVTttQkFBNUQsQ0FBdU4sd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OzttQkFBQyx3QkFBQyxRQUFELFlBQU8sbUJBQW1CLGdCQUFnQixnQkFBc0I7Ozs7aUJBQVM7Ozs7O2dCQUNqVDs7Ozs7O01BQ0g7Ozs7O2FBRVQ7Ozs7O1lBQ0o7Ozs7OztHQUlSLHFCQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUE2QyxlQUFlLHFCQUFxQixLQUFLO0lBQUk7Ozs7Y0FDekcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQXFFLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O09BQU07Ozs7aUJBQy9HLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFxRDtPQUFzQjs7OztlQUN4Rjs7Ozs7O01BQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBMEQ7UUFDbEMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQWdFLGdCQUFnQixNQUFLLE9BQVc7Ozs7OztRQUFDO09BQ3RIOzs7Ozs7TUFDSCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsZUFBZTtTQUNYLHFCQUFxQixLQUFLO1NBQzFCLE1BQU0sZ0JBQWdCLENBQUMsR0FBRyxlQUFlLENBQUMsQ0FBQztTQUMzQyxJQUFJLGVBQWU7VUFDZixNQUFNLEtBQUssU0FBUyxlQUFlLGlCQUFpQixlQUFlO1VBQ25FLElBQUksSUFBSSxHQUFHLGVBQWU7V0FBRSxVQUFVO1dBQVUsT0FBTztVQUFTLENBQUM7U0FDckU7UUFDSjtRQUNBLFdBQVU7a0JBQ2I7T0FBNkI7Ozs7aUJBQzlCLHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsZUFBZTtTQUNYLHFCQUFxQixLQUFLO1NBQzFCLGFBQWEsTUFBTSxPQUFPLElBQUk7UUFDbEM7UUFDQSxXQUFVO1FBQ1YsT0FBTyxFQUFFLGlCQUFpQixhQUFhO2tCQUMxQztPQUFtQjs7OztlQUNuQjs7Ozs7O0tBQ0o7Ozs7O1lBQ0o7Ozs7OztHQUlSLHFCQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUE2QyxlQUFlLHFCQUFxQixLQUFLO0lBQUk7Ozs7Y0FDekcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQXNGLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O09BQU07Ozs7aUJBQzVILHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFxRDtPQUFrQjs7OztlQUNwRjs7Ozs7O01BQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZDO01BQWlFOzs7OztNQUMzSCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsZUFBZSxxQkFBcUIsS0FBSztRQUFHLFdBQVU7a0JBQThLO09BQWE7Ozs7aUJBQ3ZRLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsZUFBZSxhQUFhLE1BQU0sS0FBSztRQUFHLFdBQVU7UUFBNEUsT0FBTyxFQUFFLGlCQUFpQixhQUFhO2tCQUFHO09BQWlCOzs7O2VBQ2hOOzs7Ozs7S0FDSjs7Ozs7WUFDSjs7Ozs7O0dBR1Qsd0JBQUMsb0JBQUQ7SUFBb0IsUUFBUSxDQUFDLENBQUM7SUFBZSxLQUFLLGVBQWU7SUFBSyxLQUFLLGVBQWU7SUFBSyxlQUFlLGlCQUFpQixJQUFJO0dBQUk7Ozs7O0VBQ3RJOzs7Ozs7QUFFYjs7Ozs7Ozs7O0FBRUEsU0FBUyxrQkFBa0IsR0FBRyxTQUFTLG9CQUFvQixzQkFBc0IsZUFBZSxXQUFXLGNBQWMsTUFBTTtDQUMzSCxNQUFNLE1BQU0sUUFBUSxFQUFFO0NBRXRCLElBQUksRUFBRSxXQUFXLEdBQUcsT0FDaEIsd0JBQUMsWUFBRDtFQUFVLE1BQU07RUFBRyxPQUFPLE9BQU87RUFBSSxXQUFVLE1BQUssbUJBQW1CLEVBQUUsSUFBSSxFQUFFLE9BQU8sS0FBSztFQUFHLGFBQVk7RUFBbUMsV0FBVTtDQUErTTs7Ozs7Q0FHMVcsSUFBSSxFQUFFLFdBQVcsR0FBRyxPQUNoQix3QkFBQyxPQUFEO0VBQUssV0FBVTthQUNULEVBQUUsV0FBVyxDQUFDLEVBQUMsQ0FBRSxLQUFJLFFBQU87R0FDMUIsTUFBTSxhQUFhLE9BQU8sR0FBRyxNQUFNLE9BQU8sSUFBSSxFQUFFO0dBQ2hELE1BQU0sU0FBUyxJQUFJLGVBQWUsSUFBSSxTQUFTLElBQUk7R0FDbkQsT0FDSSx3QkFBQyxTQUFEO0lBQW9CLFdBQVcsaUZBQWlGLGFBQWEsY0FBYztJQUN2SSxPQUFPLGFBQWE7S0FBRSxhQUFhO0tBQWMsaUJBQWlCLEdBQUcsYUFBYTtLQUFLLE9BQU87SUFBYSxJQUFJLENBQUM7Y0FEcEgsQ0FFSSx3QkFBQyxTQUFEO0tBQU8sTUFBSztLQUFRLE1BQU0sS0FBSyxFQUFFO0tBQU0sT0FBTyxJQUFJO0tBQUksU0FBUztLQUFZLGdCQUFnQixtQkFBbUIsRUFBRSxJQUFJLElBQUksRUFBRTtLQUFHLFdBQVU7S0FBZ0MsT0FBTyxFQUFFLGFBQWEsYUFBYTtJQUFJOzs7O2NBQzlNLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDSyxVQUNHLHdCQUFDLE9BQUQ7TUFDSSxLQUFLLFNBQVMsTUFBTTtNQUNwQixLQUFLLElBQUksY0FBYztNQUN2QixXQUFVO01BQ1YsVUFBVSxVQUFVO09BQ2hCLE1BQU0sZUFBZTtPQUNyQixNQUFNLGdCQUFnQjtPQUN0QixjQUFjO1FBQUUsS0FBSyxTQUFTLE1BQU07UUFBRyxLQUFLLElBQUksY0FBYztPQUFjLENBQUM7TUFDakY7S0FDSDs7OztlQUVMLHdCQUFDLHFCQUFELEVBQXFCLFNBQVMsSUFBSSxXQUFhOzs7O2FBQzlDOzs7OztZQUNGO01BbEJLLElBQUk7Ozs7VUFrQlQ7RUFFZixDQUFDO0NBQ0E7Ozs7O0NBR1QsSUFBSSxFQUFFLFdBQVcsR0FBRztFQUNoQixNQUFNLGNBQWMsTUFBTSxRQUFRLEdBQUcsSUFBSSxNQUFNLENBQUM7RUFDaEQsT0FDSSx3QkFBQyxPQUFEO0dBQUssV0FBVTtjQUNULEVBQUUsV0FBVyxDQUFDLEVBQUMsQ0FBRSxLQUFJLFFBQU87SUFDMUIsTUFBTSxZQUFZLFlBQVksU0FBUyxJQUFJLEVBQUU7SUFDN0MsTUFBTSxTQUFTLElBQUksZUFBZSxJQUFJLFNBQVMsSUFBSTtJQUNuRCxPQUNJLHdCQUFDLFNBQUQ7S0FBb0IsV0FBVyxpRkFBaUYsWUFBWSxjQUFjO0tBQ3RJLE9BQU8sWUFBWTtNQUFFLGFBQWE7TUFBYyxpQkFBaUIsR0FBRyxhQUFhO01BQUssT0FBTztLQUFhLElBQUksQ0FBQztlQURuSCxDQUVJLHdCQUFDLFNBQUQ7TUFBTyxNQUFLO01BQVcsU0FBUztNQUFXLFdBQVUsTUFBSyxxQkFBcUIsRUFBRSxJQUFJLElBQUksSUFBSSxFQUFFLE9BQU8sT0FBTztNQUFHLFdBQVU7TUFBd0MsT0FBTyxFQUFFLGFBQWEsYUFBYTtLQUFJOzs7O2VBQ3pNLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ssVUFDRyx3QkFBQyxPQUFEO09BQ0ksS0FBSyxTQUFTLE1BQU07T0FDeEIsS0FBSyxJQUFJLGNBQWM7T0FDbkIsV0FBVTtPQUNWLFVBQVUsVUFBVTtRQUNoQixNQUFNLGVBQWU7UUFDckIsTUFBTSxnQkFBZ0I7UUFDdEIsY0FBYztTQUFFLEtBQUssU0FBUyxNQUFNO1NBQUcsS0FBSyxJQUFJLGNBQWM7UUFBYyxDQUFDO09BQ2pGO01BQ0g7Ozs7Z0JBRUwsd0JBQUMscUJBQUQsRUFBcUIsU0FBUyxJQUFJLFdBQWE7Ozs7Y0FDOUM7Ozs7O2FBQ0Y7T0FsQkssSUFBSTs7OztXQWtCVDtHQUVmLENBQUM7RUFDQTs7Ozs7Q0FFYjtDQUVBLElBQUksRUFBRSxXQUFXLEdBQUcsT0FDaEIsd0JBQUMsU0FBRDtFQUNJLE1BQU0sRUFBRSxjQUFjLG1CQUFtQjtFQUN6QyxPQUFPLE9BQU87RUFDZCxXQUFVLE1BQUssbUJBQW1CLEVBQUUsSUFBSSxFQUFFLE9BQU8sS0FBSztFQUN0RCxXQUFVO0NBQ2I7Ozs7O0NBR0wsSUFBSSxFQUFFLFdBQVcsR0FBRyxPQUNoQix3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNWLENBQUM7R0FBRSxPQUFPO0dBQVMsT0FBTztFQUFRLEdBQUc7R0FBRSxPQUFPO0dBQVMsT0FBTztFQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUksV0FBVTtHQUNwRixNQUFNLGFBQWEsT0FBTyxHQUFHLE1BQU0sT0FBTztHQUMxQyxPQUNJLHdCQUFDLFVBQUQ7SUFBMkIsTUFBSztJQUFTLGVBQWUsbUJBQW1CLEVBQUUsSUFBSSxPQUFPLEtBQUs7SUFDekYsV0FBVyxnRkFBZ0YsYUFBYSx5QkFBeUI7SUFDakksT0FBTyxhQUFhO0tBQUUsaUJBQWlCO0tBQWMsYUFBYTtJQUFhLElBQUksQ0FBQztjQUNuRixPQUFPO0dBQ0osR0FKSyxPQUFPOzs7O1VBSVo7RUFFaEIsQ0FBQztDQUNBOzs7OztDQUdULE9BQU87QUFDWCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJGb3JtUnVubmVyUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHtcbiAgICBDbG9jaywgTG9jaywgQXJyb3dSaWdodCwgQXJyb3dMZWZ0LFxuICAgIEFsZXJ0Q2lyY2xlLCBTZW5kLCBMb2FkZXIyLCBNYXhpbWl6ZTIsXG4gICAgU3VuLCBNb29uLCBBbGVydFRyaWFuZ2xlLCBYLCBDaGVja0NpcmNsZTIsIEJvb2ttYXJrLCBCb29rbWFya0NoZWNrLCBFeWUsXG4gICAgTGF5b3V0R3JpZCwgV2lmaSwgV2lmaU9mZlxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHtcbiAgICBnZXRQdWJsaWNGb3JtQnlMaW5rLCBnZXRQdWJsaWNGb3JtUXVlc3Rpb25zLCBzdWJtaXRQdWJsaWNGb3JtUmVzcG9uc2UsXG4gICAgc3VibWl0RmVlZGJhY2ssIGNsZWFyU2Vzc2lvbiwgYXNzZXRVcmwsIGdldExvY2FsVXNlcixcbiAgICBnZXRGb3JtQnlJZCwgZ2V0UXVlc3Rpb25zLCBnZXRNeUZvcm1zLCBwb3N0RXhhbUV2ZW50LFxuICAgIHN5bmNFeGFtQW5zd2Vyc1xufSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCBSaWNoQ29udGVudFJlbmRlcmVyIGZyb20gJy4uLy4uL3V0aWxzL1JpY2hDb250ZW50UmVuZGVyZXInO1xuaW1wb3J0IEltYWdlTGlnaHRib3hNb2RhbCBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpL0ltYWdlTGlnaHRib3hNb2RhbCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZvcm1SdW5uZXJQYWdlKCkge1xuICAgIGNvbnN0IHsgZm9ybUxpbmsgfSA9IHVzZVBhcmFtcygpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBbc2VhcmNoUGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuICAgIGNvbnN0IGlzUHJldmlld01vZGUgPSBzZWFyY2hQYXJhbXMuZ2V0KCdwcmV2aWV3JykgPT09ICd0cnVlJztcblxuICAgIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtxdWVzdGlvbnMsIHNldFF1ZXN0aW9uc10gPSB1c2VTdGF0ZShbXSk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW3N1Ym1pdHRpbmcsIHNldFN1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFt2YWxpZGF0aW9uVG9hc3QsIHNldFZhbGlkYXRpb25Ub2FzdF0gPSB1c2VTdGF0ZShudWxsKTtcblxuICAgIGNvbnN0IFt0b2tlbklucHV0LCBzZXRUb2tlbklucHV0XSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbdG9rZW5VbmxvY2tlZCwgc2V0VG9rZW5VbmxvY2tlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3Jlc3BvbmRlbnROYW1lLCBzZXRSZXNwb25kZW50TmFtZV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgLy8gQlVHLTUgRklYOiBLZWVwIHJlc3BvbmRlbnROYW1lIGluIGEgcmVmIHNvIHNlbmRFeGFtRXZlbnQgZG9lc24ndCBuZWVkIGl0XG4gICAgLy8gYXMgYSB1c2VDYWxsYmFjayBkZXBlbmRlbmN5IOKAlCBwcmV2ZW50aW5nIHNlc3Npb25fc3RhcnQgZnJvbSByZS1maXJpbmcgb25cbiAgICAvLyBldmVyeSBrZXlzdHJva2Ugd2hpbGUgdGhlIHVzZXIgdHlwZXMgdGhlaXIgbmFtZS5cbiAgICBjb25zdCByZXNwb25kZW50TmFtZVJlZiA9IHVzZVJlZignJyk7XG5cbiAgICAvLyBBLTI6IHNvbGlkIHllbGxvdyByYWd1LXJhZ3VcbiAgICBjb25zdCBbbWFya2VkRm9yUmV2aWV3LCBzZXRNYXJrZWRGb3JSZXZpZXddID0gdXNlU3RhdGUobmV3IFNldCgpKTtcbiAgICAvLyBBLTE6IG5hdiBwb3B1cFxuICAgIGNvbnN0IFtuYXZQb3B1cE9wZW4sIHNldE5hdlBvcHVwT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgLy8gRkVBVC0zOiBzdWJtaXQgY29uZmlybVxuICAgIGNvbnN0IFtzdWJtaXRDb25maXJtT3Blbiwgc2V0U3VibWl0Q29uZmlybU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIC8vIEIxMDogRmlyc3QgZGlhbG9nIOKAlCB3YXJucyBhYm91dCByYWd1LXJhZ3UgcXVlc3Rpb25zIGJlZm9yZSBzdWJtaXQgY29uZmlybWF0aW9uXG4gICAgY29uc3QgW3Jldmlld1dhcm5pbmdPcGVuLCBzZXRSZXZpZXdXYXJuaW5nT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgLy8gRXhhbSBtb2RlIG1vbml0b3JpbmcgJiB2aW9sYXRpb24gdHJhY2tpbmcgKFNlcnZlci1zaWRlIHNvdXJjZSBvZiB0cnV0aClcbiAgICBjb25zdCBbdGFiU3dpdGNoQ291bnQsIHNldFRhYlN3aXRjaENvdW50XSA9IHVzZVN0YXRlKDApO1xuICAgIGNvbnN0IFt2aW9sYXRpb25Db3VudCwgc2V0VmlvbGF0aW9uQ291bnRdID0gdXNlU3RhdGUoMCk7XG4gICAgY29uc3QgW3RhYlN3aXRjaFdhcm5pbmcsIHNldFRhYlN3aXRjaFdhcm5pbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IGxhc3RUYWJTd2l0Y2hBdFJlZiA9IHVzZVJlZigwKTtcblxuICAgIC8vIFBlcnNpc3RlbnQgc2Vzc2lvbklkIGZvciBleGFtIG1vZGUgKHBlciBmb3JtTGluaykuXG4gICAgLy8gS29udHJhayBkZW5nYW4gYmFja2VuZDogZXZlbnQgcGVydGFtYSBkaWtpcmltIFRBTlBBIHNlc3Npb25JZFxuICAgIC8vIChudWxsKSBhZ2FyIHNlcnZlciB5YW5nIGdlbmVyYXRlOyBJRCBiYWxpa2FuIHNlcnZlciBkaXNpbXBhbiBkYW5cbiAgICAvLyBkaXBha2FpIHVsYW5nLiBKYW5nYW4gcHJlLWdlbmVyYXRlIFVVSUQgZGkga2xpZW4g4oCUIElEIHRhayBkaWtlbmFsXG4gICAgLy8gdGlkYWsgbGFnaSBkaWFydGlrYW4gc2ViYWdhaSBcInNlc2kgZGktcmVzZXRcIi5cbiAgICBjb25zdCBnZXRTdG9yZWRTZXNzaW9uSWQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykgcmV0dXJuIG51bGw7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShgZm9ybXVwX2V4YW1fc2Vzc2lvbl8ke2Zvcm1MaW5rfWApO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgfSwgW2Zvcm1MaW5rXSk7XG4gICAgY29uc3QgZXhhbVNlc3Npb25JZFJlZiA9IHVzZVJlZihudWxsKTtcbiAgICBpZiAoIWV4YW1TZXNzaW9uSWRSZWYuY3VycmVudCAmJiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICBleGFtU2Vzc2lvbklkUmVmLmN1cnJlbnQgPSBnZXRTdG9yZWRTZXNzaW9uSWQoKTtcbiAgICB9XG5cbiAgICBjb25zdCBbYW5zd2Vycywgc2V0QW5zd2Vyc10gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjYWNoZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShgZm9ybXVwX2NhY2hlXyR7Zm9ybUxpbmt9YCk7XG4gICAgICAgICAgICAgICAgaWYgKGNhY2hlZCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKGNhY2hlZCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwYXJzZWQgJiYgdHlwZW9mIHBhcnNlZCA9PT0gJ29iamVjdCcpIHJldHVybiBwYXJzZWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCB7fVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7fTtcbiAgICB9KTtcbiAgICBjb25zdCBhbnN3ZXJzUmVmID0gdXNlUmVmKGFuc3dlcnMpO1xuICAgIGNvbnN0IHF1ZXN0aW9uc1JlZiA9IHVzZVJlZihxdWVzdGlvbnMpO1xuXG4gICAgY29uc3QgW2N1cnJlbnRTdGVwLCBzZXRDdXJyZW50U3RlcF0gPSB1c2VTdGF0ZSgwKTtcbiAgICBjb25zdCBbbGlnaHRib3hJbWFnZSwgc2V0TGlnaHRib3hJbWFnZV0gPSB1c2VTdGF0ZShudWxsKTtcblxuICAgIGNvbnN0IFtyZXBvcnRNb2RhbE9wZW4sIHNldFJlcG9ydE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3JlcG9ydFJlYXNvbiwgc2V0UmVwb3J0UmVhc29uXSA9IHVzZVN0YXRlKCdQRVJUQU5ZQUFOX1RJREFLX0pFTEFTJyk7XG4gICAgY29uc3QgW3JlcG9ydERlc2NyaXB0aW9uLCBzZXRSZXBvcnREZXNjcmlwdGlvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW3N1Ym1pdHRpbmdSZXBvcnQsIHNldFN1Ym1pdHRpbmdSZXBvcnRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtyZXBvcnRTdWNjZXNzLCBzZXRSZXBvcnRTdWNjZXNzXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbcmVwb3J0RXJyb3IsIHNldFJlcG9ydEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcblxuICAgIGNvbnN0IFt0aW1lTGVmdCwgc2V0VGltZUxlZnRdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgdGltZXJSZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgY29uc3QgaXNTdWJtaXR0aW5nUmVmID0gdXNlUmVmKGZhbHNlKTtcblxuICAgIGNvbnN0IFtpc0RhcmtNb2RlLCBzZXRJc0RhcmtNb2RlXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICByZXR1cm4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsYXNzTGlzdC5jb250YWlucygnZGFyaycpIHx8IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0aGVtZScpID09PSAnZGFyayc7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0pO1xuXG4gICAgY29uc3QgdG9nZ2xlRGFya01vZGUgPSAoKSA9PiB7XG4gICAgICAgIHNldElzRGFya01vZGUocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gIXByZXY7XG4gICAgICAgICAgICBpZiAobmV4dCkgeyBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnZGFyaycpOyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndGhlbWUnLCAnZGFyaycpOyB9XG4gICAgICAgICAgICBlbHNlIHsgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2RhcmsnKTsgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RoZW1lJywgJ2xpZ2h0Jyk7IH1cbiAgICAgICAgICAgIHJldHVybiBuZXh0O1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgY3VycmVudFVzZXJSZWYgPSB1c2VSZWYoZ2V0TG9jYWxVc2VyKCkpO1xuICAgIGNvbnN0IGN1cnJlbnRVc2VyID0gY3VycmVudFVzZXJSZWYuY3VycmVudDtcblxuICAgIGNvbnN0IGV4YW1FdmVudFNlcVJlZiA9IHVzZVJlZigwKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7IHJlc3BvbmRlbnROYW1lUmVmLmN1cnJlbnQgPSByZXNwb25kZW50TmFtZTsgfSwgW3Jlc3BvbmRlbnROYW1lXSk7XG5cbiAgICAvLyBPZmZsaW5lLUZpcnN0IE1vZGU6IFRyYWNrIG9ubGluZS9vZmZsaW5lIHN0YXR1cyBhbmQgYXV0by1zeW5jXG4gICAgY29uc3QgW2lzT25saW5lLCBzZXRJc09ubGluZV0gPSB1c2VTdGF0ZSgoKSA9PiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdy5uYXZpZ2F0b3Iub25MaW5lIDogdHJ1ZSk7XG4gICAgY29uc3QgW3Nob3dSZXN0b3JlZFRvYXN0LCBzZXRTaG93UmVzdG9yZWRUb2FzdF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBoYW5kbGVPbmxpbmUgPSAoKSA9PiB7XG4gICAgICAgICAgICBzZXRJc09ubGluZSh0cnVlKTtcbiAgICAgICAgICAgIHNldFNob3dSZXN0b3JlZFRvYXN0KHRydWUpO1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTaG93UmVzdG9yZWRUb2FzdChmYWxzZSksIDQwMDApO1xuICAgICAgICAgICAgaWYgKGZvcm0gJiYgYW5zd2VycyAmJiBPYmplY3Qua2V5cyhhbnN3ZXJzKS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2lkID0gZXhhbVNlc3Npb25JZFJlZi5jdXJyZW50IHx8IGdldFN0b3JlZFNlc3Npb25JZCgpO1xuICAgICAgICAgICAgICAgIGlmIChzaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgc3luY0V4YW1BbnN3ZXJzKGZvcm1MaW5rLCBzaWQsIGFuc3dlcnMpLmNhdGNoKCgpID0+IHt9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGhhbmRsZU9mZmxpbmUgPSAoKSA9PiB7XG4gICAgICAgICAgICBzZXRJc09ubGluZShmYWxzZSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ29ubGluZScsIGhhbmRsZU9ubGluZSk7XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdvZmZsaW5lJywgaGFuZGxlT2ZmbGluZSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignb25saW5lJywgaGFuZGxlT25saW5lKTtcbiAgICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdvZmZsaW5lJywgaGFuZGxlT2ZmbGluZSk7XG4gICAgICAgIH07XG4gICAgfSwgW2Zvcm0sIGFuc3dlcnMsIGZvcm1MaW5rLCBnZXRTdG9yZWRTZXNzaW9uSWRdKTtcblxuICAgIC8vIGF1dG8tY2FjaGUgdG8gbG9jYWwgc3RvcmFnZSBvbiBhbnN3ZXIgY2hhbmdlXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGZvcm1MaW5rICYmIE9iamVjdC5rZXlzKGFuc3dlcnMpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKGBmb3JtdXBfY2FjaGVfJHtmb3JtTGlua31gLCBKU09OLnN0cmluZ2lmeShhbnN3ZXJzKSk7IH0gY2F0Y2gge31cbiAgICAgICAgfVxuICAgIH0sIFthbnN3ZXJzLCBmb3JtTGlua10pO1xuXG4gICAgLy8gQi0yOiBhcHBseSB0aGVtZVxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghZm9ybSkgcmV0dXJuO1xuICAgICAgICBjb25zdCByb290ID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50O1xuICAgICAgICBpZiAoZm9ybS50aGVtZVByaW1hcnlDb2xvcikgcm9vdC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1mb3JtLXByaW1hcnknLCBmb3JtLnRoZW1lUHJpbWFyeUNvbG9yKTtcbiAgICAgICAgaWYgKGZvcm0udGhlbWVCYWNrZ3JvdW5kQ29sb3IpIHJvb3Quc3R5bGUuc2V0UHJvcGVydHkoJy0tZm9ybS1iZycsIGZvcm0udGhlbWVCYWNrZ3JvdW5kQ29sb3IpO1xuICAgICAgICByZXR1cm4gKCkgPT4geyByb290LnN0eWxlLnJlbW92ZVByb3BlcnR5KCctLWZvcm0tcHJpbWFyeScpOyByb290LnN0eWxlLnJlbW92ZVByb3BlcnR5KCctLWZvcm0tYmcnKTsgfTtcbiAgICB9LCBbZm9ybV0pO1xuXG4gICAgY29uc3QgW2lzRm9yY2VTdWJtaXR0ZWQsIHNldElzRm9yY2VTdWJtaXR0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IGlzRm9yY2VTdWJtaXR0ZWRSZWYgPSB1c2VSZWYoZmFsc2UpO1xuXG4gICAgLy8gQjEyIFByb2N0b3Jpbmc6IEhhbmRsZSBwcm9jdG9yIGZvcmNlIHN1Ym1pdCAvIHNlc3Npb24gdGVybWluYXRpb25cbiAgICBjb25zdCBoYW5kbGVGb3JjZVN1Ym1pdFRlcm1pbmF0aW9uID0gdXNlQ2FsbGJhY2soKHJlc3BvbnNlSWQgPSBudWxsKSA9PiB7XG4gICAgICAgIGlmIChpc0ZvcmNlU3VibWl0dGVkUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICAgICAgaXNGb3JjZVN1Ym1pdHRlZFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgaXNTdWJtaXR0aW5nUmVmLmN1cnJlbnQgPSB0cnVlO1xuXG4gICAgICAgIGlmICh0aW1lclJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBjbGVhckludGVydmFsKHRpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgICAgICAgdGltZXJSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oYGZvcm11cF9jYWNoZV8ke2Zvcm1MaW5rfWApO1xuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oYGZvcm11cF90aW1lcl9kZWFkbGluZV8ke2Zvcm1MaW5rfWApO1xuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oYGZvcm11cF90b2tlbl8ke2Zvcm1MaW5rfWApO1xuICAgICAgICAgICAgaWYgKHJlc3BvbnNlSWQpIHtcbiAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShgZm9ybXVwX3N1Ym1pdHRlZF8ke2Zvcm1MaW5rfWAsIFN0cmluZyhyZXNwb25zZUlkKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKGBmb3JtdXBfZXhhbV9zZXNzaW9uXyR7Zm9ybUxpbmt9YCk7XG4gICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKGBmb3JtdXBfdmlvbGF0aW9uc18ke2Zvcm1MaW5rfWApO1xuICAgICAgICB9IGNhdGNoIHt9XG5cbiAgICAgICAgc2V0SXNGb3JjZVN1Ym1pdHRlZCh0cnVlKTtcbiAgICAgICAgaWYgKHJlc3BvbnNlSWQpIHtcbiAgICAgICAgICAgIG5hdmlnYXRlKGAvZi8ke2Zvcm1MaW5rfS9yZXN1bHQvJHtyZXNwb25zZUlkfWApO1xuICAgICAgICB9XG4gICAgfSwgW2Zvcm1MaW5rLCBuYXZpZ2F0ZV0pO1xuXG4gICAgY29uc3Qgc2VuZEV4YW1FdmVudCA9IHVzZUNhbGxiYWNrKGFzeW5jIChldmVudFR5cGUpID0+IHtcbiAgICBpZiAoIWZvcm0gfHwgaXNQcmV2aWV3TW9kZSB8fCBmb3JtLmlzT3duZXIpIHJldHVybjtcbiAgICBjb25zdCBpc0V4YW0gPSBmb3JtLmlzRXhhbU1vZGUgfHwgZm9ybS5kZXRlY3RUYWJTd2l0Y2g7XG4gICAgaWYgKCFpc0V4YW0gJiYgIWZvcm0uZGlzYWJsZUNvcHlQYXN0ZSkgcmV0dXJuO1xuICAgIGlmIChpc1N1Ym1pdHRpbmdSZWYuY3VycmVudCB8fCBpc0ZvcmNlU3VibWl0dGVkUmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgIGNvbnN0IG15U2VxID0gKytleGFtRXZlbnRTZXFSZWYuY3VycmVudDtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3Qgc2lkID0gZXhhbVNlc3Npb25JZFJlZi5jdXJyZW50IHx8IGdldFN0b3JlZFNlc3Npb25JZCgpO1xuICAgICAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHNpZCxcbiAgICAgICAgICAgICAgICByZXNwb25kZW50TmFtZTogKHJlc3BvbmRlbnROYW1lUmVmLmN1cnJlbnQgfHwgJycpLnRyaW0oKSB8fCBjdXJyZW50VXNlcj8uZnVsbG5hbWUgfHwgJ0Fub25pbScsXG4gICAgICAgICAgICAgICAgdHlwZTogZXZlbnRUeXBlLFxuICAgICAgICAgICAgICAgIG9jY3VycmVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBwb3N0RXhhbUV2ZW50KGZvcm1MaW5rLCBwYXlsb2FkKTtcblxuICAgICAgICAgICAgY29uc3QgaXNUZXJtaW5hdGVkID0gcmVzLnN0YXR1cyA9PT0gNDEwIHx8IHJlcy5zdGF0dXMgPT09IDQwOSB8fFxuICAgICAgICAgICAgICAgIHJlcy5kYXRhPy5pc0ZvcmNlU3VibWl0dGVkIHx8IHJlcy5kYXRhPy5pc1N1Ym1pdHRlZCB8fFxuICAgICAgICAgICAgICAgIHJlcy5kYXRhPy5zdGF0dXMgPT09ICdzdWJtaXR0ZWQnIHx8IHJlcy5kYXRhPy5zdGF0dXMgPT09ICdmb3JjZS1zdWJtaXR0ZWQnIHx8XG4gICAgICAgICAgICAgICAgcmVzLmRhdGE/LnN0YXR1cyA9PT0gJ3Rlcm1pbmF0ZWQnO1xuXG4gICAgICAgICAgICBpZiAoaXNUZXJtaW5hdGVkKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcElkID0gcmVzLmRhdGE/LnJlc3BvbnNlSWQgfHwgcmVzLmRhdGE/LmlkO1xuICAgICAgICAgICAgICAgIGhhbmRsZUZvcmNlU3VibWl0VGVybWluYXRpb24ocmVzcElkKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChyZXMub2sgJiYgcmVzLmRhdGEpIHtcbiAgICAgICAgICAgICAgICBpZiAocmVzLmRhdGEuc2Vzc2lvbklkKSB7XG4gICAgICAgICAgICAgICAgICAgIGV4YW1TZXNzaW9uSWRSZWYuY3VycmVudCA9IHJlcy5kYXRhLnNlc3Npb25JZDtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHsgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShgZm9ybXVwX2V4YW1fc2Vzc2lvbl8ke2Zvcm1MaW5rfWAsIHJlcy5kYXRhLnNlc3Npb25JZCk7IH0gY2F0Y2gge31cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiByZXMuZGF0YS50YWJTd2l0Y2hDb3VudCA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0VGFiU3dpdGNoQ291bnQocmVzLmRhdGEudGFiU3dpdGNoQ291bnQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHJlcy5kYXRhLnZpb2xhdGlvbkNvdW50ID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgICAgICBzZXRWaW9sYXRpb25Db3VudChyZXMuZGF0YS52aW9sYXRpb25Db3VudCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIE9ubHkgc2hvdyB3YXJuaW5nIGJhbm5lciB3aGVuIGFuIGFjdHVhbCB2aW9sYXRpb24gZXZlbnQgb2NjdXJzLCBub3Qgb24gcHJlc2VuY2UgKHNlc3Npb25fc3RhcnQgLyBoZWFydGJlYXQpXG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50VHlwZSAhPT0gJ3Nlc3Npb25fc3RhcnQnICYmIGV2ZW50VHlwZSAhPT0gJ2hlYXJ0YmVhdCcpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0VGFiU3dpdGNoV2FybmluZyh0cnVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHJlcy5kYXRhLnNob3VsZEF1dG9TdWJtaXQgJiYgIWlzU3VibWl0dGluZ1JlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gaGFuZGxlU3VibWl0KG51bGwsIHRydWUpLCAxMDAwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKCdbRXhhbUV2ZW50XSBCYWNrZ3JvdW5kIGV2ZW50IHJlcG9ydCBmYWlsZWQ6JywgZXZlbnRUeXBlLCBlcnIpO1xuICAgICAgICB9XG4gICAgfSwgW2Zvcm0sIGZvcm1MaW5rLCBpc1ByZXZpZXdNb2RlLCBjdXJyZW50VXNlciwgaGFuZGxlRm9yY2VTdWJtaXRUZXJtaW5hdGlvbl0pO1xuXG4gICAgLy8gRXhhbSBtb2RlIHNlc3Npb24gcHJlc2VuY2U6IHNlc3Npb25fc3RhcnQgYW5kIHBlcmlvZGljIGhlYXJ0YmVhdFxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghZm9ybSB8fCBpc1ByZXZpZXdNb2RlIHx8IGZvcm0uaXNPd25lcikgcmV0dXJuO1xuICAgICAgICBpZiAoIWZvcm0uaXNFeGFtTW9kZSAmJiAhZm9ybS5kZXRlY3RUYWJTd2l0Y2gpIHJldHVybjtcbiAgICAgICAgaWYgKGZvcm0ucmVxdWlyZXNUb2tlbiAmJiAhdG9rZW5VbmxvY2tlZCkgcmV0dXJuO1xuXG4gICAgICAgIC8vIFN0YXJ0IHNlc3Npb24gb24gc2VydmVyXG4gICAgICAgIHNlbmRFeGFtRXZlbnQoJ3Nlc3Npb25fc3RhcnQnKTtcblxuICAgICAgICAvLyBQZXJpb2RpYyBoZWFydGJlYXQgZXZlcnkgMzAgc2Vjb25kc1xuICAgICAgICBjb25zdCBoZWFydGJlYXRUaW1lciA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgICAgIGlmICghaXNTdWJtaXR0aW5nUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgICAgICBzZW5kRXhhbUV2ZW50KCdoZWFydGJlYXQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgMzAwMDApO1xuXG4gICAgICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKGhlYXJ0YmVhdFRpbWVyKTtcbiAgICB9LCBbZm9ybSwgaXNQcmV2aWV3TW9kZSwgdG9rZW5VbmxvY2tlZCwgc2VuZEV4YW1FdmVudF0pO1xuXG4gICAgLy8gRXhhbSBtb2RlIHZpb2xhdGlvbiBkZXRlY3Rpb24gKFJlYWwtdGltZSBpbmNyZW1lbnRhbCByZXBvcnQsIGFudGkgZG91YmxlLWNvdW50KVxuICAgIC8vIEJVRy0yIEZJWDogR3VhcmQgd2l0aCB0b2tlblVubG9ja2VkIHNvIHRoZSB2aXNpYmlsaXR5Y2hhbmdlIC8gY29weSAvIHBhc3RlXG4gICAgLy8gbGlzdGVuZXJzIGFyZSBvbmx5IGF0dGFjaGVkIEFGVEVSIHRoZSB1c2VyIGhhcyBwYXNzZWQgdGhlIHRva2VuIHNjcmVlbiBhbmRcbiAgICAvLyBpcyBhY3R1YWxseSBvbiB0aGUgcXVlc3Rpb24gcGFnZS5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWZvcm0gfHwgaXNQcmV2aWV3TW9kZSB8fCBmb3JtLmlzT3duZXIgfHwgaXNGb3JjZVN1Ym1pdHRlZCkgcmV0dXJuO1xuICAgICAgICAvLyBEbyBOT1QgYXR0YWNoIHZpb2xhdGlvbiBsaXN0ZW5lcnMgdW50aWwgdGhlIGV4YW0gaGFzIGFjdHVhbGx5IHN0YXJ0ZWRcbiAgICAgICAgaWYgKGZvcm0ucmVxdWlyZXNUb2tlbiAmJiAhdG9rZW5VbmxvY2tlZCkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IGlzRXhhbSA9IGZvcm0uaXNFeGFtTW9kZSB8fCBmb3JtLmRldGVjdFRhYlN3aXRjaDtcbiAgICAgICAgY29uc3QgZGlzYWJsZUNvcHkgPSBmb3JtLmRpc2FibGVDb3B5UGFzdGUgfHwgaXNFeGFtO1xuXG4gICAgICAgIGNvbnN0IGhhbmRsZVZpc2liaWxpdHlDaGFuZ2UgPSAoKSA9PiB7XG4gICAgICAgICAgICBpZiAoaXNGb3JjZVN1Ym1pdHRlZFJlZi5jdXJyZW50IHx8IGlzU3VibWl0dGluZ1JlZi5jdXJyZW50KSByZXR1cm47XG4gICAgICAgICAgICAvLyBBbnRpLWRvdWJsZS1jb3VudDogT05MWSByZXBvcnQgb24gaGlkZGVuIChsZWF2aW5nKSwgbmV2ZXIgb24gdmlzaWJsZSAocmV0dXJuKVxuICAgICAgICAgICAgaWYgKGRvY3VtZW50LmhpZGRlbiAmJiBpc0V4YW0pIHJlcG9ydFRhYlN3aXRjaCgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IHJlcG9ydFRhYlN3aXRjaCA9ICgpID0+IHtcbiAgICAgICAgICAgIGlmICghaXNFeGFtIHx8IGlzRm9yY2VTdWJtaXR0ZWRSZWYuY3VycmVudCB8fCBpc1N1Ym1pdHRpbmdSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgICAgICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgIC8vIGJsdXIgYW5kIHZpc2liaWxpdHljaGFuZ2UgY2FuIGRlc2NyaWJlIHRoZSBzYW1lIHRhYiBzd2l0Y2guXG4gICAgICAgICAgICBpZiAobm93IC0gbGFzdFRhYlN3aXRjaEF0UmVmLmN1cnJlbnQgPCAxMDAwKSByZXR1cm47XG4gICAgICAgICAgICBsYXN0VGFiU3dpdGNoQXRSZWYuY3VycmVudCA9IG5vdztcbiAgICAgICAgICAgIHNlbmRFeGFtRXZlbnQoJ3RhYl9zd2l0Y2gnKTtcbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCBoYW5kbGVXaW5kb3dCbHVyID0gKCkgPT4ge1xuICAgICAgICAgICAgaWYgKGRvY3VtZW50LmhpZGRlbiB8fCBpc0V4YW0pIHJlcG9ydFRhYlN3aXRjaCgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IGhhbmRsZUNvcHkgPSAoZSkgPT4ge1xuICAgICAgICAgICAgaWYgKGlzRm9yY2VTdWJtaXR0ZWRSZWYuY3VycmVudCB8fCBpc1N1Ym1pdHRpbmdSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgICAgICAgaWYgKGRpc2FibGVDb3B5KSB7XG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgIHNlbmRFeGFtRXZlbnQoJ2NvcHlfYXR0ZW1wdCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IGhhbmRsZVBhc3RlID0gKGUpID0+IHtcbiAgICAgICAgICAgIGlmIChpc0ZvcmNlU3VibWl0dGVkUmVmLmN1cnJlbnQgfHwgaXNTdWJtaXR0aW5nUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICAgICAgICAgIGlmIChkaXNhYmxlQ29weSkge1xuICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICBzZW5kRXhhbUV2ZW50KCdwYXN0ZV9hdHRlbXB0Jyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgaGFuZGxlQ29udGV4dE1lbnUgPSAoZSkgPT4ge1xuICAgICAgICAgICAgaWYgKGlzRm9yY2VTdWJtaXR0ZWRSZWYuY3VycmVudCB8fCBpc1N1Ym1pdHRpbmdSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgICAgICAgaWYgKGRpc2FibGVDb3B5KSB7XG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgIHNlbmRFeGFtRXZlbnQoJ2NvbnRleHRfbWVudScpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGlmIChpc0V4YW0pIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBoYW5kbGVWaXNpYmlsaXR5Q2hhbmdlKTtcbiAgICAgICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdibHVyJywgaGFuZGxlV2luZG93Qmx1cik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGRpc2FibGVDb3B5KSB7XG4gICAgICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjb3B5JywgaGFuZGxlQ29weSk7XG4gICAgICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjdXQnLCBoYW5kbGVDb3B5KTtcbiAgICAgICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Bhc3RlJywgaGFuZGxlUGFzdGUpO1xuICAgICAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY29udGV4dG1lbnUnLCBoYW5kbGVDb250ZXh0TWVudSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgaWYgKGlzRXhhbSkge1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBoYW5kbGVWaXNpYmlsaXR5Q2hhbmdlKTtcbiAgICAgICAgICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignYmx1cicsIGhhbmRsZVdpbmRvd0JsdXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGRpc2FibGVDb3B5KSB7XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY29weScsIGhhbmRsZUNvcHkpO1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2N1dCcsIGhhbmRsZUNvcHkpO1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Bhc3RlJywgaGFuZGxlUGFzdGUpO1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NvbnRleHRtZW51JywgaGFuZGxlQ29udGV4dE1lbnUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0sIFtmb3JtLCBpc1ByZXZpZXdNb2RlLCB0b2tlblVubG9ja2VkLCBzZW5kRXhhbUV2ZW50LCBpc0ZvcmNlU3VibWl0dGVkXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4geyBhbnN3ZXJzUmVmLmN1cnJlbnQgPSBhbnN3ZXJzOyB9LCBbYW5zd2Vyc10pO1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7IHF1ZXN0aW9uc1JlZi5jdXJyZW50ID0gcXVlc3Rpb25zOyB9LCBbcXVlc3Rpb25zXSk7XG5cbiAgICAvLyBCMTIgUHJvY3RvcmluZzogQ29udGludW91cyBiYWNrZ3JvdW5kIHN5bmMgb2YgZHJhZnQgYW5zd2VycyBmb3IgZXhhbSBtb2RlXG4gICAgY29uc3Qgc3luY0luUHJvZ3Jlc3NSZWYgPSB1c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IGxhc3RTeW5jZWRIYXNoUmVmID0gdXNlUmVmKCcnKTtcblxuICAgIGNvbnN0IHN5bmNEcmFmdEFuc3dlcnMgPSB1c2VDYWxsYmFjayhhc3luYyAoY3VzdG9tQW5zd2VycyA9IG51bGwsIGZvcmNlQ2hlY2sgPSBmYWxzZSkgPT4ge1xuICAgIGlmICghZm9ybSB8fCBpc1ByZXZpZXdNb2RlIHx8IGZvcm0uaXNPd25lciB8fCBpc0ZvcmNlU3VibWl0dGVkUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBjb25zdCBpc0V4YW0gPSBmb3JtLmlzRXhhbU1vZGUgfHwgZm9ybS5kZXRlY3RUYWJTd2l0Y2g7XG4gICAgaWYgKCFpc0V4YW0pIHJldHVybjtcbiAgICBpZiAoZm9ybS5yZXF1aXJlc1Rva2VuICYmICF0b2tlblVubG9ja2VkKSByZXR1cm47XG4gICAgaWYgKGlzU3VibWl0dGluZ1JlZi5jdXJyZW50IHx8IHN5bmNJblByb2dyZXNzUmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgIGNvbnN0IHNpZCA9IGV4YW1TZXNzaW9uSWRSZWYuY3VycmVudCB8fCBnZXRTdG9yZWRTZXNzaW9uSWQoKTtcbiAgICBpZiAoIXNpZCkgcmV0dXJuO1xuXG4gICAgY29uc3QgY3VyQW5zID0gY3VzdG9tQW5zd2VycyB8fCBhbnN3ZXJzUmVmLmN1cnJlbnQgfHwge307XG4gICAgY29uc3QgY3VyUXMgPSBxdWVzdGlvbnNSZWYuY3VycmVudD8ubGVuZ3RoID8gcXVlc3Rpb25zUmVmLmN1cnJlbnQgOiBxdWVzdGlvbnM7XG5cbiAgICAvLyBGSVggKEZvcmNlIFN1Ym1pdCB0aWRhayBtZW5naGVudGlrYW4gcmVzcG9uZGVuKTogZHVsdSBmdW5nc2kgaW5pXG4gICAgLy8gbGFuZ3N1bmcgYmVyaGVudGkga2FsYXUgYmVsdW0gYWRhIGphd2FiYW4gc2FtYSBzZWthbGksIGF0YXUga2FsYXVcbiAgICAvLyBqYXdhYmFuIHRpZGFrIGJlcnViYWggc2VqYWsgc3luYyB0ZXJha2hpci4gQWtpYmF0bnlhLCByZXNwb25kZW4geWFuZ1xuICAgIC8vIHNlZGFuZyBkaWFtL2JlbHVtIG1lbmphd2FiIHRpZGFrIHBlcm5haCBtZW5naXJpbSByZXF1ZXN0IGFwYSBwdW4ga2VcbiAgICAvLyBzZXJ2ZXIsIHNlaGluZ2dhIGZvcmNlLXN1Ym1pdCBkYXJpIG93bmVyIHRpZGFrIHBlcm5haCB0ZXJkZXRla3NpLlxuICAgIC8vIGZvcmNlQ2hlY2s9dHJ1ZSAoZGlwYWthaSBwb2xsaW5nIHN0YXR1cyBiZXJrYWxhKSBtZWxld2F0aSBndWFyZCBpbmlcbiAgICAvLyBzdXBheWEgdGV0YXAgcGluZyBzZXJ2ZXIgbXVybmkgdW50dWsgbWVuZ2VjZWsgc3RhdHVzIHNlc2kg4oCUIGJhY2tlbmRcbiAgICAvLyB0ZXRhcCBtZW5nZW1iYWxpa2FuIDQwMCBcIlNlc2kgc3VkYWggZGlzdWJtaXRcIiB3YWxhdSBwYXlsb2FkIGtvc29uZyxcbiAgICAvLyBrYXJlbmEgcGVuZ2VjZWthbiBpdHUgZGlsYWt1a2FuIFNFQkVMVU0gYmFja2VuZCBtZW5nZWNlayBpc2kgamF3YWJhbi5cbiAgICBpZiAoIWZvcmNlQ2hlY2sgJiYgKCFjdXJRcy5sZW5ndGggfHwgT2JqZWN0LmtleXMoY3VyQW5zKS5sZW5ndGggPT09IDApKSByZXR1cm47XG5cbiAgICBjb25zdCBmb3JtYXR0ZWRBbnN3ZXJzID0gT2JqZWN0LmVudHJpZXMoY3VyQW5zKS5tYXAoKFtxdWVzdGlvbklkLCB2YWx1ZV0pID0+IHtcbiAgICAgICAgY29uc3QgcSA9IGN1clFzLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBwYXJzZUludChxdWVzdGlvbklkLCAxMCkpO1xuICAgICAgICBpZiAoIXEpIHJldHVybiBudWxsO1xuICAgICAgICBpZiAocS50eXBlSWQgPT09IDIpIHtcbiAgICAgICAgICAgIGNvbnN0IHAgPSBwYXJzZUludCh2YWx1ZSwgMTApO1xuICAgICAgICAgICAgcmV0dXJuICghaXNOYU4ocCkgJiYgcCA+IDApID8geyBxdWVzdGlvbklkOiBxLmlkLCBvcHRpb25JZDogcCB9IDogbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAocS50eXBlSWQgPT09IDMpIHtcbiAgICAgICAgICAgIGNvbnN0IGlkcyA9IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKHYgPT4gcGFyc2VJbnQodiwgMTApKS5maWx0ZXIoaWQgPT4gIWlzTmFOKGlkKSAmJiBpZCA+IDApIDogW107XG4gICAgICAgICAgICByZXR1cm4gaWRzLmxlbmd0aCA/IGlkcy5tYXAoaWQgPT4gKHsgcXVlc3Rpb25JZDogcS5pZCwgb3B0aW9uSWQ6IGlkIH0pKSA6IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHEudHlwZUlkID09PSA1KSB7XG4gICAgICAgICAgICBjb25zdCBzID0gU3RyaW5nKHZhbHVlIHx8ICcnKS50cmltKCk7XG4gICAgICAgICAgICByZXR1cm4gcyA/IHsgcXVlc3Rpb25JZDogcS5pZCwgYW5zd2VyVmFsdWU6IChzLnRvTG93ZXJDYXNlKCkgPT09ICdiZW5hcicgfHwgcy50b0xvd2VyQ2FzZSgpID09PSAndHJ1ZScpID8gJ0JlbmFyJyA6ICdTYWxhaCcgfSA6IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdCA9IFN0cmluZyh2YWx1ZSB8fCAnJykudHJpbSgpO1xuICAgICAgICByZXR1cm4gdCA/IHsgcXVlc3Rpb25JZDogcS5pZCwgYW5zd2VyVmFsdWU6IHQgfSA6IG51bGw7XG4gICAgfSkuZmxhdCgpLmZpbHRlcihCb29sZWFuKTtcblxuICAgIGlmICghZm9yY2VDaGVjayAmJiBmb3JtYXR0ZWRBbnN3ZXJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gICAgY29uc3QgcGF5bG9hZEhhc2ggPSBKU09OLnN0cmluZ2lmeShmb3JtYXR0ZWRBbnN3ZXJzKTtcbiAgICBpZiAoIWZvcmNlQ2hlY2sgJiYgcGF5bG9hZEhhc2ggPT09IGxhc3RTeW5jZWRIYXNoUmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgIHN5bmNJblByb2dyZXNzUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHN5bmNFeGFtQW5zd2Vycyhmb3JtTGluaywgc2lkLCB7XG4gICAgICAgICAgICBhbnN3ZXJzOiBmb3JtYXR0ZWRBbnN3ZXJzLFxuICAgICAgICAgICAgcmVzcG9uZGVudE5hbWU6IChyZXNwb25kZW50TmFtZVJlZi5jdXJyZW50IHx8ICcnKS50cmltKCkgfHwgY3VycmVudFVzZXI/LmZ1bGxuYW1lIHx8ICdBbm9uaW0nLFxuICAgICAgICB9KTtcblxuICAgICAgICAvLyBGSVg6IGJhY2tlbmQgbWVtYmFsaWthbiA0MDQgKGJ1a2FuIDQxMC80MDkpIGRlbmdhbiBwZXNhblxuICAgICAgICAvLyBcIlNlc2kgc3VkYWggZGlzdWJtaXRcIiBzYWF0IHNlc2kgc3VkYWggZGktZm9yY2Utc3VibWl0IOKAlCB0YW1iYWhrYW5cbiAgICAgICAgLy8gcGVuZ2VjZWthbiBpdHUsIGthcmVuYSBrb25kaXNpIHNlYmVsdW1ueWEgdGlkYWsgcGVybmFoIGNvY29rLlxuICAgICAgICAvLyBDYXRhdGFuOiB0aWRhayBhZGEgbGFnaSBzaW55YWwgXCJyZXNldFwiIOKAlCByZXNldCBwZW5nYXdhcyBoYW55YVxuICAgICAgICAvLyBiZXJsYWt1IHVudHVrIGphd2FiYW4geWFuZyBzdWRhaCBkaXN1Ym1pdCBkYW4gdGlkYWsgcGVybmFoXG4gICAgICAgIC8vIG1lbmdoYXB1cyBqYXdhYmFuIHlhbmcgc2VkYW5nIGRpa2VyamFrYW4sIGphZGkgNDA0IGdlbmVyaWtcbiAgICAgICAgLy8gdGlkYWsgYm9sZWggbWUtcmVzZXQgc3RhdGUgbG9rYWwuXG4gICAgICAgIGNvbnN0IGlzVGVybWluYXRlZCA9IHJlcy5zdGF0dXMgPT09IDQxMCB8fCByZXMuc3RhdHVzID09PSA0MDkgfHxcbiAgICAgICAgICAgIChyZXMuc3RhdHVzID09PSA0MDAgJiYgL2Rpc3VibWl0L2kudGVzdChyZXMubWVzc2FnZSB8fCAnJykpIHx8XG4gICAgICAgICAgICByZXMuZGF0YT8uaXNGb3JjZVN1Ym1pdHRlZCB8fCByZXMuZGF0YT8uaXNTdWJtaXR0ZWQgfHxcbiAgICAgICAgICAgIHJlcy5kYXRhPy5zdGF0dXMgPT09ICdzdWJtaXR0ZWQnIHx8IHJlcy5kYXRhPy5zdGF0dXMgPT09ICdmb3JjZS1zdWJtaXR0ZWQnIHx8XG4gICAgICAgICAgICByZXMuZGF0YT8uc3RhdHVzID09PSAndGVybWluYXRlZCc7XG5cbiAgICAgICAgaWYgKGlzVGVybWluYXRlZCkge1xuICAgICAgICAgICAgY29uc3QgcmVzcElkID0gcmVzLmRhdGE/LnJlc3BvbnNlSWQgfHwgcmVzLmRhdGE/LmlkO1xuICAgICAgICAgICAgaGFuZGxlRm9yY2VTdWJtaXRUZXJtaW5hdGlvbihyZXNwSWQpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgbGFzdFN5bmNlZEhhc2hSZWYuY3VycmVudCA9IHBheWxvYWRIYXNoO1xuICAgICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignW1N5bmNBbnN3ZXJzXSBCYWNrZ3JvdW5kIGFuc3dlciBzeW5jIGZhaWxlZDonLCBlcnIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICAgIHN5bmNJblByb2dyZXNzUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9XG59LCBbZm9ybSwgaXNQcmV2aWV3TW9kZSwgdG9rZW5VbmxvY2tlZCwgZm9ybUxpbmssIGN1cnJlbnRVc2VyLCBnZXRTdG9yZWRTZXNzaW9uSWQsIHF1ZXN0aW9ucywgaGFuZGxlRm9yY2VTdWJtaXRUZXJtaW5hdGlvbl0pO1xuXG4gICAgLy8gRGVib3VuY2VkIHN5bmMgYW5zd2VycyBvbiBhbnN3ZXIgY2hhbmdlc1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFmb3JtIHx8IGlzUHJldmlld01vZGUgfHwgZm9ybS5pc093bmVyKSByZXR1cm47XG4gICAgaWYgKCFmb3JtLmlzRXhhbU1vZGUgJiYgIWZvcm0uZGV0ZWN0VGFiU3dpdGNoKSByZXR1cm47XG4gICAgaWYgKGZvcm0ucmVxdWlyZXNUb2tlbiAmJiAhdG9rZW5VbmxvY2tlZCkgcmV0dXJuO1xuXG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICAgIGlmICghaXNTdWJtaXR0aW5nUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIHN5bmNEcmFmdEFuc3dlcnMobnVsbCwgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICB9LCA0MDAwKTtcblxuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKGludGVydmFsKTtcbn0sIFtmb3JtLCBpc1ByZXZpZXdNb2RlLCB0b2tlblVubG9ja2VkLCBzeW5jRHJhZnRBbnN3ZXJzXSk7XG5cbiAgICAvLyBQZXJpb2RpYyBzeW5jIGFuc3dlcnMgZXZlcnkgMzAgc2Vjb25kc1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghZm9ybSB8fCBpc1ByZXZpZXdNb2RlIHx8IGZvcm0uaXNPd25lcikgcmV0dXJuO1xuICAgICAgICBpZiAoIWZvcm0uaXNFeGFtTW9kZSAmJiAhZm9ybS5kZXRlY3RUYWJTd2l0Y2gpIHJldHVybjtcbiAgICAgICAgaWYgKGZvcm0ucmVxdWlyZXNUb2tlbiAmJiAhdG9rZW5VbmxvY2tlZCkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IGludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKCFpc1N1Ym1pdHRpbmdSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgICAgIHN5bmNEcmFmdEFuc3dlcnMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgMzAwMDApO1xuXG4gICAgICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKGludGVydmFsKTtcbiAgICB9LCBbZm9ybSwgaXNQcmV2aWV3TW9kZSwgdG9rZW5VbmxvY2tlZCwgc3luY0RyYWZ0QW5zd2Vyc10pO1xuXG4gICAgY29uc3QgbG9hZFF1ZXN0aW9uc0ludGVybmFsID0gYXN5bmMgKHRva2VuKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdldFB1YmxpY0Zvcm1RdWVzdGlvbnMoZm9ybUxpbmssIHsgdG9rZW4sIG5hbWU6ICcnIH0pO1xuICAgICAgICBpZiAocmVzLm9rICYmIHJlcy5kYXRhKSB7XG4gICAgICAgICAgICBjb25zdCBxTGlzdCA9IHJlcy5kYXRhLnF1ZXN0aW9ucyB8fCByZXMuZGF0YSB8fCBbXTtcbiAgICAgICAgICAgIHNldFF1ZXN0aW9ucyhxTGlzdCk7XG4gICAgICAgICAgICBxdWVzdGlvbnNSZWYuY3VycmVudCA9IHFMaXN0O1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjYWNoZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShgZm9ybXVwX2NhY2hlXyR7Zm9ybUxpbmt9YCk7XG4gICAgICAgICAgICAgICAgaWYgKGNhY2hlZCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKGNhY2hlZCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwYXJzZWQgJiYgdHlwZW9mIHBhcnNlZCA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFuc3dlcnMocHJldiA9PiB7IGNvbnN0IG5leHQgPSB7IC4uLnBhcnNlZCwgLi4ucHJldiB9OyBhbnN3ZXJzUmVmLmN1cnJlbnQgPSBuZXh0OyByZXR1cm4gbmV4dDsgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoIHt9XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgbG9hZFF1ZXN0aW9ucyA9IGFzeW5jICh0b2tlbiA9IG51bGwpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZ2V0UHVibGljRm9ybVF1ZXN0aW9ucyhmb3JtTGluaywgeyB0b2tlbiwgbmFtZTogcmVzcG9uZGVudE5hbWUgfSk7XG4gICAgICAgIGlmIChyZXMub2sgJiYgcmVzLmRhdGEpIHtcbiAgICAgICAgICAgIGNvbnN0IHFMaXN0ID0gcmVzLmRhdGEucXVlc3Rpb25zIHx8IHJlcy5kYXRhIHx8IFtdO1xuICAgICAgICAgICAgc2V0UXVlc3Rpb25zKHFMaXN0KTtcbiAgICAgICAgICAgIHF1ZXN0aW9uc1JlZi5jdXJyZW50ID0gcUxpc3Q7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNhY2hlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGBmb3JtdXBfY2FjaGVfJHtmb3JtTGlua31gKTtcbiAgICAgICAgICAgICAgICBpZiAoY2FjaGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UoY2FjaGVkKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhcnNlZCAmJiB0eXBlb2YgcGFyc2VkID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QW5zd2VycyhwcmV2ID0+IHsgY29uc3QgbmV4dCA9IHsgLi4ucGFyc2VkLCAuLi5wcmV2IH07IGFuc3dlcnNSZWYuY3VycmVudCA9IG5leHQ7IHJldHVybiBuZXh0OyB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2gge31cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldEVycm9yKHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW11YXQgc29hbCBmb3JtdWxpci4nKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBsb2FkID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgICAgIHNldEVycm9yKCcnKTtcblxuICAgICAgICAgICAgLy8gQS0zOiBJbiBwcmV2aWV3IG1vZGUsIGxvYWQgZHJhZnQvcHVibGlzaGVkIGZvcm0gdmlhIG93bmVyIGVuZHBvaW50c1xuICAgICAgICAgICAgaWYgKGlzUHJldmlld01vZGUpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0Rm9ybUlkID0gc2VhcmNoUGFyYW1zLmdldCgnZm9ybUlkJyk7XG4gICAgICAgICAgICAgICAgaWYgKCF0YXJnZXRGb3JtSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG15Rm9ybXNSZXMgPSBhd2FpdCBnZXRNeUZvcm1zKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobXlGb3Jtc1Jlcy5vayAmJiBBcnJheS5pc0FycmF5KG15Rm9ybXNSZXMuZGF0YSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmb3VuZCA9IG15Rm9ybXNSZXMuZGF0YS5maW5kKGYgPT4gZi5mb3JtTGluayA9PT0gZm9ybUxpbmspO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmb3VuZCkgdGFyZ2V0Rm9ybUlkID0gZm91bmQuaWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2gge31cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAodGFyZ2V0Rm9ybUlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBbZm9ybVJlcywgcXVlc3Rpb25zUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZXRGb3JtQnlJZCh0YXJnZXRGb3JtSWQpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdldFF1ZXN0aW9ucyh0YXJnZXRGb3JtSWQpXG4gICAgICAgICAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZvcm1SZXMub2sgJiYgZm9ybVJlcy5kYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybShmb3JtUmVzLmRhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRva2VuVW5sb2NrZWQodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRVc2VyPy5mdWxsbmFtZSkgc2V0UmVzcG9uZGVudE5hbWUoY3VycmVudFVzZXIuZnVsbG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHFMaXN0ID0gQXJyYXkuaXNBcnJheShxdWVzdGlvbnNSZXMuZGF0YSkgPyBxdWVzdGlvbnNSZXMuZGF0YSA6IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFF1ZXN0aW9ucyhxTGlzdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25zUmVmLmN1cnJlbnQgPSBxTGlzdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2gge31cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdldFB1YmxpY0Zvcm1CeUxpbmsoZm9ybUxpbmspO1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxKSB7IGNsZWFyU2Vzc2lvbigpOyBuYXZpZ2F0ZSgnL2xvZ2luJyk7IHJldHVybjsgfVxuICAgICAgICAgICAgaWYgKHJlcy5vayAmJiByZXMuZGF0YSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGYgPSByZXMuZGF0YTtcbiAgICAgICAgICAgICAgICBzZXRGb3JtKGYpO1xuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50VXNlcj8uZnVsbG5hbWUpIHNldFJlc3BvbmRlbnROYW1lKGN1cnJlbnRVc2VyLmZ1bGxuYW1lKTtcblxuICAgICAgICAgICAgICAgIC8vIEEtNTogcHJldmlldyBieXBhc3NlcyBhbGwgZ2F0ZXNcbiAgICAgICAgICAgICAgICBpZiAoaXNQcmV2aWV3TW9kZSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRUb2tlblVubG9ja2VkKHRydWUpO1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCBsb2FkUXVlc3Rpb25zSW50ZXJuYWwobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBjb25zdCBsb2NhbFN1YiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGBmb3JtdXBfc3VibWl0dGVkXyR7Zm9ybUxpbmt9YCk7XG4gICAgICAgICAgICAgICAgaWYgKGYub25lUmVzcG9uc2UgJiYgKGYuYWxyZWFkeVN1Ym1pdHRlZCB8fCBsb2NhbFN1YikpIHJldHVybjtcblxuICAgICAgICAgICAgICAgIGxldCBzYXZlZFRva2VuID0gJyc7XG4gICAgICAgICAgICAgICAgdHJ5IHsgc2F2ZWRUb2tlbiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGBmb3JtdXBfdG9rZW5fJHtmb3JtTGlua31gKSB8fCAnJzsgfSBjYXRjaCB7fVxuICAgICAgICAgICAgICAgIGlmIChzYXZlZFRva2VuKSBzZXRUb2tlbklucHV0KHNhdmVkVG9rZW4pO1xuXG4gICAgICAgICAgICAgICAgaWYgKCFmLnJlcXVpcmVzVG9rZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0VG9rZW5VbmxvY2tlZCh0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgbG9hZFF1ZXN0aW9ucygpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoc2F2ZWRUb2tlbikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB1bmxvY2tSZXMgPSBhd2FpdCBnZXRQdWJsaWNGb3JtUXVlc3Rpb25zKGZvcm1MaW5rLCB7IHRva2VuOiBzYXZlZFRva2VuLCBuYW1lOiBjdXJyZW50VXNlcj8uZnVsbG5hbWUgfHwgJycgfSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh1bmxvY2tSZXMub2sgJiYgdW5sb2NrUmVzLmRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRva2VuVW5sb2NrZWQodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBxTGlzdCA9IHVubG9ja1Jlcy5kYXRhLnF1ZXN0aW9ucyB8fCB1bmxvY2tSZXMuZGF0YSB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFF1ZXN0aW9ucyhxTGlzdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbnNSZWYuY3VycmVudCA9IHFMaXN0O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKGYudGltZXJEdXJhdGlvbiAmJiBmLnRpbWVyRHVyYXRpb24gPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpbWVyRGVhZGxpbmVLZXkgPSBgZm9ybXVwX3RpbWVyX2RlYWRsaW5lXyR7Zm9ybUxpbmt9YDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRlYWRsaW5lTXMgPSBwYXJzZUludChsb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aW1lckRlYWRsaW5lS2V5KSwgMTApO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWRlYWRsaW5lTXMgfHwgaXNOYU4oZGVhZGxpbmVNcykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlYWRsaW5lTXMgPSBub3cgKyAoZi50aW1lckR1cmF0aW9uICogMTAwMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aW1lckRlYWRsaW5lS2V5LCBTdHJpbmcoZGVhZGxpbmVNcykpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHNldFRpbWVMZWZ0KE1hdGgubWF4KDAsIE1hdGguY2VpbCgoZGVhZGxpbmVNcyAtIG5vdykgLyAxMDAwKSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc2V0RXJyb3IocmVzLm1lc3NhZ2UgfHwgJ0Zvcm11bGlyIHRpZGFrIGRpdGVtdWthbiBhdGF1IGJlbHVtIGRpcHVibGlrYXNpa2FuLicpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBsb2FkKCk7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICAgIH0sIFtmb3JtTGluaywgbmF2aWdhdGVdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghdG9rZW5VbmxvY2tlZCB8fCAhZm9ybT8udGltZXJEdXJhdGlvbiB8fCBmb3JtLnRpbWVyRHVyYXRpb24gPD0gMCkgcmV0dXJuO1xuICAgICAgICBjb25zdCB0aW1lckRlYWRsaW5lS2V5ID0gYGZvcm11cF90aW1lcl9kZWFkbGluZV8ke2Zvcm1MaW5rfWA7XG4gICAgICAgIGxldCBzdG9yZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aW1lckRlYWRsaW5lS2V5KTtcbiAgICAgICAgbGV0IGRlYWRsaW5lTXMgPSBzdG9yZWQgPyBwYXJzZUludChzdG9yZWQsIDEwKSA6IG51bGw7XG4gICAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgICAgIGlmICghZGVhZGxpbmVNcyB8fCBpc05hTihkZWFkbGluZU1zKSkge1xuICAgICAgICAgICAgZGVhZGxpbmVNcyA9IG5vdyArIChmb3JtLnRpbWVyRHVyYXRpb24gKiAxMDAwKTtcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHRpbWVyRGVhZGxpbmVLZXksIFN0cmluZyhkZWFkbGluZU1zKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2hlY2tUaW1lciA9ICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlbWFpbmluZyA9IE1hdGgubWF4KDAsIE1hdGguY2VpbCgoZGVhZGxpbmVNcyAtIERhdGUubm93KCkpIC8gMTAwMCkpO1xuICAgICAgICAgICAgc2V0VGltZUxlZnQocmVtYWluaW5nKTtcbiAgICAgICAgICAgIGlmIChyZW1haW5pbmcgPD0gMCkgeyBpZiAodGltZXJSZWYuY3VycmVudCkgY2xlYXJJbnRlcnZhbCh0aW1lclJlZi5jdXJyZW50KTsgaWYgKCFpc1N1Ym1pdHRpbmdSZWYuY3VycmVudCkgaGFuZGxlU3VibWl0KG51bGwsIHRydWUpOyB9XG4gICAgICAgIH07XG4gICAgICAgIGNoZWNrVGltZXIoKTtcbiAgICAgICAgdGltZXJSZWYuY3VycmVudCA9IHNldEludGVydmFsKGNoZWNrVGltZXIsIDEwMDApO1xuICAgICAgICByZXR1cm4gKCkgPT4geyBpZiAodGltZXJSZWYuY3VycmVudCkgY2xlYXJJbnRlcnZhbCh0aW1lclJlZi5jdXJyZW50KTsgfTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gICAgfSwgW3Rva2VuVW5sb2NrZWQsIGZvcm0/LnRpbWVyRHVyYXRpb24sIGZvcm1MaW5rXSk7XG5cbiAgICAvLyBCMTM6IFN1cHBvcnQgSEg6TU06U1MgZm9yIGV4YW1zID4gMSBob3VyXG4gICAgY29uc3QgZm9ybWF0VGltZXIgPSAoc2Vjb25kcykgPT4ge1xuICAgICAgICBpZiAoc2Vjb25kcyA+PSAzNjAwKSB7XG4gICAgICAgICAgICBjb25zdCBoID0gTWF0aC5mbG9vcihzZWNvbmRzIC8gMzYwMCk7XG4gICAgICAgICAgICBjb25zdCBtID0gTWF0aC5mbG9vcigoc2Vjb25kcyAlIDM2MDApIC8gNjApO1xuICAgICAgICAgICAgY29uc3QgcyA9IHNlY29uZHMgJSA2MDtcbiAgICAgICAgICAgIHJldHVybiBgJHtTdHJpbmcoaCkucGFkU3RhcnQoMiwnMCcpfToke1N0cmluZyhtKS5wYWRTdGFydCgyLCcwJyl9OiR7U3RyaW5nKHMpLnBhZFN0YXJ0KDIsJzAnKX1gO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG0gPSBNYXRoLmZsb29yKHNlY29uZHMgLyA2MCksIHMgPSBzZWNvbmRzICUgNjA7XG4gICAgICAgIHJldHVybiBgJHtTdHJpbmcobSkucGFkU3RhcnQoMiwnMCcpfToke1N0cmluZyhzKS5wYWRTdGFydCgyLCcwJyl9YDtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQW5zd2VyQ2hhbmdlID0gKHF1ZXN0aW9uSWQsIHZhbHVlKSA9PiB7XG4gICAgICAgIHNldEFuc3dlcnMocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0geyAuLi5wcmV2LCBbcXVlc3Rpb25JZF06IHZhbHVlIH07XG4gICAgICAgICAgICBhbnN3ZXJzUmVmLmN1cnJlbnQgPSBuZXh0O1xuICAgICAgICAgICAgdHJ5IHsgbG9jYWxTdG9yYWdlLnNldEl0ZW0oYGZvcm11cF9jYWNoZV8ke2Zvcm1MaW5rfWAsIEpTT04uc3RyaW5naWZ5KG5leHQpKTsgfSBjYXRjaCB7fVxuICAgICAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVDaGVja2JveENoYW5nZSA9IChxdWVzdGlvbklkLCBvcHRpb25JZCwgY2hlY2tlZCkgPT4ge1xuICAgICAgICBzZXRBbnN3ZXJzKHByZXYgPT4ge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudCA9IEFycmF5LmlzQXJyYXkocHJldltxdWVzdGlvbklkXSkgPyBwcmV2W3F1ZXN0aW9uSWRdIDogW107XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gY2hlY2tlZCA/IFsuLi5jdXJyZW50LCBvcHRpb25JZF0gOiBjdXJyZW50LmZpbHRlcihpZCA9PiBpZCAhPT0gb3B0aW9uSWQpO1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IHsgLi4ucHJldiwgW3F1ZXN0aW9uSWRdOiB1cGRhdGVkIH07XG4gICAgICAgICAgICBhbnN3ZXJzUmVmLmN1cnJlbnQgPSBuZXh0O1xuICAgICAgICAgICAgdHJ5IHsgbG9jYWxTdG9yYWdlLnNldEl0ZW0oYGZvcm11cF9jYWNoZV8ke2Zvcm1MaW5rfWAsIEpTT04uc3RyaW5naWZ5KG5leHQpKTsgfSBjYXRjaCB7fVxuICAgICAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVVbmxvY2tUb2tlbiA9IGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgc2V0RXJyb3IoJycpO1xuICAgICAgICBjb25zdCB0b2tlbiA9IHRva2VuSW5wdXQudHJpbSgpO1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBnZXRQdWJsaWNGb3JtUXVlc3Rpb25zKGZvcm1MaW5rLCB7IHRva2VuLCBuYW1lOiByZXNwb25kZW50TmFtZSB9KTtcbiAgICAgICAgaWYgKHJlcy5vayAmJiByZXMuZGF0YSkge1xuICAgICAgICAgICAgdHJ5IHsgbG9jYWxTdG9yYWdlLnNldEl0ZW0oYGZvcm11cF90b2tlbl8ke2Zvcm1MaW5rfWAsIHRva2VuKTsgfSBjYXRjaCB7fVxuICAgICAgICAgICAgc2V0VG9rZW5VbmxvY2tlZCh0cnVlKTtcbiAgICAgICAgICAgIGNvbnN0IHFMaXN0ID0gcmVzLmRhdGEucXVlc3Rpb25zIHx8IHJlcy5kYXRhIHx8IFtdO1xuICAgICAgICAgICAgc2V0UXVlc3Rpb25zKHFMaXN0KTtcbiAgICAgICAgICAgIHF1ZXN0aW9uc1JlZi5jdXJyZW50ID0gcUxpc3Q7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNhY2hlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGBmb3JtdXBfY2FjaGVfJHtmb3JtTGlua31gKTtcbiAgICAgICAgICAgICAgICBpZiAoY2FjaGVkKSB7IGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UoY2FjaGVkKTsgaWYgKHBhcnNlZCkgeyBzZXRBbnN3ZXJzKHBhcnNlZCk7IGFuc3dlcnNSZWYuY3VycmVudCA9IHBhcnNlZDsgfSB9XG4gICAgICAgICAgICB9IGNhdGNoIHt9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRFcnJvcihyZXMubWVzc2FnZSB8fCAnVG9rZW4gc2FuZGkgYWtzZXMgc2FsYWguJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3Qgc2hvd1ZhbGlkYXRpb25BbGVydCA9IChtc2cpID0+IHsgc2V0VmFsaWRhdGlvblRvYXN0KG1zZyk7IHNldFRpbWVvdXQoKCkgPT4gc2V0VmFsaWRhdGlvblRvYXN0KG51bGwpLCA0NTAwKTsgfTtcblxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlLCBpc0F1dG8gPSBmYWxzZSwgc2tpcFdhcm5pbmdzID0gZmFsc2UpID0+IHtcbiAgICAgICAgaWYgKGUgJiYgdHlwZW9mIGUucHJldmVudERlZmF1bHQgPT09ICdmdW5jdGlvbicpIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaWYgKGlzUHJldmlld01vZGUpIHsgd2luZG93LmNsb3NlKCk7IHJldHVybjsgfVxuICAgICAgICAvLyBCMTA6IEZpcnN0IGNoZWNrIGZvciByYWd1LXJhZ3UgcXVlc3Rpb25zIChvbmx5IGZvciBtYW51YWwgc3VibWl0KVxuICAgICAgICBpZiAoIWlzQXV0byAmJiAhc2tpcFdhcm5pbmdzICYmIG1hcmtlZEZvclJldmlldy5zaXplID4gMCAmJiAhcmV2aWV3V2FybmluZ09wZW4gJiYgIXN1Ym1pdENvbmZpcm1PcGVuKSB7XG4gICAgICAgICAgICBzZXRSZXZpZXdXYXJuaW5nT3Blbih0cnVlKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzZXRTdWJtaXRDb25maXJtT3BlbihmYWxzZSk7XG4gICAgICAgIGlmIChpc1N1Ym1pdHRpbmdSZWYuY3VycmVudCkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IGN1cnJlbnRRdWVzdGlvbnMgPSBxdWVzdGlvbnNSZWYuY3VycmVudD8ubGVuZ3RoID8gcXVlc3Rpb25zUmVmLmN1cnJlbnQgOiBxdWVzdGlvbnM7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRBbnN3ZXJzID0gYW5zd2Vyc1JlZi5jdXJyZW50IHx8IGFuc3dlcnM7XG5cbiAgICAgICAgaWYgKCFpc0F1dG8pIHtcbiAgICAgICAgICAgIGNvbnN0IHVuYW5zd2VyZWQgPSBjdXJyZW50UXVlc3Rpb25zLmZpbHRlcihxID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIXEuaXNSZXF1aXJlZCkgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IGN1cnJlbnRBbnN3ZXJzW3EuaWRdO1xuICAgICAgICAgICAgICAgIHJldHVybiBxLnR5cGVJZCA9PT0gMyA/ICEoQXJyYXkuaXNBcnJheSh2YWwpICYmIHZhbC5sZW5ndGggPiAwKSA6ICEodmFsICE9PSB1bmRlZmluZWQgJiYgdmFsICE9PSBudWxsICYmIFN0cmluZyh2YWwpLnRyaW0oKS5sZW5ndGggPiAwKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKHVuYW5zd2VyZWQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IG1zZyA9IGBBZGEgJHt1bmFuc3dlcmVkLmxlbmd0aH0gcGVydGFueWFhbiB3YWppYiB5YW5nIGJlbHVtIGRpamF3YWIuYDtcbiAgICAgICAgICAgICAgICBzaG93VmFsaWRhdGlvbkFsZXJ0KG1zZyk7IHNldEVycm9yKG1zZyk7XG4gICAgICAgICAgICAgICAgY29uc3QgZmlyc3QgPSB1bmFuc3dlcmVkWzBdO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzU3RlcCA9IGZvcm0/LmZvcm1UeXBlSWQgPT09IDI7XG4gICAgICAgICAgICAgICAgaWYgKGlzU3RlcCkgeyBjb25zdCBpZHggPSBjdXJyZW50UXVlc3Rpb25zLmZpbmRJbmRleChxID0+IHEuaWQgPT09IGZpcnN0LmlkKTsgaWYgKGlkeCAhPT0gLTEpIHNldEN1cnJlbnRTdGVwKGlkeCk7IH1cbiAgICAgICAgICAgICAgICBlbHNlIHsgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChgcXVlc3Rpb24tY2FyZC0ke2ZpcnN0LmlkfWApOyBpZiAoZWwpIHsgZWwuc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjonc21vb3RoJywgYmxvY2s6J2NlbnRlcicgfSk7IGVsLmNsYXNzTGlzdC5hZGQoJ3JpbmctMicsJ3JpbmctcmVkLTQwMCcpOyBzZXRUaW1lb3V0KCgpID0+IGVsLmNsYXNzTGlzdC5yZW1vdmUoJ3JpbmctMicsJ3JpbmctcmVkLTQwMCcpLCAzNTAwKTsgfSB9XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaXNTdWJtaXR0aW5nUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICBzZXRTdWJtaXR0aW5nKHRydWUpO1xuICAgICAgICBpZiAodGltZXJSZWYuY3VycmVudCkgY2xlYXJJbnRlcnZhbCh0aW1lclJlZi5jdXJyZW50KTtcbiAgICAgICAgc2V0RXJyb3IoJycpOyBzZXRWYWxpZGF0aW9uVG9hc3QobnVsbCk7XG5cbiAgICAgICAgY29uc3QgZm9ybWF0dGVkQW5zd2VycyA9IE9iamVjdC5lbnRyaWVzKGN1cnJlbnRBbnN3ZXJzKS5tYXAoKFtxdWVzdGlvbklkLCB2YWx1ZV0pID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHEgPSBjdXJyZW50UXVlc3Rpb25zLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBwYXJzZUludChxdWVzdGlvbklkLCAxMCkpO1xuICAgICAgICAgICAgaWYgKCFxKSByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIGlmIChxLnR5cGVJZCA9PT0gMikgeyBjb25zdCBwID0gcGFyc2VJbnQodmFsdWUsIDEwKTsgcmV0dXJuICghaXNOYU4ocCkgJiYgcCA+IDApID8geyBxdWVzdGlvbklkOiBxLmlkLCBvcHRpb25JZDogcCB9IDogbnVsbDsgfVxuICAgICAgICAgICAgaWYgKHEudHlwZUlkID09PSAzKSB7IGNvbnN0IGlkcyA9IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKHYgPT4gcGFyc2VJbnQodiwxMCkpLmZpbHRlcihpZCA9PiAhaXNOYU4oaWQpICYmIGlkID4gMCkgOiBbXTsgcmV0dXJuIGlkcy5sZW5ndGggPyBpZHMubWFwKGlkID0+ICh7IHF1ZXN0aW9uSWQ6IHEuaWQsIG9wdGlvbklkOiBpZCB9KSkgOiBudWxsOyB9XG4gICAgICAgICAgICBpZiAocS50eXBlSWQgPT09IDUpIHsgY29uc3QgcyA9IFN0cmluZyh2YWx1ZXx8JycpLnRyaW0oKTsgcmV0dXJuIHMgPyB7IHF1ZXN0aW9uSWQ6IHEuaWQsIGFuc3dlclZhbHVlOiAocy50b0xvd2VyQ2FzZSgpPT09J2JlbmFyJ3x8cy50b0xvd2VyQ2FzZSgpPT09J3RydWUnKSA/ICdCZW5hcicgOiAnU2FsYWgnIH0gOiBudWxsOyB9XG4gICAgICAgICAgICBjb25zdCB0ID0gU3RyaW5nKHZhbHVlfHwnJykudHJpbSgpOyByZXR1cm4gdCA/IHsgcXVlc3Rpb25JZDogcS5pZCwgYW5zd2VyVmFsdWU6IHQgfSA6IG51bGw7XG4gICAgICAgIH0pLmZsYXQoKS5maWx0ZXIoQm9vbGVhbik7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHN1Ym1pdFB1YmxpY0Zvcm1SZXNwb25zZShmb3JtTGluaywge1xuICAgICAgICAgICAgICAgIHRva2VuOiB0b2tlbklucHV0ID8gdG9rZW5JbnB1dC50cmltKCkgOiBudWxsLFxuICAgICAgICAgICAgICAgIHJlc3BvbmRlbnROYW1lOiByZXNwb25kZW50TmFtZS50cmltKCkgfHwgJ0Fub25pbScsXG4gICAgICAgICAgICAgICAgaXNBdXRvU3VibWl0OiBCb29sZWFuKGlzQXV0byksIElzQXV0b1N1Ym1pdDogQm9vbGVhbihpc0F1dG8pLFxuICAgICAgICAgICAgICAgIGFuc3dlcnM6IGZvcm1hdHRlZEFuc3dlcnMsXG4gICAgICAgICAgICAgICAgZXhhbVNlc3Npb25JZDogZXhhbVNlc3Npb25JZFJlZi5jdXJyZW50IHx8IG51bGwsXG4gICAgICAgICAgICAgICAgdGFiU3dpdGNoQ291bnQ6IHR5cGVvZiB0YWJTd2l0Y2hDb3VudCA9PT0gJ251bWJlcicgPyB0YWJTd2l0Y2hDb3VudCA6IG51bGwsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnN0IGQgPSByZXMuZGF0YTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlSWQgPSBkPy5yZXNwb25zZUlkIHx8IGQ/LmlkIHx8ICh0eXBlb2YgZCA9PT0gJ251bWJlcicgfHwgdHlwZW9mIGQgPT09ICdzdHJpbmcnID8gZCA6IG51bGwpO1xuICAgICAgICAgICAgaWYgKHJlcy5vayAmJiByZXNwb25zZUlkKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oYGZvcm11cF9jYWNoZV8ke2Zvcm1MaW5rfWApO1xuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShgZm9ybXVwX3RpbWVyX2RlYWRsaW5lXyR7Zm9ybUxpbmt9YCk7XG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGBmb3JtdXBfdG9rZW5fJHtmb3JtTGlua31gKTtcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oYGZvcm11cF9zdWJtaXR0ZWRfJHtmb3JtTGlua31gLCBTdHJpbmcocmVzcG9uc2VJZCkpO1xuICAgICAgICAgICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKGBmb3JtdXBfZXhhbV9zZXNzaW9uXyR7Zm9ybUxpbmt9YCk7XG4gICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oYGZvcm11cF92aW9sYXRpb25zXyR7Zm9ybUxpbmt9YCk7XG4gICAgICAgICAgICAgICAgfSBjYXRjaCB7fVxuICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvZi8ke2Zvcm1MaW5rfS9yZXN1bHQvJHtyZXNwb25zZUlkfWAsIHsgc3RhdGU6IHsgZ3Vlc3RUb2tlbjogZD8uZ3Vlc3RUb2tlbiB8fCBudWxsIH0gfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlzU3VibWl0dGluZ1JlZi5jdXJyZW50ID0gZmFsc2U7IHNldFN1Ym1pdHRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVyclRleHQgPSByZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVuZ2lyaW1rYW4gcmVzcG9ucyBmb3JtdWxpci4nO1xuICAgICAgICAgICAgICAgIHNldEVycm9yKGVyclRleHQpOyBzaG93VmFsaWRhdGlvbkFsZXJ0KGVyclRleHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIGlzU3VibWl0dGluZ1JlZi5jdXJyZW50ID0gZmFsc2U7IHNldFN1Ym1pdHRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgY29uc3QgZXJyVGV4dCA9ICdUZXJqYWRpIGtlc2FsYWhhbiBrb25la3NpIHNhYXQgbWVuZ2lyaW0gZm9ybXVsaXIuJztcbiAgICAgICAgICAgIHNldEVycm9yKGVyclRleHQpOyBzaG93VmFsaWRhdGlvbkFsZXJ0KGVyclRleHQpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNlbmRSZXBvcnQgPSBhc3luYyAoZSkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7IHNldFJlcG9ydEVycm9yKCcnKTsgc2V0U3VibWl0dGluZ1JlcG9ydCh0cnVlKTtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgc3VibWl0RmVlZGJhY2soZm9ybT8uaWQsIHsgcmVhc29uOiByZXBvcnRSZWFzb24sIGRlc2NyaXB0aW9uOiByZXBvcnREZXNjcmlwdGlvbi50cmltKCkgfSk7XG4gICAgICAgIHNldFN1Ym1pdHRpbmdSZXBvcnQoZmFsc2UpO1xuICAgICAgICBpZiAocmVzLm9rKSB7IHNldFJlcG9ydFN1Y2Nlc3ModHJ1ZSk7IHNldFJlcG9ydERlc2NyaXB0aW9uKCcnKTsgc2V0VGltZW91dCgoKSA9PiB7IHNldFJlcG9ydE1vZGFsT3BlbihmYWxzZSk7IHNldFJlcG9ydFN1Y2Nlc3MoZmFsc2UpOyB9LCAyNTAwKTsgfVxuICAgICAgICBlbHNlIHNldFJlcG9ydEVycm9yKHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW5naXJpbWthbiBsYXBvcmFuIG1hc2FsYWguJyk7XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLXNjcmVlbiBiZy1bI0Y0RjhGN10gZGFyazpiZy1zbGF0ZS05NTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwidy04IGgtOCBhbmltYXRlLXNwaW4gbXgtYXV0byB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPk1lbXVhdCBmb3JtdWxpci4uLjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xuXG4gICAgaWYgKGlzRm9yY2VTdWJtaXR0ZWQpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLVsjRjRGOEY3XSBkYXJrOmJnLXNsYXRlLTk1MCBwLTQgZm9udC1zYW5zIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTggbWF4LXctbWQgdy1mdWxsIHRleHQtY2VudGVyIHNwYWNlLXktNSBzaGFkb3cteGxcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNjAgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPExvY2sgc2l6ZT17MzJ9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VzaSBVamlhbiBTZWxlc2FpXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlc2kgdWppYW4gQW5kYSB0ZWxhaCBkaXNlbGVzYWlrYW4gZGFuIGRpa3VuY2kgb2xlaCBwZW5nYXdhcy4gU2VtdWEgamF3YWJhbiBkcmFmIEFuZGEgdGVsYWggdGVyc2ltcGFuIGRlbmdhbiBhbWFuIGRpIHNpc3RlbS5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQteHMgc2hhZG93LXNtIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBLZW1iYWxpIGtlIEJlcmFuZGFcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8vIEEtNTogc2tpcCBsb2NrZWQgc2NyZWVuIGluIHByZXZpZXdcbiAgICBjb25zdCBsb2NhbFN1Ym1pdHRlZElkID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShgZm9ybXVwX3N1Ym1pdHRlZF8ke2Zvcm1MaW5rfWApIDogbnVsbDtcbiAgICBpZiAoIWlzUHJldmlld01vZGUgJiYgZm9ybSAmJiBmb3JtLm9uZVJlc3BvbnNlICYmIChmb3JtLmFscmVhZHlTdWJtaXR0ZWQgfHwgbG9jYWxTdWJtaXR0ZWRJZCkpIHtcbiAgICAgICAgY29uc3QgcHJldmlvdXNJZCA9IGZvcm0ucHJldmlvdXNSZXNwb25zZUlkIHx8IGxvY2FsU3VibWl0dGVkSWQ7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1bI0Y0RjhGN10gZGFyazpiZy1zbGF0ZS05NTAgcC00IGZvbnQtc2FucyB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC04IG1heC13LW1kIHctZnVsbCB0ZXh0LWNlbnRlciBzcGFjZS15LTUgc2hhZG93LXhsXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzYwIHRleHQtYW1iZXItNTAwIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gc2hhZG93LXhzXCI+PExvY2sgc2l6ZT17MzB9IC8+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5Gb3JtdWxpciBUZXJrdW5jaTwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkXCI+QW5kYSBzdWRhaCBwZXJuYWggbWVuZ2VyamFrYW4gZm9ybXVsaXIgPGI+e2Zvcm0udGl0bGV9PC9iPi4gUGVtYnVhdCBmb3JtdWxpciBtZW1iYXRhc2kgcGVuZ2lzaWFuIGhhbnlhIDxiPjEga2FsaSBwZW5nZXJqYWFuPC9iPiBwZXIgcmVzcG9uZGVuLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBmbGV4IGZsZXgtY29sIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwcmV2aW91c0lkICYmIGZvcm0uc2hvd1Njb3JlICYmIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvZi8ke2Zvcm1MaW5rfS9yZXN1bHQvJHtwcmV2aW91c0lkfWApfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMyBiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQteGwgdGV4dC14cyBzaGFkb3ctc20gdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIj5MaWhhdCBIYXNpbCBQZW5nZXJqYWFuIFNlYmVsdW1ueWE8L2J1dHRvbj59XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShjdXJyZW50VXNlcj8uaWQgPyAnL2Rhc2hib2FyZCcgOiAnL2xvZ2luJyl9IGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIj5LZW1iYWxpIGtlIHtjdXJyZW50VXNlcj8uaWQgPyAnRGFzaGJvYXJkJyA6ICdIYWxhbWFuIFV0YW1hJ308L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAoZXJyb3IgJiYgIWZvcm0pIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLVsjRjRGOEY3XSBkYXJrOmJnLXNsYXRlLTk1MCBwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHAtOCBtYXgtdy1tZCB3LWZ1bGwgdGV4dC1jZW50ZXIgc3BhY2UteS00IHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IGJnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNTAgdGV4dC1yZWQtNTAwIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG9cIj48QWxlcnRDaXJjbGUgc2l6ZT17Mjh9IC8+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPkZvcm11bGlyIFRpZGFrIFRlcnNlZGlhPC9oMj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj57ZXJyb3J9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG5cbiAgICAvLyBBLTU6IHNraXAgdG9rZW4gc2NyZWVuIGluIHByZXZpZXdcbiAgICBpZiAoIWlzUHJldmlld01vZGUgJiYgIXRva2VuVW5sb2NrZWQpIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLVsjRjRGOEY3XSBkYXJrOmJnLXNsYXRlLTk1MCBwLTQgZm9udC1zYW5zIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHAtOCBtYXgtdy1tZCB3LWZ1bGwgc3BhY2UteS02IHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBzaGFkb3cteHNcIj48TG9jayBzaXplPXsyNn0gLz48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+Rm9ybXVsaXIgTWVtYnV0dWhrYW4gU2FuZGkgQWtzZXM8L2gyPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW1cIj5NYXN1a2thbiB0b2tlbiBzYW5kaSB5YW5nIGRpYmVyaWthbiBvbGVoIHBlbWJ1YXQgZm9ybXVsaXIgdW50dWsgbXVsYWkgbWVuZ2lzaS48L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC81MCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTgwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtcmVkLTYwMCBkYXJrOnRleHQtcmVkLTQwMFwiPntlcnJvcn08L2Rpdj59XG4gICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVVubG9ja1Rva2VufSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIHJlcXVpcmVkIHZhbHVlPXt0b2tlbklucHV0fSBvbkNoYW5nZT17ZSA9PiBzZXRUb2tlbklucHV0KGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJNYXN1a2thbiB0b2tlbiBzYW5kaS4uLlwiIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC00IHB5LTMgdGV4dC1zbSBmb250LW1vbm8gZm9udC1ib2xkIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQteHMgc2hhZG93LXNtIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCI+QnVrYSBGb3JtdWxpcjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xuXG4gICAgY29uc3QgaXNTdGVwTGF5b3V0ID0gZm9ybT8uZm9ybVR5cGVJZCA9PT0gMiB8fCBmb3JtPy5zZXR0aW5ncz8uZm9ybVR5cGVJZCA9PT0gMjtcbiAgICBjb25zdCBjdXJyZW50USA9IHF1ZXN0aW9uc1tjdXJyZW50U3RlcF07XG4gICAgY29uc3QgdG90YWxTdGVwcyA9IHF1ZXN0aW9ucy5sZW5ndGg7XG5cbiAgICAvLyBGRUFULTQ6IHByb2dyZXNzXG4gICAgY29uc3QgYW5zd2VyZWRDb3VudCA9IHF1ZXN0aW9ucy5maWx0ZXIocSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbCA9IGFuc3dlcnNbcS5pZF07XG4gICAgICAgIHJldHVybiBxLnR5cGVJZCA9PT0gMyA/IEFycmF5LmlzQXJyYXkodmFsKSAmJiB2YWwubGVuZ3RoID4gMCA6IHZhbCAhPT0gdW5kZWZpbmVkICYmIHZhbCAhPT0gbnVsbCAmJiBTdHJpbmcodmFsKS50cmltKCkubGVuZ3RoID4gMDtcbiAgICB9KS5sZW5ndGg7XG4gICAgY29uc3QgcHJvZ3Jlc3NQZXJjZW50ID0gdG90YWxTdGVwcyA+IDAgPyBNYXRoLnJvdW5kKChhbnN3ZXJlZENvdW50IC8gdG90YWxTdGVwcykgKiAxMDApIDogMDtcblxuICAgIC8vIEItMjogdGhlbWVcbiAgICBjb25zdCBwcmltYXJ5Q29sb3IgPSBmb3JtPy50aGVtZVByaW1hcnlDb2xvciB8fCAnIzAwODk3Qic7XG4gICAgY29uc3QgYmdDb2xvciA9IGZvcm0/LnRoZW1lQmFja2dyb3VuZENvbG9yO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BtaW4taC1zY3JlZW4gZm9udC1zYW5zIGFudGlhbGlhc2VkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgJHtxdWVzdGlvbnMubGVuZ3RoID4gMCA/ICdwdC0xNicgOiAncHktOCd9IHBiLTggcHgtNCBzbTpweC02IHRyYW5zaXRpb24tY29sb3JzYH0gc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBiZ0NvbG9yIHx8IHVuZGVmaW5lZCB9fT5cblxuICAgICAgICAgICAgey8qIEEtNDogU3RpY2t5IGZ1bGwtd2lkdGggcHJvZ3Jlc3MgYmFyIGF0IHRvcCBvZiB2aWV3cG9ydCAqL31cbiAgICAgICAgICAgIHtxdWVzdGlvbnMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtMCBsZWZ0LTAgcmlnaHQtMCB6LTQwIGJnLXdoaXRlLzk1IGRhcms6Ymctc2xhdGUtOTAwLzk1IGJhY2tkcm9wLWJsdXItbWQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcHgtNCBzbTpweC04IHB5LTIuNSBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGxcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake2lzU3RlcExheW91dCA/ICdtYXgtdy00eGwgbGc6bWF4LXctNXhsJyA6ICdtYXgtdy0zeGwnfSBteC1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTEuNWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGUgbXItM1wiPntmb3JtPy50aXRsZSA/IGAke2Zvcm0udGl0bGV9IOKAlCBgIDogJyd9e2Fuc3dlcmVkQ291bnR9IGRhcmkge3RvdGFsU3RlcHN9IHNvYWwgdGVyamF3YWI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaHJpbmstMCBmb250LW1vbm9cIiBzdHlsZT17eyBjb2xvcjogcHJpbWFyeUNvbG9yIH19Pntwcm9ncmVzc1BlcmNlbnR9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtpc1N0ZXBMYXlvdXQgPyAnbWF4LXctNHhsIGxnOm1heC13LTV4bCcgOiAnbWF4LXctM3hsJ30gbXgtYXV0byB3LWZ1bGwgaC0xLjUgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIiBzdHlsZT17eyB3aWR0aDogYCR7cHJvZ3Jlc3NQZXJjZW50fSVgLCBiYWNrZ3JvdW5kQ29sb3I6IHByaW1hcnlDb2xvciB9fSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBPZmZsaW5lLUZpcnN0OiBEaXNjb25uZWN0aW9uICYgQXV0by1zYXZlIHdhcm5pbmcgYmFkZ2UgKi99XG4gICAgICAgICAgICB7IWlzT25saW5lICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIHRvcC0xNCBzbTp0b3AtMTYgcmlnaHQtNCBzbTpyaWdodC02IHotNTAgYmctYW1iZXItNTAwIHRleHQtd2hpdGUgcHgtNCBweS0yLjUgcm91bmRlZC0yeGwgc2hhZG93LXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgbWF4LXctc20gYm9yZGVyIGJvcmRlci1hbWJlci00MDAgZm9udC1ib2xkIHRleHQteHMgYW5pbWF0ZS1wdWxzZVwiPlxuICAgICAgICAgICAgICAgICAgICA8V2lmaU9mZiBzaXplPXsxNn0gY2xhc3NOYW1lPVwic2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+S29uZWtzaSBUZXJwdXR1cyAvIEJ1cnVrPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ub3JtYWwgb3BhY2l0eS05MFwiPnthbnN3ZXJlZENvdW50fSBqYXdhYmFuIHRlcnNpbXBhbiBhbWFuIGRpIHBlcmFuZ2thdC48L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIE9mZmxpbmUtRmlyc3Q6IFJlY29ubmVjdGVkIFRvYXN0ICovfVxuICAgICAgICAgICAge2lzT25saW5lICYmIHNob3dSZXN0b3JlZFRvYXN0ICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIHRvcC0xNCBzbTp0b3AtMTYgcmlnaHQtNCBzbTpyaWdodC02IHotNTAgYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIuNSByb3VuZGVkLTJ4bCBzaGFkb3cteGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBtYXgtdy1zbSBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwIGZvbnQtYm9sZCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgIDxXaWZpIHNpemU9ezE2fSBjbGFzc05hbWU9XCJzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5Lb25la3NpIFB1bGloPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ub3JtYWwgb3BhY2l0eS05MFwiPlNlbXVhIGphd2FiYW4gYmVyaGFzaWwgZGlzaW5rcm9uaXNhc2khPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBFeGFtIG1vZGUgdmlvbGF0aW9uIHdhcm5pbmcgKi99XG4gICAgICAgICAgICB7dGFiU3dpdGNoV2FybmluZyAmJiAoZm9ybT8uZGV0ZWN0VGFiU3dpdGNoIHx8IGZvcm0/LmlzRXhhbU1vZGUpICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIHRvcC01IGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgei01MCBiZy1yZWQtNjAwIHRleHQtd2hpdGUgcHgtNSBweS0zIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWF4LXctbWQgdy1bOTJ2d11cIj5cbiAgICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezE4fSBjbGFzc05hbWU9XCJzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtZXh0cmFib2xkXCI+UGVyaW5nYXRhbjogVGVyZGV0ZWtzaSBha3Rpdml0YXMga2VsdWFyIC8gcGVsYW5nZ2FyYW4gbW9kZSB1amlhbiE8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybS5tYXhUYWJTd2l0Y2ggPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gb3BhY2l0eS05MFwiPlBpbmRhaCBUYWI6IHt0YWJTd2l0Y2hDb3VudH0ve2Zvcm0ubWF4VGFiU3dpdGNofSB7dmlvbGF0aW9uQ291bnQgPiB0YWJTd2l0Y2hDb3VudCA/IGDigKIgVG90YWwgUGVsYW5nZ2FyYW46ICR7dmlvbGF0aW9uQ291bnR9YCA6ICcnfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gb3BhY2l0eS05MFwiPlBpbmRhaCBUYWI6IHt0YWJTd2l0Y2hDb3VudH0ge3Zpb2xhdGlvbkNvdW50ID4gdGFiU3dpdGNoQ291bnQgPyBg4oCiIFRvdGFsIFBlbGFuZ2dhcmFuOiAke3Zpb2xhdGlvbkNvdW50fWAgOiAnJ308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRUYWJTd2l0Y2hXYXJuaW5nKGZhbHNlKX0gY2xhc3NOYW1lPVwicC0xIGhvdmVyOmJnLXdoaXRlLzIwIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIj48WCBzaXplPXsxNX0gLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBWYWxpZGF0aW9uIFRvYXN0ICovfVxuICAgICAgICAgICAge3ZhbGlkYXRpb25Ub2FzdCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtNSBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIHotNTAgbWF4LXctbWQgdy1bOTJ2d10gc206dy1hdXRvIGJnLXJlZC02MDAgZGFyazpiZy1yZWQtNzAwIHRleHQtd2hpdGUgcHgtNCBweS0zIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJvcmRlciBib3JkZXItcmVkLTUwMCBhbmltYXRlLWluIGZhZGUtaW4gc2xpZGUtaW4tZnJvbS10b3AtMyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+PEFsZXJ0Q2lyY2xlIHNpemU9ezE4fSBjbGFzc05hbWU9XCJzaHJpbmstMCB0ZXh0LXdoaXRlXCIgLz48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1ib2xkXCI+e3ZhbGlkYXRpb25Ub2FzdH08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFZhbGlkYXRpb25Ub2FzdChudWxsKX0gY2xhc3NOYW1lPVwicC0xIHRleHQtd2hpdGUvODAgaG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIHNocmluay0wXCI+PFggc2l6ZT17MTZ9IC8+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7aXNTdGVwTGF5b3V0ID8gJ21heC13LTR4bCBsZzptYXgtdy01eGwnIDogJ21heC13LTN4bCd9IG14LWF1dG8gc3BhY2UteS02IHRyYW5zaXRpb24tYWxsYH0+XG5cbiAgICAgICAgICAgICAgICB7LyogQS01OiBQcmV2aWV3IGJhbm5lciAqL31cbiAgICAgICAgICAgICAgICB7aXNQcmV2aWV3TW9kZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNjAgYm9yZGVyIGJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItODAwIHJvdW5kZWQtMnhsIHB4LTQgcHktMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZFwiPjxFeWUgc2l6ZT17MTV9IC8+PHNwYW4+TW9kZSBQcmV2aWV3IOKAlCBKYXdhYmFuIHRpZGFrIGFrYW4gZGlzaW1wYW48L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB3aW5kb3cuY2xvc2UoKX0gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCBob3Zlcjp1bmRlcmxpbmUgY3Vyc29yLXBvaW50ZXJcIj5UdXR1cCBQcmV2aWV3PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7LyogVG9wIEJhciDigJQgaGlkZSByZXBvcnQgYnV0dG9uIGluIHByZXZpZXcgbW9kZSAoQS00KSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17dG9nZ2xlRGFya01vZGV9IGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHNoYWRvdy14cyB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1ib2xkIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRGFya01vZGUgPyA8U3VuIHNpemU9ezE1fSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTQwMFwiIC8+IDogPE1vb24gc2l6ZT17MTV9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXNEYXJrTW9kZSA/ICdNb2RlIFRlcmFuZycgOiAnTW9kZSBHZWxhcCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQS00OiBIaWRlIHJlcG9ydCBidXR0b24gaW4gcHJldmlldyBtb2RlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgeyFpc1ByZXZpZXdNb2RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRSZXBvcnRNb2RhbE9wZW4odHJ1ZSl9IGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTkwMC82MCBiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MCB0ZXh0LWFtYmVyLTcwMCBkYXJrOnRleHQtYW1iZXItMzAwIGhvdmVyOmJnLWFtYmVyLTEwMCBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBzaXplPXsxNH0gLz48c3Bhbj5MYXBvcmthbiBNYXNhbGFoPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHt0aW1lTGVmdCAhPT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHB4LTQgcHktMiByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgYm9yZGVyIGJhY2tkcm9wLWJsdXItbWQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXhzIHNtOnRleHQtc20gJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lTGVmdCA8PSA2MFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1yZWQtNTAwLzkwIHRleHQtd2hpdGUgYm9yZGVyLXJlZC00MDAgYW5pbWF0ZS1wdWxzZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0aW1lTGVmdCA8PSAzMDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzkwIHRleHQtd2hpdGUgYm9yZGVyLWFtYmVyLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwLzkwIGRhcms6Ymctc2xhdGUtODAwLzkwIHRleHQtdGVhbC00MDAgYm9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvY2sgc2l6ZT17MTV9IC8+PHNwYW4+V2FrdHU6IHtmb3JtYXRUaW1lcih0aW1lTGVmdCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQjEzOiBUaW1lciBwcm9ncmVzcyBiYXIgKi99XG4gICAgICAgICAgICAgICAge3RpbWVMZWZ0ICE9PSBudWxsICYmIGZvcm0/LnRpbWVyRHVyYXRpb24gPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xIGJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIG1iLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTEwMDAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZUxlZnQgPD0gNjAgPyAnYmctcmVkLTUwMCcgOiB0aW1lTGVmdCA8PSAzMDAgPyAnYmctYW1iZXItNTAwJyA6ICdiZy10ZWFsLTUwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7TWF0aC5tYXgoMCwgKHRpbWVMZWZ0IC8gZm9ybS50aW1lckR1cmF0aW9uKSAqIDEwMCl9JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7LyogRm9ybSBoZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgICAgICB7Zm9ybT8uYmFubmVySW1hZ2UgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC00NCBzbTpoLTU2IHJlbGF0aXZlIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17YXNzZXRVcmwoZm9ybS5iYW5uZXJJbWFnZSl9IGFsdD17Zm9ybS50aXRsZX0gY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHNtOnAtOCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIHNtOnRleHQtM3hsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0cmFja2luZy10aWdodCBicmVhay13b3Jkc1wiPntmb3JtPy50aXRsZSB8fCAnRm9ybXVsaXInfTwvaDE+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm0/LmRlc2NyaXB0aW9uICYmIDxkaXYgY2xhc3NOYW1lPVwicHQtMiB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRleHQtc20gbGVhZGluZy1yZWxheGVkIGJyZWFrLXdvcmRzIGJyZWFrLWFsbCBbb3ZlcmZsb3ctd3JhcDphbnl3aGVyZV1cIj48UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXtmb3JtLmRlc2NyaXB0aW9ufSAvPjwvZGl2Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJsb2NrXCI+TmFtYSBBbmRhIChPcHNpb25hbCk6PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17cmVzcG9uZGVudE5hbWV9IG9uQ2hhbmdlPXtlID0+IHNldFJlc3BvbmRlbnROYW1lKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJNYXN1a2thbiBuYW1hIGxlbmdrYXAgQW5kYS4uLlwiIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zLjUgcHktMi41IHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktMy41IGJnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNTAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIGRhcms6Ym9yZGVyLXJlZC04MDAgcm91bmRlZC0yeGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgc2l6ZT17MTZ9IC8+PHNwYW4+e2Vycm9yfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiDilIDilIAgU1RFUCBMQVlPVVQg4pSA4pSAICovfVxuICAgICAgICAgICAgICAgIHtpc1N0ZXBMYXlvdXQgJiYgY3VycmVudFEgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgaWQ9e2BxdWVzdGlvbi1jYXJkLSR7Y3VycmVudFEuaWR9YH0gY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtNiBzbTpwLTEwIGxnOnAtMTIgc2hhZG93LXNtIHNwYWNlLXktOCB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1ib2xkIHB4LTMuNSBweS0xLjUgcm91bmRlZC1mdWxsXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHtwcmltYXJ5Q29sb3J9MThgLCBjb2xvcjogcHJpbWFyeUNvbG9yIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU29hbCB7Y3VycmVudFN0ZXAgKyAxfSBkYXJpIHt0b3RhbFN0ZXBzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBLTE6IG5hdiBwb3B1cCB0cmlnZ2VyICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXROYXZQb3B1cE9wZW4odHJ1ZSl9IHRpdGxlPVwiTmF2aWdhc2kgc29hbCBjZXBhdFwiIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExheW91dEdyaWQgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRRLmlzUmVxdWlyZWQgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1yZWQtNTAwIGJnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNjAgcHgtMi41IHB5LTAuNSByb3VuZGVkLW1kXCI+V2FqaWI8L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQS0yOiBzb2xpZCB5ZWxsb3cgcmFndS1yYWd1ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TWFya2VkRm9yUmV2aWV3KHByZXYgPT4geyBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2KTsgaWYgKG5leHQuaGFzKGN1cnJlbnRRLmlkKSkgbmV4dC5kZWxldGUoY3VycmVudFEuaWQpOyBlbHNlIG5leHQuYWRkKGN1cnJlbnRRLmlkKTsgcmV0dXJuIG5leHQ7IH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmtlZEZvclJldmlldy5oYXMoY3VycmVudFEuaWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXllbGxvdy00MDAgZGFyazpiZy15ZWxsb3ctNTAwIHRleHQtd2hpdGUgYm9yZGVyLXllbGxvdy00MDAgZGFyazpib3JkZXIteWVsbG93LTUwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBob3Zlcjpib3JkZXIteWVsbG93LTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttYXJrZWRGb3JSZXZpZXcuaGFzKGN1cnJlbnRRLmlkKSA/IDxCb29rbWFya0NoZWNrIHNpemU9ezE0fSAvPiA6IDxCb29rbWFyayBzaXplPXsxNH0gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57bWFya2VkRm9yUmV2aWV3LmhhcyhjdXJyZW50US5pZCkgPyAnUmFndS1yYWd1JyA6ICdUYW5kYWknfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFEucXVlc3Rpb25JbWFnZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktMiB3LWZ1bGwgbWF4LXctMnhsIHJlbGF0aXZlIGdyb3VwL2ltZyBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzQwIHAtMiBzaGFkb3cteHMgbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2Fzc2V0VXJsKGN1cnJlbnRRLnF1ZXN0aW9uSW1hZ2UpfSBhbHQ9XCJHYW1iYXIgU29hbFwiIGNsYXNzTmFtZT1cIm1heC1oLTk2IHNtOm1heC1oLVs0NDBweF0gdy1hdXRvIG1heC13LWZ1bGwgcm91bmRlZC14bCBvYmplY3QtY29udGFpbiBteC1hdXRvIGN1cnNvci16b29tLWluXCIgb25DbGljaz17KCkgPT4gc2V0TGlnaHRib3hJbWFnZSh7IHNyYzogYXNzZXRVcmwoY3VycmVudFEucXVlc3Rpb25JbWFnZSksIGFsdDogJ0dhbWJhciBTb2FsJyB9KX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldExpZ2h0Ym94SW1hZ2UoeyBzcmM6IGFzc2V0VXJsKGN1cnJlbnRRLnF1ZXN0aW9uSW1hZ2UpLCBhbHQ6ICdHYW1iYXIgU29hbCcgfSl9IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0zIHJpZ2h0LTMgcC0yIGJnLXNsYXRlLTkwMC84MCBob3ZlcjpiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1tZCB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBvcGFjaXR5LTAgZ3JvdXAtaG92ZXIvaW1nOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBjdXJzb3ItcG9pbnRlclwiPjxNYXhpbWl6ZTIgc2l6ZT17MTN9IC8+IFBlcmJlc2FyPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRRLnF1ZXN0aW9uQXVkaW8gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTIgbWF4LXctbWQgdy1mdWxsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzgwIHAtMi41IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhdWRpbyBjb250cm9scyBzcmM9e2Fzc2V0VXJsKGN1cnJlbnRRLnF1ZXN0aW9uQXVkaW8pfSBjbGFzc05hbWU9XCJ3LWZ1bGwgaC04IHJvdW5kZWQteGwgb3V0bGluZS1ub25lXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYmFzZSBzbTp0ZXh0LWxnIGxnOnRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLXJlbGF4ZWQgYnJlYWstd29yZHMgYnJlYWstYWxsIFtvdmVyZmxvdy13cmFwOmFueXdoZXJlXVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXtjdXJyZW50US5xdWVzdGlvbn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTJcIj57cmVuZGVyQW5zd2VyRmllbGQoY3VycmVudFEsIGFuc3dlcnMsIGhhbmRsZUFuc3dlckNoYW5nZSwgaGFuZGxlQ2hlY2tib3hDaGFuZ2UsIHByaW1hcnlDb2xvciwgc2V0TGlnaHRib3hJbWFnZSl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRTdGVwKHByZXYgPT4gTWF0aC5tYXgocHJldiAtIDEsIDApKX0gZGlzYWJsZWQ9e2N1cnJlbnRTdGVwID09PSAwfSBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd0xlZnQgc2l6ZT17MTR9IC8+IFNlYmVsdW1ueWFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFN0ZXAgPCB0b3RhbFN0ZXBzIC0gMSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFN0ZXAocHJldiA9PiBwcmV2ICsgMSl9IGNsYXNzTmFtZT1cInB4LTUgcHktMi41IHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBzaGFkb3cteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBjdXJzb3ItcG9pbnRlclwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogcHJpbWFyeUNvbG9yIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VsYW5qdXRueWEgPEFycm93UmlnaHQgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEEtNDogSW4gcHJldmlldyBtb2RlLCBzaG93IFwiU2VsZXNhaSBQcmV2aWV3XCIgaW5zdGVhZCBvZiBzdWJtaXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNQcmV2aWV3TW9kZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5jbG9zZSgpfSBjbGFzc05hbWU9XCJweC02IHB5LTIuNSBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNjAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBzaGFkb3cteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIHNpemU9ezE0fSAvPiBTZWxlc2FpIFByZXZpZXdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KGUpID0+IGhhbmRsZVN1Ym1pdChlLCBmYWxzZSl9IGRpc2FibGVkPXtzdWJtaXR0aW5nfSBjbGFzc05hbWU9XCJweC02IHB5LTIuNSBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIGRhcms6YmctdGVhbC02MDAgZGFyazpob3ZlcjpiZy10ZWFsLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VuZCBzaXplPXsxNH0gLz4ge3N1Ym1pdHRpbmcgPyAnTWVuZ2lyaW1rYW4uLi4nIDogJ0tpcmltIEZvcm11bGlyJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAvLyDilIDilIAgU0NST0xMIExBWU9VVCDilIDilIBcbiAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9eyhlKSA9PiBoYW5kbGVTdWJtaXQoZSwgZmFsc2UpfSBjbGFzc05hbWU9XCJzcGFjZS15LTVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtxdWVzdGlvbnMubWFwKChxLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cS5pZCB8fCBpZHh9IGlkPXtgcXVlc3Rpb24tY2FyZC0ke3EuaWR9YH0gY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtNSBzbTpwLTggc2hhZG93LXNtIHNwYWNlLXktNCB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwYi0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNocmluay0wIHctNyBoLTcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBwcmltYXJ5Q29sb3IgfX0+e2lkeCArIDF9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EuaXNSZXF1aXJlZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJzaHJpbmstMCB0ZXh0LVsxMXB4XSBmb250LWV4dHJhYm9sZCB0ZXh0LXJlZC01MDAgYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC82MCBweC0yIHB5LTAuNSByb3VuZGVkLW1kXCI+V2FqaWI8L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EucXVlc3Rpb25JbWFnZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTIgdy1mdWxsIG1heC13LTJ4bCByZWxhdGl2ZSBncm91cC9pbWcgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCBwLTIgc2hhZG93LXhzIG14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17YXNzZXRVcmwocS5xdWVzdGlvbkltYWdlKX0gYWx0PVwiR2FtYmFyIFNvYWxcIiBjbGFzc05hbWU9XCJtYXgtaC05NiBzbTptYXgtaC1bNDQwcHhdIHctYXV0byBtYXgtdy1mdWxsIHJvdW5kZWQteGwgb2JqZWN0LWNvbnRhaW4gbXgtYXV0byBjdXJzb3Item9vbS1pblwiIG9uQ2xpY2s9eygpID0+IHNldExpZ2h0Ym94SW1hZ2UoeyBzcmM6IGFzc2V0VXJsKHEucXVlc3Rpb25JbWFnZSksIGFsdDogJ0dhbWJhciBTb2FsJyB9KX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRMaWdodGJveEltYWdlKHsgc3JjOiBhc3NldFVybChxLnF1ZXN0aW9uSW1hZ2UpLCBhbHQ6ICdHYW1iYXIgU29hbCcgfSl9IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0zIHJpZ2h0LTMgcC0yIGJnLXNsYXRlLTkwMC84MCBob3ZlcjpiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1tZCB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBvcGFjaXR5LTAgZ3JvdXAtaG92ZXIvaW1nOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBjdXJzb3ItcG9pbnRlclwiPjxNYXhpbWl6ZTIgc2l6ZT17MTN9IC8+IFBlcmJlc2FyPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EucXVlc3Rpb25BdWRpbyAmJiA8ZGl2IGNsYXNzTmFtZT1cIm15LTIgbWF4LXctbWQgdy1mdWxsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzgwIHAtMi41IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBzaGFkb3cteHNcIj48YXVkaW8gY29udHJvbHMgc3JjPXthc3NldFVybChxLnF1ZXN0aW9uQXVkaW8pfSBjbGFzc05hbWU9XCJ3LWZ1bGwgaC04IHJvdW5kZWQteGwgb3V0bGluZS1ub25lXCIgLz48L2Rpdj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBzbTp0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLXJlbGF4ZWQgYnJlYWstd29yZHMgYnJlYWstYWxsIFtvdmVyZmxvdy13cmFwOmFueXdoZXJlXVwiPjxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e3EucXVlc3Rpb259IC8+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMlwiPntyZW5kZXJBbnN3ZXJGaWVsZChxLCBhbnN3ZXJzLCBoYW5kbGVBbnN3ZXJDaGFuZ2UsIGhhbmRsZUNoZWNrYm94Q2hhbmdlLCBwcmltYXJ5Q29sb3IsIHNldExpZ2h0Ym94SW1hZ2UpfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBLTQ6IFByZXZpZXcgbW9kZSDigJQgc2hvdyBcIlNlbGVzYWkgUHJldmlld1wiIG9ubHksIG5vIHJlYWwgc3VibWl0ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ByZXZpZXdNb2RlID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB3aW5kb3cuY2xvc2UoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gcHgtOCBweS0zLjUgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTYwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgdGV4dC1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV5ZSBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNlbGVzYWkgUHJldmlldzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e3N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIHB4LTggcHktMy41IHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQtMnhsIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCB0ZXh0LXNtIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBwcmltYXJ5Q29sb3IgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VuZCBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntzdWJtaXR0aW5nID8gJ01lbmdpcmlta2FuIFJlc3BvbnMuLi4nIDogJ0tpcmltIFJlc3BvbnMgRm9ybXVsaXInfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQS0xOiBOYXYgcG9wdXAgbW9kYWwgKi99XG4gICAgICAgICAgICB7bmF2UG9wdXBPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzUwIGJhY2tkcm9wLWJsdXIteHNcIiBvbkNsaWNrPXsoKSA9PiBzZXROYXZQb3B1cE9wZW4oZmFsc2UpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTUgbWF4LXctc20gdy1mdWxsIHNoYWRvdy0yeGwgei0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj48TGF5b3V0R3JpZCBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMFwiIC8+IE5hdmlnYXNpIFNvYWw8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0TmF2UG9wdXBPcGVuKGZhbHNlKX0gY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgY3Vyc29yLXBvaW50ZXJcIj48WCBzaXplPXsxNn0gLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi0zIGZsZXgtd3JhcCB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj48c3BhbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHJvdW5kZWQgYmctZW1lcmFsZC01MDAgaW5saW5lLWJsb2NrXCIgLz4gVGVyamF3YWI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj48c3BhbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHJvdW5kZWQgYmctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtNzAwIGlubGluZS1ibG9ja1wiIC8+IEJlbHVtPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+PHNwYW4gY2xhc3NOYW1lPVwidy0zIGgtMyByb3VuZGVkIGJnLXllbGxvdy00MDAgaW5saW5lLWJsb2NrXCIgLz4gUmFndS1yYWd1PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTUgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cXVlc3Rpb25zLm1hcCgocSwgcUlkeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0Fuc3dlcmVkID0gKCgpID0+IHsgY29uc3QgdmFsID0gYW5zd2Vyc1txLmlkXTsgcmV0dXJuIHEudHlwZUlkID09PSAzID8gQXJyYXkuaXNBcnJheSh2YWwpICYmIHZhbC5sZW5ndGggPiAwIDogdmFsICE9PSB1bmRlZmluZWQgJiYgdmFsICE9PSBudWxsICYmIFN0cmluZyh2YWwpLnRyaW0oKS5sZW5ndGggPiAwOyB9KSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IHFJZHggPT09IGN1cnJlbnRTdGVwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc01hcmtlZCA9IG1hcmtlZEZvclJldmlldy5oYXMocS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGtleT17cS5pZCB8fCBxSWR4fSB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldEN1cnJlbnRTdGVwKHFJZHgpOyBzZXROYXZQb3B1cE9wZW4oZmFsc2UpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIHctZnVsbCBhc3BlY3Qtc3F1YXJlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ3RleHQtd2hpdGUgcmluZy0yIHJpbmctb2Zmc2V0LTEgcmluZy10ZWFsLTUwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaXNNYXJrZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXllbGxvdy00MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaXNBbnN3ZXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17aXNBY3RpdmUgPyB7IGJhY2tncm91bmRDb2xvcjogcHJpbWFyeUNvbG9yIH0gOiB7fX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3FJZHggKyAxfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc01hcmtlZCAmJiAhaXNBY3RpdmUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTAuNSAtcmlnaHQtMC41IHctMi41IGgtMi41IGJnLXllbGxvdy00MDAgcm91bmRlZC1mdWxsIGJvcmRlci0yIGJvcmRlci13aGl0ZSBkYXJrOmJvcmRlci1zbGF0ZS05MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBSZXBvcnQgTW9kYWwgKi99XG4gICAgICAgICAgICB7cmVwb3J0TW9kYWxPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzYwIGJhY2tkcm9wLWJsdXIteHNcIiBvbkNsaWNrPXsoKSA9PiBzZXRSZXBvcnRNb2RhbE9wZW4oZmFsc2UpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTYgc206cC04IG1heC13LW1kIHctZnVsbCBzaGFkb3ctMnhsIHNwYWNlLXktNCB6LTEwIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtYW1iZXItNTAwIGZvbnQtZXh0cmFib2xkIHRleHQtc21cIj48QWxlcnRUcmlhbmdsZSBzaXplPXsxOH0gLz48c3Bhbj5MYXBvcmthbiBNYXNhbGFoIEZvcm11bGlyPC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFJlcG9ydE1vZGFsT3BlbihmYWxzZSl9IGNsYXNzTmFtZT1cInAtMSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIj48WCBzaXplPXsxOH0gLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAge3JlcG9ydFN1Y2Nlc3MgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzUwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAgcm91bmRlZC0yeGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj48Q2hlY2tDaXJjbGUyIHNpemU9ezE2fSAvPjxzcGFuPkxhcG9yYW4gbWFzYWxhaCBBbmRhIHRlbGFoIHRlcmtpcmltLiBUZXJpbWEga2FzaWghPC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2VuZFJlcG9ydH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXBvcnRFcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTUwLzUwIGJvcmRlciBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwXCI+e3JlcG9ydEVycm9yfTwvZGl2Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTEuNVwiPkFsYXNhbiBNYXNhbGFoPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e3JlcG9ydFJlYXNvbn0gb25DaGFuZ2U9e2UgPT4gc2V0UmVwb3J0UmVhc29uKGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yLjUgdGV4dC14cyBmb250LWJvbGQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUEVSVEFOWUFBTl9USURBS19KRUxBU1wiPlBlcnRhbnlhYW4gdGlkYWsgamVsYXMgLyByYW5jdTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJLVU5DSV9KQVdBQkFOX1NBTEFIXCI+S3VuY2kgamF3YWJhbiAvIG9wc2kgc2FsYWg8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiS0VOREFMQV9URUtOSVNcIj5LZW5kYWxhIHRla25pcyAvIG1lZGlhIHRpZGFrIHRhbXBpbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJLT05URU5fVElEQUtfUEFOVEFTXCI+S29udGVuIHRpZGFrIHBhbnRhczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJMQUlOTllBXCI+QWxhc2FuIGxhaW5ueWE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTEuNVwiPkRlc2tyaXBzaSBLZW5kYWxhIChPcHNpb25hbCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhIHJvd3M9ezN9IHZhbHVlPXtyZXBvcnREZXNjcmlwdGlvbn0gb25DaGFuZ2U9e2UgPT4gc2V0UmVwb3J0RGVzY3JpcHRpb24oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkNlcml0YWthbiBkZXRhaWwga2VuZGFsYSB5YW5nIGRpYWxhbWkuLi5cIiBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0zIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yIHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFJlcG9ydE1vZGFsT3BlbihmYWxzZSl9IGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGN1cnNvci1wb2ludGVyXCI+QmF0YWw8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtzdWJtaXR0aW5nUmVwb3J0fSBjbGFzc05hbWU9XCJweC01IHB5LTIgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS02MFwiPjxTZW5kIHNpemU9ezEzfSAvPjxzcGFuPntzdWJtaXR0aW5nUmVwb3J0ID8gJ01lbmdpcmltLi4uJyA6ICdLaXJpbSBMYXBvcmFuJ308L3NwYW4+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIEIxMDogUmFndS1yYWd1IHdhcm5pbmcgZGlhbG9nIChmaXJzdCBvZiB0d28tZGlhbG9nIHNlcXVlbmNlKSAqL31cbiAgICAgICAgICAgIHtyZXZpZXdXYXJuaW5nT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay82MCBiYWNrZHJvcC1ibHVyLXhzXCIgb25DbGljaz17KCkgPT4gc2V0UmV2aWV3V2FybmluZ09wZW4oZmFsc2UpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgbWF4LXctc20gdy1mdWxsIHNoYWRvdy0yeGwgc3BhY2UteS00IHotMTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQtZnVsbCBiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC82MCB0ZXh0LWFtYmVyLTUwMFwiPjxCb29rbWFyayBzaXplPXsyMH0gLz48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5BZGEgU29hbCBSYWd1LVJhZ3U8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBLYW11IG1hc2loIG1lbmFuZGFpIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwXCI+e21hcmtlZEZvclJldmlldy5zaXplfSBzb2FsPC9zcGFuPiBzZWJhZ2FpIHJhZ3UtcmFndS4gSW5naW4gbWVuaW5qYXUgZHVsdSBzZWJlbHVtIG1lbmdpcmltP1xuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UmV2aWV3V2FybmluZ09wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZmlyc3RNYXJrZWRJZCA9IFsuLi5tYXJrZWRGb3JSZXZpZXddWzBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0TWFya2VkSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGBxdWVzdGlvbi1jYXJkLSR7Zmlyc3RNYXJrZWRJZH1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZWwpIGVsLnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnLCBibG9jazogJ2NlbnRlcicgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC00IHB5LTIuNSBiZy1hbWJlci01MCBob3ZlcjpiZy1hbWJlci0xMDAgZGFyazpiZy1hbWJlci05NTAvNDAgZGFyazpob3ZlcjpiZy1hbWJlci05NTAvNjAgdGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+VGluamF1IFNvYWwgUmFndS1SYWd1PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UmV2aWV3V2FybmluZ09wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlU3VibWl0KG51bGwsIGZhbHNlLCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTQgcHktMi41IHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogcHJpbWFyeUNvbG9yIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlRldGFwIEtpcmltPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogRkVBVC0zOiBTdWJtaXQgY29uZmlybSAqL31cbiAgICAgICAgICAgIHtzdWJtaXRDb25maXJtT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay82MCBiYWNrZHJvcC1ibHVyLXhzXCIgb25DbGljaz17KCkgPT4gc2V0U3VibWl0Q29uZmlybU9wZW4oZmFsc2UpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgbWF4LXctc20gdy1mdWxsIHNoYWRvdy0yeGwgc3BhY2UteS00IHotMTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQtZnVsbCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwXCI+PFNlbmQgc2l6ZT17MjB9IC8+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+S2lyaW0gSmF3YWJhbj88L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5KYXdhYmFuIHRpZGFrIGRhcGF0IGRpdWJhaCBzZXRlbGFoIGRpa2lyaW0uIEFwYWthaCBBbmRhIHlha2luPzwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFN1Ym1pdENvbmZpcm1PcGVuKGZhbHNlKX0gY2xhc3NOYW1lPVwiZmxleC0xIHB4LTQgcHktMi41IGJnLXNsYXRlLTEwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyXCI+QmF0YWw8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQobnVsbCwgZmFsc2UpfSBjbGFzc05hbWU9XCJmbGV4LTEgcHgtNCBweS0yLjUgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBwcmltYXJ5Q29sb3IgfX0+WWEsIEtpcmltPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8SW1hZ2VMaWdodGJveE1vZGFsIGlzT3Blbj17ISFsaWdodGJveEltYWdlfSBzcmM9e2xpZ2h0Ym94SW1hZ2U/LnNyY30gYWx0PXtsaWdodGJveEltYWdlPy5hbHR9IG9uQ2xvc2U9eygpID0+IHNldExpZ2h0Ym94SW1hZ2UobnVsbCl9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFuc3dlckZpZWxkKHEsIGFuc3dlcnMsIGhhbmRsZUFuc3dlckNoYW5nZSwgaGFuZGxlQ2hlY2tib3hDaGFuZ2UsIHByaW1hcnlDb2xvciA9ICcjMDA4OTdCJywgb25PcGVuSW1hZ2UgPSBudWxsKSB7XG4gICAgY29uc3QgdmFsID0gYW5zd2Vyc1txLmlkXTtcblxuICAgIGlmIChxLnR5cGVJZCA9PT0gMSkgcmV0dXJuIChcbiAgICAgICAgPHRleHRhcmVhIHJvd3M9ezN9IHZhbHVlPXt2YWwgfHwgJyd9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZUFuc3dlckNoYW5nZShxLmlkLCBlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiS2V0aWtrYW4gamF3YWJhbiBBbmRhIGRpIHNpbmkuLi5cIiBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtMnhsIHAtMy41IHRleHQteHMgc206dGV4dC1zbSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiIC8+XG4gICAgKTtcblxuICAgIGlmIChxLnR5cGVJZCA9PT0gMikgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIuNVwiPlxuICAgICAgICAgICAgeyhxLm9wdGlvbnMgfHwgW10pLm1hcChvcHQgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBTdHJpbmcodmFsKSA9PT0gU3RyaW5nKG9wdC5pZCk7XG4gICAgICAgICAgICAgICAgY29uc3Qgb3B0SW1nID0gb3B0Lm9wdGlvbkltYWdlIHx8IG9wdC5pbWFnZSB8fCBvcHQuaW1hZ2VVcmw7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGtleT17b3B0LmlkfSBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIHAtMy41IHJvdW5kZWQtMnhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke2lzU2VsZWN0ZWQgPyAnZm9udC1ib2xkJyA6ICdib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTUwJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e2lzU2VsZWN0ZWQgPyB7IGJvcmRlckNvbG9yOiBwcmltYXJ5Q29sb3IsIGJhY2tncm91bmRDb2xvcjogYCR7cHJpbWFyeUNvbG9yfTE4YCwgY29sb3I6IHByaW1hcnlDb2xvciB9IDoge319PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJyYWRpb1wiIG5hbWU9e2BxXyR7cS5pZH1gfSB2YWx1ZT17b3B0LmlkfSBjaGVja2VkPXtpc1NlbGVjdGVkfSBvbkNoYW5nZT17KCkgPT4gaGFuZGxlQW5zd2VyQ2hhbmdlKHEuaWQsIG9wdC5pZCl9IGNsYXNzTmFtZT1cInctNCBoLTQgY3Vyc29yLXBvaW50ZXIgbXQtMC41XCIgc3R5bGU9e3sgYWNjZW50Q29sb3I6IHByaW1hcnlDb2xvciB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gbGVhZGluZy1yZWxheGVkIGZsZXgtMSBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0SW1nICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXthc3NldFVybChvcHRJbWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtvcHQub3B0aW9uVGV4dCB8fCAnR2FtYmFyIE9wc2knfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtNDggbWF4LXctZnVsbCByb3VuZGVkLXhsIG9iamVjdC1jb250YWluIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBwLTEgY3Vyc29yLXpvb20taW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbk9wZW5JbWFnZT8uKHsgc3JjOiBhc3NldFVybChvcHRJbWcpLCBhbHQ6IG9wdC5vcHRpb25UZXh0IHx8ICdHYW1iYXIgT3BzaScgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17b3B0Lm9wdGlvblRleHR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG5cbiAgICBpZiAocS50eXBlSWQgPT09IDMpIHtcbiAgICAgICAgY29uc3Qgc2VsZWN0ZWRBcnIgPSBBcnJheS5pc0FycmF5KHZhbCkgPyB2YWwgOiBbXTtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yLjVcIj5cbiAgICAgICAgICAgICAgICB7KHEub3B0aW9ucyB8fCBbXSkubWFwKG9wdCA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQ2hlY2tlZCA9IHNlbGVjdGVkQXJyLmluY2x1ZGVzKG9wdC5pZCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG9wdEltZyA9IG9wdC5vcHRpb25JbWFnZSB8fCBvcHQuaW1hZ2UgfHwgb3B0LmltYWdlVXJsO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGtleT17b3B0LmlkfSBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIHAtMy41IHJvdW5kZWQtMnhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke2lzQ2hlY2tlZCA/ICdmb250LWJvbGQnIDogJ2JvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtNTAnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e2lzQ2hlY2tlZCA/IHsgYm9yZGVyQ29sb3I6IHByaW1hcnlDb2xvciwgYmFja2dyb3VuZENvbG9yOiBgJHtwcmltYXJ5Q29sb3J9MThgLCBjb2xvcjogcHJpbWFyeUNvbG9yIH0gOiB7fX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e2lzQ2hlY2tlZH0gb25DaGFuZ2U9e2UgPT4gaGFuZGxlQ2hlY2tib3hDaGFuZ2UocS5pZCwgb3B0LmlkLCBlLnRhcmdldC5jaGVja2VkKX0gY2xhc3NOYW1lPVwidy00IGgtNCByb3VuZGVkIGN1cnNvci1wb2ludGVyIG10LTAuNVwiIHN0eWxlPXt7IGFjY2VudENvbG9yOiBwcmltYXJ5Q29sb3IgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgZmxleC0xIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0SW1nICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Fzc2V0VXJsKG9wdEltZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e29wdC5vcHRpb25UZXh0IHx8ICdHYW1iYXIgT3BzaSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtNDggbWF4LXctZnVsbCByb3VuZGVkLXhsIG9iamVjdC1jb250YWluIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBwLTEgY3Vyc29yLXpvb20taW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhldmVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25PcGVuSW1hZ2U/Lih7IHNyYzogYXNzZXRVcmwob3B0SW1nKSwgYWx0OiBvcHQub3B0aW9uVGV4dCB8fCAnR2FtYmFyIE9wc2knIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXtvcHQub3B0aW9uVGV4dH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAocS50eXBlSWQgPT09IDQpIHJldHVybiAoXG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT17cS5pbmNsdWRlVGltZSA/IFwiZGF0ZXRpbWUtbG9jYWxcIiA6IFwiZGF0ZVwifVxuICAgICAgICAgICAgdmFsdWU9e3ZhbCB8fCAnJ31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUFuc3dlckNoYW5nZShxLmlkLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAvPlxuICAgICk7XG5cbiAgICBpZiAocS50eXBlSWQgPT09IDUpIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyBtYXgtdy1zbVwiPlxuICAgICAgICAgICAge1t7IHZhbHVlOiAnQmVuYXInLCBsYWJlbDogJ0JlbmFyJyB9LCB7IHZhbHVlOiAnU2FsYWgnLCBsYWJlbDogJ1NhbGFoJyB9XS5tYXAoY2hvaWNlID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gU3RyaW5nKHZhbCkgPT09IGNob2ljZS52YWx1ZTtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGtleT17Y2hvaWNlLnZhbHVlfSB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gaGFuZGxlQW5zd2VyQ2hhbmdlKHEuaWQsIGNob2ljZS52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0zIHB4LTQgcm91bmRlZC0yeGwgYm9yZGVyIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7aXNTZWxlY3RlZCA/ICd0ZXh0LXdoaXRlIHNoYWRvdy14cycgOiAnYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS01MCd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXtpc1NlbGVjdGVkID8geyBiYWNrZ3JvdW5kQ29sb3I6IHByaW1hcnlDb2xvciwgYm9yZGVyQ29sb3I6IHByaW1hcnlDb2xvciB9IDoge319PlxuICAgICAgICAgICAgICAgICAgICAgICAge2Nob2ljZS5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xuXG4gICAgcmV0dXJuIG51bGw7XG59XG4iXX0=