import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/ImageLightboxModal.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { ZoomIn, ZoomOut, RotateCcw, X, Download } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ImageLightboxModal.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function ImageLightboxModal({ src, alt = "Gambar Soal", isOpen, onClose }) {
	_s();
	const [zoom, setZoom] = useState(1);
	const [position, setPosition] = useState({
		x: 0,
		y: 0
	});
	const [isDragging, setIsDragging] = useState(false);
	const [dragStart, setDragStart] = useState({
		x: 0,
		y: 0
	});
	useEffect(() => {
		if (isOpen) {
			setZoom(1);
			setPosition({
				x: 0,
				y: 0
			});
			document.body.style.overflow = "hidden";
		} else {
			document.body.style.overflow = "unset";
		}
		return () => {
			document.body.style.overflow = "unset";
		};
	}, [isOpen]);
	useEffect(() => {
		const handleKeyDown = (e) => {
			if (e.key === "Escape" && isOpen) {
				onClose();
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [isOpen, onClose]);
	if (!isOpen || !src) return null;
	const handleZoomIn = () => setZoom((prev) => Math.min(prev + .3, 3.5));
	const handleZoomOut = () => setZoom((prev) => Math.max(prev - .3, .6));
	const handleReset = () => {
		setZoom(1);
		setPosition({
			x: 0,
			y: 0
		});
	};
	const handleMouseDown = (e) => {
		if (zoom > 1) {
			setIsDragging(true);
			setDragStart({
				x: e.clientX - position.x,
				y: e.clientY - position.y
			});
		}
	};
	const handleMouseMove = (e) => {
		if (isDragging && zoom > 1) {
			setPosition({
				x: e.clientX - dragStart.x,
				y: e.clientY - dragStart.y
			});
		}
	};
	const handleMouseUp = () => setIsDragging(false);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 select-none",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "absolute top-4 left-4 right-4 z-20 flex items-center justify-between pointer-events-none",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "px-4 py-2 bg-black/60 backdrop-blur-md border border-white/10 rounded-2xl text-white text-xs font-semibold pointer-events-auto",
				children: alt
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 pointer-events-auto",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center bg-black/60 backdrop-blur-md border border-white/10 rounded-2xl p-1 text-white",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleZoomOut,
							disabled: zoom <= .6,
							className: "p-2 hover:bg-white/10 rounded-xl transition-colors disabled:opacity-40 cursor-pointer",
							title: "Perkecil",
							children: /* @__PURE__ */ _jsxDEV(ZoomOut, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "px-2 text-xs font-mono font-bold",
							children: [Math.round(zoom * 100), "%"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleZoomIn,
							disabled: zoom >= 3.5,
							className: "p-2 hover:bg-white/10 rounded-xl transition-colors disabled:opacity-40 cursor-pointer",
							title: "Perbesar",
							children: /* @__PURE__ */ _jsxDEV(ZoomIn, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleReset,
							className: "p-2 hover:bg-white/10 rounded-xl transition-colors cursor-pointer",
							title: "Reset Ukuran",
							children: /* @__PURE__ */ _jsxDEV(RotateCcw, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: src,
							target: "_blank",
							rel: "noreferrer",
							download: true,
							className: "p-2 hover:bg-white/10 rounded-xl transition-colors cursor-pointer text-teal-400",
							title: "Buka / Unduh Resolusi Penuh",
							children: /* @__PURE__ */ _jsxDEV(Download, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onClose,
					className: "p-2.5 bg-black/60 hover:bg-red-500/80 backdrop-blur-md border border-white/10 rounded-2xl text-white transition-colors cursor-pointer",
					title: "Tutup (Esc)",
					children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 25
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: `relative max-w-full max-h-full flex items-center justify-center overflow-hidden ${zoom > 1 ? isDragging ? "cursor-grabbing" : "cursor-grab" : "cursor-default"}`,
			onMouseDown: handleMouseDown,
			onMouseMove: handleMouseMove,
			onMouseUp: handleMouseUp,
			onMouseLeave: handleMouseUp,
			children: /* @__PURE__ */ _jsxDEV("img", {
				src,
				alt,
				draggable: false,
				className: "max-h-[85vh] max-w-[90vw] object-contain rounded-2xl shadow-2xl transition-transform duration-100 ease-out",
				style: { transform: `scale(${zoom}) translate(${position.x / zoom}px, ${position.y / zoom}px)` }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 130,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 123,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 9
	}, this);
}
_s(ImageLightboxModal, "UTSF+hkTCaZjLzzZPlOXucp62Ek=");
_c = ImageLightboxModal;
var _c;
$RefreshReg$(_c, "ImageLightboxModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/ImageLightboxModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ImageLightboxModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ImageLightboxModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ImageLightboxModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLFFBQVEsU0FBUyxXQUFXLEdBQUcsZ0JBQWdCOzs7O0FBRXhELGVBQWUsU0FBUyxtQkFBbUIsRUFBRSxLQUFLLE1BQU0sZUFBZSxRQUFRLFdBQVc7O0NBQ3RGLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDO0NBQ2xDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUztFQUFFLEdBQUc7RUFBRyxHQUFHO0NBQUUsQ0FBQztDQUN2RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTO0VBQUUsR0FBRztFQUFHLEdBQUc7Q0FBRSxDQUFDO0NBRXpELGdCQUFnQjtFQUNaLElBQUksUUFBUTtHQUNSLFFBQVEsQ0FBQztHQUNULFlBQVk7SUFBRSxHQUFHO0lBQUcsR0FBRztHQUFFLENBQUM7R0FDMUIsU0FBUyxLQUFLLE1BQU0sV0FBVztFQUNuQyxPQUFPO0dBQ0gsU0FBUyxLQUFLLE1BQU0sV0FBVztFQUNuQztFQUNBLGFBQWE7R0FDVCxTQUFTLEtBQUssTUFBTSxXQUFXO0VBQ25DO0NBQ0osR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUVYLGdCQUFnQjtFQUNaLE1BQU0saUJBQWlCLE1BQU07R0FDekIsSUFBSSxFQUFFLFFBQVEsWUFBWSxRQUFRO0lBQzlCLFFBQVE7R0FDWjtFQUNKO0VBQ0EsT0FBTyxpQkFBaUIsV0FBVyxhQUFhO0VBQ2hELGFBQWEsT0FBTyxvQkFBb0IsV0FBVyxhQUFhO0NBQ3BFLEdBQUcsQ0FBQyxRQUFRLE9BQU8sQ0FBQztDQUVwQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssT0FBTztDQUU1QixNQUFNLHFCQUFxQixTQUFRLFNBQVEsS0FBSyxJQUFJLE9BQU8sSUFBSyxHQUFHLENBQUM7Q0FDcEUsTUFBTSxzQkFBc0IsU0FBUSxTQUFRLEtBQUssSUFBSSxPQUFPLElBQUssRUFBRyxDQUFDO0NBQ3JFLE1BQU0sb0JBQW9CO0VBQ3RCLFFBQVEsQ0FBQztFQUNULFlBQVk7R0FBRSxHQUFHO0dBQUcsR0FBRztFQUFFLENBQUM7Q0FDOUI7Q0FFQSxNQUFNLG1CQUFtQixNQUFNO0VBQzNCLElBQUksT0FBTyxHQUFHO0dBQ1YsY0FBYyxJQUFJO0dBQ2xCLGFBQWE7SUFBRSxHQUFHLEVBQUUsVUFBVSxTQUFTO0lBQUcsR0FBRyxFQUFFLFVBQVUsU0FBUztHQUFFLENBQUM7RUFDekU7Q0FDSjtDQUVBLE1BQU0sbUJBQW1CLE1BQU07RUFDM0IsSUFBSSxjQUFjLE9BQU8sR0FBRztHQUN4QixZQUFZO0lBQ1IsR0FBRyxFQUFFLFVBQVUsVUFBVTtJQUN6QixHQUFHLEVBQUUsVUFBVSxVQUFVO0dBQzdCLENBQUM7RUFDTDtDQUNKO0NBRUEsTUFBTSxzQkFBc0IsY0FBYyxLQUFLO0NBRS9DLE9BQ0ksd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUVJLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNWO0dBQ0E7Ozs7YUFFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNJLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsU0FBUztPQUNULFVBQVUsUUFBUTtPQUNsQixXQUFVO09BQ1YsT0FBTTtpQkFFTix3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7OztNQUNoQjs7Ozs7TUFDUix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FDSyxLQUFLLE1BQU0sT0FBTyxHQUFHLEdBQUUsR0FDdEI7Ozs7OztNQUNOLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsU0FBUztPQUNULFVBQVUsUUFBUTtPQUNsQixXQUFVO09BQ1YsT0FBTTtpQkFFTix3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztNQUNmOzs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUVOLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O01BQ2xCOzs7OztNQUNSLHdCQUFDLEtBQUQ7T0FDSSxNQUFNO09BQ04sUUFBTztPQUNQLEtBQUk7T0FDSjtPQUNBLFdBQVU7T0FDVixPQUFNO2lCQUVOLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O01BQ3RCOzs7OztLQUNGOzs7OztjQUVMLHdCQUFDLFVBQUQ7S0FDSSxNQUFLO0tBQ0wsU0FBUztLQUNULFdBQVU7S0FDVixPQUFNO2VBRU4sd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7SUFDVjs7OztZQUNQOzs7OztXQUNKOzs7OztZQUdMLHdCQUFDLE9BQUQ7R0FDSSxXQUFXLG1GQUFtRixPQUFPLElBQUssYUFBYSxvQkFBb0IsZ0JBQWlCO0dBQzVKLGFBQWE7R0FDYixhQUFhO0dBQ2IsV0FBVztHQUNYLGNBQWM7YUFFZCx3QkFBQyxPQUFEO0lBQ1M7SUFDQTtJQUNMLFdBQVc7SUFDWCxXQUFVO0lBQ1YsT0FBTyxFQUNILFdBQVcsU0FBUyxLQUFLLGNBQWMsU0FBUyxJQUFJLEtBQUssTUFBTSxTQUFTLElBQUksS0FBSyxLQUNyRjtHQUNIOzs7OztFQUNBOzs7O1VBQ0o7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkltYWdlTGlnaHRib3hNb2RhbC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFpvb21JbiwgWm9vbU91dCwgUm90YXRlQ2N3LCBYLCBEb3dubG9hZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEltYWdlTGlnaHRib3hNb2RhbCh7IHNyYywgYWx0ID0gJ0dhbWJhciBTb2FsJywgaXNPcGVuLCBvbkNsb3NlIH0pIHtcbiAgICBjb25zdCBbem9vbSwgc2V0Wm9vbV0gPSB1c2VTdGF0ZSgxKTtcbiAgICBjb25zdCBbcG9zaXRpb24sIHNldFBvc2l0aW9uXSA9IHVzZVN0YXRlKHsgeDogMCwgeTogMCB9KTtcbiAgICBjb25zdCBbaXNEcmFnZ2luZywgc2V0SXNEcmFnZ2luZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2RyYWdTdGFydCwgc2V0RHJhZ1N0YXJ0XSA9IHVzZVN0YXRlKHsgeDogMCwgeTogMCB9KTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpc09wZW4pIHtcbiAgICAgICAgICAgIHNldFpvb20oMSk7XG4gICAgICAgICAgICBzZXRQb3NpdGlvbih7IHg6IDAsIHk6IDAgfSk7XG4gICAgICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gJ2hpZGRlbic7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gJ3Vuc2V0JztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9ICd1bnNldCc7XG4gICAgICAgIH07XG4gICAgfSwgW2lzT3Blbl0pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlKSA9PiB7XG4gICAgICAgICAgICBpZiAoZS5rZXkgPT09ICdFc2NhcGUnICYmIGlzT3Blbikge1xuICAgICAgICAgICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKTtcbiAgICAgICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gICAgfSwgW2lzT3Blbiwgb25DbG9zZV0pO1xuXG4gICAgaWYgKCFpc09wZW4gfHwgIXNyYykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBoYW5kbGVab29tSW4gPSAoKSA9PiBzZXRab29tKHByZXYgPT4gTWF0aC5taW4ocHJldiArIDAuMywgMy41KSk7XG4gICAgY29uc3QgaGFuZGxlWm9vbU91dCA9ICgpID0+IHNldFpvb20ocHJldiA9PiBNYXRoLm1heChwcmV2IC0gMC4zLCAwLjYpKTtcbiAgICBjb25zdCBoYW5kbGVSZXNldCA9ICgpID0+IHtcbiAgICAgICAgc2V0Wm9vbSgxKTtcbiAgICAgICAgc2V0UG9zaXRpb24oeyB4OiAwLCB5OiAwIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVNb3VzZURvd24gPSAoZSkgPT4ge1xuICAgICAgICBpZiAoem9vbSA+IDEpIHtcbiAgICAgICAgICAgIHNldElzRHJhZ2dpbmcodHJ1ZSk7XG4gICAgICAgICAgICBzZXREcmFnU3RhcnQoeyB4OiBlLmNsaWVudFggLSBwb3NpdGlvbi54LCB5OiBlLmNsaWVudFkgLSBwb3NpdGlvbi55IH0pO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZU1vdXNlTW92ZSA9IChlKSA9PiB7XG4gICAgICAgIGlmIChpc0RyYWdnaW5nICYmIHpvb20gPiAxKSB7XG4gICAgICAgICAgICBzZXRQb3NpdGlvbih7XG4gICAgICAgICAgICAgICAgeDogZS5jbGllbnRYIC0gZHJhZ1N0YXJ0LngsXG4gICAgICAgICAgICAgICAgeTogZS5jbGllbnRZIC0gZHJhZ1N0YXJ0LnlcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZU1vdXNlVXAgPSAoKSA9PiBzZXRJc0RyYWdnaW5nKGZhbHNlKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay84NSBiYWNrZHJvcC1ibHVyLW1kIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDAgc2VsZWN0LW5vbmVcIj5cbiAgICAgICAgICAgIHsvKiBUb3AgVG9vbGJhciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgbGVmdC00IHJpZ2h0LTQgei0yMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWJsYWNrLzYwIGJhY2tkcm9wLWJsdXItbWQgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCByb3VuZGVkLTJ4bCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCBwb2ludGVyLWV2ZW50cy1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIHthbHR9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHBvaW50ZXItZXZlbnRzLWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBiZy1ibGFjay82MCBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlciBib3JkZXItd2hpdGUvMTAgcm91bmRlZC0yeGwgcC0xIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVab29tT3V0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt6b29tIDw9IDAuNn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgaG92ZXI6Ymctd2hpdGUvMTAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTQwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlBlcmtlY2lsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Wm9vbU91dCBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiB0ZXh0LXhzIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7TWF0aC5yb3VuZCh6b29tICogMTAwKX0lXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlWm9vbUlufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt6b29tID49IDMuNX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgaG92ZXI6Ymctd2hpdGUvMTAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTQwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlBlcmJlc2FyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Wm9vbUluIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUmVzZXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGhvdmVyOmJnLXdoaXRlLzEwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVzZXQgVWt1cmFuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3NyY31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRvd25sb2FkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGhvdmVyOmJnLXdoaXRlLzEwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgdGV4dC10ZWFsLTQwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJCdWthIC8gVW5kdWggUmVzb2x1c2kgUGVudWhcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yLjUgYmctYmxhY2svNjAgaG92ZXI6YmctcmVkLTUwMC84MCBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlciBib3JkZXItd2hpdGUvMTAgcm91bmRlZC0yeGwgdGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlR1dHVwIChFc2MpXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBJbWFnZSBDYW52YXMgQ29udGFpbmVyICovfVxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIG1heC13LWZ1bGwgbWF4LWgtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gJHt6b29tID4gMSA/IChpc0RyYWdnaW5nID8gJ2N1cnNvci1ncmFiYmluZycgOiAnY3Vyc29yLWdyYWInKSA6ICdjdXJzb3ItZGVmYXVsdCd9YH1cbiAgICAgICAgICAgICAgICBvbk1vdXNlRG93bj17aGFuZGxlTW91c2VEb3dufVxuICAgICAgICAgICAgICAgIG9uTW91c2VNb3ZlPXtoYW5kbGVNb3VzZU1vdmV9XG4gICAgICAgICAgICAgICAgb25Nb3VzZVVwPXtoYW5kbGVNb3VzZVVwfVxuICAgICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17aGFuZGxlTW91c2VVcH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgIHNyYz17c3JjfVxuICAgICAgICAgICAgICAgICAgICBhbHQ9e2FsdH1cbiAgICAgICAgICAgICAgICAgICAgZHJhZ2dhYmxlPXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtWzg1dmhdIG1heC13LVs5MHZ3XSBvYmplY3QtY29udGFpbiByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTEwMCBlYXNlLW91dFwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IGBzY2FsZSgke3pvb219KSB0cmFuc2xhdGUoJHtwb3NpdGlvbi54IC8gem9vbX1weCwgJHtwb3NpdGlvbi55IC8gem9vbX1weClgLFxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==