import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboard/userDashboard/responsesPage.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { TrendingUp, Calendar, FileText, ChevronRight, Users, Award, Eye, X, CheckCircle2, XCircle, MinusCircle, ChevronLeft, Loader2, ArrowLeft, BarChart3, Download, Maximize2 } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import Topbar from "/src/components/layout/Topbar.jsx";
import { getMyForms, getFormAnalytics, getFormById, clearSession, exportFormResponses, assetUrl } from "/src/services/apiService.js";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
import ImageLightboxModal from "/src/components/ui/ImageLightboxModal.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/responsesPage.jsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function ResponsesPage() {
	_s();
	const navigate = useNavigate();
	const [forms, setForms] = useState([]);
	const [loadingForms, setLoadingForms] = useState(true);
	const [selectedFormId, setSelectedFormId] = useState(null);
	const [selectedFormData, setSelectedFormData] = useState(null);
	const [analyticsData, setAnalyticsData] = useState(null);
	const [loadingDetail, setLoadingDetail] = useState(false);
	const [searchQuery, setSearchQuery] = useState("");
	const [exporting, setExporting] = useState(false);
	const [lightboxImage, setLightboxImage] = useState(null);
	// Modal Review Answers State
	const [selectedRespondent, setSelectedRespondent] = useState(null);
	useEffect(() => {
		const fetchForms = async () => {
			try {
				setLoadingForms(true);
				const result = await getMyForms();
				if (result.status === 401) {
					clearSession();
					navigate("/login");
					return;
				}
				if (result.ok && Array.isArray(result.data)) {
					setForms(result.data);
					// Select first form if available
					if (result.data.length > 0) {
						setSelectedFormId(result.data[0].id);
					}
				}
			} catch (err) {
				console.error("Error fetching forms for responses page:", err);
			} finally {
				setLoadingForms(false);
			}
		};
		fetchForms();
	}, [navigate]);
	// Load analytics/responses data whenever selectedFormId changes
	useEffect(() => {
		if (!selectedFormId) return;
		const loadFormDetails = async () => {
			setLoadingDetail(true);
			try {
				const [formRes, analyticsRes] = await Promise.all([getFormById(selectedFormId), getFormAnalytics(selectedFormId, 1, 100)]);
				if (formRes.ok) setSelectedFormData(formRes.data);
				if (analyticsRes.ok && analyticsRes.data) {
					setAnalyticsData(analyticsRes.data);
				} else {
					setAnalyticsData(null);
				}
			} catch (err) {
				console.error("Error loading form detail/analytics:", err);
			} finally {
				setLoadingDetail(false);
			}
		};
		loadFormDetails();
	}, [selectedFormId]);
	// Filter forms based on search query
	const filteredForms = useMemo(() => {
		if (!searchQuery.trim()) return forms;
		const q = searchQuery.toLowerCase();
		return forms.filter((f) => f.title && f.title.toLowerCase().includes(q) || f.description && f.description.toLowerCase().includes(q));
	}, [forms, searchQuery]);
	// Calculate response trend from existing respondent data
	const respondents = analyticsData?.respondents || [];
	// Filter respondents based on search query
	const filteredRespondents = useMemo(() => {
		if (!searchQuery.trim()) return respondents;
		const q = searchQuery.toLowerCase();
		return respondents.filter((r) => r.respondentName && r.respondentName.toLowerCase().includes(q) || String(r.responseId).includes(q));
	}, [respondents, searchQuery]);
	const trendData = useMemo(() => {
		if (!respondents || respondents.length === 0) return [];
		const dateMap = {};
		respondents.forEach((r) => {
			if (!r.submittedAt) return;
			const d = new Date(r.submittedAt).toLocaleDateString("id-ID", {
				day: "2-digit",
				month: "short"
			});
			dateMap[d] = (dateMap[d] || 0) + 1;
		});
		return Object.entries(dateMap).map(([date, count]) => ({
			date,
			count
		}));
	}, [respondents]);
	const maxCount = useMemo(() => {
		if (trendData.length === 0) return 1;
		return Math.max(...trendData.map((d) => d.count), 1);
	}, [trendData]);
	const formatDate = (dateStr) => {
		if (!dateStr) return "—";
		return new Date(dateStr).toLocaleDateString("id-ID", {
			day: "numeric",
			month: "short",
			year: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		});
	};
	const totalAllResponses = forms.reduce((acc, f) => acc + (f.responseCount ?? 0), 0);
	const handleExport = async (formId) => {
		if (!formId || exporting) return;
		setExporting(true);
		try {
			const res = await exportFormResponses(formId);
			if (!res.ok) {
				alert(res.message || "Gagal mengekspor data CSV respons.");
			}
		} catch (err) {
			console.error("Error exporting CSV:", err);
			alert("Terjadi kesalahan saat mengekspor CSV.");
		} finally {
			setExporting(false);
		}
	};
	// Modal navigation
	const currentIndex = selectedRespondent ? respondents.findIndex((r) => r.responseId === selectedRespondent.responseId) : -1;
	const goPrevious = () => {
		if (currentIndex > 0) {
			setSelectedRespondent(respondents[currentIndex - 1]);
		}
	};
	const goNext = () => {
		if (currentIndex < respondents.length - 1) {
			setSelectedRespondent(respondents[currentIndex + 1]);
		}
	};
	const getAnswerStatus = (answer) => {
		if (answer.isCorrect === true) {
			return {
				label: "Benar",
				icon: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 183,
					columnNumber: 23
				}, this),
				className: "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
			};
		}
		if (answer.isCorrect === false) {
			return {
				label: "Salah",
				icon: /* @__PURE__ */ _jsxDEV(XCircle, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 23
				}, this),
				className: "text-red-600 bg-red-50 dark:bg-red-950/60 dark:text-red-400 border-red-200 dark:border-red-800"
			};
		}
		return {
			label: "Tidak Dinilai",
			icon: /* @__PURE__ */ _jsxDEV(MinusCircle, { size: 16 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 196,
				columnNumber: 19
			}, this),
			className: "text-slate-500 bg-slate-50 dark:bg-slate-800 dark:text-slate-400 border-slate-200 dark:border-slate-700"
		};
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen w-full bg-[#F4F8F7] dark:bg-slate-950 font-sans antialiased text-slate-800 dark:text-slate-100 transition-colors",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 203,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col min-w-0 overflow-y-auto",
				children: /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 w-full p-4 sm:p-6 lg:p-8 space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV(Topbar, {
							searchQuery,
							onSearchChange: setSearchQuery,
							placeholder: "Cari formulir, responden, atau jawaban..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
							children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-2xl font-bold text-slate-900 dark:text-white tracking-tight",
								children: "Respons Formulir"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm text-slate-500 dark:text-slate-400 font-medium mt-1",
								children: [
									totalAllResponses.toLocaleString("id-ID"),
									" total respons dari ",
									forms.length,
									" formulir aktif."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 29
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 215,
								columnNumber: 25
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 21
						}, this),
						loadingForms ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-20 text-center text-slate-400 dark:text-slate-500 text-sm font-medium",
							children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin mx-auto text-[#00897B] dark:text-teal-400 mb-2" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 29
							}, this), "Memuat data respons..."]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 25
						}, this) : forms.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-slate-900 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800 p-12 text-center space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-14 h-14 bg-teal-50 dark:bg-teal-950/60 rounded-2xl flex items-center justify-center mx-auto text-[#00897B] dark:text-teal-400 shadow-xs",
									children: /* @__PURE__ */ _jsxDEV(FileText, { size: 28 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 231,
										columnNumber: 33
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-base font-bold text-slate-900 dark:text-white",
										children: "Belum Ada Formulir"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 234,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto",
										children: "Buat formulir pertama Anda dan bagikan ke audiens untuk mulai menerima respons."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 235,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => navigate("/create-form"),
									className: "px-5 py-2.5 bg-[#00897B] hover:bg-[#00796B] text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer inline-flex items-center gap-1.5",
									children: "Buat Formulir Sekarang"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 25
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3 flex-1 min-w-0",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400 shrink-0",
										children: /* @__PURE__ */ _jsxDEV(BarChart3, { size: 20 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 253,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 252,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 min-w-0",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-0.5",
											children: "Pilih Formulir Aktif"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 256,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: selectedFormId || "",
											onChange: (e) => setSelectedFormId(parseInt(e.target.value)),
											className: "w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-[#00897B] cursor-pointer",
											children: filteredForms.map((f) => /* @__PURE__ */ _jsxDEV("option", {
												value: f.id,
												children: [
													f.title || "Formulir Tanpa Judul",
													" (",
													f.responseCount ?? 0,
													" respons)"
												]
											}, f.id, true, {
												fileName: _jsxFileName,
												lineNumber: 263,
												columnNumber: 49
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 257,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 255,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 251,
									columnNumber: 33
								}, this), selectedFormId && /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 shrink-0",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => handleExport(selectedFormId),
										disabled: exporting,
										className: "px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all border border-slate-200 dark:border-slate-700 disabled:opacity-60 cursor-pointer",
										children: [exporting ? /* @__PURE__ */ _jsxDEV(Loader2, {
											size: 14,
											className: "animate-spin"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 279,
											columnNumber: 58
										}, this) : /* @__PURE__ */ _jsxDEV(Download, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 279,
											columnNumber: 107
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: exporting ? "Mengekspor..." : "Unduh CSV" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 280,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => navigate(`/forms/${selectedFormId}/edit`),
										className: "px-3.5 py-2 bg-[#00897B] hover:bg-[#00796B] text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer",
										children: "Edit Formulir"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 282,
										columnNumber: 41
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 272,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 250,
								columnNumber: 29
							}, this), loadingDetail ? /* @__PURE__ */ _jsxDEV("div", {
								className: "py-20 text-center text-slate-400 dark:text-slate-500 text-sm font-medium",
								children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin mx-auto text-[#00897B] dark:text-teal-400 mb-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 37
								}, this), "Memuat rincian respons formulir..."]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 33
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-6",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-4 lg:col-span-1",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between",
												children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1",
													children: "Total Respons Formulir Ini"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 308,
													columnNumber: 53
												}, this), /* @__PURE__ */ _jsxDEV("h3", {
													className: "text-2xl font-extrabold text-slate-900 dark:text-white",
													children: analyticsData?.totalResponses ?? respondents.length
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 309,
													columnNumber: 53
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 307,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400",
													children: /* @__PURE__ */ _jsxDEV(Users, { size: 20 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 314,
														columnNumber: 53
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 313,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 306,
												columnNumber: 45
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between",
												children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1",
													children: "Rata-rata Skor"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 320,
													columnNumber: 53
												}, this), /* @__PURE__ */ _jsxDEV("h3", {
													className: "text-2xl font-extrabold text-slate-900 dark:text-white",
													children: analyticsData?.averageScore != null ? `${analyticsData.averageScore}%` : "N/A"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 321,
													columnNumber: 53
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 319,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400",
													children: /* @__PURE__ */ _jsxDEV(Award, { size: 20 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 326,
														columnNumber: 53
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 325,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 318,
												columnNumber: 45
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between",
												children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1",
													children: "Total Soal"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 332,
													columnNumber: 53
												}, this), /* @__PURE__ */ _jsxDEV("h3", {
													className: "text-2xl font-extrabold text-slate-900 dark:text-white",
													children: analyticsData?.totalQuestions ?? 0
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 333,
													columnNumber: 53
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 331,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400",
													children: /* @__PURE__ */ _jsxDEV(FileText, { size: 20 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 338,
														columnNumber: 53
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 337,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 330,
												columnNumber: 45
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 305,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm lg:col-span-2 flex flex-col justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between mb-4",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2",
												children: [/* @__PURE__ */ _jsxDEV(TrendingUp, {
													size: 16,
													className: "text-[#00897B] dark:text-teal-400"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 348,
													columnNumber: 57
												}, this), "Diagram Tren Respons"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 347,
												columnNumber: 53
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-400 dark:text-slate-500 mt-0.5",
												children: "Perkembangan jumlah respons berdasarkan tanggal/waktu submit aktual"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 351,
												columnNumber: 53
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 346,
												columnNumber: 49
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[11px] font-bold px-2.5 py-1 rounded-full bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400",
												children: [trendData.length, " Titik Data"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 355,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 345,
											columnNumber: 45
										}, this), trendData.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
											className: "h-48 flex flex-col items-center justify-center text-center space-y-2 border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-xl p-4",
											children: [/* @__PURE__ */ _jsxDEV(Calendar, {
												size: 28,
												className: "text-slate-300 dark:text-slate-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 362,
												columnNumber: 53
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-400 dark:text-slate-500 font-medium",
												children: "Belum ada data respons untuk menampilkan diagram tren."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 363,
												columnNumber: 53
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 361,
											columnNumber: 49
										}, this) : /* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-3 pt-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "h-48 flex items-end gap-2 sm:gap-4 pt-6 pb-2 px-2 border-b border-slate-100 dark:border-slate-800",
												children: trendData.map((item, idx) => {
													const heightPercent = Math.max(item.count / maxCount * 100, 15);
													return /* @__PURE__ */ _jsxDEV("div", {
														className: "flex-1 flex flex-col items-center gap-2 h-full justify-end group",
														children: [
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-[10px] font-extrabold text-[#00897B] dark:text-teal-400 opacity-0 group-hover:opacity-100 transition-opacity",
																children: item.count
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 374,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("div", {
																className: "w-full bg-linear-to-t from-[#00897B] to-[#4DB6AC] dark:from-teal-600 dark:to-teal-400 rounded-t-lg transition-all duration-500 group-hover:brightness-110 shadow-xs",
																style: { height: `${heightPercent}%` }
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 377,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-[10px] font-semibold text-slate-400 dark:text-slate-500 truncate w-full text-center",
																children: item.date
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 381,
																columnNumber: 69
															}, this)
														]
													}, idx, true, {
														fileName: _jsxFileName,
														lineNumber: 373,
														columnNumber: 65
													}, this);
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 369,
												columnNumber: 53
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[11px] text-slate-400 dark:text-slate-500 text-center font-medium",
												children: "Sumbu X: Tanggal Pengiriman · Sumbu Y: Jumlah Respons"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 388,
												columnNumber: 53
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 368,
											columnNumber: 49
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 344,
										columnNumber: 41
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 302,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-5 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-base font-bold text-slate-900 dark:text-white",
											children: "Rincian Respons Responden"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 401,
											columnNumber: 49
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400 dark:text-slate-500 mt-0.5",
											children: "Klik Review Jawaban untuk melihat jawaban lengkap setiap responden."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 402,
											columnNumber: 49
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 400,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-slate-500 dark:text-slate-400 self-start sm:self-auto",
											children: [
												"Total: ",
												filteredRespondents.length,
												" Responden"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 406,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 399,
										columnNumber: 41
									}, this), filteredRespondents.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
										className: "py-16 text-center text-slate-400 dark:text-slate-500 text-sm font-medium",
										children: searchQuery ? `Tidak ada responden yang cocok dengan "${searchQuery}".` : "Belum ada respons yang diterima untuk formulir ini."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 412,
										columnNumber: 45
									}, this) : /* @__PURE__ */ _jsxDEV("div", {
										className: "overflow-x-auto w-full",
										children: /* @__PURE__ */ _jsxDEV("table", {
											className: "w-full text-sm text-left",
											children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
												className: "bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800",
												children: [
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3.5 px-4",
														children: "#"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 420,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3.5 px-4",
														children: "Responden"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 421,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3.5 px-4",
														children: "Soal Dijawab"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 422,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3.5 px-4",
														children: "Jumlah Benar"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 423,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3.5 px-4",
														children: "Jumlah Salah"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 424,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3.5 px-4",
														children: "Skor"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 425,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3.5 px-4",
														children: "Waktu Submit"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 426,
														columnNumber: 61
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3.5 px-4 text-right",
														children: "Aksi"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 427,
														columnNumber: 61
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 419,
												columnNumber: 57
											}, this) }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 418,
												columnNumber: 53
											}, this), /* @__PURE__ */ _jsxDEV("tbody", {
												className: "divide-y divide-slate-100 dark:divide-slate-800",
												children: filteredRespondents.map((r, idx) => {
													const scorable = r.scorableQuestions ?? 0;
													const correct = r.correctCount ?? 0;
													const wrong = r.wrongCount != null ? r.wrongCount : Math.max(scorable - correct, 0);
													return /* @__PURE__ */ _jsxDEV("tr", {
														className: "hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors",
														children: [
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-slate-400 font-medium",
																children: idx + 1
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 438,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: [/* @__PURE__ */ _jsxDEV("div", {
																	className: "font-bold text-slate-900 dark:text-white",
																	children: r.respondentName || "Anonim"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 440,
																	columnNumber: 73
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "text-[10px] text-slate-400 dark:text-slate-500",
																	children: ["Respons #", r.responseId]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 443,
																	columnNumber: 73
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 439,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-slate-600 dark:text-slate-300 font-medium",
																children: [
																	r.answeredCount ?? 0,
																	"/",
																	r.totalQuestions ?? 0
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 447,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-emerald-600 dark:text-emerald-400 font-bold",
																children: correct
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 450,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-red-500 dark:text-red-400 font-bold",
																children: wrong
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 453,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: r.score != null ? /* @__PURE__ */ _jsxDEV("span", {
																	className: `text-xs font-bold px-2.5 py-0.5 rounded-full ${r.score >= 70 ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800" : "bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400 border border-red-200 dark:border-red-800"}`,
																	children: [r.score, "%"]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 458,
																	columnNumber: 77
																}, this) : /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-xs text-slate-400 dark:text-slate-500 font-medium",
																	children: "N/A"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 466,
																	columnNumber: 77
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 456,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-slate-500 dark:text-slate-400 text-xs",
																children: formatDate(r.submittedAt)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 469,
																columnNumber: 69
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-right",
																children: /* @__PURE__ */ _jsxDEV("button", {
																	onClick: () => setSelectedRespondent(r),
																	className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#00897B] hover:bg-[#00796B] text-white text-xs font-bold shadow-xs transition-all cursor-pointer",
																	children: [/* @__PURE__ */ _jsxDEV(Eye, { size: 13 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 477,
																		columnNumber: 77
																	}, this), " Review Jawaban"]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 473,
																	columnNumber: 73
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 472,
																columnNumber: 69
															}, this)
														]
													}, r.responseId || idx, true, {
														fileName: _jsxFileName,
														lineNumber: 437,
														columnNumber: 65
													}, this);
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 430,
												columnNumber: 53
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 417,
											columnNumber: 49
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 416,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 398,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 299,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 206,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 205,
				columnNumber: 13
			}, this),
			selectedRespondent && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-black/50 backdrop-blur-xs",
					onClick: () => setSelectedRespondent(null)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 501,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 w-full max-w-3xl max-h-[90vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 animate-in fade-in zoom-in-95 duration-200",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50/50 dark:bg-slate-800/50",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "font-bold text-slate-900 dark:text-white text-base",
								children: "Review Jawaban Responden"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 511,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 dark:text-slate-500 mt-0.5",
								children: [
									"Responden: ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-700 dark:text-slate-300",
										children: selectedRespondent.respondentName || "Anonim"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 515,
										columnNumber: 48
									}, this),
									" (Respons #",
									selectedRespondent.responseId,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 514,
								columnNumber: 33
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 510,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setSelectedRespondent(null),
								className: "p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 522,
									columnNumber: 33
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 518,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 509,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-3.5 bg-slate-100/60 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 flex flex-wrap items-center gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-1.5 shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500",
										children: "Skor"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 529,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-base font-extrabold text-slate-900 dark:text-white",
										children: selectedRespondent.score != null ? `${selectedRespondent.score}%` : "N/A"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 530,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 528,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-1.5 shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500",
										children: "Dijawab"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 535,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-base font-extrabold text-slate-900 dark:text-white",
										children: [
											selectedRespondent.answeredCount,
											"/",
											selectedRespondent.totalQuestions
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 536,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 534,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-1.5 shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500",
										children: "Benar"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 541,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-base font-extrabold text-emerald-600 dark:text-emerald-400",
										children: selectedRespondent.correctCount ?? 0
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 542,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 540,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-1.5 shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500",
										children: "Waktu Submit"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 547,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs font-bold text-slate-700 dark:text-slate-300 mt-1",
										children: formatDate(selectedRespondent.submittedAt)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 548,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 546,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 527,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 overflow-y-auto p-6 space-y-4",
							children: [(selectedRespondent.answers || []).map((answer, index) => {
								const status = getAnswerStatus(answer);
								return /* @__PURE__ */ _jsxDEV("div", {
									className: "border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 bg-white dark:bg-slate-900 flex items-start gap-3 justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-3 flex-1 min-w-0",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "shrink-0 w-7 h-7 flex items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300",
												children: index + 1
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 566,
												columnNumber: 49
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex-1 min-w-0",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "text-sm font-semibold text-slate-900 dark:text-white leading-relaxed",
													children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: answer.question }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 571,
														columnNumber: 57
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 570,
													columnNumber: 53
												}, this), answer.questionImage && /* @__PURE__ */ _jsxDEV("div", {
													className: "my-2 max-w-xs relative group/img overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700 p-1 bg-white dark:bg-slate-900 shadow-xs",
													children: [/* @__PURE__ */ _jsxDEV("img", {
														src: assetUrl(answer.questionImage),
														alt: "Gambar Soal",
														className: "max-h-40 w-auto rounded-lg object-contain mx-auto cursor-zoom-in",
														onClick: () => setLightboxImage({
															src: assetUrl(answer.questionImage),
															alt: "Gambar Soal"
														})
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 575,
														columnNumber: 61
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => setLightboxImage({
															src: assetUrl(answer.questionImage),
															alt: "Gambar Soal"
														}),
														className: "absolute bottom-2 right-2 p-1.5 bg-slate-900/80 hover:bg-slate-900 text-white rounded-lg text-xs font-bold flex items-center gap-1 opacity-0 group-hover/img:opacity-100 transition-opacity cursor-pointer",
														children: [/* @__PURE__ */ _jsxDEV(Maximize2, { size: 11 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 586,
															columnNumber: 65
														}, this), " Perbesar"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 581,
														columnNumber: 61
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 574,
													columnNumber: 57
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 569,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 565,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: `shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-bold ${status.className}`,
											children: [status.icon, /* @__PURE__ */ _jsxDEV("span", { children: status.label }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 594,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 592,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 564,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "border-t border-slate-100 dark:border-slate-800 p-4 space-y-3 bg-slate-50 dark:bg-slate-800/50 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500 mb-1",
											children: "Jawaban Responden:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 600,
											columnNumber: 49
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: `rounded-xl border p-3 font-medium ${answer.isCorrect === true ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200" : answer.isCorrect === false ? "bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800 text-red-900 dark:text-red-200" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"}`,
											children: answer.answerText || answer.answerValue || answer.optionText ? /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: answer.answerText || answer.answerValue || answer.optionText }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 611,
												columnNumber: 57
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-400 dark:text-slate-500 italic",
												children: "Tidak ada jawaban"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 613,
												columnNumber: 57
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 603,
											columnNumber: 49
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 599,
											columnNumber: 45
										}, this), answer.correctAnswer && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500 mb-1",
											children: "Kunci / Jawaban Benar:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 620,
											columnNumber: 53
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 p-3 text-emerald-900 dark:text-emerald-200 font-bold",
											children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: answer.correctAnswer }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 624,
												columnNumber: 57
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 623,
											columnNumber: 53
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 619,
											columnNumber: 49
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 598,
										columnNumber: 41
									}, this)]
								}, answer.questionId || index, true, {
									fileName: _jsxFileName,
									lineNumber: 560,
									columnNumber: 37
								}, this);
							}), (!selectedRespondent.answers || selectedRespondent.answers.length === 0) && /* @__PURE__ */ _jsxDEV("div", {
								className: "text-center py-12 text-sm text-slate-400 dark:text-slate-500",
								children: "Rincian jawaban tidak tersedia."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 634,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 555,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between shrink-0",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: goPrevious,
									disabled: currentIndex <= 0,
									className: "flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(ChevronLeft, { size: 15 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 647,
										columnNumber: 33
									}, this), " Sebelumnya"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 642,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-400 dark:text-slate-500 font-semibold",
									children: [
										currentIndex + 1,
										" dari ",
										respondents.length
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 650,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: goNext,
									disabled: currentIndex === respondents.length - 1,
									className: "flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer",
									children: ["Selanjutnya ", /* @__PURE__ */ _jsxDEV(ChevronRight, { size: 15 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 659,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 654,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 641,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 506,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 500,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV(ImageLightboxModal, {
				isOpen: !!lightboxImage,
				src: lightboxImage?.src,
				alt: lightboxImage?.alt,
				onClose: () => setLightboxImage(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 668,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 202,
		columnNumber: 9
	}, this);
}
_s(ResponsesPage, "xviTl2xm32AHEMJGGnxqDg06Ljw=", false, function() {
	return [useNavigate];
});
_c = ResponsesPage;
var _c;
$RefreshReg$(_c, "ResponsesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/dashboard/userDashboard/responsesPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/responsesPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/responsesPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/responsesPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsZUFBZTtBQUM3QyxTQUFTLG1CQUFtQjtBQUM1QixTQUNJLFlBQVksVUFBVSxVQUFVLGNBQ2hDLE9BQU8sT0FBTyxLQUFLLEdBQUcsY0FBYyxTQUFTLGFBQzdDLGFBQWEsU0FBUyxXQUFXLFdBQVcsVUFBVSxpQkFDbkQ7QUFDUCxPQUFPLGFBQWE7QUFDcEIsT0FBTyxZQUFZO0FBQ25CLFNBQ0ksWUFBWSxrQkFBa0IsYUFBYSxjQUMzQyxxQkFBcUIsZ0JBQ2xCO0FBQ1AsT0FBTyx5QkFBeUI7QUFDaEMsT0FBTyx3QkFBd0I7Ozs7QUFFL0IsZUFBZSxTQUFTLGdCQUFnQjs7Q0FDcEMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLENBQUMsQ0FBQztDQUNyQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxJQUFJO0NBQ3JELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsSUFBSTtDQUN6RCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLElBQUk7Q0FDN0QsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsSUFBSTtDQUN2RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLO0NBQ3hELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxJQUFJOztDQUd2RCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLElBQUk7Q0FFakUsZ0JBQWdCO0VBQ1osTUFBTSxhQUFhLFlBQVk7R0FDM0IsSUFBSTtJQUNBLGdCQUFnQixJQUFJO0lBQ3BCLE1BQU0sU0FBUyxNQUFNLFdBQVc7SUFDaEMsSUFBSSxPQUFPLFdBQVcsS0FBSztLQUN2QixhQUFhO0tBQ2IsU0FBUyxRQUFRO0tBQ2pCO0lBQ0o7SUFDQSxJQUFJLE9BQU8sTUFBTSxNQUFNLFFBQVEsT0FBTyxJQUFJLEdBQUc7S0FDekMsU0FBUyxPQUFPLElBQUk7O0tBRXBCLElBQUksT0FBTyxLQUFLLFNBQVMsR0FBRztNQUN4QixrQkFBa0IsT0FBTyxLQUFLLEVBQUUsQ0FBQyxFQUFFO0tBQ3ZDO0lBQ0o7R0FDSixTQUFTLEtBQUs7SUFDVixRQUFRLE1BQU0sNENBQTRDLEdBQUc7R0FDakUsVUFBVTtJQUNOLGdCQUFnQixLQUFLO0dBQ3pCO0VBQ0o7RUFDQSxXQUFXO0NBQ2YsR0FBRyxDQUFDLFFBQVEsQ0FBQzs7Q0FHYixnQkFBZ0I7RUFDWixJQUFJLENBQUMsZ0JBQWdCO0VBRXJCLE1BQU0sa0JBQWtCLFlBQVk7R0FDaEMsaUJBQWlCLElBQUk7R0FDckIsSUFBSTtJQUNBLE1BQU0sQ0FBQyxTQUFTLGdCQUFnQixNQUFNLFFBQVEsSUFBSSxDQUM5QyxZQUFZLGNBQWMsR0FDMUIsaUJBQWlCLGdCQUFnQixHQUFHLEdBQUcsQ0FDM0MsQ0FBQztJQUVELElBQUksUUFBUSxJQUFJLG9CQUFvQixRQUFRLElBQUk7SUFDaEQsSUFBSSxhQUFhLE1BQU0sYUFBYSxNQUFNO0tBQ3RDLGlCQUFpQixhQUFhLElBQUk7SUFDdEMsT0FBTztLQUNILGlCQUFpQixJQUFJO0lBQ3pCO0dBQ0osU0FBUyxLQUFLO0lBQ1YsUUFBUSxNQUFNLHdDQUF3QyxHQUFHO0dBQzdELFVBQVU7SUFDTixpQkFBaUIsS0FBSztHQUMxQjtFQUNKO0VBRUEsZ0JBQWdCO0NBQ3BCLEdBQUcsQ0FBQyxjQUFjLENBQUM7O0NBR25CLE1BQU0sZ0JBQWdCLGNBQWM7RUFDaEMsSUFBSSxDQUFDLFlBQVksS0FBSyxHQUFHLE9BQU87RUFDaEMsTUFBTSxJQUFJLFlBQVksWUFBWTtFQUNsQyxPQUFPLE1BQU0sUUFBTyxNQUNmLEVBQUUsU0FBUyxFQUFFLE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQzNDLEVBQUUsZUFBZSxFQUFFLFlBQVksWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQzNEO0NBQ0wsR0FBRyxDQUFDLE9BQU8sV0FBVyxDQUFDOztDQUd2QixNQUFNLGNBQWMsZUFBZSxlQUFlLENBQUM7O0NBR25ELE1BQU0sc0JBQXNCLGNBQWM7RUFDdEMsSUFBSSxDQUFDLFlBQVksS0FBSyxHQUFHLE9BQU87RUFDaEMsTUFBTSxJQUFJLFlBQVksWUFBWTtFQUNsQyxPQUFPLFlBQVksUUFBTyxNQUNyQixFQUFFLGtCQUFrQixFQUFFLGVBQWUsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQzdELE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FDbkM7Q0FDTCxHQUFHLENBQUMsYUFBYSxXQUFXLENBQUM7Q0FFN0IsTUFBTSxZQUFZLGNBQWM7RUFDNUIsSUFBSSxDQUFDLGVBQWUsWUFBWSxXQUFXLEdBQUcsT0FBTyxDQUFDO0VBRXRELE1BQU0sVUFBVSxDQUFDO0VBQ2pCLFlBQVksU0FBUSxNQUFLO0dBQ3JCLElBQUksQ0FBQyxFQUFFLGFBQWE7R0FDcEIsTUFBTSxJQUFJLElBQUksS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLG1CQUFtQixTQUFTO0lBQzFELEtBQUs7SUFDTCxPQUFPO0dBQ1gsQ0FBQztHQUNELFFBQVEsTUFBTSxRQUFRLE1BQU0sS0FBSztFQUNyQyxDQUFDO0VBRUQsT0FBTyxPQUFPLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sWUFBWTtHQUNuRDtHQUNBO0VBQ0osRUFBRTtDQUNOLEdBQUcsQ0FBQyxXQUFXLENBQUM7Q0FFaEIsTUFBTSxXQUFXLGNBQWM7RUFDM0IsSUFBSSxVQUFVLFdBQVcsR0FBRyxPQUFPO0VBQ25DLE9BQU8sS0FBSyxJQUFJLEdBQUcsVUFBVSxLQUFJLE1BQUssRUFBRSxLQUFLLEdBQUcsQ0FBQztDQUNyRCxHQUFHLENBQUMsU0FBUyxDQUFDO0NBRWQsTUFBTSxjQUFjLFlBQVk7RUFDNUIsSUFBSSxDQUFDLFNBQVMsT0FBTztFQUNyQixPQUFPLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxtQkFBbUIsU0FBUztHQUNqRCxLQUFLO0dBQ0wsT0FBTztHQUNQLE1BQU07R0FDTixNQUFNO0dBQ04sUUFBUTtFQUNaLENBQUM7Q0FDTDtDQUVBLE1BQU0sb0JBQW9CLE1BQU0sUUFBUSxLQUFLLE1BQU0sT0FBTyxFQUFFLGlCQUFpQixJQUFJLENBQUM7Q0FFbEYsTUFBTSxlQUFlLE9BQU8sV0FBVztFQUNuQyxJQUFJLENBQUMsVUFBVSxXQUFXO0VBQzFCLGFBQWEsSUFBSTtFQUNqQixJQUFJO0dBQ0EsTUFBTSxNQUFNLE1BQU0sb0JBQW9CLE1BQU07R0FDNUMsSUFBSSxDQUFDLElBQUksSUFBSTtJQUNULE1BQU0sSUFBSSxXQUFXLG9DQUFvQztHQUM3RDtFQUNKLFNBQVMsS0FBSztHQUNWLFFBQVEsTUFBTSx3QkFBd0IsR0FBRztHQUN6QyxNQUFNLHdDQUF3QztFQUNsRCxVQUFVO0dBQ04sYUFBYSxLQUFLO0VBQ3RCO0NBQ0o7O0NBR0EsTUFBTSxlQUFlLHFCQUNmLFlBQVksV0FBVSxNQUFLLEVBQUUsZUFBZSxtQkFBbUIsVUFBVSxJQUN6RSxDQUFDO0NBRVAsTUFBTSxtQkFBbUI7RUFDckIsSUFBSSxlQUFlLEdBQUc7R0FDbEIsc0JBQXNCLFlBQVksZUFBZSxFQUFFO0VBQ3ZEO0NBQ0o7Q0FFQSxNQUFNLGVBQWU7RUFDakIsSUFBSSxlQUFlLFlBQVksU0FBUyxHQUFHO0dBQ3ZDLHNCQUFzQixZQUFZLGVBQWUsRUFBRTtFQUN2RDtDQUNKO0NBRUEsTUFBTSxtQkFBbUIsV0FBVztFQUNoQyxJQUFJLE9BQU8sY0FBYyxNQUFNO0dBQzNCLE9BQU87SUFDSCxPQUFPO0lBQ1AsTUFBTSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OztJQUMvQixXQUFXO0dBQ2Y7RUFDSjtFQUNBLElBQUksT0FBTyxjQUFjLE9BQU87R0FDNUIsT0FBTztJQUNILE9BQU87SUFDUCxNQUFNLHdCQUFDLFNBQUQsRUFBUyxNQUFNLEdBQUs7Ozs7O0lBQzFCLFdBQVc7R0FDZjtFQUNKO0VBQ0EsT0FBTztHQUNILE9BQU87R0FDUCxNQUFNLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O0dBQzlCLFdBQVc7RUFDZjtDQUNKO0NBRUEsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0ksd0JBQUMsU0FBRCxDQUFVOzs7OztHQUVWLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1gsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEI7TUFFSSx3QkFBQyxRQUFEO09BQ2lCO09BQ2IsZ0JBQWdCO09BQ2hCLGFBQVk7TUFDZjs7Ozs7TUFFRCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW1FO09BQW9COzs7O2lCQUNyRyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUNLLGtCQUFrQixlQUFlLE9BQU87U0FBRTtTQUFxQixNQUFNO1NBQU87UUFDOUU7Ozs7O2VBQ0Y7Ozs7O01BQ0o7Ozs7O01BRUosZUFDRyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHNFQUF1RTs7OztpQkFBQyx3QkFFMUY7Ozs7O2lCQUNMLE1BQU0sV0FBVyxJQUNqQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNYLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O1FBQ3BCOzs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXFEO1NBQXNCOzs7O21CQUN6Rix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBOEQ7U0FFeEU7Ozs7aUJBQ0Y7Ozs7OztRQUNMLHdCQUFDLFVBQUQ7U0FDSSxlQUFlLFNBQVMsY0FBYztTQUN0QyxXQUFVO21CQUNiO1FBRU87Ozs7O09BQ1A7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBR0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNYLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O1NBQ3JCOzs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWlHO1VBQTJCOzs7O29CQUM3SSx3QkFBQyxVQUFEO1dBQ0ksT0FBTyxrQkFBa0I7V0FDekIsV0FBVSxNQUFLLGtCQUFrQixTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUM7V0FDekQsV0FBVTtxQkFFVCxjQUFjLEtBQUksTUFDZix3QkFBQyxVQUFEO1lBQW1CLE9BQU8sRUFBRTtzQkFBNUI7YUFDSyxFQUFFLFNBQVM7YUFBdUI7YUFBRyxFQUFFLGlCQUFpQjthQUFFO1lBQ3ZEO2NBRkssRUFBRTs7OztrQkFFUCxDQUNYO1VBQ0c7Ozs7a0JBQ1A7Ozs7O2lCQUNKOzs7OztrQkFFSixrQkFDRyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxhQUFhLGNBQWM7VUFDMUMsVUFBVTtVQUNWLFdBQVU7b0JBSmQsQ0FNSyxZQUFZLHdCQUFDLFNBQUQ7V0FBUyxNQUFNO1dBQUksV0FBVTtVQUFnQjs7OztxQkFBSSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7O29CQUNuRix3QkFBQyxRQUFELFlBQU8sWUFBWSxrQkFBa0IsWUFBa0I7Ozs7a0JBQ25EOzs7OzttQkFDUix3QkFBQyxVQUFEO1VBQ0ksTUFBSztVQUNMLGVBQWUsU0FBUyxVQUFVLGVBQWUsTUFBTTtVQUN2RCxXQUFVO29CQUNiO1NBRU87Ozs7aUJBQ1A7Ozs7O2dCQUVSOzs7OztpQkFFSixnQkFDRyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHNFQUF1RTs7OztrQkFBQyxvQ0FFMUY7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBR0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FHSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNJLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUF5RjtZQUE2Qjs7OztzQkFDbkksd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1QsZUFBZSxrQkFBa0IsWUFBWTtZQUM5Qzs7OztvQkFDSDs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFDWCx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztZQUNqQjs7OztvQkFDSjs7Ozs7O1dBRUwsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQXlGO1lBQWlCOzs7O3NCQUN2SCx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDVCxlQUFlLGdCQUFnQixPQUFPLEdBQUcsY0FBYyxhQUFhLEtBQUs7WUFDMUU7Ozs7b0JBQ0g7Ozs7c0JBQ0wsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQ1gsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7Ozs7WUFDakI7Ozs7b0JBQ0o7Ozs7OztXQUVMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUF5RjtZQUFhOzs7O3NCQUNuSCx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDVCxlQUFlLGtCQUFrQjtZQUNsQzs7OztvQkFDSDs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFDWCx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztZQUNwQjs7OztvQkFDSjs7Ozs7O1VBQ0o7Ozs7O21CQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FDSSx3QkFBQyxZQUFEO2FBQVksTUFBTTthQUFJLFdBQVU7WUFBcUM7Ozs7c0JBQUMsc0JBRXRFOzs7OztxQkFDSix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBb0Q7V0FFOUQ7Ozs7bUJBQ0Y7Ozs7cUJBQ0wsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCLENBQ0ssVUFBVSxRQUFPLGFBQ2hCOzs7OzttQkFDTDs7Ozs7b0JBRUosVUFBVSxXQUFXLElBQ2xCLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsVUFBRDtZQUFVLE1BQU07WUFBSSxXQUFVO1dBQXNDOzs7O3FCQUNwRSx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBeUQ7V0FFbkU7Ozs7bUJBQ0Y7Ozs7O3FCQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ1YsVUFBVSxLQUFLLE1BQU0sUUFBUTthQUMxQixNQUFNLGdCQUFnQixLQUFLLElBQUssS0FBSyxRQUFRLFdBQVksS0FBSyxFQUFFO2FBQ2hFLE9BQ0ksd0JBQUMsT0FBRDtjQUFlLFdBQVU7d0JBQXpCO2VBQ0ksd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUNYLEtBQUs7ZUFDSjs7Ozs7ZUFDTix3QkFBQyxPQUFEO2dCQUNJLFdBQVU7Z0JBQ1YsT0FBTyxFQUFFLFFBQVEsR0FBRyxjQUFjLEdBQUc7ZUFDeEM7Ozs7O2VBQ0Qsd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUNYLEtBQUs7ZUFDSjs7Ozs7Y0FDTDtnQkFYSzs7OztvQkFXTDtZQUViLENBQUM7V0FDQTs7OztxQkFDTCx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBeUU7V0FFbkY7Ozs7bUJBQ0Y7Ozs7O2tCQUVSOzs7OztpQkFFSjs7Ozs7a0JBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBcUQ7VUFBNkI7Ozs7b0JBQ2hHLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFvRDtVQUU5RDs7OztrQkFDRjs7OztvQkFDTCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFBK0Y7WUFDbkYsb0JBQW9CO1lBQU87V0FDakM7Ozs7O2tCQUNMOzs7OzttQkFFSixvQkFBb0IsV0FBVyxJQUM1Qix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDVixjQUFjLDBDQUEwQyxZQUFZLE1BQU07U0FDMUU7Ozs7b0JBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1gsd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0ksd0JBQUMsU0FBRCxZQUNJLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkO2FBQ0ksd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQWM7YUFBSzs7Ozs7YUFDakMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQWM7YUFBYTs7Ozs7YUFDekMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQWM7YUFBZ0I7Ozs7O2FBQzVDLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUFjO2FBQWdCOzs7OzthQUM1Qyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBYzthQUFnQjs7Ozs7YUFDNUMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQWM7YUFBUTs7Ozs7YUFDcEMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQWM7YUFBZ0I7Ozs7O2FBQzVDLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUF5QjthQUFROzs7OztZQUMvQzs7Ozs7b0JBQ0Q7Ozs7cUJBQ1Asd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQ1osb0JBQW9CLEtBQUssR0FBRyxRQUFRO2FBQ2pDLE1BQU0sV0FBVyxFQUFFLHFCQUFxQjthQUN4QyxNQUFNLFVBQVUsRUFBRSxnQkFBZ0I7YUFDbEMsTUFBTSxRQUFRLEVBQUUsY0FBYyxPQUFPLEVBQUUsYUFBYSxLQUFLLElBQUksV0FBVyxTQUFTLENBQUM7YUFFbEYsT0FDSSx3QkFBQyxNQUFEO2NBQThCLFdBQVU7d0JBQXhDO2VBQ0ksd0JBQUMsTUFBRDtnQkFBSSxXQUFVOzBCQUEwQyxNQUFNO2VBQU07Ozs7O2VBQ3BFLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFBZCxDQUNJLHdCQUFDLE9BQUQ7aUJBQUssV0FBVTsyQkFDVixFQUFFLGtCQUFrQjtnQkFDcEI7Ozs7MEJBQ0wsd0JBQUMsT0FBRDtpQkFBSyxXQUFVOzJCQUFmLENBQWdFLGFBQ2xELEVBQUUsVUFDWDs7Ozs7d0JBQ0w7Ozs7OztlQUNKLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFBZDtpQkFDSyxFQUFFLGlCQUFpQjtpQkFBRTtpQkFBRSxFQUFFLGtCQUFrQjtnQkFDNUM7Ozs7OztlQUNKLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFDVDtlQUNEOzs7OztlQUNKLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFDVDtlQUNEOzs7OztlQUNKLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFDVCxFQUFFLFNBQVMsT0FDUix3QkFBQyxRQUFEO2lCQUFNLFdBQVcsZ0RBQ2IsRUFBRSxTQUFTLEtBQ0wsa0lBQ0E7MkJBSFYsQ0FLSyxFQUFFLE9BQU0sR0FDUDs7Ozs7MkJBRU4sd0JBQUMsUUFBRDtpQkFBTSxXQUFVOzJCQUF5RDtnQkFBUzs7Ozs7ZUFFdEY7Ozs7O2VBQ0osd0JBQUMsTUFBRDtnQkFBSSxXQUFVOzBCQUNULFdBQVcsRUFBRSxXQUFXO2VBQ3pCOzs7OztlQUNKLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFDVix3QkFBQyxVQUFEO2lCQUNJLGVBQWUsc0JBQXNCLENBQUM7aUJBQ3RDLFdBQVU7MkJBRmQsQ0FJSSx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OzJCQUFDLGlCQUNiOzs7Ozs7ZUFDUjs7Ozs7Y0FDSjtnQkEzQ0ssRUFBRSxjQUFjOzs7O29CQTJDckI7WUFFWixDQUFDO1dBQ0U7Ozs7bUJBQ0o7Ozs7OztTQUNOOzs7O2lCQUVSOzs7OztnQkFFSjs7Ozs7ZUFHUjs7Ozs7O0tBR1A7Ozs7OztHQUNMOzs7OztHQUdKLHNCQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFEO0tBQ0ksV0FBVTtLQUNWLGVBQWUsc0JBQXNCLElBQUk7SUFDNUM7Ozs7Y0FFRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BR0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXFEO09BRS9EOzs7O2lCQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQWlFO1NBQ2xELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnRCxtQkFBbUIsa0JBQWtCO1NBQWU7Ozs7O1NBQUM7U0FBWSxtQkFBbUI7U0FBVztRQUMzSzs7Ozs7ZUFDRjs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0ksZUFBZSxzQkFBc0IsSUFBSTtRQUN6QyxXQUFVO2tCQUVWLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O09BQ1Y7Ozs7ZUFDUDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFxRTtTQUFPOzs7O21CQUN6Rix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDUixtQkFBbUIsU0FBUyxPQUFPLEdBQUcsbUJBQW1CLE1BQU0sS0FBSztTQUN0RTs7OztpQkFDRjs7Ozs7O1FBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBcUU7U0FBVTs7OzttQkFDNUYsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWI7V0FDSyxtQkFBbUI7V0FBYztXQUFFLG1CQUFtQjtVQUN4RDs7Ozs7aUJBQ0Y7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXFFO1NBQVE7Ozs7bUJBQzFGLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNSLG1CQUFtQixnQkFBZ0I7U0FDckM7Ozs7aUJBQ0Y7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXFFO1NBQWU7Ozs7bUJBQ2pHLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNSLFdBQVcsbUJBQW1CLFdBQVc7U0FDM0M7Ozs7aUJBQ0Y7Ozs7OztPQUNKOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixFQUNNLG1CQUFtQixXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUssUUFBUSxVQUFVO1FBQ3ZELE1BQU0sU0FBUyxnQkFBZ0IsTUFBTTtRQUVyQyxPQUNJLHdCQUFDLE9BQUQ7U0FFSSxXQUFVO21CQUZkLENBSUksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUNYLFFBQVE7V0FDUDs7OztxQkFDTix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUNYLHdCQUFDLHFCQUFELEVBQXFCLFNBQVMsT0FBTyxTQUFXOzs7OztZQUMvQzs7OztzQkFDSixPQUFPLGlCQUNKLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsT0FBRDtjQUNJLEtBQUssU0FBUyxPQUFPLGFBQWE7Y0FDbEMsS0FBSTtjQUNKLFdBQVU7Y0FDVixlQUFlLGlCQUFpQjtlQUFFLEtBQUssU0FBUyxPQUFPLGFBQWE7ZUFBRyxLQUFLO2NBQWMsQ0FBQzthQUM5Rjs7Ozt1QkFDRCx3QkFBQyxVQUFEO2NBQ0ksTUFBSztjQUNMLGVBQWUsaUJBQWlCO2VBQUUsS0FBSyxTQUFTLE9BQU8sYUFBYTtlQUFHLEtBQUs7Y0FBYyxDQUFDO2NBQzNGLFdBQVU7d0JBSGQsQ0FLSSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O3dCQUFDLFdBQ25COzs7OztxQkFDUDs7Ozs7b0JBRVI7Ozs7O21CQUNKOzs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVyw0RkFBNEYsT0FBTztxQkFBbkgsQ0FDSyxPQUFPLE1BQ1Isd0JBQUMsUUFBRCxZQUFPLE9BQU8sTUFBWTs7OzttQkFDekI7Ozs7O2tCQUNKOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBeUY7VUFFbkc7Ozs7b0JBQ0gsd0JBQUMsT0FBRDtXQUFLLFdBQVcscUNBQ1osT0FBTyxjQUFjLE9BQ2YsMkhBQ0EsT0FBTyxjQUFjLFFBQ3JCLG1HQUNBO3FCQUVMLE9BQU8sY0FBYyxPQUFPLGVBQWUsT0FBTyxhQUMvQyx3QkFBQyxxQkFBRCxFQUFxQixTQUFTLE9BQU8sY0FBYyxPQUFPLGVBQWUsT0FBTyxXQUFhOzs7O3NCQUU3Rix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNEM7V0FBdUI7Ozs7O1VBRXRGOzs7O2tCQUNKOzs7O29CQUVKLE9BQU8saUJBQ0osd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUF5RjtVQUVuRzs7OztvQkFDSCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWCx3QkFBQyxxQkFBRCxFQUFxQixTQUFTLE9BQU8sY0FBZ0I7Ozs7O1VBQ3BEOzs7O2tCQUNKOzs7O2tCQUVSOzs7OztpQkFDSjtXQXBFSSxPQUFPLGNBQWM7Ozs7ZUFvRXpCO09BRWIsQ0FBQyxJQUVDLENBQUMsbUJBQW1CLFdBQVcsbUJBQW1CLFFBQVEsV0FBVyxNQUNuRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBK0Q7T0FFekU7Ozs7ZUFFUjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDSSx3QkFBQyxVQUFEO1NBQ0ksU0FBUztTQUNULFVBQVUsZ0JBQWdCO1NBQzFCLFdBQVU7bUJBSGQsQ0FLSSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7O21CQUFDLGFBQ3JCOzs7Ozs7UUFFUix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEI7VUFDSyxlQUFlO1VBQUU7VUFBTyxZQUFZO1NBQ25DOzs7Ozs7UUFFTix3QkFBQyxVQUFEO1NBQ0ksU0FBUztTQUNULFVBQVUsaUJBQWlCLFlBQVksU0FBUztTQUNoRCxXQUFVO21CQUhkLENBSUMsZ0JBQ2Usd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztpQkFDakM7Ozs7OztPQUNQOzs7Ozs7S0FFSjs7Ozs7WUFDSjs7Ozs7O0dBSVQsd0JBQUMsb0JBQUQ7SUFDSSxRQUFRLENBQUMsQ0FBQztJQUNWLEtBQUssZUFBZTtJQUNwQixLQUFLLGVBQWU7SUFDcEIsZUFBZSxpQkFBaUIsSUFBSTtHQUN2Qzs7Ozs7RUFFQTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicmVzcG9uc2VzUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQge1xuICAgIFRyZW5kaW5nVXAsIENhbGVuZGFyLCBGaWxlVGV4dCwgQ2hldnJvblJpZ2h0LFxuICAgIFVzZXJzLCBBd2FyZCwgRXllLCBYLCBDaGVja0NpcmNsZTIsIFhDaXJjbGUsIE1pbnVzQ2lyY2xlLFxuICAgIENoZXZyb25MZWZ0LCBMb2FkZXIyLCBBcnJvd0xlZnQsIEJhckNoYXJ0MywgRG93bmxvYWQsIE1heGltaXplMlxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IFNpZGViYXIgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9sYXlvdXQvU2lkZWJhcic7XG5pbXBvcnQgVG9wYmFyIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvbGF5b3V0L1RvcGJhcic7XG5pbXBvcnQge1xuICAgIGdldE15Rm9ybXMsIGdldEZvcm1BbmFseXRpY3MsIGdldEZvcm1CeUlkLCBjbGVhclNlc3Npb24sXG4gICAgZXhwb3J0Rm9ybVJlc3BvbnNlcywgYXNzZXRVcmxcbn0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgUmljaENvbnRlbnRSZW5kZXJlciBmcm9tICcuLi8uLi8uLi91dGlscy9SaWNoQ29udGVudFJlbmRlcmVyJztcbmltcG9ydCBJbWFnZUxpZ2h0Ym94TW9kYWwgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9JbWFnZUxpZ2h0Ym94TW9kYWwnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXNwb25zZXNQYWdlKCkge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBbZm9ybXMsIHNldEZvcm1zXSA9IHVzZVN0YXRlKFtdKTtcbiAgICBjb25zdCBbbG9hZGluZ0Zvcm1zLCBzZXRMb2FkaW5nRm9ybXNdID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW3NlbGVjdGVkRm9ybUlkLCBzZXRTZWxlY3RlZEZvcm1JZF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbc2VsZWN0ZWRGb3JtRGF0YSwgc2V0U2VsZWN0ZWRGb3JtRGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbYW5hbHl0aWNzRGF0YSwgc2V0QW5hbHl0aWNzRGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbbG9hZGluZ0RldGFpbCwgc2V0TG9hZGluZ0RldGFpbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2V4cG9ydGluZywgc2V0RXhwb3J0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbbGlnaHRib3hJbWFnZSwgc2V0TGlnaHRib3hJbWFnZV0gPSB1c2VTdGF0ZShudWxsKTtcblxuICAgIC8vIE1vZGFsIFJldmlldyBBbnN3ZXJzIFN0YXRlXG4gICAgY29uc3QgW3NlbGVjdGVkUmVzcG9uZGVudCwgc2V0U2VsZWN0ZWRSZXNwb25kZW50XSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgZmV0Y2hGb3JtcyA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZ0Zvcm1zKHRydWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGdldE15Rm9ybXMoKTtcbiAgICAgICAgICAgICAgICBpZiAocmVzdWx0LnN0YXR1cyA9PT0gNDAxKSB7XG4gICAgICAgICAgICAgICAgICAgIGNsZWFyU2Vzc2lvbigpO1xuICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZSgnL2xvZ2luJyk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHJlc3VsdC5vayAmJiBBcnJheS5pc0FycmF5KHJlc3VsdC5kYXRhKSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtcyhyZXN1bHQuZGF0YSk7XG4gICAgICAgICAgICAgICAgICAgIC8vIFNlbGVjdCBmaXJzdCBmb3JtIGlmIGF2YWlsYWJsZVxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0LmRhdGEubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRGb3JtSWQocmVzdWx0LmRhdGFbMF0uaWQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgZm9ybXMgZm9yIHJlc3BvbnNlcyBwYWdlOicsIGVycik7XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmdGb3JtcyhmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGZldGNoRm9ybXMoKTtcbiAgICB9LCBbbmF2aWdhdGVdKTtcblxuICAgIC8vIExvYWQgYW5hbHl0aWNzL3Jlc3BvbnNlcyBkYXRhIHdoZW5ldmVyIHNlbGVjdGVkRm9ybUlkIGNoYW5nZXNcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIXNlbGVjdGVkRm9ybUlkKSByZXR1cm47XG5cbiAgICAgICAgY29uc3QgbG9hZEZvcm1EZXRhaWxzID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgc2V0TG9hZGluZ0RldGFpbCh0cnVlKTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgW2Zvcm1SZXMsIGFuYWx5dGljc1Jlc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICAgICAgICAgIGdldEZvcm1CeUlkKHNlbGVjdGVkRm9ybUlkKSxcbiAgICAgICAgICAgICAgICAgICAgZ2V0Rm9ybUFuYWx5dGljcyhzZWxlY3RlZEZvcm1JZCwgMSwgMTAwKVxuICAgICAgICAgICAgICAgIF0pO1xuXG4gICAgICAgICAgICAgICAgaWYgKGZvcm1SZXMub2spIHNldFNlbGVjdGVkRm9ybURhdGEoZm9ybVJlcy5kYXRhKTtcbiAgICAgICAgICAgICAgICBpZiAoYW5hbHl0aWNzUmVzLm9rICYmIGFuYWx5dGljc1Jlcy5kYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldEFuYWx5dGljc0RhdGEoYW5hbHl0aWNzUmVzLmRhdGEpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHNldEFuYWx5dGljc0RhdGEobnVsbCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgbG9hZGluZyBmb3JtIGRldGFpbC9hbmFseXRpY3M6JywgZXJyKTtcbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZ0RldGFpbChmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgbG9hZEZvcm1EZXRhaWxzKCk7XG4gICAgfSwgW3NlbGVjdGVkRm9ybUlkXSk7XG5cbiAgICAvLyBGaWx0ZXIgZm9ybXMgYmFzZWQgb24gc2VhcmNoIHF1ZXJ5XG4gICAgY29uc3QgZmlsdGVyZWRGb3JtcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIXNlYXJjaFF1ZXJ5LnRyaW0oKSkgcmV0dXJuIGZvcm1zO1xuICAgICAgICBjb25zdCBxID0gc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgcmV0dXJuIGZvcm1zLmZpbHRlcihmID0+IChcbiAgICAgICAgICAgIChmLnRpdGxlICYmIGYudGl0bGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSkgfHxcbiAgICAgICAgICAgIChmLmRlc2NyaXB0aW9uICYmIGYuZGVzY3JpcHRpb24udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSlcbiAgICAgICAgKSk7XG4gICAgfSwgW2Zvcm1zLCBzZWFyY2hRdWVyeV0pO1xuXG4gICAgLy8gQ2FsY3VsYXRlIHJlc3BvbnNlIHRyZW5kIGZyb20gZXhpc3RpbmcgcmVzcG9uZGVudCBkYXRhXG4gICAgY29uc3QgcmVzcG9uZGVudHMgPSBhbmFseXRpY3NEYXRhPy5yZXNwb25kZW50cyB8fCBbXTtcbiAgICBcbiAgICAvLyBGaWx0ZXIgcmVzcG9uZGVudHMgYmFzZWQgb24gc2VhcmNoIHF1ZXJ5XG4gICAgY29uc3QgZmlsdGVyZWRSZXNwb25kZW50cyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIXNlYXJjaFF1ZXJ5LnRyaW0oKSkgcmV0dXJuIHJlc3BvbmRlbnRzO1xuICAgICAgICBjb25zdCBxID0gc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbmRlbnRzLmZpbHRlcihyID0+IChcbiAgICAgICAgICAgIChyLnJlc3BvbmRlbnROYW1lICYmIHIucmVzcG9uZGVudE5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSkgfHxcbiAgICAgICAgICAgIChTdHJpbmcoci5yZXNwb25zZUlkKS5pbmNsdWRlcyhxKSlcbiAgICAgICAgKSk7XG4gICAgfSwgW3Jlc3BvbmRlbnRzLCBzZWFyY2hRdWVyeV0pO1xuXG4gICAgY29uc3QgdHJlbmREYXRhID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmICghcmVzcG9uZGVudHMgfHwgcmVzcG9uZGVudHMubGVuZ3RoID09PSAwKSByZXR1cm4gW107XG5cbiAgICAgICAgY29uc3QgZGF0ZU1hcCA9IHt9O1xuICAgICAgICByZXNwb25kZW50cy5mb3JFYWNoKHIgPT4ge1xuICAgICAgICAgICAgaWYgKCFyLnN1Ym1pdHRlZEF0KSByZXR1cm47XG4gICAgICAgICAgICBjb25zdCBkID0gbmV3IERhdGUoci5zdWJtaXR0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdpZC1JRCcsIHtcbiAgICAgICAgICAgICAgICBkYXk6ICcyLWRpZ2l0JyxcbiAgICAgICAgICAgICAgICBtb250aDogJ3Nob3J0J1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBkYXRlTWFwW2RdID0gKGRhdGVNYXBbZF0gfHwgMCkgKyAxO1xuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gT2JqZWN0LmVudHJpZXMoZGF0ZU1hcCkubWFwKChbZGF0ZSwgY291bnRdKSA9PiAoe1xuICAgICAgICAgICAgZGF0ZSxcbiAgICAgICAgICAgIGNvdW50XG4gICAgICAgIH0pKTtcbiAgICB9LCBbcmVzcG9uZGVudHNdKTtcblxuICAgIGNvbnN0IG1heENvdW50ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmICh0cmVuZERhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gMTtcbiAgICAgICAgcmV0dXJuIE1hdGgubWF4KC4uLnRyZW5kRGF0YS5tYXAoZCA9PiBkLmNvdW50KSwgMSk7XG4gICAgfSwgW3RyZW5kRGF0YV0pO1xuXG4gICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlU3RyKSA9PiB7XG4gICAgICAgIGlmICghZGF0ZVN0cikgcmV0dXJuICfigJQnO1xuICAgICAgICByZXR1cm4gbmV3IERhdGUoZGF0ZVN0cikudG9Mb2NhbGVEYXRlU3RyaW5nKCdpZC1JRCcsIHtcbiAgICAgICAgICAgIGRheTogJ251bWVyaWMnLFxuICAgICAgICAgICAgbW9udGg6ICdzaG9ydCcsXG4gICAgICAgICAgICB5ZWFyOiAnbnVtZXJpYycsXG4gICAgICAgICAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgICAgICAgICBtaW51dGU6ICcyLWRpZ2l0J1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgdG90YWxBbGxSZXNwb25zZXMgPSBmb3Jtcy5yZWR1Y2UoKGFjYywgZikgPT4gYWNjICsgKGYucmVzcG9uc2VDb3VudCA/PyAwKSwgMCk7XG5cbiAgICBjb25zdCBoYW5kbGVFeHBvcnQgPSBhc3luYyAoZm9ybUlkKSA9PiB7XG4gICAgICAgIGlmICghZm9ybUlkIHx8IGV4cG9ydGluZykgcmV0dXJuO1xuICAgICAgICBzZXRFeHBvcnRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBleHBvcnRGb3JtUmVzcG9uc2VzKGZvcm1JZCk7XG4gICAgICAgICAgICBpZiAoIXJlcy5vaykge1xuICAgICAgICAgICAgICAgIGFsZXJ0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW5nZWtzcG9yIGRhdGEgQ1NWIHJlc3BvbnMuJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZXhwb3J0aW5nIENTVjonLCBlcnIpO1xuICAgICAgICAgICAgYWxlcnQoJ1RlcmphZGkga2VzYWxhaGFuIHNhYXQgbWVuZ2Vrc3BvciBDU1YuJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRFeHBvcnRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIE1vZGFsIG5hdmlnYXRpb25cbiAgICBjb25zdCBjdXJyZW50SW5kZXggPSBzZWxlY3RlZFJlc3BvbmRlbnRcbiAgICAgICAgPyByZXNwb25kZW50cy5maW5kSW5kZXgociA9PiByLnJlc3BvbnNlSWQgPT09IHNlbGVjdGVkUmVzcG9uZGVudC5yZXNwb25zZUlkKVxuICAgICAgICA6IC0xO1xuXG4gICAgY29uc3QgZ29QcmV2aW91cyA9ICgpID0+IHtcbiAgICAgICAgaWYgKGN1cnJlbnRJbmRleCA+IDApIHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkUmVzcG9uZGVudChyZXNwb25kZW50c1tjdXJyZW50SW5kZXggLSAxXSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgZ29OZXh0ID0gKCkgPT4ge1xuICAgICAgICBpZiAoY3VycmVudEluZGV4IDwgcmVzcG9uZGVudHMubGVuZ3RoIC0gMSkge1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWRSZXNwb25kZW50KHJlc3BvbmRlbnRzW2N1cnJlbnRJbmRleCArIDFdKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBnZXRBbnN3ZXJTdGF0dXMgPSAoYW5zd2VyKSA9PiB7XG4gICAgICAgIGlmIChhbnN3ZXIuaXNDb3JyZWN0ID09PSB0cnVlKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGxhYmVsOiAnQmVuYXInLFxuICAgICAgICAgICAgICAgIGljb246IDxDaGVja0NpcmNsZTIgc2l6ZT17MTZ9IC8+LFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogJ3RleHQtZW1lcmFsZC02MDAgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAnXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChhbnN3ZXIuaXNDb3JyZWN0ID09PSBmYWxzZSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBsYWJlbDogJ1NhbGFoJyxcbiAgICAgICAgICAgICAgICBpY29uOiA8WENpcmNsZSBzaXplPXsxNn0gLz4sXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiAndGV4dC1yZWQtNjAwIGJnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNjAgZGFyazp0ZXh0LXJlZC00MDAgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTgwMCdcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGxhYmVsOiAnVGlkYWsgRGluaWxhaScsXG4gICAgICAgICAgICBpY29uOiA8TWludXNDaXJjbGUgc2l6ZT17MTZ9IC8+LFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAndGV4dC1zbGF0ZS01MDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgfTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctWyNGNEY4RjddIGRhcms6Ymctc2xhdGUtOTUwIGZvbnQtc2FucyBhbnRpYWxpYXNlZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICA8U2lkZWJhciAvPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGZsZXgtY29sIG1pbi13LTAgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIHctZnVsbCBwLTQgc206cC02IGxnOnAtOCBzcGFjZS15LTZcIj5cblxuICAgICAgICAgICAgICAgICAgICA8VG9wYmFyIFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoUXVlcnk9e3NlYXJjaFF1ZXJ5fSBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2hhbmdlPXtzZXRTZWFyY2hRdWVyeX0gXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNhcmkgZm9ybXVsaXIsIHJlc3BvbmRlbiwgYXRhdSBqYXdhYmFuLi4uXCIgXG4gICAgICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5SZXNwb25zIEZvcm11bGlyPC9oMT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW0gbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dG90YWxBbGxSZXNwb25zZXMudG9Mb2NhbGVTdHJpbmcoJ2lkLUlEJyl9IHRvdGFsIHJlc3BvbnMgZGFyaSB7Zm9ybXMubGVuZ3RofSBmb3JtdWxpciBha3RpZi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAge2xvYWRpbmdGb3JtcyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMjAgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwidy04IGgtOCBhbmltYXRlLXNwaW4gbXgtYXV0byB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgbWItMlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTWVtdWF0IGRhdGEgcmVzcG9ucy4uLlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiBmb3Jtcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtM3hsIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC0xMiB0ZXh0LWNlbnRlciBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBzaXplPXsyOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5CZWx1bSBBZGEgRm9ybXVsaXI8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbWF4LXctc20gbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQnVhdCBmb3JtdWxpciBwZXJ0YW1hIEFuZGEgZGFuIGJhZ2lrYW4ga2UgYXVkaWVucyB1bnR1ayBtdWxhaSBtZW5lcmltYSByZXNwb25zLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2NyZWF0ZS1mb3JtJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMi41IGJnLVsjMDA4OTdCXSBob3ZlcjpiZy1bIzAwNzk2Ql0gdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIHNoYWRvdy14cyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdWF0IEZvcm11bGlyIFNla2FyYW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRm9ybSBTZWxlY3RvciBCYXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTQgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy1zbSBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSByb3VuZGVkLXhsIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyQ2hhcnQzIHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9jayBtYi0wLjVcIj5QaWxpaCBGb3JtdWxpciBBa3RpZjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRGb3JtSWQgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNlbGVjdGVkRm9ybUlkKHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql0gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkRm9ybXMubWFwKGYgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2YuaWR9IHZhbHVlPXtmLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zi50aXRsZSB8fCAnRm9ybXVsaXIgVGFucGEgSnVkdWwnfSAoe2YucmVzcG9uc2VDb3VudCA/PyAwfSByZXNwb25zKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEZvcm1JZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRXhwb3J0KHNlbGVjdGVkRm9ybUlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2V4cG9ydGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWFsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgZGlzYWJsZWQ6b3BhY2l0eS02MCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwb3J0aW5nID8gPExvYWRlcjIgc2l6ZT17MTR9IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpblwiIC8+IDogPERvd25sb2FkIHNpemU9ezE0fSAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2V4cG9ydGluZyA/ICdNZW5nZWtzcG9yLi4uJyA6ICdVbmR1aCBDU1YnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2Zvcm1zLyR7c2VsZWN0ZWRGb3JtSWR9L2VkaXRgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXQgRm9ybXVsaXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmdEZXRhaWwgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMjAgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTggaC04IGFuaW1hdGUtc3BpbiBteC1hdXRvIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBtYi0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1lbXVhdCByaW5jaWFuIHJlc3BvbnMgZm9ybXVsaXIuLi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNVTU1BUlkgU1RBVFMgJiBUUkVORCBESUFHUkFNICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU3VtbWFyeSBDYXJkcyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBsZzpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+VG90YWwgUmVzcG9ucyBGb3JtdWxpciBJbmk8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YW5hbHl0aWNzRGF0YT8udG90YWxSZXNwb25zZXMgPz8gcmVzcG9uZGVudHMubGVuZ3RofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC14bCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXJzIHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+UmF0YS1yYXRhIFNrb3I8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YW5hbHl0aWNzRGF0YT8uYXZlcmFnZVNjb3JlICE9IG51bGwgPyBgJHthbmFseXRpY3NEYXRhLmF2ZXJhZ2VTY29yZX0lYCA6ICdOL0EnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC14bCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNjAgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QXdhcmQgc2l6ZT17MjB9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTFcIj5Ub3RhbCBTb2FsPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FuYWx5dGljc0RhdGE/LnRvdGFsUXVlc3Rpb25zID8/IDB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSByb3VuZGVkLXhsIGJnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTk1MC82MCB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSRVNQT05TRSBUUkVORCBESUFHUkFNICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC02IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctc20gbGc6Y29sLXNwYW4tMiBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERpYWdyYW0gVHJlbiBSZXNwb25zXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlcmtlbWJhbmdhbiBqdW1sYWggcmVzcG9ucyBiZXJkYXNhcmthbiB0YW5nZ2FsL3dha3R1IHN1Ym1pdCBha3R1YWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0cmVuZERhdGEubGVuZ3RofSBUaXRpayBEYXRhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0cmVuZERhdGEubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQ4IGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtY2VudGVyIHNwYWNlLXktMiBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIHNpemU9ezI4fSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBkYXJrOnRleHQtc2xhdGUtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmVsdW0gYWRhIGRhdGEgcmVzcG9ucyB1bnR1ayBtZW5hbXBpbGthbiBkaWFncmFtIHRyZW4uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQ4IGZsZXggaXRlbXMtZW5kIGdhcC0yIHNtOmdhcC00IHB0LTYgcGItMiBweC0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0cmVuZERhdGEubWFwKChpdGVtLCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGhlaWdodFBlcmNlbnQgPSBNYXRoLm1heCgoaXRlbS5jb3VudCAvIG1heENvdW50KSAqIDEwMCwgMTUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTIgaC1mdWxsIGp1c3RpZnktZW5kIGdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtZXh0cmFib2xkIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5jb3VudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctbGluZWFyLXRvLXQgZnJvbS1bIzAwODk3Ql0gdG8tWyM0REI2QUNdIGRhcms6ZnJvbS10ZWFsLTYwMCBkYXJrOnRvLXRlYWwtNDAwIHJvdW5kZWQtdC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgZ3JvdXAtaG92ZXI6YnJpZ2h0bmVzcy0xMTAgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogYCR7aGVpZ2h0UGVyY2VudH0lYCB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdHJ1bmNhdGUgdy1mdWxsIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5kYXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIHRleHQtY2VudGVyIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN1bWJ1IFg6IFRhbmdnYWwgUGVuZ2lyaW1hbiDCtyBTdW1idSBZOiBKdW1sYWggUmVzcG9uc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJFU1BPTkRFTlQgQlJFQUtET1dOIFRBQkxFICYgUkVWSUVXIEFOU1dFUlMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctc20gb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5SaW5jaWFuIFJlc3BvbnMgUmVzcG9uZGVuPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBLbGlrIFJldmlldyBKYXdhYmFuIHVudHVrIG1lbGloYXQgamF3YWJhbiBsZW5na2FwIHNldGlhcCByZXNwb25kZW4uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHNlbGYtc3RhcnQgc206c2VsZi1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbDoge2ZpbHRlcmVkUmVzcG9uZGVudHMubGVuZ3RofSBSZXNwb25kZW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkUmVzcG9uZGVudHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTE2IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlYXJjaFF1ZXJ5ID8gYFRpZGFrIGFkYSByZXNwb25kZW4geWFuZyBjb2NvayBkZW5nYW4gXCIke3NlYXJjaFF1ZXJ5fVwiLmAgOiAnQmVsdW0gYWRhIHJlc3BvbnMgeWFuZyBkaXRlcmltYSB1bnR1ayBmb3JtdWxpciBpbmkuJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gdy1mdWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtc20gdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgdGV4dC1bMTFweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj4jPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlJlc3BvbmRlbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5Tb2FsIERpamF3YWI8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+SnVtbGFoIEJlbmFyPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPkp1bWxhaCBTYWxhaDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5Ta29yPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPldha3R1IFN1Ym1pdDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodFwiPkFrc2k8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFJlc3BvbmRlbnRzLm1hcCgociwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzY29yYWJsZSA9IHIuc2NvcmFibGVRdWVzdGlvbnMgPz8gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvcnJlY3QgPSByLmNvcnJlY3RDb3VudCA/PyAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgd3JvbmcgPSByLndyb25nQ291bnQgIT0gbnVsbCA/IHIud3JvbmdDb3VudCA6IE1hdGgubWF4KHNjb3JhYmxlIC0gY29ycmVjdCwgMCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17ci5yZXNwb25zZUlkIHx8IGlkeH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+e2lkeCArIDF9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ci5yZXNwb25kZW50TmFtZSB8fCAnQW5vbmltJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVzcG9ucyAje3IucmVzcG9uc2VJZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3IuYW5zd2VyZWRDb3VudCA/PyAwfS97ci50b3RhbFF1ZXN0aW9ucyA/PyAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29ycmVjdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtcmVkLTUwMCBkYXJrOnRleHQtcmVkLTQwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt3cm9uZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ci5zY29yZSAhPSBudWxsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQteHMgZm9udC1ib2xkIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHIuc2NvcmUgPj0gNzBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctcmVkLTUwIHRleHQtcmVkLTYwMCBkYXJrOmJnLXJlZC05NTAvNjAgZGFyazp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIGRhcms6Ym9yZGVyLXJlZC04MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ci5zY29yZX0lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW1cIj5OL0E8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShyLnN1Ym1pdHRlZEF0KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFJlc3BvbmRlbnQocil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCBiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIHNpemU9ezEzfSAvPiBSZXZpZXcgSmF3YWJhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICA8L21haW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIOKUgOKUgCBSRVZJRVcgSkFXQUJBTiBNT0RBTCDilIDilIAgKi99XG4gICAgICAgICAgICB7c2VsZWN0ZWRSZXNwb25kZW50ICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkUmVzcG9uZGVudChudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHctZnVsbCBtYXgtdy0zeGwgbWF4LWgtWzkwdmhdIHJvdW5kZWQtM3hsIHNoYWRvdy0yeGwgZmxleCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBNb2RhbCBIZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hyaW5rLTAgYmctc2xhdGUtNTAvNTAgZGFyazpiZy1zbGF0ZS04MDAvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0ZXh0LWJhc2VcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJldmlldyBKYXdhYmFuIFJlc3BvbmRlblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXNwb25kZW46IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+e3NlbGVjdGVkUmVzcG9uZGVudC5yZXNwb25kZW50TmFtZSB8fCAnQW5vbmltJ308L3NwYW4+IChSZXNwb25zICN7c2VsZWN0ZWRSZXNwb25kZW50LnJlc3BvbnNlSWR9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFJlc3BvbmRlbnQobnVsbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdW1tYXJ5IEJhciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS0zLjUgYmctc2xhdGUtMTAwLzYwIGRhcms6Ymctc2xhdGUtODAwLzgwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTEuNSBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+U2tvcjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUmVzcG9uZGVudC5zY29yZSAhPSBudWxsID8gYCR7c2VsZWN0ZWRSZXNwb25kZW50LnNjb3JlfSVgIDogJ04vQSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0xLjUgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPkRpamF3YWI8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJlc3BvbmRlbnQuYW5zd2VyZWRDb3VudH0ve3NlbGVjdGVkUmVzcG9uZGVudC50b3RhbFF1ZXN0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTEuNSBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+QmVuYXI8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUmVzcG9uZGVudC5jb3JyZWN0Q291bnQgPz8gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTEuNSBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+V2FrdHUgU3VibWl0PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKHNlbGVjdGVkUmVzcG9uZGVudC5zdWJtaXR0ZWRBdCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQW5zd2VyIERldGFpbHMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC02IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoc2VsZWN0ZWRSZXNwb25kZW50LmFuc3dlcnMgfHwgW10pLm1hcCgoYW5zd2VyLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzdGF0dXMgPSBnZXRBbnN3ZXJTdGF0dXMoYW5zd2VyKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17YW5zd2VyLnF1ZXN0aW9uSWQgfHwgaW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMyBmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2hyaW5rLTAgdy03IGgtNyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2luZGV4ICsgMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e2Fuc3dlci5xdWVzdGlvbn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YW5zd2VyLnF1ZXN0aW9uSW1hZ2UgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTIgbWF4LXcteHMgcmVsYXRpdmUgZ3JvdXAvaW1nIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTEgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXthc3NldFVybChhbnN3ZXIucXVlc3Rpb25JbWFnZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiR2FtYmFyIFNvYWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1heC1oLTQwIHctYXV0byByb3VuZGVkLWxnIG9iamVjdC1jb250YWluIG14LWF1dG8gY3Vyc29yLXpvb20taW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExpZ2h0Ym94SW1hZ2UoeyBzcmM6IGFzc2V0VXJsKGFuc3dlci5xdWVzdGlvbkltYWdlKSwgYWx0OiAnR2FtYmFyIFNvYWwnIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRMaWdodGJveEltYWdlKHsgc3JjOiBhc3NldFVybChhbnN3ZXIucXVlc3Rpb25JbWFnZSksIGFsdDogJ0dhbWJhciBTb2FsJyB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMiByaWdodC0yIHAtMS41IGJnLXNsYXRlLTkwMC84MCBob3ZlcjpiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIG9wYWNpdHktMCBncm91cC1ob3Zlci9pbWc6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWF4aW1pemUyIHNpemU9ezExfSAvPiBQZXJiZXNhclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgc2hyaW5rLTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgYm9yZGVyIHRleHQtWzExcHhdIGZvbnQtYm9sZCAke3N0YXR1cy5jbGFzc05hbWV9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzLmljb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57c3RhdHVzLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtNCBzcGFjZS15LTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBKYXdhYmFuIFJlc3BvbmRlbjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcm91bmRlZC14bCBib3JkZXIgcC0zIGZvbnQtbWVkaXVtICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyLmlzQ29ycmVjdCA9PT0gdHJ1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDAgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwIHRleHQtZW1lcmFsZC05MDAgZGFyazp0ZXh0LWVtZXJhbGQtMjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGFuc3dlci5pc0NvcnJlY3QgPT09IGZhbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNDAgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTgwMCB0ZXh0LXJlZC05MDAgZGFyazp0ZXh0LXJlZC0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Fuc3dlci5hbnN3ZXJUZXh0IHx8IGFuc3dlci5hbnN3ZXJWYWx1ZSB8fCBhbnN3ZXIub3B0aW9uVGV4dCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17YW5zd2VyLmFuc3dlclRleHQgfHwgYW5zd2VyLmFuc3dlclZhbHVlIHx8IGFuc3dlci5vcHRpb25UZXh0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgaXRhbGljXCI+VGlkYWsgYWRhIGphd2FiYW48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YW5zd2VyLmNvcnJlY3RBbnN3ZXIgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBLdW5jaSAvIEphd2FiYW4gQmVuYXI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC80MCBwLTMgdGV4dC1lbWVyYWxkLTkwMCBkYXJrOnRleHQtZW1lcmFsZC0yMDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e2Fuc3dlci5jb3JyZWN0QW5zd2VyfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoIXNlbGVjdGVkUmVzcG9uZGVudC5hbnN3ZXJzIHx8IHNlbGVjdGVkUmVzcG9uZGVudC5hbnN3ZXJzLmxlbmd0aCA9PT0gMCkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyIHRleHQtc20gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmluY2lhbiBqYXdhYmFuIHRpZGFrIHRlcnNlZGlhLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBNb2RhbCBGb290ZXIgTmF2aWdhdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Z29QcmV2aW91c31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRJbmRleCA8PSAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uTGVmdCBzaXplPXsxNX0gLz4gU2ViZWx1bW55YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRJbmRleCArIDF9IGRhcmkge3Jlc3BvbmRlbnRzLmxlbmd0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2dvTmV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRJbmRleCA9PT0gcmVzcG9uZGVudHMubGVuZ3RoIC0gMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZWxhbmp1dG55YSA8Q2hldnJvblJpZ2h0IHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogTGlnaHRib3ggTW9kYWwgKi99XG4gICAgICAgICAgICA8SW1hZ2VMaWdodGJveE1vZGFsXG4gICAgICAgICAgICAgICAgaXNPcGVuPXshIWxpZ2h0Ym94SW1hZ2V9XG4gICAgICAgICAgICAgICAgc3JjPXtsaWdodGJveEltYWdlPy5zcmN9XG4gICAgICAgICAgICAgICAgYWx0PXtsaWdodGJveEltYWdlPy5hbHR9XG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TGlnaHRib3hJbWFnZShudWxsKX1cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn0iXX0=