import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/ai-chat/AiChatPage.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { Sparkles, Send, Bot, User, Trash2, ArrowRight, Download, FileSpreadsheet, BarChart2, Loader2, AlertCircle, CheckCircle2, RefreshCw, ExternalLink, HelpCircle, FileText, CornerDownLeft, Clock, Layers, Plus, ShieldCheck, Key, CheckSquare, Square, Filter, ChevronRight, X, AlertTriangle, UserCheck, ShieldAlert, Mic, MicOff, Paperclip, Upload, FileUp, Check, Globe, Video, Link2, Cpu, CheckCircle } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
import InteractiveQuizOfferCard from "/src/components/ui/InteractiveQuizOfferCard.jsx";
import { getGeminiApiKey, saveGeminiApiKey, getGeminiApiKeys, saveGeminiApiKeys, getActiveApiKeyIndex, rotateToNextApiKey, removeGeminiApiKey, AVAILABLE_MODELS, generateQuestionsFromDocument, exportQuestionsToCSV, extractContentFromUrl, DEFAULT_AI_MODEL } from "/src/services/aiService.js";
import { getMyForms, getFormById, getQuestions, addQuestions, createForm, getFormResponses, getExamMonitoring, getFormAnalytics, exportFormResponses, getLocalUser, getMySubmittedResponses, getResponseDetail, getResponseAttempts, getPublicFormByLink, getPublicResponseResult } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/ai-chat/AiChatPage.jsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function AiChatPage() {
	_s();
	const navigate = useNavigate();
	const [user] = useState(() => getLocalUser());
	const userId = user?.id || "guest";
	const storageKey = `formup_ai_chat_${userId}`;
	// Model Selector state
	const [selectedModel, setSelectedModel] = useState(() => {
		const stored = localStorage.getItem("formup_selected_model_chat");
		return stored && !stored.includes("-pro") && AVAILABLE_MODELS.some((model) => model.id === stored) ? stored : DEFAULT_AI_MODEL;
	});
	const handleModelChange = (mId) => {
		setSelectedModel(mId);
		localStorage.setItem("formup_selected_model_chat", mId);
	};
	// Chat states
	const [messages, setMessages] = useState(() => {
		try {
			const saved = localStorage.getItem(storageKey);
			return saved ? JSON.parse(saved) : [];
		} catch {
			return [];
		}
	});
	const [input, setInput] = useState("");
	const [loading, setLoading] = useState(false);
	const [userForms, setUserForms] = useState([]);
	const [selectedForm, setSelectedForm] = useState(null);
	const [submittedResponses, setSubmittedResponses] = useState([]);
	const [selectedHistory, setSelectedHistory] = useState(null);
	// C-1: Voice input state (Web Speech API)
	const [isListening, setIsListening] = useState(false);
	const [speechSupported, setSpeechSupported] = useState(false);
	const recognitionRef = useRef(null);
	// C-2: Document File Upload state & Preview/Insert modal state
	const [attachedFile, setAttachedFile] = useState(null);
	const fileInputRef = useRef(null);
	const [previewDocModal, setPreviewDocModal] = useState(null);
	const [targetFormId, setTargetFormId] = useState("new");
	const [committingToForm, setCommittingToForm] = useState(false);
	const [commitSuccessInfo, setCommitSuccessInfo] = useState(null);
	// Mention @ Autocomplete
	const [showMentionMenu, setShowMentionMenu] = useState(false);
	const [mentionFilter, setMentionFilter] = useState("");
	const [mentionCursorPos, setMentionCursorPos] = useState(0);
	// Bulk export modal / selection state
	const [showBulkModal, setShowBulkModal] = useState(false);
	const [selectedFormIdsForExport, setSelectedFormIdsForExport] = useState([]);
	const [bulkDaysFilter, setBulkDaysFilter] = useState("all");
	const [bulkExporting, setBulkExporting] = useState(false);
	const [bulkProgress, setBulkProgress] = useState(null);
	// API Key Stacking Drawer
	const [apiKeys, setApiKeys] = useState(() => getGeminiApiKeys());
	const [activeKeyIdx, setActiveKeyIdx] = useState(() => getActiveApiKeyIndex());
	const [inputKeysText, setInputKeysText] = useState(() => getGeminiApiKeys().join("\n"));
	const [apiKey, setApiKey] = useState(() => getGeminiApiKey());
	const [showKeyEditor, setShowKeyEditor] = useState(false);
	const messagesEndRef = useRef(null);
	const chatContainerRef = useRef(null);
	const inputRef = useRef(null);
	const abortControllerRef = useRef(null);
	// Initialize Web Speech API for C-1 Voice Mode
	useEffect(() => {
		if (typeof window !== "undefined") {
			const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
			if (SpeechRecognition) {
				setSpeechSupported(true);
				const recognition = new SpeechRecognition();
				recognition.continuous = false;
				recognition.interimResults = true;
				recognition.lang = "id-ID";
				recognition.onresult = (event) => {
					const transcript = Array.from(event.results).map((result) => result[0].transcript).join("");
					setInput((prev) => {
						const base = prev.trim() ? `${prev.trim()} ` : "";
						return `${base}${transcript}`;
					});
				};
				recognition.onerror = (event) => {
					console.warn("[Speech Recognition Error]:", event.error);
					setIsListening(false);
				};
				recognition.onend = () => {
					setIsListening(false);
				};
				recognitionRef.current = recognition;
			}
		}
	}, []);
	const toggleVoiceInput = () => {
		if (!speechSupported || !recognitionRef.current) {
			alert("Fitur Voice Input tidak didukung di browser ini. Disarankan menggunakan Google Chrome atau Microsoft Edge.");
			return;
		}
		if (isListening) {
			recognitionRef.current.stop();
			setIsListening(false);
		} else {
			try {
				recognitionRef.current.start();
				setIsListening(true);
			} catch (e) {
				console.error(e);
			}
		}
	};
	useEffect(() => {
		const keys = getGeminiApiKeys();
		setApiKeys(keys);
		const idx = getActiveApiKeyIndex();
		setActiveKeyIdx(idx);
		setInputKeysText(keys.join("\n"));
		const savedKey = getGeminiApiKey();
		setApiKey(savedKey);
		// Fetch user forms for @mention and context
		getMyForms().then((res) => {
			if (res.ok && Array.isArray(res.data)) {
				setUserForms(res.data);
				setSelectedFormIdsForExport(res.data.map((f) => f.id));
			}
		}).catch(() => {});
		getMySubmittedResponses().then((res) => {
			if (res.ok && Array.isArray(res.data)) setSubmittedResponses(res.data);
		}).catch(() => {});
	}, []);
	useEffect(() => {
		try {
			localStorage.setItem(storageKey, JSON.stringify(messages));
		} catch {}
		messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [messages, storageKey]);
	const handleClearHistory = () => {
		if (window.confirm("Hapus seluruh riwayat percakapan AI Assistant?")) {
			if (abortControllerRef.current) abortControllerRef.current.abort();
			setMessages([]);
			setSelectedForm(null);
			try {
				localStorage.removeItem(storageKey);
			} catch {}
		}
	};
	const handleSaveKeys = (e) => {
		if (e) e.preventDefault();
		const savedKeys = saveGeminiApiKeys(inputKeysText);
		setApiKeys(savedKeys);
		setActiveKeyIdx(0);
		setApiKey(savedKeys[0] || "");
		setShowKeyEditor(false);
	};
	// Handle typing and @mention trigger
	const handleInputChange = (e) => {
		const val = e.target.value;
		const pos = e.target.selectionStart;
		setInput(val);
		// Check if cursor is right after an '@'
		const textBeforeCursor = val.slice(0, pos);
		const lastAtMatch = textBeforeCursor.match(/@([a-zA-Z0-9_\s]*)$/);
		if (lastAtMatch) {
			setShowMentionMenu(true);
			setMentionFilter(lastAtMatch[1].toLowerCase());
			setMentionCursorPos(pos);
		} else {
			setShowMentionMenu(false);
		}
	};
	const handleSelectMentionForm = (form) => {
		const textBeforeCursor = input.slice(0, mentionCursorPos);
		const textAfterCursor = input.slice(mentionCursorPos);
		const atIndex = textBeforeCursor.lastIndexOf("@");
		const newText = textBeforeCursor.slice(0, atIndex) + `@${form.title} ` + textAfterCursor;
		setInput(newText);
		setSelectedForm(form);
		setShowMentionMenu(false);
		if (inputRef.current) {
			inputRef.current.focus();
		}
	};
	const handleSelectMentionHistory = (item) => {
		const textBeforeCursor = input.slice(0, mentionCursorPos);
		const textAfterCursor = input.slice(mentionCursorPos);
		const atIndex = textBeforeCursor.lastIndexOf("@");
		const label = String(item.formTitle || item.title || "Formulir").replace(/^riwayat jawaban\s+/i, "").trim();
		setInput(textBeforeCursor.slice(0, atIndex) + `@Riwayat Jawaban ${label} ` + textAfterCursor);
		setSelectedHistory(item);
		setSelectedForm(null);
		setShowMentionMenu(false);
		inputRef.current?.focus();
	};
	const buildResponseHistoryContext = async (item) => {
		let formId = item.formId || item.form?.id;
		const responseId = item.responseId || item.id;
		if (!formId && item.formLink) {
			const formRes = await getPublicFormByLink(item.formLink);
			formId = formRes?.data?.id || formRes?.data?.formId;
		}
		if (!formId || !responseId) return {
			context: "\n=== RIWAYAT JAWABAN ===\nData riwayat tidak memiliki ID respons yang lengkap.\n",
			quizQuestions: []
		};
		let [detail, attempts] = await Promise.all([getResponseDetail(formId, responseId), getResponseAttempts(formId, responseId).catch(() => ({ ok: false }))]);
		// Some respondent-owned records are not readable through the owner
		// detail route and return 404. The existing public result route still
		// exposes the exact answer breakdown used by /result.
		if (!detail?.ok || detail?.status === 404) {
			const fallback = await getPublicResponseResult(item.formLink, responseId, item.guestToken);
			if (fallback?.ok) detail = fallback;
		}
		const payload = detail?.data || detail?.response || {};
		const answers = payload.answers || payload.responses || payload.answerDetails || payload.answerItems || [];
		const attemptData = attempts?.data || attempts?.attempts || [];
		const quizQuestions = answers.map((a) => {
			const options = a.options || a.questionOptions || a.choices || [];
			if (!a.question && !a.questionText || !Array.isArray(options) || options.length < 2) return null;
			const normalized = options.map((o) => typeof o === "string" ? { text: o } : o);
			const correctAnswer = a.correctAnswer || a.correctOption || a.correctAnswerText || "";
			const correctIndex = normalized.findIndex((o) => o.isCorrect === true || o.correct === true || correctAnswer && (o.optionText || o.text) === correctAnswer);
			if (correctIndex < 0) return null;
			return {
				question: a.question || a.questionText,
				options: normalized.map((o) => o.optionText || o.text || ""),
				correctIndex
			};
		}).filter(Boolean).slice(0, 5);
		return {
			context: `
=== RIWAYAT JAWABAN PERSONAL: "${item.formTitle || item.title || "Formulir"}" ===
- Form ID: ${formId}
- Response ID: ${responseId}
- Skor: ${payload.score ?? item.score ?? "Tidak tersedia"}
- Status: ${payload.status || item.status || "Terkirim"}
- Detail percobaan: ${JSON.stringify(attemptData).slice(0, 12e3)}
--- JAWABAN PER SOAL (gunakan data ini, jangan menebak) ---
${answers.length ? answers.map((a, i) => `${i + 1}. Soal: ${a.question || a.questionText || "-"} | Jawaban saya: ${a.optionText || a.answerText || a.answer || a.selectedAnswer || "-"} | Kunci: ${a.correctAnswer || a.correctOption || a.correctAnswerText || "-"} | Status: ${a.isCorrect == null ? a.correct == null ? "Tidak tersedia" : a.correct ? "Benar" : "Salah" : a.isCorrect ? "Benar" : "Salah"}`).join("\n") : "Endpoint tidak mengembalikan daftar jawaban per soal."}
`,
			quizQuestions
		};
	};
	// Filter forms based on bulkDaysFilter
	const filteredFormsForBulk = useMemo(() => {
		if (bulkDaysFilter === "all") return userForms;
		const days = parseInt(bulkDaysFilter, 10);
		const cutoff = new Date();
		cutoff.setDate(cutoff.getDate() - days);
		return userForms.filter((f) => f.createdAt && new Date(f.createdAt) >= cutoff);
	}, [userForms, bulkDaysFilter]);
	const toggleSelectAllBulk = () => {
		const currentFilteredIds = filteredFormsForBulk.map((f) => f.id);
		const allSelected = currentFilteredIds.every((id) => selectedFormIdsForExport.includes(id));
		if (allSelected) {
			setSelectedFormIdsForExport((prev) => prev.filter((id) => !currentFilteredIds.includes(id)));
		} else {
			setSelectedFormIdsForExport((prev) => Array.from(new Set([...prev, ...currentFilteredIds])));
		}
	};
	const toggleSelectFormForBulk = (id) => {
		setSelectedFormIdsForExport((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
	};
	// Single export trigger
	const handleSingleExport = async (formId, formTitle, format = "csv") => {
		try {
			await exportFormResponses(formId, format);
			setMessages((prev) => [...prev, {
				id: Date.now(),
				sender: "bot",
				text: `Berhasil mengunduh berkas respons **"${formTitle}"** dalam format **${format.toUpperCase()}**.`,
				timestamp: new Date().toISOString()
			}]);
		} catch (err) {
			alert(`Gagal mengekspor form: ${err.message}`);
		}
	};
	// Bulk Export Functionality
	const executeBulkExport = async (targetForms, timeRangeLabel = "Terpilih") => {
		if (targetForms.length === 0) return;
		setBulkExporting(true);
		setBulkProgress({
			current: 0,
			total: targetForms.length,
			name: ""
		});
		setShowBulkModal(false);
		try {
			for (let i = 0; i < targetForms.length; i++) {
				const f = targetForms[i];
				setBulkProgress({
					current: i + 1,
					total: targetForms.length,
					name: f.title
				});
				try {
					await exportFormResponses(f.id, "csv");
				} catch {}
				// Small delay to prevent browser download throttling
				await new Promise((r) => setTimeout(r, 600));
			}
			setMessages((prev) => [...prev, {
				id: Date.now(),
				sender: "bot",
				text: `✅ **Bulk Export Selesai!** Berhasil mengunduh file CSV terpisah untuk **${targetForms.length} formulir** (${timeRangeLabel}).`,
				timestamp: new Date().toISOString()
			}]);
		} catch (err) {
			setMessages((prev) => [...prev, {
				id: Date.now(),
				sender: "bot",
				text: `⚠️ Terjadi kendala saat melakukan bulk export: ${err.message}`,
				timestamp: new Date().toISOString()
			}]);
		} finally {
			setBulkExporting(false);
			setBulkProgress(null);
		}
	};
	// Deep context aggregator for Gemini
	const buildDeepFormContext = async (targetForm) => {
		if (!targetForm) return "";
		try {
			// A-4 Pagination Loop: Fetch all responses across all pages up to totalPages
			let allResponses = [];
			try {
				let page = 1;
				let totalPages = 1;
				do {
					const res = await getFormResponses(targetForm.id, {
						page,
						pageSize: 100
					}).catch(() => ({}));
					if (res?.ok) {
						const pageItems = Array.isArray(res.data) ? res.data : res.data?.items || [];
						allResponses = [...allResponses, ...pageItems];
						const pg = res.pagination || res.data?.pagination;
						totalPages = pg?.totalPages || Math.ceil((pg?.totalCount || allResponses.length) / 100) || 1;
					} else {
						break;
					}
					page++;
				} while (page <= totalPages && page <= 10);
			} catch {}
			const [formDetail, questionsRes, monitoringRes, analyticsRes] = await Promise.all([
				getFormById(targetForm.id).catch(() => ({})),
				getQuestions(targetForm.id).catch(() => ({})),
				getExamMonitoring(targetForm.id).catch(() => ({})),
				getFormAnalytics(targetForm.id).catch(() => ({}))
			]);
			const fData = formDetail.data || targetForm;
			const qList = Array.isArray(questionsRes.data) ? questionsRes.data : [];
			const rList = allResponses;
			const mData = monitoringRes.data || {};
			const aData = analyticsRes.data || {};
			// 1. Scoring & Ranking statistics
			const scoredResponses = rList.filter((r) => r.score != null && !isNaN(Number(r.score))).map((r) => ({
				name: r.respondentName || r.userEmail || `Responden #${r.id}`,
				score: Number(r.score),
				submittedAt: r.submittedAt || "-",
				durationMinutes: r.durationMinutes || "-"
			})).sort((a, b) => b.score - a.score);
			const totalRespondents = rList.length;
			const highestScorer = scoredResponses.length > 0 ? scoredResponses[0] : null;
			const lowestScorer = scoredResponses.length > 0 ? scoredResponses[scoredResponses.length - 1] : null;
			const avgScore = scoredResponses.length > 0 ? (scoredResponses.reduce((acc, curr) => acc + curr.score, 0) / scoredResponses.length).toFixed(1) : aData.averageScore != null ? Number(aData.averageScore).toFixed(1) : "-";
			// 2. Point Weight (Bobot Poin) & Scoring Configuration
			const scorableQuestions = qList.filter((q) => q.isScorable !== false);
			const rawPoints = scorableQuestions.map((q) => q.points != null && Number(q.points) > 0 ? Number(q.points) : 1);
			const totalMaxPoints = rawPoints.reduce((sum, p) => sum + p, 0);
			const highestPointVal = rawPoints.length > 0 ? Math.max(...rawPoints) : 0;
			const lowestPointVal = rawPoints.length > 0 ? Math.min(...rawPoints) : 0;
			const isUniformPoints = rawPoints.length > 0 && highestPointVal === lowestPointVal;
			const highestPointQuestions = qList.map((q, idx) => ({
				...q,
				qNumber: idx + 1,
				pointVal: q.points != null && Number(q.points) > 0 ? Number(q.points) : 1
			})).filter((q) => q.isScorable !== false && q.pointVal === highestPointVal);
			// 3. Anti-cheating & Exam Monitoring statistics
			const sessions = Array.isArray(mData.sessions) ? mData.sessions : [];
			const tabSwitchers = sessions.filter((s) => s.tabSwitchCount && s.tabSwitchCount > 0 || s.violations && s.violations.length > 0).map((s) => ({
				name: s.studentName || s.respondentName || "Siswa",
				tabSwitches: s.tabSwitchCount || 0,
				status: s.status || "Active",
				violations: (s.violations || []).map((v) => `${v.eventType} pada ${v.timestamp}`).join(", ")
			}));
			// 4. Question details with explicit Points, Scorable, Required & Correct Answer
			const typeLabelMap = {
				1: "Essay",
				2: "Pilihan Ganda",
				3: "Checkbox",
				4: "Date/Time",
				5: "Benar/Salah"
			};
			const questionStats = qList.map((q, idx) => {
				const typeName = typeLabelMap[q.typeId] || `Tipe ${q.typeId}`;
				const correctOpt = q.options?.find((o) => o.isCorrect)?.optionText || q.correctAnswer || (q.isScorable === false ? "(Tidak dinilai)" : "-");
				const pointDesc = q.isScorable === false ? "Tidak dinilai (0 poin)" : q.points != null ? `${q.points} poin` : "Default (1 poin / bobot sama rata)";
				return `${idx + 1}. [Tipe: ${typeName}] "${q.question}" | Bobot: ${pointDesc} | Wajib: ${q.isRequired ? "Ya" : "Tidak"} | Kunci/Jawaban Diharapkan: ${correctOpt}`;
			});
			// 5. Form Settings
			const fSettings = fData.settings || {};
			const timerDesc = fData.timerDuration || fSettings.timerDuration ? `${Math.round((fData.timerDuration || fSettings.timerDuration) / 60)} menit` : "Tidak ada batas waktu";
			return `
=== DATA LENGKAP FORMULIR: "${fData.title || targetForm.title}" ===
- ID Formulir: ${targetForm.id}
- Deskripsi: ${fData.description || "-"}
- Status: ${fData.status || "Published"}
- Total Butir Soal: ${qList.length} butir (${scorableQuestions.length} dinilai, ${qList.length - scorableQuestions.length} tidak dinilai)
- Total Responden Masuk: ${totalRespondents} orang
- Pengaturan: Batas Waktu: ${timerDesc} | Mode Ujian: ${fData.isExamMode || fSettings.isExamMode ? "Aktif" : "Non-aktif"} | Acak Soal: ${fData.randomizeQuestions || fSettings.randomizeQuestions ? "Ya" : "Tidak"}

--- INFORMASI BOBOT POIN & SKOR MAKSIMAL ---
- Total Poin Maksimal Formulir: ${totalMaxPoints} poin
- Distribusi Bobot Soal: ${isUniformPoints ? `Sama rata untuk semua soal (${highestPointVal} poin per butir)` : `Bervariasi (Tertinggi: ${highestPointVal} poin, Terendah: ${lowestPointVal} poin)`}
- Butir Soal dengan Bobot Poin Tertinggi (${highestPointVal} poin):
${highestPointQuestions.length > 0 ? highestPointQuestions.map((q) => `  * Soal No. ${q.qNumber} (${q.question ? q.question.slice(0, 60) : "Tanpa judul"}...) : ${q.pointVal} poin`).join("\n") : "  * Semua soal memiliki bobot default"}

--- STATISTIK SKOR & PERINGKAT RESPONDEN ---
- Nilai Rata-rata: ${avgScore !== "-" ? `${avgScore}%` : "-"}
- Nilai Tertinggi: ${highestScorer ? `${highestScorer.name} (Skor: ${highestScorer.score}%)` : "Belum ada data nilai"}
- Nilai Terendah: ${lowestScorer ? `${lowestScorer.name} (Skor: ${lowestScorer.score}%)` : "Belum ada data nilai"}
- Catatan Penilaian: ${totalRespondents > 0 && scoredResponses.length === 0 ? `Terdapat ${totalRespondents} respons masuk, namun skor otomatis belum terhitung (kemungkinan berisi soal Essay yang belum dinilai manual/AI atau merupakan formulir survei/non-kuis).` : `Sebanyak ${scoredResponses.length} dari ${totalRespondents} responden telah memiliki nilai terhitung.`}
- Daftar Lengkap Ranking Responden:
${scoredResponses.length > 0 ? scoredResponses.map((r, i) => `  ${i + 1}. ${r.name} - Skor: ${r.score}% (Selesai: ${r.submittedAt})`).join("\n") : "  (Belum ada respons dengan nilai terhitung)"}

--- MONITORING & LOG PELANGGARAN (TAB SWITCH / KECURANGAN) ---
- Total Peserta Ujian Sedang Berlangsung: ${mData.inProgressCount || 0}
- Log Pelanggaran & Pindah Tab Siswa:
${tabSwitchers.length > 0 ? tabSwitchers.map((s) => `  * ${s.name}: ${s.tabSwitches}x pindah tab / alt-tab | Status: ${s.status} ${s.violations ? `| Log: ${s.violations}` : ""}`).join("\n") : "  * Tidak ada kecurangan atau pelanggaran pindah tab yang terdeteksi."}

--- DAFTAR LENGKAP BUTIR SOAL, BOBOT & KUNCI JAWABAN ---
${questionStats.join("\n")}
`;
		} catch (err) {
			return `
=== DATA FORMULIR: "${targetForm.title}" ===
Gagal memuat detail mendalam: ${err.message}.
`;
		}
	};
	const handleSendMessage = async (e) => {
		if (e) e.preventDefault();
		const query = input.trim();
		if (!query && !attachedFile || loading) return;
		const curKey = (apiKey || getGeminiApiKey()).trim();
		if (!curKey) {
			setShowKeyEditor(true);
			return;
		}
		// ── C-2: DOCUMENT GENERATOR INTENT (ATTACHED FILE) ───────────────────
		if (attachedFile) {
			const currentFile = attachedFile;
			const userMsg = {
				id: Date.now(),
				sender: "user",
				text: query || `Generate soal kuis dari dokumen materi: ${currentFile.name}`,
				attachedFileInfo: {
					name: currentFile.name,
					size: (currentFile.size / 1024).toFixed(1) + " KB"
				},
				timestamp: new Date().toISOString()
			};
			setMessages((prev) => [...prev, userMsg]);
			setAttachedFile(null);
			setInput("");
			setLoading(true);
			// Placeholder bot message for generation status
			const botMsgId = Date.now() + 1;
			setMessages((prev) => [...prev, {
				id: botMsgId,
				sender: "bot",
				text: `Sedang memproses dokumen **"${currentFile.name}"** dengan AI...`,
				timestamp: new Date().toISOString()
			}]);
			try {
				const res = await generateQuestionsFromDocument({
					file: currentFile,
					instruction: query || "Buatkan butir soal kuis/ujian berkualitas tinggi dari dokumen ini",
					customApiKey: curKey,
					onStatus: (st) => {
						setMessages((prev) => prev.map((msg) => msg.id === botMsgId ? {
							...msg,
							text: st
						} : msg));
					}
				});
				if (res.ok && Array.isArray(res.data) && res.data.length > 0) {
					setMessages((prev) => prev.map((msg) => msg.id === botMsgId ? {
						...msg,
						text: `✨ Berhasil mengekstrak dan menyusun **${res.data.length} butir soal** dari materi dokumen **"${currentFile.name}"** (${res.elapsedSec}s).\n\nAnda dapat meninjau dan langsung memasukkannya ke formulir atau mengunduhnya sebagai template CSV:`,
						actionCard: {
							type: "doc_questions_preview",
							questions: res.data,
							fileName: currentFile.name,
							modelUsed: res.modelUsed,
							elapsedSec: res.elapsedSec
						}
					} : msg));
				} else {
					setMessages((prev) => prev.map((msg) => msg.id === botMsgId ? {
						...msg,
						text: `⚠️ Gagal menghasilkan soal dari dokumen: ${res.message || "Format tidak didukung atau isi tidak terbaca."}`
					} : msg));
				}
			} catch (err) {
				setMessages((prev) => prev.map((msg) => msg.id === botMsgId ? {
					...msg,
					text: `⚠️ Terjadi kendala saat membaca dokumen: ${err.message}`
				} : msg));
			} finally {
				setLoading(false);
			}
			return;
		}
		// Explicitly selected form context or explicit @mention in query
		let activeTargetForm = selectedForm;
		let responseHistoryContext = "";
		let responseQuizQuestions = [];
		const explicitHistory = selectedHistory || submittedResponses.find((item) => {
			const title = item.formTitle || item.title || "";
			return query.toLowerCase().includes(`@riwayat jawaban ${title.toLowerCase()}`);
		});
		if (explicitHistory) {
			try {
				const historyData = await buildResponseHistoryContext(explicitHistory);
				responseHistoryContext = historyData.context;
				responseQuizQuestions = historyData.quizQuestions;
			} catch (err) {
				responseHistoryContext = `\n=== RIWAYAT JAWABAN ===\nGagal memuat detail respons: ${err.message}\n`;
			}
		}
		if (!activeTargetForm) {
			const explicitMention = userForms.find((f) => query.includes(`@${f.title}`));
			if (explicitMention) {
				activeTargetForm = explicitMention;
			}
		}
		const userMsg = {
			id: Date.now(),
			sender: "user",
			text: query,
			formContext: activeTargetForm ? {
				id: activeTargetForm.id,
				title: activeTargetForm.title
			} : null,
			responseHistoryContext: explicitHistory ? { formTitle: explicitHistory.formTitle || explicitHistory.title } : null,
			timestamp: new Date().toISOString()
		};
		setMessages((prev) => [...prev, userMsg]);
		setInput("");
		setShowMentionMenu(false);
		// Keep the selected response history pinned for the next message.
		setLoading(true);
		const lowerQuery = query.toLowerCase();
		// ── INTENT 1: EXPORT INTENT (SINGLE OR BULK) ────────────────────────
		const isExportIntent = lowerQuery.includes("export") || lowerQuery.includes("ekspor") || lowerQuery.includes("unduh") || lowerQuery.includes("download");
		const isBulk = lowerQuery.includes("7 hari") || lowerQuery.includes("3 hari") || lowerQuery.includes("bulk") || lowerQuery.includes("semua form") || lowerQuery.includes("semua formulir");
		if (isExportIntent) {
			if (isBulk || !activeTargetForm && userForms.length > 0) {
				// Show bulk export selector modal / action card
				setMessages((prev) => [...prev, {
					id: Date.now() + 1,
					sender: "bot",
					text: `Berikut opsi **Bulk Export Respons**. Anda dapat memilih formulir yang ingin diunduh atau memfilter berdasarkan rentang waktu pengerjaan:`,
					actionCard: {
						type: "bulk_selector",
						totalForms: userForms.length
					},
					timestamp: new Date().toISOString()
				}]);
				setShowBulkModal(true);
				setLoading(false);
				return;
			} else if (activeTargetForm) {
				// Single form download action card
				setMessages((prev) => [...prev, {
					id: Date.now() + 1,
					sender: "bot",
					text: `Siap! Anda dapat langsung mengunduh rekapitulasi data respons untuk **"${activeTargetForm.title}"** melalui tombol di bawah:`,
					actionCard: {
						type: "single_export",
						form: activeTargetForm
					},
					timestamp: new Date().toISOString()
				}]);
				setLoading(false);
				return;
			}
		}
		// ── INTENT 2: OUT-OF-SCOPE REDIRECTS (FORM BUILDER / EDIT / CREATE) ──
		const mentionsQuestion = /(soal|pertanyaan)/i.test(lowerQuery);
		const mentionsCreateOrRevise = /(buat|buatkan|bikin|bikinkan|tambah|tambahkan|revisi|ubah|ganti|perbaiki|edit|hapus)/i.test(lowerQuery);
		const mentionsThisForm = lowerQuery.includes("form ini") || lowerQuery.includes("formulir ini") || !!activeTargetForm;
		const isQuestionIntent = mentionsQuestion && mentionsCreateOrRevise && (mentionsThisForm || userForms.length > 0);
		const isCreateNewFormIntent = !mentionsQuestion && mentionsCreateOrRevise && /(form|formulir|kuis)/i.test(lowerQuery);
		if (isQuestionIntent) {
			const target = activeTargetForm || userForms[0];
			if (target) {
				setMessages((prev) => [...prev, {
					id: Date.now() + 1,
					sender: "bot",
					text: `Untuk membuat atau merevisi butir soal pada formulir **"${target.title}"**, silakan buka **Form Builder** dibawah ini dan klik bagian **Generate Soal AI**:`,
					redirectAction: {
						label: `Buka Form Builder: ${target.title}`,
						path: `/forms/${target.id}/edit`,
						icon: "edit"
					},
					timestamp: new Date().toISOString()
				}]);
				setLoading(false);
				return;
			}
		}
		if (isCreateNewFormIntent && !lowerQuery.includes("rekomendasi") && !lowerQuery.includes("ide") && !lowerQuery.includes("contoh")) {
			setMessages((prev) => [...prev, {
				id: Date.now() + 1,
				sender: "bot",
				text: `Untuk membuat formulir baru, silakan klik tombol di bawah ini:`,
				redirectAction: {
					label: "Buat Formulir Baru",
					path: "/dashboard",
					icon: "plus"
				},
				timestamp: new Date().toISOString()
			}]);
			setLoading(false);
			return;
		}
		// ── INTENT 3: URL / YOUTUBE EXTRACTION OR DEEP ANALYTICS & SSE STREAMING ──
		const urlMatch = query.match(/https?:\/\/[^\s]+/i);
		let urlExtractedContext = "";
		let urlMetadata = null;
		if (urlMatch) {
			const detectedUrl = urlMatch[0];
			try {
				const urlResult = await extractContentFromUrl(detectedUrl, (st) => {
					// Update user or status if needed
				});
				if (urlResult.ok && urlResult.content) {
					urlMetadata = urlResult;
					urlExtractedContext = `\n\n=== KONTEN MATERI DARI TAUTAN EKSTERNAL (${urlResult.type.toUpperCase()}) ===\nJudul: ${urlResult.title}\nSumber URL: ${urlResult.url}\nIsi Materi/Transkrip:\n"""\n${urlResult.content.slice(0, 4e4)}\n"""\n`;
				}
			} catch (err) {
				console.warn("URL extraction error:", err);
			}
		}
		let deepContext = "";
		if (activeTargetForm) {
			deepContext = await buildDeepFormContext(activeTargetForm);
		} else {
			deepContext = `
DAFTAR FORMULIR MILIK PENGGUNA (${userForms.length} formulir):
${userForms.map((f, i) => `${i + 1}. "${f.title}" (ID: ${f.id}, Status: ${f.status || "Active"}, Total Respons: ${f.responseCount || 0})`).join("\n")}
`;
		}
		if (responseHistoryContext) deepContext += responseHistoryContext;
		if (urlExtractedContext) {
			deepContext += urlExtractedContext;
		}
		const systemPrompt = `
PERAN: Anda adalah FormUp AI Assistant cerdas, analitis, dan ramah khusus untuk pendidik, guru, dan pembuat kuis di platform FormUp.
TUGAS ANDA:
1. Menjawab pertanyaan pengguna secara TEPAT, SPESIFIK, dan AKURAT menggunakan data formulir aktual atau materi dari URL yang disediakan di bawah ini.
2. Jika pengguna meminta membuat soal dari link artikel/YouTube yang dilampirkan, buatkan butir soal yang relevan, mendidik, dan berkualitas.
3. Jika ditanya tentang nilai tertinggi/terendah/rata-rata, sebutkan nama siswa dan nilai persisnya dari data ranking.
4. Jika ditanya tentang kecurangan, siswa yang curang, atau log pindah tab, jelaskan data pelanggaran yang tertera di log monitoring.
5. Format jawaban selalu menggunakan Markdown yang rapi (gunakan **bold**, bullet points, numbered list, blockquotes).
6. Jika menuliskan rumus matematika/fisika, WAJIB gunakan format LaTeX $...$ untuk inline atau $$...$$ untuk baris terpisah.

${deepContext}
`.trim();
		// Add placeholder bot message for real-time SSE streaming
		const botMessageId = Date.now() + 1;
		setMessages((prev) => [...prev, {
			id: botMessageId,
			sender: "bot",
			text: "",
			formContext: activeTargetForm ? {
				id: activeTargetForm.id,
				title: activeTargetForm.title
			} : null,
			urlMeta: urlMetadata ? {
				type: urlMetadata.type,
				title: urlMetadata.title,
				url: urlMetadata.url
			} : null,
			actionCard: explicitHistory ? {
				type: "interactive_quiz",
				quizId: `history-${explicitHistory.responseId || explicitHistory.id}`,
				questions: responseQuizQuestions
			} : null,
			modelUsed: selectedModel,
			timestamp: new Date().toISOString()
		}]);
		let currentActiveKey = curKey;
		let attempt = 0;
		const maxAttempts = Math.max(1, apiKeys.length);
		try {
			while (attempt < maxAttempts) {
				attempt++;
				try {
					abortControllerRef.current = new AbortController();
					const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${selectedModel}:streamGenerateContent?key=${currentActiveKey}&alt=sse`;
					const response = await fetch(endpoint, {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({
							contents: [{
								role: "user",
								parts: [{ text: `${systemPrompt}\n\nPertanyaan Pengguna: "${query}"` }]
							}],
							generationConfig: { temperature: .7 }
						}),
						signal: abortControllerRef.current.signal
					});
					if (!response.ok) {
						const errData = await response.json().catch(() => ({}));
						const errMsg = errData.error?.message || `HTTP ${response.status}`;
						if ((response.status === 429 || response.status === 403) && apiKeys.length > 1) {
							const rotated = rotateToNextApiKey();
							currentActiveKey = rotated.key;
							setActiveKeyIdx(rotated.index);
							setApiKey(rotated.key);
							// Retry next iteration
							continue;
						}
						throw new Error(errMsg);
					}
					const reader = response.body.getReader();
					const decoder = new TextDecoder();
					let accumulatedText = "";
					let buffer = "";
					while (true) {
						const { done, value } = await reader.read();
						if (done) break;
						buffer += decoder.decode(value, { stream: true });
						const lines = buffer.split("\n");
						buffer = lines.pop() || "";
						for (const line of lines) {
							if (!line.startsWith("data: ")) continue;
							const dataStr = line.slice(6).trim();
							if (dataStr === "[DONE]") continue;
							try {
								const parsed = JSON.parse(dataStr);
								const chunk = parsed.candidates?.[0]?.content?.parts?.[0]?.text || "";
								if (chunk) {
									accumulatedText += chunk;
									setMessages((prev) => prev.map((msg) => msg.id === botMessageId ? {
										...msg,
										text: accumulatedText
									} : msg));
								}
							} catch {}
						}
					}
					if (!accumulatedText.trim()) {
						setMessages((prev) => prev.map((msg) => msg.id === botMessageId ? {
							...msg,
							text: "Maaf, saya tidak dapat merumuskan tanggapan untuk pertanyaan tersebut."
						} : msg));
					}
					break;
				} catch (err) {
					if (err.name === "AbortError") {
						break;
					}
					if (attempt >= maxAttempts) {
						setMessages((prev) => prev.map((msg) => msg.id === botMessageId ? {
							...msg,
							text: `Terjadi kendala saat menghubungi AI (${selectedModel}): ${err.message}. Periksa koneksi atau API Key Anda.`
						} : msg));
					}
				}
			}
		} finally {
			setLoading(false);
			abortControllerRef.current = null;
		}
	};
	const handleCommitQuestionsToForm = async () => {
		if (!previewDocModal || !previewDocModal.questions || previewDocModal.questions.length === 0) return;
		setCommittingToForm(true);
		try {
			let formId = targetFormId;
			let formTitle = "";
			if (formId === "new") {
				const baseTitle = previewDocModal.fileName ? previewDocModal.fileName.replace(/\.[^/.]+$/, "") : "Materi Dokumen";
				const createRes = await createForm({
					title: `Kuis dari ${baseTitle}`,
					description: `Dibuat otomatis oleh AI Assistant dari dokumen materi "${previewDocModal.fileName}".`
				});
				if (!createRes.ok || !createRes.data?.id) {
					throw new Error(createRes.message || "Gagal membuat formulir baru.");
				}
				formId = createRes.data.id;
				formTitle = createRes.data.title;
			} else {
				const found = userForms.find((f) => String(f.id) === String(formId));
				formTitle = found?.title || `Formulir #${formId}`;
			}
			const addRes = await addQuestions(formId, previewDocModal.questions);
			if (!addRes.ok) {
				throw new Error(addRes.message || "Gagal memasukkan butir soal ke formulir.");
			}
			const totalAdded = previewDocModal.questions.length;
			setPreviewDocModal(null);
			setCommitSuccessInfo({
				formId,
				formTitle,
				count: totalAdded
			});
			// Refresh user forms list in background
			getMyForms().then((res) => {
				if (res.ok && Array.isArray(res.data)) setUserForms(res.data);
			}).catch(() => {});
		} catch (err) {
			alert(`Gagal memasukkan butir soal: ${err.message}`);
		} finally {
			setCommittingToForm(false);
		}
	};
	const filteredMentionForms = userForms.filter((f) => (f.title || "").toLowerCase().includes(mentionFilter));
	const filteredMentionHistory = submittedResponses.filter((item) => (item.formTitle || item.title || "").toLowerCase().includes(mentionFilter.replace(/^riwayat jawaban\s*/, "")));
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex h-screen bg-[#F4F8F7] dark:bg-slate-950 font-sans overflow-hidden",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 970,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col min-w-0 h-screen overflow-hidden",
				children: /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 flex flex-col min-h-0 w-full overflow-hidden p-3 sm:p-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-3 border-b border-slate-200/80 dark:border-slate-800 shrink-0",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-2xl bg-teal-600 text-white flex items-center justify-center border border-teal-500/30 shrink-0",
									children: /* @__PURE__ */ _jsxDEV(Bot, { size: 22 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 979,
										columnNumber: 33
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 978,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
									className: "text-base sm:text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2",
									children: ["FormUp AI Assistant", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] uppercase px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold tracking-wide border border-slate-200 dark:border-slate-700",
										children: "Gemini"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 984,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 982,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400 hidden sm:block",
									children: "Analisis nilai responden, deteksi kecurangan, bulk export, saran evaluasi & pembuatan soal dari dokumen."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 988,
									columnNumber: 33
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 981,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 977,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 flex-wrap sm:flex-nowrap",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5 px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs",
										children: [/* @__PURE__ */ _jsxDEV(Cpu, {
											size: 13,
											className: "text-teal-600 dark:text-teal-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 997,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: selectedModel,
											onChange: (e) => handleModelChange(e.target.value),
											className: "bg-transparent text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer pr-1",
											children: AVAILABLE_MODELS.map((m) => /* @__PURE__ */ _jsxDEV("option", {
												value: m.id,
												className: "dark:bg-slate-900 text-slate-900 dark:text-white",
												children: [
													m.name,
													" ",
													m.badge ? `(${m.badge})` : ""
												]
											}, m.id, true, {
												fileName: _jsxFileName,
												lineNumber: 1004,
												columnNumber: 41
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 998,
											columnNumber: 33
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 996,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowBulkModal(true),
										className: "px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:border-teal-500 hover:text-teal-600 transition-all cursor-pointer shadow-xs",
										children: [/* @__PURE__ */ _jsxDEV(Download, {
											size: 13,
											className: "text-teal-600"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1016,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "hidden sm:inline",
											children: "Bulk Export"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1017,
											columnNumber: 33
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1011,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowKeyEditor(!showKeyEditor),
										className: `px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all cursor-pointer ${apiKeys.length > 0 ? "text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/60 border-teal-200 dark:border-teal-800" : "text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800"}`,
										children: [/* @__PURE__ */ _jsxDEV(Key, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1029,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: apiKeys.length > 0 ? `Key (${apiKeys.length})` : "Atur API Key" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1030,
											columnNumber: 33
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1020,
										columnNumber: 29
									}, this),
									messages.length > 0 && /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: handleClearHistory,
										title: "Hapus riwayat chat",
										className: "p-2 text-slate-400 hover:text-red-500 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-xl transition-all cursor-pointer",
										children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1040,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1034,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 994,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 976,
							columnNumber: 21
						}, this),
						showKeyEditor && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 my-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm space-y-3 shrink-0",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
											size: 14,
											className: "text-emerald-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1051,
											columnNumber: 37
										}, this), " Multi-Key Stacking (Auto-Failover)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1050,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("a", {
										href: "https://aistudio.google.com/app/apikey",
										target: "_blank",
										rel: "noreferrer",
										className: "text-[11px] text-teal-600 dark:text-teal-400 font-bold flex items-center gap-1 hover:underline",
										children: ["Dapatkan Key Gratis ", /* @__PURE__ */ _jsxDEV(ExternalLink, { size: 11 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1059,
											columnNumber: 57
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1053,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1049,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400",
									children: "Masukkan satu atau lebih API Key Google Gemini (pisahkan dengan baris baru). Jika limit 429 atau kuota habis tercapai pada Key 1, sistem otomatis beralih ke Key berikutnya."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1062,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("form", {
									onSubmit: handleSaveKeys,
									className: "space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("textarea", {
										rows: 3,
										value: inputKeysText,
										onChange: (e) => setInputKeysText(e.target.value),
										placeholder: "AIzaSyKey1...\\nAIzaSyKey2...",
										className: "w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-teal-500 text-slate-900 dark:text-white"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1066,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pt-1",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-slate-400",
											children: [
												"Total Key: ",
												/* @__PURE__ */ _jsxDEV("b", { children: apiKeys.length }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1075,
													columnNumber: 52
												}, this),
												" ",
												apiKeys.length > 0 && `(Aktif: Key #${activeKeyIdx + 1})`
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1074,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "submit",
											className: "px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold cursor-pointer",
											children: "Simpan Key"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1077,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1073,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1065,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1048,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							ref: chatContainerRef,
							className: "flex-1 min-h-0 overflow-y-auto overscroll-contain py-4 space-y-4 pr-1 sm:pr-2 scroll-smooth",
							children: [
								messages.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
									className: "h-full flex flex-col items-center justify-center text-center p-6 space-y-6",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-16 h-16 rounded-3xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center border border-slate-200 dark:border-slate-700",
											children: /* @__PURE__ */ _jsxDEV(Bot, { size: 32 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1096,
												columnNumber: 37
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1095,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "max-w-md space-y-1.5",
											children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-base font-extrabold text-slate-900 dark:text-white",
												children: "Ada yang bisa saya bantu hari ini?"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1099,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-500 dark:text-slate-400",
												children: [
													"Ketik ",
													/* @__PURE__ */ _jsxDEV("code", {
														className: "px-1.5 py-0.5 bg-slate-200 dark:bg-slate-800 rounded font-bold text-teal-600",
														children: "@nama_form"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1103,
														columnNumber: 47
													}, this),
													" untuk analisis nilai/kecurangan, lampirkan berkas dokumen untuk generate kuis otomatis, atau gunakan voice input:"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1102,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1098,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl w-full text-left",
											children: [
												/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setInput("Siapa responden yang mendapatkan nilai tertinggi dan nilai terendah di form ini?"),
													className: "p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl hover:border-teal-500 hover:bg-teal-50/30 dark:hover:bg-teal-950/30 transition-all cursor-pointer group space-y-1 shadow-xs",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-teal-600",
														children: [/* @__PURE__ */ _jsxDEV(UserCheck, {
															size: 14,
															className: "text-teal-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1115,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Nilai Tertinggi & Ranking" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1116,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1114,
														columnNumber: 41
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-slate-400",
														children: "Analisis peraih skor terbaik & distribusi nilai"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1118,
														columnNumber: 41
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1109,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setInput("Siapa saja responden yang terdeteksi melakukan pelanggaran atau sering pindah tab saat ujian?"),
													className: "p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl hover:border-teal-500 hover:bg-teal-50/30 dark:hover:bg-teal-950/30 transition-all cursor-pointer group space-y-1 shadow-xs",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-teal-600",
														children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, {
															size: 14,
															className: "text-amber-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1127,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Deteksi Kecurangan & Tab Switch" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1128,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1126,
														columnNumber: 41
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-slate-400",
														children: "Log alt-tab dan pelanggaran sesi ujian"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1130,
														columnNumber: 41
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1121,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setInput("Analisis butir soal yang paling sering salah dijawab dan memiliki daya beda rendah"),
													className: "p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl hover:border-teal-500 hover:bg-teal-50/30 dark:hover:bg-teal-950/30 transition-all cursor-pointer group space-y-1 shadow-xs",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-teal-600",
														children: [/* @__PURE__ */ _jsxDEV(BarChart2, {
															size: 14,
															className: "text-teal-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1139,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Evaluasi Butir Soal Sulit" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1140,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1138,
														columnNumber: 41
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-slate-400",
														children: "Tingkat kesulitan & rekomendasi revisi"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1142,
														columnNumber: 41
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1133,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => {
														setShowBulkModal(true);
													},
													className: "p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl hover:border-teal-500 hover:bg-teal-50/30 dark:hover:bg-teal-950/30 transition-all cursor-pointer group space-y-1 shadow-xs",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-teal-600",
														children: [/* @__PURE__ */ _jsxDEV(Download, {
															size: 14,
															className: "text-teal-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1151,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Bulk Export Formulir" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1152,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1150,
														columnNumber: 41
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-slate-400",
														children: "Unduh CSV multi-form dengan filter rentang waktu"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1154,
														columnNumber: 41
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1145,
													columnNumber: 37
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1108,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1094,
									columnNumber: 29
								}, this) : messages.map((m) => /* @__PURE__ */ _jsxDEV("div", {
									className: `flex items-start gap-3 ${m.sender === "user" ? "justify-end" : "justify-start"}`,
									children: [
										m.sender === "bot" && /* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 mt-1 shadow-xs",
											children: /* @__PURE__ */ _jsxDEV(Bot, { size: 16 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1168,
												columnNumber: 45
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1167,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: `max-w-[90%] sm:max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm shadow-xs space-y-2 leading-relaxed ${m.sender === "user" ? "bg-teal-600 text-white rounded-tr-xs" : "bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border border-slate-200/80 dark:border-slate-800 rounded-tl-xs"}`,
											children: [
												m.formContext && /* @__PURE__ */ _jsxDEV("div", {
													className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-teal-500/20 text-[10px] font-bold",
													children: [/* @__PURE__ */ _jsxDEV(FileText, { size: 10 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1182,
														columnNumber: 49
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["@", m.formContext.title] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1183,
														columnNumber: 49
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1181,
													columnNumber: 45
												}, this),
												m.responseHistoryContext && /* @__PURE__ */ _jsxDEV("div", {
													className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/20 text-[10px] font-bold text-amber-700 dark:text-amber-300",
													children: [/* @__PURE__ */ _jsxDEV(FileText, { size: 10 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1188,
														columnNumber: 49
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["@Riwayat Jawaban ", m.responseHistoryContext.formTitle] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1189,
														columnNumber: 49
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1187,
													columnNumber: 45
												}, this),
												m.attachedFileInfo && /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-teal-700/40 text-[11px] font-semibold text-teal-100 w-fit mb-1 border border-teal-500/30",
													children: [/* @__PURE__ */ _jsxDEV(FileText, { size: 11 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1196,
														columnNumber: 49
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
														m.attachedFileInfo.name,
														" (",
														m.attachedFileInfo.size,
														")"
													] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1197,
														columnNumber: 49
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1195,
													columnNumber: 45
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "leading-relaxed",
													children: m.text ? /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: m.text }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1204,
														columnNumber: 49
													}, this) : /* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2 text-xs text-slate-400",
														children: [/* @__PURE__ */ _jsxDEV(Loader2, {
															size: 14,
															className: "animate-spin text-teal-600"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1207,
															columnNumber: 53
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Menulis tanggapan..." }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1208,
															columnNumber: 53
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1206,
														columnNumber: 49
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1202,
													columnNumber: 41
												}, this),
												m.actionCard?.type === "single_export" && m.actionCard.form && /* @__PURE__ */ _jsxDEV("div", {
													className: "pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-2",
													children: [/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => handleSingleExport(m.actionCard.form.id, m.actionCard.form.title, "csv"),
														className: "px-3 py-2 bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer",
														children: [/* @__PURE__ */ _jsxDEV(Download, { size: 13 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1221,
															columnNumber: 53
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Unduh Format CSV" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1222,
															columnNumber: 53
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1216,
														columnNumber: 49
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => handleSingleExport(m.actionCard.form.id, m.actionCard.form.title, "xlsx"),
														className: "px-3 py-2 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer",
														children: [/* @__PURE__ */ _jsxDEV(FileSpreadsheet, { size: 13 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1229,
															columnNumber: 53
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Unduh Format Excel (XLSX)" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1230,
															columnNumber: 53
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1224,
														columnNumber: 49
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1215,
													columnNumber: 45
												}, this),
												m.actionCard?.type === "bulk_selector" && /* @__PURE__ */ _jsxDEV("div", {
													className: "pt-2 border-t border-slate-100 dark:border-slate-800",
													children: /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => setShowBulkModal(true),
														className: "px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-xs",
														children: [/* @__PURE__ */ _jsxDEV(Download, { size: 13 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1243,
															columnNumber: 53
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
															"Buka Menu Bulk Export (",
															userForms.length,
															" Formulir)"
														] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1244,
															columnNumber: 53
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1238,
														columnNumber: 49
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1237,
													columnNumber: 45
												}, this),
												m.actionCard?.type === "doc_questions_preview" && m.actionCard.questions && /* @__PURE__ */ _jsxDEV("div", {
													className: "pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2 text-xs font-bold text-teal-700 dark:text-teal-300",
														children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
															size: 14,
															className: "text-teal-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1253,
															columnNumber: 53
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [m.actionCard.questions.length, " Butir Soal Siap Digunakan"] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1254,
															columnNumber: 53
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1252,
														columnNumber: 49
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "flex flex-wrap gap-2",
														children: [/* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => {
																setPreviewDocModal({
																	questions: m.actionCard.questions,
																	fileName: m.actionCard.fileName
																});
																setTargetFormId("new");
															},
															className: "px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs",
															children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 13 }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1268,
																columnNumber: 57
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Tinjau & Masukkan ke Form" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1269,
																columnNumber: 57
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1257,
															columnNumber: 53
														}, this), /* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => exportQuestionsToCSV(m.actionCard.questions, m.actionCard.fileName || "soal-materi-ai"),
															className: "px-3.5 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer",
															children: [/* @__PURE__ */ _jsxDEV(Download, { size: 13 }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1276,
																columnNumber: 57
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Unduh Format CSV" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1277,
																columnNumber: 57
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1271,
															columnNumber: 53
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1256,
														columnNumber: 49
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1251,
													columnNumber: 45
												}, this),
												m.redirectAction && /* @__PURE__ */ _jsxDEV("div", {
													className: "pt-2",
													children: /* @__PURE__ */ _jsxDEV(Link, {
														to: m.redirectAction.path,
														className: "inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-300 text-xs font-bold hover:bg-teal-100 transition-all",
														children: [/* @__PURE__ */ _jsxDEV("span", { children: m.redirectAction.label }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1290,
															columnNumber: 53
														}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 13 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1291,
															columnNumber: 53
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1286,
														columnNumber: 49
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1285,
													columnNumber: 45
												}, this),
												m.actionCard?.type === "interactive_quiz" && m.text && m.actionCard.questions?.length > 0 && /* @__PURE__ */ _jsxDEV(InteractiveQuizOfferCard, {
													quizId: m.actionCard.quizId,
													questions: m.actionCard.questions
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1296,
													columnNumber: 45
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1172,
											columnNumber: 37
										}, this),
										m.sender === "user" && /* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0 mt-1",
											children: /* @__PURE__ */ _jsxDEV(User, { size: 16 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1302,
												columnNumber: 45
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1301,
											columnNumber: 41
										}, this)
									]
								}, m.id, true, {
									fileName: _jsxFileName,
									lineNumber: 1160,
									columnNumber: 33
								}, this)),
								bulkExporting && bulkProgress && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-800 rounded-2xl flex items-center gap-3 shrink-0",
									children: [/* @__PURE__ */ _jsxDEV(Loader2, {
										size: 20,
										className: "animate-spin text-teal-600 shrink-0"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1311,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 min-w-0",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-bold text-teal-900 dark:text-teal-100",
											children: [
												"Mengunduh CSV (",
												bulkProgress.current,
												"/",
												bulkProgress.total,
												"): ",
												bulkProgress.name
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1313,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "w-full bg-teal-200/60 dark:bg-teal-900/60 h-1.5 rounded-full mt-1.5 overflow-hidden",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "bg-teal-600 h-full transition-all duration-300 rounded-full",
												style: { width: `${bulkProgress.current / bulkProgress.total * 100}%` }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1317,
												columnNumber: 41
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1316,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1312,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1310,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { ref: messagesEndRef }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1326,
									columnNumber: 25
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1089,
							columnNumber: 21
						}, this),
						showMentionMenu && (filteredMentionForms.length > 0 || filteredMentionHistory.length > 0) && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl p-2 max-h-48 overflow-y-auto space-y-1 shrink-0 z-20",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between px-2 py-1 border-b border-slate-100 dark:border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider",
										children: "Pilih Formulir Terkait:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1333,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowMentionMenu(false),
										className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-[10px] font-bold cursor-pointer",
										children: "Tutup (Esc)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1336,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1332,
									columnNumber: 29
								}, this),
								filteredMentionHistory.map((item) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleSelectMentionHistory(item),
									className: "w-full text-left px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-amber-950/30 rounded-xl flex items-center justify-between cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "truncate",
										children: ["@Riwayat Jawaban ", item.formTitle || item.title]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1346,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-amber-600 shrink-0 ml-2",
										children: "Jawaban saya"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1347,
										columnNumber: 37
									}, this)]
								}, `history-${item.responseId || item.id}`, true, {
									fileName: _jsxFileName,
									lineNumber: 1345,
									columnNumber: 33
								}, this)),
								filteredMentionForms.map((f) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleSelectMentionForm(f),
									className: "w-full text-left px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-xl flex items-center justify-between transition-colors cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "truncate",
										children: f.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1357,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 font-normal shrink-0 ml-2",
										children: [f.responseCount || 0, " respons"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1358,
										columnNumber: 37
									}, this)]
								}, f.id, true, {
									fileName: _jsxFileName,
									lineNumber: 1351,
									columnNumber: 33
								}, this))
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1331,
							columnNumber: 25
						}, this),
						selectedForm && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-2 flex items-center justify-between gap-3 px-3.5 py-2 bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 rounded-2xl text-xs shrink-0 shadow-2xs",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 min-w-0",
								children: [/* @__PURE__ */ _jsxDEV(FileText, {
									size: 14,
									className: "text-teal-600 shrink-0"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1370,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-600 dark:text-slate-300",
									children: ["Konteks Formulir: ", /* @__PURE__ */ _jsxDEV("strong", {
										className: "text-teal-800 dark:text-teal-200",
										children: selectedForm.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1372,
										columnNumber: 55
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1371,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1369,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSelectedForm(null),
								className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-teal-100 hover:bg-red-100 dark:bg-teal-900/60 dark:hover:bg-red-950/60 text-teal-700 hover:text-red-600 dark:text-teal-300 dark:hover:text-red-300 text-[11px] font-bold transition-colors cursor-pointer",
								title: "Keluar dari konteks formulir ini",
								children: [/* @__PURE__ */ _jsxDEV(X, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1381,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Keluar Konteks" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1382,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1375,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1368,
							columnNumber: 25
						}, this),
						selectedHistory && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-2 flex items-center justify-between gap-3 px-3.5 py-2 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 rounded-2xl text-xs shrink-0 shadow-2xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-amber-800 dark:text-amber-200 truncate",
								children: ["Konteks: ", /* @__PURE__ */ _jsxDEV("strong", { children: ["@Riwayat Jawaban ", selectedHistory.formTitle || selectedHistory.title] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1388,
									columnNumber: 100
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1388,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSelectedHistory(null),
								className: "text-[11px] font-bold text-amber-700 dark:text-amber-300",
								children: "Keluar Konteks"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1389,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1387,
							columnNumber: 25
						}, this),
						attachedFile && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-2 flex items-center justify-between px-3 py-1.5 bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-800 rounded-xl text-xs w-fit shrink-0",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-teal-900 dark:text-teal-200",
								children: [
									/* @__PURE__ */ _jsxDEV(Paperclip, {
										size: 13,
										className: "text-teal-600"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1397,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold truncate max-w-[200px] sm:max-w-xs",
										children: attachedFile.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1398,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-teal-600 dark:text-teal-400",
										children: [
											"(",
											(attachedFile.size / 1024).toFixed(1),
											" KB)"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1399,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1396,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setAttachedFile(null),
								className: "text-teal-400 hover:text-red-500 font-bold ml-2 cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 13 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1406,
									columnNumber: 33
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1401,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1395,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleSendMessage,
							className: "relative flex items-center gap-2 pt-2 shrink-0",
							children: [
								/* @__PURE__ */ _jsxDEV("input", {
									type: "file",
									ref: fileInputRef,
									onChange: (e) => {
										if (e.target.files && e.target.files[0]) {
											setAttachedFile(e.target.files[0]);
											e.target.value = "";
										}
									},
									accept: ".pdf,.docx,.txt,.csv,.md,application/pdf,text/plain,text/csv",
									className: "hidden"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1413,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => fileInputRef.current?.click(),
									title: "Lampirkan Dokumen Materi (PDF, DOCX, TXT, CSV, MD)",
									className: "p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500 hover:text-teal-600 text-slate-600 dark:text-slate-300 rounded-2xl transition-all cursor-pointer shadow-xs shrink-0",
									children: /* @__PURE__ */ _jsxDEV(Paperclip, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1432,
										columnNumber: 29
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1426,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: toggleVoiceInput,
									title: isListening ? "Berhenti mendengarkan" : "Voice Input (Bicara dalam Bahasa Indonesia)",
									className: `p-3 border rounded-2xl transition-all cursor-pointer shadow-xs shrink-0 ${isListening ? "bg-red-500 text-white border-red-500 animate-pulse" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-teal-500 hover:text-teal-600 text-slate-600 dark:text-slate-300"}`,
									children: isListening ? /* @__PURE__ */ _jsxDEV(MicOff, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1445,
										columnNumber: 44
									}, this) : /* @__PURE__ */ _jsxDEV(Mic, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1445,
										columnNumber: 67
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1435,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative flex-1",
									children: [/* @__PURE__ */ _jsxDEV("textarea", {
										ref: inputRef,
										rows: 1,
										value: input,
										onChange: handleInputChange,
										onKeyDown: (e) => {
											if (e.key === "Escape") {
												setShowMentionMenu(false);
											} else if (e.key === "Enter" && !e.shiftKey) {
												e.preventDefault();
												handleSendMessage(e);
											}
										},
										placeholder: isListening ? "Sedang mendengarkan suara Anda..." : attachedFile ? "Ketik instruksi khusus (opsional) lalu tekan Enter..." : "Tanyakan ranking, kecurangan, atau ketik @ untuk pilih formulir...",
										className: "w-full pl-4 pr-12 py-3.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 shadow-sm resize-none",
										disabled: loading || bulkExporting
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1449,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										disabled: loading || !input.trim() && !attachedFile || bulkExporting,
										className: "absolute right-2.5 top-1/2 -translate-y-1/2 p-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-xs",
										children: /* @__PURE__ */ _jsxDEV(Send, { size: 15 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1477,
											columnNumber: 33
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1472,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1448,
									columnNumber: 25
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1412,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 974,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 972,
				columnNumber: 13
			}, this),
			showBulkModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xs",
					onClick: () => setShowBulkModal(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1487,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-xl space-y-4 z-10 max-h-[85vh] flex flex-col",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600",
									children: /* @__PURE__ */ _jsxDEV(Download, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1492,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1491,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-extrabold text-slate-900 dark:text-white",
									children: "Bulk Export Respons Formulir"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1495,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400",
									children: "Unduh berkas CSV terpisah untuk setiap formulir yang dipilih."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1496,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1494,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1490,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setShowBulkModal(false),
								className: "p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1504,
									columnNumber: 33
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1499,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1489,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: "Filter Rentang Waktu Pembuatan:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1510,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-5 gap-1.5",
								children: [
									{
										key: "1",
										label: "1 Hari"
									},
									{
										key: "3",
										label: "3 Hari"
									},
									{
										key: "7",
										label: "7 Hari"
									},
									{
										key: "30",
										label: "30 Hari"
									},
									{
										key: "all",
										label: "Semua"
									}
								].map((t) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setBulkDaysFilter(t.key),
									className: `py-1.5 text-xs font-bold rounded-xl border transition-all cursor-pointer ${bulkDaysFilter === t.key ? "bg-teal-600 text-white border-teal-600 shadow-xs" : "bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-teal-400"}`,
									children: t.label
								}, t.key, false, {
									fileName: _jsxFileName,
									lineNumber: 1519,
									columnNumber: 37
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1511,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1509,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 flex-1 min-h-0 flex flex-col",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-300",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									"Daftar Formulir (",
									filteredFormsForBulk.length,
									"):"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1538,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: toggleSelectAllBulk,
									className: "text-teal-600 dark:text-teal-400 hover:underline cursor-pointer",
									children: "Pilih Semua"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1539,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1537,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-2xl p-2 space-y-1 divide-y divide-slate-100 dark:divide-slate-800/60 max-h-48",
								children: filteredFormsForBulk.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
									className: "text-center py-6 text-xs text-slate-400",
									children: "Tidak ada formulir dalam rentang waktu ini."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1550,
									columnNumber: 37
								}, this) : filteredFormsForBulk.map((f) => {
									const isChecked = selectedFormIdsForExport.includes(f.id);
									return /* @__PURE__ */ _jsxDEV("div", {
										onClick: () => toggleSelectFormForBulk(f.id),
										className: "flex items-center justify-between p-2 hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl cursor-pointer transition-colors pt-2",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2.5 min-w-0 pr-2",
											children: [isChecked ? /* @__PURE__ */ _jsxDEV(CheckSquare, {
												size: 16,
												className: "text-teal-600 shrink-0"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1562,
												columnNumber: 57
											}, this) : /* @__PURE__ */ _jsxDEV(Square, {
												size: 16,
												className: "text-slate-400 shrink-0"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1564,
												columnNumber: 57
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-semibold text-slate-800 dark:text-slate-200 truncate",
												children: f.title
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1566,
												columnNumber: 53
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1560,
											columnNumber: 49
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-400 shrink-0",
											children: [f.responseCount || 0, " respons"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1568,
											columnNumber: 49
										}, this)]
									}, f.id, true, {
										fileName: _jsxFileName,
										lineNumber: 1555,
										columnNumber: 45
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1548,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1536,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setShowBulkModal(false),
								className: "flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl cursor-pointer hover:bg-slate-200",
								children: "Batal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1580,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: selectedFormIdsForExport.length === 0 || bulkExporting,
								onClick: () => {
									const forms = userForms.filter((f) => selectedFormIdsForExport.includes(f.id));
									executeBulkExport(forms, `${selectedFormIdsForExport.length} formulir terpilih`);
								},
								className: "flex-1 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl cursor-pointer flex items-center justify-center gap-2 shadow-xs",
								children: [/* @__PURE__ */ _jsxDEV(Download, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1596,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
									"Unduh (",
									selectedFormIdsForExport.length,
									") Formulir"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1597,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1587,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1579,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1488,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1486,
				columnNumber: 17
			}, this),
			previewDocModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xs",
					onClick: () => !committingToForm && setPreviewDocModal(null)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1607,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-2xl w-full shadow-2xl space-y-4 z-10 max-h-[90vh] flex flex-col",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600",
									children: /* @__PURE__ */ _jsxDEV(FileUp, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1612,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1611,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-extrabold text-slate-900 dark:text-white",
									children: ["Tinjau Soal dari Dokumen: ", previewDocModal.fileName]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1615,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400",
									children: [
										"Total ",
										previewDocModal.questions?.length || 0,
										" butir soal siap dimasukkan ke formulir Anda."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1618,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1614,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1610,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: committingToForm,
								onClick: () => setPreviewDocModal(null),
								className: "p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1629,
									columnNumber: 33
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1623,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1609,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: "Tujuan Penyimpanan Soal:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1635,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row gap-2",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: `flex-1 p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${targetFormId === "new" ? "bg-teal-50 dark:bg-teal-950/60 border-teal-500 text-teal-900 dark:text-teal-200" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"}`,
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "radio",
										name: "targetForm",
										value: "new",
										checked: targetFormId === "new",
										onChange: () => setTargetFormId("new"),
										className: "text-teal-600"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1644,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "font-bold",
											children: "✨ Buat Formulir Baru"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1653,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] text-slate-400",
											children: "Otomatis membuat kuis baru dari judul materi"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1654,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1652,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1639,
									columnNumber: 33
								}, this), userForms.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
									className: "flex-1 flex flex-col justify-center",
									children: /* @__PURE__ */ _jsxDEV("select", {
										value: targetFormId,
										onChange: (e) => setTargetFormId(e.target.value),
										className: "w-full px-3 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "new",
											children: "-- Atau Pilih Formulir Yang Sudah Ada --"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1665,
											columnNumber: 45
										}, this), userForms.map((f) => /* @__PURE__ */ _jsxDEV("option", {
											value: f.id,
											children: ["Tambahkan ke: ", f.title]
										}, f.id, true, {
											fileName: _jsxFileName,
											lineNumber: 1667,
											columnNumber: 49
										}, this))]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1660,
										columnNumber: 41
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1659,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1638,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1634,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-2xl p-3 space-y-3 max-h-64",
							children: previewDocModal.questions?.map((q, idx) => /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-white dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 rounded-xl space-y-1.5",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-slate-800 dark:text-slate-200",
											children: [
												idx + 1,
												". ",
												q.question
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1682,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 text-[10px] font-bold shrink-0",
											children: [
												q.typeId === 2 ? "Pilihan Ganda" : q.typeId === 3 ? "Checkbox" : q.typeId === 5 ? "Benar/Salah" : "Essay",
												" (",
												q.points || 1,
												" Poin)"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1685,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1681,
										columnNumber: 37
									}, this),
									q.options && q.options.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-1 pt-1",
										children: q.options.map((opt, oIdx) => /* @__PURE__ */ _jsxDEV("div", {
											className: `px-2.5 py-1 rounded-lg text-xs flex items-center gap-1.5 ${opt.isCorrect ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold border border-emerald-200 dark:border-emerald-800" : "bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400"}`,
											children: [opt.isCorrect && /* @__PURE__ */ _jsxDEV(Check, {
												size: 12,
												className: "text-emerald-500 shrink-0"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1700,
												columnNumber: 71
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "truncate",
												children: opt.optionText
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1701,
												columnNumber: 53
											}, this)]
										}, oIdx, true, {
											fileName: _jsxFileName,
											lineNumber: 1692,
											columnNumber: 49
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1690,
										columnNumber: 41
									}, this),
									q.correctAnswer && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold pt-1",
										children: ["Kunci: ", q.correctAnswer]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1707,
										columnNumber: 41
									}, this)
								]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 1680,
								columnNumber: 33
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1678,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: committingToForm,
								onClick: () => setPreviewDocModal(null),
								className: "flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl cursor-pointer hover:bg-slate-200",
								children: "Batal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1717,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: committingToForm,
								onClick: handleCommitQuestionsToForm,
								className: "flex-1 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl cursor-pointer flex items-center justify-center gap-2 shadow-xs",
								children: committingToForm ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
									size: 14,
									className: "animate-spin"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1733,
									columnNumber: 41
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Menyimpan ke Formulir..." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1734,
									columnNumber: 41
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1732,
									columnNumber: 37
								}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1738,
									columnNumber: 41
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
									"Masukkan ",
									previewDocModal.questions?.length,
									" Soal ke Form"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1739,
									columnNumber: 41
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1737,
									columnNumber: 37
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1725,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1716,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1608,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1606,
				columnNumber: 17
			}, this),
			commitSuccessInfo && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xs",
					onClick: () => setCommitSuccessInfo(null)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1751,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-sm w-full shadow-2xl space-y-4 z-10 text-center",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 mx-auto flex items-center justify-center",
							children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 24 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1754,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1753,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-base font-extrabold text-slate-900 dark:text-white",
								children: "Berhasil Dimasukkan!"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1757,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: [
									"Sebanyak ",
									/* @__PURE__ */ _jsxDEV("b", { children: [commitSuccessInfo.count, " butir soal"] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1761,
										columnNumber: 42
									}, this),
									" telah ditambahkan ke ",
									/* @__PURE__ */ _jsxDEV("b", { children: [
										"\"",
										commitSuccessInfo.formTitle,
										"\""
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1761,
										columnNumber: 107
									}, this),
									"."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1760,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1756,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setCommitSuccessInfo(null),
								className: "flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl cursor-pointer hover:bg-slate-200",
								children: "Tutup"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1765,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => navigate(`/forms/${commitSuccessInfo.formId}/edit`),
								className: "flex-1 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl cursor-pointer flex items-center justify-center gap-1.5 shadow-xs",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Buka Form Builder" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1777,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 13 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1778,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1772,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1764,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1752,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1750,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 969,
		columnNumber: 9
	}, this);
}
_s(AiChatPage, "ussa1GIC0DrZE19REuelMbXqDW8=", false, function() {
	return [useNavigate];
});
_c = AiChatPage;
var _c;
$RefreshReg$(_c, "AiChatPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/ai-chat/AiChatPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/ai-chat/AiChatPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/ai-chat/AiChatPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/ai-chat/AiChatPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsUUFBUSxlQUFlO0FBQ3JELFNBQVMsYUFBYSxZQUFZO0FBQ2xDLFNBQ0ksVUFBVSxNQUFNLEtBQUssTUFBTSxRQUFRLFlBQVksVUFDL0MsaUJBQWlCLFdBQVcsU0FBUyxhQUFhLGNBQ2xELFdBQVcsY0FBYyxZQUFZLFVBQVUsZ0JBQy9DLE9BQU8sUUFBUSxNQUFNLGFBQWEsS0FBSyxhQUFhLFFBQ3BELFFBQVEsY0FBYyxHQUFHLGVBQWUsV0FBVyxhQUNuRCxLQUFLLFFBQVEsV0FBVyxRQUFRLFFBQVEsT0FDeEMsT0FBTyxPQUFPLE9BQU8sS0FBSyxtQkFDdkI7QUFDUCxPQUFPLGFBQWE7QUFDcEIsT0FBTyx5QkFBeUI7QUFDaEMsT0FBTyw4QkFBOEI7QUFDckMsU0FDSSxpQkFDQSxrQkFDQSxrQkFDQSxtQkFDQSxzQkFDQSxvQkFDQSxvQkFDQSxrQkFDQSwrQkFDQSxzQkFDQSx1QkFDQSx3QkFDRztBQUNQLFNBQ0ksWUFDQSxhQUNBLGNBQ0EsY0FDQSxZQUNBLGtCQUNBLG1CQUNBLGtCQUNBLHFCQUNBLGNBQ0EseUJBQ0EsbUJBQ0EscUJBQ0EscUJBQ0EsK0JBQ0c7Ozs7QUFFUCxlQUFlLFNBQVMsYUFBYTs7Q0FDakMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLFFBQVEsZUFBZSxhQUFhLENBQUM7Q0FDNUMsTUFBTSxTQUFTLE1BQU0sTUFBTTtDQUMzQixNQUFNLGFBQWEsa0JBQWtCOztDQUdyQyxNQUFNLENBQUMsZUFBZSxvQkFBb0IsZUFBZTtFQUNyRCxNQUFNLFNBQVMsYUFBYSxRQUFRLDRCQUE0QjtFQUNoRSxPQUFPLFVBQVUsQ0FBQyxPQUFPLFNBQVMsTUFBTSxLQUFLLGlCQUFpQixNQUFLLFVBQVMsTUFBTSxPQUFPLE1BQU0sSUFBSSxTQUFTO0NBQ2hILENBQUM7Q0FFRCxNQUFNLHFCQUFxQixRQUFRO0VBQy9CLGlCQUFpQixHQUFHO0VBQ3BCLGFBQWEsUUFBUSw4QkFBOEIsR0FBRztDQUMxRDs7Q0FHQSxNQUFNLENBQUMsVUFBVSxlQUFlLGVBQWU7RUFDM0MsSUFBSTtHQUNBLE1BQU0sUUFBUSxhQUFhLFFBQVEsVUFBVTtHQUM3QyxPQUFPLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSSxDQUFDO0VBQ3hDLFFBQVE7R0FDSixPQUFPLENBQUM7RUFDWjtDQUNKLENBQUM7Q0FDRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDLENBQUM7Q0FDN0MsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsSUFBSTtDQUNyRCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLENBQUMsQ0FBQztDQUMvRCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7O0NBRzNELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBQzVELE1BQU0saUJBQWlCLE9BQU8sSUFBSTs7Q0FHbEMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsSUFBSTtDQUNyRCxNQUFNLGVBQWUsT0FBTyxJQUFJO0NBQ2hDLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsSUFBSTtDQUMzRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLElBQUk7O0NBRy9ELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsS0FBSztDQUM1RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsQ0FBQzs7Q0FHMUQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUN4RCxNQUFNLENBQUMsMEJBQTBCLCtCQUErQixTQUFTLENBQUMsQ0FBQztDQUMzRSxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEtBQUs7Q0FDMUQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUN4RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxJQUFJOztDQUdyRCxNQUFNLENBQUMsU0FBUyxjQUFjLGVBQWUsaUJBQWlCLENBQUM7Q0FDL0QsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLGVBQWUscUJBQXFCLENBQUM7Q0FDN0UsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLGVBQWUsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQztDQUN0RixNQUFNLENBQUMsUUFBUSxhQUFhLGVBQWUsZ0JBQWdCLENBQUM7Q0FDNUQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUV4RCxNQUFNLGlCQUFpQixPQUFPLElBQUk7Q0FDbEMsTUFBTSxtQkFBbUIsT0FBTyxJQUFJO0NBQ3BDLE1BQU0sV0FBVyxPQUFPLElBQUk7Q0FDNUIsTUFBTSxxQkFBcUIsT0FBTyxJQUFJOztDQUd0QyxnQkFBZ0I7RUFDWixJQUFJLE9BQU8sV0FBVyxhQUFhO0dBQy9CLE1BQU0sb0JBQW9CLE9BQU8scUJBQXFCLE9BQU87R0FDN0QsSUFBSSxtQkFBbUI7SUFDbkIsbUJBQW1CLElBQUk7SUFDdkIsTUFBTSxjQUFjLElBQUksa0JBQWtCO0lBQzFDLFlBQVksYUFBYTtJQUN6QixZQUFZLGlCQUFpQjtJQUM3QixZQUFZLE9BQU87SUFFbkIsWUFBWSxZQUFZLFVBQVU7S0FDOUIsTUFBTSxhQUFhLE1BQU0sS0FBSyxNQUFNLE9BQU8sQ0FBQyxDQUN2QyxLQUFJLFdBQVUsT0FBTyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQ25DLEtBQUssRUFBRTtLQUNaLFVBQVMsU0FBUTtNQUNiLE1BQU0sT0FBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxFQUFFLEtBQUs7TUFDL0MsT0FBTyxHQUFHLE9BQU87S0FDckIsQ0FBQztJQUNMO0lBRUEsWUFBWSxXQUFXLFVBQVU7S0FDN0IsUUFBUSxLQUFLLCtCQUErQixNQUFNLEtBQUs7S0FDdkQsZUFBZSxLQUFLO0lBQ3hCO0lBRUEsWUFBWSxjQUFjO0tBQ3RCLGVBQWUsS0FBSztJQUN4QjtJQUVBLGVBQWUsVUFBVTtHQUM3QjtFQUNKO0NBQ0osR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLHlCQUF5QjtFQUMzQixJQUFJLENBQUMsbUJBQW1CLENBQUMsZUFBZSxTQUFTO0dBQzdDLE1BQU0sNEdBQTRHO0dBQ2xIO0VBQ0o7RUFDQSxJQUFJLGFBQWE7R0FDYixlQUFlLFFBQVEsS0FBSztHQUM1QixlQUFlLEtBQUs7RUFDeEIsT0FBTztHQUNILElBQUk7SUFDQSxlQUFlLFFBQVEsTUFBTTtJQUM3QixlQUFlLElBQUk7R0FDdkIsU0FBUyxHQUFHO0lBQ1IsUUFBUSxNQUFNLENBQUM7R0FDbkI7RUFDSjtDQUNKO0NBRUEsZ0JBQWdCO0VBQ1osTUFBTSxPQUFPLGlCQUFpQjtFQUM5QixXQUFXLElBQUk7RUFDZixNQUFNLE1BQU0scUJBQXFCO0VBQ2pDLGdCQUFnQixHQUFHO0VBQ25CLGlCQUFpQixLQUFLLEtBQUssSUFBSSxDQUFDO0VBQ2hDLE1BQU0sV0FBVyxnQkFBZ0I7RUFDakMsVUFBVSxRQUFROztFQUdsQixXQUFXLENBQUMsQ0FBQyxNQUFLLFFBQU87R0FDckIsSUFBSSxJQUFJLE1BQU0sTUFBTSxRQUFRLElBQUksSUFBSSxHQUFHO0lBQ25DLGFBQWEsSUFBSSxJQUFJO0lBQ3JCLDRCQUE0QixJQUFJLEtBQUssS0FBSSxNQUFLLEVBQUUsRUFBRSxDQUFDO0dBQ3ZEO0VBQ0osQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7RUFDakIsd0JBQXdCLENBQUMsQ0FBQyxNQUFLLFFBQU87R0FDbEMsSUFBSSxJQUFJLE1BQU0sTUFBTSxRQUFRLElBQUksSUFBSSxHQUFHLHNCQUFzQixJQUFJLElBQUk7RUFDekUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7Q0FDckIsR0FBRyxDQUFDLENBQUM7Q0FFTCxnQkFBZ0I7RUFDWixJQUFJO0dBQ0EsYUFBYSxRQUFRLFlBQVksS0FBSyxVQUFVLFFBQVEsQ0FBQztFQUM3RCxRQUFRLENBQUM7RUFDVCxlQUFlLFNBQVMsZUFBZSxFQUFFLFVBQVUsU0FBUyxDQUFDO0NBQ2pFLEdBQUcsQ0FBQyxVQUFVLFVBQVUsQ0FBQztDQUV6QixNQUFNLDJCQUEyQjtFQUM3QixJQUFJLE9BQU8sUUFBUSxnREFBZ0QsR0FBRztHQUNsRSxJQUFJLG1CQUFtQixTQUFTLG1CQUFtQixRQUFRLE1BQU07R0FDakUsWUFBWSxDQUFDLENBQUM7R0FDZCxnQkFBZ0IsSUFBSTtHQUNwQixJQUFJO0lBQUUsYUFBYSxXQUFXLFVBQVU7R0FBRyxRQUFRLENBQUM7RUFDeEQ7Q0FDSjtDQUVBLE1BQU0sa0JBQWtCLE1BQU07RUFDMUIsSUFBSSxHQUFHLEVBQUUsZUFBZTtFQUN4QixNQUFNLFlBQVksa0JBQWtCLGFBQWE7RUFDakQsV0FBVyxTQUFTO0VBQ3BCLGdCQUFnQixDQUFDO0VBQ2pCLFVBQVUsVUFBVSxNQUFNLEVBQUU7RUFDNUIsaUJBQWlCLEtBQUs7Q0FDMUI7O0NBR0EsTUFBTSxxQkFBcUIsTUFBTTtFQUM3QixNQUFNLE1BQU0sRUFBRSxPQUFPO0VBQ3JCLE1BQU0sTUFBTSxFQUFFLE9BQU87RUFDckIsU0FBUyxHQUFHOztFQUdaLE1BQU0sbUJBQW1CLElBQUksTUFBTSxHQUFHLEdBQUc7RUFDekMsTUFBTSxjQUFjLGlCQUFpQixNQUFNLHFCQUFxQjtFQUVoRSxJQUFJLGFBQWE7R0FDYixtQkFBbUIsSUFBSTtHQUN2QixpQkFBaUIsWUFBWSxFQUFFLENBQUMsWUFBWSxDQUFDO0dBQzdDLG9CQUFvQixHQUFHO0VBQzNCLE9BQU87R0FDSCxtQkFBbUIsS0FBSztFQUM1QjtDQUNKO0NBRUEsTUFBTSwyQkFBMkIsU0FBUztFQUN0QyxNQUFNLG1CQUFtQixNQUFNLE1BQU0sR0FBRyxnQkFBZ0I7RUFDeEQsTUFBTSxrQkFBa0IsTUFBTSxNQUFNLGdCQUFnQjtFQUNwRCxNQUFNLFVBQVUsaUJBQWlCLFlBQVksR0FBRztFQUVoRCxNQUFNLFVBQVUsaUJBQWlCLE1BQU0sR0FBRyxPQUFPLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSztFQUN6RSxTQUFTLE9BQU87RUFDaEIsZ0JBQWdCLElBQUk7RUFDcEIsbUJBQW1CLEtBQUs7RUFDeEIsSUFBSSxTQUFTLFNBQVM7R0FDbEIsU0FBUyxRQUFRLE1BQU07RUFDM0I7Q0FDSjtDQUVBLE1BQU0sOEJBQThCLFNBQVM7RUFDekMsTUFBTSxtQkFBbUIsTUFBTSxNQUFNLEdBQUcsZ0JBQWdCO0VBQ3hELE1BQU0sa0JBQWtCLE1BQU0sTUFBTSxnQkFBZ0I7RUFDcEQsTUFBTSxVQUFVLGlCQUFpQixZQUFZLEdBQUc7RUFDaEQsTUFBTSxRQUFRLE9BQU8sS0FBSyxhQUFhLEtBQUssU0FBUyxVQUFVLENBQUMsQ0FBQyxRQUFRLHdCQUF3QixFQUFFLENBQUMsQ0FBQyxLQUFLO0VBQzFHLFNBQVMsaUJBQWlCLE1BQU0sR0FBRyxPQUFPLElBQUksb0JBQW9CLE1BQU0sS0FBSyxlQUFlO0VBQzVGLG1CQUFtQixJQUFJO0VBQ3ZCLGdCQUFnQixJQUFJO0VBQ3BCLG1CQUFtQixLQUFLO0VBQ3hCLFNBQVMsU0FBUyxNQUFNO0NBQzVCO0NBRUEsTUFBTSw4QkFBOEIsT0FBTyxTQUFTO0VBQ2hELElBQUksU0FBUyxLQUFLLFVBQVUsS0FBSyxNQUFNO0VBQ3ZDLE1BQU0sYUFBYSxLQUFLLGNBQWMsS0FBSztFQUMzQyxJQUFJLENBQUMsVUFBVSxLQUFLLFVBQVU7R0FDMUIsTUFBTSxVQUFVLE1BQU0sb0JBQW9CLEtBQUssUUFBUTtHQUN2RCxTQUFTLFNBQVMsTUFBTSxNQUFNLFNBQVMsTUFBTTtFQUNqRDtFQUNBLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxPQUFPO0dBQUUsU0FBUztHQUFxRixlQUFlLENBQUM7RUFBRTtFQUNySixJQUFJLENBQUMsUUFBUSxZQUFZLE1BQU0sUUFBUSxJQUFJLENBQ3ZDLGtCQUFrQixRQUFRLFVBQVUsR0FDcEMsb0JBQW9CLFFBQVEsVUFBVSxDQUFDLENBQUMsYUFBYSxFQUFFLElBQUksTUFBTSxFQUFFLENBQ3ZFLENBQUM7Ozs7RUFJRCxJQUFJLENBQUMsUUFBUSxNQUFNLFFBQVEsV0FBVyxLQUFLO0dBQ3ZDLE1BQU0sV0FBVyxNQUFNLHdCQUF3QixLQUFLLFVBQVUsWUFBWSxLQUFLLFVBQVU7R0FDekYsSUFBSSxVQUFVLElBQUksU0FBUztFQUMvQjtFQUNBLE1BQU0sVUFBVSxRQUFRLFFBQVEsUUFBUSxZQUFZLENBQUM7RUFDckQsTUFBTSxVQUFVLFFBQVEsV0FBVyxRQUFRLGFBQWEsUUFBUSxpQkFBaUIsUUFBUSxlQUFlLENBQUM7RUFDekcsTUFBTSxjQUFjLFVBQVUsUUFBUSxVQUFVLFlBQVksQ0FBQztFQUM3RCxNQUFNLGdCQUFnQixRQUFRLEtBQUksTUFBSztHQUNuQyxNQUFNLFVBQVUsRUFBRSxXQUFXLEVBQUUsbUJBQW1CLEVBQUUsV0FBVyxDQUFDO0dBQ2hFLElBQUksQ0FBQyxFQUFFLFlBQVksQ0FBQyxFQUFFLGdCQUFnQixDQUFDLE1BQU0sUUFBUSxPQUFPLEtBQUssUUFBUSxTQUFTLEdBQUcsT0FBTztHQUM1RixNQUFNLGFBQWEsUUFBUSxLQUFJLE1BQUssT0FBTyxNQUFNLFdBQVcsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDO0dBQzNFLE1BQU0sZ0JBQWdCLEVBQUUsaUJBQWlCLEVBQUUsaUJBQWlCLEVBQUUscUJBQXFCO0dBQ25GLE1BQU0sZUFBZSxXQUFXLFdBQVUsTUFBSyxFQUFFLGNBQWMsUUFBUSxFQUFFLFlBQVksUUFBUyxrQkFBa0IsRUFBRSxjQUFjLEVBQUUsVUFBVSxhQUFjO0dBQzFKLElBQUksZUFBZSxHQUFHLE9BQU87R0FDN0IsT0FBTztJQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUU7SUFBYyxTQUFTLFdBQVcsS0FBSSxNQUFLLEVBQUUsY0FBYyxFQUFFLFFBQVEsRUFBRTtJQUFHO0dBQWE7RUFDOUgsQ0FBQyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQztFQUM3QixPQUFPO0dBQUUsU0FBUztpQ0FDTyxLQUFLLGFBQWEsS0FBSyxTQUFTLFdBQVc7YUFDL0QsT0FBTztpQkFDSCxXQUFXO1VBQ2xCLFFBQVEsU0FBUyxLQUFLLFNBQVMsaUJBQWlCO1lBQzlDLFFBQVEsVUFBVSxLQUFLLFVBQVUsV0FBVztzQkFDbEMsS0FBSyxVQUFVLFdBQVcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxJQUFLLEVBQUU7O0VBRWhFLFFBQVEsU0FBUyxRQUFRLEtBQUssR0FBRyxNQUFNLEdBQUcsSUFBSSxFQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUUsZ0JBQWdCLElBQUksbUJBQW1CLEVBQUUsY0FBYyxFQUFFLGNBQWMsRUFBRSxVQUFVLEVBQUUsa0JBQWtCLElBQUksWUFBWSxFQUFFLGlCQUFpQixFQUFFLGlCQUFpQixFQUFFLHFCQUFxQixJQUFJLGFBQWEsRUFBRSxhQUFhLE9BQVEsRUFBRSxXQUFXLE9BQU8sbUJBQW1CLEVBQUUsVUFBVSxVQUFVLFVBQVcsRUFBRSxZQUFZLFVBQVUsU0FBUyxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUksd0RBQXdEOztHQUNyZDtFQUFjO0NBQ2I7O0NBR0EsTUFBTSx1QkFBdUIsY0FBYztFQUN2QyxJQUFJLG1CQUFtQixPQUFPLE9BQU87RUFDckMsTUFBTSxPQUFPLFNBQVMsZ0JBQWdCLEVBQUU7RUFDeEMsTUFBTSxTQUFTLElBQUksS0FBSztFQUN4QixPQUFPLFFBQVEsT0FBTyxRQUFRLElBQUksSUFBSTtFQUN0QyxPQUFPLFVBQVUsUUFBTyxNQUFLLEVBQUUsYUFBYSxJQUFJLEtBQUssRUFBRSxTQUFTLEtBQUssTUFBTTtDQUMvRSxHQUFHLENBQUMsV0FBVyxjQUFjLENBQUM7Q0FFOUIsTUFBTSw0QkFBNEI7RUFDOUIsTUFBTSxxQkFBcUIscUJBQXFCLEtBQUksTUFBSyxFQUFFLEVBQUU7RUFDN0QsTUFBTSxjQUFjLG1CQUFtQixPQUFNLE9BQU0seUJBQXlCLFNBQVMsRUFBRSxDQUFDO0VBQ3hGLElBQUksYUFBYTtHQUNiLDZCQUE0QixTQUFRLEtBQUssUUFBTyxPQUFNLENBQUMsbUJBQW1CLFNBQVMsRUFBRSxDQUFDLENBQUM7RUFDM0YsT0FBTztHQUNILDZCQUE0QixTQUFRLE1BQU0sS0FBSyxJQUFJLElBQUksQ0FBQyxHQUFHLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7RUFDN0Y7Q0FDSjtDQUVBLE1BQU0sMkJBQTJCLE9BQU87RUFDcEMsNkJBQTRCLFNBQ3hCLEtBQUssU0FBUyxFQUFFLElBQUksS0FBSyxRQUFPLE1BQUssTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHLE1BQU0sRUFBRSxDQUNqRTtDQUNKOztDQUdBLE1BQU0scUJBQXFCLE9BQU8sUUFBUSxXQUFXLFNBQVMsVUFBVTtFQUNwRSxJQUFJO0dBQ0EsTUFBTSxvQkFBb0IsUUFBUSxNQUFNO0dBQ3hDLGFBQVksU0FBUSxDQUNoQixHQUFHLE1BQ0g7SUFDSSxJQUFJLEtBQUssSUFBSTtJQUNiLFFBQVE7SUFDUixNQUFNLHdDQUF3QyxVQUFVLHFCQUFxQixPQUFPLFlBQVksRUFBRTtJQUNsRyxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUN0QyxDQUNKLENBQUM7RUFDTCxTQUFTLEtBQUs7R0FDVixNQUFNLDBCQUEwQixJQUFJLFNBQVM7RUFDakQ7Q0FDSjs7Q0FHQSxNQUFNLG9CQUFvQixPQUFPLGFBQWEsaUJBQWlCLGVBQWU7RUFDMUUsSUFBSSxZQUFZLFdBQVcsR0FBRztFQUM5QixpQkFBaUIsSUFBSTtFQUNyQixnQkFBZ0I7R0FBRSxTQUFTO0dBQUcsT0FBTyxZQUFZO0dBQVEsTUFBTTtFQUFHLENBQUM7RUFDbkUsaUJBQWlCLEtBQUs7RUFFdEIsSUFBSTtHQUNBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxZQUFZLFFBQVEsS0FBSztJQUN6QyxNQUFNLElBQUksWUFBWTtJQUN0QixnQkFBZ0I7S0FBRSxTQUFTLElBQUk7S0FBRyxPQUFPLFlBQVk7S0FBUSxNQUFNLEVBQUU7SUFBTSxDQUFDO0lBRTVFLElBQUk7S0FDQSxNQUFNLG9CQUFvQixFQUFFLElBQUksS0FBSztJQUN6QyxRQUFRLENBQUM7O0lBR1QsTUFBTSxJQUFJLFNBQVEsTUFBSyxXQUFXLEdBQUcsR0FBRyxDQUFDO0dBQzdDO0dBRUEsYUFBWSxTQUFRLENBQ2hCLEdBQUcsTUFDSDtJQUNJLElBQUksS0FBSyxJQUFJO0lBQ2IsUUFBUTtJQUNSLE1BQU0sMkVBQTJFLFlBQVksT0FBTyxlQUFlLGVBQWU7SUFDbEksV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDdEMsQ0FDSixDQUFDO0VBQ0wsU0FBUyxLQUFLO0dBQ1YsYUFBWSxTQUFRLENBQ2hCLEdBQUcsTUFDSDtJQUNJLElBQUksS0FBSyxJQUFJO0lBQ2IsUUFBUTtJQUNSLE1BQU0sa0RBQWtELElBQUk7SUFDNUQsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDdEMsQ0FDSixDQUFDO0VBQ0wsVUFBVTtHQUNOLGlCQUFpQixLQUFLO0dBQ3RCLGdCQUFnQixJQUFJO0VBQ3hCO0NBQ0o7O0NBR0EsTUFBTSx1QkFBdUIsT0FBTyxlQUFlO0VBQy9DLElBQUksQ0FBQyxZQUFZLE9BQU87RUFFeEIsSUFBSTs7R0FFQSxJQUFJLGVBQWUsQ0FBQztHQUNwQixJQUFJO0lBQ0EsSUFBSSxPQUFPO0lBQ1gsSUFBSSxhQUFhO0lBQ2pCLEdBQUc7S0FDQyxNQUFNLE1BQU0sTUFBTSxpQkFBaUIsV0FBVyxJQUFJO01BQUU7TUFBTSxVQUFVO0tBQUksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUU7S0FDM0YsSUFBSSxLQUFLLElBQUk7TUFDVCxNQUFNLFlBQVksTUFBTSxRQUFRLElBQUksSUFBSSxJQUFJLElBQUksT0FBUSxJQUFJLE1BQU0sU0FBUyxDQUFDO01BQzVFLGVBQWUsQ0FBQyxHQUFHLGNBQWMsR0FBRyxTQUFTO01BQzdDLE1BQU0sS0FBSyxJQUFJLGNBQWMsSUFBSSxNQUFNO01BQ3ZDLGFBQWEsSUFBSSxjQUFjLEtBQUssTUFBTSxJQUFJLGNBQWMsYUFBYSxVQUFVLEdBQUcsS0FBSztLQUMvRixPQUFPO01BQ0g7S0FDSjtLQUNBO0lBQ0osU0FBUyxRQUFRLGNBQWMsUUFBUTtHQUMzQyxRQUFRLENBQUM7R0FFVCxNQUFNLENBQUMsWUFBWSxjQUFjLGVBQWUsZ0JBQWdCLE1BQU0sUUFBUSxJQUFJO0lBQzlFLFlBQVksV0FBVyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRTtJQUMzQyxhQUFhLFdBQVcsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUU7SUFDNUMsa0JBQWtCLFdBQVcsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUU7SUFDakQsaUJBQWlCLFdBQVcsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUU7R0FDcEQsQ0FBQztHQUVELE1BQU0sUUFBUSxXQUFXLFFBQVE7R0FDakMsTUFBTSxRQUFRLE1BQU0sUUFBUSxhQUFhLElBQUksSUFBSSxhQUFhLE9BQU8sQ0FBQztHQUN0RSxNQUFNLFFBQVE7R0FDZCxNQUFNLFFBQVEsY0FBYyxRQUFRLENBQUM7R0FDckMsTUFBTSxRQUFRLGFBQWEsUUFBUSxDQUFDOztHQUdwQyxNQUFNLGtCQUFrQixNQUNuQixRQUFPLE1BQUssRUFBRSxTQUFTLFFBQVEsQ0FBQyxNQUFNLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQ3ZELEtBQUksT0FBTTtJQUNQLE1BQU0sRUFBRSxrQkFBa0IsRUFBRSxhQUFhLGNBQWMsRUFBRTtJQUN6RCxPQUFPLE9BQU8sRUFBRSxLQUFLO0lBQ3JCLGFBQWEsRUFBRSxlQUFlO0lBQzlCLGlCQUFpQixFQUFFLG1CQUFtQjtHQUMxQyxFQUFFLENBQUMsQ0FDRixNQUFNLEdBQUcsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFLO0dBRXJDLE1BQU0sbUJBQW1CLE1BQU07R0FDL0IsTUFBTSxnQkFBZ0IsZ0JBQWdCLFNBQVMsSUFBSSxnQkFBZ0IsS0FBSztHQUN4RSxNQUFNLGVBQWUsZ0JBQWdCLFNBQVMsSUFBSSxnQkFBZ0IsZ0JBQWdCLFNBQVMsS0FBSztHQUNoRyxNQUFNLFdBQVcsZ0JBQWdCLFNBQVMsS0FDbkMsZ0JBQWdCLFFBQVEsS0FBSyxTQUFTLE1BQU0sS0FBSyxPQUFPLENBQUMsSUFBSSxnQkFBZ0IsT0FBTSxDQUFFLFFBQVEsQ0FBQyxJQUM5RixNQUFNLGdCQUFnQixPQUFPLE9BQU8sTUFBTSxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSTs7R0FHNUUsTUFBTSxvQkFBb0IsTUFBTSxRQUFPLE1BQUssRUFBRSxlQUFlLEtBQUs7R0FDbEUsTUFBTSxZQUFZLGtCQUFrQixLQUFJLE1BQU0sRUFBRSxVQUFVLFFBQVEsT0FBTyxFQUFFLE1BQU0sSUFBSSxJQUFJLE9BQU8sRUFBRSxNQUFNLElBQUksQ0FBRTtHQUM5RyxNQUFNLGlCQUFpQixVQUFVLFFBQVEsS0FBSyxNQUFNLE1BQU0sR0FBRyxDQUFDO0dBQzlELE1BQU0sa0JBQWtCLFVBQVUsU0FBUyxJQUFJLEtBQUssSUFBSSxHQUFHLFNBQVMsSUFBSTtHQUN4RSxNQUFNLGlCQUFpQixVQUFVLFNBQVMsSUFBSSxLQUFLLElBQUksR0FBRyxTQUFTLElBQUk7R0FDdkUsTUFBTSxrQkFBa0IsVUFBVSxTQUFTLEtBQU0sb0JBQW9CO0dBRXJFLE1BQU0sd0JBQXdCLE1BQ3pCLEtBQUssR0FBRyxTQUFTO0lBQUUsR0FBRztJQUFHLFNBQVMsTUFBTTtJQUFHLFVBQVUsRUFBRSxVQUFVLFFBQVEsT0FBTyxFQUFFLE1BQU0sSUFBSSxJQUFJLE9BQU8sRUFBRSxNQUFNLElBQUk7R0FBRSxFQUFFLENBQUMsQ0FDeEgsUUFBTyxNQUFLLEVBQUUsZUFBZSxTQUFTLEVBQUUsYUFBYSxlQUFlOztHQUd6RSxNQUFNLFdBQVcsTUFBTSxRQUFRLE1BQU0sUUFBUSxJQUFJLE1BQU0sV0FBVyxDQUFDO0dBQ25FLE1BQU0sZUFBZSxTQUNoQixRQUFPLE1BQU0sRUFBRSxrQkFBa0IsRUFBRSxpQkFBaUIsS0FBTyxFQUFFLGNBQWMsRUFBRSxXQUFXLFNBQVMsQ0FBRSxDQUFDLENBQ3BHLEtBQUksT0FBTTtJQUNQLE1BQU0sRUFBRSxlQUFlLEVBQUUsa0JBQWtCO0lBQzNDLGFBQWEsRUFBRSxrQkFBa0I7SUFDakMsUUFBUSxFQUFFLFVBQVU7SUFDcEIsYUFBYSxFQUFFLGNBQWMsQ0FBQyxFQUFDLENBQUUsS0FBSSxNQUFLLEdBQUcsRUFBRSxVQUFVLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxLQUFLLElBQUk7R0FDN0YsRUFBRTs7R0FHTixNQUFNLGVBQWU7SUFBRSxHQUFHO0lBQVMsR0FBRztJQUFpQixHQUFHO0lBQVksR0FBRztJQUFhLEdBQUc7R0FBYztHQUN2RyxNQUFNLGdCQUFnQixNQUFNLEtBQUssR0FBRyxRQUFRO0lBQ3hDLE1BQU0sV0FBVyxhQUFhLEVBQUUsV0FBVyxRQUFRLEVBQUU7SUFDckQsTUFBTSxhQUFhLEVBQUUsU0FBUyxNQUFLLE1BQUssRUFBRSxTQUFTLENBQUMsRUFBRSxjQUFjLEVBQUUsa0JBQWtCLEVBQUUsZUFBZSxRQUFRLG9CQUFvQjtJQUNySSxNQUFNLFlBQVksRUFBRSxlQUFlLFFBQzdCLDJCQUNBLEVBQUUsVUFBVSxPQUNaLEdBQUcsRUFBRSxPQUFPLFNBQ1o7SUFDTixPQUFPLEdBQUcsTUFBTSxFQUFFLFdBQVcsU0FBUyxLQUFLLEVBQUUsU0FBUyxhQUFhLFVBQVUsWUFBWSxFQUFFLGFBQWEsT0FBTyxRQUFRLCtCQUErQjtHQUMxSixDQUFDOztHQUdELE1BQU0sWUFBWSxNQUFNLFlBQVksQ0FBQztHQUNyQyxNQUFNLFlBQWEsTUFBTSxpQkFBaUIsVUFBVSxnQkFDOUMsR0FBRyxLQUFLLE9BQU8sTUFBTSxpQkFBaUIsVUFBVSxpQkFBaUIsRUFBRSxFQUFFLFVBQ3JFO0dBRU4sT0FBTzs4QkFDVyxNQUFNLFNBQVMsV0FBVyxNQUFNO2lCQUM3QyxXQUFXLEdBQUc7ZUFDaEIsTUFBTSxlQUFlLElBQUk7WUFDNUIsTUFBTSxVQUFVLFlBQVk7c0JBQ2xCLE1BQU0sT0FBTyxVQUFVLGtCQUFrQixPQUFPLFlBQVksTUFBTSxTQUFTLGtCQUFrQixPQUFPOzJCQUMvRixpQkFBaUI7NkJBQ2YsVUFBVSxpQkFBaUIsTUFBTSxjQUFjLFVBQVUsYUFBYSxVQUFVLFlBQVksZ0JBQWdCLE1BQU0sc0JBQXNCLFVBQVUscUJBQXFCLE9BQU8sUUFBUTs7O2tDQUdqTCxlQUFlOzJCQUN0QixrQkFBa0IsK0JBQStCLGdCQUFnQixvQkFBb0IsMEJBQTBCLGdCQUFnQixtQkFBbUIsZUFBZSxRQUFROzRDQUN4SixnQkFBZ0I7RUFDMUQsc0JBQXNCLFNBQVMsSUFDM0Isc0JBQXNCLEtBQUksTUFBSyxnQkFBZ0IsRUFBRSxRQUFRLElBQUksRUFBRSxXQUFXLEVBQUUsU0FBUyxNQUFNLEdBQUcsRUFBRSxJQUFJLGNBQWMsU0FBUyxFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUMsS0FBSyxJQUFJLElBQ3ZKLHdDQUF3Qzs7O3FCQUd6QixhQUFhLE1BQU0sR0FBRyxTQUFTLEtBQUssSUFBSTtxQkFDeEMsZ0JBQWdCLEdBQUcsY0FBYyxLQUFLLFVBQVUsY0FBYyxNQUFNLE1BQU0sdUJBQXVCO29CQUNsRyxlQUFlLEdBQUcsYUFBYSxLQUFLLFVBQVUsYUFBYSxNQUFNLE1BQU0sdUJBQXVCO3VCQUMzRixtQkFBbUIsS0FBSyxnQkFBZ0IsV0FBVyxJQUNwRSxZQUFZLGlCQUFpQiw2SkFDN0IsWUFBWSxnQkFBZ0IsT0FBTyxRQUFRLGlCQUFpQiw0Q0FBNEM7O0VBRTVHLGdCQUFnQixTQUFTLElBQ3JCLGdCQUFnQixLQUFLLEdBQUcsTUFBTSxLQUFLLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxXQUFXLEVBQUUsTUFBTSxjQUFjLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksSUFDaEgsK0NBQStDOzs7NENBR1QsTUFBTSxtQkFBbUIsRUFBRTs7RUFFckUsYUFBYSxTQUFTLElBQ2xCLGFBQWEsS0FBSSxNQUFLLE9BQU8sRUFBRSxLQUFLLElBQUksRUFBRSxZQUFZLG1DQUFtQyxFQUFFLE9BQU8sR0FBRyxFQUFFLGFBQWEsVUFBVSxFQUFFLGVBQWUsSUFBSSxDQUFDLENBQUMsS0FBSyxJQUFJLElBQzlKLHdFQUF3RTs7O0VBRzVFLGNBQWMsS0FBSyxJQUFJLEVBQUU7O0VBRW5CLFNBQVMsS0FBSztHQUNWLE9BQU87c0JBQ0csV0FBVyxNQUFNO2dDQUNQLElBQUksUUFBUTs7RUFFcEM7Q0FDSjtDQUVBLE1BQU0sb0JBQW9CLE9BQU8sTUFBTTtFQUNuQyxJQUFJLEdBQUcsRUFBRSxlQUFlO0VBQ3hCLE1BQU0sUUFBUSxNQUFNLEtBQUs7RUFDekIsSUFBSyxDQUFDLFNBQVMsQ0FBQyxnQkFBaUIsU0FBUztFQUUxQyxNQUFNLFVBQVUsVUFBVSxnQkFBZ0IsRUFBQyxDQUFFLEtBQUs7RUFDbEQsSUFBSSxDQUFDLFFBQVE7R0FDVCxpQkFBaUIsSUFBSTtHQUNyQjtFQUNKOztFQUdBLElBQUksY0FBYztHQUNkLE1BQU0sY0FBYztHQUNwQixNQUFNLFVBQVU7SUFDWixJQUFJLEtBQUssSUFBSTtJQUNiLFFBQVE7SUFDUixNQUFNLFNBQVMsMkNBQTJDLFlBQVk7SUFDdEUsa0JBQWtCO0tBQUUsTUFBTSxZQUFZO0tBQU0sT0FBTyxZQUFZLE9BQU8sS0FBSSxDQUFFLFFBQVEsQ0FBQyxJQUFJO0lBQU07SUFDL0YsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDdEM7R0FFQSxhQUFZLFNBQVEsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDO0dBQ3RDLGdCQUFnQixJQUFJO0dBQ3BCLFNBQVMsRUFBRTtHQUNYLFdBQVcsSUFBSTs7R0FHZixNQUFNLFdBQVcsS0FBSyxJQUFJLElBQUk7R0FDOUIsYUFBWSxTQUFRLENBQ2hCLEdBQUcsTUFDSDtJQUNJLElBQUk7SUFDSixRQUFRO0lBQ1IsTUFBTSwrQkFBK0IsWUFBWSxLQUFLO0lBQ3RELFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0dBQ3RDLENBQ0osQ0FBQztHQUVELElBQUk7SUFDQSxNQUFNLE1BQU0sTUFBTSw4QkFBOEI7S0FDNUMsTUFBTTtLQUNOLGFBQWEsU0FBUztLQUN0QixjQUFjO0tBQ2QsV0FBVyxPQUFPO01BQ2QsYUFBWSxTQUFRLEtBQUssS0FBSSxRQUFPLElBQUksT0FBTyxXQUFXO09BQUUsR0FBRztPQUFLLE1BQU07TUFBRyxJQUFJLEdBQUcsQ0FBQztLQUN6RjtJQUNKLENBQUM7SUFFRCxJQUFJLElBQUksTUFBTSxNQUFNLFFBQVEsSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLFNBQVMsR0FBRztLQUMxRCxhQUFZLFNBQVEsS0FBSyxLQUFJLFFBQU8sSUFBSSxPQUFPLFdBQVc7TUFDdEQsR0FBRztNQUNILE1BQU0seUNBQXlDLElBQUksS0FBSyxPQUFPLHVDQUF1QyxZQUFZLEtBQUssT0FBTyxJQUFJLFdBQVc7TUFDN0ksWUFBWTtPQUNSLE1BQU07T0FDTixXQUFXLElBQUk7T0FDZixVQUFVLFlBQVk7T0FDdEIsV0FBVyxJQUFJO09BQ2YsWUFBWSxJQUFJO01BQ3BCO0tBQ0osSUFBSSxHQUFHLENBQUM7SUFDWixPQUFPO0tBQ0gsYUFBWSxTQUFRLEtBQUssS0FBSSxRQUFPLElBQUksT0FBTyxXQUFXO01BQ3RELEdBQUc7TUFDSCxNQUFNLDRDQUE0QyxJQUFJLFdBQVc7S0FDckUsSUFBSSxHQUFHLENBQUM7SUFDWjtHQUNKLFNBQVMsS0FBSztJQUNWLGFBQVksU0FBUSxLQUFLLEtBQUksUUFBTyxJQUFJLE9BQU8sV0FBVztLQUN0RCxHQUFHO0tBQ0gsTUFBTSw0Q0FBNEMsSUFBSTtJQUMxRCxJQUFJLEdBQUcsQ0FBQztHQUNaLFVBQVU7SUFDTixXQUFXLEtBQUs7R0FDcEI7R0FDQTtFQUNKOztFQUdBLElBQUksbUJBQW1CO0VBQ3ZCLElBQUkseUJBQXlCO0VBQzdCLElBQUksd0JBQXdCLENBQUM7RUFDN0IsTUFBTSxrQkFBa0IsbUJBQW1CLG1CQUFtQixNQUFLLFNBQVE7R0FDdkUsTUFBTSxRQUFRLEtBQUssYUFBYSxLQUFLLFNBQVM7R0FDOUMsT0FBTyxNQUFNLFlBQVksQ0FBQyxDQUFDLFNBQVMsb0JBQW9CLE1BQU0sWUFBWSxHQUFHO0VBQ2pGLENBQUM7RUFDRCxJQUFJLGlCQUFpQjtHQUNqQixJQUFJO0lBQ0EsTUFBTSxjQUFjLE1BQU0sNEJBQTRCLGVBQWU7SUFDckUseUJBQXlCLFlBQVk7SUFDckMsd0JBQXdCLFlBQVk7R0FDeEMsU0FDTyxLQUFLO0lBQUUseUJBQXlCLDJEQUEyRCxJQUFJLFFBQVE7R0FBSztFQUN2SDtFQUNBLElBQUksQ0FBQyxrQkFBa0I7R0FDbkIsTUFBTSxrQkFBa0IsVUFBVSxNQUFLLE1BQUssTUFBTSxTQUFTLElBQUksRUFBRSxPQUFPLENBQUM7R0FDekUsSUFBSSxpQkFBaUI7SUFDakIsbUJBQW1CO0dBQ3ZCO0VBQ0o7RUFFQSxNQUFNLFVBQVU7R0FDWixJQUFJLEtBQUssSUFBSTtHQUNiLFFBQVE7R0FDUixNQUFNO0dBQ04sYUFBYSxtQkFBbUI7SUFBRSxJQUFJLGlCQUFpQjtJQUFJLE9BQU8saUJBQWlCO0dBQU0sSUFBSTtHQUM3Rix3QkFBd0Isa0JBQWtCLEVBQUUsV0FBVyxnQkFBZ0IsYUFBYSxnQkFBZ0IsTUFBTSxJQUFJO0dBQzlHLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ3RDO0VBRUEsYUFBWSxTQUFRLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQztFQUN0QyxTQUFTLEVBQUU7RUFDWCxtQkFBbUIsS0FBSzs7RUFFeEIsV0FBVyxJQUFJO0VBRWYsTUFBTSxhQUFhLE1BQU0sWUFBWTs7RUFHckMsTUFBTSxpQkFBaUIsV0FBVyxTQUFTLFFBQVEsS0FBSyxXQUFXLFNBQVMsUUFBUSxLQUFLLFdBQVcsU0FBUyxPQUFPLEtBQUssV0FBVyxTQUFTLFVBQVU7RUFDdkosTUFBTSxTQUFTLFdBQVcsU0FBUyxRQUFRLEtBQUssV0FBVyxTQUFTLFFBQVEsS0FBSyxXQUFXLFNBQVMsTUFBTSxLQUFLLFdBQVcsU0FBUyxZQUFZLEtBQUssV0FBVyxTQUFTLGdCQUFnQjtFQUV6TCxJQUFJLGdCQUFnQjtHQUNoQixJQUFJLFVBQVcsQ0FBQyxvQkFBb0IsVUFBVSxTQUFTLEdBQUk7O0lBRXZELGFBQVksU0FBUSxDQUNoQixHQUFHLE1BQ0g7S0FDSSxJQUFJLEtBQUssSUFBSSxJQUFJO0tBQ2pCLFFBQVE7S0FDUixNQUFNO0tBQ04sWUFBWTtNQUNSLE1BQU07TUFDTixZQUFZLFVBQVU7S0FDMUI7S0FDQSxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtJQUN0QyxDQUNKLENBQUM7SUFDRCxpQkFBaUIsSUFBSTtJQUNyQixXQUFXLEtBQUs7SUFDaEI7R0FDSixPQUFPLElBQUksa0JBQWtCOztJQUV6QixhQUFZLFNBQVEsQ0FDaEIsR0FBRyxNQUNIO0tBQ0ksSUFBSSxLQUFLLElBQUksSUFBSTtLQUNqQixRQUFRO0tBQ1IsTUFBTSwwRUFBMEUsaUJBQWlCLE1BQU07S0FDdkcsWUFBWTtNQUNSLE1BQU07TUFDTixNQUFNO0tBQ1Y7S0FDQSxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtJQUN0QyxDQUNKLENBQUM7SUFDRCxXQUFXLEtBQUs7SUFDaEI7R0FDSjtFQUNKOztFQUdBLE1BQU0sbUJBQW1CLHFCQUFxQixLQUFLLFVBQVU7RUFDN0QsTUFBTSx5QkFBeUIsd0ZBQXdGLEtBQUssVUFBVTtFQUN0SSxNQUFNLG1CQUFtQixXQUFXLFNBQVMsVUFBVSxLQUFLLFdBQVcsU0FBUyxjQUFjLEtBQUssQ0FBQyxDQUFDO0VBRXJHLE1BQU0sbUJBQW1CLG9CQUFvQiwyQkFBMkIsb0JBQW9CLFVBQVUsU0FBUztFQUUvRyxNQUFNLHdCQUF3QixDQUFDLG9CQUFvQiwwQkFBMEIsd0JBQXdCLEtBQUssVUFBVTtFQUVwSCxJQUFJLGtCQUFrQjtHQUNsQixNQUFNLFNBQVMsb0JBQW9CLFVBQVU7R0FDN0MsSUFBSSxRQUFRO0lBQ1IsYUFBWSxTQUFRLENBQ2hCLEdBQUcsTUFDSDtLQUNJLElBQUksS0FBSyxJQUFJLElBQUk7S0FDakIsUUFBUTtLQUNSLE1BQU0sMkRBQTJELE9BQU8sTUFBTTtLQUM5RSxnQkFBZ0I7TUFDWixPQUFPLHNCQUFzQixPQUFPO01BQ3BDLE1BQU0sVUFBVSxPQUFPLEdBQUc7TUFDMUIsTUFBTTtLQUNWO0tBQ0EsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7SUFDdEMsQ0FDSixDQUFDO0lBQ0QsV0FBVyxLQUFLO0lBQ2hCO0dBQ0o7RUFDSjtFQUVBLElBQUkseUJBQXlCLENBQUMsV0FBVyxTQUFTLGFBQWEsS0FBSyxDQUFDLFdBQVcsU0FBUyxLQUFLLEtBQUssQ0FBQyxXQUFXLFNBQVMsUUFBUSxHQUFHO0dBQy9ILGFBQVksU0FBUSxDQUNoQixHQUFHLE1BQ0g7SUFDSSxJQUFJLEtBQUssSUFBSSxJQUFJO0lBQ2pCLFFBQVE7SUFDUixNQUFNO0lBQ04sZ0JBQWdCO0tBQ1osT0FBTztLQUNQLE1BQU07S0FDTixNQUFNO0lBQ1Y7SUFDQSxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUN0QyxDQUNKLENBQUM7R0FDRCxXQUFXLEtBQUs7R0FDaEI7RUFDSjs7RUFHQSxNQUFNLFdBQVcsTUFBTSxNQUFNLG9CQUFvQjtFQUNqRCxJQUFJLHNCQUFzQjtFQUMxQixJQUFJLGNBQWM7RUFFbEIsSUFBSSxVQUFVO0dBQ1YsTUFBTSxjQUFjLFNBQVM7R0FDN0IsSUFBSTtJQUNBLE1BQU0sWUFBWSxNQUFNLHNCQUFzQixjQUFjLE9BQU87O0lBRW5FLENBQUM7SUFDRCxJQUFJLFVBQVUsTUFBTSxVQUFVLFNBQVM7S0FDbkMsY0FBYztLQUNkLHNCQUFzQixnREFBZ0QsVUFBVSxLQUFLLFlBQVksRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLGdCQUFnQixVQUFVLElBQUksZ0NBQWdDLFVBQVUsUUFBUSxNQUFNLEdBQUcsR0FBSyxFQUFFO0lBQ3ZPO0dBQ0osU0FBUyxLQUFLO0lBQ1YsUUFBUSxLQUFLLHlCQUF5QixHQUFHO0dBQzdDO0VBQ0o7RUFFQSxJQUFJLGNBQWM7RUFDbEIsSUFBSSxrQkFBa0I7R0FDbEIsY0FBYyxNQUFNLHFCQUFxQixnQkFBZ0I7RUFDN0QsT0FBTztHQUNILGNBQWM7a0NBQ1EsVUFBVSxPQUFPO0VBQ2pELFVBQVUsS0FBSyxHQUFHLE1BQU0sR0FBRyxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sU0FBUyxFQUFFLEdBQUcsWUFBWSxFQUFFLFVBQVUsU0FBUyxtQkFBbUIsRUFBRSxpQkFBaUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRTs7RUFFOUk7RUFDQSxJQUFJLHdCQUF3QixlQUFlO0VBRTNDLElBQUkscUJBQXFCO0dBQ3JCLGVBQWU7RUFDbkI7RUFFQSxNQUFNLGVBQWU7Ozs7Ozs7Ozs7RUFVM0IsWUFBWTtFQUNaLEtBQUs7O0VBR0MsTUFBTSxlQUFlLEtBQUssSUFBSSxJQUFJO0VBQ2xDLGFBQVksU0FBUSxDQUNoQixHQUFHLE1BQ0g7R0FDSSxJQUFJO0dBQ0osUUFBUTtHQUNSLE1BQU07R0FDTixhQUFhLG1CQUFtQjtJQUFFLElBQUksaUJBQWlCO0lBQUksT0FBTyxpQkFBaUI7R0FBTSxJQUFJO0dBQzdGLFNBQVMsY0FBYztJQUFFLE1BQU0sWUFBWTtJQUFNLE9BQU8sWUFBWTtJQUFPLEtBQUssWUFBWTtHQUFJLElBQUk7R0FDcEcsWUFBWSxrQkFBa0I7SUFBRSxNQUFNO0lBQW9CLFFBQVEsV0FBVyxnQkFBZ0IsY0FBYyxnQkFBZ0I7SUFBTSxXQUFXO0dBQXNCLElBQUk7R0FDdEssV0FBVztHQUNYLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ3RDLENBQ0osQ0FBQztFQUVELElBQUksbUJBQW1CO0VBQ3ZCLElBQUksVUFBVTtFQUNkLE1BQU0sY0FBYyxLQUFLLElBQUksR0FBRyxRQUFRLE1BQU07RUFFOUMsSUFBSTtHQUNBLE9BQU8sVUFBVSxhQUFhO0lBQzFCO0lBQ0osSUFBSTtLQUNBLG1CQUFtQixVQUFVLElBQUksZ0JBQWdCO0tBQ2pELE1BQU0sV0FBVywyREFBMkQsY0FBYyw2QkFBNkIsaUJBQWlCO0tBRXhJLE1BQU0sV0FBVyxNQUFNLE1BQU0sVUFBVTtNQUNuQyxRQUFRO01BQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7TUFDOUMsTUFBTSxLQUFLLFVBQVU7T0FDakIsVUFBVSxDQUNOO1FBQUUsTUFBTTtRQUFRLE9BQU8sQ0FBQyxFQUFFLE1BQU0sR0FBRyxhQUFhLDRCQUE0QixNQUFNLEdBQUcsQ0FBQztPQUFFLENBQzVGO09BQ0Esa0JBQWtCLEVBQUUsYUFBYSxHQUFJO01BQ3pDLENBQUM7TUFDRCxRQUFRLG1CQUFtQixRQUFRO0tBQ3ZDLENBQUM7S0FFRCxJQUFJLENBQUMsU0FBUyxJQUFJO01BQ2QsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRTtNQUN0RCxNQUFNLFNBQVMsUUFBUSxPQUFPLFdBQVcsUUFBUSxTQUFTO01BQzFELEtBQUssU0FBUyxXQUFXLE9BQU8sU0FBUyxXQUFXLFFBQVEsUUFBUSxTQUFTLEdBQUc7T0FDNUUsTUFBTSxVQUFVLG1CQUFtQjtPQUNuQyxtQkFBbUIsUUFBUTtPQUMzQixnQkFBZ0IsUUFBUSxLQUFLO09BQzdCLFVBQVUsUUFBUSxHQUFHOztPQUVyQjtNQUNKO01BQ0EsTUFBTSxJQUFJLE1BQU0sTUFBTTtLQUMxQjtLQUVBLE1BQU0sU0FBUyxTQUFTLEtBQUssVUFBVTtLQUN2QyxNQUFNLFVBQVUsSUFBSSxZQUFZO0tBQ2hDLElBQUksa0JBQWtCO0tBQ3RCLElBQUksU0FBUztLQUViLE9BQU8sTUFBTTtNQUNULE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxPQUFPLEtBQUs7TUFDMUMsSUFBSSxNQUFNO01BRVYsVUFBVSxRQUFRLE9BQU8sT0FBTyxFQUFFLFFBQVEsS0FBSyxDQUFDO01BQ2hELE1BQU0sUUFBUSxPQUFPLE1BQU0sSUFBSTtNQUMvQixTQUFTLE1BQU0sSUFBSSxLQUFLO01BRXhCLEtBQUssTUFBTSxRQUFRLE9BQU87T0FDdEIsSUFBSSxDQUFDLEtBQUssV0FBVyxRQUFRLEdBQUc7T0FDaEMsTUFBTSxVQUFVLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLO09BQ25DLElBQUksWUFBWSxVQUFVO09BRTFCLElBQUk7UUFDQSxNQUFNLFNBQVMsS0FBSyxNQUFNLE9BQU87UUFDakMsTUFBTSxRQUFRLE9BQU8sYUFBYSxFQUFFLEVBQUUsU0FBUyxRQUFRLEVBQUUsRUFBRSxRQUFRO1FBQ25FLElBQUksT0FBTztTQUNQLG1CQUFtQjtTQUNuQixhQUFZLFNBQ1IsS0FBSyxLQUFJLFFBQ0wsSUFBSSxPQUFPLGVBQ0w7VUFBRSxHQUFHO1VBQUssTUFBTTtTQUFnQixJQUNoQyxHQUNWLENBQ0o7UUFDSjtPQUNKLFFBQVEsQ0FBQztNQUNiO0tBQ0o7S0FFQSxJQUFJLENBQUMsZ0JBQWdCLEtBQUssR0FBRztNQUN6QixhQUFZLFNBQ1IsS0FBSyxLQUFJLFFBQ0wsSUFBSSxPQUFPLGVBQ0w7T0FBRSxHQUFHO09BQUssTUFBTTtNQUF5RSxJQUN6RixHQUNWLENBQ0o7S0FDSjtLQUNBO0lBQ0osU0FBUyxLQUFLO0tBQ1YsSUFBSSxJQUFJLFNBQVMsY0FBYztNQUMzQjtLQUNKO0tBQ0EsSUFBSSxXQUFXLGFBQWE7TUFDeEIsYUFBWSxTQUNSLEtBQUssS0FBSSxRQUNMLElBQUksT0FBTyxlQUNMO09BQUUsR0FBRztPQUFLLE1BQU0sd0NBQXdDLGNBQWMsS0FBSyxJQUFJLFFBQVE7TUFBc0MsSUFDN0gsR0FDVixDQUNKO0tBQ0o7SUFDSjtHQUNKO0VBQ0EsVUFBVTtHQUNOLFdBQVcsS0FBSztHQUNoQixtQkFBbUIsVUFBVTtFQUNqQztDQUNKO0NBRUEsTUFBTSw4QkFBOEIsWUFBWTtFQUM1QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLGFBQWEsZ0JBQWdCLFVBQVUsV0FBVyxHQUFHO0VBQzlGLG9CQUFvQixJQUFJO0VBQ3hCLElBQUk7R0FDQSxJQUFJLFNBQVM7R0FDYixJQUFJLFlBQVk7R0FFaEIsSUFBSSxXQUFXLE9BQU87SUFDbEIsTUFBTSxZQUFZLGdCQUFnQixXQUFXLGdCQUFnQixTQUFTLFFBQVEsYUFBYSxFQUFFLElBQUk7SUFDakcsTUFBTSxZQUFZLE1BQU0sV0FBVztLQUMvQixPQUFPLGFBQWE7S0FDcEIsYUFBYSwwREFBMEQsZ0JBQWdCLFNBQVM7SUFDcEcsQ0FBQztJQUNELElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQyxVQUFVLE1BQU0sSUFBSTtLQUN0QyxNQUFNLElBQUksTUFBTSxVQUFVLFdBQVcsOEJBQThCO0lBQ3ZFO0lBQ0EsU0FBUyxVQUFVLEtBQUs7SUFDeEIsWUFBWSxVQUFVLEtBQUs7R0FDL0IsT0FBTztJQUNILE1BQU0sUUFBUSxVQUFVLE1BQUssTUFBSyxPQUFPLEVBQUUsRUFBRSxNQUFNLE9BQU8sTUFBTSxDQUFDO0lBQ2pFLFlBQVksT0FBTyxTQUFTLGFBQWE7R0FDN0M7R0FFQSxNQUFNLFNBQVMsTUFBTSxhQUFhLFFBQVEsZ0JBQWdCLFNBQVM7R0FDbkUsSUFBSSxDQUFDLE9BQU8sSUFBSTtJQUNaLE1BQU0sSUFBSSxNQUFNLE9BQU8sV0FBVywwQ0FBMEM7R0FDaEY7R0FFQSxNQUFNLGFBQWEsZ0JBQWdCLFVBQVU7R0FDN0MsbUJBQW1CLElBQUk7R0FDdkIscUJBQXFCO0lBQ2pCO0lBQ0E7SUFDQSxPQUFPO0dBQ1gsQ0FBQzs7R0FHRCxXQUFXLENBQUMsQ0FBQyxNQUFLLFFBQU87SUFDckIsSUFBSSxJQUFJLE1BQU0sTUFBTSxRQUFRLElBQUksSUFBSSxHQUFHLGFBQWEsSUFBSSxJQUFJO0dBQ2hFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQ3JCLFNBQVMsS0FBSztHQUNWLE1BQU0sZ0NBQWdDLElBQUksU0FBUztFQUN2RCxVQUFVO0dBQ04sb0JBQW9CLEtBQUs7RUFDN0I7Q0FDSjtDQUVBLE1BQU0sdUJBQXVCLFVBQVUsUUFBTyxPQUN6QyxFQUFFLFNBQVMsR0FBRSxDQUFFLFlBQVksQ0FBQyxDQUFDLFNBQVMsYUFBYSxDQUN4RDtDQUNBLE1BQU0seUJBQXlCLG1CQUFtQixRQUFPLFVBQ3BELEtBQUssYUFBYSxLQUFLLFNBQVMsR0FBRSxDQUFFLFlBQVksQ0FBQyxDQUFDLFNBQVMsY0FBYyxRQUFRLHVCQUF1QixFQUFFLENBQUMsQ0FDaEg7Q0FFQSxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDSSx3QkFBQyxTQUFELENBQVU7Ozs7O0dBRVYsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FFWCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQjtNQUVJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWCx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OztRQUNmOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUEyRyx1QkFFdkcsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXlMO1NBRW5NOzs7O2lCQUNOOzs7OztrQkFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkQ7UUFFdkU7Ozs7Z0JBQ0Y7Ozs7Z0JBQ0o7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBRUksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxLQUFEO1dBQUssTUFBTTtXQUFJLFdBQVU7VUFBb0M7Ozs7b0JBQzdELHdCQUFDLFVBQUQ7V0FDSSxPQUFPO1dBQ1AsV0FBVyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sS0FBSztXQUNqRCxXQUFVO3FCQUVULGlCQUFpQixLQUFJLE1BQ2xCLHdCQUFDLFVBQUQ7WUFBbUIsT0FBTyxFQUFFO1lBQUksV0FBVTtzQkFBMUM7YUFDSyxFQUFFO2FBQUs7YUFBRSxFQUFFLFFBQVEsSUFBSSxFQUFFLE1BQU0sS0FBSztZQUNqQztjQUZLLEVBQUU7Ozs7a0JBRVAsQ0FDWDtVQUNHOzs7O2tCQUNQOzs7Ozs7U0FFTCx3QkFBQyxVQUFEO1VBQ0ksTUFBSztVQUNMLGVBQWUsaUJBQWlCLElBQUk7VUFDcEMsV0FBVTtvQkFIZCxDQUtJLHdCQUFDLFVBQUQ7V0FBVSxNQUFNO1dBQUksV0FBVTtVQUFpQjs7OztvQkFDL0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQW1CO1VBQWlCOzs7O2tCQUNoRDs7Ozs7O1NBRVIsd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGlCQUFpQixDQUFDLGFBQWE7VUFDOUMsV0FBVywyR0FDUCxRQUFRLFNBQVMsSUFDWCx5R0FDQTtvQkFOZCxDQVNJLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7b0JBQ2hCLHdCQUFDLFFBQUQsWUFBTyxRQUFRLFNBQVMsSUFBSSxRQUFRLFFBQVEsT0FBTyxLQUFLLGVBQXFCOzs7O2tCQUN6RTs7Ozs7O1NBRVAsU0FBUyxTQUFTLEtBQ2Ysd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxTQUFTO1VBQ1QsT0FBTTtVQUNOLFdBQVU7b0JBRVYsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7U0FDZjs7Ozs7UUFFWDs7Ozs7ZUFDSjs7Ozs7O01BR0osaUJBQ0csd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNJLHdCQUFDLGFBQUQ7V0FBYSxNQUFNO1dBQUksV0FBVTtVQUFvQjs7OztvQkFBQyxxQ0FDcEQ7Ozs7O21CQUNOLHdCQUFDLEtBQUQ7VUFDSSxNQUFLO1VBQ0wsUUFBTztVQUNQLEtBQUk7VUFDSixXQUFVO29CQUpkLENBS0Msd0JBQ3VCLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7a0JBQzlDOzs7OztpQkFDRjs7Ozs7O1FBQ0wsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTZCO1FBRXZDOzs7OztRQUNILHdCQUFDLFFBQUQ7U0FBTSxVQUFVO1NBQWdCLFdBQVU7bUJBQTFDLENBQ0ksd0JBQUMsWUFBRDtVQUNJLE1BQU07VUFDTixPQUFPO1VBQ1AsV0FBVSxNQUFLLGlCQUFpQixFQUFFLE9BQU8sS0FBSztVQUM5QyxhQUFZO1VBQ1osV0FBVTtTQUNiOzs7O21CQUNELHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCO1lBQTZDO1lBQzlCLHdCQUFDLEtBQUQsWUFBSSxRQUFRLE9BQVU7Ozs7O1lBQUM7WUFBRSxRQUFRLFNBQVMsS0FBSyxnQkFBZ0IsZUFBZSxFQUFFO1dBQ3pGOzs7OztvQkFDTix3QkFBQyxVQUFEO1dBQ0ksTUFBSztXQUNMLFdBQVU7cUJBQ2I7VUFFTzs7OztrQkFDUDs7Ozs7aUJBQ0g7Ozs7OztPQUNMOzs7Ozs7TUFJVCx3QkFBQyxPQUFEO09BQ0ksS0FBSztPQUNMLFdBQVU7aUJBRmQ7UUFJSyxTQUFTLFdBQVcsSUFDakIsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWCx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OztVQUNmOzs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQTBEO1dBRXBFOzs7O3FCQUNKLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFiO2FBQTBEO2FBQ2hELHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUErRTthQUFnQjs7Ozs7YUFBQztZQUN2SDs7Ozs7bUJBQ0Y7Ozs7OztVQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0ksd0JBQUMsVUFBRDthQUNJLE1BQUs7YUFDTCxlQUFlLFNBQVMsa0ZBQWtGO2FBQzFHLFdBQVU7dUJBSGQsQ0FLSSx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLFdBQUQ7ZUFBVyxNQUFNO2VBQUksV0FBVTtjQUFpQjs7Ozt3QkFDaEQsd0JBQUMsUUFBRCxZQUFNLDRCQUErQjs7OztzQkFDcEM7Ozs7O3VCQUNMLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUE2QjthQUFrRDs7OztxQkFDeEY7Ozs7OztZQUVSLHdCQUFDLFVBQUQ7YUFDSSxNQUFLO2FBQ0wsZUFBZSxTQUFTLCtGQUErRjthQUN2SCxXQUFVO3VCQUhkLENBS0ksd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDSSx3QkFBQyxhQUFEO2VBQWEsTUFBTTtlQUFJLFdBQVU7Y0FBa0I7Ozs7d0JBQ25ELHdCQUFDLFFBQUQsWUFBTSxrQ0FBcUM7Ozs7c0JBQzFDOzs7Ozt1QkFDTCx3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFBNkI7YUFBeUM7Ozs7cUJBQy9FOzs7Ozs7WUFFUix3QkFBQyxVQUFEO2FBQ0ksTUFBSzthQUNMLGVBQWUsU0FBUyxvRkFBb0Y7YUFDNUcsV0FBVTt1QkFIZCxDQUtJLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsV0FBRDtlQUFXLE1BQU07ZUFBSSxXQUFVO2NBQWlCOzs7O3dCQUNoRCx3QkFBQyxRQUFELFlBQU0sNEJBQStCOzs7O3NCQUNwQzs7Ozs7dUJBQ0wsd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQTZCO2FBQXlDOzs7O3FCQUMvRTs7Ozs7O1lBRVIsd0JBQUMsVUFBRDthQUNJLE1BQUs7YUFDTCxlQUFlO2NBQUUsaUJBQWlCLElBQUk7YUFBRzthQUN6QyxXQUFVO3VCQUhkLENBS0ksd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDSSx3QkFBQyxVQUFEO2VBQVUsTUFBTTtlQUFJLFdBQVU7Y0FBaUI7Ozs7d0JBQy9DLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7c0JBQy9COzs7Ozt1QkFDTCx3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFBNkI7YUFBbUQ7Ozs7cUJBQ3pGOzs7Ozs7V0FDUDs7Ozs7O1NBQ0o7Ozs7O21CQUVMLFNBQVMsS0FBSyxNQUNWLHdCQUFDLE9BQUQ7U0FFSSxXQUFXLDBCQUNQLEVBQUUsV0FBVyxTQUFTLGdCQUFnQjttQkFIOUM7VUFNSyxFQUFFLFdBQVcsU0FDVix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWCx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OztVQUNmOzs7OztVQUdULHdCQUFDLE9BQUQ7V0FDSSxXQUFXLHFHQUNQLEVBQUUsV0FBVyxTQUNQLHlDQUNBO3FCQUpkO1lBUUssRUFBRSxlQUNDLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozt1QkFDckIsd0JBQUMsUUFBRCxhQUFNLEtBQUUsRUFBRSxZQUFZLEtBQVk7Ozs7cUJBQ2pDOzs7Ozs7WUFFUixFQUFFLDBCQUNDLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozt1QkFDckIsd0JBQUMsUUFBRCxhQUFNLHFCQUFrQixFQUFFLHVCQUF1QixTQUFnQjs7OztxQkFDaEU7Ozs7OztZQUlSLEVBQUUsb0JBQ0Msd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDSSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7O3VCQUNyQix3QkFBQyxRQUFEO2NBQU8sRUFBRSxpQkFBaUI7Y0FBSztjQUFHLEVBQUUsaUJBQWlCO2NBQUs7YUFBTzs7OztxQkFDaEU7Ozs7OztZQUlULHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUNWLEVBQUUsT0FDQyx3QkFBQyxxQkFBRCxFQUFxQixTQUFTLEVBQUUsS0FBTzs7Ozt3QkFFdkMsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDSSx3QkFBQyxTQUFEO2VBQVMsTUFBTTtlQUFJLFdBQVU7Y0FBOEI7Ozs7d0JBQzNELHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7c0JBQy9COzs7Ozs7WUFFUjs7Ozs7WUFHSixFQUFFLFlBQVksU0FBUyxtQkFBbUIsRUFBRSxXQUFXLFFBQ3BELHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsVUFBRDtjQUNJLE1BQUs7Y0FDTCxlQUFlLG1CQUFtQixFQUFFLFdBQVcsS0FBSyxJQUFJLEVBQUUsV0FBVyxLQUFLLE9BQU8sS0FBSztjQUN0RixXQUFVO3dCQUhkLENBS0ksd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozt3QkFDckIsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztzQkFDeEI7Ozs7O3VCQUNSLHdCQUFDLFVBQUQ7Y0FDSSxNQUFLO2NBQ0wsZUFBZSxtQkFBbUIsRUFBRSxXQUFXLEtBQUssSUFBSSxFQUFFLFdBQVcsS0FBSyxPQUFPLE1BQU07Y0FDdkYsV0FBVTt3QkFIZCxDQUtJLHdCQUFDLGlCQUFELEVBQWlCLE1BQU0sR0FBSzs7Ozt3QkFDNUIsd0JBQUMsUUFBRCxZQUFNLDRCQUErQjs7OztzQkFDakM7Ozs7O3FCQUNQOzs7Ozs7WUFJUixFQUFFLFlBQVksU0FBUyxtQkFDcEIsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQ1gsd0JBQUMsVUFBRDtjQUNJLE1BQUs7Y0FDTCxlQUFlLGlCQUFpQixJQUFJO2NBQ3BDLFdBQVU7d0JBSGQsQ0FLSSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7O3dCQUNyQix3QkFBQyxRQUFEO2VBQU07ZUFBd0IsVUFBVTtlQUFPO2NBQWdCOzs7O3NCQUMzRDs7Ozs7O1lBQ1A7Ozs7O1lBSVIsRUFBRSxZQUFZLFNBQVMsMkJBQTJCLEVBQUUsV0FBVyxhQUM1RCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNJLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsY0FBRDtlQUFjLE1BQU07ZUFBSSxXQUFVO2NBQWlCOzs7O3dCQUNuRCx3QkFBQyxRQUFELGFBQU8sRUFBRSxXQUFXLFVBQVUsUUFBTyw0QkFBZ0M7Ozs7c0JBQ3BFOzs7Ozt1QkFDTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLFVBQUQ7ZUFDSSxNQUFLO2VBQ0wsZUFBZTtnQkFDWCxtQkFBbUI7aUJBQ2YsV0FBVyxFQUFFLFdBQVc7aUJBQ3hCLFVBQVUsRUFBRSxXQUFXO2dCQUMzQixDQUFDO2dCQUNELGdCQUFnQixLQUFLO2VBQ3pCO2VBQ0EsV0FBVTt5QkFUZCxDQVdJLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7eUJBQ2pCLHdCQUFDLFFBQUQsWUFBTSw0QkFBK0I7Ozs7dUJBQ2pDOzs7Ozt3QkFDUix3QkFBQyxVQUFEO2VBQ0ksTUFBSztlQUNMLGVBQWUscUJBQXFCLEVBQUUsV0FBVyxXQUFXLEVBQUUsV0FBVyxZQUFZLGdCQUFnQjtlQUNyRyxXQUFVO3lCQUhkLENBS0ksd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozt5QkFDckIsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7Ozt1QkFDeEI7Ozs7O3NCQUNQOzs7OztxQkFDSjs7Ozs7O1lBSVIsRUFBRSxrQkFDQyx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFDWCx3QkFBQyxNQUFEO2NBQ0ksSUFBSSxFQUFFLGVBQWU7Y0FDckIsV0FBVTt3QkFGZCxDQUlJLHdCQUFDLFFBQUQsWUFBTyxFQUFFLGVBQWUsTUFBWTs7Ozt3QkFDcEMsd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7OztzQkFDckI7Ozs7OztZQUNMOzs7OztZQUVSLEVBQUUsWUFBWSxTQUFTLHNCQUFzQixFQUFFLFFBQVEsRUFBRSxXQUFXLFdBQVcsU0FBUyxLQUNyRix3QkFBQywwQkFBRDthQUEwQixRQUFRLEVBQUUsV0FBVzthQUFRLFdBQVcsRUFBRSxXQUFXO1lBQVk7Ozs7O1dBRTlGOzs7Ozs7VUFFSixFQUFFLFdBQVcsVUFDVix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWCx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztVQUNoQjs7Ozs7U0FFUjtXQWhKSSxFQUFFOzs7O2VBZ0pOLENBQ1I7UUFHSixpQkFBaUIsZ0JBQ2Qsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxTQUFEO1VBQVMsTUFBTTtVQUFJLFdBQVU7U0FBdUM7Ozs7bUJBQ3BFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWI7WUFBa0U7WUFDOUMsYUFBYTtZQUFRO1lBQUUsYUFBYTtZQUFNO1lBQUksYUFBYTtXQUM1RTs7Ozs7b0JBQ0gsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1gsd0JBQUMsT0FBRDtZQUNJLFdBQVU7WUFDVixPQUFPLEVBQUUsT0FBTyxHQUFJLGFBQWEsVUFBVSxhQUFhLFFBQVMsSUFBSSxHQUFHO1dBQzNFOzs7OztVQUNBOzs7O2tCQUNKOzs7OztpQkFDSjs7Ozs7O1FBR1Qsd0JBQUMsT0FBRCxFQUFLLEtBQUssZUFBaUI7Ozs7O09BQzFCOzs7Ozs7TUFHSixvQkFBb0IscUJBQXFCLFNBQVMsS0FBSyx1QkFBdUIsU0FBUyxNQUNwRix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWdFO1NBRTFFOzs7O21CQUNILHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxtQkFBbUIsS0FBSztVQUN2QyxXQUFVO29CQUNiO1NBRU87Ozs7aUJBQ1A7Ozs7OztRQUNKLHVCQUF1QixLQUFJLFNBQ3hCLHdCQUFDLFVBQUQ7U0FBc0QsTUFBSztTQUFTLGVBQWUsMkJBQTJCLElBQUk7U0FBRyxXQUFVO21CQUEvSCxDQUNJLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUEyQixxQkFBa0IsS0FBSyxhQUFhLEtBQUssS0FBWTs7Ozs7bUJBQ2hGLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyQztTQUFrQjs7OztpQkFDekU7V0FISyxXQUFXLEtBQUssY0FBYyxLQUFLOzs7O2VBR3hDLENBQ1g7UUFDQSxxQkFBcUIsS0FBSSxNQUN0Qix3QkFBQyxVQUFEO1NBRUksTUFBSztTQUNMLGVBQWUsd0JBQXdCLENBQUM7U0FDeEMsV0FBVTttQkFKZCxDQU1JLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFZLEVBQUU7U0FBWTs7OzttQkFDMUMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0ssRUFBRSxpQkFBaUIsR0FBRSxVQUNwQjs7Ozs7aUJBQ0Y7V0FUQyxFQUFFOzs7O2VBU0gsQ0FDWDtPQUNBOzs7Ozs7TUFJUixnQkFDRyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsVUFBRDtTQUFVLE1BQU07U0FBSSxXQUFVO1FBQTBCOzs7O2tCQUN4RCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBcUQsc0JBQy9CLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO29CQUFvQyxhQUFhO1NBQWM7Ozs7aUJBQ2pHOzs7OztnQkFDTDs7Ozs7aUJBQ0wsd0JBQUMsVUFBRDtRQUNJLE1BQUs7UUFDTCxlQUFlLGdCQUFnQixJQUFJO1FBQ25DLFdBQVU7UUFDVixPQUFNO2tCQUpWLENBTUksd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7OztrQkFDZCx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7O2dCQUN0Qjs7Ozs7ZUFDUDs7Ozs7O01BRVIsbUJBQ0csd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FBOEQsYUFBUyx3QkFBQyxVQUFELGFBQVEscUJBQWtCLGdCQUFnQixhQUFhLGdCQUFnQixLQUFjOzs7O2dCQUFPOzs7OztpQkFDbkssd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxlQUFlLG1CQUFtQixJQUFJO1FBQUcsV0FBVTtrQkFBMkQ7T0FBc0I7Ozs7ZUFDeko7Ozs7OztNQUlSLGdCQUNHLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDSSx3QkFBQyxXQUFEO1VBQVcsTUFBTTtVQUFJLFdBQVU7U0FBaUI7Ozs7O1NBQ2hELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnRCxhQUFhO1NBQVc7Ozs7O1NBQ3hGLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUErRDtZQUFHLGFBQWEsT0FBTyxLQUFJLENBQUUsUUFBUSxDQUFDO1dBQUU7VUFBVTs7Ozs7O1FBQ2hIOzs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLGVBQWUsZ0JBQWdCLElBQUk7UUFDbkMsV0FBVTtrQkFFVix3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztPQUNWOzs7O2VBQ1A7Ozs7OztNQUlULHdCQUFDLFFBQUQ7T0FBTSxVQUFVO09BQW1CLFdBQVU7aUJBQTdDO1FBQ0ksd0JBQUMsU0FBRDtTQUNJLE1BQUs7U0FDTCxLQUFLO1NBQ0wsV0FBVyxNQUFNO1VBQ2IsSUFBSSxFQUFFLE9BQU8sU0FBUyxFQUFFLE9BQU8sTUFBTSxJQUFJO1dBQ3JDLGdCQUFnQixFQUFFLE9BQU8sTUFBTSxFQUFFO1dBQ2pDLEVBQUUsT0FBTyxRQUFRO1VBQ3JCO1NBQ0o7U0FDQSxRQUFPO1NBQ1AsV0FBVTtRQUNiOzs7OztRQUVELHdCQUFDLFVBQUQ7U0FDSSxNQUFLO1NBQ0wsZUFBZSxhQUFhLFNBQVMsTUFBTTtTQUMzQyxPQUFNO1NBQ04sV0FBVTttQkFFVix3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7OztRQUNsQjs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0ksTUFBSztTQUNMLFNBQVM7U0FDVCxPQUFPLGNBQWMsMEJBQTBCO1NBQy9DLFdBQVcsMkVBQ1AsY0FDTSx1REFDQTttQkFHVCxjQUFjLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7b0JBQUksd0JBQUMsS0FBRCxFQUFLLE1BQU0sR0FBSzs7Ozs7UUFDbEQ7Ozs7O1FBRVIsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxZQUFEO1VBQ0ksS0FBSztVQUNMLE1BQU07VUFDTixPQUFPO1VBQ1AsVUFBVTtVQUNWLFlBQVksTUFBTTtXQUNkLElBQUksRUFBRSxRQUFRLFVBQVU7WUFDcEIsbUJBQW1CLEtBQUs7V0FDNUIsT0FBTyxJQUFJLEVBQUUsUUFBUSxXQUFXLENBQUMsRUFBRSxVQUFVO1lBQ3pDLEVBQUUsZUFBZTtZQUNqQixrQkFBa0IsQ0FBQztXQUN2QjtVQUNKO1VBQ0EsYUFDSSxjQUNNLHNDQUNBLGVBQ0EsMERBQ0E7VUFFVixXQUFVO1VBQ1YsVUFBVSxXQUFXO1NBQ3hCOzs7O21CQUNELHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsVUFBVSxXQUFZLENBQUMsTUFBTSxLQUFLLEtBQUssQ0FBQyxnQkFBaUI7VUFDekQsV0FBVTtvQkFFVix3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztTQUNiOzs7O2lCQUNQOzs7Ozs7T0FDSDs7Ozs7O0tBQ0o7Ozs7OztHQUNMOzs7OztHQUdKLGlCQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFrRSxlQUFlLGlCQUFpQixLQUFLO0lBQUk7Ozs7Y0FDMUgsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWCx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztRQUNwQjs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXdEO1FBQWdDOzs7O2tCQUN0Ryx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkI7UUFBZ0U7Ozs7Z0JBQ3pHOzs7O2dCQUNKOzs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLGVBQWUsaUJBQWlCLEtBQUs7UUFDckMsV0FBVTtrQkFFVix3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztPQUNWOzs7O2VBQ1A7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXVEO09BQXNDOzs7O2lCQUM5Ryx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDVjtTQUNHO1VBQUUsS0FBSztVQUFLLE9BQU87U0FBUztTQUM1QjtVQUFFLEtBQUs7VUFBSyxPQUFPO1NBQVM7U0FDNUI7VUFBRSxLQUFLO1VBQUssT0FBTztTQUFTO1NBQzVCO1VBQUUsS0FBSztVQUFNLE9BQU87U0FBVTtTQUM5QjtVQUFFLEtBQUs7VUFBTyxPQUFPO1NBQVE7UUFDakMsQ0FBQyxDQUFDLEtBQUksTUFDRix3QkFBQyxVQUFEO1NBRUksTUFBSztTQUNMLGVBQWUsa0JBQWtCLEVBQUUsR0FBRztTQUN0QyxXQUFXLDRFQUNQLG1CQUFtQixFQUFFLE1BQ2YscURBQ0E7bUJBR1QsRUFBRTtRQUNDLEdBVkMsRUFBRTs7OztlQVVILENBQ1g7T0FDQTs7OztlQUNKOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsUUFBRDtTQUFNO1NBQWtCLHFCQUFxQjtTQUFPO1FBQVE7Ozs7a0JBQzVELHdCQUFDLFVBQUQ7U0FDSSxNQUFLO1NBQ0wsU0FBUztTQUNULFdBQVU7bUJBQ2I7UUFFTzs7OztnQkFDUDs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1YscUJBQXFCLFdBQVcsSUFDN0Isd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTBDO1FBQThDOzs7O21CQUVyRyxxQkFBcUIsS0FBSSxNQUFLO1NBQzFCLE1BQU0sWUFBWSx5QkFBeUIsU0FBUyxFQUFFLEVBQUU7U0FDeEQsT0FDSSx3QkFBQyxPQUFEO1VBRUksZUFBZSx3QkFBd0IsRUFBRSxFQUFFO1VBQzNDLFdBQVU7b0JBSGQsQ0FLSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNLLFlBQ0csd0JBQUMsYUFBRDtZQUFhLE1BQU07WUFBSSxXQUFVO1dBQTBCOzs7O3NCQUUzRCx3QkFBQyxRQUFEO1lBQVEsTUFBTTtZQUFJLFdBQVU7V0FBMkI7Ozs7cUJBRTNELHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFxRSxFQUFFO1dBQVk7Ozs7bUJBQ2xHOzs7OztvQkFDTCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FDSyxFQUFFLGlCQUFpQixHQUFFLFVBQ3BCOzs7OztrQkFDTDtZQWZJLEVBQUU7Ozs7Z0JBZU47UUFFYixDQUFDO09BRUo7Ozs7ZUFDSjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLGVBQWUsaUJBQWlCLEtBQUs7UUFDckMsV0FBVTtrQkFDYjtPQUVPOzs7O2lCQUNSLHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsVUFBVSx5QkFBeUIsV0FBVyxLQUFLO1FBQ25ELGVBQWU7U0FDWCxNQUFNLFFBQVEsVUFBVSxRQUFPLE1BQUsseUJBQXlCLFNBQVMsRUFBRSxFQUFFLENBQUM7U0FDM0Usa0JBQWtCLE9BQU8sR0FBRyx5QkFBeUIsT0FBTyxtQkFBbUI7UUFDbkY7UUFDQSxXQUFVO2tCQVBkLENBU0ksd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OztrQkFDckIsd0JBQUMsUUFBRDtTQUFNO1NBQVEseUJBQXlCO1NBQU87UUFBZ0I7Ozs7Z0JBQzFEOzs7OztlQUNQOzs7Ozs7S0FDSjs7Ozs7WUFDSjs7Ozs7O0dBSVIsbUJBQ0csd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWtFLGVBQWUsQ0FBQyxvQkFBb0IsbUJBQW1CLElBQUk7SUFBSTs7OztjQUNoSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNYLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7O1FBQ2xCOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUFzRSw4QkFDdkMsZ0JBQWdCLFFBQzNDOzs7OztrQkFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUEwQztVQUMvQixnQkFBZ0IsV0FBVyxVQUFVO1VBQUU7U0FDL0M7Ozs7O2dCQUNGOzs7O2dCQUNKOzs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLFVBQVU7UUFDVixlQUFlLG1CQUFtQixJQUFJO1FBQ3RDLFdBQVU7a0JBRVYsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7T0FDVjs7OztlQUNQOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUF1RDtPQUVqRTs7OztpQkFDUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLFNBQUQ7U0FBTyxXQUFXLHdGQUNkLGlCQUFpQixRQUNYLG9GQUNBO21CQUhWLENBS0ksd0JBQUMsU0FBRDtVQUNJLE1BQUs7VUFDTCxNQUFLO1VBQ0wsT0FBTTtVQUNOLFNBQVMsaUJBQWlCO1VBQzFCLGdCQUFnQixnQkFBZ0IsS0FBSztVQUNyQyxXQUFVO1NBQ2I7Ozs7bUJBQ0Qsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBWTtVQUF1Qjs7OztvQkFDaEQsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQTZCO1VBQStDOzs7O2tCQUN4Rjs7Ozs7aUJBQ0Y7Ozs7O2tCQUVOLFVBQVUsU0FBUyxLQUNoQix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWCx3QkFBQyxVQUFEO1VBQ0ksT0FBTztVQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7VUFDL0MsV0FBVTtvQkFIZCxDQUtJLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFNO1VBQWdEOzs7O29CQUNuRSxVQUFVLEtBQUksTUFDWCx3QkFBQyxVQUFEO1dBQW1CLE9BQU8sRUFBRTtxQkFBNUIsQ0FBZ0Msa0JBQ2IsRUFBRSxLQUNiO2FBRkssRUFBRTs7OztpQkFFUCxDQUNYLENBQ0c7Ozs7OztRQUNQOzs7O2dCQUVSOzs7OztlQUNKOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDVixnQkFBZ0IsV0FBVyxLQUFLLEdBQUcsUUFDaEMsd0JBQUMsT0FBRDtRQUFlLFdBQVU7a0JBQXpCO1NBQ0ksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFDSyxNQUFNO1lBQUU7WUFBRyxFQUFFO1dBQ1o7Ozs7O29CQUNOLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQjtZQUNLLEVBQUUsV0FBVyxJQUFJLGtCQUFrQixFQUFFLFdBQVcsSUFBSSxhQUFhLEVBQUUsV0FBVyxJQUFJLGdCQUFnQjtZQUFRO1lBQUcsRUFBRSxVQUFVO1lBQUU7V0FDMUg7Ozs7O2tCQUNMOzs7Ozs7U0FDSixFQUFFLFdBQVcsRUFBRSxRQUFRLFNBQVMsS0FDN0Isd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1YsRUFBRSxRQUFRLEtBQUssS0FBSyxTQUNqQix3QkFBQyxPQUFEO1dBRUksV0FBVyw0REFDUCxJQUFJLFlBQ0UsNElBQ0E7cUJBTGQsQ0FRSyxJQUFJLGFBQWEsd0JBQUMsT0FBRDtZQUFPLE1BQU07WUFBSSxXQUFVO1dBQTZCOzs7O3FCQUMxRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBWSxJQUFJO1dBQWlCOzs7O21CQUNoRDthQVRJOzs7O2lCQVNKLENBQ1I7U0FDQTs7Ozs7U0FFUixFQUFFLGlCQUNDLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiLENBQXFGLFdBQ3pFLEVBQUUsYUFDWDs7Ozs7O1FBRU47VUEvQks7Ozs7Y0ErQkwsQ0FDUjtNQUNBOzs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsVUFBRDtRQUNJLE1BQUs7UUFDTCxVQUFVO1FBQ1YsZUFBZSxtQkFBbUIsSUFBSTtRQUN0QyxXQUFVO2tCQUNiO09BRU87Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNJLE1BQUs7UUFDTCxVQUFVO1FBQ1YsU0FBUztRQUNULFdBQVU7a0JBRVQsbUJBQ0csZ0RBQ0ksd0JBQUMsU0FBRDtTQUFTLE1BQU07U0FBSSxXQUFVO1FBQWdCOzs7O2tCQUM3Qyx3QkFBQyxRQUFELFlBQU0sMkJBQThCOzs7O2dCQUN0Qzs7OzttQkFFRixnREFDSSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2tCQUNqQix3QkFBQyxRQUFEO1NBQU07U0FBVSxnQkFBZ0IsV0FBVztTQUFPO1FBQW1COzs7O2dCQUN2RTs7Ozs7T0FFRjs7OztlQUNQOzs7Ozs7S0FDSjs7Ozs7WUFDSjs7Ozs7O0dBSVIscUJBQ0csd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWtFLGVBQWUscUJBQXFCLElBQUk7SUFBSTs7OztjQUM3SCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1gsd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7Ozs7TUFDeEI7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBMEQ7T0FFcEU7Ozs7aUJBQ0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FBMEQ7U0FDN0Msd0JBQUMsS0FBRCxhQUFJLGtCQUFrQixPQUFNLGFBQWM7Ozs7O1NBQUM7U0FBc0Isd0JBQUMsS0FBRDtVQUFHO1VBQUUsa0JBQWtCO1VBQVU7U0FBSTs7Ozs7U0FBQztRQUNqSDs7Ozs7ZUFDRjs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLGVBQWUscUJBQXFCLElBQUk7UUFDeEMsV0FBVTtrQkFDYjtPQUVPOzs7O2lCQUNSLHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsZUFBZSxTQUFTLFVBQVUsa0JBQWtCLE9BQU8sTUFBTTtRQUNqRSxXQUFVO2tCQUhkLENBS0ksd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztrQkFDN0Isd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7OztnQkFDbkI7Ozs7O2VBQ1A7Ozs7OztLQUNKOzs7OztZQUNKOzs7Ozs7RUFFUjs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQWlDaGF0UGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7XG4gICAgU3BhcmtsZXMsIFNlbmQsIEJvdCwgVXNlciwgVHJhc2gyLCBBcnJvd1JpZ2h0LCBEb3dubG9hZCxcbiAgICBGaWxlU3ByZWFkc2hlZXQsIEJhckNoYXJ0MiwgTG9hZGVyMiwgQWxlcnRDaXJjbGUsIENoZWNrQ2lyY2xlMixcbiAgICBSZWZyZXNoQ3csIEV4dGVybmFsTGluaywgSGVscENpcmNsZSwgRmlsZVRleHQsIENvcm5lckRvd25MZWZ0LFxuICAgIENsb2NrLCBMYXllcnMsIFBsdXMsIFNoaWVsZENoZWNrLCBLZXksIENoZWNrU3F1YXJlLCBTcXVhcmUsXG4gICAgRmlsdGVyLCBDaGV2cm9uUmlnaHQsIFgsIEFsZXJ0VHJpYW5nbGUsIFVzZXJDaGVjaywgU2hpZWxkQWxlcnQsXG4gICAgTWljLCBNaWNPZmYsIFBhcGVyY2xpcCwgVXBsb2FkLCBGaWxlVXAsIENoZWNrLFxuICAgIEdsb2JlLCBWaWRlbywgTGluazIsIENwdSwgQ2hlY2tDaXJjbGVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBTaWRlYmFyIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvbGF5b3V0L1NpZGViYXInO1xuaW1wb3J0IFJpY2hDb250ZW50UmVuZGVyZXIgZnJvbSAnLi4vLi4vdXRpbHMvUmljaENvbnRlbnRSZW5kZXJlcic7XG5pbXBvcnQgSW50ZXJhY3RpdmVRdWl6T2ZmZXJDYXJkIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdWkvSW50ZXJhY3RpdmVRdWl6T2ZmZXJDYXJkJztcbmltcG9ydCB7XG4gICAgZ2V0R2VtaW5pQXBpS2V5LFxuICAgIHNhdmVHZW1pbmlBcGlLZXksXG4gICAgZ2V0R2VtaW5pQXBpS2V5cyxcbiAgICBzYXZlR2VtaW5pQXBpS2V5cyxcbiAgICBnZXRBY3RpdmVBcGlLZXlJbmRleCxcbiAgICByb3RhdGVUb05leHRBcGlLZXksXG4gICAgcmVtb3ZlR2VtaW5pQXBpS2V5LFxuICAgIEFWQUlMQUJMRV9NT0RFTFMsXG4gICAgZ2VuZXJhdGVRdWVzdGlvbnNGcm9tRG9jdW1lbnQsXG4gICAgZXhwb3J0UXVlc3Rpb25zVG9DU1YsXG4gICAgZXh0cmFjdENvbnRlbnRGcm9tVXJsLFxuICAgIERFRkFVTFRfQUlfTU9ERUxcbn0gZnJvbSAnLi4vLi4vc2VydmljZXMvYWlTZXJ2aWNlJztcbmltcG9ydCB7XG4gICAgZ2V0TXlGb3JtcyxcbiAgICBnZXRGb3JtQnlJZCxcbiAgICBnZXRRdWVzdGlvbnMsXG4gICAgYWRkUXVlc3Rpb25zLFxuICAgIGNyZWF0ZUZvcm0sXG4gICAgZ2V0Rm9ybVJlc3BvbnNlcyxcbiAgICBnZXRFeGFtTW9uaXRvcmluZyxcbiAgICBnZXRGb3JtQW5hbHl0aWNzLFxuICAgIGV4cG9ydEZvcm1SZXNwb25zZXMsXG4gICAgZ2V0TG9jYWxVc2VyLFxuICAgIGdldE15U3VibWl0dGVkUmVzcG9uc2VzLFxuICAgIGdldFJlc3BvbnNlRGV0YWlsLFxuICAgIGdldFJlc3BvbnNlQXR0ZW1wdHMsXG4gICAgZ2V0UHVibGljRm9ybUJ5TGluayxcbiAgICBnZXRQdWJsaWNSZXNwb25zZVJlc3VsdFxufSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQWlDaGF0UGFnZSgpIHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgW3VzZXJdID0gdXNlU3RhdGUoKCkgPT4gZ2V0TG9jYWxVc2VyKCkpO1xuICAgIGNvbnN0IHVzZXJJZCA9IHVzZXI/LmlkIHx8ICdndWVzdCc7XG4gICAgY29uc3Qgc3RvcmFnZUtleSA9IGBmb3JtdXBfYWlfY2hhdF8ke3VzZXJJZH1gO1xuXG4gICAgLy8gTW9kZWwgU2VsZWN0b3Igc3RhdGVcbiAgICBjb25zdCBbc2VsZWN0ZWRNb2RlbCwgc2V0U2VsZWN0ZWRNb2RlbF0gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgICAgIGNvbnN0IHN0b3JlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdmb3JtdXBfc2VsZWN0ZWRfbW9kZWxfY2hhdCcpO1xuICAgICAgICByZXR1cm4gc3RvcmVkICYmICFzdG9yZWQuaW5jbHVkZXMoJy1wcm8nKSAmJiBBVkFJTEFCTEVfTU9ERUxTLnNvbWUobW9kZWwgPT4gbW9kZWwuaWQgPT09IHN0b3JlZCkgPyBzdG9yZWQgOiBERUZBVUxUX0FJX01PREVMO1xuICAgIH0pO1xuXG4gICAgY29uc3QgaGFuZGxlTW9kZWxDaGFuZ2UgPSAobUlkKSA9PiB7XG4gICAgICAgIHNldFNlbGVjdGVkTW9kZWwobUlkKTtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2Zvcm11cF9zZWxlY3RlZF9tb2RlbF9jaGF0JywgbUlkKTtcbiAgICB9O1xuXG4gICAgLy8gQ2hhdCBzdGF0ZXNcbiAgICBjb25zdCBbbWVzc2FnZXMsIHNldE1lc3NhZ2VzXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oc3RvcmFnZUtleSk7XG4gICAgICAgICAgICByZXR1cm4gc2F2ZWQgPyBKU09OLnBhcnNlKHNhdmVkKSA6IFtdO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIGNvbnN0IFtpbnB1dCwgc2V0SW5wdXRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbdXNlckZvcm1zLCBzZXRVc2VyRm9ybXNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtzZWxlY3RlZEZvcm0sIHNldFNlbGVjdGVkRm9ybV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbc3VibWl0dGVkUmVzcG9uc2VzLCBzZXRTdWJtaXR0ZWRSZXNwb25zZXNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtzZWxlY3RlZEhpc3RvcnksIHNldFNlbGVjdGVkSGlzdG9yeV0gPSB1c2VTdGF0ZShudWxsKTtcblxuICAgIC8vIEMtMTogVm9pY2UgaW5wdXQgc3RhdGUgKFdlYiBTcGVlY2ggQVBJKVxuICAgIGNvbnN0IFtpc0xpc3RlbmluZywgc2V0SXNMaXN0ZW5pbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtzcGVlY2hTdXBwb3J0ZWQsIHNldFNwZWVjaFN1cHBvcnRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgcmVjb2duaXRpb25SZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgICAvLyBDLTI6IERvY3VtZW50IEZpbGUgVXBsb2FkIHN0YXRlICYgUHJldmlldy9JbnNlcnQgbW9kYWwgc3RhdGVcbiAgICBjb25zdCBbYXR0YWNoZWRGaWxlLCBzZXRBdHRhY2hlZEZpbGVdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IFtwcmV2aWV3RG9jTW9kYWwsIHNldFByZXZpZXdEb2NNb2RhbF0gPSB1c2VTdGF0ZShudWxsKTsgLy8geyBxdWVzdGlvbnMsIGZpbGVOYW1lIH1cbiAgICBjb25zdCBbdGFyZ2V0Rm9ybUlkLCBzZXRUYXJnZXRGb3JtSWRdID0gdXNlU3RhdGUoJ25ldycpOyAvLyAnbmV3JyB8IGZvcm1JZFxuICAgIGNvbnN0IFtjb21taXR0aW5nVG9Gb3JtLCBzZXRDb21taXR0aW5nVG9Gb3JtXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbY29tbWl0U3VjY2Vzc0luZm8sIHNldENvbW1pdFN1Y2Nlc3NJbmZvXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gICAgLy8gTWVudGlvbiBAIEF1dG9jb21wbGV0ZVxuICAgIGNvbnN0IFtzaG93TWVudGlvbk1lbnUsIHNldFNob3dNZW50aW9uTWVudV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW21lbnRpb25GaWx0ZXIsIHNldE1lbnRpb25GaWx0ZXJdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFttZW50aW9uQ3Vyc29yUG9zLCBzZXRNZW50aW9uQ3Vyc29yUG9zXSA9IHVzZVN0YXRlKDApO1xuXG4gICAgLy8gQnVsayBleHBvcnQgbW9kYWwgLyBzZWxlY3Rpb24gc3RhdGVcbiAgICBjb25zdCBbc2hvd0J1bGtNb2RhbCwgc2V0U2hvd0J1bGtNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3NlbGVjdGVkRm9ybUlkc0ZvckV4cG9ydCwgc2V0U2VsZWN0ZWRGb3JtSWRzRm9yRXhwb3J0XSA9IHVzZVN0YXRlKFtdKTtcbiAgICBjb25zdCBbYnVsa0RheXNGaWx0ZXIsIHNldEJ1bGtEYXlzRmlsdGVyXSA9IHVzZVN0YXRlKCdhbGwnKTsgLy8gJzEnIHwgJzMnIHwgJzcnIHwgJzMwJyB8ICdhbGwnXG4gICAgY29uc3QgW2J1bGtFeHBvcnRpbmcsIHNldEJ1bGtFeHBvcnRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtidWxrUHJvZ3Jlc3MsIHNldEJ1bGtQcm9ncmVzc10gPSB1c2VTdGF0ZShudWxsKTtcblxuICAgIC8vIEFQSSBLZXkgU3RhY2tpbmcgRHJhd2VyXG4gICAgY29uc3QgW2FwaUtleXMsIHNldEFwaUtleXNdID0gdXNlU3RhdGUoKCkgPT4gZ2V0R2VtaW5pQXBpS2V5cygpKTtcbiAgICBjb25zdCBbYWN0aXZlS2V5SWR4LCBzZXRBY3RpdmVLZXlJZHhdID0gdXNlU3RhdGUoKCkgPT4gZ2V0QWN0aXZlQXBpS2V5SW5kZXgoKSk7XG4gICAgY29uc3QgW2lucHV0S2V5c1RleHQsIHNldElucHV0S2V5c1RleHRdID0gdXNlU3RhdGUoKCkgPT4gZ2V0R2VtaW5pQXBpS2V5cygpLmpvaW4oJ1xcbicpKTtcbiAgICBjb25zdCBbYXBpS2V5LCBzZXRBcGlLZXldID0gdXNlU3RhdGUoKCkgPT4gZ2V0R2VtaW5pQXBpS2V5KCkpO1xuICAgIGNvbnN0IFtzaG93S2V5RWRpdG9yLCBzZXRTaG93S2V5RWRpdG9yXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IG1lc3NhZ2VzRW5kUmVmID0gdXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IGNoYXRDb250YWluZXJSZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgY29uc3QgaW5wdXRSZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgY29uc3QgYWJvcnRDb250cm9sbGVyUmVmID0gdXNlUmVmKG51bGwpO1xuXG4gICAgLy8gSW5pdGlhbGl6ZSBXZWIgU3BlZWNoIEFQSSBmb3IgQy0xIFZvaWNlIE1vZGVcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIGNvbnN0IFNwZWVjaFJlY29nbml0aW9uID0gd2luZG93LlNwZWVjaFJlY29nbml0aW9uIHx8IHdpbmRvdy53ZWJraXRTcGVlY2hSZWNvZ25pdGlvbjtcbiAgICAgICAgICAgIGlmIChTcGVlY2hSZWNvZ25pdGlvbikge1xuICAgICAgICAgICAgICAgIHNldFNwZWVjaFN1cHBvcnRlZCh0cnVlKTtcbiAgICAgICAgICAgICAgICBjb25zdCByZWNvZ25pdGlvbiA9IG5ldyBTcGVlY2hSZWNvZ25pdGlvbigpO1xuICAgICAgICAgICAgICAgIHJlY29nbml0aW9uLmNvbnRpbnVvdXMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICByZWNvZ25pdGlvbi5pbnRlcmltUmVzdWx0cyA9IHRydWU7XG4gICAgICAgICAgICAgICAgcmVjb2duaXRpb24ubGFuZyA9ICdpZC1JRCc7XG5cbiAgICAgICAgICAgICAgICByZWNvZ25pdGlvbi5vbnJlc3VsdCA9IChldmVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0cmFuc2NyaXB0ID0gQXJyYXkuZnJvbShldmVudC5yZXN1bHRzKVxuICAgICAgICAgICAgICAgICAgICAgICAgLm1hcChyZXN1bHQgPT4gcmVzdWx0WzBdLnRyYW5zY3JpcHQpXG4gICAgICAgICAgICAgICAgICAgICAgICAuam9pbignJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldElucHV0KHByZXYgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFzZSA9IHByZXYudHJpbSgpID8gYCR7cHJldi50cmltKCl9IGAgOiAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgJHtiYXNlfSR7dHJhbnNjcmlwdH1gO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgcmVjb2duaXRpb24ub25lcnJvciA9IChldmVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ1tTcGVlY2ggUmVjb2duaXRpb24gRXJyb3JdOicsIGV2ZW50LmVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0SXNMaXN0ZW5pbmcoZmFsc2UpO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICByZWNvZ25pdGlvbi5vbmVuZCA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0SXNMaXN0ZW5pbmcoZmFsc2UpO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICByZWNvZ25pdGlvblJlZi5jdXJyZW50ID0gcmVjb2duaXRpb247XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG5cbiAgICBjb25zdCB0b2dnbGVWb2ljZUlucHV0ID0gKCkgPT4ge1xuICAgICAgICBpZiAoIXNwZWVjaFN1cHBvcnRlZCB8fCAhcmVjb2duaXRpb25SZWYuY3VycmVudCkge1xuICAgICAgICAgICAgYWxlcnQoJ0ZpdHVyIFZvaWNlIElucHV0IHRpZGFrIGRpZHVrdW5nIGRpIGJyb3dzZXIgaW5pLiBEaXNhcmFua2FuIG1lbmdndW5ha2FuIEdvb2dsZSBDaHJvbWUgYXRhdSBNaWNyb3NvZnQgRWRnZS4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNMaXN0ZW5pbmcpIHtcbiAgICAgICAgICAgIHJlY29nbml0aW9uUmVmLmN1cnJlbnQuc3RvcCgpO1xuICAgICAgICAgICAgc2V0SXNMaXN0ZW5pbmcoZmFsc2UpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICByZWNvZ25pdGlvblJlZi5jdXJyZW50LnN0YXJ0KCk7XG4gICAgICAgICAgICAgICAgc2V0SXNMaXN0ZW5pbmcodHJ1ZSk7XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBrZXlzID0gZ2V0R2VtaW5pQXBpS2V5cygpO1xuICAgICAgICBzZXRBcGlLZXlzKGtleXMpO1xuICAgICAgICBjb25zdCBpZHggPSBnZXRBY3RpdmVBcGlLZXlJbmRleCgpO1xuICAgICAgICBzZXRBY3RpdmVLZXlJZHgoaWR4KTtcbiAgICAgICAgc2V0SW5wdXRLZXlzVGV4dChrZXlzLmpvaW4oJ1xcbicpKTtcbiAgICAgICAgY29uc3Qgc2F2ZWRLZXkgPSBnZXRHZW1pbmlBcGlLZXkoKTtcbiAgICAgICAgc2V0QXBpS2V5KHNhdmVkS2V5KTtcblxuICAgICAgICAvLyBGZXRjaCB1c2VyIGZvcm1zIGZvciBAbWVudGlvbiBhbmQgY29udGV4dFxuICAgICAgICBnZXRNeUZvcm1zKCkudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgaWYgKHJlcy5vayAmJiBBcnJheS5pc0FycmF5KHJlcy5kYXRhKSkge1xuICAgICAgICAgICAgICAgIHNldFVzZXJGb3JtcyhyZXMuZGF0YSk7XG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRGb3JtSWRzRm9yRXhwb3J0KHJlcy5kYXRhLm1hcChmID0+IGYuaWQpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkuY2F0Y2goKCkgPT4ge30pO1xuICAgICAgICBnZXRNeVN1Ym1pdHRlZFJlc3BvbnNlcygpLnRoZW4ocmVzID0+IHtcbiAgICAgICAgICAgIGlmIChyZXMub2sgJiYgQXJyYXkuaXNBcnJheShyZXMuZGF0YSkpIHNldFN1Ym1pdHRlZFJlc3BvbnNlcyhyZXMuZGF0YSk7XG4gICAgICAgIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgICB9LCBbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oc3RvcmFnZUtleSwgSlNPTi5zdHJpbmdpZnkobWVzc2FnZXMpKTtcbiAgICAgICAgfSBjYXRjaCB7fVxuICAgICAgICBtZXNzYWdlc0VuZFJlZi5jdXJyZW50Py5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICB9LCBbbWVzc2FnZXMsIHN0b3JhZ2VLZXldKTtcblxuICAgIGNvbnN0IGhhbmRsZUNsZWFySGlzdG9yeSA9ICgpID0+IHtcbiAgICAgICAgaWYgKHdpbmRvdy5jb25maXJtKCdIYXB1cyBzZWx1cnVoIHJpd2F5YXQgcGVyY2FrYXBhbiBBSSBBc3Npc3RhbnQ/JykpIHtcbiAgICAgICAgICAgIGlmIChhYm9ydENvbnRyb2xsZXJSZWYuY3VycmVudCkgYWJvcnRDb250cm9sbGVyUmVmLmN1cnJlbnQuYWJvcnQoKTtcbiAgICAgICAgICAgIHNldE1lc3NhZ2VzKFtdKTtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkRm9ybShudWxsKTtcbiAgICAgICAgICAgIHRyeSB7IGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKHN0b3JhZ2VLZXkpOyB9IGNhdGNoIHt9XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZUtleXMgPSAoZSkgPT4ge1xuICAgICAgICBpZiAoZSkgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBjb25zdCBzYXZlZEtleXMgPSBzYXZlR2VtaW5pQXBpS2V5cyhpbnB1dEtleXNUZXh0KTtcbiAgICAgICAgc2V0QXBpS2V5cyhzYXZlZEtleXMpO1xuICAgICAgICBzZXRBY3RpdmVLZXlJZHgoMCk7XG4gICAgICAgIHNldEFwaUtleShzYXZlZEtleXNbMF0gfHwgJycpO1xuICAgICAgICBzZXRTaG93S2V5RWRpdG9yKGZhbHNlKTtcbiAgICB9O1xuXG4gICAgLy8gSGFuZGxlIHR5cGluZyBhbmQgQG1lbnRpb24gdHJpZ2dlclxuICAgIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcbiAgICAgICAgY29uc3QgdmFsID0gZS50YXJnZXQudmFsdWU7XG4gICAgICAgIGNvbnN0IHBvcyA9IGUudGFyZ2V0LnNlbGVjdGlvblN0YXJ0O1xuICAgICAgICBzZXRJbnB1dCh2YWwpO1xuXG4gICAgICAgIC8vIENoZWNrIGlmIGN1cnNvciBpcyByaWdodCBhZnRlciBhbiAnQCdcbiAgICAgICAgY29uc3QgdGV4dEJlZm9yZUN1cnNvciA9IHZhbC5zbGljZSgwLCBwb3MpO1xuICAgICAgICBjb25zdCBsYXN0QXRNYXRjaCA9IHRleHRCZWZvcmVDdXJzb3IubWF0Y2goL0AoW2EtekEtWjAtOV9cXHNdKikkLyk7XG5cbiAgICAgICAgaWYgKGxhc3RBdE1hdGNoKSB7XG4gICAgICAgICAgICBzZXRTaG93TWVudGlvbk1lbnUodHJ1ZSk7XG4gICAgICAgICAgICBzZXRNZW50aW9uRmlsdGVyKGxhc3RBdE1hdGNoWzFdLnRvTG93ZXJDYXNlKCkpO1xuICAgICAgICAgICAgc2V0TWVudGlvbkN1cnNvclBvcyhwb3MpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0U2hvd01lbnRpb25NZW51KGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTZWxlY3RNZW50aW9uRm9ybSA9IChmb3JtKSA9PiB7XG4gICAgICAgIGNvbnN0IHRleHRCZWZvcmVDdXJzb3IgPSBpbnB1dC5zbGljZSgwLCBtZW50aW9uQ3Vyc29yUG9zKTtcbiAgICAgICAgY29uc3QgdGV4dEFmdGVyQ3Vyc29yID0gaW5wdXQuc2xpY2UobWVudGlvbkN1cnNvclBvcyk7XG4gICAgICAgIGNvbnN0IGF0SW5kZXggPSB0ZXh0QmVmb3JlQ3Vyc29yLmxhc3RJbmRleE9mKCdAJyk7XG4gICAgICAgIFxuICAgICAgICBjb25zdCBuZXdUZXh0ID0gdGV4dEJlZm9yZUN1cnNvci5zbGljZSgwLCBhdEluZGV4KSArIGBAJHtmb3JtLnRpdGxlfSBgICsgdGV4dEFmdGVyQ3Vyc29yO1xuICAgICAgICBzZXRJbnB1dChuZXdUZXh0KTtcbiAgICAgICAgc2V0U2VsZWN0ZWRGb3JtKGZvcm0pO1xuICAgICAgICBzZXRTaG93TWVudGlvbk1lbnUoZmFsc2UpO1xuICAgICAgICBpZiAoaW5wdXRSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgaW5wdXRSZWYuY3VycmVudC5mb2N1cygpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdE1lbnRpb25IaXN0b3J5ID0gKGl0ZW0pID0+IHtcbiAgICAgICAgY29uc3QgdGV4dEJlZm9yZUN1cnNvciA9IGlucHV0LnNsaWNlKDAsIG1lbnRpb25DdXJzb3JQb3MpO1xuICAgICAgICBjb25zdCB0ZXh0QWZ0ZXJDdXJzb3IgPSBpbnB1dC5zbGljZShtZW50aW9uQ3Vyc29yUG9zKTtcbiAgICAgICAgY29uc3QgYXRJbmRleCA9IHRleHRCZWZvcmVDdXJzb3IubGFzdEluZGV4T2YoJ0AnKTtcbiAgICAgICAgY29uc3QgbGFiZWwgPSBTdHJpbmcoaXRlbS5mb3JtVGl0bGUgfHwgaXRlbS50aXRsZSB8fCAnRm9ybXVsaXInKS5yZXBsYWNlKC9ecml3YXlhdCBqYXdhYmFuXFxzKy9pLCAnJykudHJpbSgpO1xuICAgICAgICBzZXRJbnB1dCh0ZXh0QmVmb3JlQ3Vyc29yLnNsaWNlKDAsIGF0SW5kZXgpICsgYEBSaXdheWF0IEphd2FiYW4gJHtsYWJlbH0gYCArIHRleHRBZnRlckN1cnNvcik7XG4gICAgICAgIHNldFNlbGVjdGVkSGlzdG9yeShpdGVtKTtcbiAgICAgICAgc2V0U2VsZWN0ZWRGb3JtKG51bGwpO1xuICAgICAgICBzZXRTaG93TWVudGlvbk1lbnUoZmFsc2UpO1xuICAgICAgICBpbnB1dFJlZi5jdXJyZW50Py5mb2N1cygpO1xuICAgIH07XG5cbiAgICBjb25zdCBidWlsZFJlc3BvbnNlSGlzdG9yeUNvbnRleHQgPSBhc3luYyAoaXRlbSkgPT4ge1xuICAgICAgICBsZXQgZm9ybUlkID0gaXRlbS5mb3JtSWQgfHwgaXRlbS5mb3JtPy5pZDtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VJZCA9IGl0ZW0ucmVzcG9uc2VJZCB8fCBpdGVtLmlkO1xuICAgICAgICBpZiAoIWZvcm1JZCAmJiBpdGVtLmZvcm1MaW5rKSB7XG4gICAgICAgICAgICBjb25zdCBmb3JtUmVzID0gYXdhaXQgZ2V0UHVibGljRm9ybUJ5TGluayhpdGVtLmZvcm1MaW5rKTtcbiAgICAgICAgICAgIGZvcm1JZCA9IGZvcm1SZXM/LmRhdGE/LmlkIHx8IGZvcm1SZXM/LmRhdGE/LmZvcm1JZDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWZvcm1JZCB8fCAhcmVzcG9uc2VJZCkgcmV0dXJuIHsgY29udGV4dDogJ1xcbj09PSBSSVdBWUFUIEpBV0FCQU4gPT09XFxuRGF0YSByaXdheWF0IHRpZGFrIG1lbWlsaWtpIElEIHJlc3BvbnMgeWFuZyBsZW5na2FwLlxcbicsIHF1aXpRdWVzdGlvbnM6IFtdIH07XG4gICAgICAgIGxldCBbZGV0YWlsLCBhdHRlbXB0c10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICBnZXRSZXNwb25zZURldGFpbChmb3JtSWQsIHJlc3BvbnNlSWQpLFxuICAgICAgICAgICAgZ2V0UmVzcG9uc2VBdHRlbXB0cyhmb3JtSWQsIHJlc3BvbnNlSWQpLmNhdGNoKCgpID0+ICh7IG9rOiBmYWxzZSB9KSlcbiAgICAgICAgXSk7XG4gICAgICAgIC8vIFNvbWUgcmVzcG9uZGVudC1vd25lZCByZWNvcmRzIGFyZSBub3QgcmVhZGFibGUgdGhyb3VnaCB0aGUgb3duZXJcbiAgICAgICAgLy8gZGV0YWlsIHJvdXRlIGFuZCByZXR1cm4gNDA0LiBUaGUgZXhpc3RpbmcgcHVibGljIHJlc3VsdCByb3V0ZSBzdGlsbFxuICAgICAgICAvLyBleHBvc2VzIHRoZSBleGFjdCBhbnN3ZXIgYnJlYWtkb3duIHVzZWQgYnkgL3Jlc3VsdC5cbiAgICAgICAgaWYgKCFkZXRhaWw/Lm9rIHx8IGRldGFpbD8uc3RhdHVzID09PSA0MDQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZhbGxiYWNrID0gYXdhaXQgZ2V0UHVibGljUmVzcG9uc2VSZXN1bHQoaXRlbS5mb3JtTGluaywgcmVzcG9uc2VJZCwgaXRlbS5ndWVzdFRva2VuKTtcbiAgICAgICAgICAgIGlmIChmYWxsYmFjaz8ub2spIGRldGFpbCA9IGZhbGxiYWNrO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSBkZXRhaWw/LmRhdGEgfHwgZGV0YWlsPy5yZXNwb25zZSB8fCB7fTtcbiAgICAgICAgY29uc3QgYW5zd2VycyA9IHBheWxvYWQuYW5zd2VycyB8fCBwYXlsb2FkLnJlc3BvbnNlcyB8fCBwYXlsb2FkLmFuc3dlckRldGFpbHMgfHwgcGF5bG9hZC5hbnN3ZXJJdGVtcyB8fCBbXTtcbiAgICAgICAgY29uc3QgYXR0ZW1wdERhdGEgPSBhdHRlbXB0cz8uZGF0YSB8fCBhdHRlbXB0cz8uYXR0ZW1wdHMgfHwgW107XG4gICAgICAgIGNvbnN0IHF1aXpRdWVzdGlvbnMgPSBhbnN3ZXJzLm1hcChhID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG9wdGlvbnMgPSBhLm9wdGlvbnMgfHwgYS5xdWVzdGlvbk9wdGlvbnMgfHwgYS5jaG9pY2VzIHx8IFtdO1xuICAgICAgICAgICAgaWYgKCFhLnF1ZXN0aW9uICYmICFhLnF1ZXN0aW9uVGV4dCB8fCAhQXJyYXkuaXNBcnJheShvcHRpb25zKSB8fCBvcHRpb25zLmxlbmd0aCA8IDIpIHJldHVybiBudWxsO1xuICAgICAgICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IG9wdGlvbnMubWFwKG8gPT4gdHlwZW9mIG8gPT09ICdzdHJpbmcnID8geyB0ZXh0OiBvIH0gOiBvKTtcbiAgICAgICAgICAgIGNvbnN0IGNvcnJlY3RBbnN3ZXIgPSBhLmNvcnJlY3RBbnN3ZXIgfHwgYS5jb3JyZWN0T3B0aW9uIHx8IGEuY29ycmVjdEFuc3dlclRleHQgfHwgJyc7XG4gICAgICAgICAgICBjb25zdCBjb3JyZWN0SW5kZXggPSBub3JtYWxpemVkLmZpbmRJbmRleChvID0+IG8uaXNDb3JyZWN0ID09PSB0cnVlIHx8IG8uY29ycmVjdCA9PT0gdHJ1ZSB8fCAoY29ycmVjdEFuc3dlciAmJiAoby5vcHRpb25UZXh0IHx8IG8udGV4dCkgPT09IGNvcnJlY3RBbnN3ZXIpKTtcbiAgICAgICAgICAgIGlmIChjb3JyZWN0SW5kZXggPCAwKSByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIHJldHVybiB7IHF1ZXN0aW9uOiBhLnF1ZXN0aW9uIHx8IGEucXVlc3Rpb25UZXh0LCBvcHRpb25zOiBub3JtYWxpemVkLm1hcChvID0+IG8ub3B0aW9uVGV4dCB8fCBvLnRleHQgfHwgJycpLCBjb3JyZWN0SW5kZXggfTtcbiAgICAgICAgfSkuZmlsdGVyKEJvb2xlYW4pLnNsaWNlKDAsIDUpO1xuICAgICAgICByZXR1cm4geyBjb250ZXh0OiBgXG49PT0gUklXQVlBVCBKQVdBQkFOIFBFUlNPTkFMOiBcIiR7aXRlbS5mb3JtVGl0bGUgfHwgaXRlbS50aXRsZSB8fCAnRm9ybXVsaXInfVwiID09PVxuLSBGb3JtIElEOiAke2Zvcm1JZH1cbi0gUmVzcG9uc2UgSUQ6ICR7cmVzcG9uc2VJZH1cbi0gU2tvcjogJHtwYXlsb2FkLnNjb3JlID8/IGl0ZW0uc2NvcmUgPz8gJ1RpZGFrIHRlcnNlZGlhJ31cbi0gU3RhdHVzOiAke3BheWxvYWQuc3RhdHVzIHx8IGl0ZW0uc3RhdHVzIHx8ICdUZXJraXJpbSd9XG4tIERldGFpbCBwZXJjb2JhYW46ICR7SlNPTi5zdHJpbmdpZnkoYXR0ZW1wdERhdGEpLnNsaWNlKDAsIDEyMDAwKX1cbi0tLSBKQVdBQkFOIFBFUiBTT0FMIChndW5ha2FuIGRhdGEgaW5pLCBqYW5nYW4gbWVuZWJhaykgLS0tXG4ke2Fuc3dlcnMubGVuZ3RoID8gYW5zd2Vycy5tYXAoKGEsIGkpID0+IGAke2kgKyAxfS4gU29hbDogJHthLnF1ZXN0aW9uIHx8IGEucXVlc3Rpb25UZXh0IHx8ICctJ30gfCBKYXdhYmFuIHNheWE6ICR7YS5vcHRpb25UZXh0IHx8IGEuYW5zd2VyVGV4dCB8fCBhLmFuc3dlciB8fCBhLnNlbGVjdGVkQW5zd2VyIHx8ICctJ30gfCBLdW5jaTogJHthLmNvcnJlY3RBbnN3ZXIgfHwgYS5jb3JyZWN0T3B0aW9uIHx8IGEuY29ycmVjdEFuc3dlclRleHQgfHwgJy0nfSB8IFN0YXR1czogJHthLmlzQ29ycmVjdCA9PSBudWxsID8gKGEuY29ycmVjdCA9PSBudWxsID8gJ1RpZGFrIHRlcnNlZGlhJyA6IGEuY29ycmVjdCA/ICdCZW5hcicgOiAnU2FsYWgnKSA6IGEuaXNDb3JyZWN0ID8gJ0JlbmFyJyA6ICdTYWxhaCd9YCkuam9pbignXFxuJykgOiAnRW5kcG9pbnQgdGlkYWsgbWVuZ2VtYmFsaWthbiBkYWZ0YXIgamF3YWJhbiBwZXIgc29hbC4nfVxuYCwgcXVpelF1ZXN0aW9ucyB9O1xuICAgIH07XG5cbiAgICAvLyBGaWx0ZXIgZm9ybXMgYmFzZWQgb24gYnVsa0RheXNGaWx0ZXJcbiAgICBjb25zdCBmaWx0ZXJlZEZvcm1zRm9yQnVsayA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoYnVsa0RheXNGaWx0ZXIgPT09ICdhbGwnKSByZXR1cm4gdXNlckZvcm1zO1xuICAgICAgICBjb25zdCBkYXlzID0gcGFyc2VJbnQoYnVsa0RheXNGaWx0ZXIsIDEwKTtcbiAgICAgICAgY29uc3QgY3V0b2ZmID0gbmV3IERhdGUoKTtcbiAgICAgICAgY3V0b2ZmLnNldERhdGUoY3V0b2ZmLmdldERhdGUoKSAtIGRheXMpO1xuICAgICAgICByZXR1cm4gdXNlckZvcm1zLmZpbHRlcihmID0+IGYuY3JlYXRlZEF0ICYmIG5ldyBEYXRlKGYuY3JlYXRlZEF0KSA+PSBjdXRvZmYpO1xuICAgIH0sIFt1c2VyRm9ybXMsIGJ1bGtEYXlzRmlsdGVyXSk7XG5cbiAgICBjb25zdCB0b2dnbGVTZWxlY3RBbGxCdWxrID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBjdXJyZW50RmlsdGVyZWRJZHMgPSBmaWx0ZXJlZEZvcm1zRm9yQnVsay5tYXAoZiA9PiBmLmlkKTtcbiAgICAgICAgY29uc3QgYWxsU2VsZWN0ZWQgPSBjdXJyZW50RmlsdGVyZWRJZHMuZXZlcnkoaWQgPT4gc2VsZWN0ZWRGb3JtSWRzRm9yRXhwb3J0LmluY2x1ZGVzKGlkKSk7XG4gICAgICAgIGlmIChhbGxTZWxlY3RlZCkge1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWRGb3JtSWRzRm9yRXhwb3J0KHByZXYgPT4gcHJldi5maWx0ZXIoaWQgPT4gIWN1cnJlbnRGaWx0ZXJlZElkcy5pbmNsdWRlcyhpZCkpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkRm9ybUlkc0ZvckV4cG9ydChwcmV2ID0+IEFycmF5LmZyb20obmV3IFNldChbLi4ucHJldiwgLi4uY3VycmVudEZpbHRlcmVkSWRzXSkpKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCB0b2dnbGVTZWxlY3RGb3JtRm9yQnVsayA9IChpZCkgPT4ge1xuICAgICAgICBzZXRTZWxlY3RlZEZvcm1JZHNGb3JFeHBvcnQocHJldiA9PiBcbiAgICAgICAgICAgIHByZXYuaW5jbHVkZXMoaWQpID8gcHJldi5maWx0ZXIoeCA9PiB4ICE9PSBpZCkgOiBbLi4ucHJldiwgaWRdXG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIC8vIFNpbmdsZSBleHBvcnQgdHJpZ2dlclxuICAgIGNvbnN0IGhhbmRsZVNpbmdsZUV4cG9ydCA9IGFzeW5jIChmb3JtSWQsIGZvcm1UaXRsZSwgZm9ybWF0ID0gJ2NzdicpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGV4cG9ydEZvcm1SZXNwb25zZXMoZm9ybUlkLCBmb3JtYXQpO1xuICAgICAgICAgICAgc2V0TWVzc2FnZXMocHJldiA9PiBbXG4gICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgICAgICBzZW5kZXI6ICdib3QnLFxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiBgQmVyaGFzaWwgbWVuZ3VuZHVoIGJlcmthcyByZXNwb25zICoqXCIke2Zvcm1UaXRsZX1cIioqIGRhbGFtIGZvcm1hdCAqKiR7Zm9ybWF0LnRvVXBwZXJDYXNlKCl9KiouYCxcbiAgICAgICAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBhbGVydChgR2FnYWwgbWVuZ2Vrc3BvciBmb3JtOiAke2Vyci5tZXNzYWdlfWApO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIEJ1bGsgRXhwb3J0IEZ1bmN0aW9uYWxpdHlcbiAgICBjb25zdCBleGVjdXRlQnVsa0V4cG9ydCA9IGFzeW5jICh0YXJnZXRGb3JtcywgdGltZVJhbmdlTGFiZWwgPSAnVGVycGlsaWgnKSA9PiB7XG4gICAgICAgIGlmICh0YXJnZXRGb3Jtcy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgICAgICAgc2V0QnVsa0V4cG9ydGluZyh0cnVlKTtcbiAgICAgICAgc2V0QnVsa1Byb2dyZXNzKHsgY3VycmVudDogMCwgdG90YWw6IHRhcmdldEZvcm1zLmxlbmd0aCwgbmFtZTogJycgfSk7XG4gICAgICAgIHNldFNob3dCdWxrTW9kYWwoZmFsc2UpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhcmdldEZvcm1zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZiA9IHRhcmdldEZvcm1zW2ldO1xuICAgICAgICAgICAgICAgIHNldEJ1bGtQcm9ncmVzcyh7IGN1cnJlbnQ6IGkgKyAxLCB0b3RhbDogdGFyZ2V0Rm9ybXMubGVuZ3RoLCBuYW1lOiBmLnRpdGxlIH0pO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGV4cG9ydEZvcm1SZXNwb25zZXMoZi5pZCwgJ2NzdicpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2gge31cblxuICAgICAgICAgICAgICAgIC8vIFNtYWxsIGRlbGF5IHRvIHByZXZlbnQgYnJvd3NlciBkb3dubG9hZCB0aHJvdHRsaW5nXG4gICAgICAgICAgICAgICAgYXdhaXQgbmV3IFByb21pc2UociA9PiBzZXRUaW1lb3V0KHIsIDYwMCkpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+IFtcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6IERhdGUubm93KCksXG4gICAgICAgICAgICAgICAgICAgIHNlbmRlcjogJ2JvdCcsXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IGDinIUgKipCdWxrIEV4cG9ydCBTZWxlc2FpISoqIEJlcmhhc2lsIG1lbmd1bmR1aCBmaWxlIENTViB0ZXJwaXNhaCB1bnR1ayAqKiR7dGFyZ2V0Rm9ybXMubGVuZ3RofSBmb3JtdWxpcioqICgke3RpbWVSYW5nZUxhYmVsfSkuYCxcbiAgICAgICAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+IFtcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6IERhdGUubm93KCksXG4gICAgICAgICAgICAgICAgICAgIHNlbmRlcjogJ2JvdCcsXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IGDimqDvuI8gVGVyamFkaSBrZW5kYWxhIHNhYXQgbWVsYWt1a2FuIGJ1bGsgZXhwb3J0OiAke2Vyci5tZXNzYWdlfWAsXG4gICAgICAgICAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgXSk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRCdWxrRXhwb3J0aW5nKGZhbHNlKTtcbiAgICAgICAgICAgIHNldEJ1bGtQcm9ncmVzcyhudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBEZWVwIGNvbnRleHQgYWdncmVnYXRvciBmb3IgR2VtaW5pXG4gICAgY29uc3QgYnVpbGREZWVwRm9ybUNvbnRleHQgPSBhc3luYyAodGFyZ2V0Rm9ybSkgPT4ge1xuICAgICAgICBpZiAoIXRhcmdldEZvcm0pIHJldHVybiAnJztcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gQS00IFBhZ2luYXRpb24gTG9vcDogRmV0Y2ggYWxsIHJlc3BvbnNlcyBhY3Jvc3MgYWxsIHBhZ2VzIHVwIHRvIHRvdGFsUGFnZXNcbiAgICAgICAgICAgIGxldCBhbGxSZXNwb25zZXMgPSBbXTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgbGV0IHBhZ2UgPSAxO1xuICAgICAgICAgICAgICAgIGxldCB0b3RhbFBhZ2VzID0gMTtcbiAgICAgICAgICAgICAgICBkbyB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdldEZvcm1SZXNwb25zZXModGFyZ2V0Rm9ybS5pZCwgeyBwYWdlLCBwYWdlU2l6ZTogMTAwIH0pLmNhdGNoKCgpID0+ICh7fSkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzPy5vaykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGFnZUl0ZW1zID0gQXJyYXkuaXNBcnJheShyZXMuZGF0YSkgPyByZXMuZGF0YSA6IChyZXMuZGF0YT8uaXRlbXMgfHwgW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgYWxsUmVzcG9uc2VzID0gWy4uLmFsbFJlc3BvbnNlcywgLi4ucGFnZUl0ZW1zXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBnID0gcmVzLnBhZ2luYXRpb24gfHwgcmVzLmRhdGE/LnBhZ2luYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICB0b3RhbFBhZ2VzID0gcGc/LnRvdGFsUGFnZXMgfHwgTWF0aC5jZWlsKChwZz8udG90YWxDb3VudCB8fCBhbGxSZXNwb25zZXMubGVuZ3RoKSAvIDEwMCkgfHwgMTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHBhZ2UrKztcbiAgICAgICAgICAgICAgICB9IHdoaWxlIChwYWdlIDw9IHRvdGFsUGFnZXMgJiYgcGFnZSA8PSAxMCk7XG4gICAgICAgICAgICB9IGNhdGNoIHt9XG5cbiAgICAgICAgICAgIGNvbnN0IFtmb3JtRGV0YWlsLCBxdWVzdGlvbnNSZXMsIG1vbml0b3JpbmdSZXMsIGFuYWx5dGljc1Jlc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICAgICAgZ2V0Rm9ybUJ5SWQodGFyZ2V0Rm9ybS5pZCkuY2F0Y2goKCkgPT4gKHt9KSksXG4gICAgICAgICAgICAgICAgZ2V0UXVlc3Rpb25zKHRhcmdldEZvcm0uaWQpLmNhdGNoKCgpID0+ICh7fSkpLFxuICAgICAgICAgICAgICAgIGdldEV4YW1Nb25pdG9yaW5nKHRhcmdldEZvcm0uaWQpLmNhdGNoKCgpID0+ICh7fSkpLFxuICAgICAgICAgICAgICAgIGdldEZvcm1BbmFseXRpY3ModGFyZ2V0Rm9ybS5pZCkuY2F0Y2goKCkgPT4gKHt9KSlcbiAgICAgICAgICAgIF0pO1xuXG4gICAgICAgICAgICBjb25zdCBmRGF0YSA9IGZvcm1EZXRhaWwuZGF0YSB8fCB0YXJnZXRGb3JtO1xuICAgICAgICAgICAgY29uc3QgcUxpc3QgPSBBcnJheS5pc0FycmF5KHF1ZXN0aW9uc1Jlcy5kYXRhKSA/IHF1ZXN0aW9uc1Jlcy5kYXRhIDogW107XG4gICAgICAgICAgICBjb25zdCByTGlzdCA9IGFsbFJlc3BvbnNlcztcbiAgICAgICAgICAgIGNvbnN0IG1EYXRhID0gbW9uaXRvcmluZ1Jlcy5kYXRhIHx8IHt9O1xuICAgICAgICAgICAgY29uc3QgYURhdGEgPSBhbmFseXRpY3NSZXMuZGF0YSB8fCB7fTtcblxuICAgICAgICAgICAgLy8gMS4gU2NvcmluZyAmIFJhbmtpbmcgc3RhdGlzdGljc1xuICAgICAgICAgICAgY29uc3Qgc2NvcmVkUmVzcG9uc2VzID0gckxpc3RcbiAgICAgICAgICAgICAgICAuZmlsdGVyKHIgPT4gci5zY29yZSAhPSBudWxsICYmICFpc05hTihOdW1iZXIoci5zY29yZSkpKVxuICAgICAgICAgICAgICAgIC5tYXAociA9PiAoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiByLnJlc3BvbmRlbnROYW1lIHx8IHIudXNlckVtYWlsIHx8IGBSZXNwb25kZW4gIyR7ci5pZH1gLFxuICAgICAgICAgICAgICAgICAgICBzY29yZTogTnVtYmVyKHIuc2NvcmUpLFxuICAgICAgICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogci5zdWJtaXR0ZWRBdCB8fCAnLScsXG4gICAgICAgICAgICAgICAgICAgIGR1cmF0aW9uTWludXRlczogci5kdXJhdGlvbk1pbnV0ZXMgfHwgJy0nLFxuICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnNjb3JlIC0gYS5zY29yZSk7XG5cbiAgICAgICAgICAgIGNvbnN0IHRvdGFsUmVzcG9uZGVudHMgPSByTGlzdC5sZW5ndGg7XG4gICAgICAgICAgICBjb25zdCBoaWdoZXN0U2NvcmVyID0gc2NvcmVkUmVzcG9uc2VzLmxlbmd0aCA+IDAgPyBzY29yZWRSZXNwb25zZXNbMF0gOiBudWxsO1xuICAgICAgICAgICAgY29uc3QgbG93ZXN0U2NvcmVyID0gc2NvcmVkUmVzcG9uc2VzLmxlbmd0aCA+IDAgPyBzY29yZWRSZXNwb25zZXNbc2NvcmVkUmVzcG9uc2VzLmxlbmd0aCAtIDFdIDogbnVsbDtcbiAgICAgICAgICAgIGNvbnN0IGF2Z1Njb3JlID0gc2NvcmVkUmVzcG9uc2VzLmxlbmd0aCA+IDBcbiAgICAgICAgICAgICAgICA/IChzY29yZWRSZXNwb25zZXMucmVkdWNlKChhY2MsIGN1cnIpID0+IGFjYyArIGN1cnIuc2NvcmUsIDApIC8gc2NvcmVkUmVzcG9uc2VzLmxlbmd0aCkudG9GaXhlZCgxKVxuICAgICAgICAgICAgICAgIDogKGFEYXRhLmF2ZXJhZ2VTY29yZSAhPSBudWxsID8gTnVtYmVyKGFEYXRhLmF2ZXJhZ2VTY29yZSkudG9GaXhlZCgxKSA6ICctJyk7XG5cbiAgICAgICAgICAgIC8vIDIuIFBvaW50IFdlaWdodCAoQm9ib3QgUG9pbikgJiBTY29yaW5nIENvbmZpZ3VyYXRpb25cbiAgICAgICAgICAgIGNvbnN0IHNjb3JhYmxlUXVlc3Rpb25zID0gcUxpc3QuZmlsdGVyKHEgPT4gcS5pc1Njb3JhYmxlICE9PSBmYWxzZSk7XG4gICAgICAgICAgICBjb25zdCByYXdQb2ludHMgPSBzY29yYWJsZVF1ZXN0aW9ucy5tYXAocSA9PiAocS5wb2ludHMgIT0gbnVsbCAmJiBOdW1iZXIocS5wb2ludHMpID4gMCA/IE51bWJlcihxLnBvaW50cykgOiAxKSk7XG4gICAgICAgICAgICBjb25zdCB0b3RhbE1heFBvaW50cyA9IHJhd1BvaW50cy5yZWR1Y2UoKHN1bSwgcCkgPT4gc3VtICsgcCwgMCk7XG4gICAgICAgICAgICBjb25zdCBoaWdoZXN0UG9pbnRWYWwgPSByYXdQb2ludHMubGVuZ3RoID4gMCA/IE1hdGgubWF4KC4uLnJhd1BvaW50cykgOiAwO1xuICAgICAgICAgICAgY29uc3QgbG93ZXN0UG9pbnRWYWwgPSByYXdQb2ludHMubGVuZ3RoID4gMCA/IE1hdGgubWluKC4uLnJhd1BvaW50cykgOiAwO1xuICAgICAgICAgICAgY29uc3QgaXNVbmlmb3JtUG9pbnRzID0gcmF3UG9pbnRzLmxlbmd0aCA+IDAgJiYgKGhpZ2hlc3RQb2ludFZhbCA9PT0gbG93ZXN0UG9pbnRWYWwpO1xuXG4gICAgICAgICAgICBjb25zdCBoaWdoZXN0UG9pbnRRdWVzdGlvbnMgPSBxTGlzdFxuICAgICAgICAgICAgICAgIC5tYXAoKHEsIGlkeCkgPT4gKHsgLi4ucSwgcU51bWJlcjogaWR4ICsgMSwgcG9pbnRWYWw6IHEucG9pbnRzICE9IG51bGwgJiYgTnVtYmVyKHEucG9pbnRzKSA+IDAgPyBOdW1iZXIocS5wb2ludHMpIDogMSB9KSlcbiAgICAgICAgICAgICAgICAuZmlsdGVyKHEgPT4gcS5pc1Njb3JhYmxlICE9PSBmYWxzZSAmJiBxLnBvaW50VmFsID09PSBoaWdoZXN0UG9pbnRWYWwpO1xuXG4gICAgICAgICAgICAvLyAzLiBBbnRpLWNoZWF0aW5nICYgRXhhbSBNb25pdG9yaW5nIHN0YXRpc3RpY3NcbiAgICAgICAgICAgIGNvbnN0IHNlc3Npb25zID0gQXJyYXkuaXNBcnJheShtRGF0YS5zZXNzaW9ucykgPyBtRGF0YS5zZXNzaW9ucyA6IFtdO1xuICAgICAgICAgICAgY29uc3QgdGFiU3dpdGNoZXJzID0gc2Vzc2lvbnNcbiAgICAgICAgICAgICAgICAuZmlsdGVyKHMgPT4gKHMudGFiU3dpdGNoQ291bnQgJiYgcy50YWJTd2l0Y2hDb3VudCA+IDApIHx8IChzLnZpb2xhdGlvbnMgJiYgcy52aW9sYXRpb25zLmxlbmd0aCA+IDApKVxuICAgICAgICAgICAgICAgIC5tYXAocyA9PiAoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBzLnN0dWRlbnROYW1lIHx8IHMucmVzcG9uZGVudE5hbWUgfHwgJ1Npc3dhJyxcbiAgICAgICAgICAgICAgICAgICAgdGFiU3dpdGNoZXM6IHMudGFiU3dpdGNoQ291bnQgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBzLnN0YXR1cyB8fCAnQWN0aXZlJyxcbiAgICAgICAgICAgICAgICAgICAgdmlvbGF0aW9uczogKHMudmlvbGF0aW9ucyB8fCBbXSkubWFwKHYgPT4gYCR7di5ldmVudFR5cGV9IHBhZGEgJHt2LnRpbWVzdGFtcH1gKS5qb2luKCcsICcpXG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICAvLyA0LiBRdWVzdGlvbiBkZXRhaWxzIHdpdGggZXhwbGljaXQgUG9pbnRzLCBTY29yYWJsZSwgUmVxdWlyZWQgJiBDb3JyZWN0IEFuc3dlclxuICAgICAgICAgICAgY29uc3QgdHlwZUxhYmVsTWFwID0geyAxOiAnRXNzYXknLCAyOiAnUGlsaWhhbiBHYW5kYScsIDM6ICdDaGVja2JveCcsIDQ6ICdEYXRlL1RpbWUnLCA1OiAnQmVuYXIvU2FsYWgnIH07XG4gICAgICAgICAgICBjb25zdCBxdWVzdGlvblN0YXRzID0gcUxpc3QubWFwKChxLCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB0eXBlTmFtZSA9IHR5cGVMYWJlbE1hcFtxLnR5cGVJZF0gfHwgYFRpcGUgJHtxLnR5cGVJZH1gO1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvcnJlY3RPcHQgPSBxLm9wdGlvbnM/LmZpbmQobyA9PiBvLmlzQ29ycmVjdCk/Lm9wdGlvblRleHQgfHwgcS5jb3JyZWN0QW5zd2VyIHx8IChxLmlzU2NvcmFibGUgPT09IGZhbHNlID8gJyhUaWRhayBkaW5pbGFpKScgOiAnLScpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHBvaW50RGVzYyA9IHEuaXNTY29yYWJsZSA9PT0gZmFsc2UgXG4gICAgICAgICAgICAgICAgICAgID8gJ1RpZGFrIGRpbmlsYWkgKDAgcG9pbiknIFxuICAgICAgICAgICAgICAgICAgICA6IHEucG9pbnRzICE9IG51bGwgXG4gICAgICAgICAgICAgICAgICAgID8gYCR7cS5wb2ludHN9IHBvaW5gIFxuICAgICAgICAgICAgICAgICAgICA6ICdEZWZhdWx0ICgxIHBvaW4gLyBib2JvdCBzYW1hIHJhdGEpJztcbiAgICAgICAgICAgICAgICByZXR1cm4gYCR7aWR4ICsgMX0uIFtUaXBlOiAke3R5cGVOYW1lfV0gXCIke3EucXVlc3Rpb259XCIgfCBCb2JvdDogJHtwb2ludERlc2N9IHwgV2FqaWI6ICR7cS5pc1JlcXVpcmVkID8gJ1lhJyA6ICdUaWRhayd9IHwgS3VuY2kvSmF3YWJhbiBEaWhhcmFwa2FuOiAke2NvcnJlY3RPcHR9YDtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyA1LiBGb3JtIFNldHRpbmdzXG4gICAgICAgICAgICBjb25zdCBmU2V0dGluZ3MgPSBmRGF0YS5zZXR0aW5ncyB8fCB7fTtcbiAgICAgICAgICAgIGNvbnN0IHRpbWVyRGVzYyA9IChmRGF0YS50aW1lckR1cmF0aW9uIHx8IGZTZXR0aW5ncy50aW1lckR1cmF0aW9uKSBcbiAgICAgICAgICAgICAgICA/IGAke01hdGgucm91bmQoKGZEYXRhLnRpbWVyRHVyYXRpb24gfHwgZlNldHRpbmdzLnRpbWVyRHVyYXRpb24pIC8gNjApfSBtZW5pdGAgXG4gICAgICAgICAgICAgICAgOiAnVGlkYWsgYWRhIGJhdGFzIHdha3R1JztcblxuICAgICAgICAgICAgcmV0dXJuIGBcbj09PSBEQVRBIExFTkdLQVAgRk9STVVMSVI6IFwiJHtmRGF0YS50aXRsZSB8fCB0YXJnZXRGb3JtLnRpdGxlfVwiID09PVxuLSBJRCBGb3JtdWxpcjogJHt0YXJnZXRGb3JtLmlkfVxuLSBEZXNrcmlwc2k6ICR7ZkRhdGEuZGVzY3JpcHRpb24gfHwgJy0nfVxuLSBTdGF0dXM6ICR7ZkRhdGEuc3RhdHVzIHx8ICdQdWJsaXNoZWQnfVxuLSBUb3RhbCBCdXRpciBTb2FsOiAke3FMaXN0Lmxlbmd0aH0gYnV0aXIgKCR7c2NvcmFibGVRdWVzdGlvbnMubGVuZ3RofSBkaW5pbGFpLCAke3FMaXN0Lmxlbmd0aCAtIHNjb3JhYmxlUXVlc3Rpb25zLmxlbmd0aH0gdGlkYWsgZGluaWxhaSlcbi0gVG90YWwgUmVzcG9uZGVuIE1hc3VrOiAke3RvdGFsUmVzcG9uZGVudHN9IG9yYW5nXG4tIFBlbmdhdHVyYW46IEJhdGFzIFdha3R1OiAke3RpbWVyRGVzY30gfCBNb2RlIFVqaWFuOiAke2ZEYXRhLmlzRXhhbU1vZGUgfHwgZlNldHRpbmdzLmlzRXhhbU1vZGUgPyAnQWt0aWYnIDogJ05vbi1ha3RpZid9IHwgQWNhayBTb2FsOiAke2ZEYXRhLnJhbmRvbWl6ZVF1ZXN0aW9ucyB8fCBmU2V0dGluZ3MucmFuZG9taXplUXVlc3Rpb25zID8gJ1lhJyA6ICdUaWRhayd9XG5cbi0tLSBJTkZPUk1BU0kgQk9CT1QgUE9JTiAmIFNLT1IgTUFLU0lNQUwgLS0tXG4tIFRvdGFsIFBvaW4gTWFrc2ltYWwgRm9ybXVsaXI6ICR7dG90YWxNYXhQb2ludHN9IHBvaW5cbi0gRGlzdHJpYnVzaSBCb2JvdCBTb2FsOiAke2lzVW5pZm9ybVBvaW50cyA/IGBTYW1hIHJhdGEgdW50dWsgc2VtdWEgc29hbCAoJHtoaWdoZXN0UG9pbnRWYWx9IHBvaW4gcGVyIGJ1dGlyKWAgOiBgQmVydmFyaWFzaSAoVGVydGluZ2dpOiAke2hpZ2hlc3RQb2ludFZhbH0gcG9pbiwgVGVyZW5kYWg6ICR7bG93ZXN0UG9pbnRWYWx9IHBvaW4pYH1cbi0gQnV0aXIgU29hbCBkZW5nYW4gQm9ib3QgUG9pbiBUZXJ0aW5nZ2kgKCR7aGlnaGVzdFBvaW50VmFsfSBwb2luKTpcbiR7aGlnaGVzdFBvaW50UXVlc3Rpb25zLmxlbmd0aCA+IDAgXG4gICAgPyBoaWdoZXN0UG9pbnRRdWVzdGlvbnMubWFwKHEgPT4gYCAgKiBTb2FsIE5vLiAke3EucU51bWJlcn0gKCR7cS5xdWVzdGlvbiA/IHEucXVlc3Rpb24uc2xpY2UoMCwgNjApIDogJ1RhbnBhIGp1ZHVsJ30uLi4pIDogJHtxLnBvaW50VmFsfSBwb2luYCkuam9pbignXFxuJylcbiAgICA6ICcgICogU2VtdWEgc29hbCBtZW1pbGlraSBib2JvdCBkZWZhdWx0J31cblxuLS0tIFNUQVRJU1RJSyBTS09SICYgUEVSSU5HS0FUIFJFU1BPTkRFTiAtLS1cbi0gTmlsYWkgUmF0YS1yYXRhOiAke2F2Z1Njb3JlICE9PSAnLScgPyBgJHthdmdTY29yZX0lYCA6ICctJ31cbi0gTmlsYWkgVGVydGluZ2dpOiAke2hpZ2hlc3RTY29yZXIgPyBgJHtoaWdoZXN0U2NvcmVyLm5hbWV9IChTa29yOiAke2hpZ2hlc3RTY29yZXIuc2NvcmV9JSlgIDogJ0JlbHVtIGFkYSBkYXRhIG5pbGFpJ31cbi0gTmlsYWkgVGVyZW5kYWg6ICR7bG93ZXN0U2NvcmVyID8gYCR7bG93ZXN0U2NvcmVyLm5hbWV9IChTa29yOiAke2xvd2VzdFNjb3Jlci5zY29yZX0lKWAgOiAnQmVsdW0gYWRhIGRhdGEgbmlsYWknfVxuLSBDYXRhdGFuIFBlbmlsYWlhbjogJHt0b3RhbFJlc3BvbmRlbnRzID4gMCAmJiBzY29yZWRSZXNwb25zZXMubGVuZ3RoID09PSAwIFxuICAgID8gYFRlcmRhcGF0ICR7dG90YWxSZXNwb25kZW50c30gcmVzcG9ucyBtYXN1aywgbmFtdW4gc2tvciBvdG9tYXRpcyBiZWx1bSB0ZXJoaXR1bmcgKGtlbXVuZ2tpbmFuIGJlcmlzaSBzb2FsIEVzc2F5IHlhbmcgYmVsdW0gZGluaWxhaSBtYW51YWwvQUkgYXRhdSBtZXJ1cGFrYW4gZm9ybXVsaXIgc3VydmVpL25vbi1rdWlzKS5gIFxuICAgIDogYFNlYmFueWFrICR7c2NvcmVkUmVzcG9uc2VzLmxlbmd0aH0gZGFyaSAke3RvdGFsUmVzcG9uZGVudHN9IHJlc3BvbmRlbiB0ZWxhaCBtZW1pbGlraSBuaWxhaSB0ZXJoaXR1bmcuYH1cbi0gRGFmdGFyIExlbmdrYXAgUmFua2luZyBSZXNwb25kZW46XG4ke3Njb3JlZFJlc3BvbnNlcy5sZW5ndGggPiAwIFxuICAgID8gc2NvcmVkUmVzcG9uc2VzLm1hcCgociwgaSkgPT4gYCAgJHtpICsgMX0uICR7ci5uYW1lfSAtIFNrb3I6ICR7ci5zY29yZX0lIChTZWxlc2FpOiAke3Iuc3VibWl0dGVkQXR9KWApLmpvaW4oJ1xcbicpXG4gICAgOiAnICAoQmVsdW0gYWRhIHJlc3BvbnMgZGVuZ2FuIG5pbGFpIHRlcmhpdHVuZyknfVxuXG4tLS0gTU9OSVRPUklORyAmIExPRyBQRUxBTkdHQVJBTiAoVEFCIFNXSVRDSCAvIEtFQ1VSQU5HQU4pIC0tLVxuLSBUb3RhbCBQZXNlcnRhIFVqaWFuIFNlZGFuZyBCZXJsYW5nc3VuZzogJHttRGF0YS5pblByb2dyZXNzQ291bnQgfHwgMH1cbi0gTG9nIFBlbGFuZ2dhcmFuICYgUGluZGFoIFRhYiBTaXN3YTpcbiR7dGFiU3dpdGNoZXJzLmxlbmd0aCA+IDAgXG4gICAgPyB0YWJTd2l0Y2hlcnMubWFwKHMgPT4gYCAgKiAke3MubmFtZX06ICR7cy50YWJTd2l0Y2hlc314IHBpbmRhaCB0YWIgLyBhbHQtdGFiIHwgU3RhdHVzOiAke3Muc3RhdHVzfSAke3MudmlvbGF0aW9ucyA/IGB8IExvZzogJHtzLnZpb2xhdGlvbnN9YCA6ICcnfWApLmpvaW4oJ1xcbicpXG4gICAgOiAnICAqIFRpZGFrIGFkYSBrZWN1cmFuZ2FuIGF0YXUgcGVsYW5nZ2FyYW4gcGluZGFoIHRhYiB5YW5nIHRlcmRldGVrc2kuJ31cblxuLS0tIERBRlRBUiBMRU5HS0FQIEJVVElSIFNPQUwsIEJPQk9UICYgS1VOQ0kgSkFXQUJBTiAtLS1cbiR7cXVlc3Rpb25TdGF0cy5qb2luKCdcXG4nKX1cbmA7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgcmV0dXJuIGBcbj09PSBEQVRBIEZPUk1VTElSOiBcIiR7dGFyZ2V0Rm9ybS50aXRsZX1cIiA9PT1cbkdhZ2FsIG1lbXVhdCBkZXRhaWwgbWVuZGFsYW06ICR7ZXJyLm1lc3NhZ2V9LlxuYDtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTZW5kTWVzc2FnZSA9IGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGlmIChlKSBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gaW5wdXQudHJpbSgpO1xuICAgICAgICBpZiAoKCFxdWVyeSAmJiAhYXR0YWNoZWRGaWxlKSB8fCBsb2FkaW5nKSByZXR1cm47XG5cbiAgICAgICAgY29uc3QgY3VyS2V5ID0gKGFwaUtleSB8fCBnZXRHZW1pbmlBcGlLZXkoKSkudHJpbSgpO1xuICAgICAgICBpZiAoIWN1cktleSkge1xuICAgICAgICAgICAgc2V0U2hvd0tleUVkaXRvcih0cnVlKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOKUgOKUgCBDLTI6IERPQ1VNRU5UIEdFTkVSQVRPUiBJTlRFTlQgKEFUVEFDSEVEIEZJTEUpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgICBpZiAoYXR0YWNoZWRGaWxlKSB7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50RmlsZSA9IGF0dGFjaGVkRmlsZTtcbiAgICAgICAgICAgIGNvbnN0IHVzZXJNc2cgPSB7XG4gICAgICAgICAgICAgICAgaWQ6IERhdGUubm93KCksXG4gICAgICAgICAgICAgICAgc2VuZGVyOiAndXNlcicsXG4gICAgICAgICAgICAgICAgdGV4dDogcXVlcnkgfHwgYEdlbmVyYXRlIHNvYWwga3VpcyBkYXJpIGRva3VtZW4gbWF0ZXJpOiAke2N1cnJlbnRGaWxlLm5hbWV9YCxcbiAgICAgICAgICAgICAgICBhdHRhY2hlZEZpbGVJbmZvOiB7IG5hbWU6IGN1cnJlbnRGaWxlLm5hbWUsIHNpemU6IChjdXJyZW50RmlsZS5zaXplIC8gMTAyNCkudG9GaXhlZCgxKSArICcgS0InIH0sXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gWy4uLnByZXYsIHVzZXJNc2ddKTtcbiAgICAgICAgICAgIHNldEF0dGFjaGVkRmlsZShudWxsKTtcbiAgICAgICAgICAgIHNldElucHV0KCcnKTtcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG5cbiAgICAgICAgICAgIC8vIFBsYWNlaG9sZGVyIGJvdCBtZXNzYWdlIGZvciBnZW5lcmF0aW9uIHN0YXR1c1xuICAgICAgICAgICAgY29uc3QgYm90TXNnSWQgPSBEYXRlLm5vdygpICsgMTtcbiAgICAgICAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gW1xuICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZDogYm90TXNnSWQsXG4gICAgICAgICAgICAgICAgICAgIHNlbmRlcjogJ2JvdCcsXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IGBTZWRhbmcgbWVtcHJvc2VzIGRva3VtZW4gKipcIiR7Y3VycmVudEZpbGUubmFtZX1cIioqIGRlbmdhbiBBSS4uLmAsXG4gICAgICAgICAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgXSk7XG5cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZ2VuZXJhdGVRdWVzdGlvbnNGcm9tRG9jdW1lbnQoe1xuICAgICAgICAgICAgICAgICAgICBmaWxlOiBjdXJyZW50RmlsZSxcbiAgICAgICAgICAgICAgICAgICAgaW5zdHJ1Y3Rpb246IHF1ZXJ5IHx8ICdCdWF0a2FuIGJ1dGlyIHNvYWwga3Vpcy91amlhbiBiZXJrdWFsaXRhcyB0aW5nZ2kgZGFyaSBkb2t1bWVuIGluaScsXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbUFwaUtleTogY3VyS2V5LFxuICAgICAgICAgICAgICAgICAgICBvblN0YXR1czogKHN0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+IHByZXYubWFwKG1zZyA9PiBtc2cuaWQgPT09IGJvdE1zZ0lkID8geyAuLi5tc2csIHRleHQ6IHN0IH0gOiBtc2cpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgaWYgKHJlcy5vayAmJiBBcnJheS5pc0FycmF5KHJlcy5kYXRhKSAmJiByZXMuZGF0YS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gcHJldi5tYXAobXNnID0+IG1zZy5pZCA9PT0gYm90TXNnSWQgPyB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5tc2csXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBg4pyoIEJlcmhhc2lsIG1lbmdla3N0cmFrIGRhbiBtZW55dXN1biAqKiR7cmVzLmRhdGEubGVuZ3RofSBidXRpciBzb2FsKiogZGFyaSBtYXRlcmkgZG9rdW1lbiAqKlwiJHtjdXJyZW50RmlsZS5uYW1lfVwiKiogKCR7cmVzLmVsYXBzZWRTZWN9cykuXFxuXFxuQW5kYSBkYXBhdCBtZW5pbmphdSBkYW4gbGFuZ3N1bmcgbWVtYXN1a2thbm55YSBrZSBmb3JtdWxpciBhdGF1IG1lbmd1bmR1aG55YSBzZWJhZ2FpIHRlbXBsYXRlIENTVjpgLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uQ2FyZDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdkb2NfcXVlc3Rpb25zX3ByZXZpZXcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uczogcmVzLmRhdGEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWU6IGN1cnJlbnRGaWxlLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWxVc2VkOiByZXMubW9kZWxVc2VkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsYXBzZWRTZWM6IHJlcy5lbGFwc2VkU2VjXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gOiBtc2cpKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+IHByZXYubWFwKG1zZyA9PiBtc2cuaWQgPT09IGJvdE1zZ0lkID8ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4ubXNnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogYOKaoO+4jyBHYWdhbCBtZW5naGFzaWxrYW4gc29hbCBkYXJpIGRva3VtZW46ICR7cmVzLm1lc3NhZ2UgfHwgJ0Zvcm1hdCB0aWRhayBkaWR1a3VuZyBhdGF1IGlzaSB0aWRhayB0ZXJiYWNhLid9YFxuICAgICAgICAgICAgICAgICAgICB9IDogbXNnKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgc2V0TWVzc2FnZXMocHJldiA9PiBwcmV2Lm1hcChtc2cgPT4gbXNnLmlkID09PSBib3RNc2dJZCA/IHtcbiAgICAgICAgICAgICAgICAgICAgLi4ubXNnLFxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiBg4pqg77iPIFRlcmphZGkga2VuZGFsYSBzYWF0IG1lbWJhY2EgZG9rdW1lbjogJHtlcnIubWVzc2FnZX1gXG4gICAgICAgICAgICAgICAgfSA6IG1zZykpO1xuICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEV4cGxpY2l0bHkgc2VsZWN0ZWQgZm9ybSBjb250ZXh0IG9yIGV4cGxpY2l0IEBtZW50aW9uIGluIHF1ZXJ5XG4gICAgICAgIGxldCBhY3RpdmVUYXJnZXRGb3JtID0gc2VsZWN0ZWRGb3JtO1xuICAgICAgICBsZXQgcmVzcG9uc2VIaXN0b3J5Q29udGV4dCA9ICcnO1xuICAgICAgICBsZXQgcmVzcG9uc2VRdWl6UXVlc3Rpb25zID0gW107XG4gICAgICAgIGNvbnN0IGV4cGxpY2l0SGlzdG9yeSA9IHNlbGVjdGVkSGlzdG9yeSB8fCBzdWJtaXR0ZWRSZXNwb25zZXMuZmluZChpdGVtID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRpdGxlID0gaXRlbS5mb3JtVGl0bGUgfHwgaXRlbS50aXRsZSB8fCAnJztcbiAgICAgICAgICAgIHJldHVybiBxdWVyeS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGBAcml3YXlhdCBqYXdhYmFuICR7dGl0bGUudG9Mb3dlckNhc2UoKX1gKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChleHBsaWNpdEhpc3RvcnkpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaGlzdG9yeURhdGEgPSBhd2FpdCBidWlsZFJlc3BvbnNlSGlzdG9yeUNvbnRleHQoZXhwbGljaXRIaXN0b3J5KTtcbiAgICAgICAgICAgICAgICByZXNwb25zZUhpc3RvcnlDb250ZXh0ID0gaGlzdG9yeURhdGEuY29udGV4dDtcbiAgICAgICAgICAgICAgICByZXNwb25zZVF1aXpRdWVzdGlvbnMgPSBoaXN0b3J5RGF0YS5xdWl6UXVlc3Rpb25zO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycikgeyByZXNwb25zZUhpc3RvcnlDb250ZXh0ID0gYFxcbj09PSBSSVdBWUFUIEpBV0FCQU4gPT09XFxuR2FnYWwgbWVtdWF0IGRldGFpbCByZXNwb25zOiAke2Vyci5tZXNzYWdlfVxcbmA7IH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWFjdGl2ZVRhcmdldEZvcm0pIHtcbiAgICAgICAgICAgIGNvbnN0IGV4cGxpY2l0TWVudGlvbiA9IHVzZXJGb3Jtcy5maW5kKGYgPT4gcXVlcnkuaW5jbHVkZXMoYEAke2YudGl0bGV9YCkpO1xuICAgICAgICAgICAgaWYgKGV4cGxpY2l0TWVudGlvbikge1xuICAgICAgICAgICAgICAgIGFjdGl2ZVRhcmdldEZvcm0gPSBleHBsaWNpdE1lbnRpb247XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1c2VyTXNnID0ge1xuICAgICAgICAgICAgaWQ6IERhdGUubm93KCksXG4gICAgICAgICAgICBzZW5kZXI6ICd1c2VyJyxcbiAgICAgICAgICAgIHRleHQ6IHF1ZXJ5LFxuICAgICAgICAgICAgZm9ybUNvbnRleHQ6IGFjdGl2ZVRhcmdldEZvcm0gPyB7IGlkOiBhY3RpdmVUYXJnZXRGb3JtLmlkLCB0aXRsZTogYWN0aXZlVGFyZ2V0Rm9ybS50aXRsZSB9IDogbnVsbCxcbiAgICAgICAgICAgIHJlc3BvbnNlSGlzdG9yeUNvbnRleHQ6IGV4cGxpY2l0SGlzdG9yeSA/IHsgZm9ybVRpdGxlOiBleHBsaWNpdEhpc3RvcnkuZm9ybVRpdGxlIHx8IGV4cGxpY2l0SGlzdG9yeS50aXRsZSB9IDogbnVsbCxcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgIH07XG5cbiAgICAgICAgc2V0TWVzc2FnZXMocHJldiA9PiBbLi4ucHJldiwgdXNlck1zZ10pO1xuICAgICAgICBzZXRJbnB1dCgnJyk7XG4gICAgICAgIHNldFNob3dNZW50aW9uTWVudShmYWxzZSk7XG4gICAgICAgIC8vIEtlZXAgdGhlIHNlbGVjdGVkIHJlc3BvbnNlIGhpc3RvcnkgcGlubmVkIGZvciB0aGUgbmV4dCBtZXNzYWdlLlxuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuXG4gICAgICAgIGNvbnN0IGxvd2VyUXVlcnkgPSBxdWVyeS50b0xvd2VyQ2FzZSgpO1xuXG4gICAgICAgIC8vIOKUgOKUgCBJTlRFTlQgMTogRVhQT1JUIElOVEVOVCAoU0lOR0xFIE9SIEJVTEspIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgICBjb25zdCBpc0V4cG9ydEludGVudCA9IGxvd2VyUXVlcnkuaW5jbHVkZXMoJ2V4cG9ydCcpIHx8IGxvd2VyUXVlcnkuaW5jbHVkZXMoJ2Vrc3BvcicpIHx8IGxvd2VyUXVlcnkuaW5jbHVkZXMoJ3VuZHVoJykgfHwgbG93ZXJRdWVyeS5pbmNsdWRlcygnZG93bmxvYWQnKTtcbiAgICAgICAgY29uc3QgaXNCdWxrID0gbG93ZXJRdWVyeS5pbmNsdWRlcygnNyBoYXJpJykgfHwgbG93ZXJRdWVyeS5pbmNsdWRlcygnMyBoYXJpJykgfHwgbG93ZXJRdWVyeS5pbmNsdWRlcygnYnVsaycpIHx8IGxvd2VyUXVlcnkuaW5jbHVkZXMoJ3NlbXVhIGZvcm0nKSB8fCBsb3dlclF1ZXJ5LmluY2x1ZGVzKCdzZW11YSBmb3JtdWxpcicpO1xuXG4gICAgICAgIGlmIChpc0V4cG9ydEludGVudCkge1xuICAgICAgICAgICAgaWYgKGlzQnVsayB8fCAoIWFjdGl2ZVRhcmdldEZvcm0gJiYgdXNlckZvcm1zLmxlbmd0aCA+IDApKSB7XG4gICAgICAgICAgICAgICAgLy8gU2hvdyBidWxrIGV4cG9ydCBzZWxlY3RvciBtb2RhbCAvIGFjdGlvbiBjYXJkXG4gICAgICAgICAgICAgICAgc2V0TWVzc2FnZXMocHJldiA9PiBbXG4gICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBEYXRlLm5vdygpICsgMSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbmRlcjogJ2JvdCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBgQmVyaWt1dCBvcHNpICoqQnVsayBFeHBvcnQgUmVzcG9ucyoqLiBBbmRhIGRhcGF0IG1lbWlsaWggZm9ybXVsaXIgeWFuZyBpbmdpbiBkaXVuZHVoIGF0YXUgbWVtZmlsdGVyIGJlcmRhc2Fya2FuIHJlbnRhbmcgd2FrdHUgcGVuZ2VyamFhbjpgLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uQ2FyZDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdidWxrX3NlbGVjdG9yJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbEZvcm1zOiB1c2VyRm9ybXMubGVuZ3RoXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgIHNldFNob3dCdWxrTW9kYWwodHJ1ZSk7XG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChhY3RpdmVUYXJnZXRGb3JtKSB7XG4gICAgICAgICAgICAgICAgLy8gU2luZ2xlIGZvcm0gZG93bmxvYWQgYWN0aW9uIGNhcmRcbiAgICAgICAgICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+IFtcbiAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IERhdGUubm93KCkgKyAxLFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VuZGVyOiAnYm90JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IGBTaWFwISBBbmRhIGRhcGF0IGxhbmdzdW5nIG1lbmd1bmR1aCByZWthcGl0dWxhc2kgZGF0YSByZXNwb25zIHVudHVrICoqXCIke2FjdGl2ZVRhcmdldEZvcm0udGl0bGV9XCIqKiBtZWxhbHVpIHRvbWJvbCBkaSBiYXdhaDpgLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uQ2FyZDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdzaW5nbGVfZXhwb3J0JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtOiBhY3RpdmVUYXJnZXRGb3JtXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOKUgOKUgCBJTlRFTlQgMjogT1VULU9GLVNDT1BFIFJFRElSRUNUUyAoRk9STSBCVUlMREVSIC8gRURJVCAvIENSRUFURSkg4pSA4pSAXG4gICAgICAgIGNvbnN0IG1lbnRpb25zUXVlc3Rpb24gPSAvKHNvYWx8cGVydGFueWFhbikvaS50ZXN0KGxvd2VyUXVlcnkpO1xuICAgICAgICBjb25zdCBtZW50aW9uc0NyZWF0ZU9yUmV2aXNlID0gLyhidWF0fGJ1YXRrYW58YmlraW58YmlraW5rYW58dGFtYmFofHRhbWJhaGthbnxyZXZpc2l8dWJhaHxnYW50aXxwZXJiYWlraXxlZGl0fGhhcHVzKS9pLnRlc3QobG93ZXJRdWVyeSk7XG4gICAgICAgIGNvbnN0IG1lbnRpb25zVGhpc0Zvcm0gPSBsb3dlclF1ZXJ5LmluY2x1ZGVzKCdmb3JtIGluaScpIHx8IGxvd2VyUXVlcnkuaW5jbHVkZXMoJ2Zvcm11bGlyIGluaScpIHx8ICEhYWN0aXZlVGFyZ2V0Rm9ybTtcblxuICAgICAgICBjb25zdCBpc1F1ZXN0aW9uSW50ZW50ID0gbWVudGlvbnNRdWVzdGlvbiAmJiBtZW50aW9uc0NyZWF0ZU9yUmV2aXNlICYmIChtZW50aW9uc1RoaXNGb3JtIHx8IHVzZXJGb3Jtcy5sZW5ndGggPiAwKTtcblxuICAgICAgICBjb25zdCBpc0NyZWF0ZU5ld0Zvcm1JbnRlbnQgPSAhbWVudGlvbnNRdWVzdGlvbiAmJiBtZW50aW9uc0NyZWF0ZU9yUmV2aXNlICYmIC8oZm9ybXxmb3JtdWxpcnxrdWlzKS9pLnRlc3QobG93ZXJRdWVyeSk7XG5cbiAgICAgICAgaWYgKGlzUXVlc3Rpb25JbnRlbnQpIHtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGFjdGl2ZVRhcmdldEZvcm0gfHwgdXNlckZvcm1zWzBdO1xuICAgICAgICAgICAgaWYgKHRhcmdldCkge1xuICAgICAgICAgICAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gW1xuICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogRGF0ZS5ub3coKSArIDEsXG4gICAgICAgICAgICAgICAgICAgICAgICBzZW5kZXI6ICdib3QnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogYFVudHVrIG1lbWJ1YXQgYXRhdSBtZXJldmlzaSBidXRpciBzb2FsIHBhZGEgZm9ybXVsaXIgKipcIiR7dGFyZ2V0LnRpdGxlfVwiKiosIHNpbGFrYW4gYnVrYSAqKkZvcm0gQnVpbGRlcioqIGRpYmF3YWggaW5pIGRhbiBrbGlrIGJhZ2lhbiAqKkdlbmVyYXRlIFNvYWwgQUkqKjpgLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVkaXJlY3RBY3Rpb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogYEJ1a2EgRm9ybSBCdWlsZGVyOiAke3RhcmdldC50aXRsZX1gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6IGAvZm9ybXMvJHt0YXJnZXQuaWR9L2VkaXRgLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb246ICdlZGl0J1xuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaXNDcmVhdGVOZXdGb3JtSW50ZW50ICYmICFsb3dlclF1ZXJ5LmluY2x1ZGVzKCdyZWtvbWVuZGFzaScpICYmICFsb3dlclF1ZXJ5LmluY2x1ZGVzKCdpZGUnKSAmJiAhbG93ZXJRdWVyeS5pbmNsdWRlcygnY29udG9oJykpIHtcbiAgICAgICAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gW1xuICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZDogRGF0ZS5ub3coKSArIDEsXG4gICAgICAgICAgICAgICAgICAgIHNlbmRlcjogJ2JvdCcsXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IGBVbnR1ayBtZW1idWF0IGZvcm11bGlyIGJhcnUsIHNpbGFrYW4ga2xpayB0b21ib2wgZGkgYmF3YWggaW5pOmAsXG4gICAgICAgICAgICAgICAgICAgIHJlZGlyZWN0QWN0aW9uOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ0J1YXQgRm9ybXVsaXIgQmFydScsXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnL2Rhc2hib2FyZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiAncGx1cydcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdKTtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8g4pSA4pSAIElOVEVOVCAzOiBVUkwgLyBZT1VUVUJFIEVYVFJBQ1RJT04gT1IgREVFUCBBTkFMWVRJQ1MgJiBTU0UgU1RSRUFNSU5HIOKUgOKUgFxuICAgICAgICBjb25zdCB1cmxNYXRjaCA9IHF1ZXJ5Lm1hdGNoKC9odHRwcz86XFwvXFwvW15cXHNdKy9pKTtcbiAgICAgICAgbGV0IHVybEV4dHJhY3RlZENvbnRleHQgPSAnJztcbiAgICAgICAgbGV0IHVybE1ldGFkYXRhID0gbnVsbDtcblxuICAgICAgICBpZiAodXJsTWF0Y2gpIHtcbiAgICAgICAgICAgIGNvbnN0IGRldGVjdGVkVXJsID0gdXJsTWF0Y2hbMF07XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHVybFJlc3VsdCA9IGF3YWl0IGV4dHJhY3RDb250ZW50RnJvbVVybChkZXRlY3RlZFVybCwgKHN0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSB1c2VyIG9yIHN0YXR1cyBpZiBuZWVkZWRcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAodXJsUmVzdWx0Lm9rICYmIHVybFJlc3VsdC5jb250ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIHVybE1ldGFkYXRhID0gdXJsUmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICB1cmxFeHRyYWN0ZWRDb250ZXh0ID0gYFxcblxcbj09PSBLT05URU4gTUFURVJJIERBUkkgVEFVVEFOIEVLU1RFUk5BTCAoJHt1cmxSZXN1bHQudHlwZS50b1VwcGVyQ2FzZSgpfSkgPT09XFxuSnVkdWw6ICR7dXJsUmVzdWx0LnRpdGxlfVxcblN1bWJlciBVUkw6ICR7dXJsUmVzdWx0LnVybH1cXG5Jc2kgTWF0ZXJpL1RyYW5za3JpcDpcXG5cIlwiXCJcXG4ke3VybFJlc3VsdC5jb250ZW50LnNsaWNlKDAsIDQwMDAwKX1cXG5cIlwiXCJcXG5gO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignVVJMIGV4dHJhY3Rpb24gZXJyb3I6JywgZXJyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBkZWVwQ29udGV4dCA9ICcnO1xuICAgICAgICBpZiAoYWN0aXZlVGFyZ2V0Rm9ybSkge1xuICAgICAgICAgICAgZGVlcENvbnRleHQgPSBhd2FpdCBidWlsZERlZXBGb3JtQ29udGV4dChhY3RpdmVUYXJnZXRGb3JtKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRlZXBDb250ZXh0ID0gYFxuREFGVEFSIEZPUk1VTElSIE1JTElLIFBFTkdHVU5BICgke3VzZXJGb3Jtcy5sZW5ndGh9IGZvcm11bGlyKTpcbiR7dXNlckZvcm1zLm1hcCgoZiwgaSkgPT4gYCR7aSArIDF9LiBcIiR7Zi50aXRsZX1cIiAoSUQ6ICR7Zi5pZH0sIFN0YXR1czogJHtmLnN0YXR1cyB8fCAnQWN0aXZlJ30sIFRvdGFsIFJlc3BvbnM6ICR7Zi5yZXNwb25zZUNvdW50IHx8IDB9KWApLmpvaW4oJ1xcbicpfVxuYDtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzcG9uc2VIaXN0b3J5Q29udGV4dCkgZGVlcENvbnRleHQgKz0gcmVzcG9uc2VIaXN0b3J5Q29udGV4dDtcblxuICAgICAgICBpZiAodXJsRXh0cmFjdGVkQ29udGV4dCkge1xuICAgICAgICAgICAgZGVlcENvbnRleHQgKz0gdXJsRXh0cmFjdGVkQ29udGV4dDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHN5c3RlbVByb21wdCA9IGBcblBFUkFOOiBBbmRhIGFkYWxhaCBGb3JtVXAgQUkgQXNzaXN0YW50IGNlcmRhcywgYW5hbGl0aXMsIGRhbiByYW1haCBraHVzdXMgdW50dWsgcGVuZGlkaWssIGd1cnUsIGRhbiBwZW1idWF0IGt1aXMgZGkgcGxhdGZvcm0gRm9ybVVwLlxuVFVHQVMgQU5EQTpcbjEuIE1lbmphd2FiIHBlcnRhbnlhYW4gcGVuZ2d1bmEgc2VjYXJhIFRFUEFULCBTUEVTSUZJSywgZGFuIEFLVVJBVCBtZW5nZ3VuYWthbiBkYXRhIGZvcm11bGlyIGFrdHVhbCBhdGF1IG1hdGVyaSBkYXJpIFVSTCB5YW5nIGRpc2VkaWFrYW4gZGkgYmF3YWggaW5pLlxuMi4gSmlrYSBwZW5nZ3VuYSBtZW1pbnRhIG1lbWJ1YXQgc29hbCBkYXJpIGxpbmsgYXJ0aWtlbC9Zb3VUdWJlIHlhbmcgZGlsYW1waXJrYW4sIGJ1YXRrYW4gYnV0aXIgc29hbCB5YW5nIHJlbGV2YW4sIG1lbmRpZGlrLCBkYW4gYmVya3VhbGl0YXMuXG4zLiBKaWthIGRpdGFueWEgdGVudGFuZyBuaWxhaSB0ZXJ0aW5nZ2kvdGVyZW5kYWgvcmF0YS1yYXRhLCBzZWJ1dGthbiBuYW1hIHNpc3dhIGRhbiBuaWxhaSBwZXJzaXNueWEgZGFyaSBkYXRhIHJhbmtpbmcuXG40LiBKaWthIGRpdGFueWEgdGVudGFuZyBrZWN1cmFuZ2FuLCBzaXN3YSB5YW5nIGN1cmFuZywgYXRhdSBsb2cgcGluZGFoIHRhYiwgamVsYXNrYW4gZGF0YSBwZWxhbmdnYXJhbiB5YW5nIHRlcnRlcmEgZGkgbG9nIG1vbml0b3JpbmcuXG41LiBGb3JtYXQgamF3YWJhbiBzZWxhbHUgbWVuZ2d1bmFrYW4gTWFya2Rvd24geWFuZyByYXBpIChndW5ha2FuICoqYm9sZCoqLCBidWxsZXQgcG9pbnRzLCBudW1iZXJlZCBsaXN0LCBibG9ja3F1b3RlcykuXG42LiBKaWthIG1lbnVsaXNrYW4gcnVtdXMgbWF0ZW1hdGlrYS9maXNpa2EsIFdBSklCIGd1bmFrYW4gZm9ybWF0IExhVGVYICQuLi4kIHVudHVrIGlubGluZSBhdGF1ICQkLi4uJCQgdW50dWsgYmFyaXMgdGVycGlzYWguXG5cbiR7ZGVlcENvbnRleHR9XG5gLnRyaW0oKTtcblxuICAgICAgICAvLyBBZGQgcGxhY2Vob2xkZXIgYm90IG1lc3NhZ2UgZm9yIHJlYWwtdGltZSBTU0Ugc3RyZWFtaW5nXG4gICAgICAgIGNvbnN0IGJvdE1lc3NhZ2VJZCA9IERhdGUubm93KCkgKyAxO1xuICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+IFtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgaWQ6IGJvdE1lc3NhZ2VJZCxcbiAgICAgICAgICAgICAgICBzZW5kZXI6ICdib3QnLFxuICAgICAgICAgICAgICAgIHRleHQ6ICcnLFxuICAgICAgICAgICAgICAgIGZvcm1Db250ZXh0OiBhY3RpdmVUYXJnZXRGb3JtID8geyBpZDogYWN0aXZlVGFyZ2V0Rm9ybS5pZCwgdGl0bGU6IGFjdGl2ZVRhcmdldEZvcm0udGl0bGUgfSA6IG51bGwsXG4gICAgICAgICAgICAgICAgdXJsTWV0YTogdXJsTWV0YWRhdGEgPyB7IHR5cGU6IHVybE1ldGFkYXRhLnR5cGUsIHRpdGxlOiB1cmxNZXRhZGF0YS50aXRsZSwgdXJsOiB1cmxNZXRhZGF0YS51cmwgfSA6IG51bGwsXG4gICAgICAgICAgICAgICAgYWN0aW9uQ2FyZDogZXhwbGljaXRIaXN0b3J5ID8geyB0eXBlOiAnaW50ZXJhY3RpdmVfcXVpeicsIHF1aXpJZDogYGhpc3RvcnktJHtleHBsaWNpdEhpc3RvcnkucmVzcG9uc2VJZCB8fCBleHBsaWNpdEhpc3RvcnkuaWR9YCwgcXVlc3Rpb25zOiByZXNwb25zZVF1aXpRdWVzdGlvbnMgfSA6IG51bGwsXG4gICAgICAgICAgICAgICAgbW9kZWxVc2VkOiBzZWxlY3RlZE1vZGVsLFxuICAgICAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgICAgICB9XG4gICAgICAgIF0pO1xuXG4gICAgICAgIGxldCBjdXJyZW50QWN0aXZlS2V5ID0gY3VyS2V5O1xuICAgICAgICBsZXQgYXR0ZW1wdCA9IDA7XG4gICAgICAgIGNvbnN0IG1heEF0dGVtcHRzID0gTWF0aC5tYXgoMSwgYXBpS2V5cy5sZW5ndGgpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB3aGlsZSAoYXR0ZW1wdCA8IG1heEF0dGVtcHRzKSB7XG4gICAgICAgICAgICAgICAgYXR0ZW1wdCsrO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhYm9ydENvbnRyb2xsZXJSZWYuY3VycmVudCA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgICAgICAgICBjb25zdCBlbmRwb2ludCA9IGBodHRwczovL2dlbmVyYXRpdmVsYW5ndWFnZS5nb29nbGVhcGlzLmNvbS92MWJldGEvbW9kZWxzLyR7c2VsZWN0ZWRNb2RlbH06c3RyZWFtR2VuZXJhdGVDb250ZW50P2tleT0ke2N1cnJlbnRBY3RpdmVLZXl9JmFsdD1zc2VgO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goZW5kcG9pbnQsIHtcbiAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250ZW50czogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcm9sZTogJ3VzZXInLCBwYXJ0czogW3sgdGV4dDogYCR7c3lzdGVtUHJvbXB0fVxcblxcblBlcnRhbnlhYW4gUGVuZ2d1bmE6IFwiJHtxdWVyeX1cImAgfV0gfVxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGdlbmVyYXRpb25Db25maWc6IHsgdGVtcGVyYXR1cmU6IDAuNyB9XG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlclJlZi5jdXJyZW50LnNpZ25hbFxuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBlcnJEYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+ICh7fSkpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBlcnJNc2cgPSBlcnJEYXRhLmVycm9yPy5tZXNzYWdlIHx8IGBIVFRQICR7cmVzcG9uc2Uuc3RhdHVzfWA7XG4gICAgICAgICAgICAgICAgICAgIGlmICgocmVzcG9uc2Uuc3RhdHVzID09PSA0MjkgfHwgcmVzcG9uc2Uuc3RhdHVzID09PSA0MDMpICYmIGFwaUtleXMubGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgcm90YXRlZCA9IHJvdGF0ZVRvTmV4dEFwaUtleSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudEFjdGl2ZUtleSA9IHJvdGF0ZWQua2V5O1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlS2V5SWR4KHJvdGF0ZWQuaW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXBpS2V5KHJvdGF0ZWQua2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJldHJ5IG5leHQgaXRlcmF0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZXJyTXNnKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBjb25zdCByZWFkZXIgPSByZXNwb25zZS5ib2R5LmdldFJlYWRlcigpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGRlY29kZXIgPSBuZXcgVGV4dERlY29kZXIoKTtcbiAgICAgICAgICAgICAgICBsZXQgYWNjdW11bGF0ZWRUZXh0ID0gJyc7XG4gICAgICAgICAgICAgICAgbGV0IGJ1ZmZlciA9ICcnO1xuXG4gICAgICAgICAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgeyBkb25lLCB2YWx1ZSB9ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRvbmUpIGJyZWFrO1xuXG4gICAgICAgICAgICAgICAgICAgIGJ1ZmZlciArPSBkZWNvZGVyLmRlY29kZSh2YWx1ZSwgeyBzdHJlYW06IHRydWUgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVzID0gYnVmZmVyLnNwbGl0KCdcXG4nKTtcbiAgICAgICAgICAgICAgICAgICAgYnVmZmVyID0gbGluZXMucG9wKCkgfHwgJyc7XG5cbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBsaW5lIG9mIGxpbmVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWxpbmUuc3RhcnRzV2l0aCgnZGF0YTogJykpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGF0YVN0ciA9IGxpbmUuc2xpY2UoNikudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRhdGFTdHIgPT09ICdbRE9ORV0nKSBjb250aW51ZTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKGRhdGFTdHIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNodW5rID0gcGFyc2VkLmNhbmRpZGF0ZXM/LlswXT8uY29udGVudD8ucGFydHM/LlswXT8udGV4dCB8fCAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY2h1bmspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjdW11bGF0ZWRUZXh0ICs9IGNodW5rO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2Lm1hcChtc2cgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtc2cuaWQgPT09IGJvdE1lc3NhZ2VJZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHsgLi4ubXNnLCB0ZXh0OiBhY2N1bXVsYXRlZFRleHQgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG1zZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2gge31cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmICghYWNjdW11bGF0ZWRUZXh0LnRyaW0oKSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBwcmV2Lm1hcChtc2cgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtc2cuaWQgPT09IGJvdE1lc3NhZ2VJZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHsgLi4ubXNnLCB0ZXh0OiAnTWFhZiwgc2F5YSB0aWRhayBkYXBhdCBtZXJ1bXVza2FuIHRhbmdnYXBhbiB1bnR1ayBwZXJ0YW55YWFuIHRlcnNlYnV0LicgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG1zZ1xuICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhazsgLy8gc3VjY2Vzc2Z1bGx5IGZpbmlzaGVkXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyLm5hbWUgPT09ICdBYm9ydEVycm9yJykge1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGF0dGVtcHQgPj0gbWF4QXR0ZW1wdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0TWVzc2FnZXMocHJldiA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgcHJldi5tYXAobXNnID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbXNnLmlkID09PSBib3RNZXNzYWdlSWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB7IC4uLm1zZywgdGV4dDogYFRlcmphZGkga2VuZGFsYSBzYWF0IG1lbmdodWJ1bmdpIEFJICgke3NlbGVjdGVkTW9kZWx9KTogJHtlcnIubWVzc2FnZX0uIFBlcmlrc2Ega29uZWtzaSBhdGF1IEFQSSBLZXkgQW5kYS5gIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBtc2dcbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgYWJvcnRDb250cm9sbGVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNvbW1pdFF1ZXN0aW9uc1RvRm9ybSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFwcmV2aWV3RG9jTW9kYWwgfHwgIXByZXZpZXdEb2NNb2RhbC5xdWVzdGlvbnMgfHwgcHJldmlld0RvY01vZGFsLnF1ZXN0aW9ucy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgICAgICAgc2V0Q29tbWl0dGluZ1RvRm9ybSh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGxldCBmb3JtSWQgPSB0YXJnZXRGb3JtSWQ7XG4gICAgICAgICAgICBsZXQgZm9ybVRpdGxlID0gJyc7XG5cbiAgICAgICAgICAgIGlmIChmb3JtSWQgPT09ICduZXcnKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYmFzZVRpdGxlID0gcHJldmlld0RvY01vZGFsLmZpbGVOYW1lID8gcHJldmlld0RvY01vZGFsLmZpbGVOYW1lLnJlcGxhY2UoL1xcLlteLy5dKyQvLCAnJykgOiAnTWF0ZXJpIERva3VtZW4nO1xuICAgICAgICAgICAgICAgIGNvbnN0IGNyZWF0ZVJlcyA9IGF3YWl0IGNyZWF0ZUZvcm0oe1xuICAgICAgICAgICAgICAgICAgICB0aXRsZTogYEt1aXMgZGFyaSAke2Jhc2VUaXRsZX1gLFxuICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogYERpYnVhdCBvdG9tYXRpcyBvbGVoIEFJIEFzc2lzdGFudCBkYXJpIGRva3VtZW4gbWF0ZXJpIFwiJHtwcmV2aWV3RG9jTW9kYWwuZmlsZU5hbWV9XCIuYCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAoIWNyZWF0ZVJlcy5vayB8fCAhY3JlYXRlUmVzLmRhdGE/LmlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihjcmVhdGVSZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVtYnVhdCBmb3JtdWxpciBiYXJ1LicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmb3JtSWQgPSBjcmVhdGVSZXMuZGF0YS5pZDtcbiAgICAgICAgICAgICAgICBmb3JtVGl0bGUgPSBjcmVhdGVSZXMuZGF0YS50aXRsZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZm91bmQgPSB1c2VyRm9ybXMuZmluZChmID0+IFN0cmluZyhmLmlkKSA9PT0gU3RyaW5nKGZvcm1JZCkpO1xuICAgICAgICAgICAgICAgIGZvcm1UaXRsZSA9IGZvdW5kPy50aXRsZSB8fCBgRm9ybXVsaXIgIyR7Zm9ybUlkfWA7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IGFkZFJlcyA9IGF3YWl0IGFkZFF1ZXN0aW9ucyhmb3JtSWQsIHByZXZpZXdEb2NNb2RhbC5xdWVzdGlvbnMpO1xuICAgICAgICAgICAgaWYgKCFhZGRSZXMub2spIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYWRkUmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbWFzdWtrYW4gYnV0aXIgc29hbCBrZSBmb3JtdWxpci4nKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgdG90YWxBZGRlZCA9IHByZXZpZXdEb2NNb2RhbC5xdWVzdGlvbnMubGVuZ3RoO1xuICAgICAgICAgICAgc2V0UHJldmlld0RvY01vZGFsKG51bGwpO1xuICAgICAgICAgICAgc2V0Q29tbWl0U3VjY2Vzc0luZm8oe1xuICAgICAgICAgICAgICAgIGZvcm1JZCxcbiAgICAgICAgICAgICAgICBmb3JtVGl0bGUsXG4gICAgICAgICAgICAgICAgY291bnQ6IHRvdGFsQWRkZWRcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyBSZWZyZXNoIHVzZXIgZm9ybXMgbGlzdCBpbiBiYWNrZ3JvdW5kXG4gICAgICAgICAgICBnZXRNeUZvcm1zKCkudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZXMub2sgJiYgQXJyYXkuaXNBcnJheShyZXMuZGF0YSkpIHNldFVzZXJGb3JtcyhyZXMuZGF0YSk7XG4gICAgICAgICAgICB9KS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgYWxlcnQoYEdhZ2FsIG1lbWFzdWtrYW4gYnV0aXIgc29hbDogJHtlcnIubWVzc2FnZX1gKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldENvbW1pdHRpbmdUb0Zvcm0oZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGZpbHRlcmVkTWVudGlvbkZvcm1zID0gdXNlckZvcm1zLmZpbHRlcihmID0+XG4gICAgICAgIChmLnRpdGxlIHx8ICcnKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKG1lbnRpb25GaWx0ZXIpXG4gICAgKTtcbiAgICBjb25zdCBmaWx0ZXJlZE1lbnRpb25IaXN0b3J5ID0gc3VibWl0dGVkUmVzcG9uc2VzLmZpbHRlcihpdGVtID0+XG4gICAgICAgIChpdGVtLmZvcm1UaXRsZSB8fCBpdGVtLnRpdGxlIHx8ICcnKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKG1lbnRpb25GaWx0ZXIucmVwbGFjZSgvXnJpd2F5YXQgamF3YWJhblxccyovLCAnJykpXG4gICAgKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLXNjcmVlbiBiZy1bI0Y0RjhGN10gZGFyazpiZy1zbGF0ZS05NTAgZm9udC1zYW5zIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgPFNpZGViYXIgLz5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBtaW4tdy0wIGgtc2NyZWVuIG92ZXJmbG93LWhpZGRlblwiPlxuXG4gICAgICAgICAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgbWluLWgtMCB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHAtMyBzbTpwLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIEhlYWRlciBiYXIgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLTJ4bCBiZy10ZWFsLTYwMCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciBib3JkZXItdGVhbC01MDAvMzAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJvdCBzaXplPXsyMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYXNlIHNtOnRleHQtbGcgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGb3JtVXAgQUkgQXNzaXN0YW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCB0cmFja2luZy13aWRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdlbWluaVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaGlkZGVuIHNtOmJsb2NrXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBbmFsaXNpcyBuaWxhaSByZXNwb25kZW4sIGRldGVrc2kga2VjdXJhbmdhbiwgYnVsayBleHBvcnQsIHNhcmFuIGV2YWx1YXNpICYgcGVtYnVhdGFuIHNvYWwgZGFyaSBkb2t1bWVuLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXAgc206ZmxleC1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTW9kZWwgU2VsZWN0b3IgRHJvcGRvd24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0xLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDcHUgc2l6ZT17MTN9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTW9kZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZU1vZGVsQ2hhbmdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXRyYW5zcGFyZW50IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGN1cnNvci1wb2ludGVyIHByLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7QVZBSUxBQkxFX01PREVMUy5tYXAobSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e20uaWR9IHZhbHVlPXttLmlkfSBjbGFzc05hbWU9XCJkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge20ubmFtZX0ge20uYmFkZ2UgPyBgKCR7bS5iYWRnZX0pYCA6ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0J1bGtNb2RhbCh0cnVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJvcmRlci10ZWFsLTUwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgc2l6ZT17MTN9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+QnVsayBFeHBvcnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93S2V5RWRpdG9yKCFzaG93S2V5RWRpdG9yKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJvcmRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXBpS2V5cy5sZW5ndGggPiAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDAgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LWFtYmVyLTcwMCBkYXJrOnRleHQtYW1iZXItMzAwIGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzYwIGJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItODAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxLZXkgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnthcGlLZXlzLmxlbmd0aCA+IDAgPyBgS2V5ICgke2FwaUtleXMubGVuZ3RofSlgIDogJ0F0dXIgQVBJIEtleSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge21lc3NhZ2VzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsZWFySGlzdG9yeX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiSGFwdXMgcml3YXlhdCBjaGF0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXJlZC01MDAgZGFyazpob3Zlcjp0ZXh0LXJlZC00MDAgaG92ZXI6YmctcmVkLTUwIGRhcms6aG92ZXI6YmctcmVkLTk1MC80MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogQVBJIEtleSBTdGFja2luZyBEcmF3ZXIgaWYgb3BlbmVkICovfVxuICAgICAgICAgICAgICAgICAgICB7c2hvd0tleUVkaXRvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBteS0yIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBzaGFkb3ctc20gc3BhY2UteS0zIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgc2l6ZT17MTR9IGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC01MDBcIiAvPiBNdWx0aS1LZXkgU3RhY2tpbmcgKEF1dG8tRmFpbG92ZXIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL2Fpc3R1ZGlvLmdvb2dsZS5jb20vYXBwL2FwaWtleVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGFwYXRrYW4gS2V5IEdyYXRpcyA8RXh0ZXJuYWxMaW5rIHNpemU9ezExfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWFzdWtrYW4gc2F0dSBhdGF1IGxlYmloIEFQSSBLZXkgR29vZ2xlIEdlbWluaSAocGlzYWhrYW4gZGVuZ2FuIGJhcmlzIGJhcnUpLiBKaWthIGxpbWl0IDQyOSBhdGF1IGt1b3RhIGhhYmlzIHRlcmNhcGFpIHBhZGEgS2V5IDEsIHNpc3RlbSBvdG9tYXRpcyBiZXJhbGloIGtlIEtleSBiZXJpa3V0bnlhLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2F2ZUtleXN9IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aW5wdXRLZXlzVGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldElucHV0S2V5c1RleHQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBSXphU3lLZXkxLi4uXFxuQUl6YVN5S2V5Mi4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LW1vbm8gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgS2V5OiA8Yj57YXBpS2V5cy5sZW5ndGh9PC9iPiB7YXBpS2V5cy5sZW5ndGggPiAwICYmIGAoQWt0aWY6IEtleSAjJHthY3RpdmVLZXlJZHggKyAxfSlgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNpbXBhbiBLZXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7LyogQ2hhdCBNZXNzYWdlcyBDb250YWluZXIgd2l0aCByb2J1c3Qgd2hlZWwgc2Nyb2xsICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVmPXtjaGF0Q29udGFpbmVyUmVmfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi1oLTAgb3ZlcmZsb3cteS1hdXRvIG92ZXJzY3JvbGwtY29udGFpbiBweS00IHNwYWNlLXktNCBwci0xIHNtOnByLTIgc2Nyb2xsLXNtb290aFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttZXNzYWdlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLWZ1bGwgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1jZW50ZXIgcC02IHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLTN4bCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3Qgc2l6ZT17MzJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LW1kIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkYSB5YW5nIGJpc2Egc2F5YSBiYW50dSBoYXJpIGluaT9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBLZXRpayA8Y29kZSBjbGFzc05hbWU9XCJweC0xLjUgcHktMC41IGJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNjAwXCI+QG5hbWFfZm9ybTwvY29kZT4gdW50dWsgYW5hbGlzaXMgbmlsYWkva2VjdXJhbmdhbiwgbGFtcGlya2FuIGJlcmthcyBkb2t1bWVuIHVudHVrIGdlbmVyYXRlIGt1aXMgb3RvbWF0aXMsIGF0YXUgZ3VuYWthbiB2b2ljZSBpbnB1dDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1Z2dlc3Rpb24gQ2hpcHMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMyBtYXgtdy14bCB3LWZ1bGwgdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW5wdXQoJ1NpYXBhIHJlc3BvbmRlbiB5YW5nIG1lbmRhcGF0a2FuIG5pbGFpIHRlcnRpbmdnaSBkYW4gbmlsYWkgdGVyZW5kYWggZGkgZm9ybSBpbmk/Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0zLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIGhvdmVyOmJvcmRlci10ZWFsLTUwMCBob3ZlcjpiZy10ZWFsLTUwLzMwIGRhcms6aG92ZXI6YmctdGVhbC05NTAvMzAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZ3JvdXAgc3BhY2UteS0xIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGdyb3VwLWhvdmVyOnRleHQtdGVhbC02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXJDaGVjayBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk5pbGFpIFRlcnRpbmdnaSAmIFJhbmtpbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5BbmFsaXNpcyBwZXJhaWggc2tvciB0ZXJiYWlrICYgZGlzdHJpYnVzaSBuaWxhaTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW5wdXQoJ1NpYXBhIHNhamEgcmVzcG9uZGVuIHlhbmcgdGVyZGV0ZWtzaSBtZWxha3VrYW4gcGVsYW5nZ2FyYW4gYXRhdSBzZXJpbmcgcGluZGFoIHRhYiBzYWF0IHVqaWFuPycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMy41IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBob3Zlcjpib3JkZXItdGVhbC01MDAgaG92ZXI6YmctdGVhbC01MC8zMCBkYXJrOmhvdmVyOmJnLXRlYWwtOTUwLzMwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGdyb3VwIHNwYWNlLXktMSBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBncm91cC1ob3Zlcjp0ZXh0LXRlYWwtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTaGllbGRBbGVydCBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EZXRla3NpIEtlY3VyYW5nYW4gJiBUYWIgU3dpdGNoPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+TG9nIGFsdC10YWIgZGFuIHBlbGFuZ2dhcmFuIHNlc2kgdWppYW48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElucHV0KCdBbmFsaXNpcyBidXRpciBzb2FsIHlhbmcgcGFsaW5nIHNlcmluZyBzYWxhaCBkaWphd2FiIGRhbiBtZW1pbGlraSBkYXlhIGJlZGEgcmVuZGFoJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0zLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIGhvdmVyOmJvcmRlci10ZWFsLTUwMCBob3ZlcjpiZy10ZWFsLTUwLzMwIGRhcms6aG92ZXI6YmctdGVhbC05NTAvMzAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZ3JvdXAgc3BhY2UteS0xIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGdyb3VwLWhvdmVyOnRleHQtdGVhbC02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhckNoYXJ0MiBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkV2YWx1YXNpIEJ1dGlyIFNvYWwgU3VsaXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5UaW5na2F0IGtlc3VsaXRhbiAmIHJla29tZW5kYXNpIHJldmlzaTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRTaG93QnVsa01vZGFsKHRydWUpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMy41IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBob3Zlcjpib3JkZXItdGVhbC01MDAgaG92ZXI6YmctdGVhbC01MC8zMCBkYXJrOmhvdmVyOmJnLXRlYWwtOTUwLzMwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGdyb3VwIHNwYWNlLXktMSBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBncm91cC1ob3Zlcjp0ZXh0LXRlYWwtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkJ1bGsgRXhwb3J0IEZvcm11bGlyPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+VW5kdWggQ1NWIG11bHRpLWZvcm0gZGVuZ2FuIGZpbHRlciByZW50YW5nIHdha3R1PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlcy5tYXAoKG0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXttLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1zdGFydCBnYXAtMyAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG0uc2VuZGVyID09PSAndXNlcicgPyAnanVzdGlmeS1lbmQnIDogJ2p1c3RpZnktc3RhcnQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge20uc2VuZGVyID09PSAnYm90JyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQteGwgYmctdGVhbC02MDAgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMCBtdC0xIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm90IHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1heC13LVs5MCVdIHNtOm1heC13LVs4MCVdIHJvdW5kZWQtMnhsIHAtNCB0ZXh0LXhzIHNtOnRleHQtc20gc2hhZG93LXhzIHNwYWNlLXktMiBsZWFkaW5nLXJlbGF4ZWQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbS5zZW5kZXIgPT09ICd1c2VyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctdGVhbC02MDAgdGV4dC13aGl0ZSByb3VuZGVkLXRyLXhzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC10bC14cydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRm9ybSBDb250ZXh0IFRhZyBpZiBhdmFpbGFibGUgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge20uZm9ybUNvbnRleHQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yIHB5LTAuNSByb3VuZGVkLW1kIGJnLXRlYWwtNTAwLzIwIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IHNpemU9ezEwfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QHttLmZvcm1Db250ZXh0LnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS5yZXNwb25zZUhpc3RvcnlDb250ZXh0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBiZy1hbWJlci01MDAvMjAgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBzaXplPXsxMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkBSaXdheWF0IEphd2FiYW4ge20ucmVzcG9uc2VIaXN0b3J5Q29udGV4dC5mb3JtVGl0bGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFVzZXIgYXR0YWNoZWQgZmlsZSBiYWRnZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS5hdHRhY2hlZEZpbGVJbmZvICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgYmctdGVhbC03MDAvNDAgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXRlYWwtMTAwIHctZml0IG1iLTEgYm9yZGVyIGJvcmRlci10ZWFsLTUwMC8zMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IHNpemU9ezExfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e20uYXR0YWNoZWRGaWxlSW5mby5uYW1lfSAoe20uYXR0YWNoZWRGaWxlSW5mby5zaXplfSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTWVzc2FnZSBCb2R5IHdpdGggUmljaCBGb3JtYXR0aW5nICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttLnRleHQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXttLnRleHR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsxNH0gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHRleHQtdGVhbC02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk1lbnVsaXMgdGFuZ2dhcGFuLi4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQWN0aW9uIENhcmQgZm9yIFNpbmdsZSBFeHBvcnQgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge20uYWN0aW9uQ2FyZD8udHlwZSA9PT0gJ3NpbmdsZV9leHBvcnQnICYmIG0uYWN0aW9uQ2FyZC5mb3JtICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2luZ2xlRXhwb3J0KG0uYWN0aW9uQ2FyZC5mb3JtLmlkLCBtLmFjdGlvbkNhcmQuZm9ybS50aXRsZSwgJ2NzdicpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMiBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgaG92ZXI6YmctdGVhbC0xMDAgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5VbmR1aCBGb3JtYXQgQ1NWPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2luZ2xlRXhwb3J0KG0uYWN0aW9uQ2FyZC5mb3JtLmlkLCBtLmFjdGlvbkNhcmQuZm9ybS50aXRsZSwgJ3hsc3gnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGhvdmVyOmJnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVNwcmVhZHNoZWV0IHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlVuZHVoIEZvcm1hdCBFeGNlbCAoWExTWCk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBY3Rpb24gQ2FyZCBmb3IgQnVsayBTZWxlY3RvciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS5hY3Rpb25DYXJkPy50eXBlID09PSAnYnVsa19zZWxlY3RvcicgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QnVsa01vZGFsKHRydWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QnVrYSBNZW51IEJ1bGsgRXhwb3J0ICh7dXNlckZvcm1zLmxlbmd0aH0gRm9ybXVsaXIpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQWN0aW9uIENhcmQgZm9yIERvY3VtZW50IEdlbmVyYXRlZCBRdWVzdGlvbnMgUHJldmlldyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS5hY3Rpb25DYXJkPy50eXBlID09PSAnZG9jX3F1ZXN0aW9uc19wcmV2aWV3JyAmJiBtLmFjdGlvbkNhcmQucXVlc3Rpb25zICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MTR9IGNsYXNzTmFtZT1cInRleHQtdGVhbC01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnttLmFjdGlvbkNhcmQucXVlc3Rpb25zLmxlbmd0aH0gQnV0aXIgU29hbCBTaWFwIERpZ3VuYWthbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFByZXZpZXdEb2NNb2RhbCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25zOiBtLmFjdGlvbkNhcmQucXVlc3Rpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lOiBtLmFjdGlvbkNhcmQuZmlsZU5hbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGFyZ2V0Rm9ybUlkKCduZXcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5UaW5qYXUgJiBNYXN1a2thbiBrZSBGb3JtPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGV4cG9ydFF1ZXN0aW9uc1RvQ1NWKG0uYWN0aW9uQ2FyZC5xdWVzdGlvbnMsIG0uYWN0aW9uQ2FyZC5maWxlTmFtZSB8fCAnc29hbC1tYXRlcmktYWknKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VW5kdWggRm9ybWF0IENTVjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJlZGlyZWN0IENUQSBBY3Rpb24gQnV0dG9uIGlmIHN1Z2dlc3RlZCBieSBib3QgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge20ucmVkaXJlY3RBY3Rpb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e20ucmVkaXJlY3RBY3Rpb24ucGF0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMy41IHB5LTIgcm91bmRlZC14bCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCBob3ZlcjpiZy10ZWFsLTEwMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e20ucmVkaXJlY3RBY3Rpb24ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttLmFjdGlvbkNhcmQ/LnR5cGUgPT09ICdpbnRlcmFjdGl2ZV9xdWl6JyAmJiBtLnRleHQgJiYgbS5hY3Rpb25DYXJkLnF1ZXN0aW9ucz8ubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnRlcmFjdGl2ZVF1aXpPZmZlckNhcmQgcXVpeklkPXttLmFjdGlvbkNhcmQucXVpeklkfSBxdWVzdGlvbnM9e20uYWN0aW9uQ2FyZC5xdWVzdGlvbnN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS5zZW5kZXIgPT09ICd1c2VyJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQteGwgYmctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hyaW5rLTAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlciBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7YnVsa0V4cG9ydGluZyAmJiBidWxrUHJvZ3Jlc3MgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC81MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIHNpemU9ezIwfSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gdGV4dC10ZWFsLTYwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtdGVhbC05MDAgZGFyazp0ZXh0LXRlYWwtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWVuZ3VuZHVoIENTViAoe2J1bGtQcm9ncmVzcy5jdXJyZW50fS97YnVsa1Byb2dyZXNzLnRvdGFsfSk6IHtidWxrUHJvZ3Jlc3MubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRlYWwtMjAwLzYwIGRhcms6YmctdGVhbC05MDAvNjAgaC0xLjUgcm91bmRlZC1mdWxsIG10LTEuNSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXRlYWwtNjAwIGgtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAkeyhidWxrUHJvZ3Jlc3MuY3VycmVudCAvIGJ1bGtQcm9ncmVzcy50b3RhbCkgKiAxMDB9JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiByZWY9e21lc3NhZ2VzRW5kUmVmfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogTWVudGlvbiBAIFBvcG92ZXIgTWVudSAqL31cbiAgICAgICAgICAgICAgICAgICAge3Nob3dNZW50aW9uTWVudSAmJiAoZmlsdGVyZWRNZW50aW9uRm9ybXMubGVuZ3RoID4gMCB8fCBmaWx0ZXJlZE1lbnRpb25IaXN0b3J5Lmxlbmd0aCA+IDApICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMiBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgc2hhZG93LXhsIHAtMiBtYXgtaC00OCBvdmVyZmxvdy15LWF1dG8gc3BhY2UteS0xIHNocmluay0wIHotMjBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC0yIHB5LTEgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGlsaWggRm9ybXVsaXIgVGVya2FpdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNZW50aW9uTWVudShmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFR1dHVwIChFc2MpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZE1lbnRpb25IaXN0b3J5Lm1hcChpdGVtID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2BoaXN0b3J5LSR7aXRlbS5yZXNwb25zZUlkIHx8IGl0ZW0uaWR9YH0gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdE1lbnRpb25IaXN0b3J5KGl0ZW0pfSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLWFtYmVyLTUwIGRhcms6aG92ZXI6YmctYW1iZXItOTUwLzMwIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPkBSaXdheWF0IEphd2FiYW4ge2l0ZW0uZm9ybVRpdGxlIHx8IGl0ZW0udGl0bGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci02MDAgc2hyaW5rLTAgbWwtMlwiPkphd2FiYW4gc2F5YTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkTWVudGlvbkZvcm1zLm1hcChmID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtmLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWxlY3RNZW50aW9uRm9ybShmKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgcHgtMyBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6YmctdGVhbC01MCBkYXJrOmhvdmVyOmJnLXRlYWwtOTUwLzQwIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57Zi50aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW5vcm1hbCBzaHJpbmstMCBtbC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2YucmVzcG9uc2VDb3VudCB8fCAwfSByZXNwb25zXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEFjdGl2ZSBGb3JtIFBpbiBCYWRnZSAqL31cbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRm9ybSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHB4LTMuNSBweS0yIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIHJvdW5kZWQtMnhsIHRleHQteHMgc2hyaW5rLTAgc2hhZG93LTJ4c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17MTR9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBLb250ZWtzIEZvcm11bGlyOiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtdGVhbC04MDAgZGFyazp0ZXh0LXRlYWwtMjAwXCI+e3NlbGVjdGVkRm9ybS50aXRsZX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkRm9ybShudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgYmctdGVhbC0xMDAgaG92ZXI6YmctcmVkLTEwMCBkYXJrOmJnLXRlYWwtOTAwLzYwIGRhcms6aG92ZXI6YmctcmVkLTk1MC82MCB0ZXh0LXRlYWwtNzAwIGhvdmVyOnRleHQtcmVkLTYwMCBkYXJrOnRleHQtdGVhbC0zMDAgZGFyazpob3Zlcjp0ZXh0LXJlZC0zMDAgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJLZWx1YXIgZGFyaSBrb250ZWtzIGZvcm11bGlyIGluaVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBzaXplPXsxMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+S2VsdWFyIEtvbnRla3M8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkSGlzdG9yeSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHB4LTMuNSBweS0yIGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzUwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMCByb3VuZGVkLTJ4bCB0ZXh0LXhzIHNocmluay0wIHNoYWRvdy0yeHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTgwMCBkYXJrOnRleHQtYW1iZXItMjAwIHRydW5jYXRlXCI+S29udGVrczogPHN0cm9uZz5AUml3YXlhdCBKYXdhYmFuIHtzZWxlY3RlZEhpc3RvcnkuZm9ybVRpdGxlIHx8IHNlbGVjdGVkSGlzdG9yeS50aXRsZX08L3N0cm9uZz48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRIaXN0b3J5KG51bGwpfSBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMFwiPktlbHVhciBLb250ZWtzPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7LyogQXR0YWNoZWQgZmlsZSBjaGlwIGluZGljYXRvciAqL31cbiAgICAgICAgICAgICAgICAgICAge2F0dGFjaGVkRmlsZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTMgcHktMS41IGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC81MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIHJvdW5kZWQteGwgdGV4dC14cyB3LWZpdCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC10ZWFsLTkwMCBkYXJrOnRleHQtdGVhbC0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFBhcGVyY2xpcCBzaXplPXsxM30gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0cnVuY2F0ZSBtYXgtdy1bMjAwcHhdIHNtOm1heC13LXhzXCI+e2F0dGFjaGVkRmlsZS5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIj4oeyhhdHRhY2hlZEZpbGUuc2l6ZSAvIDEwMjQpLnRvRml4ZWQoMSl9IEtCKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBdHRhY2hlZEZpbGUobnVsbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdGVhbC00MDAgaG92ZXI6dGV4dC1yZWQtNTAwIGZvbnQtYm9sZCBtbC0yIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIElucHV0IEJhciB3aXRoIEF0dGFjaG1lbnQsIFZvaWNlLCBhbmQgU2VuZCAqL31cbiAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVNlbmRNZXNzYWdlfSBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwdC0yIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmPXtmaWxlSW5wdXRSZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLnRhcmdldC5maWxlcyAmJiBlLnRhcmdldC5maWxlc1swXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXR0YWNoZWRGaWxlKGUudGFyZ2V0LmZpbGVzWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID0gJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cIi5wZGYsLmRvY3gsLnR4dCwuY3N2LC5tZCxhcHBsaWNhdGlvbi9wZGYsdGV4dC9wbGFpbix0ZXh0L2NzdlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkxhbXBpcmthbiBEb2t1bWVuIE1hdGVyaSAoUERGLCBET0NYLCBUWFQsIENTViwgTUQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci10ZWFsLTUwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC0yeGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzIHNocmluay0wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGFwZXJjbGlwIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVWb2ljZUlucHV0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtpc0xpc3RlbmluZyA/ICdCZXJoZW50aSBtZW5kZW5nYXJrYW4nIDogJ1ZvaWNlIElucHV0IChCaWNhcmEgZGFsYW0gQmFoYXNhIEluZG9uZXNpYSknfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyBib3JkZXIgcm91bmRlZC0yeGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzIHNocmluay0wICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTGlzdGVuaW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1yZWQtNTAwIHRleHQtd2hpdGUgYm9yZGVyLXJlZC01MDAgYW5pbWF0ZS1wdWxzZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci10ZWFsLTUwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzTGlzdGVuaW5nID8gPE1pY09mZiBzaXplPXsxOH0gLz4gOiA8TWljIHNpemU9ezE4fSAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWY9e2lucHV0UmVmfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXsxfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGUua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNZW50aW9uTWVudShmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnRW50ZXInICYmICFlLnNoaWZ0S2V5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVNlbmRNZXNzYWdlKGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0xpc3RlbmluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ1NlZGFuZyBtZW5kZW5nYXJrYW4gc3VhcmEgQW5kYS4uLidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGF0dGFjaGVkRmlsZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ0tldGlrIGluc3RydWtzaSBraHVzdXMgKG9wc2lvbmFsKSBsYWx1IHRla2FuIEVudGVyLi4uJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ1Rhbnlha2FuIHJhbmtpbmcsIGtlY3VyYW5nYW4sIGF0YXUga2V0aWsgQCB1bnR1ayBwaWxpaCBmb3JtdWxpci4uLidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtNCBwci0xMiBweS0zLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwIHNoYWRvdy1zbSByZXNpemUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8IGJ1bGtFeHBvcnRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZyB8fCAoIWlucHV0LnRyaW0oKSAmJiAhYXR0YWNoZWRGaWxlKSB8fCBidWxrRXhwb3J0aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0yLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHAtMiBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZW5kIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgICA8L21haW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJ1bGsgRXhwb3J0IE1vZGFsIHdpdGggQ2hlY2tib3hlcyBhbmQgRGF0ZSBGaWx0ZXJzICovfVxuICAgICAgICAgICAge3Nob3dCdWxrTW9kYWwgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctc2xhdGUtOTAwLzYwIGRhcms6YmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci14c1wiIG9uQ2xpY2s9eygpID0+IHNldFNob3dCdWxrTW9kYWwoZmFsc2UpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTYgbWF4LXctbGcgdy1mdWxsIHNoYWRvdy14bCBzcGFjZS15LTQgei0xMCBtYXgtaC1bODV2aF0gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LXRlYWwtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+QnVsayBFeHBvcnQgUmVzcG9ucyBGb3JtdWxpcjwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlVuZHVoIGJlcmthcyBDU1YgdGVycGlzYWggdW50dWsgc2V0aWFwIGZvcm11bGlyIHlhbmcgZGlwaWxpaC48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dCdWxrTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIERhdGUgUmFuZ2UgUXVpY2sgRmlsdGVycyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPkZpbHRlciBSZW50YW5nIFdha3R1IFBlbWJ1YXRhbjo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNSBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJzEnLCBsYWJlbDogJzEgSGFyaScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnMycsIGxhYmVsOiAnMyBIYXJpJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICc3JywgbGFiZWw6ICc3IEhhcmknIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJzMwJywgbGFiZWw6ICczMCBIYXJpJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdhbGwnLCBsYWJlbDogJ1NlbXVhJyB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKHQgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dC5rZXl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QnVsa0RheXNGaWx0ZXIodC5rZXkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrRGF5c0ZpbHRlciA9PT0gdC5rZXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXRlYWwtNjAwIHRleHQtd2hpdGUgYm9yZGVyLXRlYWwtNjAwIHNoYWRvdy14cydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXRlYWwtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0LmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGb3JtIExpc3Qgd2l0aCBDaGVja2JveGVzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgZmxleC0xIG1pbi1oLTAgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RGFmdGFyIEZvcm11bGlyICh7ZmlsdGVyZWRGb3Jtc0ZvckJ1bGsubGVuZ3RofSk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVNlbGVjdEFsbEJ1bGt9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBob3Zlcjp1bmRlcmxpbmUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaWxpaCBTZW11YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC0yIHNwYWNlLXktMSBkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMC82MCBtYXgtaC00OFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRGb3Jtc0ZvckJ1bGsubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktNiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+VGlkYWsgYWRhIGZvcm11bGlyIGRhbGFtIHJlbnRhbmcgd2FrdHUgaW5pLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkRm9ybXNGb3JCdWxrLm1hcChmID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0NoZWNrZWQgPSBzZWxlY3RlZEZvcm1JZHNGb3JFeHBvcnQuaW5jbHVkZXMoZi5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtmLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2VsZWN0Rm9ybUZvckJ1bGsoZi5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0yIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzYwIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgcHQtMlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBtaW4tdy0wIHByLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNDaGVja2VkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tTcXVhcmUgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTcXVhcmUgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHRydW5jYXRlXCI+e2YudGl0bGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmLnJlc3BvbnNlQ291bnQgfHwgMH0gcmVzcG9uc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRm9vdGVyIENUQSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dCdWxrTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMi41IGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgaG92ZXI6Ymctc2xhdGUtMjAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhdGFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NlbGVjdGVkRm9ybUlkc0ZvckV4cG9ydC5sZW5ndGggPT09IDAgfHwgYnVsa0V4cG9ydGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZm9ybXMgPSB1c2VyRm9ybXMuZmlsdGVyKGYgPT4gc2VsZWN0ZWRGb3JtSWRzRm9yRXhwb3J0LmluY2x1ZGVzKGYuaWQpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4ZWN1dGVCdWxrRXhwb3J0KGZvcm1zLCBgJHtzZWxlY3RlZEZvcm1JZHNGb3JFeHBvcnQubGVuZ3RofSBmb3JtdWxpciB0ZXJwaWxpaGApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMi41IGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIGRpc2FibGVkOm9wYWNpdHktNTAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlVuZHVoICh7c2VsZWN0ZWRGb3JtSWRzRm9yRXhwb3J0Lmxlbmd0aH0pIEZvcm11bGlyPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIEMtMiBQcmV2aWV3ICYgSW5zZXJ0IERvY3VtZW50IFF1ZXN0aW9ucyBNb2RhbCAqL31cbiAgICAgICAgICAgIHtwcmV2aWV3RG9jTW9kYWwgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctc2xhdGUtOTAwLzYwIGRhcms6YmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci14c1wiIG9uQ2xpY2s9eygpID0+ICFjb21taXR0aW5nVG9Gb3JtICYmIHNldFByZXZpZXdEb2NNb2RhbChudWxsKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IG1heC13LTJ4bCB3LWZ1bGwgc2hhZG93LTJ4bCBzcGFjZS15LTQgei0xMCBtYXgtaC1bOTB2aF0gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LXRlYWwtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVVwIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpbmphdSBTb2FsIGRhcmkgRG9rdW1lbjoge3ByZXZpZXdEb2NNb2RhbC5maWxlTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIHtwcmV2aWV3RG9jTW9kYWwucXVlc3Rpb25zPy5sZW5ndGggfHwgMH0gYnV0aXIgc29hbCBzaWFwIGRpbWFzdWtrYW4ga2UgZm9ybXVsaXIgQW5kYS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NvbW1pdHRpbmdUb0Zvcm19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFByZXZpZXdEb2NNb2RhbChudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBUYXJnZXQgRm9ybSBTZWxlY3Rpb24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUdWp1YW4gUGVueWltcGFuYW4gU29hbDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPXtgZmxleC0xIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXRGb3JtSWQgPT09ICduZXcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIGJvcmRlci10ZWFsLTUwMCB0ZXh0LXRlYWwtOTAwIGRhcms6dGV4dC10ZWFsLTIwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0YXJnZXRGb3JtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT1cIm5ld1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGFyZ2V0Rm9ybUlkID09PSAnbmV3J31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gc2V0VGFyZ2V0Rm9ybUlkKCduZXcnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGRcIj7inKggQnVhdCBGb3JtdWxpciBCYXJ1PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+T3RvbWF0aXMgbWVtYnVhdCBrdWlzIGJhcnUgZGFyaSBqdWR1bCBtYXRlcmk8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlckZvcm1zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhcmdldEZvcm1JZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUYXJnZXRGb3JtSWQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJuZXdcIj4tLSBBdGF1IFBpbGloIEZvcm11bGlyIFlhbmcgU3VkYWggQWRhIC0tPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyRm9ybXMubWFwKGYgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2YuaWR9IHZhbHVlPXtmLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYW1iYWhrYW4ga2U6IHtmLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFF1ZXN0aW9ucyBsaXN0IHByZXZpZXcgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtMyBzcGFjZS15LTMgbWF4LWgtNjRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJldmlld0RvY01vZGFsLnF1ZXN0aW9ucz8ubWFwKChxLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwicC0zIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aWR4ICsgMX0uIHtxLnF1ZXN0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLW1kIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EudHlwZUlkID09PSAyID8gJ1BpbGloYW4gR2FuZGEnIDogcS50eXBlSWQgPT09IDMgPyAnQ2hlY2tib3gnIDogcS50eXBlSWQgPT09IDUgPyAnQmVuYXIvU2FsYWgnIDogJ0Vzc2F5J30gKHtxLnBvaW50cyB8fCAxfSBQb2luKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Eub3B0aW9ucyAmJiBxLm9wdGlvbnMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0xIHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Eub3B0aW9ucy5tYXAoKG9wdCwgb0lkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17b0lkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yLjUgcHktMSByb3VuZGVkLWxnIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHQuaXNDb3JyZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNjAgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgZm9udC1ib2xkIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHQuaXNDb3JyZWN0ICYmIDxDaGVjayBzaXplPXsxMn0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTUwMCBzaHJpbmstMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+e29wdC5vcHRpb25UZXh0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS5jb3JyZWN0QW5zd2VyICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBmb250LXNlbWlib2xkIHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgS3VuY2k6IHtxLmNvcnJlY3RBbnN3ZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1vZGFsIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NvbW1pdHRpbmdUb0Zvcm19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFByZXZpZXdEb2NNb2RhbChudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIuNSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLXNsYXRlLTIwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYXRhbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjb21taXR0aW5nVG9Gb3JtfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb21taXRRdWVzdGlvbnNUb0Zvcm19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yLjUgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgZGlzYWJsZWQ6b3BhY2l0eS01MCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb21taXR0aW5nVG9Gb3JtID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsxNH0gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NZW55aW1wYW4ga2UgRm9ybXVsaXIuLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFBsdXMgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+TWFzdWtrYW4ge3ByZXZpZXdEb2NNb2RhbC5xdWVzdGlvbnM/Lmxlbmd0aH0gU29hbCBrZSBGb3JtPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogQ29tbWl0IFN1Y2Nlc3MgRGlhbG9nICovfVxuICAgICAgICAgICAge2NvbW1pdFN1Y2Nlc3NJbmZvICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLXNsYXRlLTkwMC82MCBkYXJrOmJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXIteHNcIiBvbkNsaWNrPXsoKSA9PiBzZXRDb21taXRTdWNjZXNzSW5mbyhudWxsKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IG1heC13LXNtIHctZnVsbCBzaGFkb3ctMnhsIHNwYWNlLXktNCB6LTEwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1lbWVyYWxkLTEwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzgwIHRleHQtZW1lcmFsZC02MDAgbXgtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MjR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmVyaGFzaWwgRGltYXN1a2thbiFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZWJhbnlhayA8Yj57Y29tbWl0U3VjY2Vzc0luZm8uY291bnR9IGJ1dGlyIHNvYWw8L2I+IHRlbGFoIGRpdGFtYmFoa2FuIGtlIDxiPlwie2NvbW1pdFN1Y2Nlc3NJbmZvLmZvcm1UaXRsZX1cIjwvYj4uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB0LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDb21taXRTdWNjZXNzSW5mbyhudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIuNSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLXNsYXRlLTIwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUdXR1cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvZm9ybXMvJHtjb21taXRTdWNjZXNzSW5mby5mb3JtSWR9L2VkaXRgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIuNSBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QnVrYSBGb3JtIEJ1aWxkZXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==