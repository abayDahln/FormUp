import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_BASE_URL": "https://api.formup.my.id"};const envUrl = import.meta.env.VITE_API_BASE_URL;
const API_BASE_URL = envUrl !== undefined && envUrl !== "" ? envUrl : import.meta.env.DEV ? "" : "https://api.formup.my.id";
export const getToken = () => {
	if (typeof window === "undefined") return null;
	const local = localStorage.getItem("token");
	if (local) return local;
	const session = sessionStorage.getItem("token");
	if (session) return session;
	if (typeof document !== "undefined") {
		const match = document.cookie.match(/(?:^|;\s*)formup_token=([^;]+)/);
		if (match && match[1]) {
			localStorage.setItem("token", match[1]);
			return match[1];
		}
	}
	return null;
};
// Upload gambar untuk opsi jawaban tertentu
export const uploadOptionImage = (formId, questionId, optionId, file, onProgress) => {
	return new Promise((resolve) => {
		const token = getToken();
		const form = new FormData();
		form.append("file", file);
		const xhr = new XMLHttpRequest();
		if (typeof onProgress === "function") {
			xhr.upload.addEventListener("progress", (e) => {
				if (e.lengthComputable) onProgress(Math.round(e.loaded / e.total * 100));
			});
		}
		xhr.onload = () => {
			try {
				const data = JSON.parse(xhr.responseText);
				resolve({
					ok: xhr.status >= 200 && xhr.status < 300,
					status: xhr.status,
					data: data?.data ?? data,
					message: data?.message
				});
			} catch {
				resolve({
					ok: false,
					status: xhr.status,
					message: "Response parse error"
				});
			}
		};
		xhr.onerror = () => resolve({
			ok: false,
			status: 0,
			message: "Network error"
		});
		xhr.open("POST", `${API_BASE_URL}/api/forms/${formId}/questions/${questionId}/options/${optionId}/upload-image`);
		if (token) xhr.setRequestHeader("Authorization", `Bearer ${token}`);
		xhr.send(form);
	});
};
const authHeaders = () => {
	const headers = { "Content-Type": "application/json" };
	const token = getToken();
	if (token) headers["Authorization"] = `Bearer ${token}`;
	return headers;
};
let _refreshInFlight = null;
const _redirectToLoginWithReason = (reason) => {
	clearSession();
	if (typeof window === "undefined") return;
	try {
		const path = window.location.pathname || "";
		if (path.startsWith("/login")) return;
		const query = reason ? `?reason=${encodeURIComponent(reason)}` : "";
		window.location.assign(`/login${query}`);
	} catch {}
};
const _performRefreshMutex = async () => {
	if (_refreshInFlight) return _refreshInFlight;
	_refreshInFlight = (async () => {
		try {
			const res = await fetch(`${API_BASE_URL}/api/auth/refresh`, {
				method: "POST",
				headers: authHeaders()
			});
			const result = await parseResponse(res);
			if (result.ok && result.data?.token) {
				const remember = localStorage.getItem("rememberMe") === "true";
				const existingUser = getLocalUser();
				saveSession({
					token: result.data.token,
					user: existingUser || result.data.user || null
				}, remember);
				return true;
			}
			_redirectToLoginWithReason("session_expired");
			return false;
		} catch {
			_redirectToLoginWithReason("session_expired");
			return false;
		} finally {
			_refreshInFlight = null;
		}
	})();
	return _refreshInFlight;
};
export const authFetch = async (url, options = {}) => {
	const token = getToken();
	const isFormData = options && options.body && typeof options.body.append && typeof options.body.constructor === "function" && options.body instanceof FormData;
	const baseHeaders = {};
	if (!isFormData) baseHeaders["Content-Type"] = "application/json";
	if (token) baseHeaders["Authorization"] = `Bearer ${token}`;
	const headers = {
		...baseHeaders,
		...options.headers || {}
	};
	const res = await fetch(url, {
		...options,
		headers
	});
	const isAuthUrl = typeof url === "string" && url.includes("/api/auth/");
	if (token && res.status === 401 && !isAuthUrl) {
		const refreshed = await _performRefreshMutex();
		if (refreshed) {
			const newToken = getToken();
			const retryHeaders = { ...options.headers || {} };
			if (!isFormData) retryHeaders["Content-Type"] = "application/json";
			if (newToken) retryHeaders["Authorization"] = `Bearer ${newToken}`;
			return fetch(url, {
				...options,
				headers: retryHeaders,
				body: options.body
			});
		}
	}
	return res;
};
const parseResponse = async (res) => {
	let body;
	try {
		body = await res.json();
	} catch {
		body = {};
	}
	const serverDown = res.status === 502 || res.status === 503 || res.status === 504;
	return {
		ok: res.ok,
		status: body.status ?? res.status,
		message: body.message ?? (res.ok ? "OK" : serverDown ? "Server sedang tidak aktif. Silakan coba lagi beberapa saat kemudian." : "Error"),
		data: body.data ?? null
	};
};
// ── Auth Endpoints ────────────────────────────────────────────────────────────
export const login = async (email, password) => {
	const res = await fetch(`${API_BASE_URL}/api/auth/login`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			email,
			password
		})
	});
	return parseResponse(res);
};
export const register = async (fullname, username, email, password, birthdate) => {
	const res = await fetch(`${API_BASE_URL}/api/auth/register`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			fullname,
			username,
			email,
			password,
			birthdate
		})
	});
	return parseResponse(res);
};
export const verifyRegistration = async (fullname, username, email, password, birthdate, otp) => {
	const res = await fetch(`${API_BASE_URL}/api/auth/verify-registration`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			fullname,
			username,
			email,
			password,
			birthdate,
			otp
		})
	});
	return parseResponse(res);
};
export const refreshToken = async () => {
	const res = await fetch(`${API_BASE_URL}/api/auth/refresh`, {
		method: "POST",
		headers: authHeaders()
	});
	return parseResponse(res);
};
export const forgotPassword = async (email) => {
	const res = await fetch(`${API_BASE_URL}/api/auth/forgot-password`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ email })
	});
	return parseResponse(res);
};
export const resetPassword = async (email, otp, newPassword) => {
	const res = await fetch(`${API_BASE_URL}/api/auth/reset-password`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			email,
			otp,
			newPassword
		})
	});
	return parseResponse(res);
};
// ── User Profile Endpoints ────────────────────────────────────────────────────
export const getMyProfile = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/users/me`));
export const updateProfile = async (payload) => {
	const res = await authFetch(`${API_BASE_URL}/api/users/me`, {
		method: "PUT",
		body: JSON.stringify(payload)
	});
	return parseResponse(res);
};
export const changePassword = async (currentPassword, newPassword) => {
	const res = await authFetch(`${API_BASE_URL}/api/users/change-password`, {
		method: "POST",
		body: JSON.stringify({
			currentPassword,
			newPassword
		})
	});
	return parseResponse(res);
};
export const uploadProfileImage = async (file) => {
	const form = new FormData();
	form.append("file", file);
	const res = await authFetch(`${API_BASE_URL}/api/users/me/profile-image`, {
		method: "POST",
		body: form
	});
	return parseResponse(res);
};
export const getMyStats = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/users/me/stats`));
export const getMySubmittedResponses = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/users/me/responses`));
// ── Reference Endpoints ──────────────────────────────────────────────────────
export const getFormTypes = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/references/form-types`));
export const getFormStatuses = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/references/form-statuses`));
export const getQuestionTypes = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/references/question-types`));
// ── Form Endpoints ────────────────────────────────────────────────────────────
export const getMyForms = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/forms`));
export const getFormById = async (id) => parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${id}`));
export const createForm = async ({ title, description, descriptionFormat }) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms`, {
		method: "POST",
		body: JSON.stringify({
			title,
			description,
			descriptionFormat
		})
	});
	return parseResponse(res);
};
export const updateForm = async (id, payload) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${id}`, {
		method: "PUT",
		body: JSON.stringify(payload)
	});
	return parseResponse(res);
};
export const deleteForm = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${id}`, { method: "DELETE" });
	return parseResponse(res);
};
export const bulkDeleteForms = async (formIds) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/bulk-delete`, {
		method: "POST",
		body: JSON.stringify({ formIds })
	});
	return parseResponse(res);
};
export const togglePublishForm = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${id}/publish`, { method: "POST" });
	return parseResponse(res);
};
export const updateFormSettings = async (id, settings) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${id}/settings`, {
		method: "PATCH",
		body: JSON.stringify(settings)
	});
	return parseResponse(res);
};
export const getFormShare = async (id) => parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${id}/share`));
export const uploadFormBanner = async (formId, file) => {
	const form = new FormData();
	form.append("file", file);
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/banner`, {
		method: "POST",
		body: form
	});
	return parseResponse(res);
};
// ── Question Endpoints ────────────────────────────────────────────────────────
export const getQuestions = async (formId, { page, pageSize, search } = {}) => {
	const params = new URLSearchParams();
	if (page != null) params.set("page", page);
	if (pageSize != null) params.set("pageSize", pageSize);
	if (search != null && search !== "") params.set("search", search);
	const qs = params.toString() ? `?${params.toString()}` : "";
	return parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${formId}/questions${qs}`));
};
export const saveQuestions = async (formId, questions) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/questions`, {
		method: "PUT",
		body: JSON.stringify({ questions })
	});
	return parseResponse(res);
};
export const addQuestions = async (formId, questions) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/questions`, {
		method: "POST",
		body: JSON.stringify({ questions })
	});
	return parseResponse(res);
};
export const deleteQuestion = async (formId, questionId) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/questions/${questionId}`, { method: "DELETE" });
	return parseResponse(res);
};
export const deleteAllQuestions = async (formId) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/questions`, { method: "DELETE" });
	return parseResponse(res);
};
export const previewImportQuestions = async (formId, file) => {
	const form = new FormData();
	form.append("file", file);
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/questions/import/preview`, {
		method: "POST",
		body: form
	});
	return parseResponse(res);
};
export const importQuestions = async (formId, file) => {
	const form = new FormData();
	form.append("file", file);
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/questions/import`, {
		method: "POST",
		body: form
	});
	return parseResponse(res);
};
// B1: Use XMLHttpRequest for upload progress support
export const uploadQuestionImage = (formId, questionId, file, onProgress) => {
	return new Promise((resolve) => {
		const token = getToken();
		const form = new FormData();
		form.append("file", file);
		const xhr = new XMLHttpRequest();
		if (typeof onProgress === "function") {
			xhr.upload.addEventListener("progress", (e) => {
				if (e.lengthComputable) onProgress(Math.round(e.loaded / e.total * 100));
			});
		}
		xhr.onload = () => {
			try {
				const data = JSON.parse(xhr.responseText);
				resolve({
					ok: xhr.status >= 200 && xhr.status < 300,
					status: xhr.status,
					data: data?.data ?? data,
					message: data?.message
				});
			} catch {
				resolve({
					ok: false,
					status: xhr.status,
					message: "Response parse error"
				});
			}
		};
		xhr.onerror = () => resolve({
			ok: false,
			status: 0,
			message: "Network error"
		});
		xhr.open("POST", `${API_BASE_URL}/api/forms/${formId}/questions/${questionId}/upload-image`);
		if (token) xhr.setRequestHeader("Authorization", `Bearer ${token}`);
		xhr.send(form);
	});
};
// B1: Use XMLHttpRequest for upload progress support
export const uploadQuestionAudio = (formId, questionId, file, onProgress) => {
	return new Promise((resolve) => {
		const token = getToken();
		const form = new FormData();
		form.append("file", file);
		const xhr = new XMLHttpRequest();
		if (typeof onProgress === "function") {
			xhr.upload.addEventListener("progress", (e) => {
				if (e.lengthComputable) onProgress(Math.round(e.loaded / e.total * 100));
			});
		}
		xhr.onload = () => {
			try {
				const data = JSON.parse(xhr.responseText);
				resolve({
					ok: xhr.status >= 200 && xhr.status < 300,
					status: xhr.status,
					data: data?.data ?? data,
					message: data?.message
				});
			} catch {
				resolve({
					ok: false,
					status: xhr.status,
					message: "Response parse error"
				});
			}
		};
		xhr.onerror = () => resolve({
			ok: false,
			status: 0,
			message: "Network error"
		});
		xhr.open("POST", `${API_BASE_URL}/api/forms/${formId}/questions/${questionId}/upload-audio`);
		if (token) xhr.setRequestHeader("Authorization", `Bearer ${token}`);
		xhr.send(form);
	});
};
// ── Response Endpoints (Owner) ────────────────────────────────────────────────
export const getFormResponses = async (formId, { page, pageSize, search } = {}) => {
	const params = new URLSearchParams();
	if (page != null) params.set("page", page);
	if (pageSize != null) params.set("pageSize", pageSize);
	if (search != null && search !== "") params.set("search", search);
	const qs = params.toString() ? `?${params}` : "";
	return parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${formId}/responses${qs}`));
};
export const getResponseDetail = async (formId, responseId) => parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${formId}/responses/${responseId}`));
export const getResponseResult = async (formId, responseId) => parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${formId}/responses/${responseId}/result`));
export const getResponseAttempts = async (formId, responseId) => parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${formId}/responses/${responseId}/attempts`));
export const updateResponseStatus = async (responseId, statusId) => {
	const res = await authFetch(`${API_BASE_URL}/api/responses/${responseId}/status`, {
		method: "PUT",
		body: JSON.stringify({ statusId })
	});
	return parseResponse(res);
};
// Helper: Resolve answer key per question according to specification
export const resolveAnswerKey = (q) => {
	if (!q) return "";
	const typeId = q.typeId ?? q.type_id;
	const typeName = String(q.type || q.questionType?.type || "").toLowerCase();
	// Untuk tipe soal Essay atau Benar-Salah: ambil dari q.CorrectAnswer
	if (typeId === 1 || typeId === 5 || typeName.includes("essay") || typeName.includes("benar") || typeName.includes("true") || typeName.includes("false")) {
		return q.correctAnswer || q.CorrectAnswer || "";
	}
	// Untuk tipe soal PG atau Checkbox: gabungkan teks opsi yang IsCorrect == true, dipisah "; "
	const options = q.options || q.optionQuestions || q.OptionQuestions || [];
	if (Array.isArray(options) && options.length > 0) {
		const correctOpts = options.filter((o) => o.isCorrect === true || o.IsCorrect === true).map((o) => o.optionText || o.OptionText || "").filter(Boolean);
		if (correctOpts.length > 0) {
			return correctOpts.join("; ");
		}
	}
	return q.correctAnswer || q.CorrectAnswer || "";
};
export const ResolveAnswerKey = resolveAnswerKey;
// Helper: Bersihkan notasi KaTeX/LaTeX jadi teks/unicode biasa (A5)
export const stripMathNotation = (text) => {
	if (text === null || text === undefined) return "";
	let str = String(text);
	// Iterative replacement for fractions: \frac{a}{b} -> a/b
	for (let i = 0; i < 5; i++) {
		const next = str.replace(/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, "$1/$2");
		if (next === str) break;
		str = next;
	}
	// Square roots: \sqrt[n]{x} -> n√(x), \sqrt{x} -> √(x)
	str = str.replace(/\\sqrt\[([^\]]+)\]\{([^{}]+)\}/g, "$1√($2)");
	str = str.replace(/\\sqrt\{([^{}]+)\}/g, "√($1)");
	// Common LaTeX math symbols to unicode
	const mathReplacements = [
		[/\\times\b/g, "×"],
		[/\\div\b/g, "÷"],
		[/\\pm\b/g, "±"],
		[/\\mp\b/g, "∓"],
		[/\\le(q)?\b/g, "≤"],
		[/\\ge(q)?\b/g, "≥"],
		[/\\ne(q)?\b/g, "≠"],
		[/\\approx\b/g, "≈"],
		[/\\sim\b/g, "~"],
		[/\\infty\b/g, "∞"],
		[/\\cdot\b/g, "·"],
		[/\\bullet\b/g, "•"],
		[/\\circ\b/g, "°"],
		[/\\degree\b/g, "°"],
		[/\\alpha\b/g, "α"],
		[/\\beta\b/g, "β"],
		[/\\gamma\b/g, "γ"],
		[/\\delta\b/g, "δ"],
		[/\\Delta\b/g, "Δ"],
		[/\\pi\b/g, "π"],
		[/\\theta\b/g, "θ"],
		[/\\lambda\b/g, "λ"],
		[/\\sigma\b/g, "σ"],
		[/\\omega\b/g, "ω"],
		[/\\sum\b/g, "Σ"],
		[/\\prod\b/g, "∏"],
		[/\\rightarrow\b/g, "→"],
		[/\\leftarrow\b/g, "←"],
		[/\\leftrightarrow\b/g, "↔"]
	];
	for (const [pattern, replacement] of mathReplacements) {
		str = str.replace(pattern, replacement);
	}
	// Text wrappers: \text{...}, \mathrm{...}, etc.
	str = str.replace(/\\(?:text|mathrm|mathbf|mathit|textbf|textit)\{([^{}]+)\}/g, "$1");
	// Remove $ and $$ delimiters
	str = str.replace(/\$\$([\s\S]*?)\$\$/g, "$1");
	str = str.replace(/\$([^$]+)\$/g, "$1");
	// Remove remaining escaped braces: \{ -> {, \} -> }
	str = str.replace(/\\([{}])/g, "$1");
	// Clean up residual backslashes before alpha words
	str = str.replace(/\\[a-zA-Z]+/g, "");
	// Strip html tags
	str = str.replace(/<[^>]*>/g, "");
	return str.trim();
};
export const exportUrl = (formId, format = "csv", includeAnswerKey = true) => {
	const token = getToken();
	const params = new URLSearchParams();
	if (format) params.set("format", format);
	if (includeAnswerKey !== undefined) params.set("includeAnswerKey", includeAnswerKey);
	if (token) params.set("token", token);
	const qs = params.toString() ? `?${params}` : "";
	return `${API_BASE_URL}/api/forms/${formId}/responses/export${qs}`;
};
export const exportFormResponses = async (formId, format = "csv", includeAnswerKey = true) => {
	const fmt = (format || "csv").toLowerCase();
	const params = new URLSearchParams();
	params.set("format", fmt);
	if (includeAnswerKey !== undefined) {
		params.set("includeAnswerKey", includeAnswerKey);
	}
	try {
		const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/responses/export?${params.toString()}`);
		if (!res.ok) {
			let msg = "Gagal mengekspor data respons";
			let errDetail = "";
			try {
				const err = await res.json();
				msg = err.message || msg;
				errDetail = JSON.stringify(err);
			} catch {
				try {
					errDetail = await res.text();
				} catch {}
			}
			if (fmt === "pdf" && res.status === 500) {
				console.error("[Export PDF 500 Error] Server failed generating PDF:", res.status, errDetail);
				msg = "Export PDF gagal, kemungkinan karena konten matematika pada soal. Coba export CSV/Excel sementara, atau hubungi admin.";
			}
			return {
				ok: false,
				message: msg
			};
		}
		const blob = await res.blob();
		const url = window.URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		const ext = fmt === "xlsx" ? "xlsx" : fmt === "pdf" ? "pdf" : "csv";
		a.download = `responses-form-${formId}.${ext}`;
		document.body.appendChild(a);
		a.click();
		a.remove();
		window.URL.revokeObjectURL(url);
		return { ok: true };
	} catch (networkErr) {
		console.error("[Export Responses Network Error]:", networkErr);
		return {
			ok: false,
			message: fmt === "pdf" ? "Export PDF gagal, kemungkinan karena konten matematika pada soal. Coba export CSV/Excel sementara, atau hubungi admin." : "Terjadi kesalahan jaringan saat mengekspor data respons."
		};
	}
};
// ── Feedback Endpoints ────────────────────────────────────────────────────────
export const submitFeedback = async (formId, { reason, description, responseId = null }) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/feedback`, {
		method: "POST",
		body: JSON.stringify({
			reason,
			description,
			responseId
		})
	});
	return parseResponse(res);
};
export const getMyFeedback = async (formId) => parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${formId}/feedback`));
export const getFormFeedbacks = async (formId) => parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${formId}/feedbacks`));
// ── Template Endpoints ────────────────────────────────────────────────────────
export const templateDownloadUrl = (format = "csv") => `${API_BASE_URL}/api/templates/import-questions?format=${format}`;
// ── Analytics Endpoints ───────────────────────────────────────────────────────
export const getFormAnalytics = async (formId) => parseResponse(await authFetch(`${API_BASE_URL}/api/forms/${formId}/analytics`));
// ── Public Form Flow (Responden) ──────────────────────────────────────────────
// Step 1: Get public form metadata & requirements (no questions)
export const getPublicFormByLink = async (formLink) => {
	const res = await fetch(`${API_BASE_URL}/api/public/forms/${formLink}`);
	return parseResponse(res);
};
// Step 2: Request public questions after token/login validation
export const getPublicFormQuestions = async (formLink, { token, name } = {}) => {
	const res = await authFetch(`${API_BASE_URL}/api/public/forms/${formLink}/questions`, {
		method: "POST",
		body: JSON.stringify({
			token: token || null,
			name: name || null
		})
	});
	return parseResponse(res);
};
// Step 3: Submit public form responses
export const submitPublicFormResponse = async (formLink, payload) => {
	const res = await authFetch(`${API_BASE_URL}/api/public/forms/${formLink}/responses`, {
		method: "POST",
		body: JSON.stringify(payload)
	});
	return parseResponse(res);
};
// Step 4: Get public response result (for respondent view)
export const getPublicResponseResult = async (formLink, responseId, guestToken) => {
	const url = guestToken ? `${API_BASE_URL}/api/public/forms/${formLink}/responses/${responseId}?token=${encodeURIComponent(guestToken)}` : `${API_BASE_URL}/api/public/forms/${formLink}/responses/${responseId}`;
	const res = await authFetch(url);
	return parseResponse(res);
};
// ── Exam Monitoring Endpoints ────────────────────────────────────────────────
// Backend: [HttpPost("api/public/forms/{formLink}/exam-events")] in ExamMonitoringController.cs
export const postExamEvent = async (formLink, eventData) => {
	const res = await authFetch(`${API_BASE_URL}/api/public/forms/${formLink}/exam-events`, {
		method: "POST",
		body: JSON.stringify(eventData)
	});
	return parseResponse(res);
};
// Backend: [HttpGet("api/forms/{formId}/exam-monitoring")] in ExamMonitoringController.cs
export const getExamMonitoring = async (formId) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/exam-monitoring`);
	return parseResponse(res);
};
export const ExamProctorActions = { ForceSubmitByProctor: "FORCE_SUBMIT_BY_PROCTOR" };
// Backend: [HttpPost("api/forms/{formId}/exam-monitoring/sessions/{sessionId}/force-submit")]
export const forceSubmitExamSession = async (formId, sessionId) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/exam-monitoring/sessions/${encodeURIComponent(sessionId)}/force-submit`, { method: "POST" });
	return parseResponse(res);
};
// Backend: [HttpPost("api/forms/{formId}/exam-monitoring/sessions/{sessionId}/reset")]
export const resetExamSession = async (formId, sessionId) => {
	const res = await authFetch(`${API_BASE_URL}/api/forms/${formId}/exam-monitoring/sessions/${encodeURIComponent(sessionId)}/reset`, { method: "POST" });
	return parseResponse(res);
};
// Backend: [HttpPost("api/public/forms/{formLink}/exam-sessions/{sessionId}/sync-answers")]
// Note: syncExamAnswers is used by guest (no auth token expected); tetap pakai fetch manual tanpa wrapper karena Content-Type di-set custom tanpa auth header influence.
export const syncExamAnswers = async (formLink, sessionId, { answers, respondentName }) => {
	const res = await fetch(`${API_BASE_URL}/api/public/forms/${encodeURIComponent(formLink)}/exam-sessions/${encodeURIComponent(sessionId)}/sync-answers`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			answers,
			respondentName
		})
	});
	return parseResponse(res);
};
// ── Score Override Endpoints ─────────────────────────────────────────────────
// Backend: [HttpPut("api/responses/{id}/answers/{answerId}/score")] in ResponsesController.cs
export const overrideAnswerScore = async (responseId, answerId, payload) => {
	const res = await authFetch(`${API_BASE_URL}/api/responses/${responseId}/answers/${answerId}/score`, {
		method: "PUT",
		body: JSON.stringify(payload)
	});
	return parseResponse(res);
};
// Backend: [HttpPut("api/responses/{id}/scores")] in ResponsesController.cs
export const bulkOverrideAnswerScores = async (responseId, overrides) => {
	const res = await authFetch(`${API_BASE_URL}/api/responses/${responseId}/scores`, {
		method: "PUT",
		body: JSON.stringify({ overrides })
	});
	return parseResponse(res);
};
// Alias (backward compatible — beberapa call site lama memakai updateAnswerScore)
export const updateAnswerScore = overrideAnswerScore;
// ── Admin Endpoints ───────────────────────────────────────────────────────────
export const adminGetUsers = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/admin/users`));
export const adminGetUserDetail = async (id) => parseResponse(await authFetch(`${API_BASE_URL}/api/admin/users/${id}`));
export const adminGetForms = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/admin/forms`));
export const adminGetFormDetail = async (id) => parseResponse(await authFetch(`${API_BASE_URL}/api/admin/forms/${id}`));
export const adminGetFeedback = async () => parseResponse(await authFetch(`${API_BASE_URL}/api/admin/feedback`));
export const adminBanUser = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/admin/users/${id}/ban`, { method: "PUT" });
	return parseResponse(res);
};
export const adminActivateUser = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/admin/users/${id}/activate`, { method: "PUT" });
	return parseResponse(res);
};
export const adminDeleteUser = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/admin/users/${id}`, { method: "DELETE" });
	return parseResponse(res);
};
export const adminTakedownForm = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/admin/forms/${id}/takedown`, { method: "POST" });
	return parseResponse(res);
};
export const adminRestoreForm = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/admin/forms/${id}/restore`, { method: "POST" });
	return parseResponse(res);
};
export const adminDeleteForm = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/admin/forms/${id}`, { method: "DELETE" });
	return parseResponse(res);
};
export const adminDeleteFeedback = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/admin/feedback/${id}`, { method: "DELETE" });
	return parseResponse(res);
};
export const adminTakedownFormFromFeedback = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/admin/feedback/${id}/takedown`, { method: "POST" });
	return parseResponse(res);
};
export const adminRestoreFormFromFeedback = async (id) => {
	const res = await authFetch(`${API_BASE_URL}/api/admin/feedback/${id}/restore`, { method: "POST" });
	return parseResponse(res);
};
// ── Session Helpers ───────────────────────────────────────────────────────────
export const saveSession = (authData, rememberMe = true) => {
	const storage = rememberMe ? localStorage : sessionStorage;
	const altStorage = rememberMe ? sessionStorage : localStorage;
	altStorage.removeItem("token");
	altStorage.removeItem("user");
	if (authData.token) {
		storage.setItem("token", authData.token);
		// Set cookie with appropriate expiration
		const maxAge = rememberMe ? 60 * 60 * 24 * 30 : "";
		const cookieStr = `formup_token=${authData.token}; path=/; SameSite=Lax${maxAge ? `; max-age=${maxAge}` : ""}`;
		if (typeof document !== "undefined") {
			document.cookie = cookieStr;
		}
	}
	if (authData.user) {
		storage.setItem("user", JSON.stringify(authData.user));
	}
	if (rememberMe) {
		localStorage.setItem("rememberMe", "true");
	} else {
		localStorage.removeItem("rememberMe");
	}
};
export const clearSession = () => {
	localStorage.removeItem("token");
	localStorage.removeItem("user");
	localStorage.removeItem("rememberMe");
	sessionStorage.removeItem("token");
	sessionStorage.removeItem("user");
	if (typeof document !== "undefined") {
		document.cookie = "formup_token=; path=/; max-age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax";
		document.cookie = "formup_token=; path=/; max-age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT";
		document.cookie = "formup_token=; max-age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT";
	}
};
export const isAuthenticated = () => !!getToken();
export const getLocalUser = () => {
	try {
		const u = localStorage.getItem("user") || sessionStorage.getItem("user");
		return u ? JSON.parse(u) : {};
	} catch {
		return {};
	}
};
export const assetUrl = (path, fallback = "") => {
	if (!path) return fallback;
	if (typeof path !== "string") {
		if (typeof window !== "undefined" && path instanceof File) {
			try {
				return URL.createObjectURL(path);
			} catch {
				return fallback;
			}
		}
		return fallback;
	}
	if (path.startsWith("http") || path.startsWith("blob:") || path.startsWith("data:")) return path;
	return `${API_BASE_URL}${path.startsWith("/") ? "" : "/"}${path}`;
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsTUFBTSxTQUFTLE9BQU8sS0FBSyxJQUFJO0FBQy9CLE1BQU0sZUFBZ0IsV0FBVyxhQUFhLFdBQVcsS0FDbkQsU0FDQyxPQUFPLEtBQUssSUFBSSxNQUFNLEtBQUs7QUFFbEMsT0FBTyxNQUFNLGlCQUFpQjtDQUMxQixJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87Q0FDMUMsTUFBTSxRQUFRLGFBQWEsUUFBUSxPQUFPO0NBQzFDLElBQUksT0FBTyxPQUFPO0NBQ2xCLE1BQU0sVUFBVSxlQUFlLFFBQVEsT0FBTztDQUM5QyxJQUFJLFNBQVMsT0FBTztDQUVwQixJQUFJLE9BQU8sYUFBYSxhQUFhO0VBQ2pDLE1BQU0sUUFBUSxTQUFTLE9BQU8sTUFBTSxnQ0FBZ0M7RUFDcEUsSUFBSSxTQUFTLE1BQU0sSUFBSTtHQUNuQixhQUFhLFFBQVEsU0FBUyxNQUFNLEVBQUU7R0FDdEMsT0FBTyxNQUFNO0VBQ2pCO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7O0FBR0EsT0FBTyxNQUFNLHFCQUFxQixRQUFRLFlBQVksVUFBVSxNQUFNLGVBQWU7Q0FDakYsT0FBTyxJQUFJLFNBQVMsWUFBWTtFQUM1QixNQUFNLFFBQVEsU0FBUztFQUN2QixNQUFNLE9BQU8sSUFBSSxTQUFTO0VBQzFCLEtBQUssT0FBTyxRQUFRLElBQUk7RUFDeEIsTUFBTSxNQUFNLElBQUksZUFBZTtFQUMvQixJQUFJLE9BQU8sZUFBZSxZQUFZO0dBQ2xDLElBQUksT0FBTyxpQkFBaUIsYUFBYSxNQUFNO0lBQzNDLElBQUksRUFBRSxrQkFBa0IsV0FBVyxLQUFLLE1BQU8sRUFBRSxTQUFTLEVBQUUsUUFBUyxHQUFHLENBQUM7R0FDN0UsQ0FBQztFQUNMO0VBQ0EsSUFBSSxlQUFlO0dBQ2YsSUFBSTtJQUNBLE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxZQUFZO0lBQ3hDLFFBQVE7S0FBRSxJQUFJLElBQUksVUFBVSxPQUFPLElBQUksU0FBUztLQUFLLFFBQVEsSUFBSTtLQUFRLE1BQU0sTUFBTSxRQUFRO0tBQU0sU0FBUyxNQUFNO0lBQVEsQ0FBQztHQUMvSCxRQUFRO0lBQ0osUUFBUTtLQUFFLElBQUk7S0FBTyxRQUFRLElBQUk7S0FBUSxTQUFTO0lBQXVCLENBQUM7R0FDOUU7RUFDSjtFQUNBLElBQUksZ0JBQWdCLFFBQVE7R0FBRSxJQUFJO0dBQU8sUUFBUTtHQUFHLFNBQVM7RUFBZ0IsQ0FBQztFQUM5RSxJQUFJLEtBQUssUUFBUSxHQUFHLGFBQWEsYUFBYSxPQUFPLGFBQWEsV0FBVyxXQUFXLFNBQVMsY0FBYztFQUMvRyxJQUFJLE9BQU8sSUFBSSxpQkFBaUIsaUJBQWlCLFVBQVUsT0FBTztFQUNsRSxJQUFJLEtBQUssSUFBSTtDQUNqQixDQUFDO0FBQ0w7QUFFQSxNQUFNLG9CQUFvQjtDQUN0QixNQUFNLFVBQVUsRUFBRSxnQkFBZ0IsbUJBQW1CO0NBQ3JELE1BQU0sUUFBUSxTQUFTO0NBQ3ZCLElBQUksT0FBTyxRQUFRLG1CQUFtQixVQUFVO0NBQ2hELE9BQU87QUFDWDtBQUVBLElBQUksbUJBQW1CO0FBRXZCLE1BQU0sOEJBQThCLFdBQVc7Q0FDM0MsYUFBYTtDQUNiLElBQUksT0FBTyxXQUFXLGFBQWE7Q0FDbkMsSUFBSTtFQUNBLE1BQU0sT0FBTyxPQUFPLFNBQVMsWUFBWTtFQUN6QyxJQUFJLEtBQUssV0FBVyxRQUFRLEdBQUc7RUFDL0IsTUFBTSxRQUFRLFNBQVMsV0FBVyxtQkFBbUIsTUFBTSxNQUFNO0VBQ2pFLE9BQU8sU0FBUyxPQUFPLFNBQVMsT0FBTztDQUMzQyxRQUFRLENBRVI7QUFDSjtBQUVBLE1BQU0sdUJBQXVCLFlBQVk7Q0FDckMsSUFBSSxrQkFBa0IsT0FBTztDQUM3QixvQkFBb0IsWUFBWTtFQUM1QixJQUFJO0dBQ0EsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWEsb0JBQW9CO0lBQ3hELFFBQVE7SUFDUixTQUFTLFlBQVk7R0FDekIsQ0FBQztHQUNELE1BQU0sU0FBUyxNQUFNLGNBQWMsR0FBRztHQUN0QyxJQUFJLE9BQU8sTUFBTSxPQUFPLE1BQU0sT0FBTztJQUNqQyxNQUFNLFdBQVcsYUFBYSxRQUFRLFlBQVksTUFBTTtJQUN4RCxNQUFNLGVBQWUsYUFBYTtJQUNsQyxZQUFZO0tBQUUsT0FBTyxPQUFPLEtBQUs7S0FBTyxNQUFNLGdCQUFnQixPQUFPLEtBQUssUUFBUTtJQUFLLEdBQUcsUUFBUTtJQUNsRyxPQUFPO0dBQ1g7R0FDQSwyQkFBMkIsaUJBQWlCO0dBQzVDLE9BQU87RUFDWCxRQUFRO0dBQ0osMkJBQTJCLGlCQUFpQjtHQUM1QyxPQUFPO0VBQ1gsVUFBVTtHQUNOLG1CQUFtQjtFQUN2QjtDQUNKLEVBQUMsQ0FBRTtDQUNILE9BQU87QUFDWDtBQUVBLE9BQU8sTUFBTSxZQUFZLE9BQU8sS0FBSyxVQUFVLENBQUMsTUFBTTtDQUNsRCxNQUFNLFFBQVEsU0FBUztDQUN2QixNQUFNLGFBQWEsV0FBVyxRQUFRLFFBQVEsT0FBTyxRQUFRLEtBQUssVUFBVSxPQUFPLFFBQVEsS0FBSyxnQkFBZ0IsY0FBYyxRQUFRLGdCQUFnQjtDQUN0SixNQUFNLGNBQWMsQ0FBQztDQUNyQixJQUFJLENBQUMsWUFBWSxZQUFZLGtCQUFrQjtDQUMvQyxJQUFJLE9BQU8sWUFBWSxtQkFBbUIsVUFBVTtDQUNwRCxNQUFNLFVBQVU7RUFBRSxHQUFHO0VBQWEsR0FBSSxRQUFRLFdBQVcsQ0FBQztDQUFHO0NBRTdELE1BQU0sTUFBTSxNQUFNLE1BQU0sS0FBSztFQUFFLEdBQUc7RUFBUztDQUFRLENBQUM7Q0FDcEQsTUFBTSxZQUFZLE9BQU8sUUFBUSxZQUFZLElBQUksU0FBUyxZQUFZO0NBQ3RFLElBQUksU0FBUyxJQUFJLFdBQVcsT0FBTyxDQUFDLFdBQVc7RUFDM0MsTUFBTSxZQUFZLE1BQU0scUJBQXFCO0VBQzdDLElBQUksV0FBVztHQUNYLE1BQU0sV0FBVyxTQUFTO0dBQzFCLE1BQU0sZUFBZSxFQUFFLEdBQUksUUFBUSxXQUFXLENBQUMsRUFBRztHQUNsRCxJQUFJLENBQUMsWUFBWSxhQUFhLGtCQUFrQjtHQUNoRCxJQUFJLFVBQVUsYUFBYSxtQkFBbUIsVUFBVTtHQUN4RCxPQUFPLE1BQU0sS0FBSztJQUFFLEdBQUc7SUFBUyxTQUFTO0lBQWMsTUFBTSxRQUFRO0dBQUssQ0FBQztFQUMvRTtDQUNKO0NBQ0EsT0FBTztBQUNYO0FBRUEsTUFBTSxnQkFBZ0IsT0FBTyxRQUFRO0NBQ2pDLElBQUk7Q0FDSixJQUFJO0VBQUUsT0FBTyxNQUFNLElBQUksS0FBSztDQUFHLFFBQVE7RUFBRSxPQUFPLENBQUM7Q0FBRztDQUNwRCxNQUFNLGFBQWEsSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXO0NBQzlFLE9BQU87RUFDSCxJQUFJLElBQUk7RUFDUixRQUFRLEtBQUssVUFBVSxJQUFJO0VBQzNCLFNBQVMsS0FBSyxZQUFZLElBQUksS0FBSyxPQUFRLGFBQWEseUVBQXlFO0VBQ2pJLE1BQU0sS0FBSyxRQUFRO0NBQ3ZCO0FBQ0o7O0FBR0EsT0FBTyxNQUFNLFFBQVEsT0FBTyxPQUFPLGFBQWE7Q0FDNUMsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWEsa0JBQWtCO0VBQ3RELFFBQVE7RUFDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtFQUM5QyxNQUFNLEtBQUssVUFBVTtHQUFFO0dBQU87RUFBUyxDQUFDO0NBQzVDLENBQUM7Q0FDRCxPQUFPLGNBQWMsR0FBRztBQUM1QjtBQUVBLE9BQU8sTUFBTSxXQUFXLE9BQU8sVUFBVSxVQUFVLE9BQU8sVUFBVSxjQUFjO0NBQzlFLE1BQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxhQUFhLHFCQUFxQjtFQUN6RCxRQUFRO0VBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7RUFDOUMsTUFBTSxLQUFLLFVBQVU7R0FBRTtHQUFVO0dBQVU7R0FBTztHQUFVO0VBQVUsQ0FBQztDQUMzRSxDQUFDO0NBQ0QsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFFQSxPQUFPLE1BQU0scUJBQXFCLE9BQU8sVUFBVSxVQUFVLE9BQU8sVUFBVSxXQUFXLFFBQVE7Q0FDN0YsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWEsZ0NBQWdDO0VBQ3BFLFFBQVE7RUFDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtFQUM5QyxNQUFNLEtBQUssVUFBVTtHQUFFO0dBQVU7R0FBVTtHQUFPO0dBQVU7R0FBVztFQUFJLENBQUM7Q0FDaEYsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBRUEsT0FBTyxNQUFNLGVBQWUsWUFBWTtDQUNwQyxNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsYUFBYSxvQkFBb0I7RUFDeEQsUUFBUTtFQUNSLFNBQVMsWUFBWTtDQUN6QixDQUFDO0NBQ0QsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFFQSxPQUFPLE1BQU0saUJBQWlCLE9BQU8sVUFBVTtDQUMzQyxNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsYUFBYSw0QkFBNEI7RUFDaEUsUUFBUTtFQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0VBQzlDLE1BQU0sS0FBSyxVQUFVLEVBQUUsTUFBTSxDQUFDO0NBQ2xDLENBQUM7Q0FDRCxPQUFPLGNBQWMsR0FBRztBQUM1QjtBQUVBLE9BQU8sTUFBTSxnQkFBZ0IsT0FBTyxPQUFPLEtBQUssZ0JBQWdCO0NBQzVELE1BQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxhQUFhLDJCQUEyQjtFQUMvRCxRQUFRO0VBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7RUFDOUMsTUFBTSxLQUFLLFVBQVU7R0FBRTtHQUFPO0dBQUs7RUFBWSxDQUFDO0NBQ3BELENBQUM7Q0FDRCxPQUFPLGNBQWMsR0FBRztBQUM1Qjs7QUFHQSxPQUFPLE1BQU0sZUFBZSxZQUFZLGNBQWMsTUFBTSxVQUFVLEdBQUcsYUFBYSxjQUFjLENBQUM7QUFFckcsT0FBTyxNQUFNLGdCQUFnQixPQUFPLFlBQVk7Q0FDNUMsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsZ0JBQWdCO0VBQ3hELFFBQVE7RUFDUixNQUFNLEtBQUssVUFBVSxPQUFPO0NBQ2hDLENBQUM7Q0FDRCxPQUFPLGNBQWMsR0FBRztBQUM1QjtBQUVBLE9BQU8sTUFBTSxpQkFBaUIsT0FBTyxpQkFBaUIsZ0JBQWdCO0NBQ2xFLE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FBRyxhQUFhLDZCQUE2QjtFQUNyRSxRQUFRO0VBQ1IsTUFBTSxLQUFLLFVBQVU7R0FBRTtHQUFpQjtFQUFZLENBQUM7Q0FDekQsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBRUEsT0FBTyxNQUFNLHFCQUFxQixPQUFPLFNBQVM7Q0FDOUMsTUFBTSxPQUFPLElBQUksU0FBUztDQUMxQixLQUFLLE9BQU8sUUFBUSxJQUFJO0NBQ3hCLE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FBRyxhQUFhLDhCQUE4QjtFQUN0RSxRQUFRO0VBQ1IsTUFBTTtDQUNWLENBQUM7Q0FDRCxPQUFPLGNBQWMsR0FBRztBQUM1QjtBQUVBLE9BQU8sTUFBTSxhQUFhLFlBQVksY0FBYyxNQUFNLFVBQVUsR0FBRyxhQUFhLG9CQUFvQixDQUFDO0FBQ3pHLE9BQU8sTUFBTSwwQkFBMEIsWUFBWSxjQUFjLE1BQU0sVUFBVSxHQUFHLGFBQWEsd0JBQXdCLENBQUM7O0FBRzFILE9BQU8sTUFBTSxlQUFlLFlBQVksY0FBYyxNQUFNLFVBQVUsR0FBRyxhQUFhLDJCQUEyQixDQUFDO0FBQ2xILE9BQU8sTUFBTSxrQkFBa0IsWUFBWSxjQUFjLE1BQU0sVUFBVSxHQUFHLGFBQWEsOEJBQThCLENBQUM7QUFDeEgsT0FBTyxNQUFNLG1CQUFtQixZQUFZLGNBQWMsTUFBTSxVQUFVLEdBQUcsYUFBYSwrQkFBK0IsQ0FBQzs7QUFHMUgsT0FBTyxNQUFNLGFBQWEsWUFBWSxjQUFjLE1BQU0sVUFBVSxHQUFHLGFBQWEsV0FBVyxDQUFDO0FBRWhHLE9BQU8sTUFBTSxjQUFjLE9BQU8sT0FBTyxjQUFjLE1BQU0sVUFBVSxHQUFHLGFBQWEsYUFBYSxJQUFJLENBQUM7QUFFekcsT0FBTyxNQUFNLGFBQWEsT0FBTyxFQUFFLE9BQU8sYUFBYSx3QkFBd0I7Q0FDM0UsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsYUFBYTtFQUNyRCxRQUFRO0VBQ1IsTUFBTSxLQUFLLFVBQVU7R0FBRTtHQUFPO0dBQWE7RUFBa0IsQ0FBQztDQUNsRSxDQUFDO0NBQ0QsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFFQSxPQUFPLE1BQU0sYUFBYSxPQUFPLElBQUksWUFBWTtDQUM3QyxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE1BQU07RUFDM0QsUUFBUTtFQUNSLE1BQU0sS0FBSyxVQUFVLE9BQU87Q0FDaEMsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBRUEsT0FBTyxNQUFNLGFBQWEsT0FBTyxPQUFPO0NBQ3BDLE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FBRyxhQUFhLGFBQWEsTUFBTSxFQUFFLFFBQVEsU0FBUyxDQUFDO0NBQ25GLE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBRUEsT0FBTyxNQUFNLGtCQUFrQixPQUFPLFlBQVk7Q0FDOUMsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEseUJBQXlCO0VBQ2pFLFFBQVE7RUFDUixNQUFNLEtBQUssVUFBVSxFQUFFLFFBQVEsQ0FBQztDQUNwQyxDQUFDO0NBQ0QsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFFQSxPQUFPLE1BQU0sb0JBQW9CLE9BQU8sT0FBTztDQUMzQyxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLEdBQUcsV0FBVyxFQUFFLFFBQVEsT0FBTyxDQUFDO0NBQ3pGLE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBRUEsT0FBTyxNQUFNLHFCQUFxQixPQUFPLElBQUksYUFBYTtDQUN0RCxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLEdBQUcsWUFBWTtFQUNwRSxRQUFRO0VBQ1IsTUFBTSxLQUFLLFVBQVUsUUFBUTtDQUNqQyxDQUFDO0NBQ0QsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFFQSxPQUFPLE1BQU0sZUFBZSxPQUFPLE9BQU8sY0FBYyxNQUFNLFVBQVUsR0FBRyxhQUFhLGFBQWEsR0FBRyxPQUFPLENBQUM7QUFFaEgsT0FBTyxNQUFNLG1CQUFtQixPQUFPLFFBQVEsU0FBUztDQUNwRCxNQUFNLE9BQU8sSUFBSSxTQUFTO0NBQzFCLEtBQUssT0FBTyxRQUFRLElBQUk7Q0FDeEIsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsYUFBYSxPQUFPLFVBQVU7RUFDdEUsUUFBUTtFQUNSLE1BQU07Q0FDVixDQUFDO0NBQ0QsT0FBTyxjQUFjLEdBQUc7QUFDNUI7O0FBR0EsT0FBTyxNQUFNLGVBQWUsT0FBTyxRQUFRLEVBQUUsTUFBTSxVQUFVLFdBQVcsQ0FBQyxNQUFNO0NBQzNFLE1BQU0sU0FBUyxJQUFJLGdCQUFnQjtDQUNuQyxJQUFJLFFBQVEsTUFBTSxPQUFPLElBQUksUUFBUSxJQUFJO0NBQ3pDLElBQUksWUFBWSxNQUFNLE9BQU8sSUFBSSxZQUFZLFFBQVE7Q0FDckQsSUFBSSxVQUFVLFFBQVEsV0FBVyxJQUFJLE9BQU8sSUFBSSxVQUFVLE1BQU07Q0FDaEUsTUFBTSxLQUFLLE9BQU8sU0FBUyxJQUFJLElBQUksT0FBTyxTQUFTLE1BQU07Q0FDekQsT0FBTyxjQUFjLE1BQU0sVUFBVSxHQUFHLGFBQWEsYUFBYSxPQUFPLFlBQVksSUFBSSxDQUFDO0FBQzlGO0FBRUEsT0FBTyxNQUFNLGdCQUFnQixPQUFPLFFBQVEsY0FBYztDQUN0RCxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sYUFBYTtFQUN6RSxRQUFRO0VBQ1IsTUFBTSxLQUFLLFVBQVUsRUFBRSxVQUFVLENBQUM7Q0FDdEMsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBRUEsT0FBTyxNQUFNLGVBQWUsT0FBTyxRQUFRLGNBQWM7Q0FDckQsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsYUFBYSxPQUFPLGFBQWE7RUFDekUsUUFBUTtFQUNSLE1BQU0sS0FBSyxVQUFVLEVBQUUsVUFBVSxDQUFDO0NBQ3RDLENBQUM7Q0FDRCxPQUFPLGNBQWMsR0FBRztBQUM1QjtBQUVBLE9BQU8sTUFBTSxpQkFBaUIsT0FBTyxRQUFRLGVBQWU7Q0FDeEQsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsYUFBYSxPQUFPLGFBQWEsY0FBYyxFQUN2RixRQUFRLFNBQ1osQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBRUEsT0FBTyxNQUFNLHFCQUFxQixPQUFPLFdBQVc7Q0FDaEQsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsYUFBYSxPQUFPLGFBQWEsRUFDekUsUUFBUSxTQUNaLENBQUM7Q0FDRCxPQUFPLGNBQWMsR0FBRztBQUM1QjtBQUVBLE9BQU8sTUFBTSx5QkFBeUIsT0FBTyxRQUFRLFNBQVM7Q0FDMUQsTUFBTSxPQUFPLElBQUksU0FBUztDQUMxQixLQUFLLE9BQU8sUUFBUSxJQUFJO0NBQ3hCLE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FBRyxhQUFhLGFBQWEsT0FBTyw0QkFBNEI7RUFDeEYsUUFBUTtFQUNSLE1BQU07Q0FDVixDQUFDO0NBQ0QsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFFQSxPQUFPLE1BQU0sa0JBQWtCLE9BQU8sUUFBUSxTQUFTO0NBQ25ELE1BQU0sT0FBTyxJQUFJLFNBQVM7Q0FDMUIsS0FBSyxPQUFPLFFBQVEsSUFBSTtDQUN4QixNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sb0JBQW9CO0VBQ2hGLFFBQVE7RUFDUixNQUFNO0NBQ1YsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCOztBQUdBLE9BQU8sTUFBTSx1QkFBdUIsUUFBUSxZQUFZLE1BQU0sZUFBZTtDQUN6RSxPQUFPLElBQUksU0FBUyxZQUFZO0VBQzVCLE1BQU0sUUFBUSxTQUFTO0VBQ3ZCLE1BQU0sT0FBTyxJQUFJLFNBQVM7RUFDMUIsS0FBSyxPQUFPLFFBQVEsSUFBSTtFQUN4QixNQUFNLE1BQU0sSUFBSSxlQUFlO0VBQy9CLElBQUksT0FBTyxlQUFlLFlBQVk7R0FDbEMsSUFBSSxPQUFPLGlCQUFpQixhQUFhLE1BQU07SUFDM0MsSUFBSSxFQUFFLGtCQUFrQixXQUFXLEtBQUssTUFBTyxFQUFFLFNBQVMsRUFBRSxRQUFTLEdBQUcsQ0FBQztHQUM3RSxDQUFDO0VBQ0w7RUFDQSxJQUFJLGVBQWU7R0FDZixJQUFJO0lBQ0EsTUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLFlBQVk7SUFDeEMsUUFBUTtLQUFFLElBQUksSUFBSSxVQUFVLE9BQU8sSUFBSSxTQUFTO0tBQUssUUFBUSxJQUFJO0tBQVEsTUFBTSxNQUFNLFFBQVE7S0FBTSxTQUFTLE1BQU07SUFBUSxDQUFDO0dBQy9ILFFBQVE7SUFDSixRQUFRO0tBQUUsSUFBSTtLQUFPLFFBQVEsSUFBSTtLQUFRLFNBQVM7SUFBdUIsQ0FBQztHQUM5RTtFQUNKO0VBQ0EsSUFBSSxnQkFBZ0IsUUFBUTtHQUFFLElBQUk7R0FBTyxRQUFRO0dBQUcsU0FBUztFQUFnQixDQUFDO0VBQzlFLElBQUksS0FBSyxRQUFRLEdBQUcsYUFBYSxhQUFhLE9BQU8sYUFBYSxXQUFXLGNBQWM7RUFDM0YsSUFBSSxPQUFPLElBQUksaUJBQWlCLGlCQUFpQixVQUFVLE9BQU87RUFDbEUsSUFBSSxLQUFLLElBQUk7Q0FDakIsQ0FBQztBQUNMOztBQUdBLE9BQU8sTUFBTSx1QkFBdUIsUUFBUSxZQUFZLE1BQU0sZUFBZTtDQUN6RSxPQUFPLElBQUksU0FBUyxZQUFZO0VBQzVCLE1BQU0sUUFBUSxTQUFTO0VBQ3ZCLE1BQU0sT0FBTyxJQUFJLFNBQVM7RUFDMUIsS0FBSyxPQUFPLFFBQVEsSUFBSTtFQUN4QixNQUFNLE1BQU0sSUFBSSxlQUFlO0VBQy9CLElBQUksT0FBTyxlQUFlLFlBQVk7R0FDbEMsSUFBSSxPQUFPLGlCQUFpQixhQUFhLE1BQU07SUFDM0MsSUFBSSxFQUFFLGtCQUFrQixXQUFXLEtBQUssTUFBTyxFQUFFLFNBQVMsRUFBRSxRQUFTLEdBQUcsQ0FBQztHQUM3RSxDQUFDO0VBQ0w7RUFDQSxJQUFJLGVBQWU7R0FDZixJQUFJO0lBQ0EsTUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLFlBQVk7SUFDeEMsUUFBUTtLQUFFLElBQUksSUFBSSxVQUFVLE9BQU8sSUFBSSxTQUFTO0tBQUssUUFBUSxJQUFJO0tBQVEsTUFBTSxNQUFNLFFBQVE7S0FBTSxTQUFTLE1BQU07SUFBUSxDQUFDO0dBQy9ILFFBQVE7SUFDSixRQUFRO0tBQUUsSUFBSTtLQUFPLFFBQVEsSUFBSTtLQUFRLFNBQVM7SUFBdUIsQ0FBQztHQUM5RTtFQUNKO0VBQ0EsSUFBSSxnQkFBZ0IsUUFBUTtHQUFFLElBQUk7R0FBTyxRQUFRO0dBQUcsU0FBUztFQUFnQixDQUFDO0VBQzlFLElBQUksS0FBSyxRQUFRLEdBQUcsYUFBYSxhQUFhLE9BQU8sYUFBYSxXQUFXLGNBQWM7RUFDM0YsSUFBSSxPQUFPLElBQUksaUJBQWlCLGlCQUFpQixVQUFVLE9BQU87RUFDbEUsSUFBSSxLQUFLLElBQUk7Q0FDakIsQ0FBQztBQUNMOztBQUdBLE9BQU8sTUFBTSxtQkFBbUIsT0FBTyxRQUFRLEVBQUUsTUFBTSxVQUFVLFdBQVcsQ0FBQyxNQUFNO0NBQy9FLE1BQU0sU0FBUyxJQUFJLGdCQUFnQjtDQUNuQyxJQUFJLFFBQVEsTUFBTSxPQUFPLElBQUksUUFBUSxJQUFJO0NBQ3pDLElBQUksWUFBWSxNQUFNLE9BQU8sSUFBSSxZQUFZLFFBQVE7Q0FDckQsSUFBSSxVQUFVLFFBQVEsV0FBVyxJQUFJLE9BQU8sSUFBSSxVQUFVLE1BQU07Q0FDaEUsTUFBTSxLQUFLLE9BQU8sU0FBUyxJQUFJLElBQUksV0FBVztDQUM5QyxPQUFPLGNBQWMsTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sWUFBWSxJQUFJLENBQUM7QUFDOUY7QUFDQSxPQUFPLE1BQU0sb0JBQW9CLE9BQU8sUUFBUSxlQUFlLGNBQWMsTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sYUFBYSxZQUFZLENBQUM7QUFFM0osT0FBTyxNQUFNLG9CQUFvQixPQUFPLFFBQVEsZUFBZSxjQUFjLE1BQU0sVUFBVSxHQUFHLGFBQWEsYUFBYSxPQUFPLGFBQWEsV0FBVyxRQUFRLENBQUM7QUFFbEssT0FBTyxNQUFNLHNCQUFzQixPQUFPLFFBQVEsZUFBZSxjQUFjLE1BQU0sVUFBVSxHQUFHLGFBQWEsYUFBYSxPQUFPLGFBQWEsV0FBVyxVQUFVLENBQUM7QUFFdEssT0FBTyxNQUFNLHVCQUF1QixPQUFPLFlBQVksYUFBYTtDQUNoRSxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxpQkFBaUIsV0FBVyxVQUFVO0VBQzlFLFFBQVE7RUFDUixNQUFNLEtBQUssVUFBVSxFQUFFLFNBQVMsQ0FBQztDQUNyQyxDQUFDO0NBQ0QsT0FBTyxjQUFjLEdBQUc7QUFDNUI7O0FBR0EsT0FBTyxNQUFNLG9CQUFvQixNQUFNO0NBQ25DLElBQUksQ0FBQyxHQUFHLE9BQU87Q0FDZixNQUFNLFNBQVMsRUFBRSxVQUFVLEVBQUU7Q0FDN0IsTUFBTSxXQUFXLE9BQU8sRUFBRSxRQUFRLEVBQUUsY0FBYyxRQUFRLEVBQUUsQ0FBQyxDQUFDLFlBQVk7O0NBRzFFLElBQUksV0FBVyxLQUFLLFdBQVcsS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLLFNBQVMsU0FBUyxPQUFPLEtBQUssU0FBUyxTQUFTLE1BQU0sS0FBSyxTQUFTLFNBQVMsT0FBTyxHQUFHO0VBQ3JKLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxpQkFBaUI7Q0FDakQ7O0NBR0EsTUFBTSxVQUFVLEVBQUUsV0FBVyxFQUFFLG1CQUFtQixFQUFFLG1CQUFtQixDQUFDO0NBQ3hFLElBQUksTUFBTSxRQUFRLE9BQU8sS0FBSyxRQUFRLFNBQVMsR0FBRztFQUM5QyxNQUFNLGNBQWMsUUFDZixRQUFPLE1BQUssRUFBRSxjQUFjLFFBQVEsRUFBRSxjQUFjLElBQUksQ0FBQyxDQUN6RCxLQUFJLE1BQUssRUFBRSxjQUFjLEVBQUUsY0FBYyxFQUFFLENBQUMsQ0FDNUMsT0FBTyxPQUFPO0VBQ25CLElBQUksWUFBWSxTQUFTLEdBQUc7R0FDeEIsT0FBTyxZQUFZLEtBQUssSUFBSTtFQUNoQztDQUNKO0NBRUEsT0FBTyxFQUFFLGlCQUFpQixFQUFFLGlCQUFpQjtBQUNqRDtBQUNBLE9BQU8sTUFBTSxtQkFBbUI7O0FBR2hDLE9BQU8sTUFBTSxxQkFBcUIsU0FBUztDQUN2QyxJQUFJLFNBQVMsUUFBUSxTQUFTLFdBQVcsT0FBTztDQUNoRCxJQUFJLE1BQU0sT0FBTyxJQUFJOztDQUdyQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0VBQ3hCLE1BQU0sT0FBTyxJQUFJLFFBQVEsbUNBQW1DLE9BQU87RUFDbkUsSUFBSSxTQUFTLEtBQUs7RUFDbEIsTUFBTTtDQUNWOztDQUdBLE1BQU0sSUFBSSxRQUFRLG1DQUFtQyxTQUFTO0NBQzlELE1BQU0sSUFBSSxRQUFRLHVCQUF1QixPQUFPOztDQUdoRCxNQUFNLG1CQUFtQjtFQUNyQixDQUFDLGNBQWMsR0FBRztFQUNsQixDQUFDLFlBQVksR0FBRztFQUNoQixDQUFDLFdBQVcsR0FBRztFQUNmLENBQUMsV0FBVyxHQUFHO0VBQ2YsQ0FBQyxlQUFlLEdBQUc7RUFDbkIsQ0FBQyxlQUFlLEdBQUc7RUFDbkIsQ0FBQyxlQUFlLEdBQUc7RUFDbkIsQ0FBQyxlQUFlLEdBQUc7RUFDbkIsQ0FBQyxZQUFZLEdBQUc7RUFDaEIsQ0FBQyxjQUFjLEdBQUc7RUFDbEIsQ0FBQyxhQUFhLEdBQUc7RUFDakIsQ0FBQyxlQUFlLEdBQUc7RUFDbkIsQ0FBQyxhQUFhLEdBQUc7RUFDakIsQ0FBQyxlQUFlLEdBQUc7RUFDbkIsQ0FBQyxjQUFjLEdBQUc7RUFDbEIsQ0FBQyxhQUFhLEdBQUc7RUFDakIsQ0FBQyxjQUFjLEdBQUc7RUFDbEIsQ0FBQyxjQUFjLEdBQUc7RUFDbEIsQ0FBQyxjQUFjLEdBQUc7RUFDbEIsQ0FBQyxXQUFXLEdBQUc7RUFDZixDQUFDLGNBQWMsR0FBRztFQUNsQixDQUFDLGVBQWUsR0FBRztFQUNuQixDQUFDLGNBQWMsR0FBRztFQUNsQixDQUFDLGNBQWMsR0FBRztFQUNsQixDQUFDLFlBQVksR0FBRztFQUNoQixDQUFDLGFBQWEsR0FBRztFQUNqQixDQUFDLG1CQUFtQixHQUFHO0VBQ3ZCLENBQUMsa0JBQWtCLEdBQUc7RUFDdEIsQ0FBQyx1QkFBdUIsR0FBRztDQUMvQjtDQUVBLEtBQUssTUFBTSxDQUFDLFNBQVMsZ0JBQWdCLGtCQUFrQjtFQUNuRCxNQUFNLElBQUksUUFBUSxTQUFTLFdBQVc7Q0FDMUM7O0NBR0EsTUFBTSxJQUFJLFFBQVEsOERBQThELElBQUk7O0NBR3BGLE1BQU0sSUFBSSxRQUFRLHVCQUF1QixJQUFJO0NBQzdDLE1BQU0sSUFBSSxRQUFRLGdCQUFnQixJQUFJOztDQUd0QyxNQUFNLElBQUksUUFBUSxhQUFhLElBQUk7O0NBR25DLE1BQU0sSUFBSSxRQUFRLGdCQUFnQixFQUFFOztDQUdwQyxNQUFNLElBQUksUUFBUSxZQUFZLEVBQUU7Q0FFaEMsT0FBTyxJQUFJLEtBQUs7QUFDcEI7QUFFQSxPQUFPLE1BQU0sYUFBYSxRQUFRLFNBQVMsT0FBTyxtQkFBbUIsU0FBUztDQUMxRSxNQUFNLFFBQVEsU0FBUztDQUN2QixNQUFNLFNBQVMsSUFBSSxnQkFBZ0I7Q0FDbkMsSUFBSSxRQUFRLE9BQU8sSUFBSSxVQUFVLE1BQU07Q0FDdkMsSUFBSSxxQkFBcUIsV0FBVyxPQUFPLElBQUksb0JBQW9CLGdCQUFnQjtDQUNuRixJQUFJLE9BQU8sT0FBTyxJQUFJLFNBQVMsS0FBSztDQUNwQyxNQUFNLEtBQUssT0FBTyxTQUFTLElBQUksSUFBSSxXQUFXO0NBQzlDLE9BQU8sR0FBRyxhQUFhLGFBQWEsT0FBTyxtQkFBbUI7QUFDbEU7QUFFQSxPQUFPLE1BQU0sc0JBQXNCLE9BQU8sUUFBUSxTQUFTLE9BQU8sbUJBQW1CLFNBQVM7Q0FDMUYsTUFBTSxPQUFPLFVBQVUsTUFBSyxDQUFFLFlBQVk7Q0FDMUMsTUFBTSxTQUFTLElBQUksZ0JBQWdCO0NBQ25DLE9BQU8sSUFBSSxVQUFVLEdBQUc7Q0FDeEIsSUFBSSxxQkFBcUIsV0FBVztFQUNoQyxPQUFPLElBQUksb0JBQW9CLGdCQUFnQjtDQUNuRDtDQUVBLElBQUk7RUFDQSxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sb0JBQW9CLE9BQU8sU0FBUyxHQUFHO0VBRXZHLElBQUksQ0FBQyxJQUFJLElBQUk7R0FDVCxJQUFJLE1BQU07R0FDVixJQUFJLFlBQVk7R0FDaEIsSUFBSTtJQUNBLE1BQU0sTUFBTSxNQUFNLElBQUksS0FBSztJQUMzQixNQUFNLElBQUksV0FBVztJQUNyQixZQUFZLEtBQUssVUFBVSxHQUFHO0dBQ2xDLFFBQVE7SUFDSixJQUFJO0tBQ0EsWUFBWSxNQUFNLElBQUksS0FBSztJQUMvQixRQUFRLENBQUM7R0FDYjtHQUVBLElBQUksUUFBUSxTQUFTLElBQUksV0FBVyxLQUFLO0lBQ3JDLFFBQVEsTUFBTSx3REFBd0QsSUFBSSxRQUFRLFNBQVM7SUFDM0YsTUFBTTtHQUNWO0dBRUEsT0FBTztJQUFFLElBQUk7SUFBTyxTQUFTO0dBQUk7RUFDckM7RUFFQSxNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7RUFDNUIsTUFBTSxNQUFNLE9BQU8sSUFBSSxnQkFBZ0IsSUFBSTtFQUMzQyxNQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7RUFDcEMsRUFBRSxPQUFPO0VBQ1QsTUFBTSxNQUFNLFFBQVEsU0FBUyxTQUFTLFFBQVEsUUFBUSxRQUFRO0VBQzlELEVBQUUsV0FBVyxrQkFBa0IsT0FBTyxHQUFHO0VBQ3pDLFNBQVMsS0FBSyxZQUFZLENBQUM7RUFDM0IsRUFBRSxNQUFNO0VBQ1IsRUFBRSxPQUFPO0VBQ1QsT0FBTyxJQUFJLGdCQUFnQixHQUFHO0VBQzlCLE9BQU8sRUFBRSxJQUFJLEtBQUs7Q0FDdEIsU0FBUyxZQUFZO0VBQ2pCLFFBQVEsTUFBTSxxQ0FBcUMsVUFBVTtFQUM3RCxPQUFPO0dBQ0gsSUFBSTtHQUNKLFNBQVMsUUFBUSxRQUNYLDJIQUNBO0VBQ1Y7Q0FDSjtBQUNKOztBQUdBLE9BQU8sTUFBTSxpQkFBaUIsT0FBTyxRQUFRLEVBQUUsUUFBUSxhQUFhLGFBQWEsV0FBVztDQUN4RixNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sWUFBWTtFQUN4RSxRQUFRO0VBQ1IsTUFBTSxLQUFLLFVBQVU7R0FBRTtHQUFRO0dBQWE7RUFBVyxDQUFDO0NBQzVELENBQUM7Q0FDRCxPQUFPLGNBQWMsR0FBRztBQUM1QjtBQUVBLE9BQU8sTUFBTSxnQkFBZ0IsT0FBTyxXQUFXLGNBQWMsTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sVUFBVSxDQUFDO0FBQzVILE9BQU8sTUFBTSxtQkFBbUIsT0FBTyxXQUFXLGNBQWMsTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sV0FBVyxDQUFDOztBQUdoSSxPQUFPLE1BQU0sdUJBQXVCLFNBQVMsVUFDekMsR0FBRyxhQUFhLHlDQUF5Qzs7QUFHN0QsT0FBTyxNQUFNLG1CQUFtQixPQUFPLFdBQVcsY0FBYyxNQUFNLFVBQVUsR0FBRyxhQUFhLGFBQWEsT0FBTyxXQUFXLENBQUM7OztBQUtoSSxPQUFPLE1BQU0sc0JBQXNCLE9BQU8sYUFBYTtDQUNuRCxNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsYUFBYSxvQkFBb0IsVUFBVTtDQUN0RSxPQUFPLGNBQWMsR0FBRztBQUM1Qjs7QUFHQSxPQUFPLE1BQU0seUJBQXlCLE9BQU8sVUFBVSxFQUFFLE9BQU8sU0FBUyxDQUFDLE1BQU07Q0FDNUUsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsb0JBQW9CLFNBQVMsYUFBYTtFQUNsRixRQUFRO0VBQ1IsTUFBTSxLQUFLLFVBQVU7R0FBRSxPQUFPLFNBQVM7R0FBTSxNQUFNLFFBQVE7RUFBSyxDQUFDO0NBQ3JFLENBQUM7Q0FDRCxPQUFPLGNBQWMsR0FBRztBQUM1Qjs7QUFHQSxPQUFPLE1BQU0sMkJBQTJCLE9BQU8sVUFBVSxZQUFZO0NBQ2pFLE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FBRyxhQUFhLG9CQUFvQixTQUFTLGFBQWE7RUFDbEYsUUFBUTtFQUNSLE1BQU0sS0FBSyxVQUFVLE9BQU87Q0FDaEMsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCOztBQUdBLE9BQU8sTUFBTSwwQkFBMEIsT0FBTyxVQUFVLFlBQVksZUFBZTtDQUMvRSxNQUFNLE1BQU0sYUFDTixHQUFHLGFBQWEsb0JBQW9CLFNBQVMsYUFBYSxXQUFXLFNBQVMsbUJBQW1CLFVBQVUsTUFDM0csR0FBRyxhQUFhLG9CQUFvQixTQUFTLGFBQWE7Q0FDaEUsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHO0NBQy9CLE9BQU8sY0FBYyxHQUFHO0FBQzVCOzs7QUFJQSxPQUFPLE1BQU0sZ0JBQWdCLE9BQU8sVUFBVSxjQUFjO0NBQ3hELE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FBRyxhQUFhLG9CQUFvQixTQUFTLGVBQWU7RUFDcEYsUUFBUTtFQUNSLE1BQU0sS0FBSyxVQUFVLFNBQVM7Q0FDbEMsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCOztBQUdBLE9BQU8sTUFBTSxvQkFBb0IsT0FBTyxXQUFXO0NBQy9DLE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FBRyxhQUFhLGFBQWEsT0FBTyxpQkFBaUI7Q0FDakYsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFFQSxPQUFPLE1BQU0scUJBQXFCLEVBQzlCLHNCQUFzQiwwQkFDMUI7O0FBR0EsT0FBTyxNQUFNLHlCQUF5QixPQUFPLFFBQVEsY0FBYztDQUMvRCxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sNEJBQTRCLG1CQUFtQixTQUFTLEVBQUUsZ0JBQWdCLEVBQ3RJLFFBQVEsT0FDWixDQUFDO0NBQ0QsT0FBTyxjQUFjLEdBQUc7QUFDNUI7O0FBR0EsT0FBTyxNQUFNLG1CQUFtQixPQUFPLFFBQVEsY0FBYztDQUN6RCxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxhQUFhLE9BQU8sNEJBQTRCLG1CQUFtQixTQUFTLEVBQUUsU0FBUyxFQUMvSCxRQUFRLE9BQ1osQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCOzs7QUFJQSxPQUFPLE1BQU0sa0JBQWtCLE9BQU8sVUFBVSxXQUFXLEVBQUUsU0FBUyxxQkFBcUI7Q0FDdkYsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWEsb0JBQW9CLG1CQUFtQixRQUFRLEVBQUUsaUJBQWlCLG1CQUFtQixTQUFTLEVBQUUsZ0JBQWdCO0VBQ3BKLFFBQVE7RUFDUixTQUFTLEVBQ0wsZ0JBQWdCLG1CQUNwQjtFQUNBLE1BQU0sS0FBSyxVQUFVO0dBQUU7R0FBUztFQUFlLENBQUM7Q0FDcEQsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCOzs7QUFJQSxPQUFPLE1BQU0sc0JBQXNCLE9BQU8sWUFBWSxVQUFVLFlBQVk7Q0FDeEUsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsaUJBQWlCLFdBQVcsV0FBVyxTQUFTLFNBQVM7RUFDakcsUUFBUTtFQUNSLE1BQU0sS0FBSyxVQUFVLE9BQU87Q0FDaEMsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCOztBQUdBLE9BQU8sTUFBTSwyQkFBMkIsT0FBTyxZQUFZLGNBQWM7Q0FDckUsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsaUJBQWlCLFdBQVcsVUFBVTtFQUM5RSxRQUFRO0VBQ1IsTUFBTSxLQUFLLFVBQVUsRUFBRSxVQUFVLENBQUM7Q0FDdEMsQ0FBQztDQUNELE9BQU8sY0FBYyxHQUFHO0FBQzVCOztBQUdBLE9BQU8sTUFBTSxvQkFBb0I7O0FBR2pDLE9BQU8sTUFBTSxnQkFBZ0IsWUFBWSxjQUFjLE1BQU0sVUFBVSxHQUFHLGFBQWEsaUJBQWlCLENBQUM7QUFDekcsT0FBTyxNQUFNLHFCQUFxQixPQUFPLE9BQU8sY0FBYyxNQUFNLFVBQVUsR0FBRyxhQUFhLG1CQUFtQixJQUFJLENBQUM7QUFDdEgsT0FBTyxNQUFNLGdCQUFnQixZQUFZLGNBQWMsTUFBTSxVQUFVLEdBQUcsYUFBYSxpQkFBaUIsQ0FBQztBQUN6RyxPQUFPLE1BQU0scUJBQXFCLE9BQU8sT0FBTyxjQUFjLE1BQU0sVUFBVSxHQUFHLGFBQWEsbUJBQW1CLElBQUksQ0FBQztBQUN0SCxPQUFPLE1BQU0sbUJBQW1CLFlBQVksY0FBYyxNQUFNLFVBQVUsR0FBRyxhQUFhLG9CQUFvQixDQUFDO0FBRS9HLE9BQU8sTUFBTSxlQUFlLE9BQU8sT0FBTztDQUN0QyxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxtQkFBbUIsR0FBRyxPQUFPLEVBQUUsUUFBUSxNQUFNLENBQUM7Q0FDMUYsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFDQSxPQUFPLE1BQU0sb0JBQW9CLE9BQU8sT0FBTztDQUMzQyxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxtQkFBbUIsR0FBRyxZQUFZLEVBQUUsUUFBUSxNQUFNLENBQUM7Q0FDL0YsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFDQSxPQUFPLE1BQU0sa0JBQWtCLE9BQU8sT0FBTztDQUN6QyxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxtQkFBbUIsTUFBTSxFQUFFLFFBQVEsU0FBUyxDQUFDO0NBQ3pGLE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBQ0EsT0FBTyxNQUFNLG9CQUFvQixPQUFPLE9BQU87Q0FDM0MsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsbUJBQW1CLEdBQUcsWUFBWSxFQUFFLFFBQVEsT0FBTyxDQUFDO0NBQ2hHLE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBQ0EsT0FBTyxNQUFNLG1CQUFtQixPQUFPLE9BQU87Q0FDMUMsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsbUJBQW1CLEdBQUcsV0FBVyxFQUFFLFFBQVEsT0FBTyxDQUFDO0NBQy9GLE9BQU8sY0FBYyxHQUFHO0FBQzVCO0FBQ0EsT0FBTyxNQUFNLGtCQUFrQixPQUFPLE9BQU87Q0FDekMsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHLGFBQWEsbUJBQW1CLE1BQU0sRUFBRSxRQUFRLFNBQVMsQ0FBQztDQUN6RixPQUFPLGNBQWMsR0FBRztBQUM1QjtBQUNBLE9BQU8sTUFBTSxzQkFBc0IsT0FBTyxPQUFPO0NBQzdDLE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FBRyxhQUFhLHNCQUFzQixNQUFNLEVBQUUsUUFBUSxTQUFTLENBQUM7Q0FDNUYsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFDQSxPQUFPLE1BQU0sZ0NBQWdDLE9BQU8sT0FBTztDQUN2RCxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxzQkFBc0IsR0FBRyxZQUFZLEVBQUUsUUFBUSxPQUFPLENBQUM7Q0FDbkcsT0FBTyxjQUFjLEdBQUc7QUFDNUI7QUFDQSxPQUFPLE1BQU0sK0JBQStCLE9BQU8sT0FBTztDQUN0RCxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBQUcsYUFBYSxzQkFBc0IsR0FBRyxXQUFXLEVBQUUsUUFBUSxPQUFPLENBQUM7Q0FDbEcsT0FBTyxjQUFjLEdBQUc7QUFDNUI7O0FBR0EsT0FBTyxNQUFNLGVBQWUsVUFBVSxhQUFhLFNBQVM7Q0FDeEQsTUFBTSxVQUFVLGFBQWEsZUFBZTtDQUM1QyxNQUFNLGFBQWEsYUFBYSxpQkFBaUI7Q0FDakQsV0FBVyxXQUFXLE9BQU87Q0FDN0IsV0FBVyxXQUFXLE1BQU07Q0FFNUIsSUFBSSxTQUFTLE9BQU87RUFDaEIsUUFBUSxRQUFRLFNBQVMsU0FBUyxLQUFLOztFQUV2QyxNQUFNLFNBQVMsYUFBYSxLQUFLLEtBQUssS0FBSyxLQUFLO0VBQ2hELE1BQU0sWUFBWSxnQkFBZ0IsU0FBUyxNQUFNLHdCQUF3QixTQUFTLGFBQWEsV0FBVztFQUMxRyxJQUFJLE9BQU8sYUFBYSxhQUFhO0dBQ2pDLFNBQVMsU0FBUztFQUN0QjtDQUNKO0NBRUEsSUFBSSxTQUFTLE1BQU07RUFDZixRQUFRLFFBQVEsUUFBUSxLQUFLLFVBQVUsU0FBUyxJQUFJLENBQUM7Q0FDekQ7Q0FFQSxJQUFJLFlBQVk7RUFDWixhQUFhLFFBQVEsY0FBYyxNQUFNO0NBQzdDLE9BQU87RUFDSCxhQUFhLFdBQVcsWUFBWTtDQUN4QztBQUNKO0FBRUEsT0FBTyxNQUFNLHFCQUFxQjtDQUM5QixhQUFhLFdBQVcsT0FBTztDQUMvQixhQUFhLFdBQVcsTUFBTTtDQUM5QixhQUFhLFdBQVcsWUFBWTtDQUNwQyxlQUFlLFdBQVcsT0FBTztDQUNqQyxlQUFlLFdBQVcsTUFBTTtDQUNoQyxJQUFJLE9BQU8sYUFBYSxhQUFhO0VBQ2pDLFNBQVMsU0FBUztFQUNsQixTQUFTLFNBQVM7RUFDbEIsU0FBUyxTQUFTO0NBQ3RCO0FBQ0o7QUFFQSxPQUFPLE1BQU0sd0JBQXdCLENBQUMsQ0FBQyxTQUFTO0FBRWhELE9BQU8sTUFBTSxxQkFBcUI7Q0FDOUIsSUFBSTtFQUNBLE1BQU0sSUFBSSxhQUFhLFFBQVEsTUFBTSxLQUFLLGVBQWUsUUFBUSxNQUFNO0VBQ3ZFLE9BQU8sSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFJLENBQUM7Q0FDaEMsUUFBUTtFQUNKLE9BQU8sQ0FBQztDQUNaO0FBQ0o7QUFFQSxPQUFPLE1BQU0sWUFBWSxNQUFNLFdBQVcsT0FBTztDQUM3QyxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLElBQUksT0FBTyxTQUFTLFVBQVU7RUFDMUIsSUFBSSxPQUFPLFdBQVcsZUFBZSxnQkFBZ0IsTUFBTTtHQUN2RCxJQUFJO0lBQUUsT0FBTyxJQUFJLGdCQUFnQixJQUFJO0dBQUcsUUFBUTtJQUFFLE9BQU87R0FBVTtFQUN2RTtFQUNBLE9BQU87Q0FDWDtDQUNBLElBQUksS0FBSyxXQUFXLE1BQU0sS0FBSyxLQUFLLFdBQVcsT0FBTyxLQUFLLEtBQUssV0FBVyxPQUFPLEdBQUcsT0FBTztDQUM1RixPQUFPLEdBQUcsZUFBZSxLQUFLLFdBQVcsR0FBRyxJQUFJLEtBQUssTUFBTTtBQUMvRCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJhcGlTZXJ2aWNlLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IGVudlVybCA9IGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9CQVNFX1VSTDtcbmNvbnN0IEFQSV9CQVNFX1VSTCA9IChlbnZVcmwgIT09IHVuZGVmaW5lZCAmJiBlbnZVcmwgIT09ICcnKVxuICAgID8gZW52VXJsIFxuICAgIDogKGltcG9ydC5tZXRhLmVudi5ERVYgPyAnJyA6ICdodHRwczovL2FwaS5mb3JtdXAubXkuaWQnKTtcblxuZXhwb3J0IGNvbnN0IGdldFRva2VuID0gKCkgPT4ge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgbG9jYWwgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKTtcbiAgICBpZiAobG9jYWwpIHJldHVybiBsb2NhbDtcbiAgICBjb25zdCBzZXNzaW9uID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKTtcbiAgICBpZiAoc2Vzc2lvbikgcmV0dXJuIHNlc3Npb247XG5cbiAgICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICBjb25zdCBtYXRjaCA9IGRvY3VtZW50LmNvb2tpZS5tYXRjaCgvKD86Xnw7XFxzKilmb3JtdXBfdG9rZW49KFteO10rKS8pO1xuICAgICAgICBpZiAobWF0Y2ggJiYgbWF0Y2hbMV0pIHtcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd0b2tlbicsIG1hdGNoWzFdKTtcbiAgICAgICAgICAgIHJldHVybiBtYXRjaFsxXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn07XG5cbi8vIFVwbG9hZCBnYW1iYXIgdW50dWsgb3BzaSBqYXdhYmFuIHRlcnRlbnR1XG5leHBvcnQgY29uc3QgdXBsb2FkT3B0aW9uSW1hZ2UgPSAoZm9ybUlkLCBxdWVzdGlvbklkLCBvcHRpb25JZCwgZmlsZSwgb25Qcm9ncmVzcykgPT4ge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICBjb25zdCB0b2tlbiA9IGdldFRva2VuKCk7XG4gICAgICAgIGNvbnN0IGZvcm0gPSBuZXcgRm9ybURhdGEoKTtcbiAgICAgICAgZm9ybS5hcHBlbmQoJ2ZpbGUnLCBmaWxlKTtcbiAgICAgICAgY29uc3QgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIGlmICh0eXBlb2Ygb25Qcm9ncmVzcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgeGhyLnVwbG9hZC5hZGRFdmVudExpc3RlbmVyKCdwcm9ncmVzcycsIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGUubGVuZ3RoQ29tcHV0YWJsZSkgb25Qcm9ncmVzcyhNYXRoLnJvdW5kKChlLmxvYWRlZCAvIGUudG90YWwpICogMTAwKSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB4aHIub25sb2FkID0gKCkgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gSlNPTi5wYXJzZSh4aHIucmVzcG9uc2VUZXh0KTtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHsgb2s6IHhoci5zdGF0dXMgPj0gMjAwICYmIHhoci5zdGF0dXMgPCAzMDAsIHN0YXR1czogeGhyLnN0YXR1cywgZGF0YTogZGF0YT8uZGF0YSA/PyBkYXRhLCBtZXNzYWdlOiBkYXRhPy5tZXNzYWdlIH0pO1xuICAgICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSh7IG9rOiBmYWxzZSwgc3RhdHVzOiB4aHIuc3RhdHVzLCBtZXNzYWdlOiAnUmVzcG9uc2UgcGFyc2UgZXJyb3InIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB4aHIub25lcnJvciA9ICgpID0+IHJlc29sdmUoeyBvazogZmFsc2UsIHN0YXR1czogMCwgbWVzc2FnZTogJ05ldHdvcmsgZXJyb3InIH0pO1xuICAgICAgICB4aHIub3BlbignUE9TVCcsIGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9xdWVzdGlvbnMvJHtxdWVzdGlvbklkfS9vcHRpb25zLyR7b3B0aW9uSWR9L3VwbG9hZC1pbWFnZWApO1xuICAgICAgICBpZiAodG9rZW4pIHhoci5zZXRSZXF1ZXN0SGVhZGVyKCdBdXRob3JpemF0aW9uJywgYEJlYXJlciAke3Rva2VufWApO1xuICAgICAgICB4aHIuc2VuZChmb3JtKTtcbiAgICB9KTtcbn07XG5cbmNvbnN0IGF1dGhIZWFkZXJzID0gKCkgPT4ge1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfTtcbiAgICBjb25zdCB0b2tlbiA9IGdldFRva2VuKCk7XG4gICAgaWYgKHRva2VuKSBoZWFkZXJzWydBdXRob3JpemF0aW9uJ10gPSBgQmVhcmVyICR7dG9rZW59YDtcbiAgICByZXR1cm4gaGVhZGVycztcbn07XG5cbmxldCBfcmVmcmVzaEluRmxpZ2h0ID0gbnVsbDtcblxuY29uc3QgX3JlZGlyZWN0VG9Mb2dpbldpdGhSZWFzb24gPSAocmVhc29uKSA9PiB7XG4gICAgY2xlYXJTZXNzaW9uKCk7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSByZXR1cm47XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcGF0aCA9IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSB8fCAnJztcbiAgICAgICAgaWYgKHBhdGguc3RhcnRzV2l0aCgnL2xvZ2luJykpIHJldHVybjtcbiAgICAgICAgY29uc3QgcXVlcnkgPSByZWFzb24gPyBgP3JlYXNvbj0ke2VuY29kZVVSSUNvbXBvbmVudChyZWFzb24pfWAgOiAnJztcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmFzc2lnbihgL2xvZ2luJHtxdWVyeX1gKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgICAgLyogaWdub3JlICovXG4gICAgfVxufTtcblxuY29uc3QgX3BlcmZvcm1SZWZyZXNoTXV0ZXggPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKF9yZWZyZXNoSW5GbGlnaHQpIHJldHVybiBfcmVmcmVzaEluRmxpZ2h0O1xuICAgIF9yZWZyZXNoSW5GbGlnaHQgPSAoYXN5bmMgKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYXV0aC9yZWZyZXNoYCwge1xuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IGF1dGhIZWFkZXJzKCksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHBhcnNlUmVzcG9uc2UocmVzKTtcbiAgICAgICAgICAgIGlmIChyZXN1bHQub2sgJiYgcmVzdWx0LmRhdGE/LnRva2VuKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVtZW1iZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgncmVtZW1iZXJNZScpID09PSAndHJ1ZSc7XG4gICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdVc2VyID0gZ2V0TG9jYWxVc2VyKCk7XG4gICAgICAgICAgICAgICAgc2F2ZVNlc3Npb24oeyB0b2tlbjogcmVzdWx0LmRhdGEudG9rZW4sIHVzZXI6IGV4aXN0aW5nVXNlciB8fCByZXN1bHQuZGF0YS51c2VyIHx8IG51bGwgfSwgcmVtZW1iZXIpO1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3JlZGlyZWN0VG9Mb2dpbldpdGhSZWFzb24oJ3Nlc3Npb25fZXhwaXJlZCcpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIF9yZWRpcmVjdFRvTG9naW5XaXRoUmVhc29uKCdzZXNzaW9uX2V4cGlyZWQnKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIF9yZWZyZXNoSW5GbGlnaHQgPSBudWxsO1xuICAgICAgICB9XG4gICAgfSkoKTtcbiAgICByZXR1cm4gX3JlZnJlc2hJbkZsaWdodDtcbn07XG5cbmV4cG9ydCBjb25zdCBhdXRoRmV0Y2ggPSBhc3luYyAodXJsLCBvcHRpb25zID0ge30pID0+IHtcbiAgICBjb25zdCB0b2tlbiA9IGdldFRva2VuKCk7XG4gICAgY29uc3QgaXNGb3JtRGF0YSA9IG9wdGlvbnMgJiYgb3B0aW9ucy5ib2R5ICYmIHR5cGVvZiBvcHRpb25zLmJvZHkuYXBwZW5kICYmIHR5cGVvZiBvcHRpb25zLmJvZHkuY29uc3RydWN0b3IgPT09ICdmdW5jdGlvbicgJiYgb3B0aW9ucy5ib2R5IGluc3RhbmNlb2YgRm9ybURhdGE7XG4gICAgY29uc3QgYmFzZUhlYWRlcnMgPSB7fTtcbiAgICBpZiAoIWlzRm9ybURhdGEpIGJhc2VIZWFkZXJzWydDb250ZW50LVR5cGUnXSA9ICdhcHBsaWNhdGlvbi9qc29uJztcbiAgICBpZiAodG9rZW4pIGJhc2VIZWFkZXJzWydBdXRob3JpemF0aW9uJ10gPSBgQmVhcmVyICR7dG9rZW59YDtcbiAgICBjb25zdCBoZWFkZXJzID0geyAuLi5iYXNlSGVhZGVycywgLi4uKG9wdGlvbnMuaGVhZGVycyB8fCB7fSkgfTtcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCwgeyAuLi5vcHRpb25zLCBoZWFkZXJzIH0pO1xuICAgIGNvbnN0IGlzQXV0aFVybCA9IHR5cGVvZiB1cmwgPT09ICdzdHJpbmcnICYmIHVybC5pbmNsdWRlcygnL2FwaS9hdXRoLycpO1xuICAgIGlmICh0b2tlbiAmJiByZXMuc3RhdHVzID09PSA0MDEgJiYgIWlzQXV0aFVybCkge1xuICAgICAgICBjb25zdCByZWZyZXNoZWQgPSBhd2FpdCBfcGVyZm9ybVJlZnJlc2hNdXRleCgpO1xuICAgICAgICBpZiAocmVmcmVzaGVkKSB7XG4gICAgICAgICAgICBjb25zdCBuZXdUb2tlbiA9IGdldFRva2VuKCk7XG4gICAgICAgICAgICBjb25zdCByZXRyeUhlYWRlcnMgPSB7IC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pIH07XG4gICAgICAgICAgICBpZiAoIWlzRm9ybURhdGEpIHJldHJ5SGVhZGVyc1snQ29udGVudC1UeXBlJ10gPSAnYXBwbGljYXRpb24vanNvbic7XG4gICAgICAgICAgICBpZiAobmV3VG9rZW4pIHJldHJ5SGVhZGVyc1snQXV0aG9yaXphdGlvbiddID0gYEJlYXJlciAke25ld1Rva2VufWA7XG4gICAgICAgICAgICByZXR1cm4gZmV0Y2godXJsLCB7IC4uLm9wdGlvbnMsIGhlYWRlcnM6IHJldHJ5SGVhZGVycywgYm9keTogb3B0aW9ucy5ib2R5IH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXM7XG59O1xuXG5jb25zdCBwYXJzZVJlc3BvbnNlID0gYXN5bmMgKHJlcykgPT4ge1xuICAgIGxldCBib2R5O1xuICAgIHRyeSB7IGJvZHkgPSBhd2FpdCByZXMuanNvbigpOyB9IGNhdGNoIHsgYm9keSA9IHt9OyB9XG4gICAgY29uc3Qgc2VydmVyRG93biA9IHJlcy5zdGF0dXMgPT09IDUwMiB8fCByZXMuc3RhdHVzID09PSA1MDMgfHwgcmVzLnN0YXR1cyA9PT0gNTA0O1xuICAgIHJldHVybiB7XG4gICAgICAgIG9rOiByZXMub2ssXG4gICAgICAgIHN0YXR1czogYm9keS5zdGF0dXMgPz8gcmVzLnN0YXR1cyxcbiAgICAgICAgbWVzc2FnZTogYm9keS5tZXNzYWdlID8/IChyZXMub2sgPyAnT0snIDogKHNlcnZlckRvd24gPyAnU2VydmVyIHNlZGFuZyB0aWRhayBha3RpZi4gU2lsYWthbiBjb2JhIGxhZ2kgYmViZXJhcGEgc2FhdCBrZW11ZGlhbi4nIDogJ0Vycm9yJykpLFxuICAgICAgICBkYXRhOiBib2R5LmRhdGEgPz8gbnVsbCxcbiAgICB9O1xufTtcblxuLy8g4pSA4pSAIEF1dGggRW5kcG9pbnRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0IGNvbnN0IGxvZ2luID0gYXN5bmMgKGVtYWlsLCBwYXNzd29yZCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2F1dGgvbG9naW5gLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBlbWFpbCwgcGFzc3dvcmQgfSksXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbmV4cG9ydCBjb25zdCByZWdpc3RlciA9IGFzeW5jIChmdWxsbmFtZSwgdXNlcm5hbWUsIGVtYWlsLCBwYXNzd29yZCwgYmlydGhkYXRlKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYXV0aC9yZWdpc3RlcmAsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGZ1bGxuYW1lLCB1c2VybmFtZSwgZW1haWwsIHBhc3N3b3JkLCBiaXJ0aGRhdGUgfSksXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbmV4cG9ydCBjb25zdCB2ZXJpZnlSZWdpc3RyYXRpb24gPSBhc3luYyAoZnVsbG5hbWUsIHVzZXJuYW1lLCBlbWFpbCwgcGFzc3dvcmQsIGJpcnRoZGF0ZSwgb3RwKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYXV0aC92ZXJpZnktcmVnaXN0cmF0aW9uYCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgZnVsbG5hbWUsIHVzZXJuYW1lLCBlbWFpbCwgcGFzc3dvcmQsIGJpcnRoZGF0ZSwgb3RwIH0pLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG5leHBvcnQgY29uc3QgcmVmcmVzaFRva2VuID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2F1dGgvcmVmcmVzaGAsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnM6IGF1dGhIZWFkZXJzKCksXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbmV4cG9ydCBjb25zdCBmb3Jnb3RQYXNzd29yZCA9IGFzeW5jIChlbWFpbCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2F1dGgvZm9yZ290LXBhc3N3b3JkYCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgZW1haWwgfSksXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbmV4cG9ydCBjb25zdCByZXNldFBhc3N3b3JkID0gYXN5bmMgKGVtYWlsLCBvdHAsIG5ld1Bhc3N3b3JkKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYXV0aC9yZXNldC1wYXNzd29yZGAsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGVtYWlsLCBvdHAsIG5ld1Bhc3N3b3JkIH0pLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG4vLyDilIDilIAgVXNlciBQcm9maWxlIEVuZHBvaW50cyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBjb25zdCBnZXRNeVByb2ZpbGUgPSBhc3luYyAoKSA9PiBwYXJzZVJlc3BvbnNlKGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS91c2Vycy9tZWApKTtcblxuZXhwb3J0IGNvbnN0IHVwZGF0ZVByb2ZpbGUgPSBhc3luYyAocGF5bG9hZCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS91c2Vycy9tZWAsIHtcbiAgICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGF5bG9hZCksXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbmV4cG9ydCBjb25zdCBjaGFuZ2VQYXNzd29yZCA9IGFzeW5jIChjdXJyZW50UGFzc3dvcmQsIG5ld1Bhc3N3b3JkKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL3VzZXJzL2NoYW5nZS1wYXNzd29yZGAsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgY3VycmVudFBhc3N3b3JkLCBuZXdQYXNzd29yZCB9KSxcbiAgICB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuZXhwb3J0IGNvbnN0IHVwbG9hZFByb2ZpbGVJbWFnZSA9IGFzeW5jIChmaWxlKSA9PiB7XG4gICAgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgIGZvcm0uYXBwZW5kKCdmaWxlJywgZmlsZSk7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL3VzZXJzL21lL3Byb2ZpbGUtaW1hZ2VgLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBib2R5OiBmb3JtLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0TXlTdGF0cyA9IGFzeW5jICgpID0+IHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL3VzZXJzL21lL3N0YXRzYCkpO1xuZXhwb3J0IGNvbnN0IGdldE15U3VibWl0dGVkUmVzcG9uc2VzID0gYXN5bmMgKCkgPT4gcGFyc2VSZXNwb25zZShhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvdXNlcnMvbWUvcmVzcG9uc2VzYCkpO1xuXG4vLyDilIDilIAgUmVmZXJlbmNlIEVuZHBvaW50cyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBjb25zdCBnZXRGb3JtVHlwZXMgPSBhc3luYyAoKSA9PiBwYXJzZVJlc3BvbnNlKGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9yZWZlcmVuY2VzL2Zvcm0tdHlwZXNgKSk7XG5leHBvcnQgY29uc3QgZ2V0Rm9ybVN0YXR1c2VzID0gYXN5bmMgKCkgPT4gcGFyc2VSZXNwb25zZShhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvcmVmZXJlbmNlcy9mb3JtLXN0YXR1c2VzYCkpO1xuZXhwb3J0IGNvbnN0IGdldFF1ZXN0aW9uVHlwZXMgPSBhc3luYyAoKSA9PiBwYXJzZVJlc3BvbnNlKGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9yZWZlcmVuY2VzL3F1ZXN0aW9uLXR5cGVzYCkpO1xuXG4vLyDilIDilIAgRm9ybSBFbmRwb2ludHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgZ2V0TXlGb3JtcyA9IGFzeW5jICgpID0+IHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zYCkpO1xuXG5leHBvcnQgY29uc3QgZ2V0Rm9ybUJ5SWQgPSBhc3luYyAoaWQpID0+IHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7aWR9YCkpO1xuXG5leHBvcnQgY29uc3QgY3JlYXRlRm9ybSA9IGFzeW5jICh7IHRpdGxlLCBkZXNjcmlwdGlvbiwgZGVzY3JpcHRpb25Gb3JtYXQgfSkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtc2AsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdGl0bGUsIGRlc2NyaXB0aW9uLCBkZXNjcmlwdGlvbkZvcm1hdCB9KSxcbiAgICB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuZXhwb3J0IGNvbnN0IHVwZGF0ZUZvcm0gPSBhc3luYyAoaWQsIHBheWxvYWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvZm9ybXMvJHtpZH1gLCB7XG4gICAgICAgIG1ldGhvZDogJ1BVVCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHBheWxvYWQpLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG5leHBvcnQgY29uc3QgZGVsZXRlRm9ybSA9IGFzeW5jIChpZCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2lkfWAsIHsgbWV0aG9kOiAnREVMRVRFJyB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuZXhwb3J0IGNvbnN0IGJ1bGtEZWxldGVGb3JtcyA9IGFzeW5jIChmb3JtSWRzKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zL2J1bGstZGVsZXRlYCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBmb3JtSWRzIH0pLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG5leHBvcnQgY29uc3QgdG9nZ2xlUHVibGlzaEZvcm0gPSBhc3luYyAoaWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvZm9ybXMvJHtpZH0vcHVibGlzaGAsIHsgbWV0aG9kOiAnUE9TVCcgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbmV4cG9ydCBjb25zdCB1cGRhdGVGb3JtU2V0dGluZ3MgPSBhc3luYyAoaWQsIHNldHRpbmdzKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7aWR9L3NldHRpbmdzYCwge1xuICAgICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHNldHRpbmdzKSxcbiAgICB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuZXhwb3J0IGNvbnN0IGdldEZvcm1TaGFyZSA9IGFzeW5jIChpZCkgPT4gcGFyc2VSZXNwb25zZShhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvZm9ybXMvJHtpZH0vc2hhcmVgKSk7XG5cbmV4cG9ydCBjb25zdCB1cGxvYWRGb3JtQmFubmVyID0gYXN5bmMgKGZvcm1JZCwgZmlsZSkgPT4ge1xuICAgIGNvbnN0IGZvcm0gPSBuZXcgRm9ybURhdGEoKTtcbiAgICBmb3JtLmFwcGVuZCgnZmlsZScsIGZpbGUpO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2Zvcm1JZH0vYmFubmVyYCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgYm9keTogZm9ybSxcbiAgICB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuLy8g4pSA4pSAIFF1ZXN0aW9uIEVuZHBvaW50cyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBjb25zdCBnZXRRdWVzdGlvbnMgPSBhc3luYyAoZm9ybUlkLCB7IHBhZ2UsIHBhZ2VTaXplLCBzZWFyY2ggfSA9IHt9KSA9PiB7XG4gICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgIGlmIChwYWdlICE9IG51bGwpIHBhcmFtcy5zZXQoJ3BhZ2UnLCBwYWdlKTtcbiAgICBpZiAocGFnZVNpemUgIT0gbnVsbCkgcGFyYW1zLnNldCgncGFnZVNpemUnLCBwYWdlU2l6ZSk7XG4gICAgaWYgKHNlYXJjaCAhPSBudWxsICYmIHNlYXJjaCAhPT0gJycpIHBhcmFtcy5zZXQoJ3NlYXJjaCcsIHNlYXJjaCk7XG4gICAgY29uc3QgcXMgPSBwYXJhbXMudG9TdHJpbmcoKSA/IGA/JHtwYXJhbXMudG9TdHJpbmcoKX1gIDogJyc7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9xdWVzdGlvbnMke3FzfWApKTtcbn07XG5cbmV4cG9ydCBjb25zdCBzYXZlUXVlc3Rpb25zID0gYXN5bmMgKGZvcm1JZCwgcXVlc3Rpb25zKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9xdWVzdGlvbnNgLCB7XG4gICAgICAgIG1ldGhvZDogJ1BVVCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgcXVlc3Rpb25zIH0pLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG5leHBvcnQgY29uc3QgYWRkUXVlc3Rpb25zID0gYXN5bmMgKGZvcm1JZCwgcXVlc3Rpb25zKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9xdWVzdGlvbnNgLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHF1ZXN0aW9ucyB9KSxcbiAgICB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuZXhwb3J0IGNvbnN0IGRlbGV0ZVF1ZXN0aW9uID0gYXN5bmMgKGZvcm1JZCwgcXVlc3Rpb25JZCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2Zvcm1JZH0vcXVlc3Rpb25zLyR7cXVlc3Rpb25JZH1gLCB7XG4gICAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbmV4cG9ydCBjb25zdCBkZWxldGVBbGxRdWVzdGlvbnMgPSBhc3luYyAoZm9ybUlkKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9xdWVzdGlvbnNgLCB7XG4gICAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbmV4cG9ydCBjb25zdCBwcmV2aWV3SW1wb3J0UXVlc3Rpb25zID0gYXN5bmMgKGZvcm1JZCwgZmlsZSkgPT4ge1xuICAgIGNvbnN0IGZvcm0gPSBuZXcgRm9ybURhdGEoKTtcbiAgICBmb3JtLmFwcGVuZCgnZmlsZScsIGZpbGUpO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2Zvcm1JZH0vcXVlc3Rpb25zL2ltcG9ydC9wcmV2aWV3YCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgYm9keTogZm9ybSxcbiAgICB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuZXhwb3J0IGNvbnN0IGltcG9ydFF1ZXN0aW9ucyA9IGFzeW5jIChmb3JtSWQsIGZpbGUpID0+IHtcbiAgICBjb25zdCBmb3JtID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgZm9ybS5hcHBlbmQoJ2ZpbGUnLCBmaWxlKTtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvZm9ybXMvJHtmb3JtSWR9L3F1ZXN0aW9ucy9pbXBvcnRgLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBib2R5OiBmb3JtLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG4vLyBCMTogVXNlIFhNTEh0dHBSZXF1ZXN0IGZvciB1cGxvYWQgcHJvZ3Jlc3Mgc3VwcG9ydFxuZXhwb3J0IGNvbnN0IHVwbG9hZFF1ZXN0aW9uSW1hZ2UgPSAoZm9ybUlkLCBxdWVzdGlvbklkLCBmaWxlLCBvblByb2dyZXNzKSA9PiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIGNvbnN0IHRva2VuID0gZ2V0VG9rZW4oKTtcbiAgICAgICAgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgICAgICBmb3JtLmFwcGVuZCgnZmlsZScsIGZpbGUpO1xuICAgICAgICBjb25zdCB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgaWYgKHR5cGVvZiBvblByb2dyZXNzID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICB4aHIudXBsb2FkLmFkZEV2ZW50TGlzdGVuZXIoJ3Byb2dyZXNzJywgKGUpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZS5sZW5ndGhDb21wdXRhYmxlKSBvblByb2dyZXNzKE1hdGgucm91bmQoKGUubG9hZGVkIC8gZS50b3RhbCkgKiAxMDApKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHhoci5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBKU09OLnBhcnNlKHhoci5yZXNwb25zZVRleHQpO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoeyBvazogeGhyLnN0YXR1cyA+PSAyMDAgJiYgeGhyLnN0YXR1cyA8IDMwMCwgc3RhdHVzOiB4aHIuc3RhdHVzLCBkYXRhOiBkYXRhPy5kYXRhID8/IGRhdGEsIG1lc3NhZ2U6IGRhdGE/Lm1lc3NhZ2UgfSk7XG4gICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHsgb2s6IGZhbHNlLCBzdGF0dXM6IHhoci5zdGF0dXMsIG1lc3NhZ2U6ICdSZXNwb25zZSBwYXJzZSBlcnJvcicgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHhoci5vbmVycm9yID0gKCkgPT4gcmVzb2x2ZSh7IG9rOiBmYWxzZSwgc3RhdHVzOiAwLCBtZXNzYWdlOiAnTmV0d29yayBlcnJvcicgfSk7XG4gICAgICAgIHhoci5vcGVuKCdQT1NUJywgYCR7QVBJX0JBU0VfVVJMfS9hcGkvZm9ybXMvJHtmb3JtSWR9L3F1ZXN0aW9ucy8ke3F1ZXN0aW9uSWR9L3VwbG9hZC1pbWFnZWApO1xuICAgICAgICBpZiAodG9rZW4pIHhoci5zZXRSZXF1ZXN0SGVhZGVyKCdBdXRob3JpemF0aW9uJywgYEJlYXJlciAke3Rva2VufWApO1xuICAgICAgICB4aHIuc2VuZChmb3JtKTtcbiAgICB9KTtcbn07XG5cbi8vIEIxOiBVc2UgWE1MSHR0cFJlcXVlc3QgZm9yIHVwbG9hZCBwcm9ncmVzcyBzdXBwb3J0XG5leHBvcnQgY29uc3QgdXBsb2FkUXVlc3Rpb25BdWRpbyA9IChmb3JtSWQsIHF1ZXN0aW9uSWQsIGZpbGUsIG9uUHJvZ3Jlc3MpID0+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgY29uc3QgdG9rZW4gPSBnZXRUb2tlbigpO1xuICAgICAgICBjb25zdCBmb3JtID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgICAgIGZvcm0uYXBwZW5kKCdmaWxlJywgZmlsZSk7XG4gICAgICAgIGNvbnN0IHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICBpZiAodHlwZW9mIG9uUHJvZ3Jlc3MgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHhoci51cGxvYWQuYWRkRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCAoZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChlLmxlbmd0aENvbXB1dGFibGUpIG9uUHJvZ3Jlc3MoTWF0aC5yb3VuZCgoZS5sb2FkZWQgLyBlLnRvdGFsKSAqIDEwMCkpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgeGhyLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UoeGhyLnJlc3BvbnNlVGV4dCk7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSh7IG9rOiB4aHIuc3RhdHVzID49IDIwMCAmJiB4aHIuc3RhdHVzIDwgMzAwLCBzdGF0dXM6IHhoci5zdGF0dXMsIGRhdGE6IGRhdGE/LmRhdGEgPz8gZGF0YSwgbWVzc2FnZTogZGF0YT8ubWVzc2FnZSB9KTtcbiAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgIHJlc29sdmUoeyBvazogZmFsc2UsIHN0YXR1czogeGhyLnN0YXR1cywgbWVzc2FnZTogJ1Jlc3BvbnNlIHBhcnNlIGVycm9yJyB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgeGhyLm9uZXJyb3IgPSAoKSA9PiByZXNvbHZlKHsgb2s6IGZhbHNlLCBzdGF0dXM6IDAsIG1lc3NhZ2U6ICdOZXR3b3JrIGVycm9yJyB9KTtcbiAgICAgICAgeGhyLm9wZW4oJ1BPU1QnLCBgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2Zvcm1JZH0vcXVlc3Rpb25zLyR7cXVlc3Rpb25JZH0vdXBsb2FkLWF1ZGlvYCk7XG4gICAgICAgIGlmICh0b2tlbikgeGhyLnNldFJlcXVlc3RIZWFkZXIoJ0F1dGhvcml6YXRpb24nLCBgQmVhcmVyICR7dG9rZW59YCk7XG4gICAgICAgIHhoci5zZW5kKGZvcm0pO1xuICAgIH0pO1xufTtcblxuLy8g4pSA4pSAIFJlc3BvbnNlIEVuZHBvaW50cyAoT3duZXIpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0IGNvbnN0IGdldEZvcm1SZXNwb25zZXMgPSBhc3luYyAoZm9ybUlkLCB7IHBhZ2UsIHBhZ2VTaXplLCBzZWFyY2ggfSA9IHt9KSA9PiB7XG4gICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgIGlmIChwYWdlICE9IG51bGwpIHBhcmFtcy5zZXQoJ3BhZ2UnLCBwYWdlKTtcbiAgICBpZiAocGFnZVNpemUgIT0gbnVsbCkgcGFyYW1zLnNldCgncGFnZVNpemUnLCBwYWdlU2l6ZSk7XG4gICAgaWYgKHNlYXJjaCAhPSBudWxsICYmIHNlYXJjaCAhPT0gJycpIHBhcmFtcy5zZXQoJ3NlYXJjaCcsIHNlYXJjaCk7XG4gICAgY29uc3QgcXMgPSBwYXJhbXMudG9TdHJpbmcoKSA/IGA/JHtwYXJhbXN9YCA6ICcnO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2Zvcm1JZH0vcmVzcG9uc2VzJHtxc31gKSk7XG59O1xuZXhwb3J0IGNvbnN0IGdldFJlc3BvbnNlRGV0YWlsID0gYXN5bmMgKGZvcm1JZCwgcmVzcG9uc2VJZCkgPT4gcGFyc2VSZXNwb25zZShhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvZm9ybXMvJHtmb3JtSWR9L3Jlc3BvbnNlcy8ke3Jlc3BvbnNlSWR9YCkpO1xuXG5leHBvcnQgY29uc3QgZ2V0UmVzcG9uc2VSZXN1bHQgPSBhc3luYyAoZm9ybUlkLCByZXNwb25zZUlkKSA9PiBwYXJzZVJlc3BvbnNlKGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2Zvcm1JZH0vcmVzcG9uc2VzLyR7cmVzcG9uc2VJZH0vcmVzdWx0YCkpO1xuXG5leHBvcnQgY29uc3QgZ2V0UmVzcG9uc2VBdHRlbXB0cyA9IGFzeW5jIChmb3JtSWQsIHJlc3BvbnNlSWQpID0+IHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9yZXNwb25zZXMvJHtyZXNwb25zZUlkfS9hdHRlbXB0c2ApKTtcblxuZXhwb3J0IGNvbnN0IHVwZGF0ZVJlc3BvbnNlU3RhdHVzID0gYXN5bmMgKHJlc3BvbnNlSWQsIHN0YXR1c0lkKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL3Jlc3BvbnNlcy8ke3Jlc3BvbnNlSWR9L3N0YXR1c2AsIHtcbiAgICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBzdGF0dXNJZCB9KSxcbiAgICB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuLy8gSGVscGVyOiBSZXNvbHZlIGFuc3dlciBrZXkgcGVyIHF1ZXN0aW9uIGFjY29yZGluZyB0byBzcGVjaWZpY2F0aW9uXG5leHBvcnQgY29uc3QgcmVzb2x2ZUFuc3dlcktleSA9IChxKSA9PiB7XG4gICAgaWYgKCFxKSByZXR1cm4gJyc7XG4gICAgY29uc3QgdHlwZUlkID0gcS50eXBlSWQgPz8gcS50eXBlX2lkO1xuICAgIGNvbnN0IHR5cGVOYW1lID0gU3RyaW5nKHEudHlwZSB8fCBxLnF1ZXN0aW9uVHlwZT8udHlwZSB8fCAnJykudG9Mb3dlckNhc2UoKTtcblxuICAgIC8vIFVudHVrIHRpcGUgc29hbCBFc3NheSBhdGF1IEJlbmFyLVNhbGFoOiBhbWJpbCBkYXJpIHEuQ29ycmVjdEFuc3dlclxuICAgIGlmICh0eXBlSWQgPT09IDEgfHwgdHlwZUlkID09PSA1IHx8IHR5cGVOYW1lLmluY2x1ZGVzKCdlc3NheScpIHx8IHR5cGVOYW1lLmluY2x1ZGVzKCdiZW5hcicpIHx8IHR5cGVOYW1lLmluY2x1ZGVzKCd0cnVlJykgfHwgdHlwZU5hbWUuaW5jbHVkZXMoJ2ZhbHNlJykpIHtcbiAgICAgICAgcmV0dXJuIHEuY29ycmVjdEFuc3dlciB8fCBxLkNvcnJlY3RBbnN3ZXIgfHwgJyc7XG4gICAgfVxuXG4gICAgLy8gVW50dWsgdGlwZSBzb2FsIFBHIGF0YXUgQ2hlY2tib3g6IGdhYnVuZ2thbiB0ZWtzIG9wc2kgeWFuZyBJc0NvcnJlY3QgPT0gdHJ1ZSwgZGlwaXNhaCBcIjsgXCJcbiAgICBjb25zdCBvcHRpb25zID0gcS5vcHRpb25zIHx8IHEub3B0aW9uUXVlc3Rpb25zIHx8IHEuT3B0aW9uUXVlc3Rpb25zIHx8IFtdO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG9wdGlvbnMpICYmIG9wdGlvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICBjb25zdCBjb3JyZWN0T3B0cyA9IG9wdGlvbnNcbiAgICAgICAgICAgIC5maWx0ZXIobyA9PiBvLmlzQ29ycmVjdCA9PT0gdHJ1ZSB8fCBvLklzQ29ycmVjdCA9PT0gdHJ1ZSlcbiAgICAgICAgICAgIC5tYXAobyA9PiBvLm9wdGlvblRleHQgfHwgby5PcHRpb25UZXh0IHx8ICcnKVxuICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgaWYgKGNvcnJlY3RPcHRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiBjb3JyZWN0T3B0cy5qb2luKCc7ICcpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHEuY29ycmVjdEFuc3dlciB8fCBxLkNvcnJlY3RBbnN3ZXIgfHwgJyc7XG59O1xuZXhwb3J0IGNvbnN0IFJlc29sdmVBbnN3ZXJLZXkgPSByZXNvbHZlQW5zd2VyS2V5O1xuXG4vLyBIZWxwZXI6IEJlcnNpaGthbiBub3Rhc2kgS2FUZVgvTGFUZVggamFkaSB0ZWtzL3VuaWNvZGUgYmlhc2EgKEE1KVxuZXhwb3J0IGNvbnN0IHN0cmlwTWF0aE5vdGF0aW9uID0gKHRleHQpID0+IHtcbiAgICBpZiAodGV4dCA9PT0gbnVsbCB8fCB0ZXh0ID09PSB1bmRlZmluZWQpIHJldHVybiAnJztcbiAgICBsZXQgc3RyID0gU3RyaW5nKHRleHQpO1xuXG4gICAgLy8gSXRlcmF0aXZlIHJlcGxhY2VtZW50IGZvciBmcmFjdGlvbnM6IFxcZnJhY3thfXtifSAtPiBhL2JcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDU7IGkrKykge1xuICAgICAgICBjb25zdCBuZXh0ID0gc3RyLnJlcGxhY2UoL1xcXFxmcmFjXFx7KFtee31dKylcXH1cXHsoW157fV0rKVxcfS9nLCAnJDEvJDInKTtcbiAgICAgICAgaWYgKG5leHQgPT09IHN0cikgYnJlYWs7XG4gICAgICAgIHN0ciA9IG5leHQ7XG4gICAgfVxuXG4gICAgLy8gU3F1YXJlIHJvb3RzOiBcXHNxcnRbbl17eH0gLT4gbuKImih4KSwgXFxzcXJ0e3h9IC0+IOKImih4KVxuICAgIHN0ciA9IHN0ci5yZXBsYWNlKC9cXFxcc3FydFxcWyhbXlxcXV0rKVxcXVxceyhbXnt9XSspXFx9L2csICckMeKImigkMiknKTtcbiAgICBzdHIgPSBzdHIucmVwbGFjZSgvXFxcXHNxcnRcXHsoW157fV0rKVxcfS9nLCAn4oiaKCQxKScpO1xuXG4gICAgLy8gQ29tbW9uIExhVGVYIG1hdGggc3ltYm9scyB0byB1bmljb2RlXG4gICAgY29uc3QgbWF0aFJlcGxhY2VtZW50cyA9IFtcbiAgICAgICAgWy9cXFxcdGltZXNcXGIvZywgJ8OXJ10sXG4gICAgICAgIFsvXFxcXGRpdlxcYi9nLCAnw7cnXSxcbiAgICAgICAgWy9cXFxccG1cXGIvZywgJ8KxJ10sXG4gICAgICAgIFsvXFxcXG1wXFxiL2csICfiiJMnXSxcbiAgICAgICAgWy9cXFxcbGUocSk/XFxiL2csICfiiaQnXSxcbiAgICAgICAgWy9cXFxcZ2UocSk/XFxiL2csICfiiaUnXSxcbiAgICAgICAgWy9cXFxcbmUocSk/XFxiL2csICfiiaAnXSxcbiAgICAgICAgWy9cXFxcYXBwcm94XFxiL2csICfiiYgnXSxcbiAgICAgICAgWy9cXFxcc2ltXFxiL2csICd+J10sXG4gICAgICAgIFsvXFxcXGluZnR5XFxiL2csICfiiJ4nXSxcbiAgICAgICAgWy9cXFxcY2RvdFxcYi9nLCAnwrcnXSxcbiAgICAgICAgWy9cXFxcYnVsbGV0XFxiL2csICfigKInXSxcbiAgICAgICAgWy9cXFxcY2lyY1xcYi9nLCAnwrAnXSxcbiAgICAgICAgWy9cXFxcZGVncmVlXFxiL2csICfCsCddLFxuICAgICAgICBbL1xcXFxhbHBoYVxcYi9nLCAnzrEnXSxcbiAgICAgICAgWy9cXFxcYmV0YVxcYi9nLCAnzrInXSxcbiAgICAgICAgWy9cXFxcZ2FtbWFcXGIvZywgJ86zJ10sXG4gICAgICAgIFsvXFxcXGRlbHRhXFxiL2csICfOtCddLFxuICAgICAgICBbL1xcXFxEZWx0YVxcYi9nLCAnzpQnXSxcbiAgICAgICAgWy9cXFxccGlcXGIvZywgJ8+AJ10sXG4gICAgICAgIFsvXFxcXHRoZXRhXFxiL2csICfOuCddLFxuICAgICAgICBbL1xcXFxsYW1iZGFcXGIvZywgJ867J10sXG4gICAgICAgIFsvXFxcXHNpZ21hXFxiL2csICfPgyddLFxuICAgICAgICBbL1xcXFxvbWVnYVxcYi9nLCAnz4knXSxcbiAgICAgICAgWy9cXFxcc3VtXFxiL2csICfOoyddLFxuICAgICAgICBbL1xcXFxwcm9kXFxiL2csICfiiI8nXSxcbiAgICAgICAgWy9cXFxccmlnaHRhcnJvd1xcYi9nLCAn4oaSJ10sXG4gICAgICAgIFsvXFxcXGxlZnRhcnJvd1xcYi9nLCAn4oaQJ10sXG4gICAgICAgIFsvXFxcXGxlZnRyaWdodGFycm93XFxiL2csICfihpQnXSxcbiAgICBdO1xuXG4gICAgZm9yIChjb25zdCBbcGF0dGVybiwgcmVwbGFjZW1lbnRdIG9mIG1hdGhSZXBsYWNlbWVudHMpIHtcbiAgICAgICAgc3RyID0gc3RyLnJlcGxhY2UocGF0dGVybiwgcmVwbGFjZW1lbnQpO1xuICAgIH1cblxuICAgIC8vIFRleHQgd3JhcHBlcnM6IFxcdGV4dHsuLi59LCBcXG1hdGhybXsuLi59LCBldGMuXG4gICAgc3RyID0gc3RyLnJlcGxhY2UoL1xcXFwoPzp0ZXh0fG1hdGhybXxtYXRoYmZ8bWF0aGl0fHRleHRiZnx0ZXh0aXQpXFx7KFtee31dKylcXH0vZywgJyQxJyk7XG5cbiAgICAvLyBSZW1vdmUgJCBhbmQgJCQgZGVsaW1pdGVyc1xuICAgIHN0ciA9IHN0ci5yZXBsYWNlKC9cXCRcXCQoW1xcc1xcU10qPylcXCRcXCQvZywgJyQxJyk7XG4gICAgc3RyID0gc3RyLnJlcGxhY2UoL1xcJChbXiRdKylcXCQvZywgJyQxJyk7XG5cbiAgICAvLyBSZW1vdmUgcmVtYWluaW5nIGVzY2FwZWQgYnJhY2VzOiBcXHsgLT4geywgXFx9IC0+IH1cbiAgICBzdHIgPSBzdHIucmVwbGFjZSgvXFxcXChbe31dKS9nLCAnJDEnKTtcblxuICAgIC8vIENsZWFuIHVwIHJlc2lkdWFsIGJhY2tzbGFzaGVzIGJlZm9yZSBhbHBoYSB3b3Jkc1xuICAgIHN0ciA9IHN0ci5yZXBsYWNlKC9cXFxcW2EtekEtWl0rL2csICcnKTtcblxuICAgIC8vIFN0cmlwIGh0bWwgdGFnc1xuICAgIHN0ciA9IHN0ci5yZXBsYWNlKC88W14+XSo+L2csICcnKTtcblxuICAgIHJldHVybiBzdHIudHJpbSgpO1xufTtcblxuZXhwb3J0IGNvbnN0IGV4cG9ydFVybCA9IChmb3JtSWQsIGZvcm1hdCA9ICdjc3YnLCBpbmNsdWRlQW5zd2VyS2V5ID0gdHJ1ZSkgPT4ge1xuICAgIGNvbnN0IHRva2VuID0gZ2V0VG9rZW4oKTtcbiAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XG4gICAgaWYgKGZvcm1hdCkgcGFyYW1zLnNldCgnZm9ybWF0JywgZm9ybWF0KTtcbiAgICBpZiAoaW5jbHVkZUFuc3dlcktleSAhPT0gdW5kZWZpbmVkKSBwYXJhbXMuc2V0KCdpbmNsdWRlQW5zd2VyS2V5JywgaW5jbHVkZUFuc3dlcktleSk7XG4gICAgaWYgKHRva2VuKSBwYXJhbXMuc2V0KCd0b2tlbicsIHRva2VuKTtcbiAgICBjb25zdCBxcyA9IHBhcmFtcy50b1N0cmluZygpID8gYD8ke3BhcmFtc31gIDogJyc7XG4gICAgcmV0dXJuIGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9yZXNwb25zZXMvZXhwb3J0JHtxc31gO1xufTtcblxuZXhwb3J0IGNvbnN0IGV4cG9ydEZvcm1SZXNwb25zZXMgPSBhc3luYyAoZm9ybUlkLCBmb3JtYXQgPSAnY3N2JywgaW5jbHVkZUFuc3dlcktleSA9IHRydWUpID0+IHtcbiAgICBjb25zdCBmbXQgPSAoZm9ybWF0IHx8ICdjc3YnKS50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcbiAgICBwYXJhbXMuc2V0KCdmb3JtYXQnLCBmbXQpO1xuICAgIGlmIChpbmNsdWRlQW5zd2VyS2V5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcGFyYW1zLnNldCgnaW5jbHVkZUFuc3dlcktleScsIGluY2x1ZGVBbnN3ZXJLZXkpO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2Zvcm1JZH0vcmVzcG9uc2VzL2V4cG9ydD8ke3BhcmFtcy50b1N0cmluZygpfWApO1xuXG4gICAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgICAgICBsZXQgbXNnID0gJ0dhZ2FsIG1lbmdla3Nwb3IgZGF0YSByZXNwb25zJztcbiAgICAgICAgICAgIGxldCBlcnJEZXRhaWwgPSAnJztcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgICAgICAgICBtc2cgPSBlcnIubWVzc2FnZSB8fCBtc2c7XG4gICAgICAgICAgICAgICAgZXJyRGV0YWlsID0gSlNPTi5zdHJpbmdpZnkoZXJyKTtcbiAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGVyckRldGFpbCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICAgICAgICAgICAgfSBjYXRjaCB7fVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoZm10ID09PSAncGRmJyAmJiByZXMuc3RhdHVzID09PSA1MDApIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbRXhwb3J0IFBERiA1MDAgRXJyb3JdIFNlcnZlciBmYWlsZWQgZ2VuZXJhdGluZyBQREY6JywgcmVzLnN0YXR1cywgZXJyRGV0YWlsKTtcbiAgICAgICAgICAgICAgICBtc2cgPSAnRXhwb3J0IFBERiBnYWdhbCwga2VtdW5na2luYW4ga2FyZW5hIGtvbnRlbiBtYXRlbWF0aWthIHBhZGEgc29hbC4gQ29iYSBleHBvcnQgQ1NWL0V4Y2VsIHNlbWVudGFyYSwgYXRhdSBodWJ1bmdpIGFkbWluLic7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgbWVzc2FnZTogbXNnIH07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzLmJsb2IoKTtcbiAgICAgICAgY29uc3QgdXJsID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgICAgIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICAgIGEuaHJlZiA9IHVybDtcbiAgICAgICAgY29uc3QgZXh0ID0gZm10ID09PSAneGxzeCcgPyAneGxzeCcgOiBmbXQgPT09ICdwZGYnID8gJ3BkZicgOiAnY3N2JztcbiAgICAgICAgYS5kb3dubG9hZCA9IGByZXNwb25zZXMtZm9ybS0ke2Zvcm1JZH0uJHtleHR9YDtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChhKTtcbiAgICAgICAgYS5jbGljaygpO1xuICAgICAgICBhLnJlbW92ZSgpO1xuICAgICAgICB3aW5kb3cuVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICAgICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIH0gY2F0Y2ggKG5ldHdvcmtFcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignW0V4cG9ydCBSZXNwb25zZXMgTmV0d29yayBFcnJvcl06JywgbmV0d29ya0Vycik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgICBtZXNzYWdlOiBmbXQgPT09ICdwZGYnXG4gICAgICAgICAgICAgICAgPyAnRXhwb3J0IFBERiBnYWdhbCwga2VtdW5na2luYW4ga2FyZW5hIGtvbnRlbiBtYXRlbWF0aWthIHBhZGEgc29hbC4gQ29iYSBleHBvcnQgQ1NWL0V4Y2VsIHNlbWVudGFyYSwgYXRhdSBodWJ1bmdpIGFkbWluLidcbiAgICAgICAgICAgICAgICA6ICdUZXJqYWRpIGtlc2FsYWhhbiBqYXJpbmdhbiBzYWF0IG1lbmdla3Nwb3IgZGF0YSByZXNwb25zLidcbiAgICAgICAgfTtcbiAgICB9XG59O1xuXG4vLyDilIDilIAgRmVlZGJhY2sgRW5kcG9pbnRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0IGNvbnN0IHN1Ym1pdEZlZWRiYWNrID0gYXN5bmMgKGZvcm1JZCwgeyByZWFzb24sIGRlc2NyaXB0aW9uLCByZXNwb25zZUlkID0gbnVsbCB9KSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9mZWVkYmFja2AsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgcmVhc29uLCBkZXNjcmlwdGlvbiwgcmVzcG9uc2VJZCB9KSxcbiAgICB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuZXhwb3J0IGNvbnN0IGdldE15RmVlZGJhY2sgPSBhc3luYyAoZm9ybUlkKSA9PiBwYXJzZVJlc3BvbnNlKGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2Zvcm1JZH0vZmVlZGJhY2tgKSk7XG5leHBvcnQgY29uc3QgZ2V0Rm9ybUZlZWRiYWNrcyA9IGFzeW5jIChmb3JtSWQpID0+IHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9mZWVkYmFja3NgKSk7XG5cbi8vIOKUgOKUgCBUZW1wbGF0ZSBFbmRwb2ludHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgdGVtcGxhdGVEb3dubG9hZFVybCA9IChmb3JtYXQgPSAnY3N2JykgPT5cbiAgICBgJHtBUElfQkFTRV9VUkx9L2FwaS90ZW1wbGF0ZXMvaW1wb3J0LXF1ZXN0aW9ucz9mb3JtYXQ9JHtmb3JtYXR9YDtcblxuLy8g4pSA4pSAIEFuYWx5dGljcyBFbmRwb2ludHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgZ2V0Rm9ybUFuYWx5dGljcyA9IGFzeW5jIChmb3JtSWQpID0+IHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9hbmFseXRpY3NgKSk7XG5cbi8vIOKUgOKUgCBQdWJsaWMgRm9ybSBGbG93IChSZXNwb25kZW4pIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vLyBTdGVwIDE6IEdldCBwdWJsaWMgZm9ybSBtZXRhZGF0YSAmIHJlcXVpcmVtZW50cyAobm8gcXVlc3Rpb25zKVxuZXhwb3J0IGNvbnN0IGdldFB1YmxpY0Zvcm1CeUxpbmsgPSBhc3luYyAoZm9ybUxpbmspID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9wdWJsaWMvZm9ybXMvJHtmb3JtTGlua31gKTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuLy8gU3RlcCAyOiBSZXF1ZXN0IHB1YmxpYyBxdWVzdGlvbnMgYWZ0ZXIgdG9rZW4vbG9naW4gdmFsaWRhdGlvblxuZXhwb3J0IGNvbnN0IGdldFB1YmxpY0Zvcm1RdWVzdGlvbnMgPSBhc3luYyAoZm9ybUxpbmssIHsgdG9rZW4sIG5hbWUgfSA9IHt9KSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL3B1YmxpYy9mb3Jtcy8ke2Zvcm1MaW5rfS9xdWVzdGlvbnNgLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHRva2VuOiB0b2tlbiB8fCBudWxsLCBuYW1lOiBuYW1lIHx8IG51bGwgfSksXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbi8vIFN0ZXAgMzogU3VibWl0IHB1YmxpYyBmb3JtIHJlc3BvbnNlc1xuZXhwb3J0IGNvbnN0IHN1Ym1pdFB1YmxpY0Zvcm1SZXNwb25zZSA9IGFzeW5jIChmb3JtTGluaywgcGF5bG9hZCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9wdWJsaWMvZm9ybXMvJHtmb3JtTGlua30vcmVzcG9uc2VzYCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGF5bG9hZCksXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbi8vIFN0ZXAgNDogR2V0IHB1YmxpYyByZXNwb25zZSByZXN1bHQgKGZvciByZXNwb25kZW50IHZpZXcpXG5leHBvcnQgY29uc3QgZ2V0UHVibGljUmVzcG9uc2VSZXN1bHQgPSBhc3luYyAoZm9ybUxpbmssIHJlc3BvbnNlSWQsIGd1ZXN0VG9rZW4pID0+IHtcbiAgICBjb25zdCB1cmwgPSBndWVzdFRva2VuXG4gICAgICAgID8gYCR7QVBJX0JBU0VfVVJMfS9hcGkvcHVibGljL2Zvcm1zLyR7Zm9ybUxpbmt9L3Jlc3BvbnNlcy8ke3Jlc3BvbnNlSWR9P3Rva2VuPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGd1ZXN0VG9rZW4pfWBcbiAgICAgICAgOiBgJHtBUElfQkFTRV9VUkx9L2FwaS9wdWJsaWMvZm9ybXMvJHtmb3JtTGlua30vcmVzcG9uc2VzLyR7cmVzcG9uc2VJZH1gO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaCh1cmwpO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG4vLyDilIDilIAgRXhhbSBNb25pdG9yaW5nIEVuZHBvaW50cyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIEJhY2tlbmQ6IFtIdHRwUG9zdChcImFwaS9wdWJsaWMvZm9ybXMve2Zvcm1MaW5rfS9leGFtLWV2ZW50c1wiKV0gaW4gRXhhbU1vbml0b3JpbmdDb250cm9sbGVyLmNzXG5leHBvcnQgY29uc3QgcG9zdEV4YW1FdmVudCA9IGFzeW5jIChmb3JtTGluaywgZXZlbnREYXRhKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL3B1YmxpYy9mb3Jtcy8ke2Zvcm1MaW5rfS9leGFtLWV2ZW50c2AsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGV2ZW50RGF0YSksXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbi8vIEJhY2tlbmQ6IFtIdHRwR2V0KFwiYXBpL2Zvcm1zL3tmb3JtSWR9L2V4YW0tbW9uaXRvcmluZ1wiKV0gaW4gRXhhbU1vbml0b3JpbmdDb250cm9sbGVyLmNzXG5leHBvcnQgY29uc3QgZ2V0RXhhbU1vbml0b3JpbmcgPSBhc3luYyAoZm9ybUlkKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2Zvcm1zLyR7Zm9ybUlkfS9leGFtLW1vbml0b3JpbmdgKTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuZXhwb3J0IGNvbnN0IEV4YW1Qcm9jdG9yQWN0aW9ucyA9IHtcbiAgICBGb3JjZVN1Ym1pdEJ5UHJvY3RvcjogJ0ZPUkNFX1NVQk1JVF9CWV9QUk9DVE9SJyxcbn07XG5cbi8vIEJhY2tlbmQ6IFtIdHRwUG9zdChcImFwaS9mb3Jtcy97Zm9ybUlkfS9leGFtLW1vbml0b3Jpbmcvc2Vzc2lvbnMve3Nlc3Npb25JZH0vZm9yY2Utc3VibWl0XCIpXVxuZXhwb3J0IGNvbnN0IGZvcmNlU3VibWl0RXhhbVNlc3Npb24gPSBhc3luYyAoZm9ybUlkLCBzZXNzaW9uSWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvZm9ybXMvJHtmb3JtSWR9L2V4YW0tbW9uaXRvcmluZy9zZXNzaW9ucy8ke2VuY29kZVVSSUNvbXBvbmVudChzZXNzaW9uSWQpfS9mb3JjZS1zdWJtaXRgLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG4vLyBCYWNrZW5kOiBbSHR0cFBvc3QoXCJhcGkvZm9ybXMve2Zvcm1JZH0vZXhhbS1tb25pdG9yaW5nL3Nlc3Npb25zL3tzZXNzaW9uSWR9L3Jlc2V0XCIpXVxuZXhwb3J0IGNvbnN0IHJlc2V0RXhhbVNlc3Npb24gPSBhc3luYyAoZm9ybUlkLCBzZXNzaW9uSWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvZm9ybXMvJHtmb3JtSWR9L2V4YW0tbW9uaXRvcmluZy9zZXNzaW9ucy8ke2VuY29kZVVSSUNvbXBvbmVudChzZXNzaW9uSWQpfS9yZXNldGAsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbi8vIEJhY2tlbmQ6IFtIdHRwUG9zdChcImFwaS9wdWJsaWMvZm9ybXMve2Zvcm1MaW5rfS9leGFtLXNlc3Npb25zL3tzZXNzaW9uSWR9L3N5bmMtYW5zd2Vyc1wiKV1cbi8vIE5vdGU6IHN5bmNFeGFtQW5zd2VycyBpcyB1c2VkIGJ5IGd1ZXN0IChubyBhdXRoIHRva2VuIGV4cGVjdGVkKTsgdGV0YXAgcGFrYWkgZmV0Y2ggbWFudWFsIHRhbnBhIHdyYXBwZXIga2FyZW5hIENvbnRlbnQtVHlwZSBkaS1zZXQgY3VzdG9tIHRhbnBhIGF1dGggaGVhZGVyIGluZmx1ZW5jZS5cbmV4cG9ydCBjb25zdCBzeW5jRXhhbUFuc3dlcnMgPSBhc3luYyAoZm9ybUxpbmssIHNlc3Npb25JZCwgeyBhbnN3ZXJzLCByZXNwb25kZW50TmFtZSB9KSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvcHVibGljL2Zvcm1zLyR7ZW5jb2RlVVJJQ29tcG9uZW50KGZvcm1MaW5rKX0vZXhhbS1zZXNzaW9ucy8ke2VuY29kZVVSSUNvbXBvbmVudChzZXNzaW9uSWQpfS9zeW5jLWFuc3dlcnNgLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9LFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGFuc3dlcnMsIHJlc3BvbmRlbnROYW1lIH0pLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG4vLyDilIDilIAgU2NvcmUgT3ZlcnJpZGUgRW5kcG9pbnRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gQmFja2VuZDogW0h0dHBQdXQoXCJhcGkvcmVzcG9uc2VzL3tpZH0vYW5zd2Vycy97YW5zd2VySWR9L3Njb3JlXCIpXSBpbiBSZXNwb25zZXNDb250cm9sbGVyLmNzXG5leHBvcnQgY29uc3Qgb3ZlcnJpZGVBbnN3ZXJTY29yZSA9IGFzeW5jIChyZXNwb25zZUlkLCBhbnN3ZXJJZCwgcGF5bG9hZCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9yZXNwb25zZXMvJHtyZXNwb25zZUlkfS9hbnN3ZXJzLyR7YW5zd2VySWR9L3Njb3JlYCwge1xuICAgICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKSxcbiAgICB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcblxuLy8gQmFja2VuZDogW0h0dHBQdXQoXCJhcGkvcmVzcG9uc2VzL3tpZH0vc2NvcmVzXCIpXSBpbiBSZXNwb25zZXNDb250cm9sbGVyLmNzXG5leHBvcnQgY29uc3QgYnVsa092ZXJyaWRlQW5zd2VyU2NvcmVzID0gYXN5bmMgKHJlc3BvbnNlSWQsIG92ZXJyaWRlcykgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9yZXNwb25zZXMvJHtyZXNwb25zZUlkfS9zY29yZXNgLCB7XG4gICAgICAgIG1ldGhvZDogJ1BVVCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgb3ZlcnJpZGVzIH0pLFxuICAgIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuXG4vLyBBbGlhcyAoYmFja3dhcmQgY29tcGF0aWJsZSDigJQgYmViZXJhcGEgY2FsbCBzaXRlIGxhbWEgbWVtYWthaSB1cGRhdGVBbnN3ZXJTY29yZSlcbmV4cG9ydCBjb25zdCB1cGRhdGVBbnN3ZXJTY29yZSA9IG92ZXJyaWRlQW5zd2VyU2NvcmU7XG5cbi8vIOKUgOKUgCBBZG1pbiBFbmRwb2ludHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgYWRtaW5HZXRVc2VycyA9IGFzeW5jICgpID0+IHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2FkbWluL3VzZXJzYCkpO1xuZXhwb3J0IGNvbnN0IGFkbWluR2V0VXNlckRldGFpbCA9IGFzeW5jIChpZCkgPT4gcGFyc2VSZXNwb25zZShhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYWRtaW4vdXNlcnMvJHtpZH1gKSk7XG5leHBvcnQgY29uc3QgYWRtaW5HZXRGb3JtcyA9IGFzeW5jICgpID0+IHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2FkbWluL2Zvcm1zYCkpO1xuZXhwb3J0IGNvbnN0IGFkbWluR2V0Rm9ybURldGFpbCA9IGFzeW5jIChpZCkgPT4gcGFyc2VSZXNwb25zZShhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYWRtaW4vZm9ybXMvJHtpZH1gKSk7XG5leHBvcnQgY29uc3QgYWRtaW5HZXRGZWVkYmFjayA9IGFzeW5jICgpID0+IHBhcnNlUmVzcG9uc2UoYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2FkbWluL2ZlZWRiYWNrYCkpO1xuXG5leHBvcnQgY29uc3QgYWRtaW5CYW5Vc2VyID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2FkbWluL3VzZXJzLyR7aWR9L2JhbmAsIHsgbWV0aG9kOiAnUFVUJyB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcbmV4cG9ydCBjb25zdCBhZG1pbkFjdGl2YXRlVXNlciA9IGFzeW5jIChpZCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhGZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9hZG1pbi91c2Vycy8ke2lkfS9hY3RpdmF0ZWAsIHsgbWV0aG9kOiAnUFVUJyB9KTtcbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXMpO1xufTtcbmV4cG9ydCBjb25zdCBhZG1pbkRlbGV0ZVVzZXIgPSBhc3luYyAoaWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYWRtaW4vdXNlcnMvJHtpZH1gLCB7IG1ldGhvZDogJ0RFTEVURScgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5leHBvcnQgY29uc3QgYWRtaW5UYWtlZG93bkZvcm0gPSBhc3luYyAoaWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYWRtaW4vZm9ybXMvJHtpZH0vdGFrZWRvd25gLCB7IG1ldGhvZDogJ1BPU1QnIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuZXhwb3J0IGNvbnN0IGFkbWluUmVzdG9yZUZvcm0gPSBhc3luYyAoaWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYWRtaW4vZm9ybXMvJHtpZH0vcmVzdG9yZWAsIHsgbWV0aG9kOiAnUE9TVCcgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5leHBvcnQgY29uc3QgYWRtaW5EZWxldGVGb3JtID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2FkbWluL2Zvcm1zLyR7aWR9YCwgeyBtZXRob2Q6ICdERUxFVEUnIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuZXhwb3J0IGNvbnN0IGFkbWluRGVsZXRlRmVlZGJhY2sgPSBhc3luYyAoaWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYWRtaW4vZmVlZGJhY2svJHtpZH1gLCB7IG1ldGhvZDogJ0RFTEVURScgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5leHBvcnQgY29uc3QgYWRtaW5UYWtlZG93bkZvcm1Gcm9tRmVlZGJhY2sgPSBhc3luYyAoaWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYWRtaW4vZmVlZGJhY2svJHtpZH0vdGFrZWRvd25gLCB7IG1ldGhvZDogJ1BPU1QnIH0pO1xuICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKHJlcyk7XG59O1xuZXhwb3J0IGNvbnN0IGFkbWluUmVzdG9yZUZvcm1Gcm9tRmVlZGJhY2sgPSBhc3luYyAoaWQpID0+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBhdXRoRmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYWRtaW4vZmVlZGJhY2svJHtpZH0vcmVzdG9yZWAsIHsgbWV0aG9kOiAnUE9TVCcgfSk7XG4gICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UocmVzKTtcbn07XG5cbi8vIOKUgOKUgCBTZXNzaW9uIEhlbHBlcnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3Qgc2F2ZVNlc3Npb24gPSAoYXV0aERhdGEsIHJlbWVtYmVyTWUgPSB0cnVlKSA9PiB7XG4gICAgY29uc3Qgc3RvcmFnZSA9IHJlbWVtYmVyTWUgPyBsb2NhbFN0b3JhZ2UgOiBzZXNzaW9uU3RvcmFnZTtcbiAgICBjb25zdCBhbHRTdG9yYWdlID0gcmVtZW1iZXJNZSA/IHNlc3Npb25TdG9yYWdlIDogbG9jYWxTdG9yYWdlO1xuICAgIGFsdFN0b3JhZ2UucmVtb3ZlSXRlbSgndG9rZW4nKTtcbiAgICBhbHRTdG9yYWdlLnJlbW92ZUl0ZW0oJ3VzZXInKTtcblxuICAgIGlmIChhdXRoRGF0YS50b2tlbikge1xuICAgICAgICBzdG9yYWdlLnNldEl0ZW0oJ3Rva2VuJywgYXV0aERhdGEudG9rZW4pO1xuICAgICAgICAvLyBTZXQgY29va2llIHdpdGggYXBwcm9wcmlhdGUgZXhwaXJhdGlvblxuICAgICAgICBjb25zdCBtYXhBZ2UgPSByZW1lbWJlck1lID8gNjAgKiA2MCAqIDI0ICogMzAgOiAnJzsgLy8gMzAgZGF5cyBvciBzZXNzaW9uXG4gICAgICAgIGNvbnN0IGNvb2tpZVN0ciA9IGBmb3JtdXBfdG9rZW49JHthdXRoRGF0YS50b2tlbn07IHBhdGg9LzsgU2FtZVNpdGU9TGF4JHttYXhBZ2UgPyBgOyBtYXgtYWdlPSR7bWF4QWdlfWAgOiAnJ31gO1xuICAgICAgICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgZG9jdW1lbnQuY29va2llID0gY29va2llU3RyO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGF1dGhEYXRhLnVzZXIpIHtcbiAgICAgICAgc3RvcmFnZS5zZXRJdGVtKCd1c2VyJywgSlNPTi5zdHJpbmdpZnkoYXV0aERhdGEudXNlcikpO1xuICAgIH1cblxuICAgIGlmIChyZW1lbWJlck1lKSB7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdyZW1lbWJlck1lJywgJ3RydWUnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgncmVtZW1iZXJNZScpO1xuICAgIH1cbn07XG5cbmV4cG9ydCBjb25zdCBjbGVhclNlc3Npb24gPSAoKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ3Rva2VuJyk7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ3VzZXInKTtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgncmVtZW1iZXJNZScpO1xuICAgIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oJ3Rva2VuJyk7XG4gICAgc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbSgndXNlcicpO1xuICAgIGlmICh0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGRvY3VtZW50LmNvb2tpZSA9ICdmb3JtdXBfdG9rZW49OyBwYXRoPS87IG1heC1hZ2U9MDsgZXhwaXJlcz1UaHUsIDAxIEphbiAxOTcwIDAwOjAwOjAwIEdNVDsgU2FtZVNpdGU9TGF4JztcbiAgICAgICAgZG9jdW1lbnQuY29va2llID0gJ2Zvcm11cF90b2tlbj07IHBhdGg9LzsgbWF4LWFnZT0wOyBleHBpcmVzPVRodSwgMDEgSmFuIDE5NzAgMDA6MDA6MDAgR01UJztcbiAgICAgICAgZG9jdW1lbnQuY29va2llID0gJ2Zvcm11cF90b2tlbj07IG1heC1hZ2U9MDsgZXhwaXJlcz1UaHUsIDAxIEphbiAxOTcwIDAwOjAwOjAwIEdNVCc7XG4gICAgfVxufTtcblxuZXhwb3J0IGNvbnN0IGlzQXV0aGVudGljYXRlZCA9ICgpID0+ICEhZ2V0VG9rZW4oKTtcblxuZXhwb3J0IGNvbnN0IGdldExvY2FsVXNlciA9ICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCB1ID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3VzZXInKSB8fCBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCd1c2VyJyk7XG4gICAgICAgIHJldHVybiB1ID8gSlNPTi5wYXJzZSh1KSA6IHt9O1xuICAgIH0gY2F0Y2gge1xuICAgICAgICByZXR1cm4ge307XG4gICAgfVxufTtcblxuZXhwb3J0IGNvbnN0IGFzc2V0VXJsID0gKHBhdGgsIGZhbGxiYWNrID0gJycpID0+IHtcbiAgICBpZiAoIXBhdGgpIHJldHVybiBmYWxsYmFjaztcbiAgICBpZiAodHlwZW9mIHBhdGggIT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiBwYXRoIGluc3RhbmNlb2YgRmlsZSkge1xuICAgICAgICAgICAgdHJ5IHsgcmV0dXJuIFVSTC5jcmVhdGVPYmplY3RVUkwocGF0aCk7IH0gY2F0Y2ggeyByZXR1cm4gZmFsbGJhY2s7IH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsbGJhY2s7XG4gICAgfVxuICAgIGlmIChwYXRoLnN0YXJ0c1dpdGgoJ2h0dHAnKSB8fCBwYXRoLnN0YXJ0c1dpdGgoJ2Jsb2I6JykgfHwgcGF0aC5zdGFydHNXaXRoKCdkYXRhOicpKSByZXR1cm4gcGF0aDtcbiAgICByZXR1cm4gYCR7QVBJX0JBU0VfVVJMfSR7cGF0aC5zdGFydHNXaXRoKCcvJykgPyAnJyA6ICcvJ30ke3BhdGh9YDtcbn07XG4iXX0=