import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/MathAndCodeModal.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Calculator, Code, Check, X } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
import VisualFormulaEditor from "/src/components/ui/VisualFormulaEditor.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/MathAndCodeModal.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function MathAndCodeModal({ isOpen, mode, onClose, onInsert }) {
	_s();
	const [mathInput, setMathInput] = useState("\\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}");
	const [mathFormat, setMathFormat] = useState("inline");
	const [codeLanguage, setCodeLanguage] = useState("javascript");
	const [codeInput, setCodeInput] = useState("function calculateSum(a, b) {\n    return a + b;\n}");
	const [visualMode, setVisualMode] = useState(false);
	const openVisualEditor = () => {
		if (mathInput === "\\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}") setMathInput("");
		setVisualMode(true);
	};
	if (!isOpen) return null;
	const handleInsert = () => {
		if (mode === "math") {
			const formula = mathInput.trim();
			if (formula) {
				if (mathFormat === "inline") {
					onInsert(`$${formula}$ `);
				} else {
					onInsert(`<p>$$${formula}$$</p><p><br></p>`);
				}
			}
		} else if (mode === "code") {
			const code = codeInput.trim();
			if (code) {
				onInsert(`<pre><code class="language-${codeLanguage}">${code}</code></pre><p><br></p>`);
			}
		}
		onClose();
	};
	const insertMathSymbol = (sym) => {
		setMathInput((prev) => prev + sym);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 space-y-4 font-sans text-slate-800 dark:text-slate-100 animate-in fade-in zoom-in-95 duration-150",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2.5",
						children: [mode === "math" ? /* @__PURE__ */ _jsxDEV("div", {
							className: "p-2 bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400 rounded-xl",
							children: /* @__PURE__ */ _jsxDEV(Calculator, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 51,
								columnNumber: 33
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 29
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "p-2 bg-slate-900 dark:bg-slate-800 text-teal-400 rounded-xl",
							children: /* @__PURE__ */ _jsxDEV(Code, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 55,
								columnNumber: 33
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-extrabold text-slate-900 dark:text-white",
							children: mode === "math" ? "Sisipkan Rumus Matematika (KaTeX)" : "Sisipkan Blok Kode (Syntax Highlight)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onClose,
						className: "p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg cursor-pointer",
						children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 17
				}, this),
				mode === "math" && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between gap-3 rounded-xl border border-teal-200 bg-teal-50/70 dark:border-teal-800 dark:bg-teal-950/40 px-3 py-2",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs font-extrabold text-teal-800 dark:text-teal-200",
						children: "Bangun rumus tanpa mengetik LaTeX"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 29
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[10px] text-teal-700/80 dark:text-teal-300/80",
						children: "Pilih template matematika atau kimia dengan preview langsung."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 29
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: openVisualEditor,
						className: "shrink-0 px-3 py-2 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-extrabold cursor-pointer",
						children: "Editor Rumus Visual"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 21
				}, this),
				mode === "math" && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300",
									children: "Format Penempatan Rumus:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 83,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setMathFormat("inline"),
										className: `px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${mathFormat === "inline" ? "bg-white dark:bg-slate-700 text-[#00897B] dark:text-teal-400 shadow-2xs" : "text-slate-500 hover:text-slate-700 dark:text-slate-400"}`,
										children: "Inline ($teks samping$)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 85,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setMathFormat("block"),
										className: `px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${mathFormat === "block" ? "bg-white dark:bg-slate-700 text-[#00897B] dark:text-teal-400 shadow-2xs" : "text-slate-500 hover:text-slate-700 dark:text-slate-400"}`,
										children: "Blok Baris ($$tengah$$)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 96,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => visualMode ? setVisualMode(false) : openVisualEditor(),
									className: "px-3 py-1.5 rounded-lg bg-teal-50 text-teal-700 dark:bg-teal-950/50 dark:text-teal-300 text-xs font-bold",
									children: visualMode ? "Mode Manual" : "Editor Rumus Visual"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 108,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 25
						}, this),
						visualMode ? /* @__PURE__ */ _jsxDEV(VisualFormulaEditor, {
							value: mathInput,
							onChange: setMathInput
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 39
						}, this) : /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1.5",
							children: "Simbol Cepat LaTeX:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap gap-1.5",
							children: [
								{
									label: "Pecahan (a/b)",
									sym: "\\frac{a}{b}"
								},
								{
									label: "Akar (√x)",
									sym: "\\sqrt{x}"
								},
								{
									label: "Pangkat (x²)",
									sym: "x^2"
								},
								{
									label: "Subskrip (x₁)",
									sym: "x_1"
								},
								{
									label: "Sigma (∑)",
									sym: "\\sum_{i=1}^{n}"
								},
								{
									label: "Integral (∫)",
									sym: "\\int_{a}^{b}"
								},
								{
									label: "Plus-Minus (±)",
									sym: "\\pm"
								},
								{
									label: "Tak Hingga (∞)",
									sym: "\\infty"
								},
								{
									label: "Pi (π)",
									sym: "\\pi"
								}
							].map((s, i) => /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => insertMathSymbol(s.sym),
								className: "px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-mono font-bold rounded-lg transition-all cursor-pointer",
								children: s.label
							}, i, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 37
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 107
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
							children: "Ekspresi Rumus LaTeX"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("textarea", {
							rows: 3,
							value: mathInput,
							onChange: (e) => setMathInput(e.target.value),
							placeholder: "contoh: \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}",
							className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-[11px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-1",
							children: "Pratinjau Rumus:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-4 min-h-16 flex items-center justify-center",
							children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
								content: `$$${mathInput || "..."}$$`,
								className: "text-sm font-bold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 33
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 21
				}, this),
				mode === "code" && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: "Bahasa Pemrograman:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: codeLanguage,
								onChange: (e) => setCodeLanguage(e.target.value),
								className: "border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] bg-white dark:bg-slate-800",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "javascript",
										children: "JavaScript"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 168,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "python",
										children: "Python"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 169,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "csharp",
										children: "C#"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "html",
										children: "HTML / CSS"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 171,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "sql",
										children: "SQL"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 172,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "java",
										children: "Java"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "cpp",
										children: "C++"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 174,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "json",
										children: "JSON"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 175,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
							children: "Kode Sumber"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("textarea", {
							rows: 5,
							value: codeInput,
							onChange: (e) => setCodeInput(e.target.value),
							placeholder: "Ketik atau tempel potongan kode di sini...",
							className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 181,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-[11px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-1",
							children: "Pratinjau Kode:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "max-h-40 overflow-y-auto rounded-xl",
							children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: `<pre><code class="language-${codeLanguage}">${codeInput || "// ..."}</code></pre>` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 33
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onClose,
						className: "px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl cursor-pointer",
						children: "Batal"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 202,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleInsert,
						className: "px-4 py-2 bg-[#00897B] hover:bg-[#00796B] text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer",
						children: [/* @__PURE__ */ _jsxDEV(Check, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 25
						}, this), " Sisipkan ke Soal"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 209,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 201,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 9
	}, this);
}
_s(MathAndCodeModal, "CnqNd1bFsrKQ3s/PJrMDwISGxFI=");
_c = MathAndCodeModal;
var _c;
$RefreshReg$(_c, "MathAndCodeModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/MathAndCodeModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/MathAndCodeModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/MathAndCodeModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/MathAndCodeModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZLE1BQU0sT0FBTyxTQUFTO0FBQzNDLE9BQU8seUJBQXlCO0FBQ2hDLE9BQU8seUJBQXlCOzs7O0FBRWhDLGVBQWUsU0FBUyxpQkFBaUIsRUFBRSxRQUFRLE1BQU0sU0FBUyxZQUFZOztDQUMxRSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyx1Q0FBdUM7Q0FDbEYsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsUUFBUTtDQUNyRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxZQUFZO0NBQzdELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLHFEQUFxRDtDQUNoRyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0seUJBQXlCO0VBQzNCLElBQUksY0FBYyx5Q0FBeUMsYUFBYSxFQUFFO0VBQzFFLGNBQWMsSUFBSTtDQUN0QjtDQUVBLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsTUFBTSxxQkFBcUI7RUFDdkIsSUFBSSxTQUFTLFFBQVE7R0FDakIsTUFBTSxVQUFVLFVBQVUsS0FBSztHQUMvQixJQUFJLFNBQVM7SUFDVCxJQUFJLGVBQWUsVUFBVTtLQUN6QixTQUFTLElBQUksUUFBUSxHQUFHO0lBQzVCLE9BQU87S0FDSCxTQUFTLFFBQVEsUUFBUSxrQkFBa0I7SUFDL0M7R0FDSjtFQUNKLE9BQU8sSUFBSSxTQUFTLFFBQVE7R0FDeEIsTUFBTSxPQUFPLFVBQVUsS0FBSztHQUM1QixJQUFJLE1BQU07SUFDTixTQUFTLDhCQUE4QixhQUFhLElBQUksS0FBSyx5QkFBeUI7R0FDMUY7RUFDSjtFQUNBLFFBQVE7Q0FDWjtDQUVBLE1BQU0sb0JBQW9CLFFBQVE7RUFDOUIsY0FBYSxTQUFRLE9BQU8sR0FBRztDQUNuQztDQUVBLE9BQ0ksd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDWCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ssU0FBUyxTQUNOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNYLHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7O01BQ3RCOzs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNYLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O01BQ2hCOzs7O2dCQUVULHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNULFNBQVMsU0FBUyxzQ0FBc0M7TUFDekQ7Ozs7Y0FDSDs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQVEsTUFBSztNQUFTLFNBQVM7TUFBUyxXQUFVO2dCQUM5Qyx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztLQUNWOzs7O2FBQ1A7Ozs7OztJQUVKLFNBQVMsVUFDTix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUEwRDtLQUFvQzs7OztlQUMzRyx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBcUQ7S0FBZ0U7Ozs7YUFDakk7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQVEsTUFBSztNQUFTLFNBQVM7TUFBa0IsV0FBVTtnQkFBK0c7S0FFbEs7Ozs7YUFDUDs7Ozs7O0lBSVIsU0FBUyxVQUNOLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNJLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUF1RDtRQUErQjs7Ozs7UUFDdkcsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxVQUFEO1VBQ0ksTUFBSztVQUNMLGVBQWUsY0FBYyxRQUFRO1VBQ3JDLFdBQVcsd0VBQ1AsZUFBZSxXQUNULDRFQUNBO29CQUViO1NBRU87Ozs7bUJBQ1Isd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGNBQWMsT0FBTztVQUNwQyxXQUFXLHdFQUNQLGVBQWUsVUFDVCw0RUFDQTtvQkFFYjtTQUVPOzs7O2lCQUNQOzs7Ozs7UUFDTCx3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLGVBQWUsYUFBYSxjQUFjLEtBQUssSUFBSSxpQkFBaUI7U0FBRyxXQUFVO21CQUE0RyxhQUFhLGdCQUFnQjtRQUE4Qjs7Ozs7T0FDN1E7Ozs7OztNQUVKLGFBQWEsd0JBQUMscUJBQUQ7T0FBcUIsT0FBTztPQUFXLFVBQVU7TUFBZTs7OztpQkFBSSx3QkFBQyxPQUFELGFBQzlFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFvRTtNQUEwQjs7OztnQkFDL0csd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1Y7UUFDRztTQUFFLE9BQU87U0FBaUIsS0FBSztRQUFlO1FBQzlDO1NBQUUsT0FBTztTQUFhLEtBQUs7UUFBWTtRQUN2QztTQUFFLE9BQU87U0FBZ0IsS0FBSztRQUFNO1FBQ3BDO1NBQUUsT0FBTztTQUFpQixLQUFLO1FBQU07UUFDckM7U0FBRSxPQUFPO1NBQWEsS0FBSztRQUFrQjtRQUM3QztTQUFFLE9BQU87U0FBZ0IsS0FBSztRQUFnQjtRQUM5QztTQUFFLE9BQU87U0FBa0IsS0FBSztRQUFPO1FBQ3ZDO1NBQUUsT0FBTztTQUFrQixLQUFLO1FBQVU7UUFDMUM7U0FBRSxPQUFPO1NBQVUsS0FBSztRQUFPO09BQ25DLENBQUMsQ0FBQyxLQUFLLEdBQUcsTUFDTix3QkFBQyxVQUFEO1FBRUksTUFBSztRQUNMLGVBQWUsaUJBQWlCLEVBQUUsR0FBRztRQUNyQyxXQUFVO2tCQUVULEVBQUU7T0FDQyxHQU5DOzs7O2NBTUQsQ0FDWDtNQUNBOzs7O2NBQ0o7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFrRTtNQUEyQjs7OztnQkFDOUcsd0JBQUMsWUFBRDtPQUNJLE1BQU07T0FDTixPQUFPO09BQ1AsV0FBVSxNQUFLLGFBQWEsRUFBRSxPQUFPLEtBQUs7T0FDMUMsYUFBWTtPQUNaLFdBQVU7TUFDYjs7OztjQUNBOzs7OztNQUdMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBb0c7TUFBdUI7Ozs7Z0JBQzVJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNYLHdCQUFDLHFCQUFEO1FBQXFCLFNBQVMsS0FBSyxhQUFhLE1BQU07UUFBSyxXQUFVO09BQXFCOzs7OztNQUN6Rjs7OztjQUNKOzs7OztLQUNKOzs7Ozs7SUFJUixTQUFTLFVBQ04sd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXVEO09BQTBCOzs7O2lCQUNsRyx3QkFBQyxVQUFEO1FBQ0ksT0FBTztRQUNQLFdBQVUsTUFBSyxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7UUFDN0MsV0FBVTtrQkFIZDtTQUtJLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFhO1NBQWtCOzs7OztTQUM3Qyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBUztTQUFjOzs7OztTQUNyQyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBUztTQUFVOzs7OztTQUNqQyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBTztTQUFrQjs7Ozs7U0FDdkMsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQU07U0FBVzs7Ozs7U0FDL0Isd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQU87U0FBWTs7Ozs7U0FDakMsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQU07U0FBVzs7Ozs7U0FDL0Isd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQU87U0FBWTs7Ozs7UUFDN0I7Ozs7O2VBQ1A7Ozs7OztNQUVMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0U7TUFBa0I7Ozs7Z0JBQ3JHLHdCQUFDLFlBQUQ7T0FDSSxNQUFNO09BQ04sT0FBTztPQUNQLFdBQVUsTUFBSyxhQUFhLEVBQUUsT0FBTyxLQUFLO09BQzFDLGFBQVk7T0FDWixXQUFVO01BQ2I7Ozs7Y0FDQTs7Ozs7TUFHTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQW9HO01BQXNCOzs7O2dCQUMzSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCx3QkFBQyxxQkFBRCxFQUFxQixTQUFTLDhCQUE4QixhQUFhLElBQUksYUFBYSxTQUFTLGVBQWlCOzs7OztNQUNuSDs7OztjQUNKOzs7OztLQUNKOzs7Ozs7SUFJVCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsVUFBRDtNQUNJLE1BQUs7TUFDTCxTQUFTO01BQ1QsV0FBVTtnQkFDYjtLQUVPOzs7O2VBQ1Isd0JBQUMsVUFBRDtNQUNJLE1BQUs7TUFDTCxTQUFTO01BQ1QsV0FBVTtnQkFIZCxDQUtJLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7Z0JBQUMsbUJBQ2Y7Ozs7O2FBQ1A7Ozs7OztHQUVKOzs7Ozs7Q0FDSjs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJNYXRoQW5kQ29kZU1vZGFsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IENhbGN1bGF0b3IsIENvZGUsIENoZWNrLCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBSaWNoQ29udGVudFJlbmRlcmVyIGZyb20gJy4uLy4uL3V0aWxzL1JpY2hDb250ZW50UmVuZGVyZXInO1xuaW1wb3J0IFZpc3VhbEZvcm11bGFFZGl0b3IgZnJvbSAnLi9WaXN1YWxGb3JtdWxhRWRpdG9yJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWF0aEFuZENvZGVNb2RhbCh7IGlzT3BlbiwgbW9kZSwgb25DbG9zZSwgb25JbnNlcnQgfSkge1xuICAgIGNvbnN0IFttYXRoSW5wdXQsIHNldE1hdGhJbnB1dF0gPSB1c2VTdGF0ZSgnXFxcXGZyYWN7LWIgXFxcXHBtIFxcXFxzcXJ0e2JeMiAtIDRhY319ezJhfScpO1xuICAgIGNvbnN0IFttYXRoRm9ybWF0LCBzZXRNYXRoRm9ybWF0XSA9IHVzZVN0YXRlKCdpbmxpbmUnKTsgLy8gJ2lubGluZScgb3IgJ2Jsb2NrJ1xuICAgIGNvbnN0IFtjb2RlTGFuZ3VhZ2UsIHNldENvZGVMYW5ndWFnZV0gPSB1c2VTdGF0ZSgnamF2YXNjcmlwdCcpO1xuICAgIGNvbnN0IFtjb2RlSW5wdXQsIHNldENvZGVJbnB1dF0gPSB1c2VTdGF0ZSgnZnVuY3Rpb24gY2FsY3VsYXRlU3VtKGEsIGIpIHtcXG4gICAgcmV0dXJuIGEgKyBiO1xcbn0nKTtcbiAgICBjb25zdCBbdmlzdWFsTW9kZSwgc2V0VmlzdWFsTW9kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3Qgb3BlblZpc3VhbEVkaXRvciA9ICgpID0+IHtcbiAgICAgICAgaWYgKG1hdGhJbnB1dCA9PT0gJ1xcXFxmcmFjey1iIFxcXFxwbSBcXFxcc3FydHtiXjIgLSA0YWN9fXsyYX0nKSBzZXRNYXRoSW5wdXQoJycpO1xuICAgICAgICBzZXRWaXN1YWxNb2RlKHRydWUpO1xuICAgIH07XG5cbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBoYW5kbGVJbnNlcnQgPSAoKSA9PiB7XG4gICAgICAgIGlmIChtb2RlID09PSAnbWF0aCcpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm11bGEgPSBtYXRoSW5wdXQudHJpbSgpO1xuICAgICAgICAgICAgaWYgKGZvcm11bGEpIHtcbiAgICAgICAgICAgICAgICBpZiAobWF0aEZvcm1hdCA9PT0gJ2lubGluZScpIHtcbiAgICAgICAgICAgICAgICAgICAgb25JbnNlcnQoYCQke2Zvcm11bGF9JCBgKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBvbkluc2VydChgPHA+JCQke2Zvcm11bGF9JCQ8L3A+PHA+PGJyPjwvcD5gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAobW9kZSA9PT0gJ2NvZGUnKSB7XG4gICAgICAgICAgICBjb25zdCBjb2RlID0gY29kZUlucHV0LnRyaW0oKTtcbiAgICAgICAgICAgIGlmIChjb2RlKSB7XG4gICAgICAgICAgICAgICAgb25JbnNlcnQoYDxwcmU+PGNvZGUgY2xhc3M9XCJsYW5ndWFnZS0ke2NvZGVMYW5ndWFnZX1cIj4ke2NvZGV9PC9jb2RlPjwvcHJlPjxwPjxicj48L3A+YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgb25DbG9zZSgpO1xuICAgIH07XG5cbiAgICBjb25zdCBpbnNlcnRNYXRoU3ltYm9sID0gKHN5bSkgPT4ge1xuICAgICAgICBzZXRNYXRoSW5wdXQocHJldiA9PiBwcmV2ICsgc3ltKTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci14cyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy0yeGwgbWF4LXctbGcgdy1mdWxsIG1heC1oLVs5MHZoXSBvdmVyZmxvdy15LWF1dG8gcC02IHNwYWNlLXktNCBmb250LXNhbnMgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0xNTBcIj5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ21hdGgnID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FsY3VsYXRvciBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctc2xhdGUtOTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtdGVhbC00MDAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29kZSBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ21hdGgnID8gJ1Npc2lwa2FuIFJ1bXVzIE1hdGVtYXRpa2EgKEthVGVYKScgOiAnU2lzaXBrYW4gQmxvayBLb2RlIChTeW50YXggSGlnaGxpZ2h0KSd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25DbG9zZX0gY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAge21vZGUgPT09ICdtYXRoJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBiZy10ZWFsLTUwLzcwIGRhcms6Ym9yZGVyLXRlYWwtODAwIGRhcms6YmctdGVhbC05NTAvNDAgcHgtMyBweS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdGV4dC10ZWFsLTgwMCBkYXJrOnRleHQtdGVhbC0yMDBcIj5CYW5ndW4gcnVtdXMgdGFucGEgbWVuZ2V0aWsgTGFUZVg8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC10ZWFsLTcwMC84MCBkYXJrOnRleHQtdGVhbC0zMDAvODBcIj5QaWxpaCB0ZW1wbGF0ZSBtYXRlbWF0aWthIGF0YXUga2ltaWEgZGVuZ2FuIHByZXZpZXcgbGFuZ3N1bmcuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtvcGVuVmlzdWFsRWRpdG9yfSBjbGFzc05hbWU9XCJzaHJpbmstMCBweC0zIHB5LTIgcm91bmRlZC1sZyBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1leHRyYWJvbGQgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0b3IgUnVtdXMgVmlzdWFsXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBNb2RlOiBNQVRIICovfVxuICAgICAgICAgICAgICAgIHttb2RlID09PSAnbWF0aCcgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPkZvcm1hdCBQZW5lbXBhdGFuIFJ1bXVzOjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcC0xIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNYXRoRm9ybWF0KCdpbmxpbmUnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF0aEZvcm1hdCA9PT0gJ2lubGluZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgZGFyazpiZy1zbGF0ZS03MDAgdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwIHNoYWRvdy0yeHMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW5saW5lICgkdGVrcyBzYW1waW5nJClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TWF0aEZvcm1hdCgnYmxvY2snKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF0aEZvcm1hdCA9PT0gJ2Jsb2NrJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTcwMCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgc2hhZG93LTJ4cydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCbG9rIEJhcmlzICgkJHRlbmdhaCQkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB2aXN1YWxNb2RlID8gc2V0VmlzdWFsTW9kZShmYWxzZSkgOiBvcGVuVmlzdWFsRWRpdG9yKCl9IGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHJvdW5kZWQtbGcgYmctdGVhbC01MCB0ZXh0LXRlYWwtNzAwIGRhcms6YmctdGVhbC05NTAvNTAgZGFyazp0ZXh0LXRlYWwtMzAwIHRleHQteHMgZm9udC1ib2xkXCI+e3Zpc3VhbE1vZGUgPyAnTW9kZSBNYW51YWwnIDogJ0VkaXRvciBSdW11cyBWaXN1YWwnfTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt2aXN1YWxNb2RlID8gPFZpc3VhbEZvcm11bGFFZGl0b3IgdmFsdWU9e21hdGhJbnB1dH0gb25DaGFuZ2U9e3NldE1hdGhJbnB1dH0gLz4gOiA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJsb2NrIG1iLTEuNVwiPlNpbWJvbCBDZXBhdCBMYVRlWDo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogJ1BlY2FoYW4gKGEvYiknLCBzeW06ICdcXFxcZnJhY3thfXtifScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdBa2FyICjiiJp4KScsIHN5bTogJ1xcXFxzcXJ0e3h9JyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogJ1BhbmdrYXQgKHjCsiknLCBzeW06ICd4XjInIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnU3Vic2tyaXAgKHjigoEpJywgc3ltOiAneF8xJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogJ1NpZ21hICjiiJEpJywgc3ltOiAnXFxcXHN1bV97aT0xfV57bn0nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnSW50ZWdyYWwgKOKIqyknLCBzeW06ICdcXFxcaW50X3thfV57Yn0nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnUGx1cy1NaW51cyAowrEpJywgc3ltOiAnXFxcXHBtJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogJ1RhayBIaW5nZ2EgKOKIniknLCBzeW06ICdcXFxcaW5mdHknIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnUGkgKM+AKScsIHN5bTogJ1xcXFxwaScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXS5tYXAoKHMsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaW5zZXJ0TWF0aFN5bWJvbChzLnN5bSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHRleHQtWzExcHhdIGZvbnQtbW9ubyBmb250LWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3MubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj59XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPkVrc3ByZXNpIFJ1bXVzIExhVGVYPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21hdGhJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0TWF0aElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJjb250b2g6IFxcZnJhY3stYiBcXHBtIFxcc3FydHtiXjIgLSA0YWN9fXsyYX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIGZvbnQtbW9ubyBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogTGl2ZSBLYVRlWCBQcmV2aWV3ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2sgbWItMVwiPlByYXRpbmphdSBSdW11czo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC00IG1pbi1oLTE2IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e2AkJCR7bWF0aElucHV0IHx8ICcuLi4nfSQkYH0gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7LyogTW9kZTogQ09ERSAqL31cbiAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ2NvZGUnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5CYWhhc2EgUGVtcm9ncmFtYW46PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb2RlTGFuZ3VhZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldENvZGVMYW5ndWFnZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiamF2YXNjcmlwdFwiPkphdmFTY3JpcHQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInB5dGhvblwiPlB5dGhvbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY3NoYXJwXCI+QyM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImh0bWxcIj5IVE1MIC8gQ1NTPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJzcWxcIj5TUUw8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImphdmFcIj5KYXZhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjcHBcIj5DKys8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImpzb25cIj5KU09OPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBibG9jayBtYi0xXCI+S29kZSBTdW1iZXI8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXs1fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29kZUlucHV0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRDb2RlSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIktldGlrIGF0YXUgdGVtcGVsIHBvdG9uZ2FuIGtvZGUgZGkgc2luaS4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zLjUgcHktMi41IHRleHQteHMgZm9udC1tb25vIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBMaXZlIENvZGUgUHJldmlldyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJsb2NrIG1iLTFcIj5QcmF0aW5qYXUgS29kZTo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtNDAgb3ZlcmZsb3cteS1hdXRvIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17YDxwcmU+PGNvZGUgY2xhc3M9XCJsYW5ndWFnZS0ke2NvZGVMYW5ndWFnZX1cIj4ke2NvZGVJbnB1dCB8fCAnLy8gLi4uJ308L2NvZGU+PC9wcmU+YH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgey8qIEFjdGlvbnMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgQmF0YWxcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlSW5zZXJ0fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLVsjMDA4OTdCXSBob3ZlcjpiZy1bIzAwNzk2Ql0gdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHNoYWRvdy14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrIHNpemU9ezE0fSAvPiBTaXNpcGthbiBrZSBTb2FsXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==