import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/BlockQuestionEditor.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Code, Calculator, Plus, Trash2, ChevronUp, ChevronDown, Type, Sparkles, Bold, Italic, Underline, Strikethrough, AlignLeft, AlignCenter, AlignRight, AlignJustify, List, ListOrdered, Quote, Link as LinkIcon, RemoveFormatting, Palette, Highlighter } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
import VisualFormulaEditor from "/src/components/ui/VisualFormulaEditor.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/BlockQuestionEditor.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const TEXT_COLORS = [
	{
		name: "Default",
		value: "inherit",
		class: "bg-slate-800 dark:bg-slate-200"
	},
	{
		name: "Hitam",
		value: "#1e293b",
		class: "bg-slate-800"
	},
	{
		name: "Merah",
		value: "#ef4444",
		class: "bg-red-500"
	},
	{
		name: "Hijau",
		value: "#10b981",
		class: "bg-emerald-500"
	},
	{
		name: "Teal",
		value: "#00897b",
		class: "bg-[#00897b]"
	},
	{
		name: "Biru",
		value: "#3b82f6",
		class: "bg-blue-500"
	},
	{
		name: "Ungu",
		value: "#8b5cf6",
		class: "bg-purple-500"
	},
	{
		name: "Oranye",
		value: "#f97316",
		class: "bg-orange-500"
	}
];
const HIGHLIGHT_COLORS = [
	{
		name: "None",
		value: "transparent",
		class: "bg-transparent border border-slate-300"
	},
	{
		name: "Kuning",
		value: "#fef08a",
		class: "bg-yellow-200"
	},
	{
		name: "Hijau",
		value: "#bbf7d0",
		class: "bg-green-200"
	},
	{
		name: "Biru",
		value: "#bfdbfe",
		class: "bg-blue-200"
	},
	{
		name: "Pink",
		value: "#fbcfe8",
		class: "bg-pink-200"
	},
	{
		name: "Oranye",
		value: "#fed7aa",
		class: "bg-orange-200"
	},
	{
		name: "Ungu",
		value: "#e9d5ff",
		class: "bg-purple-200"
	}
];
/**
* Parse an HTML or Markdown string into structured content blocks
*/
function parseStringToBlocks(rawStr) {
	if (!rawStr || typeof rawStr !== "string" || !rawStr.trim()) {
		return [{
			id: `b_${Date.now()}_0`,
			type: "text",
			content: ""
		}];
	}
	const blocks = [];
	const text = rawStr.trim();
	// Combined regex for code blocks, standalone math blocks
	const combinedRegex = /<pre><code(?: class="language-([a-zA-Z0-9_#-]+)")?>([\s\S]*?)<\/code><\/pre>|```([a-zA-Z0-9_#-]*)[ \t\r\n]*([\s\S]*?)```|<p>\$\$([\s\S]*?)\$\$<\/p>|\$\$([\s\S]+?)\$\$/gi;
	let lastIndex = 0;
	let match;
	while ((match = combinedRegex.exec(text)) !== null) {
		if (match.index > lastIndex) {
			const beforeText = text.substring(lastIndex, match.index).trim();
			if (beforeText) {
				blocks.push({
					id: `b_${Date.now()}_${blocks.length}`,
					type: "text",
					content: beforeText
				});
			}
		}
		if (match[0].startsWith("<pre") || match[0].startsWith("```")) {
			const lang = match[1] || match[3] || "javascript";
			const code = (match[2] || match[4] || "").trim();
			blocks.push({
				id: `b_${Date.now()}_${blocks.length}`,
				type: "code",
				language: lang,
				content: code
			});
		} else {
			const formula = (match[5] || match[6] || "").trim();
			blocks.push({
				id: `b_${Date.now()}_${blocks.length}`,
				type: "math",
				content: formula
			});
		}
		lastIndex = match.index + match[0].length;
	}
	if (lastIndex < text.length) {
		const remaining = text.substring(lastIndex).trim();
		if (remaining) {
			blocks.push({
				id: `b_${Date.now()}_${blocks.length}`,
				type: "text",
				content: remaining
			});
		}
	}
	return blocks.length > 0 ? blocks : [{
		id: `b_${Date.now()}_0`,
		type: "text",
		content: rawStr
	}];
}
/**
* Serialize structured blocks back to standard HTML string
*/
function serializeBlocksToString(blocks) {
	if (!blocks || blocks.length === 0) return "";
	return blocks.map((b) => {
		if (b.type === "code") {
			const cleanCode = b.content ? b.content.trim() : "";
			return `<pre><code class="language-${b.language || "javascript"}">${cleanCode}</code></pre>`;
		}
		if (b.type === "math") {
			const formula = b.content ? b.content.trim() : "";
			return `<p>$$${formula}$$</p>`;
		}
		return b.content || "";
	}).join("\n");
}
export default function BlockQuestionEditor({ value, onChange, placeholder = "Tuliskan isi pertanyaan..." }) {
	_s();
	const [blocks, setBlocks] = useState(() => parseStringToBlocks(value));
	const [activeBlockId, setActiveBlockId] = useState(null);
	const [colorPickerOpen, setColorPickerOpen] = useState(null);
	const [highlightPickerOpen, setHighlightPickerOpen] = useState(null);
	const [visualFormulaBlockId, setVisualFormulaBlockId] = useState(null);
	const [visualFormulaValue, setVisualFormulaValue] = useState("");
	const [activeFormats, setActiveFormats] = useState({});
	const editorRefs = useRef({});
	const lastEmittedValueRef = useRef(value);
	const refreshActiveFormats = () => {
		const selection = window.getSelection();
		const editor = selection?.anchorNode?.parentElement?.closest?.("[contenteditable=\"true\"]");
		if (!editor) return;
		const blockId = Object.keys(editorRefs.current).find((id) => editorRefs.current[id] === editor);
		if (!blockId) return;
		const formatBlock = String(document.queryCommandValue("formatBlock") || "").toLowerCase().replace(/[<>]/g, "");
		setActiveFormats({
			blockId,
			bold: document.queryCommandState("bold"),
			italic: document.queryCommandState("italic"),
			underline: document.queryCommandState("underline"),
			strike: document.queryCommandState("strikeThrough"),
			align: [
				"center",
				"right",
				"justify"
			].find((value) => document.queryCommandState(`justify${value[0].toUpperCase()}${value.slice(1)}`)) || "left",
			heading: formatBlock
		});
	};
	useEffect(() => {
		document.addEventListener("selectionchange", refreshActiveFormats);
		return () => document.removeEventListener("selectionchange", refreshActiveFormats);
	}, []);
	// Sync external value changes
	useEffect(() => {
		if (value !== lastEmittedValueRef.current) {
			lastEmittedValueRef.current = value;
			const newBlocks = parseStringToBlocks(value);
			setBlocks(newBlocks);
			newBlocks.forEach((b) => {
				if (b.type === "text" && editorRefs.current[b.id]) {
					const el = editorRefs.current[b.id];
					if (el && el.innerHTML !== (b.content || "") && document.activeElement !== el) {
						el.innerHTML = b.content || "";
					}
				}
			});
		}
	}, [value]);
	const updateBlocksAndEmit = (newBlocks) => {
		setBlocks(newBlocks);
		const serialized = serializeBlocksToString(newBlocks);
		lastEmittedValueRef.current = serialized;
		if (onChange) onChange(serialized);
	};
	const handleUpdateBlock = (id, field, val) => {
		const next = blocks.map((b) => b.id === id ? {
			...b,
			[field]: val
		} : b);
		updateBlocksAndEmit(next);
	};
	const handleAddBlock = (type, afterIndex = null) => {
		const newBlock = {
			id: `b_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
			type,
			language: type === "code" ? "javascript" : undefined,
			content: type === "math" ? "\\frac{a}{b}" : ""
		};
		let next;
		if (afterIndex !== null && afterIndex >= 0) {
			next = [...blocks];
			next.splice(afterIndex + 1, 0, newBlock);
		} else {
			next = [...blocks, newBlock];
		}
		updateBlocksAndEmit(next);
		setActiveBlockId(newBlock.id);
	};
	const handleDeleteBlock = (id) => {
		if (blocks.length <= 1) {
			updateBlocksAndEmit([{
				id: `b_${Date.now()}_0`,
				type: "text",
				content: ""
			}]);
			return;
		}
		const next = blocks.filter((b) => b.id !== id);
		updateBlocksAndEmit(next);
	};
	const handleMoveBlock = (index, dir) => {
		const target = index + dir;
		if (target < 0 || target >= blocks.length) return;
		const next = [...blocks];
		[next[index], next[target]] = [next[target], next[index]];
		updateBlocksAndEmit(next);
	};
	// WYSIWYG Formatting Helpers for contentEditable
	const applyFormatting = (blockId, formatType, payload = null) => {
		const editor = editorRefs.current[blockId];
		if (!editor) return;
		editor.focus();
		const currentBlock = String(document.queryCommandValue("formatBlock") || "").toLowerCase().replace(/[<>]/g, "");
		const currentFontSize = String(document.queryCommandValue("fontSize") || "");
		switch (formatType) {
			case "bold":
				document.execCommand("bold", false, null);
				break;
			case "italic":
				document.execCommand("italic", false, null);
				break;
			case "underline":
				document.execCommand("underline", false, null);
				break;
			case "strike":
				document.execCommand("strikeThrough", false, null);
				break;
			case "color":
				document.execCommand("foreColor", false, payload === "inherit" ? "#1e293b" : payload);
				break;
			case "highlight":
				if (payload === "transparent") {
					document.execCommand("removeFormat", false, null);
				} else {
					if (!document.execCommand("hiliteColor", false, payload)) {
						document.execCommand("backColor", false, payload);
					}
				}
				break;
			case "h2":
				document.execCommand("formatBlock", false, currentBlock === "h2" ? "<div>" : "<h2>");
				break;
			case "h1":
				document.execCommand("formatBlock", false, currentBlock === "h1" ? "<div>" : "<h1>");
				break;
			case "h3":
				document.execCommand("formatBlock", false, currentBlock === "h3" ? "<div>" : "<h3>");
				break;
			case "clearHeading":
				document.execCommand("formatBlock", false, "<div>");
				break;
			case "small":
				if (currentFontSize === "2") document.execCommand("removeFormat", false, null);
				else document.execCommand("fontSize", false, "2");
				break;
			case "align":
				document.execCommand("justify" + (payload === "center" ? "Center" : payload === "right" ? "Right" : payload === "justify" ? "Full" : "Left"), false, null);
				break;
			case "ul":
				document.execCommand("insertUnorderedList", false, null);
				break;
			case "ol":
				document.execCommand("insertOrderedList", false, null);
				break;
			case "quote":
				document.execCommand("formatBlock", false, "<blockquote>");
				break;
			case "code":
				document.execCommand("formatBlock", false, "<pre>");
				break;
			case "math": {
				const sel = window.getSelection();
				const selText = sel ? sel.toString() : "";
				document.execCommand("insertHTML", false, `$${selText || "x^2"}$`);
				break;
			}
			case "link": {
				const url = window.prompt("Masukkan alamat URL tautan (contoh: https://google.com):", "https://");
				if (url) {
					document.execCommand("createLink", false, url);
				}
				break;
			}
			case "clear":
				document.execCommand("removeFormat", false, null);
				document.execCommand("formatBlock", false, "<div>");
				break;
			default: return;
		}
		handleUpdateBlock(blockId, "content", editor.innerHTML);
		setTimeout(refreshActiveFormats, 0);
		setColorPickerOpen(null);
		setHighlightPickerOpen(null);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "border border-slate-200 dark:border-slate-800 rounded-2xl bg-slate-50/50 dark:bg-slate-900/50 p-3 sm:p-4 space-y-3 font-sans transition-colors",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center justify-end gap-2 pb-2.5 border-b border-slate-200/80 dark:border-slate-800",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center gap-1.5",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => handleAddBlock("text"),
							className: "inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xs transition-all cursor-pointer",
							title: "Tambah Blok Teks Bebas / WYSIWYG",
							children: [/* @__PURE__ */ _jsxDEV(Type, {
								size: 13,
								className: "text-teal-600 dark:text-teal-400"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 321,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "+ Teks WYSIWYG" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 315,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => handleAddBlock("code"),
							className: "inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xs transition-all cursor-pointer",
							title: "Tambah Blok Kode Terisolasi (Syntax Highlighted)",
							children: [/* @__PURE__ */ _jsxDEV(Code, {
								size: 13,
								className: "text-amber-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "+ Blok Kode" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => handleAddBlock("math"),
							className: "inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xs transition-all cursor-pointer",
							title: "Tambah Blok Rumus Matematika (KaTeX)",
							children: [/* @__PURE__ */ _jsxDEV(Calculator, {
								size: 13,
								className: "text-[#00897B] dark:text-teal-400"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "+ Rumus KaTeX" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 335,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 314,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 312,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-3.5",
				children: blocks.map((block, idx) => /* @__PURE__ */ _jsxDEV("div", {
					onClick: () => setActiveBlockId(block.id),
					className: `relative rounded-2xl border transition-all ${activeBlockId === block.id ? "border-[#00897B] dark:border-teal-500 ring-2 ring-teal-500/20 bg-white dark:bg-slate-800 shadow-sm" : "border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-800/80 hover:border-slate-300 dark:hover:border-slate-600"} p-3.5 space-y-3`,
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-700/60 pb-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: `px-2 py-0.5 rounded-lg text-[10px] font-extrabold uppercase tracking-wider ${block.type === "code" ? "bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800" : block.type === "math" ? "bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400 border border-teal-200 dark:border-teal-800" : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold"}`,
									children: block.type === "code" ? "Blok Kode" : block.type === "math" ? "Rumus KaTeX" : `Blok Teks #${idx + 1}`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 362,
									columnNumber: 33
								}, this), block.type === "code" && /* @__PURE__ */ _jsxDEV("select", {
									value: block.language || "javascript",
									onChange: (e) => handleUpdateBlock(block.id, "language", e.target.value),
									className: "text-[11px] font-bold border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-0.5 bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-[#00897B]",
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "javascript",
											children: "JavaScript"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 378,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "python",
											children: "Python"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 379,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "csharp",
											children: "C#"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 380,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "html",
											children: "HTML / CSS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 381,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "sql",
											children: "SQL"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 382,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "java",
											children: "Java"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 383,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "cpp",
											children: "C++"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 384,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "json",
											children: "JSON"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 385,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "php",
											children: "PHP"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 386,
											columnNumber: 41
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 373,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 361,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => handleMoveBlock(idx, -1),
										disabled: idx === 0,
										className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 disabled:opacity-30 cursor-pointer",
										title: "Pindah ke Atas",
										children: /* @__PURE__ */ _jsxDEV(ChevronUp, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 399,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 392,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => handleMoveBlock(idx, 1),
										disabled: idx === blocks.length - 1,
										className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 disabled:opacity-30 cursor-pointer",
										title: "Pindah ke Bawah",
										children: /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 408,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 401,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => handleDeleteBlock(block.id),
										className: "p-1 text-red-400 hover:text-red-600 cursor-pointer",
										title: "Hapus Blok",
										children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 416,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 410,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 391,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 360,
							columnNumber: 25
						}, this),
						block.type === "text" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								onMouseDown: (e) => e.preventDefault(),
								className: "flex flex-wrap items-center gap-1 p-1.5 bg-slate-100/80 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-300",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "bold"),
										className: `p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.bold ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Tebal (Bold)",
										children: /* @__PURE__ */ _jsxDEV(Bold, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 435,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 429,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "italic"),
										className: `p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.italic ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Miring (Italic)",
										children: /* @__PURE__ */ _jsxDEV(Italic, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 443,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 437,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "underline"),
										className: `p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.underline ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Garis Bawah (Underline)",
										children: /* @__PURE__ */ _jsxDEV(Underline, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 451,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 445,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "strike"),
										className: `p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.strike ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Coret (Strikethrough)",
										children: /* @__PURE__ */ _jsxDEV(Strikethrough, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 459,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 453,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { className: "h-4 w-px bg-slate-300 dark:bg-slate-700 mx-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 462,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "relative",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												setColorPickerOpen(colorPickerOpen === block.id ? null : block.id);
												setHighlightPickerOpen(null);
											},
											className: "p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 text-teal-600 dark:text-teal-400 transition-colors flex items-center gap-0.5 cursor-pointer",
											title: "Warna Font Teks",
											children: /* @__PURE__ */ _jsxDEV(Palette, { size: 13 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 475,
												columnNumber: 45
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 466,
											columnNumber: 41
										}, this), colorPickerOpen === block.id && /* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-full left-0 mt-1 z-30 p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl flex gap-1.5 animate-in fade-in zoom-in-95 duration-100",
											children: TEXT_COLORS.map((c) => /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => applyFormatting(block.id, "color", c.value),
												className: `w-5 h-5 rounded-full ${c.class} hover:scale-110 transition-transform cursor-pointer shadow-xs`,
												title: c.name
											}, c.name, false, {
												fileName: _jsxFileName,
												lineNumber: 481,
												columnNumber: 53
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 479,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 465,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "relative",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												setHighlightPickerOpen(highlightPickerOpen === block.id ? null : block.id);
												setColorPickerOpen(null);
											},
											className: "p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 text-amber-500 transition-colors flex items-center gap-0.5 cursor-pointer",
											title: "Warna Sorot (Highlight Background)",
											children: /* @__PURE__ */ _jsxDEV(Highlighter, { size: 13 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 503,
												columnNumber: 45
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 494,
											columnNumber: 41
										}, this), highlightPickerOpen === block.id && /* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-full left-0 mt-1 z-30 p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl flex gap-1.5 animate-in fade-in zoom-in-95 duration-100",
											children: HIGHLIGHT_COLORS.map((h) => /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => applyFormatting(block.id, "highlight", h.value),
												className: `w-5 h-5 rounded-full ${h.class} hover:scale-110 transition-transform cursor-pointer shadow-xs`,
												title: h.name
											}, h.name, false, {
												fileName: _jsxFileName,
												lineNumber: 509,
												columnNumber: 53
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 507,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 493,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { className: "h-4 w-px bg-slate-300 dark:bg-slate-700 mx-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 521,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "clearHeading"),
										className: `px-1.5 py-1 text-[10px] font-semibold rounded-lg hover:bg-white dark:hover:bg-slate-800 cursor-pointer ${activeFormats.blockId === block.id && ![
											"h1",
											"h2",
											"h3"
										].includes(activeFormats.heading) ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Kembali ke teks normal",
										children: "Normal"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 524,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "h1"),
										className: `px-1.5 py-1 text-xs font-extrabold rounded-lg hover:bg-white dark:hover:bg-slate-800 cursor-pointer ${activeFormats.blockId === block.id && activeFormats.heading === "h1" ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Judul H1",
										children: "H1"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 525,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "h2"),
										className: `px-1.5 py-1 text-[11px] font-extrabold rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.heading === "h2" ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Judul Besar (H2)",
										children: "H2"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 526,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "h3"),
										className: `px-1.5 py-1 text-[11px] font-extrabold rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.heading === "h3" ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Judul Sedang (H3)",
										children: "H3"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 534,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "small"),
										className: "px-1.5 py-1 text-[10px] font-semibold rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer",
										title: "Teks Kecil",
										children: "Kecil"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 542,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { className: "h-4 w-px bg-slate-300 dark:bg-slate-700 mx-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 551,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "align", "left"),
										className: `p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.align === "left" ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Rata Kiri",
										children: /* @__PURE__ */ _jsxDEV(AlignLeft, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 560,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 554,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "align", "center"),
										className: `p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.align === "center" ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Rata Tengah",
										children: /* @__PURE__ */ _jsxDEV(AlignCenter, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 568,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 562,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "align", "right"),
										className: `p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.align === "right" ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Rata Kanan",
										children: /* @__PURE__ */ _jsxDEV(AlignRight, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 576,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 570,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "align", "justify"),
										className: `p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer ${activeFormats.blockId === block.id && activeFormats.align === "justify" ? "bg-teal-100 text-teal-700 ring-1 ring-teal-400" : ""}`,
										title: "Rata Kiri Kanan (Justify)",
										children: /* @__PURE__ */ _jsxDEV(AlignJustify, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 584,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 578,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { className: "h-4 w-px bg-slate-300 dark:bg-slate-700 mx-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 587,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "ul"),
										className: "p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer",
										title: "Daftar Poin (Bullet List)",
										children: /* @__PURE__ */ _jsxDEV(List, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 596,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 590,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "ol"),
										className: "p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer",
										title: "Daftar Nomor (Numbered List)",
										children: /* @__PURE__ */ _jsxDEV(ListOrdered, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 604,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 598,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "quote"),
										className: "p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer",
										title: "Kutipan (Blockquote)",
										children: /* @__PURE__ */ _jsxDEV(Quote, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 612,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 606,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "link"),
										className: "p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer",
										title: "Sisipkan Tautan URL",
										children: /* @__PURE__ */ _jsxDEV(LinkIcon, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 620,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 614,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "math"),
										className: "px-2 py-1 text-[11px] font-bold text-[#00897B] dark:text-teal-400 hover:bg-white dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer",
										title: "Sisipkan Rumus Inline ($rumus$)",
										children: "$Rumus$"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 622,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => {
											setVisualFormulaValue("");
											setVisualFormulaBlockId(block.id);
										},
										className: "px-2 py-1 text-[11px] font-bold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 rounded-lg cursor-pointer",
										children: "Editor Rumus Visual"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 630,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { className: "h-4 w-px bg-slate-300 dark:bg-slate-700 mx-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 638,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => applyFormatting(block.id, "clear"),
										className: "p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 text-slate-400 hover:text-red-500 transition-colors cursor-pointer",
										title: "Hapus Format (Clear Formatting)",
										children: /* @__PURE__ */ _jsxDEV(RemoveFormatting, { size: 13 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 646,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 640,
										columnNumber: 37
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 426,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								ref: (el) => {
									editorRefs.current[block.id] = el;
									if (el && document.activeElement !== el && el.innerHTML !== (block.content || "")) {
										el.innerHTML = block.content || "";
									}
								},
								contentEditable: true,
								suppressContentEditableWarning: true,
								role: "textbox",
								"aria-multiline": "true",
								"data-placeholder": placeholder,
								onInput: (e) => handleUpdateBlock(block.id, "content", e.currentTarget.innerHTML),
								onFocus: () => setActiveBlockId(block.id),
								className: "formup-rich-editor min-h-20 w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-slate-100 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-[#00897B] dark:focus:ring-teal-400 leading-relaxed transition-colors empty:before:content-[attr(data-placeholder)] empty:before:text-slate-400 dark:empty:before:text-slate-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 651,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 423,
							columnNumber: 29
						}, this),
						block.type === "code" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "relative rounded-xl overflow-hidden bg-slate-950 border border-slate-800",
								children: /* @__PURE__ */ _jsxDEV("textarea", {
									rows: 5,
									value: block.content || "",
									onChange: (e) => handleUpdateBlock(block.id, "content", e.target.value),
									placeholder: "// Tulis atau tempel kode sumber di sini...",
									className: "w-full p-3 font-mono text-xs text-teal-300 bg-transparent focus:outline-none resize-y leading-relaxed",
									spellCheck: false
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 674,
									columnNumber: 37
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 673,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Teks sebelum & sesudah blok kode ini terpisah secara aman tanpa tertelan." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 684,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleAddBlock("text", idx),
									className: "text-[#00897B] dark:text-teal-400 font-bold hover:underline cursor-pointer",
									children: "+ Tambah Teks di Bawah Kode"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 685,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 683,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 672,
							columnNumber: 29
						}, this),
						block.type === "math" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap gap-1",
									children: [
										{
											l: "Pecahan",
											s: "\\frac{a}{b}"
										},
										{
											l: "Akar √",
											s: "\\sqrt{x}"
										},
										{
											l: "x²",
											s: "x^2"
										},
										{
											l: "x₁",
											s: "x_1"
										},
										{
											l: "∑",
											s: "\\sum_{i=1}^n"
										},
										{
											l: "∫",
											s: "\\int_{a}^b"
										},
										{
											l: "±",
											s: "\\pm"
										},
										{
											l: "π",
											s: "\\pi"
										},
										{
											l: "∞",
											s: "\\infty"
										}
									].map((sym, sIdx) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => handleUpdateBlock(block.id, "content", (block.content || "") + sym.s),
										className: "px-2 py-0.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 rounded text-[10px] font-mono font-bold text-slate-700 dark:text-slate-200 cursor-pointer",
										children: sym.l
									}, sIdx, false, {
										fileName: _jsxFileName,
										lineNumber: 711,
										columnNumber: 41
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 699,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("textarea", {
									rows: 2,
									value: block.content || "",
									onChange: (e) => handleUpdateBlock(block.id, "content", e.target.value),
									placeholder: "Ekspresi LaTeX, contoh: \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}",
									className: "w-full font-mono border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white bg-slate-50/50 dark:bg-slate-900/60 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 721,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setVisualFormulaValue(block.content || "");
										setVisualFormulaBlockId(block.id);
									},
									className: "px-2.5 py-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 text-[11px] font-bold cursor-pointer",
									children: "Buka Editor Rumus Visual"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 728,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-teal-50/40 dark:bg-teal-950/40 border border-teal-100 dark:border-teal-900/60 rounded-xl flex items-center justify-center",
									children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
										content: `$$${block.content || "..."}$$`,
										className: "text-sm font-bold"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 730,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 729,
									columnNumber: 33
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 698,
							columnNumber: 29
						}, this)
					]
				}, block.id, true, {
					fileName: _jsxFileName,
					lineNumber: 350,
					columnNumber: 21
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 348,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "pt-2 flex items-center justify-center gap-2 border-t border-slate-200/60 dark:border-slate-800",
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => handleAddBlock("text"),
					className: "inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all cursor-pointer",
					children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 13 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 745,
						columnNumber: 21
					}, this), " Tambah Paragraf Teks"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 740,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 739,
				columnNumber: 13
			}, this),
			visualFormulaBlockId && (() => {
				const target = blocks.find((b) => b.id === visualFormulaBlockId);
				if (!target) return null;
				return /* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "relative bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-5 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-extrabold",
									children: "Editor Rumus Visual"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 754,
									columnNumber: 76
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setVisualFormulaBlockId(null),
									className: "text-slate-400 cursor-pointer",
									children: "✕"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 754,
									columnNumber: 139
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 754,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV(VisualFormulaEditor, {
								value: visualFormulaValue,
								onChange: setVisualFormulaValue
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 755,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									if (target.type === "text") {
										const snippet = visualFormulaValue.trim();
										if (snippet) handleUpdateBlock(target.id, "content", `${target.content || ""} $${snippet}$ `);
									} else {
										handleUpdateBlock(target.id, "content", visualFormulaValue);
									}
									setVisualFormulaBlockId(null);
								},
								className: "w-full py-2 rounded-xl bg-teal-600 text-white text-xs font-bold cursor-pointer",
								children: "Sisipkan ke Soal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 756,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 753,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 752,
					columnNumber: 24
				}, this);
			})()
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 309,
		columnNumber: 9
	}, this);
}
_s(BlockQuestionEditor, "ppJAgVU1pt7F+UALvjjvB8cvag8=");
_c = BlockQuestionEditor;
var _c;
$RefreshReg$(_c, "BlockQuestionEditor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/BlockQuestionEditor.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/BlockQuestionEditor.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/BlockQuestionEditor.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/BlockQuestionEditor.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsY0FBYztBQUM1QyxTQUNJLE1BQU0sWUFBWSxNQUFNLFFBQVEsV0FBVyxhQUMzQyxNQUFNLFVBQVUsTUFBTSxRQUFRLFdBQVcsZUFDekMsV0FBVyxhQUFhLFlBQVksY0FDcEMsTUFBTSxhQUFhLE9BQU8sUUFBUSxVQUFVLGtCQUM1QyxTQUFTLG1CQUNOO0FBQ1AsT0FBTyx5QkFBeUI7QUFDaEMsT0FBTyx5QkFBeUI7Ozs7QUFFaEMsTUFBTSxjQUFjO0NBQ2hCO0VBQUUsTUFBTTtFQUFXLE9BQU87RUFBVyxPQUFPO0NBQWlDO0NBQzdFO0VBQUUsTUFBTTtFQUFTLE9BQU87RUFBVyxPQUFPO0NBQWU7Q0FDekQ7RUFBRSxNQUFNO0VBQVMsT0FBTztFQUFXLE9BQU87Q0FBYTtDQUN2RDtFQUFFLE1BQU07RUFBUyxPQUFPO0VBQVcsT0FBTztDQUFpQjtDQUMzRDtFQUFFLE1BQU07RUFBUSxPQUFPO0VBQVcsT0FBTztDQUFlO0NBQ3hEO0VBQUUsTUFBTTtFQUFRLE9BQU87RUFBVyxPQUFPO0NBQWM7Q0FDdkQ7RUFBRSxNQUFNO0VBQVEsT0FBTztFQUFXLE9BQU87Q0FBZ0I7Q0FDekQ7RUFBRSxNQUFNO0VBQVUsT0FBTztFQUFXLE9BQU87Q0FBZ0I7QUFDL0Q7QUFFQSxNQUFNLG1CQUFtQjtDQUNyQjtFQUFFLE1BQU07RUFBUSxPQUFPO0VBQWUsT0FBTztDQUF5QztDQUN0RjtFQUFFLE1BQU07RUFBVSxPQUFPO0VBQVcsT0FBTztDQUFnQjtDQUMzRDtFQUFFLE1BQU07RUFBUyxPQUFPO0VBQVcsT0FBTztDQUFlO0NBQ3pEO0VBQUUsTUFBTTtFQUFRLE9BQU87RUFBVyxPQUFPO0NBQWM7Q0FDdkQ7RUFBRSxNQUFNO0VBQVEsT0FBTztFQUFXLE9BQU87Q0FBYztDQUN2RDtFQUFFLE1BQU07RUFBVSxPQUFPO0VBQVcsT0FBTztDQUFnQjtDQUMzRDtFQUFFLE1BQU07RUFBUSxPQUFPO0VBQVcsT0FBTztDQUFnQjtBQUM3RDs7OztBQUtBLFNBQVMsb0JBQW9CLFFBQVE7Q0FDakMsSUFBSSxDQUFDLFVBQVUsT0FBTyxXQUFXLFlBQVksQ0FBQyxPQUFPLEtBQUssR0FBRztFQUN6RCxPQUFPLENBQUM7R0FBRSxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7R0FBSyxNQUFNO0dBQVEsU0FBUztFQUFHLENBQUM7Q0FDbEU7Q0FFQSxNQUFNLFNBQVMsQ0FBQztDQUNoQixNQUFNLE9BQU8sT0FBTyxLQUFLOztDQUd6QixNQUFNLGdCQUFnQjtDQUV0QixJQUFJLFlBQVk7Q0FDaEIsSUFBSTtDQUVKLFFBQVEsUUFBUSxjQUFjLEtBQUssSUFBSSxPQUFPLE1BQU07RUFDaEQsSUFBSSxNQUFNLFFBQVEsV0FBVztHQUN6QixNQUFNLGFBQWEsS0FBSyxVQUFVLFdBQVcsTUFBTSxLQUFLLENBQUMsQ0FBQyxLQUFLO0dBQy9ELElBQUksWUFBWTtJQUNaLE9BQU8sS0FBSztLQUNSLElBQUksS0FBSyxLQUFLLElBQUksRUFBRSxHQUFHLE9BQU87S0FDOUIsTUFBTTtLQUNOLFNBQVM7SUFDYixDQUFDO0dBQ0w7RUFDSjtFQUVBLElBQUksTUFBTSxFQUFFLENBQUMsV0FBVyxNQUFNLEtBQUssTUFBTSxFQUFFLENBQUMsV0FBVyxLQUFLLEdBQUc7R0FDM0QsTUFBTSxPQUFPLE1BQU0sTUFBTSxNQUFNLE1BQU07R0FDckMsTUFBTSxRQUFRLE1BQU0sTUFBTSxNQUFNLE1BQU0sR0FBRSxDQUFFLEtBQUs7R0FDL0MsT0FBTyxLQUFLO0lBQ1IsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFLEdBQUcsT0FBTztJQUM5QixNQUFNO0lBQ04sVUFBVTtJQUNWLFNBQVM7R0FDYixDQUFDO0VBQ0wsT0FBTztHQUNILE1BQU0sV0FBVyxNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUUsQ0FBRSxLQUFLO0dBQ2xELE9BQU8sS0FBSztJQUNSLElBQUksS0FBSyxLQUFLLElBQUksRUFBRSxHQUFHLE9BQU87SUFDOUIsTUFBTTtJQUNOLFNBQVM7R0FDYixDQUFDO0VBQ0w7RUFFQSxZQUFZLE1BQU0sUUFBUSxNQUFNLEVBQUUsQ0FBQztDQUN2QztDQUVBLElBQUksWUFBWSxLQUFLLFFBQVE7RUFDekIsTUFBTSxZQUFZLEtBQUssVUFBVSxTQUFTLENBQUMsQ0FBQyxLQUFLO0VBQ2pELElBQUksV0FBVztHQUNYLE9BQU8sS0FBSztJQUNSLElBQUksS0FBSyxLQUFLLElBQUksRUFBRSxHQUFHLE9BQU87SUFDOUIsTUFBTTtJQUNOLFNBQVM7R0FDYixDQUFDO0VBQ0w7Q0FDSjtDQUVBLE9BQU8sT0FBTyxTQUFTLElBQUksU0FBUyxDQUFDO0VBQUUsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFO0VBQUssTUFBTTtFQUFRLFNBQVM7Q0FBTyxDQUFDO0FBQ25HOzs7O0FBS0EsU0FBUyx3QkFBd0IsUUFBUTtDQUNyQyxJQUFJLENBQUMsVUFBVSxPQUFPLFdBQVcsR0FBRyxPQUFPO0NBRTNDLE9BQU8sT0FBTyxLQUFJLE1BQUs7RUFDbkIsSUFBSSxFQUFFLFNBQVMsUUFBUTtHQUNuQixNQUFNLFlBQVksRUFBRSxVQUFVLEVBQUUsUUFBUSxLQUFLLElBQUk7R0FDakQsT0FBTyw4QkFBOEIsRUFBRSxZQUFZLGFBQWEsSUFBSSxVQUFVO0VBQ2xGO0VBQ0EsSUFBSSxFQUFFLFNBQVMsUUFBUTtHQUNuQixNQUFNLFVBQVUsRUFBRSxVQUFVLEVBQUUsUUFBUSxLQUFLLElBQUk7R0FDL0MsT0FBTyxRQUFRLFFBQVE7RUFDM0I7RUFDQSxPQUFPLEVBQUUsV0FBVztDQUN4QixDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUk7QUFDaEI7QUFFQSxlQUFlLFNBQVMsb0JBQW9CLEVBQUUsT0FBTyxVQUFVLGNBQWMsZ0NBQWdDOztDQUN6RyxNQUFNLENBQUMsUUFBUSxhQUFhLGVBQWUsb0JBQW9CLEtBQUssQ0FBQztDQUNyRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxJQUFJO0NBQ3ZELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsSUFBSTtDQUMzRCxNQUFNLENBQUMscUJBQXFCLDBCQUEwQixTQUFTLElBQUk7Q0FDbkUsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxJQUFJO0NBQ3JFLE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsRUFBRTtDQUMvRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxDQUFDLENBQUM7Q0FDckQsTUFBTSxhQUFhLE9BQU8sQ0FBQyxDQUFDO0NBQzVCLE1BQU0sc0JBQXNCLE9BQU8sS0FBSztDQUV4QyxNQUFNLDZCQUE2QjtFQUMvQixNQUFNLFlBQVksT0FBTyxhQUFhO0VBQ3RDLE1BQU0sU0FBUyxXQUFXLFlBQVksZUFBZSxVQUFVLDRCQUEwQjtFQUN6RixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sVUFBVSxPQUFPLEtBQUssV0FBVyxPQUFPLENBQUMsQ0FBQyxNQUFLLE9BQU0sV0FBVyxRQUFRLFFBQVEsTUFBTTtFQUM1RixJQUFJLENBQUMsU0FBUztFQUNkLE1BQU0sY0FBYyxPQUFPLFNBQVMsa0JBQWtCLGFBQWEsS0FBSyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLFNBQVMsRUFBRTtFQUM3RyxpQkFBaUI7R0FDYjtHQUNBLE1BQU0sU0FBUyxrQkFBa0IsTUFBTTtHQUN2QyxRQUFRLFNBQVMsa0JBQWtCLFFBQVE7R0FDM0MsV0FBVyxTQUFTLGtCQUFrQixXQUFXO0dBQ2pELFFBQVEsU0FBUyxrQkFBa0IsZUFBZTtHQUNsRCxPQUFPO0lBQUM7SUFBVTtJQUFTO0dBQVMsQ0FBQyxDQUFDLE1BQUssVUFBUyxTQUFTLGtCQUFrQixVQUFVLE1BQU0sRUFBRSxDQUFDLFlBQVksSUFBSSxNQUFNLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSztHQUN4SSxTQUFTO0VBQ2IsQ0FBQztDQUNMO0NBRUEsZ0JBQWdCO0VBQ1osU0FBUyxpQkFBaUIsbUJBQW1CLG9CQUFvQjtFQUNqRSxhQUFhLFNBQVMsb0JBQW9CLG1CQUFtQixvQkFBb0I7Q0FDckYsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ1osSUFBSSxVQUFVLG9CQUFvQixTQUFTO0dBQ3ZDLG9CQUFvQixVQUFVO0dBQzlCLE1BQU0sWUFBWSxvQkFBb0IsS0FBSztHQUMzQyxVQUFVLFNBQVM7R0FDbkIsVUFBVSxTQUFRLE1BQUs7SUFDbkIsSUFBSSxFQUFFLFNBQVMsVUFBVSxXQUFXLFFBQVEsRUFBRSxLQUFLO0tBQy9DLE1BQU0sS0FBSyxXQUFXLFFBQVEsRUFBRTtLQUNoQyxJQUFJLE1BQU0sR0FBRyxlQUFlLEVBQUUsV0FBVyxPQUFPLFNBQVMsa0JBQWtCLElBQUk7TUFDM0UsR0FBRyxZQUFZLEVBQUUsV0FBVztLQUNoQztJQUNKO0dBQ0osQ0FBQztFQUNMO0NBQ0osR0FBRyxDQUFDLEtBQUssQ0FBQztDQUVWLE1BQU0sdUJBQXVCLGNBQWM7RUFDdkMsVUFBVSxTQUFTO0VBQ25CLE1BQU0sYUFBYSx3QkFBd0IsU0FBUztFQUNwRCxvQkFBb0IsVUFBVTtFQUM5QixJQUFJLFVBQVUsU0FBUyxVQUFVO0NBQ3JDO0NBRUEsTUFBTSxxQkFBcUIsSUFBSSxPQUFPLFFBQVE7RUFDMUMsTUFBTSxPQUFPLE9BQU8sS0FBSSxNQUFLLEVBQUUsT0FBTyxLQUFLO0dBQUUsR0FBRztJQUFJLFFBQVE7RUFBSSxJQUFJLENBQUM7RUFDckUsb0JBQW9CLElBQUk7Q0FDNUI7Q0FFQSxNQUFNLGtCQUFrQixNQUFNLGFBQWEsU0FBUztFQUNoRCxNQUFNLFdBQVc7R0FDYixJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUUsR0FBRyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUM7R0FDdkQ7R0FDTixVQUFVLFNBQVMsU0FBUyxlQUFlO0dBQzNDLFNBQVMsU0FBUyxTQUFTLGlCQUFpQjtFQUNoRDtFQUVBLElBQUk7RUFDSixJQUFJLGVBQWUsUUFBUSxjQUFjLEdBQUc7R0FDeEMsT0FBTyxDQUFDLEdBQUcsTUFBTTtHQUNqQixLQUFLLE9BQU8sYUFBYSxHQUFHLEdBQUcsUUFBUTtFQUMzQyxPQUFPO0dBQ0gsT0FBTyxDQUFDLEdBQUcsUUFBUSxRQUFRO0VBQy9CO0VBRUEsb0JBQW9CLElBQUk7RUFDeEIsaUJBQWlCLFNBQVMsRUFBRTtDQUNoQztDQUVBLE1BQU0scUJBQXFCLE9BQU87RUFDOUIsSUFBSSxPQUFPLFVBQVUsR0FBRztHQUNwQixvQkFBb0IsQ0FBQztJQUFFLElBQUksS0FBSyxLQUFLLElBQUksRUFBRTtJQUFLLE1BQU07SUFBUSxTQUFTO0dBQUcsQ0FBQyxDQUFDO0dBQzVFO0VBQ0o7RUFDQSxNQUFNLE9BQU8sT0FBTyxRQUFPLE1BQUssRUFBRSxPQUFPLEVBQUU7RUFDM0Msb0JBQW9CLElBQUk7Q0FDNUI7Q0FFQSxNQUFNLG1CQUFtQixPQUFPLFFBQVE7RUFDcEMsTUFBTSxTQUFTLFFBQVE7RUFDdkIsSUFBSSxTQUFTLEtBQUssVUFBVSxPQUFPLFFBQVE7RUFDM0MsTUFBTSxPQUFPLENBQUMsR0FBRyxNQUFNO0VBQ3ZCLENBQUMsS0FBSyxRQUFRLEtBQUssV0FBVyxDQUFDLEtBQUssU0FBUyxLQUFLLE1BQU07RUFDeEQsb0JBQW9CLElBQUk7Q0FDNUI7O0NBR0EsTUFBTSxtQkFBbUIsU0FBUyxZQUFZLFVBQVUsU0FBUztFQUM3RCxNQUFNLFNBQVMsV0FBVyxRQUFRO0VBQ2xDLElBQUksQ0FBQyxRQUFRO0VBRWIsT0FBTyxNQUFNO0VBQ2IsTUFBTSxlQUFlLE9BQU8sU0FBUyxrQkFBa0IsYUFBYSxLQUFLLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsU0FBUyxFQUFFO0VBQzlHLE1BQU0sa0JBQWtCLE9BQU8sU0FBUyxrQkFBa0IsVUFBVSxLQUFLLEVBQUU7RUFFM0UsUUFBUSxZQUFSO0dBQ0ksS0FBSztJQUNELFNBQVMsWUFBWSxRQUFRLE9BQU8sSUFBSTtJQUN4QztHQUNKLEtBQUs7SUFDRCxTQUFTLFlBQVksVUFBVSxPQUFPLElBQUk7SUFDMUM7R0FDSixLQUFLO0lBQ0QsU0FBUyxZQUFZLGFBQWEsT0FBTyxJQUFJO0lBQzdDO0dBQ0osS0FBSztJQUNELFNBQVMsWUFBWSxpQkFBaUIsT0FBTyxJQUFJO0lBQ2pEO0dBQ0osS0FBSztJQUNELFNBQVMsWUFBWSxhQUFhLE9BQU8sWUFBWSxZQUFZLFlBQVksT0FBTztJQUNwRjtHQUNKLEtBQUs7SUFDRCxJQUFJLFlBQVksZUFBZTtLQUMzQixTQUFTLFlBQVksZ0JBQWdCLE9BQU8sSUFBSTtJQUNwRCxPQUFPO0tBQ0gsSUFBSSxDQUFDLFNBQVMsWUFBWSxlQUFlLE9BQU8sT0FBTyxHQUFHO01BQ3RELFNBQVMsWUFBWSxhQUFhLE9BQU8sT0FBTztLQUNwRDtJQUNKO0lBQ0E7R0FDSixLQUFLO0lBQ0QsU0FBUyxZQUFZLGVBQWUsT0FBTyxpQkFBaUIsT0FBTyxVQUFVLE1BQU07SUFDbkY7R0FDSixLQUFLO0lBQ0QsU0FBUyxZQUFZLGVBQWUsT0FBTyxpQkFBaUIsT0FBTyxVQUFVLE1BQU07SUFDbkY7R0FDSixLQUFLO0lBQ0QsU0FBUyxZQUFZLGVBQWUsT0FBTyxpQkFBaUIsT0FBTyxVQUFVLE1BQU07SUFDbkY7R0FDSixLQUFLO0lBQ0QsU0FBUyxZQUFZLGVBQWUsT0FBTyxPQUFPO0lBQ2xEO0dBQ0osS0FBSztJQUNELElBQUksb0JBQW9CLEtBQUssU0FBUyxZQUFZLGdCQUFnQixPQUFPLElBQUk7U0FDeEUsU0FBUyxZQUFZLFlBQVksT0FBTyxHQUFHO0lBQ2hEO0dBQ0osS0FBSztJQUNELFNBQVMsWUFBWSxhQUFhLFlBQVksV0FBVyxXQUFXLFlBQVksVUFBVSxVQUFVLFlBQVksWUFBWSxTQUFTLFNBQVMsT0FBTyxJQUFJO0lBQ3pKO0dBQ0osS0FBSztJQUNELFNBQVMsWUFBWSx1QkFBdUIsT0FBTyxJQUFJO0lBQ3ZEO0dBQ0osS0FBSztJQUNELFNBQVMsWUFBWSxxQkFBcUIsT0FBTyxJQUFJO0lBQ3JEO0dBQ0osS0FBSztJQUNELFNBQVMsWUFBWSxlQUFlLE9BQU8sY0FBYztJQUN6RDtHQUNKLEtBQUs7SUFDRCxTQUFTLFlBQVksZUFBZSxPQUFPLE9BQU87SUFDbEQ7R0FDSixLQUFLLFFBQVE7SUFDVCxNQUFNLE1BQU0sT0FBTyxhQUFhO0lBQ2hDLE1BQU0sVUFBVSxNQUFNLElBQUksU0FBUyxJQUFJO0lBQ3ZDLFNBQVMsWUFBWSxjQUFjLE9BQU8sSUFBSSxXQUFXLE1BQU0sRUFBRTtJQUNqRTtHQUNKO0dBQ0EsS0FBSyxRQUFRO0lBQ1QsTUFBTSxNQUFNLE9BQU8sT0FBTyw0REFBNEQsVUFBVTtJQUNoRyxJQUFJLEtBQUs7S0FDTCxTQUFTLFlBQVksY0FBYyxPQUFPLEdBQUc7SUFDakQ7SUFDQTtHQUNKO0dBQ0EsS0FBSztJQUNELFNBQVMsWUFBWSxnQkFBZ0IsT0FBTyxJQUFJO0lBQ2hELFNBQVMsWUFBWSxlQUFlLE9BQU8sT0FBTztJQUNsRDtHQUNKLFNBQ0k7RUFDUjtFQUVBLGtCQUFrQixTQUFTLFdBQVcsT0FBTyxTQUFTO0VBQ3RELFdBQVcsc0JBQXNCLENBQUM7RUFDbEMsbUJBQW1CLElBQUk7RUFDdkIsdUJBQXVCLElBQUk7Q0FDL0I7Q0FFQSxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FHSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUVYLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDSSx3QkFBQyxVQUFEO09BQ0ksTUFBSztPQUNMLGVBQWUsZUFBZSxNQUFNO09BQ3BDLFdBQVU7T0FDVixPQUFNO2lCQUpWLENBTUksd0JBQUMsTUFBRDtRQUFNLE1BQU07UUFBSSxXQUFVO09BQW9DOzs7O2lCQUM5RCx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7O2VBQ3RCOzs7Ozs7TUFFUix3QkFBQyxVQUFEO09BQ0ksTUFBSztPQUNMLGVBQWUsZUFBZSxNQUFNO09BQ3BDLFdBQVU7T0FDVixPQUFNO2lCQUpWLENBTUksd0JBQUMsTUFBRDtRQUFNLE1BQU07UUFBSSxXQUFVO09BQWtCOzs7O2lCQUM1Qyx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7ZUFDbkI7Ozs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsZUFBZSxlQUFlLE1BQU07T0FDcEMsV0FBVTtPQUNWLE9BQU07aUJBSlYsQ0FNSSx3QkFBQyxZQUFEO1FBQVksTUFBTTtRQUFJLFdBQVU7T0FBcUM7Ozs7aUJBQ3JFLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7ZUFDckI7Ozs7OztLQUNQOzs7Ozs7R0FDSjs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNWLE9BQU8sS0FBSyxPQUFPLFFBQ2hCLHdCQUFDLE9BQUQ7S0FFSSxlQUFlLGlCQUFpQixNQUFNLEVBQUU7S0FDeEMsV0FBVyw4Q0FDUCxrQkFBa0IsTUFBTSxLQUNsQix1R0FDQSw2SEFDVDtlQVBMO01BVUksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLFFBQUQ7U0FBTSxXQUFXLDhFQUNiLE1BQU0sU0FBUyxTQUNULHNIQUNBLE1BQU0sU0FBUyxTQUNmLGlIQUNBO21CQUVMLE1BQU0sU0FBUyxTQUFTLGNBQWMsTUFBTSxTQUFTLFNBQVMsZ0JBQWdCLGNBQWMsTUFBTTtRQUNqRzs7OztrQkFFTCxNQUFNLFNBQVMsVUFDWix3QkFBQyxVQUFEO1NBQ0ksT0FBTyxNQUFNLFlBQVk7U0FDekIsV0FBVSxNQUFLLGtCQUFrQixNQUFNLElBQUksWUFBWSxFQUFFLE9BQU8sS0FBSztTQUNyRSxXQUFVO21CQUhkO1VBS0ksd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQWE7VUFBa0I7Ozs7O1VBQzdDLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFTO1VBQWM7Ozs7O1VBQ3JDLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFTO1VBQVU7Ozs7O1VBQ2pDLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFPO1VBQWtCOzs7OztVQUN2Qyx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBTTtVQUFXOzs7OztVQUMvQix3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBTztVQUFZOzs7OztVQUNqQyx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBTTtVQUFXOzs7OztVQUMvQix3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBTztVQUFZOzs7OztVQUNqQyx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBTTtVQUFXOzs7OztTQUMzQjs7Ozs7Z0JBRVg7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0ksd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixLQUFLLENBQUMsQ0FBQztVQUN0QyxVQUFVLFFBQVE7VUFDbEIsV0FBVTtVQUNWLE9BQU07b0JBRU4sd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7U0FDbEI7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixLQUFLLENBQUM7VUFDckMsVUFBVSxRQUFRLE9BQU8sU0FBUztVQUNsQyxXQUFVO1VBQ1YsT0FBTTtvQkFFTix3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztTQUNwQjs7Ozs7U0FDUix3QkFBQyxVQUFEO1VBQ0ksTUFBSztVQUNMLGVBQWUsa0JBQWtCLE1BQU0sRUFBRTtVQUN6QyxXQUFVO1VBQ1YsT0FBTTtvQkFFTix3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztTQUNmOzs7OztRQUNQOzs7OztlQUNKOzs7Ozs7TUFHSixNQUFNLFNBQVMsVUFDWix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUdJLHdCQUFDLE9BQUQ7UUFBSyxjQUFhLE1BQUssRUFBRSxlQUFlO1FBQUcsV0FBVTtrQkFBckQ7U0FHSSx3QkFBQyxVQUFEO1VBQ0ksTUFBSztVQUNMLGVBQWUsZ0JBQWdCLE1BQU0sSUFBSSxNQUFNO1VBQy9DLFdBQVcsdUlBQXVJLGNBQWMsWUFBWSxNQUFNLE1BQU0sY0FBYyxPQUFPLG1EQUFtRDtVQUNoUSxPQUFNO29CQUVOLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O1NBQ2I7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixNQUFNLElBQUksUUFBUTtVQUNqRCxXQUFXLHVJQUF1SSxjQUFjLFlBQVksTUFBTSxNQUFNLGNBQWMsU0FBUyxtREFBbUQ7VUFDbFEsT0FBTTtvQkFFTix3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztTQUNmOzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLFdBQVc7VUFDcEQsV0FBVyx1SUFBdUksY0FBYyxZQUFZLE1BQU0sTUFBTSxjQUFjLFlBQVksbURBQW1EO1VBQ3JRLE9BQU07b0JBRU4sd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7U0FDbEI7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixNQUFNLElBQUksUUFBUTtVQUNqRCxXQUFXLHVJQUF1SSxjQUFjLFlBQVksTUFBTSxNQUFNLGNBQWMsU0FBUyxtREFBbUQ7VUFDbFEsT0FBTTtvQkFFTix3QkFBQyxlQUFELEVBQWUsTUFBTSxHQUFLOzs7OztTQUN0Qjs7Ozs7U0FFUix3QkFBQyxPQUFELEVBQUssV0FBVSxpREFBa0Q7Ozs7O1NBR2pFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsVUFBRDtXQUNJLE1BQUs7V0FDTCxlQUFlO1lBQ1gsbUJBQW1CLG9CQUFvQixNQUFNLEtBQUssT0FBTyxNQUFNLEVBQUU7WUFDakUsdUJBQXVCLElBQUk7V0FDL0I7V0FDQSxXQUFVO1dBQ1YsT0FBTTtxQkFFTix3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7OztVQUNoQjs7OztvQkFFUCxvQkFBb0IsTUFBTSxNQUN2Qix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDVixZQUFZLEtBQUksTUFDYix3QkFBQyxVQUFEO1lBRUksTUFBSztZQUNMLGVBQWUsZ0JBQWdCLE1BQU0sSUFBSSxTQUFTLEVBQUUsS0FBSztZQUN6RCxXQUFXLHdCQUF3QixFQUFFLE1BQU07WUFDM0MsT0FBTyxFQUFFO1dBQ1osR0FMUSxFQUFFOzs7O2tCQUtWLENBQ0o7VUFDQTs7OztrQkFFUjs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxVQUFEO1dBQ0ksTUFBSztXQUNMLGVBQWU7WUFDWCx1QkFBdUIsd0JBQXdCLE1BQU0sS0FBSyxPQUFPLE1BQU0sRUFBRTtZQUN6RSxtQkFBbUIsSUFBSTtXQUMzQjtXQUNBLFdBQVU7V0FDVixPQUFNO3FCQUVOLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O1VBQ3BCOzs7O29CQUVQLHdCQUF3QixNQUFNLE1BQzNCLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNWLGlCQUFpQixLQUFJLE1BQ2xCLHdCQUFDLFVBQUQ7WUFFSSxNQUFLO1lBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLGFBQWEsRUFBRSxLQUFLO1lBQzdELFdBQVcsd0JBQXdCLEVBQUUsTUFBTTtZQUMzQyxPQUFPLEVBQUU7V0FDWixHQUxRLEVBQUU7Ozs7a0JBS1YsQ0FDSjtVQUNBOzs7O2tCQUVSOzs7Ozs7U0FFTCx3QkFBQyxPQUFELEVBQUssV0FBVSxpREFBa0Q7Ozs7O1NBR2pFLHdCQUFDLFVBQUQ7VUFBUSxNQUFLO1VBQVMsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLGNBQWM7VUFBRyxXQUFXLDBHQUEwRyxjQUFjLFlBQVksTUFBTSxNQUFNLENBQUM7V0FBQztXQUFNO1dBQU07VUFBSSxDQUFDLENBQUMsU0FBUyxjQUFjLE9BQU8sSUFBSSxtREFBbUQ7VUFBTSxPQUFNO29CQUF5QjtTQUFjOzs7OztTQUN2WSx3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLGVBQWUsZ0JBQWdCLE1BQU0sSUFBSSxJQUFJO1VBQUcsV0FBVyx1R0FBdUcsY0FBYyxZQUFZLE1BQU0sTUFBTSxjQUFjLFlBQVksT0FBTyxtREFBbUQ7VUFBTSxPQUFNO29CQUFXO1NBQVU7Ozs7O1NBQ25WLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLElBQUk7VUFDN0MsV0FBVyw2SEFBNkgsY0FBYyxZQUFZLE1BQU0sTUFBTSxjQUFjLFlBQVksT0FBTyxtREFBbUQ7VUFDbFEsT0FBTTtvQkFDVDtTQUVPOzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLElBQUk7VUFDN0MsV0FBVyw2SEFBNkgsY0FBYyxZQUFZLE1BQU0sTUFBTSxjQUFjLFlBQVksT0FBTyxtREFBbUQ7VUFDbFEsT0FBTTtvQkFDVDtTQUVPOzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLE9BQU87VUFDaEQsV0FBVTtVQUNWLE9BQU07b0JBQ1Q7U0FFTzs7Ozs7U0FFUix3QkFBQyxPQUFELEVBQUssV0FBVSxpREFBa0Q7Ozs7O1NBR2pFLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLFNBQVMsTUFBTTtVQUN4RCxXQUFXLDRGQUE0RixjQUFjLFlBQVksTUFBTSxNQUFNLGNBQWMsVUFBVSxTQUFTLG1EQUFtRDtVQUNqTyxPQUFNO29CQUVOLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O1NBQ2xCOzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLFNBQVMsUUFBUTtVQUMxRCxXQUFXLDRGQUE0RixjQUFjLFlBQVksTUFBTSxNQUFNLGNBQWMsVUFBVSxXQUFXLG1EQUFtRDtVQUNuTyxPQUFNO29CQUVOLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O1NBQ3BCOzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLFNBQVMsT0FBTztVQUN6RCxXQUFXLDRGQUE0RixjQUFjLFlBQVksTUFBTSxNQUFNLGNBQWMsVUFBVSxVQUFVLG1EQUFtRDtVQUNsTyxPQUFNO29CQUVOLHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7O1NBQ25COzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLFNBQVMsU0FBUztVQUMzRCxXQUFXLDRGQUE0RixjQUFjLFlBQVksTUFBTSxNQUFNLGNBQWMsVUFBVSxZQUFZLG1EQUFtRDtVQUNwTyxPQUFNO29CQUVOLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O1NBQ3JCOzs7OztTQUVSLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGlEQUFrRDs7Ozs7U0FHakUsd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixNQUFNLElBQUksSUFBSTtVQUM3QyxXQUFVO1VBQ1YsT0FBTTtvQkFFTix3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztTQUNiOzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLElBQUk7VUFDN0MsV0FBVTtVQUNWLE9BQU07b0JBRU4sd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7Ozs7U0FDcEI7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixNQUFNLElBQUksT0FBTztVQUNoRCxXQUFVO1VBQ1YsT0FBTTtvQkFFTix3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztTQUNkOzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLE1BQU07VUFDL0MsV0FBVTtVQUNWLE9BQU07b0JBRU4sd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7U0FDakI7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixNQUFNLElBQUksTUFBTTtVQUMvQyxXQUFVO1VBQ1YsT0FBTTtvQkFDVDtTQUVPOzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZTtXQUFFLHNCQUFzQixFQUFFO1dBQUcsd0JBQXdCLE1BQU0sRUFBRTtVQUFHO1VBQy9FLFdBQVU7b0JBQ2I7U0FFTzs7Ozs7U0FFUix3QkFBQyxPQUFELEVBQUssV0FBVSxpREFBa0Q7Ozs7O1NBRWpFLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLE9BQU87VUFDaEQsV0FBVTtVQUNWLE9BQU07b0JBRU4sd0JBQUMsa0JBQUQsRUFBa0IsTUFBTSxHQUFLOzs7OztTQUN6Qjs7Ozs7UUFDUDs7Ozs7aUJBR0wsd0JBQUMsT0FBRDtRQUNJLE1BQUssT0FBTTtTQUNQLFdBQVcsUUFBUSxNQUFNLE1BQU07U0FDL0IsSUFBSSxNQUFNLFNBQVMsa0JBQWtCLE1BQU0sR0FBRyxlQUFlLE1BQU0sV0FBVyxLQUFLO1VBQy9FLEdBQUcsWUFBWSxNQUFNLFdBQVc7U0FDcEM7UUFDSjtRQUNBO1FBQ0E7UUFDQSxNQUFLO1FBQ0wsa0JBQWU7UUFDZixvQkFBa0I7UUFDbEIsVUFBUyxNQUFLLGtCQUFrQixNQUFNLElBQUksV0FBVyxFQUFFLGNBQWMsU0FBUztRQUM5RSxlQUFlLGlCQUFpQixNQUFNLEVBQUU7UUFDeEMsV0FBVTtPQUNiOzs7O2VBQ0E7Ozs7OztNQUlSLE1BQU0sU0FBUyxVQUNaLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1gsd0JBQUMsWUFBRDtTQUNJLE1BQU07U0FDTixPQUFPLE1BQU0sV0FBVztTQUN4QixXQUFVLE1BQUssa0JBQWtCLE1BQU0sSUFBSSxXQUFXLEVBQUUsT0FBTyxLQUFLO1NBQ3BFLGFBQVk7U0FDWixXQUFVO1NBQ1YsWUFBWTtRQUNmOzs7OztPQUNBOzs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsUUFBRCxZQUFNLDRFQUErRTs7OztrQkFDckYsd0JBQUMsVUFBRDtTQUNJLE1BQUs7U0FDTCxlQUFlLGVBQWUsUUFBUSxHQUFHO1NBQ3pDLFdBQVU7bUJBQ2I7UUFFTzs7OztnQkFDUDs7Ozs7ZUFDSjs7Ozs7O01BSVIsTUFBTSxTQUFTLFVBQ1osd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDVjtVQUNHO1dBQUUsR0FBRztXQUFXLEdBQUc7VUFBZTtVQUNsQztXQUFFLEdBQUc7V0FBVSxHQUFHO1VBQVk7VUFDOUI7V0FBRSxHQUFHO1dBQU0sR0FBRztVQUFNO1VBQ3BCO1dBQUUsR0FBRztXQUFNLEdBQUc7VUFBTTtVQUNwQjtXQUFFLEdBQUc7V0FBSyxHQUFHO1VBQWdCO1VBQzdCO1dBQUUsR0FBRztXQUFLLEdBQUc7VUFBYztVQUMzQjtXQUFFLEdBQUc7V0FBSyxHQUFHO1VBQU87VUFDcEI7V0FBRSxHQUFHO1dBQUssR0FBRztVQUFPO1VBQ3BCO1dBQUUsR0FBRztXQUFLLEdBQUc7VUFBVTtTQUMzQixDQUFDLENBQUMsS0FBSyxLQUFLLFNBQ1Isd0JBQUMsVUFBRDtVQUVJLE1BQUs7VUFDTCxlQUFlLGtCQUFrQixNQUFNLElBQUksWUFBWSxNQUFNLFdBQVcsTUFBTSxJQUFJLENBQUM7VUFDbkYsV0FBVTtvQkFFVCxJQUFJO1NBQ0QsR0FOQzs7OztnQkFNRCxDQUNYO1FBQ0E7Ozs7O1FBQ0wsd0JBQUMsWUFBRDtTQUNJLE1BQU07U0FDTixPQUFPLE1BQU0sV0FBVztTQUN4QixXQUFVLE1BQUssa0JBQWtCLE1BQU0sSUFBSSxXQUFXLEVBQUUsT0FBTyxLQUFLO1NBQ3BFLGFBQVk7U0FDWixXQUFVO1FBQ2I7Ozs7O1FBQ0Qsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxlQUFlO1VBQUUsc0JBQXNCLE1BQU0sV0FBVyxFQUFFO1VBQUcsd0JBQXdCLE1BQU0sRUFBRTtTQUFHO1NBQUcsV0FBVTttQkFBZ0k7UUFBZ0M7Ozs7O1FBQ25TLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNYLHdCQUFDLHFCQUFEO1VBQXFCLFNBQVMsS0FBSyxNQUFNLFdBQVcsTUFBTTtVQUFLLFdBQVU7U0FBcUI7Ozs7O1FBQzdGOzs7OztPQUNKOzs7Ozs7S0FFUjtPQS9YSSxNQUFNOzs7O1dBK1hWLENBQ1I7R0FDQTs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNYLHdCQUFDLFVBQUQ7S0FDSSxNQUFLO0tBQ0wsZUFBZSxlQUFlLE1BQU07S0FDcEMsV0FBVTtlQUhkLENBS0ksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OztlQUFDLHVCQUNkOzs7Ozs7R0FDUDs7Ozs7R0FFSiwrQkFBK0I7SUFDNUIsTUFBTSxTQUFTLE9BQU8sTUFBSyxNQUFLLEVBQUUsT0FBTyxvQkFBb0I7SUFDN0QsSUFBSSxDQUFDLFFBQVEsT0FBTztJQUNwQixPQUFPLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2xCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBbUQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXlCO1FBQXVCOzs7O2tCQUFDLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsZUFBZSx3QkFBd0IsSUFBSTtTQUFHLFdBQVU7bUJBQWdDO1FBQVM7Ozs7Z0JBQU07Ozs7OztPQUMvTyx3QkFBQyxxQkFBRDtRQUFxQixPQUFPO1FBQW9CLFVBQVU7T0FBd0I7Ozs7O09BQ2xGLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsZUFBZTtTQUNqQyxJQUFJLE9BQU8sU0FBUyxRQUFRO1VBQ3hCLE1BQU0sVUFBVSxtQkFBbUIsS0FBSztVQUN4QyxJQUFJLFNBQVMsa0JBQWtCLE9BQU8sSUFBSSxXQUFXLEdBQUcsT0FBTyxXQUFXLEdBQUcsSUFBSSxRQUFRLEdBQUc7U0FDaEcsT0FBTztVQUNILGtCQUFrQixPQUFPLElBQUksV0FBVyxrQkFBa0I7U0FDOUQ7U0FDQSx3QkFBd0IsSUFBSTtRQUNoQztRQUFHLFdBQVU7a0JBQWlGO09BQXdCOzs7OztNQUNySDs7Ozs7O0lBQ0o7Ozs7O0dBQ1QsRUFBQyxDQUFFO0VBQ0Y7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkJsb2NrUXVlc3Rpb25FZGl0b3IuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gICAgQ29kZSwgQ2FsY3VsYXRvciwgUGx1cywgVHJhc2gyLCBDaGV2cm9uVXAsIENoZXZyb25Eb3duLFxuICAgIFR5cGUsIFNwYXJrbGVzLCBCb2xkLCBJdGFsaWMsIFVuZGVybGluZSwgU3RyaWtldGhyb3VnaCxcbiAgICBBbGlnbkxlZnQsIEFsaWduQ2VudGVyLCBBbGlnblJpZ2h0LCBBbGlnbkp1c3RpZnksXG4gICAgTGlzdCwgTGlzdE9yZGVyZWQsIFF1b3RlLCBMaW5rIGFzIExpbmtJY29uLCBSZW1vdmVGb3JtYXR0aW5nLFxuICAgIFBhbGV0dGUsIEhpZ2hsaWdodGVyXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgUmljaENvbnRlbnRSZW5kZXJlciBmcm9tICcuLi8uLi91dGlscy9SaWNoQ29udGVudFJlbmRlcmVyJztcbmltcG9ydCBWaXN1YWxGb3JtdWxhRWRpdG9yIGZyb20gJy4vVmlzdWFsRm9ybXVsYUVkaXRvcic7XG5cbmNvbnN0IFRFWFRfQ09MT1JTID0gW1xuICAgIHsgbmFtZTogJ0RlZmF1bHQnLCB2YWx1ZTogJ2luaGVyaXQnLCBjbGFzczogJ2JnLXNsYXRlLTgwMCBkYXJrOmJnLXNsYXRlLTIwMCcgfSxcbiAgICB7IG5hbWU6ICdIaXRhbScsIHZhbHVlOiAnIzFlMjkzYicsIGNsYXNzOiAnYmctc2xhdGUtODAwJyB9LFxuICAgIHsgbmFtZTogJ01lcmFoJywgdmFsdWU6ICcjZWY0NDQ0JywgY2xhc3M6ICdiZy1yZWQtNTAwJyB9LFxuICAgIHsgbmFtZTogJ0hpamF1JywgdmFsdWU6ICcjMTBiOTgxJywgY2xhc3M6ICdiZy1lbWVyYWxkLTUwMCcgfSxcbiAgICB7IG5hbWU6ICdUZWFsJywgdmFsdWU6ICcjMDA4OTdiJywgY2xhc3M6ICdiZy1bIzAwODk3Yl0nIH0sXG4gICAgeyBuYW1lOiAnQmlydScsIHZhbHVlOiAnIzNiODJmNicsIGNsYXNzOiAnYmctYmx1ZS01MDAnIH0sXG4gICAgeyBuYW1lOiAnVW5ndScsIHZhbHVlOiAnIzhiNWNmNicsIGNsYXNzOiAnYmctcHVycGxlLTUwMCcgfSxcbiAgICB7IG5hbWU6ICdPcmFueWUnLCB2YWx1ZTogJyNmOTczMTYnLCBjbGFzczogJ2JnLW9yYW5nZS01MDAnIH0sXG5dO1xuXG5jb25zdCBISUdITElHSFRfQ09MT1JTID0gW1xuICAgIHsgbmFtZTogJ05vbmUnLCB2YWx1ZTogJ3RyYW5zcGFyZW50JywgY2xhc3M6ICdiZy10cmFuc3BhcmVudCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCcgfSxcbiAgICB7IG5hbWU6ICdLdW5pbmcnLCB2YWx1ZTogJyNmZWYwOGEnLCBjbGFzczogJ2JnLXllbGxvdy0yMDAnIH0sXG4gICAgeyBuYW1lOiAnSGlqYXUnLCB2YWx1ZTogJyNiYmY3ZDAnLCBjbGFzczogJ2JnLWdyZWVuLTIwMCcgfSxcbiAgICB7IG5hbWU6ICdCaXJ1JywgdmFsdWU6ICcjYmZkYmZlJywgY2xhc3M6ICdiZy1ibHVlLTIwMCcgfSxcbiAgICB7IG5hbWU6ICdQaW5rJywgdmFsdWU6ICcjZmJjZmU4JywgY2xhc3M6ICdiZy1waW5rLTIwMCcgfSxcbiAgICB7IG5hbWU6ICdPcmFueWUnLCB2YWx1ZTogJyNmZWQ3YWEnLCBjbGFzczogJ2JnLW9yYW5nZS0yMDAnIH0sXG4gICAgeyBuYW1lOiAnVW5ndScsIHZhbHVlOiAnI2U5ZDVmZicsIGNsYXNzOiAnYmctcHVycGxlLTIwMCcgfSxcbl07XG5cbi8qKlxuICogUGFyc2UgYW4gSFRNTCBvciBNYXJrZG93biBzdHJpbmcgaW50byBzdHJ1Y3R1cmVkIGNvbnRlbnQgYmxvY2tzXG4gKi9cbmZ1bmN0aW9uIHBhcnNlU3RyaW5nVG9CbG9ja3MocmF3U3RyKSB7XG4gICAgaWYgKCFyYXdTdHIgfHwgdHlwZW9mIHJhd1N0ciAhPT0gJ3N0cmluZycgfHwgIXJhd1N0ci50cmltKCkpIHtcbiAgICAgICAgcmV0dXJuIFt7IGlkOiBgYl8ke0RhdGUubm93KCl9XzBgLCB0eXBlOiAndGV4dCcsIGNvbnRlbnQ6ICcnIH1dO1xuICAgIH1cblxuICAgIGNvbnN0IGJsb2NrcyA9IFtdO1xuICAgIGNvbnN0IHRleHQgPSByYXdTdHIudHJpbSgpO1xuXG4gICAgLy8gQ29tYmluZWQgcmVnZXggZm9yIGNvZGUgYmxvY2tzLCBzdGFuZGFsb25lIG1hdGggYmxvY2tzXG4gICAgY29uc3QgY29tYmluZWRSZWdleCA9IC88cHJlPjxjb2RlKD86IGNsYXNzPVwibGFuZ3VhZ2UtKFthLXpBLVowLTlfIy1dKylcIik/PihbXFxzXFxTXSo/KTxcXC9jb2RlPjxcXC9wcmU+fGBgYChbYS16QS1aMC05XyMtXSopWyBcXHRcXHJcXG5dKihbXFxzXFxTXSo/KWBgYHw8cD5cXCRcXCQoW1xcc1xcU10qPylcXCRcXCQ8XFwvcD58XFwkXFwkKFtcXHNcXFNdKz8pXFwkXFwkL2dpO1xuXG4gICAgbGV0IGxhc3RJbmRleCA9IDA7XG4gICAgbGV0IG1hdGNoO1xuXG4gICAgd2hpbGUgKChtYXRjaCA9IGNvbWJpbmVkUmVnZXguZXhlYyh0ZXh0KSkgIT09IG51bGwpIHtcbiAgICAgICAgaWYgKG1hdGNoLmluZGV4ID4gbGFzdEluZGV4KSB7XG4gICAgICAgICAgICBjb25zdCBiZWZvcmVUZXh0ID0gdGV4dC5zdWJzdHJpbmcobGFzdEluZGV4LCBtYXRjaC5pbmRleCkudHJpbSgpO1xuICAgICAgICAgICAgaWYgKGJlZm9yZVRleHQpIHtcbiAgICAgICAgICAgICAgICBibG9ja3MucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIGlkOiBgYl8ke0RhdGUubm93KCl9XyR7YmxvY2tzLmxlbmd0aH1gLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGJlZm9yZVRleHRcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChtYXRjaFswXS5zdGFydHNXaXRoKCc8cHJlJykgfHwgbWF0Y2hbMF0uc3RhcnRzV2l0aCgnYGBgJykpIHtcbiAgICAgICAgICAgIGNvbnN0IGxhbmcgPSBtYXRjaFsxXSB8fCBtYXRjaFszXSB8fCAnamF2YXNjcmlwdCc7XG4gICAgICAgICAgICBjb25zdCBjb2RlID0gKG1hdGNoWzJdIHx8IG1hdGNoWzRdIHx8ICcnKS50cmltKCk7XG4gICAgICAgICAgICBibG9ja3MucHVzaCh7XG4gICAgICAgICAgICAgICAgaWQ6IGBiXyR7RGF0ZS5ub3coKX1fJHtibG9ja3MubGVuZ3RofWAsXG4gICAgICAgICAgICAgICAgdHlwZTogJ2NvZGUnLFxuICAgICAgICAgICAgICAgIGxhbmd1YWdlOiBsYW5nLFxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGNvZGVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZm9ybXVsYSA9IChtYXRjaFs1XSB8fCBtYXRjaFs2XSB8fCAnJykudHJpbSgpO1xuICAgICAgICAgICAgYmxvY2tzLnB1c2goe1xuICAgICAgICAgICAgICAgIGlkOiBgYl8ke0RhdGUubm93KCl9XyR7YmxvY2tzLmxlbmd0aH1gLFxuICAgICAgICAgICAgICAgIHR5cGU6ICdtYXRoJyxcbiAgICAgICAgICAgICAgICBjb250ZW50OiBmb3JtdWxhXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxhc3RJbmRleCA9IG1hdGNoLmluZGV4ICsgbWF0Y2hbMF0ubGVuZ3RoO1xuICAgIH1cblxuICAgIGlmIChsYXN0SW5kZXggPCB0ZXh0Lmxlbmd0aCkge1xuICAgICAgICBjb25zdCByZW1haW5pbmcgPSB0ZXh0LnN1YnN0cmluZyhsYXN0SW5kZXgpLnRyaW0oKTtcbiAgICAgICAgaWYgKHJlbWFpbmluZykge1xuICAgICAgICAgICAgYmxvY2tzLnB1c2goe1xuICAgICAgICAgICAgICAgIGlkOiBgYl8ke0RhdGUubm93KCl9XyR7YmxvY2tzLmxlbmd0aH1gLFxuICAgICAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICAgICAgICBjb250ZW50OiByZW1haW5pbmdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGJsb2Nrcy5sZW5ndGggPiAwID8gYmxvY2tzIDogW3sgaWQ6IGBiXyR7RGF0ZS5ub3coKX1fMGAsIHR5cGU6ICd0ZXh0JywgY29udGVudDogcmF3U3RyIH1dO1xufVxuXG4vKipcbiAqIFNlcmlhbGl6ZSBzdHJ1Y3R1cmVkIGJsb2NrcyBiYWNrIHRvIHN0YW5kYXJkIEhUTUwgc3RyaW5nXG4gKi9cbmZ1bmN0aW9uIHNlcmlhbGl6ZUJsb2Nrc1RvU3RyaW5nKGJsb2Nrcykge1xuICAgIGlmICghYmxvY2tzIHx8IGJsb2Nrcy5sZW5ndGggPT09IDApIHJldHVybiAnJztcblxuICAgIHJldHVybiBibG9ja3MubWFwKGIgPT4ge1xuICAgICAgICBpZiAoYi50eXBlID09PSAnY29kZScpIHtcbiAgICAgICAgICAgIGNvbnN0IGNsZWFuQ29kZSA9IGIuY29udGVudCA/IGIuY29udGVudC50cmltKCkgOiAnJztcbiAgICAgICAgICAgIHJldHVybiBgPHByZT48Y29kZSBjbGFzcz1cImxhbmd1YWdlLSR7Yi5sYW5ndWFnZSB8fCAnamF2YXNjcmlwdCd9XCI+JHtjbGVhbkNvZGV9PC9jb2RlPjwvcHJlPmA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGIudHlwZSA9PT0gJ21hdGgnKSB7XG4gICAgICAgICAgICBjb25zdCBmb3JtdWxhID0gYi5jb250ZW50ID8gYi5jb250ZW50LnRyaW0oKSA6ICcnO1xuICAgICAgICAgICAgcmV0dXJuIGA8cD4kJCR7Zm9ybXVsYX0kJDwvcD5gO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBiLmNvbnRlbnQgfHwgJyc7XG4gICAgfSkuam9pbignXFxuJyk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEJsb2NrUXVlc3Rpb25FZGl0b3IoeyB2YWx1ZSwgb25DaGFuZ2UsIHBsYWNlaG9sZGVyID0gJ1R1bGlza2FuIGlzaSBwZXJ0YW55YWFuLi4uJyB9KSB7XG4gICAgY29uc3QgW2Jsb2Nrcywgc2V0QmxvY2tzXSA9IHVzZVN0YXRlKCgpID0+IHBhcnNlU3RyaW5nVG9CbG9ja3ModmFsdWUpKTtcbiAgICBjb25zdCBbYWN0aXZlQmxvY2tJZCwgc2V0QWN0aXZlQmxvY2tJZF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbY29sb3JQaWNrZXJPcGVuLCBzZXRDb2xvclBpY2tlck9wZW5dID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2hpZ2hsaWdodFBpY2tlck9wZW4sIHNldEhpZ2hsaWdodFBpY2tlck9wZW5dID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW3Zpc3VhbEZvcm11bGFCbG9ja0lkLCBzZXRWaXN1YWxGb3JtdWxhQmxvY2tJZF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbdmlzdWFsRm9ybXVsYVZhbHVlLCBzZXRWaXN1YWxGb3JtdWxhVmFsdWVdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFthY3RpdmVGb3JtYXRzLCBzZXRBY3RpdmVGb3JtYXRzXSA9IHVzZVN0YXRlKHt9KTtcbiAgICBjb25zdCBlZGl0b3JSZWZzID0gdXNlUmVmKHt9KTtcbiAgICBjb25zdCBsYXN0RW1pdHRlZFZhbHVlUmVmID0gdXNlUmVmKHZhbHVlKTtcblxuICAgIGNvbnN0IHJlZnJlc2hBY3RpdmVGb3JtYXRzID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBzZWxlY3Rpb24gPSB3aW5kb3cuZ2V0U2VsZWN0aW9uKCk7XG4gICAgICAgIGNvbnN0IGVkaXRvciA9IHNlbGVjdGlvbj8uYW5jaG9yTm9kZT8ucGFyZW50RWxlbWVudD8uY2xvc2VzdD8uKCdbY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiXScpO1xuICAgICAgICBpZiAoIWVkaXRvcikgcmV0dXJuO1xuICAgICAgICBjb25zdCBibG9ja0lkID0gT2JqZWN0LmtleXMoZWRpdG9yUmVmcy5jdXJyZW50KS5maW5kKGlkID0+IGVkaXRvclJlZnMuY3VycmVudFtpZF0gPT09IGVkaXRvcik7XG4gICAgICAgIGlmICghYmxvY2tJZCkgcmV0dXJuO1xuICAgICAgICBjb25zdCBmb3JtYXRCbG9jayA9IFN0cmluZyhkb2N1bWVudC5xdWVyeUNvbW1hbmRWYWx1ZSgnZm9ybWF0QmxvY2snKSB8fCAnJykudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bPD5dL2csICcnKTtcbiAgICAgICAgc2V0QWN0aXZlRm9ybWF0cyh7XG4gICAgICAgICAgICBibG9ja0lkLFxuICAgICAgICAgICAgYm9sZDogZG9jdW1lbnQucXVlcnlDb21tYW5kU3RhdGUoJ2JvbGQnKSxcbiAgICAgICAgICAgIGl0YWxpYzogZG9jdW1lbnQucXVlcnlDb21tYW5kU3RhdGUoJ2l0YWxpYycpLFxuICAgICAgICAgICAgdW5kZXJsaW5lOiBkb2N1bWVudC5xdWVyeUNvbW1hbmRTdGF0ZSgndW5kZXJsaW5lJyksXG4gICAgICAgICAgICBzdHJpa2U6IGRvY3VtZW50LnF1ZXJ5Q29tbWFuZFN0YXRlKCdzdHJpa2VUaHJvdWdoJyksXG4gICAgICAgICAgICBhbGlnbjogWydjZW50ZXInLCAncmlnaHQnLCAnanVzdGlmeSddLmZpbmQodmFsdWUgPT4gZG9jdW1lbnQucXVlcnlDb21tYW5kU3RhdGUoYGp1c3RpZnkke3ZhbHVlWzBdLnRvVXBwZXJDYXNlKCl9JHt2YWx1ZS5zbGljZSgxKX1gKSkgfHwgJ2xlZnQnLFxuICAgICAgICAgICAgaGVhZGluZzogZm9ybWF0QmxvY2ssXG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdzZWxlY3Rpb25jaGFuZ2UnLCByZWZyZXNoQWN0aXZlRm9ybWF0cyk7XG4gICAgICAgIHJldHVybiAoKSA9PiBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdzZWxlY3Rpb25jaGFuZ2UnLCByZWZyZXNoQWN0aXZlRm9ybWF0cyk7XG4gICAgfSwgW10pO1xuXG4gICAgLy8gU3luYyBleHRlcm5hbCB2YWx1ZSBjaGFuZ2VzXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKHZhbHVlICE9PSBsYXN0RW1pdHRlZFZhbHVlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGxhc3RFbWl0dGVkVmFsdWVSZWYuY3VycmVudCA9IHZhbHVlO1xuICAgICAgICAgICAgY29uc3QgbmV3QmxvY2tzID0gcGFyc2VTdHJpbmdUb0Jsb2Nrcyh2YWx1ZSk7XG4gICAgICAgICAgICBzZXRCbG9ja3MobmV3QmxvY2tzKTtcbiAgICAgICAgICAgIG5ld0Jsb2Nrcy5mb3JFYWNoKGIgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChiLnR5cGUgPT09ICd0ZXh0JyAmJiBlZGl0b3JSZWZzLmN1cnJlbnRbYi5pZF0pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZWwgPSBlZGl0b3JSZWZzLmN1cnJlbnRbYi5pZF07XG4gICAgICAgICAgICAgICAgICAgIGlmIChlbCAmJiBlbC5pbm5lckhUTUwgIT09IChiLmNvbnRlbnQgfHwgJycpICYmIGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgIT09IGVsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbC5pbm5lckhUTUwgPSBiLmNvbnRlbnQgfHwgJyc7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sIFt2YWx1ZV0pO1xuXG4gICAgY29uc3QgdXBkYXRlQmxvY2tzQW5kRW1pdCA9IChuZXdCbG9ja3MpID0+IHtcbiAgICAgICAgc2V0QmxvY2tzKG5ld0Jsb2Nrcyk7XG4gICAgICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSBzZXJpYWxpemVCbG9ja3NUb1N0cmluZyhuZXdCbG9ja3MpO1xuICAgICAgICBsYXN0RW1pdHRlZFZhbHVlUmVmLmN1cnJlbnQgPSBzZXJpYWxpemVkO1xuICAgICAgICBpZiAob25DaGFuZ2UpIG9uQ2hhbmdlKHNlcmlhbGl6ZWQpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVVcGRhdGVCbG9jayA9IChpZCwgZmllbGQsIHZhbCkgPT4ge1xuICAgICAgICBjb25zdCBuZXh0ID0gYmxvY2tzLm1hcChiID0+IGIuaWQgPT09IGlkID8geyAuLi5iLCBbZmllbGRdOiB2YWwgfSA6IGIpO1xuICAgICAgICB1cGRhdGVCbG9ja3NBbmRFbWl0KG5leHQpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVBZGRCbG9jayA9ICh0eXBlLCBhZnRlckluZGV4ID0gbnVsbCkgPT4ge1xuICAgICAgICBjb25zdCBuZXdCbG9jayA9IHtcbiAgICAgICAgICAgIGlkOiBgYl8ke0RhdGUubm93KCl9XyR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyKDIsIDUpfWAsXG4gICAgICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICAgICAgbGFuZ3VhZ2U6IHR5cGUgPT09ICdjb2RlJyA/ICdqYXZhc2NyaXB0JyA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIGNvbnRlbnQ6IHR5cGUgPT09ICdtYXRoJyA/ICdcXFxcZnJhY3thfXtifScgOiAnJ1xuICAgICAgICB9O1xuXG4gICAgICAgIGxldCBuZXh0O1xuICAgICAgICBpZiAoYWZ0ZXJJbmRleCAhPT0gbnVsbCAmJiBhZnRlckluZGV4ID49IDApIHtcbiAgICAgICAgICAgIG5leHQgPSBbLi4uYmxvY2tzXTtcbiAgICAgICAgICAgIG5leHQuc3BsaWNlKGFmdGVySW5kZXggKyAxLCAwLCBuZXdCbG9jayk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXh0ID0gWy4uLmJsb2NrcywgbmV3QmxvY2tdO1xuICAgICAgICB9XG5cbiAgICAgICAgdXBkYXRlQmxvY2tzQW5kRW1pdChuZXh0KTtcbiAgICAgICAgc2V0QWN0aXZlQmxvY2tJZChuZXdCbG9jay5pZCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZURlbGV0ZUJsb2NrID0gKGlkKSA9PiB7XG4gICAgICAgIGlmIChibG9ja3MubGVuZ3RoIDw9IDEpIHtcbiAgICAgICAgICAgIHVwZGF0ZUJsb2Nrc0FuZEVtaXQoW3sgaWQ6IGBiXyR7RGF0ZS5ub3coKX1fMGAsIHR5cGU6ICd0ZXh0JywgY29udGVudDogJycgfV0pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5leHQgPSBibG9ja3MuZmlsdGVyKGIgPT4gYi5pZCAhPT0gaWQpO1xuICAgICAgICB1cGRhdGVCbG9ja3NBbmRFbWl0KG5leHQpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVNb3ZlQmxvY2sgPSAoaW5kZXgsIGRpcikgPT4ge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBpbmRleCArIGRpcjtcbiAgICAgICAgaWYgKHRhcmdldCA8IDAgfHwgdGFyZ2V0ID49IGJsb2Nrcy5sZW5ndGgpIHJldHVybjtcbiAgICAgICAgY29uc3QgbmV4dCA9IFsuLi5ibG9ja3NdO1xuICAgICAgICBbbmV4dFtpbmRleF0sIG5leHRbdGFyZ2V0XV0gPSBbbmV4dFt0YXJnZXRdLCBuZXh0W2luZGV4XV07XG4gICAgICAgIHVwZGF0ZUJsb2Nrc0FuZEVtaXQobmV4dCk7XG4gICAgfTtcblxuICAgIC8vIFdZU0lXWUcgRm9ybWF0dGluZyBIZWxwZXJzIGZvciBjb250ZW50RWRpdGFibGVcbiAgICBjb25zdCBhcHBseUZvcm1hdHRpbmcgPSAoYmxvY2tJZCwgZm9ybWF0VHlwZSwgcGF5bG9hZCA9IG51bGwpID0+IHtcbiAgICAgICAgY29uc3QgZWRpdG9yID0gZWRpdG9yUmVmcy5jdXJyZW50W2Jsb2NrSWRdO1xuICAgICAgICBpZiAoIWVkaXRvcikgcmV0dXJuO1xuXG4gICAgICAgIGVkaXRvci5mb2N1cygpO1xuICAgICAgICBjb25zdCBjdXJyZW50QmxvY2sgPSBTdHJpbmcoZG9jdW1lbnQucXVlcnlDb21tYW5kVmFsdWUoJ2Zvcm1hdEJsb2NrJykgfHwgJycpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvWzw+XS9nLCAnJyk7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRGb250U2l6ZSA9IFN0cmluZyhkb2N1bWVudC5xdWVyeUNvbW1hbmRWYWx1ZSgnZm9udFNpemUnKSB8fCAnJyk7XG5cbiAgICAgICAgc3dpdGNoIChmb3JtYXRUeXBlKSB7XG4gICAgICAgICAgICBjYXNlICdib2xkJzpcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5leGVjQ29tbWFuZCgnYm9sZCcsIGZhbHNlLCBudWxsKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2l0YWxpYyc6XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2l0YWxpYycsIGZhbHNlLCBudWxsKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3VuZGVybGluZSc6XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ3VuZGVybGluZScsIGZhbHNlLCBudWxsKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3N0cmlrZSc6XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ3N0cmlrZVRocm91Z2gnLCBmYWxzZSwgbnVsbCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdjb2xvcic6XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2ZvcmVDb2xvcicsIGZhbHNlLCBwYXlsb2FkID09PSAnaW5oZXJpdCcgPyAnIzFlMjkzYicgOiBwYXlsb2FkKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2hpZ2hsaWdodCc6XG4gICAgICAgICAgICAgICAgaWYgKHBheWxvYWQgPT09ICd0cmFuc3BhcmVudCcpIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ3JlbW92ZUZvcm1hdCcsIGZhbHNlLCBudWxsKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWRvY3VtZW50LmV4ZWNDb21tYW5kKCdoaWxpdGVDb2xvcicsIGZhbHNlLCBwYXlsb2FkKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2JhY2tDb2xvcicsIGZhbHNlLCBwYXlsb2FkKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2gyJzpcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5leGVjQ29tbWFuZCgnZm9ybWF0QmxvY2snLCBmYWxzZSwgY3VycmVudEJsb2NrID09PSAnaDInID8gJzxkaXY+JyA6ICc8aDI+Jyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdoMSc6XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2Zvcm1hdEJsb2NrJywgZmFsc2UsIGN1cnJlbnRCbG9jayA9PT0gJ2gxJyA/ICc8ZGl2PicgOiAnPGgxPicpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnaDMnOlxuICAgICAgICAgICAgICAgIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdmb3JtYXRCbG9jaycsIGZhbHNlLCBjdXJyZW50QmxvY2sgPT09ICdoMycgPyAnPGRpdj4nIDogJzxoMz4nKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2NsZWFySGVhZGluZyc6XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2Zvcm1hdEJsb2NrJywgZmFsc2UsICc8ZGl2PicpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnc21hbGwnOlxuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50Rm9udFNpemUgPT09ICcyJykgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ3JlbW92ZUZvcm1hdCcsIGZhbHNlLCBudWxsKTtcbiAgICAgICAgICAgICAgICBlbHNlIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdmb250U2l6ZScsIGZhbHNlLCAnMicpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnYWxpZ24nOlxuICAgICAgICAgICAgICAgIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdqdXN0aWZ5JyArIChwYXlsb2FkID09PSAnY2VudGVyJyA/ICdDZW50ZXInIDogcGF5bG9hZCA9PT0gJ3JpZ2h0JyA/ICdSaWdodCcgOiBwYXlsb2FkID09PSAnanVzdGlmeScgPyAnRnVsbCcgOiAnTGVmdCcpLCBmYWxzZSwgbnVsbCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd1bCc6XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2luc2VydFVub3JkZXJlZExpc3QnLCBmYWxzZSwgbnVsbCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdvbCc6XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2luc2VydE9yZGVyZWRMaXN0JywgZmFsc2UsIG51bGwpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAncXVvdGUnOlxuICAgICAgICAgICAgICAgIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdmb3JtYXRCbG9jaycsIGZhbHNlLCAnPGJsb2NrcXVvdGU+Jyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdjb2RlJzpcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5leGVjQ29tbWFuZCgnZm9ybWF0QmxvY2snLCBmYWxzZSwgJzxwcmU+Jyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdtYXRoJzoge1xuICAgICAgICAgICAgICAgIGNvbnN0IHNlbCA9IHdpbmRvdy5nZXRTZWxlY3Rpb24oKTtcbiAgICAgICAgICAgICAgICBjb25zdCBzZWxUZXh0ID0gc2VsID8gc2VsLnRvU3RyaW5nKCkgOiAnJztcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5leGVjQ29tbWFuZCgnaW5zZXJ0SFRNTCcsIGZhbHNlLCBgJCR7c2VsVGV4dCB8fCAneF4yJ30kYCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdsaW5rJzoge1xuICAgICAgICAgICAgICAgIGNvbnN0IHVybCA9IHdpbmRvdy5wcm9tcHQoJ01hc3Vra2FuIGFsYW1hdCBVUkwgdGF1dGFuIChjb250b2g6IGh0dHBzOi8vZ29vZ2xlLmNvbSk6JywgJ2h0dHBzOi8vJyk7XG4gICAgICAgICAgICAgICAgaWYgKHVybCkge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5leGVjQ29tbWFuZCgnY3JlYXRlTGluaycsIGZhbHNlLCB1cmwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ2NsZWFyJzpcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5leGVjQ29tbWFuZCgncmVtb3ZlRm9ybWF0JywgZmFsc2UsIG51bGwpO1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdmb3JtYXRCbG9jaycsIGZhbHNlLCAnPGRpdj4nKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaGFuZGxlVXBkYXRlQmxvY2soYmxvY2tJZCwgJ2NvbnRlbnQnLCBlZGl0b3IuaW5uZXJIVE1MKTtcbiAgICAgICAgc2V0VGltZW91dChyZWZyZXNoQWN0aXZlRm9ybWF0cywgMCk7XG4gICAgICAgIHNldENvbG9yUGlja2VyT3BlbihudWxsKTtcbiAgICAgICAgc2V0SGlnaGxpZ2h0UGlja2VyT3BlbihudWxsKTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgYmctc2xhdGUtNTAvNTAgZGFyazpiZy1zbGF0ZS05MDAvNTAgcC0zIHNtOnAtNCBzcGFjZS15LTMgZm9udC1zYW5zIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHsvKiBRdWljayBBZGQgVG9vbGJhciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yIHBiLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFkZEJsb2NrKCd0ZXh0Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgc2hhZG93LTJ4cyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlRhbWJhaCBCbG9rIFRla3MgQmViYXMgLyBXWVNJV1lHXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cGUgc2l6ZT17MTN9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPisgVGVrcyBXWVNJV1lHPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFkZEJsb2NrKCdjb2RlJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgc2hhZG93LTJ4cyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlRhbWJhaCBCbG9rIEtvZGUgVGVyaXNvbGFzaSAoU3ludGF4IEhpZ2hsaWdodGVkKVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb2RlIHNpemU9ezEzfSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4rIEJsb2sgS29kZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBZGRCbG9jaygnbWF0aCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHNoYWRvdy0yeHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJUYW1iYWggQmxvayBSdW11cyBNYXRlbWF0aWthIChLYVRlWClcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FsY3VsYXRvciBzaXplPXsxM30gY2xhc3NOYW1lPVwidGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPisgUnVtdXMgS2FUZVg8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBCbG9ja3MgTGlzdCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zLjVcIj5cbiAgICAgICAgICAgICAgICB7YmxvY2tzLm1hcCgoYmxvY2ssIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2Jsb2NrLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlQmxvY2tJZChibG9jay5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSByb3VuZGVkLTJ4bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVCbG9ja0lkID09PSBibG9jay5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItWyMwMDg5N0JdIGRhcms6Ym9yZGVyLXRlYWwtNTAwIHJpbmctMiByaW5nLXRlYWwtNTAwLzIwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAvODAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAvODAgaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCBkYXJrOmhvdmVyOmJvcmRlci1zbGF0ZS02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9IHAtMy41IHNwYWNlLXktM2B9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCbG9jayBIZWFkZXIgQ29udHJvbHMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMC82MCBwYi0yIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgcHktMC41IHJvdW5kZWQtbGcgdGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9jay50eXBlID09PSAnY29kZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC82MCB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGJsb2NrLnR5cGUgPT09ICdtYXRoJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmb250LWJvbGQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtibG9jay50eXBlID09PSAnY29kZScgPyAnQmxvayBLb2RlJyA6IGJsb2NrLnR5cGUgPT09ICdtYXRoJyA/ICdSdW11cyBLYVRlWCcgOiBgQmxvayBUZWtzICMke2lkeCArIDF9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtibG9jay50eXBlID09PSAnY29kZScgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtibG9jay5sYW5ndWFnZSB8fCAnamF2YXNjcmlwdCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gaGFuZGxlVXBkYXRlQmxvY2soYmxvY2suaWQsICdsYW5ndWFnZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgcHgtMiBweS0wLjUgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctWyMwMDg5N0JdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiamF2YXNjcmlwdFwiPkphdmFTY3JpcHQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicHl0aG9uXCI+UHl0aG9uPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNzaGFycFwiPkMjPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImh0bWxcIj5IVE1MIC8gQ1NTPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInNxbFwiPlNRTDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJqYXZhXCI+SmF2YTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjcHBcIj5DKys8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwianNvblwiPkpTT048L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicGhwXCI+UEhQPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVNb3ZlQmxvY2soaWR4LCAtMSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aWR4ID09PSAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgZGlzYWJsZWQ6b3BhY2l0eS0zMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlBpbmRhaCBrZSBBdGFzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25VcCBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTW92ZUJsb2NrKGlkeCwgMSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aWR4ID09PSBibG9ja3MubGVuZ3RoIC0gMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIGRpc2FibGVkOm9wYWNpdHktMzAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJQaW5kYWgga2UgQmF3YWhcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZUJsb2NrKGJsb2NrLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXJlZC00MDAgaG92ZXI6dGV4dC1yZWQtNjAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiSGFwdXMgQmxva1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDilIDilIAgMS4gVEVYVCBCTE9DSyBXSVRIIEZVTEwgV1lTSVdZRyBGT1JNQVRUSU5HIFRPT0xCQVIg4pSA4pSAICovfVxuICAgICAgICAgICAgICAgICAgICAgICAge2Jsb2NrLnR5cGUgPT09ICd0ZXh0JyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSaWNoIEZvcm1hdHRpbmcgVG9vbGJhciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBvbk1vdXNlRG93bj17ZSA9PiBlLnByZXZlbnREZWZhdWx0KCl9IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMSBwLTEuNSBiZy1zbGF0ZS0xMDAvODAgZGFyazpiZy1zbGF0ZS05MDAvODAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVGV4dCBTdHlsZXMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYXBwbHlGb3JtYXR0aW5nKGJsb2NrLmlkLCAnYm9sZCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgaG92ZXI6Ymctd2hpdGUgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7YWN0aXZlRm9ybWF0cy5ibG9ja0lkID09PSBibG9jay5pZCAmJiBhY3RpdmVGb3JtYXRzLmJvbGQgPyAnYmctdGVhbC0xMDAgdGV4dC10ZWFsLTcwMCByaW5nLTEgcmluZy10ZWFsLTQwMCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVGViYWwgKEJvbGQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm9sZCBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ2l0YWxpYycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgaG92ZXI6Ymctd2hpdGUgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7YWN0aXZlRm9ybWF0cy5ibG9ja0lkID09PSBibG9jay5pZCAmJiBhY3RpdmVGb3JtYXRzLml0YWxpYyA/ICdiZy10ZWFsLTEwMCB0ZXh0LXRlYWwtNzAwIHJpbmctMSByaW5nLXRlYWwtNDAwJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJNaXJpbmcgKEl0YWxpYylcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJdGFsaWMgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhcHBseUZvcm1hdHRpbmcoYmxvY2suaWQsICd1bmRlcmxpbmUnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke2FjdGl2ZUZvcm1hdHMuYmxvY2tJZCA9PT0gYmxvY2suaWQgJiYgYWN0aXZlRm9ybWF0cy51bmRlcmxpbmUgPyAnYmctdGVhbC0xMDAgdGV4dC10ZWFsLTcwMCByaW5nLTEgcmluZy10ZWFsLTQwMCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiR2FyaXMgQmF3YWggKFVuZGVybGluZSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxVbmRlcmxpbmUgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhcHBseUZvcm1hdHRpbmcoYmxvY2suaWQsICdzdHJpa2UnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke2FjdGl2ZUZvcm1hdHMuYmxvY2tJZCA9PT0gYmxvY2suaWQgJiYgYWN0aXZlRm9ybWF0cy5zdHJpa2UgPyAnYmctdGVhbC0xMDAgdGV4dC10ZWFsLTcwMCByaW5nLTEgcmluZy10ZWFsLTQwMCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ29yZXQgKFN0cmlrZXRocm91Z2gpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3RyaWtldGhyb3VnaCBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNCB3LXB4IGJnLXNsYXRlLTMwMCBkYXJrOmJnLXNsYXRlLTcwMCBteC0wLjVcIiAvPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQ29sb3JzICYgSGlnaGxpZ2h0cyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDb2xvclBpY2tlck9wZW4oY29sb3JQaWNrZXJPcGVuID09PSBibG9jay5pZCA/IG51bGwgOiBibG9jay5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRIaWdobGlnaHRQaWNrZXJPcGVuKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0wLjUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIldhcm5hIEZvbnQgVGVrc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGFsZXR0ZSBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb2xvclBpY2tlck9wZW4gPT09IGJsb2NrLmlkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtZnVsbCBsZWZ0LTAgbXQtMSB6LTMwIHAtMiBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBzaGFkb3cteGwgZmxleCBnYXAtMS41IGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1RFWFRfQ09MT1JTLm1hcChjID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Yy5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYXBwbHlGb3JtYXR0aW5nKGJsb2NrLmlkLCAnY29sb3InLCBjLnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy01IGgtNSByb3VuZGVkLWZ1bGwgJHtjLmNsYXNzfSBob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzYH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2MubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEhpZ2hsaWdodFBpY2tlck9wZW4oaGlnaGxpZ2h0UGlja2VyT3BlbiA9PT0gYmxvY2suaWQgPyBudWxsIDogYmxvY2suaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29sb3JQaWNrZXJPcGVuKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRleHQtYW1iZXItNTAwIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0wLjUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIldhcm5hIFNvcm90IChIaWdobGlnaHQgQmFja2dyb3VuZClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEhpZ2hsaWdodGVyIHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2hpZ2hsaWdodFBpY2tlck9wZW4gPT09IGJsb2NrLmlkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtZnVsbCBsZWZ0LTAgbXQtMSB6LTMwIHAtMiBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBzaGFkb3cteGwgZmxleCBnYXAtMS41IGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge0hJR0hMSUdIVF9DT0xPUlMubWFwKGggPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtoLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhcHBseUZvcm1hdHRpbmcoYmxvY2suaWQsICdoaWdobGlnaHQnLCBoLnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy01IGgtNSByb3VuZGVkLWZ1bGwgJHtoLmNsYXNzfSBob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzYH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2gubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQgdy1weCBiZy1zbGF0ZS0zMDAgZGFyazpiZy1zbGF0ZS03MDAgbXgtMC41XCIgLz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZvbnQgU2l6ZSAmIEhlYWRpbmdzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gYXBwbHlGb3JtYXR0aW5nKGJsb2NrLmlkLCAnY2xlYXJIZWFkaW5nJyl9IGNsYXNzTmFtZT17YHB4LTEuNSBweS0xIHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBjdXJzb3ItcG9pbnRlciAke2FjdGl2ZUZvcm1hdHMuYmxvY2tJZCA9PT0gYmxvY2suaWQgJiYgIVsnaDEnLCAnaDInLCAnaDMnXS5pbmNsdWRlcyhhY3RpdmVGb3JtYXRzLmhlYWRpbmcpID8gJ2JnLXRlYWwtMTAwIHRleHQtdGVhbC03MDAgcmluZy0xIHJpbmctdGVhbC00MDAnIDogJyd9YH0gdGl0bGU9XCJLZW1iYWxpIGtlIHRla3Mgbm9ybWFsXCI+Tm9ybWFsPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBhcHBseUZvcm1hdHRpbmcoYmxvY2suaWQsICdoMScpfSBjbGFzc05hbWU9e2BweC0xLjUgcHktMSB0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIHJvdW5kZWQtbGcgaG92ZXI6Ymctd2hpdGUgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgY3Vyc29yLXBvaW50ZXIgJHthY3RpdmVGb3JtYXRzLmJsb2NrSWQgPT09IGJsb2NrLmlkICYmIGFjdGl2ZUZvcm1hdHMuaGVhZGluZyA9PT0gJ2gxJyA/ICdiZy10ZWFsLTEwMCB0ZXh0LXRlYWwtNzAwIHJpbmctMSByaW5nLXRlYWwtNDAwJyA6ICcnfWB9IHRpdGxlPVwiSnVkdWwgSDFcIj5IMTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ2gyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMS41IHB5LTEgdGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgcm91bmRlZC1sZyBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke2FjdGl2ZUZvcm1hdHMuYmxvY2tJZCA9PT0gYmxvY2suaWQgJiYgYWN0aXZlRm9ybWF0cy5oZWFkaW5nID09PSAnaDInID8gJ2JnLXRlYWwtMTAwIHRleHQtdGVhbC03MDAgcmluZy0xIHJpbmctdGVhbC00MDAnIDogJyd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkp1ZHVsIEJlc2FyIChIMilcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEgyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhcHBseUZvcm1hdHRpbmcoYmxvY2suaWQsICdoMycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTEuNSBweS0xIHRleHQtWzExcHhdIGZvbnQtZXh0cmFib2xkIHJvdW5kZWQtbGcgaG92ZXI6Ymctd2hpdGUgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHthY3RpdmVGb3JtYXRzLmJsb2NrSWQgPT09IGJsb2NrLmlkICYmIGFjdGl2ZUZvcm1hdHMuaGVhZGluZyA9PT0gJ2gzJyA/ICdiZy10ZWFsLTEwMCB0ZXh0LXRlYWwtNzAwIHJpbmctMSByaW5nLXRlYWwtNDAwJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJKdWR1bCBTZWRhbmcgKEgzKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSDNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ3NtYWxsJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMS41IHB5LTEgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlRla3MgS2VjaWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEtlY2lsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQgdy1weCBiZy1zbGF0ZS0zMDAgZGFyazpiZy1zbGF0ZS03MDAgbXgtMC41XCIgLz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRleHQgQWxpZ25tZW50ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ2FsaWduJywgJ2xlZnQnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7YWN0aXZlRm9ybWF0cy5ibG9ja0lkID09PSBibG9jay5pZCAmJiBhY3RpdmVGb3JtYXRzLmFsaWduID09PSAnbGVmdCcgPyAnYmctdGVhbC0xMDAgdGV4dC10ZWFsLTcwMCByaW5nLTEgcmluZy10ZWFsLTQwMCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmF0YSBLaXJpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxpZ25MZWZ0IHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYXBwbHlGb3JtYXR0aW5nKGJsb2NrLmlkLCAnYWxpZ24nLCAnY2VudGVyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1sZyBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke2FjdGl2ZUZvcm1hdHMuYmxvY2tJZCA9PT0gYmxvY2suaWQgJiYgYWN0aXZlRm9ybWF0cy5hbGlnbiA9PT0gJ2NlbnRlcicgPyAnYmctdGVhbC0xMDAgdGV4dC10ZWFsLTcwMCByaW5nLTEgcmluZy10ZWFsLTQwMCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmF0YSBUZW5nYWhcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGlnbkNlbnRlciBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ2FsaWduJywgJ3JpZ2h0Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1sZyBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke2FjdGl2ZUZvcm1hdHMuYmxvY2tJZCA9PT0gYmxvY2suaWQgJiYgYWN0aXZlRm9ybWF0cy5hbGlnbiA9PT0gJ3JpZ2h0JyA/ICdiZy10ZWFsLTEwMCB0ZXh0LXRlYWwtNzAwIHJpbmctMSByaW5nLXRlYWwtNDAwJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSYXRhIEthbmFuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxpZ25SaWdodCBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ2FsaWduJywgJ2p1c3RpZnknKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7YWN0aXZlRm9ybWF0cy5ibG9ja0lkID09PSBibG9jay5pZCAmJiBhY3RpdmVGb3JtYXRzLmFsaWduID09PSAnanVzdGlmeScgPyAnYmctdGVhbC0xMDAgdGV4dC10ZWFsLTcwMCByaW5nLTEgcmluZy10ZWFsLTQwMCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmF0YSBLaXJpIEthbmFuIChKdXN0aWZ5KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFsaWduSnVzdGlmeSBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNCB3LXB4IGJnLXNsYXRlLTMwMCBkYXJrOmJnLXNsYXRlLTcwMCBteC0wLjVcIiAvPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTGlzdHMgJiBJbnNlcnRzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ3VsJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEYWZ0YXIgUG9pbiAoQnVsbGV0IExpc3QpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlzdCBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ29sJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEYWZ0YXIgTm9tb3IgKE51bWJlcmVkIExpc3QpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlzdE9yZGVyZWQgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhcHBseUZvcm1hdHRpbmcoYmxvY2suaWQsICdxdW90ZScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgaG92ZXI6Ymctd2hpdGUgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiS3V0aXBhbiAoQmxvY2txdW90ZSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxRdW90ZSBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ2xpbmsnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlNpc2lwa2FuIFRhdXRhbiBVUkxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rSWNvbiBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5Rm9ybWF0dGluZyhibG9jay5pZCwgJ21hdGgnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTEgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlNpc2lwa2FuIFJ1bXVzIElubGluZSAoJHJ1bXVzJClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICRSdW11cyRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0VmlzdWFsRm9ybXVsYVZhbHVlKCcnKTsgc2V0VmlzdWFsRm9ybXVsYUJsb2NrSWQoYmxvY2suaWQpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDAgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRvciBSdW11cyBWaXN1YWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNCB3LXB4IGJnLXNsYXRlLTMwMCBkYXJrOmJnLXNsYXRlLTcwMCBteC0wLjVcIiAvPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYXBwbHlGb3JtYXR0aW5nKGJsb2NrLmlkLCAnY2xlYXInKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcmVkLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJIYXB1cyBGb3JtYXQgKENsZWFyIEZvcm1hdHRpbmcpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVtb3ZlRm9ybWF0dGluZyBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTmF0aXZlIHJpY2gtdGV4dCBzdXJmYWNlOiB0b29sYmFyIGNvbW1hbmRzIG9wZXJhdGUgb24gdGhpcyBET00uICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWY9e2VsID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0b3JSZWZzLmN1cnJlbnRbYmxvY2suaWRdID0gZWw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVsICYmIGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgIT09IGVsICYmIGVsLmlubmVySFRNTCAhPT0gKGJsb2NrLmNvbnRlbnQgfHwgJycpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsLmlubmVySFRNTCA9IGJsb2NrLmNvbnRlbnQgfHwgJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnRFZGl0YWJsZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VwcHJlc3NDb250ZW50RWRpdGFibGVXYXJuaW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlPVwidGV4dGJveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLW11bHRpbGluZT1cInRydWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1wbGFjZWhvbGRlcj17cGxhY2Vob2xkZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbklucHV0PXtlID0+IGhhbmRsZVVwZGF0ZUJsb2NrKGJsb2NrLmlkLCAnY29udGVudCcsIGUuY3VycmVudFRhcmdldC5pbm5lckhUTUwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Gb2N1cz17KCkgPT4gc2V0QWN0aXZlQmxvY2tJZChibG9jay5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtdXAtcmljaC1lZGl0b3IgbWluLWgtMjAgdy1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yLjUgdGV4dC14cyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql0gZGFyazpmb2N1czpyaW5nLXRlYWwtNDAwIGxlYWRpbmctcmVsYXhlZCB0cmFuc2l0aW9uLWNvbG9ycyBlbXB0eTpiZWZvcmU6Y29udGVudC1bYXR0cihkYXRhLXBsYWNlaG9sZGVyKV0gZW1wdHk6YmVmb3JlOnRleHQtc2xhdGUtNDAwIGRhcms6ZW1wdHk6YmVmb3JlOnRleHQtc2xhdGUtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDilIDilIAgMi4gQ09ERSBCTE9DSyAoSVNPTEFURUQpIOKUgOKUgCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtibG9jay50eXBlID09PSAnY29kZScgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXs1fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtibG9jay5jb250ZW50IHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZVVwZGF0ZUJsb2NrKGJsb2NrLmlkLCAnY29udGVudCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi8vIFR1bGlzIGF0YXUgdGVtcGVsIGtvZGUgc3VtYmVyIGRpIHNpbmkuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgZm9udC1tb25vIHRleHQteHMgdGV4dC10ZWFsLTMwMCBiZy10cmFuc3BhcmVudCBmb2N1czpvdXRsaW5lLW5vbmUgcmVzaXplLXkgbGVhZGluZy1yZWxheGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcGVsbENoZWNrPXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5UZWtzIHNlYmVsdW0gJiBzZXN1ZGFoIGJsb2sga29kZSBpbmkgdGVycGlzYWggc2VjYXJhIGFtYW4gdGFucGEgdGVydGVsYW4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFkZEJsb2NrKCd0ZXh0JywgaWR4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgZm9udC1ib2xkIGhvdmVyOnVuZGVybGluZSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKyBUYW1iYWggVGVrcyBkaSBCYXdhaCBLb2RlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pSA4pSAIDMuIE1BVEggQkxPQ0sgKEtBVEVYKSDilIDilIAgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICB7YmxvY2sudHlwZSA9PT0gJ21hdGgnICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbDogJ1BlY2FoYW4nLCBzOiAnXFxcXGZyYWN7YX17Yn0nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsOiAnQWthciDiiJonLCBzOiAnXFxcXHNxcnR7eH0nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsOiAneMKyJywgczogJ3heMicgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGw6ICd44oKBJywgczogJ3hfMScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGw6ICfiiJEnLCBzOiAnXFxcXHN1bV97aT0xfV5uJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbDogJ+KIqycsIHM6ICdcXFxcaW50X3thfV5iJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbDogJ8KxJywgczogJ1xcXFxwbScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGw6ICfPgCcsIHM6ICdcXFxccGknIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsOiAn4oieJywgczogJ1xcXFxpbmZ0eScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChzeW0sIHNJZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17c0lkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZUJsb2NrKGJsb2NrLmlkLCAnY29udGVudCcsIChibG9jay5jb250ZW50IHx8ICcnKSArIHN5bS5zKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTYwMCByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3ltLmx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtibG9jay5jb250ZW50IHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gaGFuZGxlVXBkYXRlQmxvY2soYmxvY2suaWQsICdjb250ZW50JywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFa3NwcmVzaSBMYVRlWCwgY29udG9oOiBcXGZyYWN7LWIgXFxwbSBcXHNxcnR7Yl4yLTRhY319ezJhfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZm9udC1tb25vIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTkwMC82MCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRWaXN1YWxGb3JtdWxhVmFsdWUoYmxvY2suY29udGVudCB8fCAnJyk7IHNldFZpc3VhbEZvcm11bGFCbG9ja0lkKGJsb2NrLmlkKTsgfX0gY2xhc3NOYW1lPVwicHgtMi41IHB5LTEuNSByb3VuZGVkLWxnIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgY3Vyc29yLXBvaW50ZXJcIj5CdWthIEVkaXRvciBSdW11cyBWaXN1YWw8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctdGVhbC01MC80MCBkYXJrOmJnLXRlYWwtOTUwLzQwIGJvcmRlciBib3JkZXItdGVhbC0xMDAgZGFyazpib3JkZXItdGVhbC05MDAvNjAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17YCQkJHtibG9jay5jb250ZW50IHx8ICcuLi4nfSQkYH0gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBCb3R0b20gQWRkIEJhciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwLzYwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFkZEJsb2NrKCd0ZXh0Jyl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxQbHVzIHNpemU9ezEzfSAvPiBUYW1iYWggUGFyYWdyYWYgVGVrc1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHt2aXN1YWxGb3JtdWxhQmxvY2tJZCAmJiAoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGJsb2Nrcy5maW5kKGIgPT4gYi5pZCA9PT0gdmlzdWFsRm9ybXVsYUJsb2NrSWQpO1xuICAgICAgICAgICAgICAgIGlmICghdGFyZ2V0KSByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgYmctYmxhY2svNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCB3LWZ1bGwgbWF4LXcteGwgbWF4LWgtWzkwdmhdIG92ZXJmbG93LXktYXV0byBwLTUgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPjxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtZXh0cmFib2xkXCI+RWRpdG9yIFJ1bXVzIFZpc3VhbDwvaDM+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0VmlzdWFsRm9ybXVsYUJsb2NrSWQobnVsbCl9IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGN1cnNvci1wb2ludGVyXCI+4pyVPC9idXR0b24+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VmlzdWFsRm9ybXVsYUVkaXRvciB2YWx1ZT17dmlzdWFsRm9ybXVsYVZhbHVlfSBvbkNoYW5nZT17c2V0VmlzdWFsRm9ybXVsYVZhbHVlfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0YXJnZXQudHlwZSA9PT0gJ3RleHQnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNuaXBwZXQgPSB2aXN1YWxGb3JtdWxhVmFsdWUudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc25pcHBldCkgaGFuZGxlVXBkYXRlQmxvY2sodGFyZ2V0LmlkLCAnY29udGVudCcsIGAke3RhcmdldC5jb250ZW50IHx8ICcnfSAkJHtzbmlwcGV0fSQgYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlQmxvY2sodGFyZ2V0LmlkLCAnY29udGVudCcsIHZpc3VhbEZvcm11bGFWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZpc3VhbEZvcm11bGFCbG9ja0lkKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX0gY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcm91bmRlZC14bCBiZy10ZWFsLTYwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIGN1cnNvci1wb2ludGVyXCI+U2lzaXBrYW4ga2UgU29hbDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj47XG4gICAgICAgICAgICB9KSgpfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuIl19