import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const _jsxDEV = __vite__cjsImport24_react_jsxDevRuntime["jsxDEV"];import { Routes, Route, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import Login from "/src/features/auth/Login.jsx";
import Register from "/src/features/auth/Register.jsx";
import Verify from "/src/features/auth/VerifyRegister.jsx";
import UserHome from "/src/features/dashboard/userDashboard/userhome.jsx";
import MyForms from "/src/features/dashboard/userDashboard/myForms.jsx";
import TemplatesPage from "/src/features/dashboard/userDashboard/templateForm.jsx";
import UserHistory from "/src/features/dashboard/userDashboard/userHistory.jsx";
import ResponsesPage from "/src/features/dashboard/userDashboard/responsesPage.jsx";
import CreateForm from "/src/features/form-builder/CreateForm.jsx";
import FormBuilder from "/src/features/form-builder/FormBuilder.jsx";
import FormResponsesPage from "/src/features/form-responses/FormResponsesPage.jsx?t=1789530336114";
import FormAnalyticsPage from "/src/features/form-responses/FormAnalyticsPage.jsx";
import FormRunnerPage from "/src/features/form-runner/FormRunnerPage.jsx?t=1789530336151";
import FormResultPage from "/src/features/form-runner/FormResultPage.jsx";
import AdminDashboardPage from "/src/features/admin/AdminDashboardPage.jsx";
import ProfilePage from "/src/features/profile/ProfilePage.jsx";
import ForgotPasswordPage from "/src/features/auth/ForgotPasswordPage.jsx";
import LandingPage from "/src/features/landing/LandingPage.jsx?t=1789530336154";
import AiChatPage from "/src/features/ai-chat/AiChatPage.jsx";
import ProtectedRoute from "/src/components/ui/ProtectedRoute.jsx";
import ErrorBoundary from "/src/components/ui/ErrorBoundary.jsx";
import OfflineBanner from "/src/components/ui/OfflineBanner.jsx";
import { isAuthenticated } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/App.jsx";
import __vite__cjsImport24_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
function App() {
	return /* @__PURE__ */ _jsxDEV(ErrorBoundary, { children: [/* @__PURE__ */ _jsxDEV(OfflineBanner, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/",
			element: isAuthenticated() ? /* @__PURE__ */ _jsxDEV(Navigate, {
				to: "/dashboard",
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 52
			}, this) : /* @__PURE__ */ _jsxDEV(LandingPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 91
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 37
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/register",
			element: /* @__PURE__ */ _jsxDEV(Register, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 40
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/verify",
			element: /* @__PURE__ */ _jsxDEV(Verify, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 38
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/forgot-password",
			element: /* @__PURE__ */ _jsxDEV(ForgotPasswordPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 47
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/f/:formLink",
			element: /* @__PURE__ */ _jsxDEV(FormRunnerPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 43
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/f/:formLink/result/:responseId",
			element: /* @__PURE__ */ _jsxDEV(FormResultPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 62
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/dashboard",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(UserHome, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 57
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 41
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/my-forms",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(MyForms, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 56
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 40
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/templates",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(TemplatesPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 57
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 41
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/responses",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(ResponsesPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 57
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 41
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/history",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(UserHistory, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 55
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 39
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/create-form",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(CreateForm, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 59
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 43
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/forms/:id/edit",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(FormBuilder, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 62
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 46
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/forms/:id/responses",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(FormResponsesPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 67
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 51
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/forms/:id/analytics",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(FormAnalyticsPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 67
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 51
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/admin",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(AdminDashboardPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 53
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 37
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/ai-chat",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(AiChatPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 55
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 39
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/profile",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(ProfilePage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 55
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 39
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx?t=1789530336154";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLE9BQU8sZ0JBQWdCO0FBQ3hDLE9BQU8sV0FBVztBQUNsQixPQUFPLGNBQWM7QUFDckIsT0FBTyxZQUFZO0FBQ25CLE9BQU8sY0FBYztBQUNyQixPQUFPLGFBQWE7QUFDcEIsT0FBTyxtQkFBbUI7QUFDMUIsT0FBTyxpQkFBaUI7QUFDeEIsT0FBTyxtQkFBbUI7QUFDMUIsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyxpQkFBaUI7QUFDeEIsT0FBTyx1QkFBdUI7QUFDOUIsT0FBTyx1QkFBdUI7QUFDOUIsT0FBTyxvQkFBb0I7QUFDM0IsT0FBTyxvQkFBb0I7QUFDM0IsT0FBTyx3QkFBd0I7QUFDL0IsT0FBTyxpQkFBaUI7QUFDeEIsT0FBTyx3QkFBd0I7QUFDL0IsT0FBTyxpQkFBaUI7QUFDeEIsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyxvQkFBb0I7QUFDM0IsT0FBTyxtQkFBbUI7QUFDMUIsT0FBTyxtQkFBbUI7QUFDMUIsU0FBUyx1QkFBdUI7OztBQUVoQyxTQUFTLE1BQU07Q0FDYixPQUNFLHdCQUFDLGVBQUQsYUFDRSx3QkFBQyxlQUFELENBQWdCOzs7O1dBQ2hCLHdCQUFDLFFBQUQ7RUFDQSx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFJLFNBQVMsZ0JBQWdCLElBQUksd0JBQUMsVUFBRDtJQUFVLElBQUc7SUFBYTtHQUFTOzs7O2NBQUksd0JBQUMsYUFBRCxDQUFjOzs7OztFQUFJOzs7OztFQUV0Ryx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFTLFNBQVMsd0JBQUMsT0FBRCxDQUFROzs7OztFQUFJOzs7OztFQUMxQyx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFZLFNBQVMsd0JBQUMsVUFBRCxDQUFXOzs7OztFQUFJOzs7OztFQUNoRCx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFVLFNBQVMsd0JBQUMsUUFBRCxDQUFTOzs7OztFQUFJOzs7OztFQUM1Qyx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFtQixTQUFTLHdCQUFDLG9CQUFELENBQXFCOzs7OztFQUFJOzs7OztFQUNqRSx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFlLFNBQVMsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O0VBQUk7Ozs7O0VBQ3pELHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQWtDLFNBQVMsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O0VBQUk7Ozs7O0VBRTVFLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQWEsU0FBUyx3QkFBQyxnQkFBRCxZQUFnQix3QkFBQyxVQUFELENBQVc7Ozs7WUFBaUI7Ozs7O0VBQUk7Ozs7O0VBQ2xGLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQVksU0FBUyx3QkFBQyxnQkFBRCxZQUFnQix3QkFBQyxTQUFELENBQVU7Ozs7WUFBaUI7Ozs7O0VBQUk7Ozs7O0VBQ2hGLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQWEsU0FBUyx3QkFBQyxnQkFBRCxZQUFnQix3QkFBQyxlQUFELENBQWdCOzs7O1lBQWlCOzs7OztFQUFJOzs7OztFQUN2Rix3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFhLFNBQVMsd0JBQUMsZ0JBQUQsWUFBZ0Isd0JBQUMsZUFBRCxDQUFnQjs7OztZQUFpQjs7Ozs7RUFBSTs7Ozs7RUFDdkYsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBVyxTQUFTLHdCQUFDLGdCQUFELFlBQWdCLHdCQUFDLGFBQUQsQ0FBYzs7OztZQUFpQjs7Ozs7RUFBSTs7Ozs7RUFFbkYsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBZSxTQUFTLHdCQUFDLGdCQUFELFlBQWdCLHdCQUFDLFlBQUQsQ0FBYTs7OztZQUFpQjs7Ozs7RUFBSTs7Ozs7RUFDdEYsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBa0IsU0FBUyx3QkFBQyxnQkFBRCxZQUFnQix3QkFBQyxhQUFELENBQWM7Ozs7WUFBaUI7Ozs7O0VBQUk7Ozs7O0VBQzFGLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQXVCLFNBQVMsd0JBQUMsZ0JBQUQsWUFBZ0Isd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7WUFBaUI7Ozs7O0VBQUk7Ozs7O0VBQ3JHLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQXVCLFNBQVMsd0JBQUMsZ0JBQUQsWUFBZ0Isd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7WUFBaUI7Ozs7O0VBQUk7Ozs7O0VBRXJHLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQVMsU0FBUyx3QkFBQyxnQkFBRCxZQUFnQix3QkFBQyxvQkFBRCxDQUFxQjs7OztZQUFpQjs7Ozs7RUFBSTs7Ozs7RUFDeEYsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBVyxTQUFTLHdCQUFDLGdCQUFELFlBQWdCLHdCQUFDLFlBQUQsQ0FBYTs7OztZQUFpQjs7Ozs7RUFBSTs7Ozs7RUFDbEYsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBVyxTQUFTLHdCQUFDLGdCQUFELFlBQWdCLHdCQUFDLGFBQUQsQ0FBYzs7OztZQUFpQjs7Ozs7RUFBSTs7Ozs7Q0FDN0U7Ozs7U0FDTzs7Ozs7QUFFbkI7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJvdXRlcywgUm91dGUsIE5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgTG9naW4gZnJvbSAnLi9mZWF0dXJlcy9hdXRoL0xvZ2luJztcbmltcG9ydCBSZWdpc3RlciBmcm9tICcuL2ZlYXR1cmVzL2F1dGgvUmVnaXN0ZXInO1xuaW1wb3J0IFZlcmlmeSBmcm9tICcuLi9zcmMvZmVhdHVyZXMvYXV0aC9WZXJpZnlSZWdpc3Rlcic7XG5pbXBvcnQgVXNlckhvbWUgZnJvbSAnLi9mZWF0dXJlcy9kYXNoYm9hcmQvdXNlckRhc2hib2FyZC91c2VyaG9tZSc7XG5pbXBvcnQgTXlGb3JtcyBmcm9tICcuL2ZlYXR1cmVzL2Rhc2hib2FyZC91c2VyRGFzaGJvYXJkL215Rm9ybXMnO1xuaW1wb3J0IFRlbXBsYXRlc1BhZ2UgZnJvbSAnLi9mZWF0dXJlcy9kYXNoYm9hcmQvdXNlckRhc2hib2FyZC90ZW1wbGF0ZUZvcm0nO1xuaW1wb3J0IFVzZXJIaXN0b3J5IGZyb20gJy4vZmVhdHVyZXMvZGFzaGJvYXJkL3VzZXJEYXNoYm9hcmQvdXNlckhpc3RvcnknO1xuaW1wb3J0IFJlc3BvbnNlc1BhZ2UgZnJvbSAnLi9mZWF0dXJlcy9kYXNoYm9hcmQvdXNlckRhc2hib2FyZC9yZXNwb25zZXNQYWdlJztcbmltcG9ydCBDcmVhdGVGb3JtIGZyb20gJy4vZmVhdHVyZXMvZm9ybS1idWlsZGVyL0NyZWF0ZUZvcm0nO1xuaW1wb3J0IEZvcm1CdWlsZGVyIGZyb20gJy4vZmVhdHVyZXMvZm9ybS1idWlsZGVyL0Zvcm1CdWlsZGVyJztcbmltcG9ydCBGb3JtUmVzcG9uc2VzUGFnZSBmcm9tICcuL2ZlYXR1cmVzL2Zvcm0tcmVzcG9uc2VzL0Zvcm1SZXNwb25zZXNQYWdlJztcbmltcG9ydCBGb3JtQW5hbHl0aWNzUGFnZSBmcm9tICcuL2ZlYXR1cmVzL2Zvcm0tcmVzcG9uc2VzL0Zvcm1BbmFseXRpY3NQYWdlJztcbmltcG9ydCBGb3JtUnVubmVyUGFnZSBmcm9tICcuL2ZlYXR1cmVzL2Zvcm0tcnVubmVyL0Zvcm1SdW5uZXJQYWdlJztcbmltcG9ydCBGb3JtUmVzdWx0UGFnZSBmcm9tICcuL2ZlYXR1cmVzL2Zvcm0tcnVubmVyL0Zvcm1SZXN1bHRQYWdlJztcbmltcG9ydCBBZG1pbkRhc2hib2FyZFBhZ2UgZnJvbSAnLi9mZWF0dXJlcy9hZG1pbi9BZG1pbkRhc2hib2FyZFBhZ2UnO1xuaW1wb3J0IFByb2ZpbGVQYWdlIGZyb20gJy4vZmVhdHVyZXMvcHJvZmlsZS9Qcm9maWxlUGFnZSc7XG5pbXBvcnQgRm9yZ290UGFzc3dvcmRQYWdlIGZyb20gJy4vZmVhdHVyZXMvYXV0aC9Gb3Jnb3RQYXNzd29yZFBhZ2UnO1xuaW1wb3J0IExhbmRpbmdQYWdlIGZyb20gJy4vZmVhdHVyZXMvbGFuZGluZy9MYW5kaW5nUGFnZSc7XG5pbXBvcnQgQWlDaGF0UGFnZSBmcm9tICcuL2ZlYXR1cmVzL2FpLWNoYXQvQWlDaGF0UGFnZSc7XG5pbXBvcnQgUHJvdGVjdGVkUm91dGUgZnJvbSAnLi9jb21wb25lbnRzL3VpL1Byb3RlY3RlZFJvdXRlJztcbmltcG9ydCBFcnJvckJvdW5kYXJ5IGZyb20gJy4vY29tcG9uZW50cy91aS9FcnJvckJvdW5kYXJ5JztcbmltcG9ydCBPZmZsaW5lQmFubmVyIGZyb20gJy4vY29tcG9uZW50cy91aS9PZmZsaW5lQmFubmVyJztcbmltcG9ydCB7IGlzQXV0aGVudGljYXRlZCB9IGZyb20gJy4vc2VydmljZXMvYXBpU2VydmljZSc7XG5cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIChcbiAgICA8RXJyb3JCb3VuZGFyeT5cbiAgICAgIDxPZmZsaW5lQmFubmVyIC8+XG4gICAgICA8Um91dGVzPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17aXNBdXRoZW50aWNhdGVkKCkgPyA8TmF2aWdhdGUgdG89XCIvZGFzaGJvYXJkXCIgcmVwbGFjZSAvPiA6IDxMYW5kaW5nUGFnZSAvPn0gLz5cblxuICAgICAgPFJvdXRlIHBhdGg9XCIvbG9naW5cIiBlbGVtZW50PXs8TG9naW4gLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIi9yZWdpc3RlclwiIGVsZW1lbnQ9ezxSZWdpc3RlciAvPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL3ZlcmlmeVwiIGVsZW1lbnQ9ezxWZXJpZnkgLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIi9mb3Jnb3QtcGFzc3dvcmRcIiBlbGVtZW50PXs8Rm9yZ290UGFzc3dvcmRQYWdlIC8+fSAvPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvZi86Zm9ybUxpbmtcIiBlbGVtZW50PXs8Rm9ybVJ1bm5lclBhZ2UgLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIi9mLzpmb3JtTGluay9yZXN1bHQvOnJlc3BvbnNlSWRcIiBlbGVtZW50PXs8Rm9ybVJlc3VsdFBhZ2UgLz59IC8+XG5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2Rhc2hib2FyZFwiIGVsZW1lbnQ9ezxQcm90ZWN0ZWRSb3V0ZT48VXNlckhvbWUgLz48L1Byb3RlY3RlZFJvdXRlPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL215LWZvcm1zXCIgZWxlbWVudD17PFByb3RlY3RlZFJvdXRlPjxNeUZvcm1zIC8+PC9Qcm90ZWN0ZWRSb3V0ZT59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIi90ZW1wbGF0ZXNcIiBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+PFRlbXBsYXRlc1BhZ2UgLz48L1Byb3RlY3RlZFJvdXRlPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL3Jlc3BvbnNlc1wiIGVsZW1lbnQ9ezxQcm90ZWN0ZWRSb3V0ZT48UmVzcG9uc2VzUGFnZSAvPjwvUHJvdGVjdGVkUm91dGU+fSAvPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvaGlzdG9yeVwiIGVsZW1lbnQ9ezxQcm90ZWN0ZWRSb3V0ZT48VXNlckhpc3RvcnkgLz48L1Byb3RlY3RlZFJvdXRlPn0gLz5cblxuICAgICAgPFJvdXRlIHBhdGg9XCIvY3JlYXRlLWZvcm1cIiBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+PENyZWF0ZUZvcm0gLz48L1Byb3RlY3RlZFJvdXRlPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2Zvcm1zLzppZC9lZGl0XCIgZWxlbWVudD17PFByb3RlY3RlZFJvdXRlPjxGb3JtQnVpbGRlciAvPjwvUHJvdGVjdGVkUm91dGU+fSAvPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvZm9ybXMvOmlkL3Jlc3BvbnNlc1wiIGVsZW1lbnQ9ezxQcm90ZWN0ZWRSb3V0ZT48Rm9ybVJlc3BvbnNlc1BhZ2UgLz48L1Byb3RlY3RlZFJvdXRlPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2Zvcm1zLzppZC9hbmFseXRpY3NcIiBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+PEZvcm1BbmFseXRpY3NQYWdlIC8+PC9Qcm90ZWN0ZWRSb3V0ZT59IC8+XG5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2FkbWluXCIgZWxlbWVudD17PFByb3RlY3RlZFJvdXRlPjxBZG1pbkRhc2hib2FyZFBhZ2UgLz48L1Byb3RlY3RlZFJvdXRlPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2FpLWNoYXRcIiBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+PEFpQ2hhdFBhZ2UgLz48L1Byb3RlY3RlZFJvdXRlPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL3Byb2ZpbGVcIiBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+PFByb2ZpbGVQYWdlIC8+PC9Qcm90ZWN0ZWRSb3V0ZT59IC8+XG4gICAgPC9Sb3V0ZXM+XG4gICAgPC9FcnJvckJvdW5kYXJ5PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7ICJdfQ==