import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/form-responses/FormResponsesPage.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const Fragment = __vite__cjsImport0_react["Fragment"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport9_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { ArrowLeft, Download, Eye, X, BarChart2, Loader2, MessageSquare, AlertTriangle, CheckCircle2, XCircle, MinusCircle, ChevronLeft, ChevronRight, TrendingUp, Calendar, Maximize2, Sliders, Edit2, RotateCcw, Check, Save, ShieldAlert, ShieldCheck, Activity, Radio, RefreshCw, ChevronDown, ChevronUp, Search, Filter, AlertCircle, ArrowRight as ArrowRightIcon, Share2 } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import ConfirmModal from "/src/components/ui/ConfirmModal.jsx";
import { getFormById, getFormResponses, getFormAnalytics, getResponseResult, getQuestions, getResponseDetail, getResponseAttempts, updateResponseStatus, clearSession, exportFormResponses, getFormFeedbacks, assetUrl, overrideAnswerScore, bulkOverrideAnswerScores, getExamMonitoring, forceSubmitExamSession, resetExamSession, resolveAnswerKey, ResolveAnswerKey, ExamProctorActions, stripMathNotation } from "/src/services/apiService.js";
import { getGeminiApiKey, scoreHolisticEssayWithAI, AVAILABLE_MODELS } from "/src/services/aiService.js";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
import ImageLightboxModal from "/src/components/ui/ImageLightboxModal.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-responses/FormResponsesPage.jsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const STATUS_OPTIONS = [
	{
		id: 1,
		label: "Baru",
		code: "new"
	},
	{
		id: 2,
		label: "Ditinjau",
		code: "reviewed"
	},
	{
		id: 3,
		label: "Diterima",
		code: "accepted"
	},
	{
		id: 4,
		label: "Ditolak",
		code: "rejected"
	}
];
const PAGE_SIZE = 25;
export { resolveAnswerKey, ResolveAnswerKey };
export const resolveQuestionKey = (qDef) => resolveAnswerKey(qDef);
export const resolveBaseIsCorrect = (answer, qDef) => {
	if (!qDef) return null;
	const aText = String(answer?.answerText || answer?.answerValue || answer?.optionText || "").trim().toLowerCase();
	if (qDef.typeId === 2 || qDef.typeId === 5) {
		const correctOpt = (qDef.options || []).find((o) => o.isCorrect === true);
		if (!correctOpt) return null;
		if (answer?.optionId && correctOpt.id) {
			return Number(answer.optionId) === Number(correctOpt.id);
		}
		if (!aText) return false;
		return aText === String(correctOpt.optionText || "").trim().toLowerCase();
	}
	if (qDef.typeId === 3) {
		const correctOpts = (qDef.options || []).filter((o) => o.isCorrect === true);
		if (correctOpts.length === 0) return null;
		if (Array.isArray(answer?.selectedOptions) && answer.selectedOptions.length > 0) {
			const selected = answer.selectedOptions.map((s) => String(s).trim().toLowerCase()).sort();
			const correct = correctOpts.map((c) => String(c.optionText).trim().toLowerCase()).sort();
			if (selected.length !== correct.length) return false;
			return selected.every((val, idx) => val === correct[idx]);
		}
		if (!aText) return false;
		const correctText = correctOpts.map((c) => String(c.optionText).trim().toLowerCase()).sort().join(", ");
		return aText === correctText;
	}
	if (qDef.correctAnswer && qDef.correctAnswer.trim()) {
		if (!aText) return false;
		return aText === String(qDef.correctAnswer).trim().toLowerCase();
	}
	return null;
};
export const getEffectiveIsCorrect = (answer, qDef) => {
	if (!answer) return null;
	if (answer.isCorrectOverride !== null && answer.isCorrectOverride !== undefined) {
		return !!answer.isCorrectOverride;
	}
	if (answer.isCorrect !== null && answer.isCorrect !== undefined) {
		return !!answer.isCorrect;
	}
	if (qDef) {
		const base = resolveBaseIsCorrect(answer, qDef);
		if (base !== null) return base;
	}
	if (answer.correctAnswer && (answer.answerText || answer.answerValue || answer.optionText)) {
		const aText = String(answer.answerText || answer.answerValue || answer.optionText || "").trim().toLowerCase();
		const cText = String(answer.correctAnswer).trim().toLowerCase();
		if (aText && cText) return aText === cText;
	}
	return null;
};
export const calculateTotalScore = (answers, questions) => {
	const qList = Array.isArray(questions) && questions.length > 0 ? questions : [];
	if (qList.length === 0) {
		const total = answers?.length || 1;
		const correct = (answers || []).filter((a) => getEffectiveIsCorrect(a) === true).length;
		return {
			score: Math.round(correct / total * 100 * 10) / 10,
			correctCount: correct,
			wrongCount: Math.max(0, total - correct),
			totalQuestions: total,
			totalPoints: total,
			earnedPoints: correct
		};
	}
	let totalPoints = 0;
	let earnedPoints = 0;
	let correctCount = 0;
	let wrongCount = 0;
	qList.forEach((q) => {
		const qPoints = Number(q.points) > 0 ? Number(q.points) : 1;
		totalPoints += qPoints;
		const ans = (answers || []).find((a) => Number(a.questionId) === Number(q.id));
		// BUG-3 FIX: honour partial (fractional) earned points when the owner has
		// set a manualScore override (e.g. 90% of an essay). manualScore is raw
		// earned points (same unit as qPoints), NOT a percentage.
		if (ans && ans.manualScore != null && ans.manualScore !== undefined) {
			const raw = Number(ans.manualScore);
			if (!isNaN(raw) && raw >= 0) {
				earnedPoints += Math.min(raw, qPoints);
				// Count as correct only if they earned > 0 (so status badge shows something sensible)
				if (raw > 0) correctCount++;
				else wrongCount++;
				return;
			}
		}
		const effective = getEffectiveIsCorrect(ans, q);
		if (effective === true) {
			earnedPoints += qPoints;
			correctCount++;
		} else if (effective === false) {
			wrongCount++;
		}
	});
	const score = totalPoints > 0 ? Math.round(earnedPoints / totalPoints * 100 * 10) / 10 : 0;
	return {
		score,
		correctCount,
		wrongCount,
		totalQuestions: qList.length,
		totalPoints,
		earnedPoints
	};
};
const getLocalManualOverrides = (formId) => {
	try {
		const raw = localStorage.getItem(`formup_overrides_${formId}`);
		return raw ? JSON.parse(raw) : {};
	} catch {
		return {};
	}
};
const saveLocalManualOverride = (formId, responseId, questionId, isCorrect) => {
	try {
		const cur = getLocalManualOverrides(formId);
		if (!cur[responseId]) cur[responseId] = {};
		cur[responseId][questionId] = isCorrect;
		localStorage.setItem(`formup_overrides_${formId}`, JSON.stringify(cur));
	} catch (e) {
		console.warn("Failed to save manual override locally", e);
	}
};
const isProctorActionType = (type) => (type || "").toLowerCase() === ExamProctorActions.ForceSubmitByProctor.toLowerCase();
const getGenuineViolationCount = (session) => (session?.violations || []).filter((v) => !isProctorActionType(v.type)).length;
export default function FormResponsesPage() {
	_s();
	const { id } = useParams();
	const navigate = useNavigate();
	const [activeTab, setActiveTab] = useState("responses");
	const [form, setForm] = useState(null);
	const [formQuestions, setFormQuestions] = useState([]);
	const [responses, setResponses] = useState([]);
	const [analytics, setAnalytics] = useState(null);
	const [loading, setLoading] = useState(true);
	const [statusUpdating, setStatusUpdating] = useState(null);
	const [toast, setToast] = useState(null);
	const [exporting, setExporting] = useState(false);
	const [lightboxImage, setLightboxImage] = useState(null);
	// Feedback
	const [feedbacks, setFeedbacks] = useState([]);
	const [feedbackLoading, setFeedbackLoading] = useState(false);
	// Review Answers Modal
	const [selectedRespondent, setSelectedRespondent] = useState(null);
	const [editingScoreId, setEditingScoreId] = useState(null);
	const [inlineScoreInput, setInlineScoreInput] = useState("");
	// BUG-3: partial per-answer score override state (essay questions only)
	const [partialScoreEditingId, setPartialScoreEditingId] = useState(null);
	const [partialScoreInput, setPartialScoreInput] = useState("");
	// B-2: Complete correction panel state (essay) — IsCorrectOverride explicit + OverrideNote
	const [activeCorrectionId, setActiveCorrectionId] = useState(null);
	const [correctionNote, setCorrectionNote] = useState("");
	const [correctionIsCorrectOverride, setCorrectionIsCorrectOverride] = useState(undefined);
	// B-3: AI Essay Scoring — redesigned to holistic per-submission (A-8)
	const [aiScoringAnswerId, setAiScoringAnswerId] = useState(null);
	const [aiScoreSuggestions, setAiScoreSuggestions] = useState({});
	// A-8: Holistic scoring state
	const [aiHolisticScoring, setAiHolisticScoring] = useState(false);
	const [aiModel, setAiModel] = useState(() => {
		const m = localStorage.getItem("formup_selected_model_chat");
		return m && !m.includes("-pro") && AVAILABLE_MODELS.some((model) => model.id === m) ? m : "gemini-3.6-flash";
	});
	const [aiHolisticResult, setAiHolisticResult] = useState(null);
	const [aiHolisticPreviewOpen, setAiHolisticPreviewOpen] = useState(false);
	const [bulkModalOpen, setBulkModalOpen] = useState(false);
	const [bulkType, setBulkType] = useState("min");
	const [bulkValue, setBulkValue] = useState(75);
	const [bulkFilter, setBulkFilter] = useState("all");
	const [filterThreshold, setFilterThreshold] = useState(75);
	const [filterRangeMin, setFilterRangeMin] = useState(0);
	const [filterRangeMax, setFilterRangeMax] = useState(70);
	// Exam Monitoring State
	const [monitoringData, setMonitoringData] = useState(null);
	const [monitoringLoading, setMonitoringLoading] = useState(false);
	const [monitoringError, setMonitoringError] = useState("");
	const [monitoringFilter, setMonitoringFilter] = useState("all");
	const [monitoringSearch, setMonitoringSearch] = useState("");
	const [expandedSessions, setExpandedSessions] = useState(new Set());
	const [autoRefresh, setAutoRefresh] = useState(true);
	const [lastRefreshedAt, setLastRefreshedAt] = useState(null);
	const [includeAnswerKey, setIncludeAnswerKey] = useState(true);
	// Proctoring action modal state
	const [proctorModal, setProctorModal] = useState({
		isOpen: false,
		type: null,
		sessionId: null,
		respondentName: "",
		loading: false
	});
	const handleOpenForceSubmit = (session) => {
		setProctorModal({
			isOpen: true,
			type: "force_submit",
			sessionId: session.sessionId,
			respondentName: session.respondentName || "Anonim",
			loading: false
		});
	};
	const handleOpenResetSession = (session) => {
		setProctorModal({
			isOpen: true,
			type: "reset",
			sessionId: session.sessionId,
			respondentName: session.respondentName || "Anonim",
			loading: false
		});
	};
	const handleConfirmProctorAction = async () => {
		const { type, sessionId } = proctorModal;
		if (!sessionId) return;
		setProctorModal((prev) => ({
			...prev,
			loading: true
		}));
		try {
			if (type === "force_submit") {
				const res = await forceSubmitExamSession(id, sessionId);
				if (res.ok) {
					showToast(res.message || "Sesi ujian berhasil diselesaikan paksa.");
					setProctorModal({
						isOpen: false,
						type: null,
						sessionId: null,
						respondentName: "",
						loading: false
					});
					fetchExamMonitoring(true);
					getFormResponses(id, {
						page: 1,
						pageSize: PAGE_SIZE
					}).then((respRes) => {
						if (respRes.ok && respRes.data) setResponses(respRes.data.responses || respRes.data || []);
					}).catch(() => {});
				} else {
					showToast(res.message || "Gagal menyelesaikan paksa sesi ujian.", "error");
					setProctorModal((prev) => ({
						...prev,
						loading: false
					}));
				}
			} else if (type === "reset") {
				const res = await resetExamSession(id, sessionId);
				if (res.ok) {
					showToast(res.message || "Jawaban peserta berhasil di-reset.");
					setProctorModal({
						isOpen: false,
						type: null,
						sessionId: null,
						respondentName: "",
						loading: false
					});
					fetchExamMonitoring(true);
					getFormResponses(id, {
						page: 1,
						pageSize: PAGE_SIZE
					}).then((respRes) => {
						if (respRes.ok && respRes.data) setResponses(respRes.data.responses || respRes.data || []);
					}).catch(() => {});
				} else {
					showToast(res.message || "Gagal me-reset jawaban peserta.", "error");
					setProctorModal((prev) => ({
						...prev,
						loading: false
					}));
				}
			}
		} catch (err) {
			console.error(err);
			showToast("Terjadi kesalahan saat memproses aksi proctoring.", "error");
			setProctorModal((prev) => ({
				...prev,
				loading: false
			}));
		}
	};
	const toggleSessionExpand = (sessionId) => {
		setExpandedSessions((prev) => {
			const next = new Set(prev);
			if (next.has(sessionId)) next.delete(sessionId);
			else next.add(sessionId);
			return next;
		});
	};
	const fetchExamMonitoring = useCallback(async (isSilent = false) => {
		if (!id) return;
		if (!isSilent) setMonitoringLoading(true);
		try {
			const res = await getExamMonitoring(id);
			if (res.ok && res.data) {
				setMonitoringData(res.data);
				setLastRefreshedAt(new Date());
				setMonitoringError("");
			} else if (!isSilent) {
				setMonitoringError(res.message || "Gagal memuat data monitoring.");
			}
		} catch (err) {
			if (!isSilent) setMonitoringError("Koneksi terputus saat mengambil data monitoring.");
		} finally {
			if (!isSilent) setMonitoringLoading(false);
		}
	}, [id]);
	// Polling effect when activeTab === 'monitoring'
	useEffect(() => {
		if (activeTab !== "monitoring") return;
		fetchExamMonitoring(false);
		if (!autoRefresh) return;
		const intervalId = setInterval(() => {
			fetchExamMonitoring(true);
		}, 5e3);
		return () => clearInterval(intervalId);
	}, [
		activeTab,
		autoRefresh,
		fetchExamMonitoring
	]);
	const filteredSessions = useMemo(() => {
		const list = monitoringData?.sessions || [];
		const maxSw = monitoringData?.maxTabSwitch || 3;
		return list.filter((s) => {
			if (monitoringSearch) {
				const term = monitoringSearch.toLowerCase();
				const name = (s.respondentName || "Anonim").toLowerCase();
				if (!name.includes(term)) return false;
			}
			if (monitoringFilter === "in_progress") return s.status === "in_progress";
			if (monitoringFilter === "submitted") return s.status === "submitted";
			if (monitoringFilter === "violations") return getGenuineViolationCount(s) > 0;
			if (monitoringFilter === "high_violations") return getGenuineViolationCount(s) >= maxSw || s.tabSwitchCount >= maxSw;
			return true;
		});
	}, [
		monitoringData,
		monitoringFilter,
		monitoringSearch
	]);
	const getViolationInfo = (type) => {
		switch (type) {
			case "tab_switch": return {
				label: "Pindah Tab / Layar Ujian",
				icon: /* @__PURE__ */ _jsxDEV(ArrowRightIcon, { size: 13 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 374,
					columnNumber: 27
				}, this),
				color: "text-red-600 dark:text-red-400",
				bg: "bg-red-50 dark:bg-red-950/60"
			};
			case "window_blur": return {
				label: "Jendela Browser Kehilangan Fokus",
				icon: /* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 13 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 381,
					columnNumber: 27
				}, this),
				color: "text-amber-600 dark:text-amber-400",
				bg: "bg-amber-50 dark:bg-amber-950/60"
			};
			case "copy_attempt": return {
				label: "Percobaan Menyalin Teks (Copy)",
				icon: /* @__PURE__ */ _jsxDEV(XCircle, { size: 13 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 388,
					columnNumber: 27
				}, this),
				color: "text-purple-600 dark:text-purple-400",
				bg: "bg-purple-50 dark:bg-purple-950/60"
			};
			case "paste_attempt": return {
				label: "Percobaan Menempel Teks (Paste)",
				icon: /* @__PURE__ */ _jsxDEV(XCircle, { size: 13 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 395,
					columnNumber: 27
				}, this),
				color: "text-indigo-600 dark:text-indigo-400",
				bg: "bg-indigo-50 dark:bg-indigo-950/60"
			};
			case "context_menu": return {
				label: "Klik Kanan (Context Menu)",
				icon: /* @__PURE__ */ _jsxDEV(MinusCircle, { size: 13 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 402,
					columnNumber: 27
				}, this),
				color: "text-slate-600 dark:text-slate-400",
				bg: "bg-slate-100 dark:bg-slate-800"
			};
			case "FORCE_SUBMIT_BY_PROCTOR":
			case "force_submit_by_proctor": return {
				label: "Diselesaikan Paksa oleh Pengawas (Force Submit)",
				icon: /* @__PURE__ */ _jsxDEV(ShieldAlert, { size: 13 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 410,
					columnNumber: 27
				}, this),
				color: "text-red-700 dark:text-red-300",
				bg: "bg-red-100 dark:bg-red-950/80"
			};
			default: return {
				label: `Pelanggaran: ${type}`,
				icon: /* @__PURE__ */ _jsxDEV(AlertCircle, { size: 13 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 417,
					columnNumber: 27
				}, this),
				color: "text-red-600 dark:text-red-400",
				bg: "bg-red-50 dark:bg-red-950/60"
			};
		}
	};
	const formatDateWithTime = (d) => d ? new Date(d).toLocaleString("id-ID", {
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	}) : "—";
	useEffect(() => {
		const load = async () => {
			setLoading(true);
			try {
				// Silently load monitoring data in parallel if available
				getExamMonitoring(id).then((res) => {
					if (res.ok && res.data) setMonitoringData(res.data);
				}).catch(() => {});
				const [formRes, respRes, analyticsRes, questionsRes] = await Promise.all([
					getFormById(id),
					getFormResponses(id, {
						page: 1,
						pageSize: PAGE_SIZE
					}),
					getFormAnalytics(id, 1, 100),
					getQuestions(id)
				]);
				if (formRes.status === 401) {
					clearSession();
					navigate("/login");
					return;
				}
				if (formRes.ok) setForm(formRes.data);
				let loadedQuestions = [];
				if (questionsRes.ok && Array.isArray(questionsRes.data)) {
					loadedQuestions = questionsRes.data;
					setFormQuestions(loadedQuestions);
				}
				if (respRes.ok) {
					const list = Array.isArray(respRes.data) ? respRes.data : respRes.data?.responses || respRes.data?.items || [];
					setResponses(list);
				}
				if (analyticsRes.ok && analyticsRes.data) {
					const localOverrides = getLocalManualOverrides(id);
					let data = analyticsRes.data;
					if (data.respondents) {
						data.respondents = data.respondents.map((r) => {
							const respOverrides = localOverrides[r.responseId] || {};
							const updatedAnswers = (r.answers || []).map((a) => {
								const qDef = loadedQuestions.find((q) => Number(q.id) === Number(a.questionId));
								const key = a.correctAnswer || resolveQuestionKey(qDef);
								const hasLocalOverride = respOverrides[a.questionId] !== undefined;
								const effOverride = hasLocalOverride ? respOverrides[a.questionId] : a.isCorrectOverride;
								const effIsCorrect = getEffectiveIsCorrect({
									...a,
									isCorrectOverride: effOverride
								}, qDef);
								return {
									...a,
									correctAnswer: key,
									isCorrectOverride: effOverride,
									isCorrect: effIsCorrect
								};
							});
							const scoring = calculateTotalScore(updatedAnswers, loadedQuestions);
							const hasAnyOverride = Object.keys(respOverrides).length > 0 || updatedAnswers.some((a) => a.isCorrectOverride !== null && a.isCorrectOverride !== undefined);
							return {
								...r,
								answers: updatedAnswers,
								correctCount: scoring.correctCount,
								wrongCount: scoring.wrongCount,
								score: scoring.score,
								isCustomScore: hasAnyOverride || r.isCustomScore
							};
						});
					}
					setAnalytics(data);
				}
			} catch (err) {
				console.error("Error loading responses:", err);
			} finally {
				setLoading(false);
			}
		};
		load();
	}, [id, navigate]);
	// Load feedback tab
	// Load feedback tab
	// Load feedback tab — GET /api/forms/{formId}/feedbacks (plural) is the
	// endpoint that returns ALL feedback submitted by respondents on this
	// form, which is what the owner needs to see here. GET /api/forms/{formId}/feedback
	// (singular, "getMyFeedback") returns only the logged-in user's own
	// feedback submissions and returned 404 for owners who never submitted
	// feedback themselves — the wrong endpoint for this purpose.
	useEffect(() => {
		if (activeTab !== "feedback") return;
		const loadFeedback = async () => {
			setFeedbackLoading(true);
			const res = await getFormFeedbacks(id);
			setFeedbackLoading(false);
			if (res.ok) {
				const data = res.data;
				let list = [];
				if (Array.isArray(data)) list = data;
				else if (data?.items && Array.isArray(data.items)) list = data.items;
				else if (data && typeof data === "object") list = [data];
				setFeedbacks(list.filter((fb) => !(fb.reason || "").startsWith("ADMIN_")));
			} else {
				setFeedbacks([]);
			}
		};
		loadFeedback();
	}, [activeTab, id]);
	const showToast = (msg, type = "success") => {
		setToast({
			msg,
			type
		});
		setTimeout(() => setToast(null), 3e3);
	};
	// Merge respondent data from analytics with response list
	const respondentsList = useMemo(() => {
		if (analytics?.respondents && analytics.respondents.length > 0) {
			return analytics.respondents;
		}
		return (responses || []).map((r) => ({
			responseId: r.id,
			respondentName: r.respondentName,
			submittedAt: r.submittedAt,
			status: r.status,
			answeredCount: 0,
			totalQuestions: 0,
			correctCount: 0,
			wrongCount: 0,
			score: null,
			answers: []
		}));
	}, [analytics, responses]);
	const handleExport = async (formId, format = "csv") => {
		if (!formId || exporting) return;
		setExporting(true);
		try {
			// For Excel / PDF, use server-side export endpoint
			if (format === "xlsx" || format === "pdf") {
				const res = await exportFormResponses(formId, format, includeAnswerKey);
				if (!res.ok) {
					showToast(res.message || `Gagal mengekspor ${format.toUpperCase()}`, "error");
				} else {
					showToast(`File ${format.toUpperCase()} berhasil diunduh!`);
				}
				return;
			}
			// For CSV: If no local responses list, fallback to server-side CSV
			if (!respondentsList || respondentsList.length === 0) {
				const res = await exportFormResponses(formId, "csv", includeAnswerKey);
				if (!res.ok) {
					showToast(res.message || "Belum ada data respons untuk diekspor.", "error");
				} else {
					showToast("File CSV berhasil diunduh!");
				}
				return;
			}
			// Extract unique question titles
			const questionMap = new Map();
			respondentsList.forEach((r) => {
				(r.answers || []).forEach((a) => {
					if (a.questionId && !questionMap.has(a.questionId)) {
						const cleanTitle = (a.question || `Soal #${a.questionId}`).replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
						questionMap.set(a.questionId, cleanTitle);
					}
				});
			});
			// Also ensure any loaded questions are included
			(formQuestions || []).forEach((q) => {
				if (q.id && !questionMap.has(q.id)) {
					const cleanTitle = (q.question || q.question1 || `Soal #${q.id}`).replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
					questionMap.set(q.id, cleanTitle);
				}
			});
			const escapeCsv = (val) => {
				if (val === null || val === undefined) return "\"\"";
				const str = String(val).replace(/<[^>]*>/g, "").replace(/[\r\n]+/g, " ").trim();
				return `"${str.replace(/"/g, "\"\"")}"`;
			};
			const headerRow = [
				"Response ID",
				"Submitted At",
				"Respondent",
				...Array.from(questionMap.values()).map(stripMathNotation)
			];
			let rows = [];
			// A5 Spec:
			// "Format CSV: tambahkan baris ke-2 berisi KUNCI,JAWABAN,-,<kunci per soal>, tepat di bawah header. Hapus kolom Kunci_* versi lama."
			// "Parameter ?includeAnswerKey=false harus tetap bisa mematikan baris kunci jawaban."
			if (includeAnswerKey) {
				const answerKeyRow = [
					"KUNCI",
					"JAWABAN",
					"-",
					...Array.from(questionMap.keys()).map((qId) => {
						const qDef = (formQuestions || []).find((q) => q.id === qId);
						return stripMathNotation(resolveAnswerKey(qDef));
					})
				];
				rows.push(answerKeyRow.map(escapeCsv).join(","));
			}
			const dataRows = (respondentsList || []).map((r) => {
				const answerByQ = new Map((r.answers || []).map((a) => [a.questionId, a.answerText || a.answerValue || a.optionText || ""]));
				return [
					r.responseId,
					r.submittedAt ? formatDate(r.submittedAt) : "-",
					r.respondentName || "Anonim",
					...Array.from(questionMap.keys()).map((qId) => stripMathNotation(answerByQ.get(qId) || ""))
				].map(escapeCsv).join(",");
			});
			rows.push(...dataRows);
			const csvContent = "﻿" + [headerRow.map(escapeCsv).join(","), ...rows].join("\r\n");
			const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = url;
			link.setAttribute("download", `respons-formulir-${form?.title ? form.title.replace(/\s+/g, "_") : formId}.csv`);
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
			URL.revokeObjectURL(url);
			showToast("File CSV berhasil diunduh!");
		} catch (err) {
			console.error(err);
			showToast("Terjadi kesalahan saat mengekspor.", "error");
		} finally {
			setExporting(false);
		}
	};
	const handleStatusChange = async (responseId, statusId) => {
		setStatusUpdating(responseId);
		const res = await updateResponseStatus(responseId, statusId);
		if (res.ok) {
			const statusLabel = STATUS_OPTIONS.find((s) => s.id === statusId)?.code ?? "new";
			setResponses((prev) => prev.map((r) => r.id === responseId ? {
				...r,
				status: statusLabel
			} : r));
			showToast("Status respons berhasil diperbarui");
		} else {
			showToast(res.message || "Gagal memperbarui status", "error");
		}
		setStatusUpdating(null);
	};
	const formatDate = (d) => d ? new Date(d).toLocaleString("id-ID", {
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	}) : "—";
	const statusStyle = (status) => {
		switch (status?.toLowerCase()) {
			case "new":
			case "baru": return "bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400";
			case "reviewed":
			case "ditinjau": return "bg-yellow-50 text-yellow-600 dark:bg-yellow-950/60 dark:text-yellow-400";
			case "accepted":
			case "diterima": return "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400";
			case "rejected":
			case "ditolak": return "bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400";
			default: return "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400";
		}
	};
	const handleSaveIndividualScore = async (responseId, newScore) => {
		const parsed = Math.max(0, Math.min(100, parseFloat(newScore) || 0));
		// Update local display state optimistically
		setAnalytics((prev) => {
			if (!prev?.respondents) return prev;
			return {
				...prev,
				respondents: prev.respondents.map((r) => r.responseId === responseId ? {
					...r,
					score: parsed,
					isCustomScore: true
				} : r)
			};
		});
		setEditingScoreId(null);
		showToast(`Skor responden #${responseId} diperbarui menjadi ${parsed}%`);
	};
	const openRespondentReview = async (respondent) => {
		const localOverrides = getLocalManualOverrides(id)[respondent.responseId] || {};
		const currentAnswers = (respondent.answers || []).map((a) => {
			const qDef = formQuestions.find((q) => Number(q.id) === Number(a.questionId));
			const key = a.correctAnswer || resolveQuestionKey(qDef);
			const hasLocalOverride = localOverrides[a.questionId] !== undefined;
			const effOverride = hasLocalOverride ? localOverrides[a.questionId] : a.isCorrectOverride;
			const effIsCorrect = getEffectiveIsCorrect({
				...a,
				isCorrectOverride: effOverride
			}, qDef);
			return {
				...a,
				correctAnswer: key,
				isCorrectOverride: effOverride,
				isCorrect: effIsCorrect
			};
		});
		const initialScoring = calculateTotalScore(currentAnswers, formQuestions);
		setSelectedRespondent({
			...respondent,
			answers: currentAnswers,
			correctCount: initialScoring.correctCount,
			wrongCount: initialScoring.wrongCount,
			score: initialScoring.score,
			totalQuestions: initialScoring.totalQuestions
		});
		// Always load full response result so answers contain proper AnswerId and server-calculated scores
		const res = await getResponseResult(id, respondent.responseId);
		if (res.ok && res.data) {
			const serverAnswers = res.data.answers || respondent.answers || [];
			const mergedAnswers = serverAnswers.map((a) => {
				const qDef = formQuestions.find((q) => Number(q.id) === Number(a.questionId));
				const key = a.correctAnswer || resolveQuestionKey(qDef);
				const hasLocalOverride = localOverrides[a.questionId] !== undefined;
				const effectiveOverride = hasLocalOverride ? localOverrides[a.questionId] : a.isCorrectOverride;
				const effIsCorrect = getEffectiveIsCorrect({
					...a,
					isCorrectOverride: effectiveOverride,
					isCorrect: a.isCorrect
				}, qDef);
				return {
					...a,
					correctAnswer: key,
					isCorrectOverride: effectiveOverride,
					isCorrect: effIsCorrect
				};
			});
			const scoring = calculateTotalScore(mergedAnswers, formQuestions);
			setSelectedRespondent((prev) => ({
				...respondent,
				...res.data,
				answers: mergedAnswers,
				correctCount: scoring.correctCount,
				wrongCount: scoring.wrongCount,
				score: scoring.score,
				totalQuestions: scoring.totalQuestions
			}));
		}
	};
	const handleSetQuestionCorrect = async (responseId, questionId, targetIsCorrect) => {
		let srAnswer = selectedRespondent?.answers?.find((a) => Number(a.questionId) === Number(questionId));
		let answerId = srAnswer?.answerId || srAnswer?.id;
		if (!answerId) {
			const fresh = await getResponseResult(id, responseId);
			if (fresh.ok && fresh.data?.answers) {
				const found = fresh.data.answers.find((a) => Number(a.questionId) === Number(questionId));
				answerId = found?.answerId || found?.id;
			}
		}
		const parsedAnswerId = parseInt(answerId, 10);
		if (!parsedAnswerId || isNaN(parsedAnswerId)) {
			showToast("Tidak dapat menemukan ID jawaban valid dari server.", "error");
			return;
		}
		const res = await overrideAnswerScore(responseId, parsedAnswerId, {
			isCorrectOverride: targetIsCorrect,
			manualScore: null,
			overrideNote: "Manual correction by form owner"
		});
		if (res.ok) {
			saveLocalManualOverride(id, responseId, questionId, targetIsCorrect);
			setSelectedRespondent((prev) => {
				if (!prev) return prev;
				const newAnswers = (prev.answers || []).map((a) => {
					if (Number(a.questionId) === Number(questionId)) {
						return {
							...a,
							isCorrectOverride: targetIsCorrect,
							isCorrect: targetIsCorrect
						};
					}
					return a;
				});
				const scoring = calculateTotalScore(newAnswers, formQuestions);
				return {
					...prev,
					answers: newAnswers,
					correctCount: scoring.correctCount,
					wrongCount: scoring.wrongCount,
					score: scoring.score
				};
			});
			// Update respondent row in table
			setAnalytics((prev) => {
				if (!prev?.respondents) return prev;
				return {
					...prev,
					respondents: prev.respondents.map((r) => {
						if (r.responseId !== responseId) return r;
						const newAnswers = (r.answers || []).map((a) => {
							if (Number(a.questionId) === Number(questionId)) {
								return {
									...a,
									isCorrectOverride: targetIsCorrect,
									isCorrect: targetIsCorrect
								};
							}
							return a;
						});
						const scoring = calculateTotalScore(newAnswers, formQuestions);
						return {
							...r,
							answers: newAnswers,
							correctCount: scoring.correctCount,
							wrongCount: scoring.wrongCount,
							score: scoring.score,
							isCustomScore: true
						};
					})
				};
			});
			showToast(`Status soal diubah menjadi ${targetIsCorrect ? "Benar" : "Salah"}`);
		} else {
			showToast(res.message || "Gagal mengubah status soal.", "error");
		}
	};
	// BUG-3 FIX: partial score override for essay answers.
	// pctStr is a string "0"–"100". Converts to raw earned points relative to the
	// question weight and sends to the backend's existing manualScore field.
	// The boolean isCorrectOverride is set to true when pct > 0 so the answer is
	// not shown as "Salah" in the UI, and false only when pct === 0.
	const handleSetPartialScore = async (responseId, questionId, answerId, pctStr, qPoints) => {
		const pct = Math.max(0, Math.min(100, parseFloat(pctStr) || 0));
		const rawPoints = Math.round(pct / 100 * qPoints * 100) / 100;
		const isCorrectOverride = pct > 0;
		const parsedAnswerId = parseInt(answerId, 10);
		if (!parsedAnswerId || isNaN(parsedAnswerId)) {
			// fetch answerId on demand (same fallback as handleSetQuestionCorrect)
			const fresh = await getResponseResult(id, responseId);
			if (fresh.ok && fresh.data?.answers) {
				const found = fresh.data.answers.find((a) => Number(a.questionId) === Number(questionId));
				const fetchedId = found?.answerId || found?.id;
				if (!fetchedId) {
					showToast("ID jawaban tidak ditemukan.", "error");
					return;
				}
				return handleSetPartialScore(responseId, questionId, fetchedId, pctStr, qPoints);
			}
			showToast("ID jawaban tidak ditemukan.", "error");
			return;
		}
		const res = await overrideAnswerScore(responseId, parsedAnswerId, {
			isCorrectOverride,
			manualScore: rawPoints,
			overrideNote: `Skor parsial ${pct}% oleh pemilik formulir`
		});
		if (res.ok) {
			// Persist locally (extend existing override map with manualScore info)
			try {
				const cur = getLocalManualOverrides(id);
				if (!cur[responseId]) cur[responseId] = {};
				cur[responseId][questionId] = {
					isCorrect: isCorrectOverride,
					manualScore: rawPoints,
					pct
				};
				localStorage.setItem(`formup_overrides_${id}`, JSON.stringify(cur));
			} catch {}
			// Update review modal state
			setSelectedRespondent((prev) => {
				if (!prev) return prev;
				const newAnswers = (prev.answers || []).map((a) => {
					if (Number(a.questionId) === Number(questionId)) {
						return {
							...a,
							isCorrectOverride,
							isCorrect: isCorrectOverride,
							manualScore: rawPoints
						};
					}
					return a;
				});
				const scoring = calculateTotalScore(newAnswers, formQuestions);
				return {
					...prev,
					answers: newAnswers,
					correctCount: scoring.correctCount,
					wrongCount: scoring.wrongCount,
					score: scoring.score
				};
			});
			// Update respondent row in summary table
			setAnalytics((prev) => {
				if (!prev?.respondents) return prev;
				return {
					...prev,
					respondents: prev.respondents.map((r) => {
						if (r.responseId !== responseId) return r;
						const newAnswers = (r.answers || []).map((a) => {
							if (Number(a.questionId) === Number(questionId)) {
								return {
									...a,
									isCorrectOverride,
									isCorrect: isCorrectOverride,
									manualScore: rawPoints
								};
							}
							return a;
						});
						const scoring = calculateTotalScore(newAnswers, formQuestions);
						return {
							...r,
							answers: newAnswers,
							correctCount: scoring.correctCount,
							wrongCount: scoring.wrongCount,
							score: scoring.score,
							isCustomScore: true
						};
					})
				};
			});
			setPartialScoreEditingId(null);
			showToast(`Skor parsial ${pct}% (${rawPoints} poin) berhasil disimpan`);
		} else {
			showToast(res.message || "Gagal menyimpan skor parsial.", "error");
		}
	};
	// B-2: Save complete correction (partial score + explicit isCorrectOverride + overrideNote)
	const handleSaveCompleteCorrection = async (responseId, questionId, answerId, qPoints) => {
		const parsedAnswerId = parseInt(answerId, 10);
		let finalAnswerId = parsedAnswerId;
		if (!parsedAnswerId || isNaN(parsedAnswerId)) {
			const fresh = await getResponseResult(id, responseId);
			if (fresh.ok && fresh.data?.answers) {
				const found = fresh.data.answers.find((a) => Number(a.questionId) === Number(questionId));
				const fetchedId = found?.answerId || found?.id;
				if (!fetchedId) {
					showToast("ID jawaban tidak ditemukan.", "error");
					return;
				}
				finalAnswerId = parseInt(fetchedId, 10);
			} else {
				showToast("ID jawaban tidak ditemukan.", "error");
				return;
			}
		}
		let finalManualScore = null;
		let finalIsCorrectOverride = correctionIsCorrectOverride;
		if (partialScoreEditingId === answerId || partialScoreEditingId === questionId) {
			const pct = Math.max(0, Math.min(100, parseFloat(partialScoreInput) || 0));
			finalManualScore = Math.round(pct / 100 * qPoints * 100) / 100;
			if (finalIsCorrectOverride === undefined || finalIsCorrectOverride === null) {
				finalIsCorrectOverride = pct > 0;
			}
		} else if (finalIsCorrectOverride === undefined || finalIsCorrectOverride === null) {
			const currentAnswer = (selectedRespondent?.answers || []).find((a) => Number(a.questionId) === Number(questionId));
			finalIsCorrectOverride = currentAnswer?.isCorrectOverride ?? currentAnswer?.isCorrect ?? false;
		}
		const payload = {
			isCorrectOverride: finalIsCorrectOverride,
			manualScore: finalManualScore,
			overrideNote: correctionNote?.trim() || null
		};
		const res = await overrideAnswerScore(responseId, finalAnswerId, payload);
		if (res.ok) {
			try {
				const cur = getLocalManualOverrides(id);
				if (!cur[responseId]) cur[responseId] = {};
				const pctVal = finalManualScore != null ? Math.round(Number(finalManualScore) / qPoints * 100) : finalIsCorrectOverride ? 100 : 0;
				cur[responseId][questionId] = {
					isCorrect: finalIsCorrectOverride,
					manualScore: finalManualScore,
					pct: pctVal,
					note: correctionNote?.trim() || null
				};
				localStorage.setItem(`formup_overrides_${id}`, JSON.stringify(cur));
			} catch {}
			setSelectedRespondent((prev) => {
				if (!prev) return prev;
				const newAnswers = (prev.answers || []).map((a) => {
					if (Number(a.questionId) === Number(questionId)) {
						return {
							...a,
							isCorrectOverride: finalIsCorrectOverride,
							isCorrect: finalIsCorrectOverride,
							manualScore: finalManualScore,
							overrideNote: payload.overrideNote ?? a.overrideNote
						};
					}
					return a;
				});
				const scoring = calculateTotalScore(newAnswers, formQuestions);
				return {
					...prev,
					answers: newAnswers,
					correctCount: scoring.correctCount,
					wrongCount: scoring.wrongCount,
					score: scoring.score
				};
			});
			setAnalytics((prev) => {
				if (!prev?.respondents) return prev;
				return {
					...prev,
					respondents: prev.respondents.map((r) => {
						if (r.responseId !== responseId) return r;
						const newAnswers = (r.answers || []).map((a) => {
							if (Number(a.questionId) === Number(questionId)) {
								return {
									...a,
									isCorrectOverride: finalIsCorrectOverride,
									isCorrect: finalIsCorrectOverride,
									manualScore: finalManualScore,
									overrideNote: payload.overrideNote ?? a.overrideNote
								};
							}
							return a;
						});
						const scoring = calculateTotalScore(newAnswers, formQuestions);
						return {
							...r,
							answers: newAnswers,
							correctCount: scoring.correctCount,
							wrongCount: scoring.wrongCount,
							score: scoring.score,
							isCustomScore: true
						};
					})
				};
			});
			setActiveCorrectionId(null);
			setPartialScoreEditingId(null);
			showToast("Koreksi jawaban berhasil disimpan.");
		} else {
			showToast(res.message || "Gagal menyimpan koreksi.", "error");
		}
	};
	// A-8: Holistic AI analysis — kirim semua jawaban essay + ringkasan PG sekaligus
	const handleAiHolisticScore = async (respondent) => {
		let answers = respondent.answers || [];
		const hasMissingAnswerId = answers.some((a) => !a.answerId && !a.id);
		if (hasMissingAnswerId || answers.length === 0) {
			const fresh = await getResponseResult(id, respondent.responseId);
			if (fresh.ok && fresh.data?.answers) {
				answers = fresh.data.answers;
				setSelectedRespondent((prev) => ({
					...prev,
					...fresh.data
				}));
			}
		}
		const essayAnswers = answers.filter((a) => a.typeId === 1);
		if (essayAnswers.length === 0) {
			showToast("Tidak ada soal essay dalam submission ini.", "error");
			return;
		}
		setAiHolisticScoring(true);
		try {
			const pgAnswers = answers.filter((a) => a.typeId !== 1);
			const pgCorrect = pgAnswers.filter((a) => {
				const qDef = (formQuestions || []).find((q) => Number(q.id) === Number(a.questionId));
				return getEffectiveIsCorrect(a, qDef) === true;
			}).length;
			const pgTotal = pgAnswers.length;
			const essaySectionAnswers = essayAnswers.map((a) => {
				const qDef = (formQuestions || []).find((q) => Number(q.id) === Number(a.questionId));
				return {
					...a,
					correctAnswer: a.correctAnswer || resolveQuestionKey(qDef) || "(tidak ada kunci)"
				};
			});
			const pgSection = pgTotal > 0 ? `\n\nRingkasan PG: ${pgCorrect}/${pgTotal} benar (${Math.round(pgCorrect / pgTotal * 100)}%)` : "";
			const res = await scoreHolisticEssayWithAI({
				essayAnswers: essaySectionAnswers,
				pgSection,
				selectedModel: aiModel,
				customApiKey: getGeminiApiKey()
			});
			if (!res.ok) {
				showToast(res.message || "Gagal menilai essay dengan AI.", "error");
				return;
			}
			const suggestions = res.data || [];
			// Map suggestions back to answer objects
			const mapped = suggestions.map((s, i) => {
				const answer = essayAnswers[i];
				return {
					answer,
					suggestion: s,
					answerId: s.answerId || answer?.answerId || answer?.id
				};
			}).filter((x) => x.answer);
			// Calculate estimated total score using calculateTotalScore
			const simulatedAnswers = (selectedRespondent?.answers || []).map((a) => {
				const matchedSug = mapped.find((x) => Number(x.answer?.questionId) === Number(a.questionId));
				if (matchedSug) {
					return {
						...a,
						isCorrect: matchedSug.suggestion.isCorrect,
						isCorrectOverride: matchedSug.suggestion.isCorrect
					};
				}
				const qDef = (formQuestions || []).find((q) => Number(q.id) === Number(a.questionId));
				return {
					...a,
					isCorrect: getEffectiveIsCorrect(a, qDef)
				};
			});
			const simScoring = calculateTotalScore(simulatedAnswers, formQuestions);
			const totalEstimate = simScoring.score;
			setAiHolisticResult({
				essaySuggestions: mapped,
				pgSummary: pgTotal > 0 ? `${pgCorrect}/${pgTotal} benar` : null,
				totalEstimate
			});
			setAiHolisticPreviewOpen(true);
		} catch (err) {
			showToast("Gagal analisis AI: " + err.message, "error");
		} finally {
			setAiHolisticScoring(false);
		}
	};
	// A-8: Apply all AI suggestions at once via bulk endpoint
	// A-8: Apply all AI suggestions at once via bulk endpoint
	const handleApplyAllAiScores = async () => {
		if (!aiHolisticResult || !selectedRespondent) return;
		const responseId = selectedRespondent.responseId;
		const overrides = aiHolisticResult.essaySuggestions.map((x) => {
			const aId = parseInt(x.answerId, 10);
			if (!aId || isNaN(aId)) return null;
			// FIX: convert the AI's percentage score into raw earned points
			// (manualScore), the same unit calculateTotalScore expects for
			// partial credit. Sending manualScore: null discarded the AI's
			// actual score and fell back to the boolean isCorrectOverride
			// path, which always awards full points — turning a 95% essay
			// into 100% once applied.
			const qDef = (formQuestions || []).find((q) => Number(q.id) === Number(x.answer?.questionId));
			const qPoints = qDef && Number(qDef.points) > 0 ? Number(qDef.points) : 1;
			const pct = Math.max(0, Math.min(100, Number(x.suggestion.score) || 0));
			const rawPoints = Math.round(pct / 100 * qPoints * 100) / 100;
			return {
				answerId: aId,
				manualScore: rawPoints,
				isCorrectOverride: pct > 0,
				overrideNote: `AI Holistic: ${x.suggestion.reason} (Nilai: ${x.suggestion.score})`
			};
		}).filter(Boolean);
		if (overrides.length === 0) {
			showToast("Tidak ada jawaban dengan ID valid untuk di-apply.", "error");
			return;
		}
		const res = await bulkOverrideAnswerScores(responseId, overrides);
		if (res.ok) {
			overrides.forEach((o) => {
				const matchedEssay = aiHolisticResult.essaySuggestions.find((x) => parseInt(x.answerId, 10) === o.answerId);
				const qId = matchedEssay?.answer?.questionId;
				if (qId) {
					saveLocalManualOverride(id, responseId, qId, o.isCorrectOverride);
				}
			});
			setSelectedRespondent((prev) => {
				if (!prev) return prev;
				const updatedAnswers = (prev.answers || []).map((a) => {
					const matchedSug = aiHolisticResult.essaySuggestions.find((x) => Number(x.answer?.questionId) === Number(a.questionId));
					if (matchedSug) {
						const qDef = (formQuestions || []).find((q) => Number(q.id) === Number(a.questionId));
						const qPoints = qDef && Number(qDef.points) > 0 ? Number(qDef.points) : 1;
						const pct = Math.max(0, Math.min(100, Number(matchedSug.suggestion.score) || 0));
						const rawPoints = Math.round(pct / 100 * qPoints * 100) / 100;
						return {
							...a,
							isCorrectOverride: pct > 0,
							isCorrect: pct > 0,
							manualScore: rawPoints
						};
					}
					return a;
				});
				const scoring = calculateTotalScore(updatedAnswers, formQuestions);
				return {
					...prev,
					answers: updatedAnswers,
					correctCount: scoring.correctCount,
					wrongCount: scoring.wrongCount,
					score: scoring.score
				};
			});
			// Also update analytics list
			setAnalytics((prev) => {
				if (!prev?.respondents) return prev;
				return {
					...prev,
					respondents: prev.respondents.map((r) => {
						if (r.responseId !== responseId) return r;
						const updatedAnswers = (r.answers || []).map((a) => {
							const matchedSug = aiHolisticResult.essaySuggestions.find((x) => Number(x.answer?.questionId) === Number(a.questionId));
							if (matchedSug) {
								const qDef = (formQuestions || []).find((q) => Number(q.id) === Number(a.questionId));
								const qPoints = qDef && Number(qDef.points) > 0 ? Number(qDef.points) : 1;
								const pct = Math.max(0, Math.min(100, Number(matchedSug.suggestion.score) || 0));
								const rawPoints = Math.round(pct / 100 * qPoints * 100) / 100;
								return {
									...a,
									isCorrectOverride: pct > 0,
									isCorrect: pct > 0,
									manualScore: rawPoints
								};
							}
							return a;
						});
						const scoring = calculateTotalScore(updatedAnswers, formQuestions);
						return {
							...r,
							answers: updatedAnswers,
							correctCount: scoring.correctCount,
							wrongCount: scoring.wrongCount,
							score: scoring.score,
							isCustomScore: true
						};
					})
				};
			});
			setAiHolisticPreviewOpen(false);
			setAiHolisticResult(null);
			showToast(`${overrides.length} skor essay AI berhasil diterapkan!`);
		} else {
			showToast(res.message || "Gagal menerapkan skor AI.", "error");
		}
	};
	// Preview adjustments before applying
	const previewAdjustments = useMemo(() => {
		return respondentsList.map((r) => {
			const current = r.score != null ? r.score : 0;
			let meetsFilter = true;
			if (bulkFilter === "below") {
				meetsFilter = current < filterThreshold;
			} else if (bulkFilter === "range") {
				meetsFilter = current >= filterRangeMin && current <= filterRangeMax;
			}
			let projected = current;
			if (meetsFilter) {
				if (bulkType === "min") {
					projected = Math.max(current, bulkValue);
				} else if (bulkType === "bonus") {
					projected = Math.min(100, Math.max(0, current + bulkValue));
				} else if (bulkType === "scale") {
					projected = Math.min(100, Math.max(0, Math.round(current * (bulkValue / 100) * 10) / 10));
				} else if (bulkType === "set_fixed") {
					projected = Math.min(100, Math.max(0, bulkValue));
				}
			}
			return {
				...r,
				currentScore: current,
				projectedScore: Math.round(projected * 10) / 10,
				diff: Math.round((projected - current) * 10) / 10,
				meetsFilter
			};
		});
	}, [
		respondentsList,
		bulkType,
		bulkFilter,
		filterThreshold,
		filterRangeMin,
		filterRangeMax,
		bulkValue
	]);
	const handleApplyBulkScore = () => {
		setAnalytics((prev) => {
			if (!prev?.respondents) return prev;
			const updated = prev.respondents.map((r) => {
				const item = previewAdjustments.find((p) => p.responseId === r.responseId);
				if (!item || !item.meetsFilter) return r;
				return {
					...r,
					score: item.projectedScore,
					isCustomScore: true
				};
			});
			return {
				...prev,
				respondents: updated
			};
		});
		setBulkModalOpen(false);
		showToast("Penyesuaian skor massal berhasil diterapkan!");
	};
	const handleResetAllScores = async () => {
		setBulkModalOpen(false);
		// Reload analytics fresh from server
		const res = await getFormAnalytics(id, 1, 100);
		if (res.ok && res.data) setAnalytics(res.data);
		showToast("Skor dikembalikan ke perhitungan sistem.");
	};
	// Trend calculations
	const trendData = useMemo(() => {
		if (!respondentsList || respondentsList.length === 0) return [];
		const dateMap = {};
		respondentsList.forEach((r) => {
			if (!r.submittedAt) return;
			const d = new Date(r.submittedAt).toLocaleDateString("id-ID", {
				day: "2-digit",
				month: "short"
			});
			dateMap[d] = (dateMap[d] || 0) + 1;
		});
		return Object.entries(dateMap).map(([date, count]) => ({
			date,
			count
		}));
	}, [respondentsList]);
	const maxCount = useMemo(() => {
		if (trendData.length === 0) return 1;
		return Math.max(...trendData.map((d) => d.count), 1);
	}, [trendData]);
	const currentIndex = selectedRespondent ? respondentsList.findIndex((r) => r.responseId === selectedRespondent.responseId) : -1;
	const goPrevious = () => {
		if (currentIndex > 0) {
			openRespondentReview(respondentsList[currentIndex - 1]);
		}
	};
	const goNext = () => {
		if (currentIndex < respondentsList.length - 1) {
			openRespondentReview(respondentsList[currentIndex + 1]);
		}
	};
	const getAnswerStatus = (answer, qDef = null) => {
		const q = qDef || (formQuestions || []).find((f) => Number(f.id) === Number(answer?.questionId));
		const effective = getEffectiveIsCorrect(answer, q);
		if (effective === true) {
			return {
				label: "Benar",
				icon: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1375,
					columnNumber: 23
				}, this),
				className: "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
			};
		}
		if (effective === false) {
			return {
				label: "Salah",
				icon: /* @__PURE__ */ _jsxDEV(XCircle, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1382,
					columnNumber: 23
				}, this),
				className: "text-red-600 bg-red-50 dark:bg-red-950/60 dark:text-red-400 border-red-200 dark:border-red-800"
			};
		}
		return {
			label: "Tidak Dinilai",
			icon: /* @__PURE__ */ _jsxDEV(MinusCircle, { size: 16 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1388,
				columnNumber: 19
			}, this),
			className: "text-slate-500 bg-slate-50 dark:bg-slate-800 dark:text-slate-400 border-slate-200 dark:border-slate-700"
		};
	};
	if (loading) return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center justify-center min-h-screen bg-[#F4F8F7] dark:bg-slate-950",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center space-y-2",
			children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin mx-auto text-[#00897B] dark:text-teal-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1396,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-slate-400 dark:text-slate-500 text-sm font-medium",
				children: "Memuat respons..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1397,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 1395,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 1394,
		columnNumber: 9
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen w-full bg-[#F4F8F7] dark:bg-slate-950 font-sans antialiased text-slate-800 dark:text-slate-100 transition-colors",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1404,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col min-w-0 overflow-y-auto",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 py-4 flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3 min-w-0",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => navigate("/my-forms"),
								className: "p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all",
								children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1414,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1410,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("h1", {
									className: "text-base font-extrabold text-slate-900 dark:text-white truncate",
									children: form?.title || "Formulir"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1417,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 dark:text-slate-500",
									children: [respondentsList.length, " total respons masuk"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1420,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1416,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1409,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 shrink-0",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => navigate(`/forms/${id}/analytics`),
									className: "flex items-center gap-1.5 px-3.5 py-2 bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/60 dark:hover:bg-teal-900 text-[#00897B] dark:text-teal-400 text-xs font-bold rounded-xl transition-all cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(BarChart2, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1430,
										columnNumber: 29
									}, this), " Analisis"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1426,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("label", {
									className: "flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 select-none cursor-pointer font-medium px-2 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "checkbox",
										checked: includeAnswerKey,
										onChange: (e) => setIncludeAnswerKey(e.target.checked),
										className: "rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1434,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Kunci Jawaban" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1440,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1433,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleExport(id, "csv"),
									disabled: exporting,
									className: "flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs disabled:opacity-60 cursor-pointer",
									title: "Unduh format CSV",
									children: [exporting ? /* @__PURE__ */ _jsxDEV(Loader2, {
										size: 13,
										className: "animate-spin"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1450,
										columnNumber: 42
									}, this) : /* @__PURE__ */ _jsxDEV(Download, { size: 13 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1450,
										columnNumber: 91
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "CSV" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1451,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1443,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleExport(id, "xlsx"),
									disabled: exporting,
									className: "flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs disabled:opacity-60 cursor-pointer",
									title: "Unduh format Excel (.xlsx)",
									children: [/* @__PURE__ */ _jsxDEV(Download, { size: 13 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1461,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Excel" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1462,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1454,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleExport(id, "pdf"),
									disabled: exporting,
									className: "flex items-center gap-1.5 px-3 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs disabled:opacity-60 cursor-pointer",
									title: "Unduh format PDF (.pdf)",
									children: [/* @__PURE__ */ _jsxDEV(Download, { size: 13 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1472,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PDF" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1473,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1465,
									columnNumber: 25
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1425,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1408,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setActiveTab("responses"),
									className: `flex items-center gap-1.5 py-3.5 px-5 text-xs font-extrabold border-b-2 transition-all cursor-pointer ${activeTab === "responses" ? "border-[#00897B] text-[#00897B] dark:border-teal-400 dark:text-teal-400" : "border-transparent text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"}`,
									children: [/* @__PURE__ */ _jsxDEV(Eye, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1489,
										columnNumber: 29
									}, this), " Respons"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1481,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setActiveTab("feedback"),
									className: `flex items-center gap-1.5 py-3.5 px-5 text-xs font-extrabold border-b-2 transition-all cursor-pointer ${activeTab === "feedback" ? "border-amber-500 text-amber-600 dark:border-amber-400 dark:text-amber-400" : "border-transparent text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"}`,
									children: [
										/* @__PURE__ */ _jsxDEV(MessageSquare, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1499,
											columnNumber: 29
										}, this),
										" Masukan",
										feedbacks.length > 0 && /* @__PURE__ */ _jsxDEV("span", {
											className: "px-1.5 py-0.5 rounded-full text-[10px] bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300",
											children: feedbacks.length
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1501,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1491,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setActiveTab("monitoring"),
									className: `flex items-center gap-2 py-3.5 px-5 text-xs font-extrabold border-b-2 transition-all cursor-pointer ${activeTab === "monitoring" ? "border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400" : "border-transparent text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"}`,
									children: [
										/* @__PURE__ */ _jsxDEV(ShieldAlert, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1514,
											columnNumber: 29
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "Monitoring" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1515,
											columnNumber: 29
										}, this),
										monitoringData?.onlineCount > 0 && /* @__PURE__ */ _jsxDEV("span", {
											className: "flex h-2 w-2 relative",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1518,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("span", { className: "relative inline-flex rounded-full h-2 w-2 bg-emerald-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1519,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1517,
											columnNumber: 33
										}, this),
										monitoringData?.sessions && /* @__PURE__ */ _jsxDEV("span", {
											className: "px-1.5 py-0.5 rounded-full text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300",
											children: monitoringData.sessions.length
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1523,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1506,
									columnNumber: 25
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1480,
							columnNumber: 21
						}, this), activeTab === "monitoring" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3 py-2",
							children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "checkbox",
										checked: autoRefresh,
										onChange: (e) => setAutoRefresh(e.target.checked),
										className: "w-3.5 h-3.5 accent-indigo-600 rounded cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1533,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "hidden sm:inline",
										children: "Auto-refresh (5s)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1539,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1532,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => fetchExamMonitoring(false),
									disabled: monitoringLoading,
									className: "flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-all cursor-pointer disabled:opacity-50",
									title: "Segarkan Data Monitoring",
									children: [/* @__PURE__ */ _jsxDEV(RefreshCw, {
										size: 12,
										className: monitoringLoading ? "animate-spin" : ""
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1548,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Segarkan" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1549,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1541,
									columnNumber: 29
								}, this),
								lastRefreshedAt && /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] text-slate-400 dark:text-slate-500 hidden md:inline",
									children: lastRefreshedAt.toLocaleTimeString("id-ID")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1552,
									columnNumber: 33
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1531,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1479,
						columnNumber: 17
					}, this),
					toast && /* @__PURE__ */ _jsxDEV("div", {
						className: `fixed top-4 right-4 z-50 px-4 py-3 rounded-2xl shadow-xl text-xs font-bold text-white transition-all ${toast.type === "error" ? "bg-red-500" : "bg-[#00897B]"}`,
						children: toast.msg
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1561,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-6 max-w-6xl mx-auto w-full space-y-6",
						children: [
							activeTab === "responses" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [trendData.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(TrendingUp, {
											size: 16,
											className: "text-[#00897B] dark:text-teal-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1577,
											columnNumber: 49
										}, this), "Diagram Tren Respons Formulir"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1576,
										columnNumber: 45
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 dark:text-slate-500 mt-0.5",
										children: "Perkembangan jumlah pengiriman berdasarkan tanggal submit"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1580,
										columnNumber: 45
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1575,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-bold px-2.5 py-1 rounded-full bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400",
										children: [trendData.length, " Titik Data"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1584,
										columnNumber: 41
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1574,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "h-44 flex items-end gap-3 pt-6 pb-2 px-2 border-b border-slate-100 dark:border-slate-800",
									children: trendData.map((item, idx) => {
										const heightPercent = Math.max(item.count / maxCount * 100, 15);
										return /* @__PURE__ */ _jsxDEV("div", {
											className: "flex-1 flex flex-col items-center gap-2 h-full justify-end group",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-extrabold text-[#00897B] dark:text-teal-400 opacity-0 group-hover:opacity-100 transition-opacity",
													children: item.count
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1594,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "w-full bg-linear-to-t from-[#00897B] to-[#4DB6AC] dark:from-teal-600 dark:to-teal-400 rounded-t-lg transition-all duration-500 group-hover:brightness-110 shadow-xs",
													style: { height: `${heightPercent}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1597,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-semibold text-slate-400 dark:text-slate-500 truncate w-full text-center",
													children: item.date
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1601,
													columnNumber: 53
												}, this)
											]
										}, idx, true, {
											fileName: _jsxFileName,
											lineNumber: 1593,
											columnNumber: 49
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1589,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1573,
								columnNumber: 33
							}, this), respondentsList.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "text-center py-16 px-4 bg-white dark:bg-slate-900 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center space-y-4 shadow-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-14 h-14 rounded-2xl bg-teal-50 dark:bg-teal-950/60 flex items-center justify-center text-[#00897B] dark:text-teal-400",
										children: /* @__PURE__ */ _jsxDEV(MessageSquare, { size: 28 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1614,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1613,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1 max-w-sm",
										children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-base font-bold text-slate-900 dark:text-white",
											children: "Belum Ada Respons Masuk"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1617,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500 dark:text-slate-400 leading-relaxed",
											children: "Formulir ini belum menerima kiriman jawaban dari audiens. Bagikan tautan formulir Anda agar responden dapat mulai mengisi."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1620,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1616,
										columnNumber: 37
									}, this),
									form?.formLink && /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => {
											const url = `${window.location.origin}/f/${form.formLink}`;
											navigator.clipboard.writeText(url);
											showToast("Tautan formulir berhasil disalin ke clipboard!");
										},
										className: "inline-flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV(Share2, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1634,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Salin Tautan Formulir" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1635,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1625,
										columnNumber: 41
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1612,
								columnNumber: 33
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ _jsxDEV("h2", {
											className: "text-sm font-bold text-slate-900 dark:text-white",
											children: "Daftar Respons Masuk"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1643,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-slate-400 dark:text-slate-500",
											children: [respondentsList.length, " Total Respons"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1644,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1642,
										columnNumber: 41
									}, this), respondentsList.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setBulkModalOpen(true),
											className: "flex items-center gap-1.5 px-3 py-1.5 bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-[#00897B] dark:text-teal-400 hover:bg-teal-100 dark:hover:bg-teal-900/60 rounded-xl text-xs font-bold transition-all shadow-2xs cursor-pointer",
											title: "Ubah skor seluruh responden secara massal (bonus, skala, dll)",
											children: [/* @__PURE__ */ _jsxDEV(Sliders, { size: 13 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1655,
												columnNumber: 53
											}, this), " Penyesuaian Skor Massal"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1649,
											columnNumber: 49
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1648,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1641,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "overflow-x-auto w-full",
									children: /* @__PURE__ */ _jsxDEV("table", {
										className: "w-full text-sm text-left",
										children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
											className: "bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800",
											children: [
												/* @__PURE__ */ _jsxDEV("th", {
													className: "py-3 px-4",
													children: "#"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1665,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "py-3 px-4",
													children: "Responden"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1666,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "py-3 px-4",
													children: "Soal Dijawab"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1667,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "py-3 px-4",
													children: "Benar"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1668,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "py-3 px-4",
													children: "Salah"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1669,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "py-3 px-4",
													children: "Skor"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1670,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "py-3 px-4",
													children: "Status"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1671,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "py-3 px-4",
													children: "Waktu Submit"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1672,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "py-3 px-4 text-right",
													children: "Aksi"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1673,
													columnNumber: 53
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1664,
											columnNumber: 49
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1663,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("tbody", {
											className: "divide-y divide-slate-100 dark:divide-slate-800",
											children: respondentsList.map((r, i) => {
												const scorable = r.scorableQuestions ?? 0;
												const correct = r.correctCount ?? 0;
												const wrong = r.wrongCount != null ? r.wrongCount : Math.max(scorable - correct, 0);
												const isEditing = editingScoreId === r.responseId;
												return /* @__PURE__ */ _jsxDEV("tr", {
													className: "hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors",
													children: [
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-slate-400 font-medium",
															children: i + 1
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1685,
															columnNumber: 61
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4",
															children: [/* @__PURE__ */ _jsxDEV("div", {
																className: "font-bold text-slate-900 dark:text-white",
																children: r.respondentName || "Anonim"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1687,
																columnNumber: 65
															}, this), /* @__PURE__ */ _jsxDEV("div", {
																className: "text-[10px] text-slate-400 dark:text-slate-500",
																children: ["#", r.responseId]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1688,
																columnNumber: 65
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1686,
															columnNumber: 61
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-slate-600 dark:text-slate-300 font-medium",
															children: [
																r.answeredCount ?? 0,
																"/",
																r.totalQuestions ?? 0
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1690,
															columnNumber: 61
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-emerald-600 dark:text-emerald-400 font-bold",
															children: correct
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1693,
															columnNumber: 61
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-red-500 dark:text-red-400 font-bold",
															children: wrong
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1696,
															columnNumber: 61
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4",
															children: isEditing ? /* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center gap-1",
																children: [
																	/* @__PURE__ */ _jsxDEV("input", {
																		type: "number",
																		min: "0",
																		max: "100",
																		step: "0.5",
																		value: inlineScoreInput,
																		onChange: (e) => setInlineScoreInput(e.target.value),
																		className: "w-16 px-2 py-1 bg-white dark:bg-slate-800 border border-[#00897B] rounded-lg text-xs font-bold text-slate-900 dark:text-white focus:outline-none",
																		autoFocus: true,
																		onKeyDown: (e) => e.key === "Enter" && handleSaveIndividualScore(r.responseId, inlineScoreInput)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1702,
																		columnNumber: 73
																	}, this),
																	/* @__PURE__ */ _jsxDEV("button", {
																		type: "button",
																		onClick: () => handleSaveIndividualScore(r.responseId, inlineScoreInput),
																		className: "p-1 bg-[#00897B] text-white rounded-lg hover:bg-[#00796B] cursor-pointer",
																		title: "Simpan Skor",
																		children: /* @__PURE__ */ _jsxDEV(Check, { size: 12 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 1719,
																			columnNumber: 77
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1713,
																		columnNumber: 73
																	}, this),
																	/* @__PURE__ */ _jsxDEV("button", {
																		type: "button",
																		onClick: () => setEditingScoreId(null),
																		className: "p-1 text-slate-400 hover:text-slate-600 cursor-pointer",
																		title: "Batal",
																		children: /* @__PURE__ */ _jsxDEV(X, { size: 12 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 1727,
																			columnNumber: 77
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1721,
																		columnNumber: 73
																	}, this)
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1701,
																columnNumber: 69
															}, this) : /* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center gap-1.5 group",
																children: [r.score != null ? /* @__PURE__ */ _jsxDEV("span", {
																	className: `text-xs font-bold px-2 py-0.5 rounded-full ${r.score >= 70 ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400" : "bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400"}`,
																	children: [
																		r.score,
																		"%",
																		r.isCustomScore && /* @__PURE__ */ _jsxDEV("span", {
																			className: "ml-1 text-[9px] opacity-75 font-normal",
																			children: "*edit"
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 1739,
																			columnNumber: 101
																		}, this)
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 1733,
																	columnNumber: 77
																}, this) : /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-xs text-slate-400 dark:text-slate-500 font-medium",
																	children: "N/A"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1742,
																	columnNumber: 77
																}, this), /* @__PURE__ */ _jsxDEV("button", {
																	type: "button",
																	onClick: () => {
																		setEditingScoreId(r.responseId);
																		setInlineScoreInput(r.score != null ? String(r.score) : "100");
																	},
																	className: "opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-[#00897B] rounded transition-opacity cursor-pointer",
																	title: "Ubah Nilai Responden",
																	children: /* @__PURE__ */ _jsxDEV(Edit2, { size: 12 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1753,
																		columnNumber: 77
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1744,
																	columnNumber: 73
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1731,
																columnNumber: 69
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1699,
															columnNumber: 61
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4",
															children: /* @__PURE__ */ _jsxDEV("select", {
																value: STATUS_OPTIONS.find((s) => s.code === r.status?.toLowerCase())?.id ?? 1,
																onChange: (e) => handleStatusChange(r.responseId, parseInt(e.target.value)),
																disabled: statusUpdating === r.responseId,
																className: `text-[11px] font-bold px-2.5 py-1 rounded-full border-0 cursor-pointer focus:outline-none focus:ring-1 focus:ring-teal-400 disabled:opacity-60 ${statusStyle(r.status)}`,
																children: STATUS_OPTIONS.map((s) => /* @__PURE__ */ _jsxDEV("option", {
																	value: s.id,
																	children: s.label
																}, s.id, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1766,
																	columnNumber: 73
																}, this))
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1759,
																columnNumber: 65
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1758,
															columnNumber: 61
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-slate-500 dark:text-slate-400 text-xs",
															children: formatDate(r.submittedAt)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1770,
															columnNumber: 61
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-right",
															children: /* @__PURE__ */ _jsxDEV("button", {
																onClick: () => openRespondentReview(r),
																className: "inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#00897B] hover:bg-[#00796B] text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer",
																children: [/* @__PURE__ */ _jsxDEV(Eye, { size: 13 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1778,
																	columnNumber: 69
																}, this), " Review Jawaban"]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1774,
																columnNumber: 65
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1773,
															columnNumber: 61
														}, this)
													]
												}, r.responseId || i, true, {
													fileName: _jsxFileName,
													lineNumber: 1684,
													columnNumber: 57
												}, this);
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1676,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1662,
										columnNumber: 41
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1661,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1640,
								columnNumber: 33
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1570,
								columnNumber: 25
							}, this),
							activeTab === "feedback" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: feedbackLoading ? /* @__PURE__ */ _jsxDEV("div", {
								className: "text-center py-16 text-slate-400 dark:text-slate-500 text-sm font-medium",
								children: "Memuat laporan masukan..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1796,
								columnNumber: 33
							}, this) : feedbacks.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "text-center py-16 space-y-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800",
								children: [
									/* @__PURE__ */ _jsxDEV(MessageSquare, {
										size: 32,
										className: "text-slate-300 dark:text-slate-600 mx-auto"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1799,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-500 dark:text-slate-400 text-sm font-bold",
										children: "Belum ada laporan masukan untuk formulir ini."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1800,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 dark:text-slate-500",
										children: "Masukan dikirimkan oleh responden setelah menyelesaikan formulir."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1801,
										columnNumber: 37
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1798,
								columnNumber: 33
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: feedbacks.map((fb, i) => /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start justify-between gap-3",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-extrabold px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800 flex items-center gap-1.5",
												children: [
													/* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 13 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1809,
														columnNumber: 53
													}, this),
													" ",
													fb.reason
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1808,
												columnNumber: 49
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs text-slate-400 dark:text-slate-500 font-medium shrink-0",
												children: formatDate(fb.createdAt)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1811,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1807,
											columnNumber: 45
										}, this),
										fb.description && /* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm text-slate-700 dark:text-slate-200 leading-relaxed border-l-2 border-amber-300 dark:border-amber-500 pl-3",
											children: fb.description
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1815,
											columnNumber: 49
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-3 pt-1 border-t border-slate-100 dark:border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "w-6 h-6 bg-teal-100 dark:bg-teal-950 text-[#00897B] dark:text-teal-400 rounded-full flex items-center justify-center text-[10px] font-black shrink-0",
												children: (fb.userName || "U").charAt(0).toUpperCase()
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1821,
												columnNumber: 49
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold text-slate-800 dark:text-slate-200",
												children: fb.userName || "Anonim"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1824,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1820,
											columnNumber: 45
										}, this)
									]
								}, fb.id ?? i, true, {
									fileName: _jsxFileName,
									lineNumber: 1806,
									columnNumber: 41
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1804,
								columnNumber: 33
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1794,
								columnNumber: 25
							}, this),
							activeTab === "monitoring" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-6",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs font-bold uppercase tracking-wider",
															children: "Mode Ujian"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1840,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV(ShieldCheck, {
															size: 18,
															className: monitoringData?.isExamMode || monitoringData?.detectTabSwitch ? "text-emerald-500" : "text-slate-400"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1841,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1839,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2",
														children: /* @__PURE__ */ _jsxDEV("span", {
															className: `text-base font-extrabold px-2.5 py-0.5 rounded-full text-xs ${monitoringData?.isExamMode || monitoringData?.detectTabSwitch ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800" : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400"}`,
															children: monitoringData?.isExamMode || monitoringData?.detectTabSwitch ? "Aktif" : "Nonaktif"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1844,
															columnNumber: 41
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1843,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-slate-400 dark:text-slate-500 mt-2",
														children: monitoringData?.autoSubmitOnTabSwitch ? `Auto-submit: Maks ${monitoringData.maxTabSwitch || 3}x tab switch` : "Pencatatan pelanggaran aktif"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1852,
														columnNumber: 37
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1838,
												columnNumber: 33
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs font-bold uppercase tracking-wider",
															children: "Sedang Mengerjakan"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1861,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV(Activity, {
															size: 18,
															className: "text-amber-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1862,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1860,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-baseline gap-2",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "text-2xl font-black text-slate-900 dark:text-white",
															children: monitoringData?.inProgressCount ?? 0
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1865,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs text-slate-400 font-semibold",
															children: "peserta"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1868,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1864,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-amber-600 dark:text-amber-400 font-semibold mt-2",
														children: "Belum mengirimkan jawaban"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1870,
														columnNumber: 37
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1859,
												columnNumber: 33
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs font-bold uppercase tracking-wider",
															children: "Online Live"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1877,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV(Radio, {
															size: 18,
															className: "text-emerald-500 animate-pulse"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1878,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1876,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-baseline gap-2",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "text-2xl font-black text-emerald-600 dark:text-emerald-400",
															children: monitoringData?.onlineCount ?? 0
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1881,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs text-slate-400 font-semibold",
															children: "aktif saat ini"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1884,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1880,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-slate-400 dark:text-slate-500 mt-2",
														children: "Ada aktivitas 90 detik terakhir"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1886,
														columnNumber: 37
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1875,
												columnNumber: 33
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs font-bold uppercase tracking-wider",
															children: "Sudah Submit"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1893,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV(CheckCircle2, {
															size: 18,
															className: "text-blue-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1894,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1892,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-baseline gap-2",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "text-2xl font-black text-slate-900 dark:text-white",
															children: monitoringData?.submittedCount ?? 0
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1897,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs text-slate-400 font-semibold",
															children: "selesai"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1900,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1896,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-slate-400 dark:text-slate-500 mt-2",
														children: "Jawaban telah tersimpan"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1902,
														columnNumber: 37
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1891,
												columnNumber: 33
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1837,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0",
											children: [
												{
													id: "all",
													label: "Semua Peserta"
												},
												{
													id: "in_progress",
													label: "Sedang Mengerjakan"
												},
												{
													id: "submitted",
													label: "Sudah Submit"
												},
												{
													id: "violations",
													label: "Ada Pelanggaran"
												},
												{
													id: "high_violations",
													label: "Pelanggaran Tinggi"
												}
											].map((tab) => /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setMonitoringFilter(tab.id),
												className: `px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${monitoringFilter === tab.id ? "bg-indigo-600 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
												children: tab.label
											}, tab.id, false, {
												fileName: _jsxFileName,
												lineNumber: 1918,
												columnNumber: 41
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1910,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative w-full md:w-64",
											children: [/* @__PURE__ */ _jsxDEV(Search, {
												size: 14,
												className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1934,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												placeholder: "Cari nama responden...",
												value: monitoringSearch,
												onChange: (e) => setMonitoringSearch(e.target.value),
												className: "w-full pl-9 pr-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs outline-none focus:border-indigo-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1935,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1933,
											columnNumber: 33
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1909,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden",
										children: monitoringLoading && !monitoringData ? /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-center p-12 text-slate-400 gap-2",
											children: [/* @__PURE__ */ _jsxDEV(Loader2, {
												size: 18,
												className: "animate-spin text-indigo-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1949,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold",
												children: "Memuat data monitoring..."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1950,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1948,
											columnNumber: 37
										}, this) : filteredSessions.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
											className: "text-center p-12 text-slate-400 dark:text-slate-500",
											children: [
												/* @__PURE__ */ _jsxDEV(ShieldAlert, {
													size: 36,
													className: "mx-auto mb-2 text-slate-300 dark:text-slate-600"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1954,
													columnNumber: 41
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-sm font-bold text-slate-700 dark:text-slate-300",
													children: "Belum ada peserta ujian ditemukan"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1955,
													columnNumber: 41
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs mt-1",
													children: "Peserta yang membuka halaman ujian akan otomatis tercatat dan muncul di sini secara real-time."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1956,
													columnNumber: 41
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1953,
											columnNumber: 37
										}, this) : /* @__PURE__ */ _jsxDEV("div", {
											className: "overflow-x-auto",
											children: /* @__PURE__ */ _jsxDEV("table", {
												className: "w-full text-left border-collapse",
												children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
													className: "border-b border-slate-200 dark:border-slate-800 text-[11px] font-extrabold uppercase text-slate-400 dark:text-slate-500 bg-slate-50/70 dark:bg-slate-800/50",
													children: [
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Responden"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1963,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Status Pengerjaan"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1964,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Pindah Tab"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1965,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Total Pelanggaran"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1966,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Aktivitas Terakhir"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1967,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4 text-right",
															children: "Aksi & Log"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1968,
															columnNumber: 53
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1962,
													columnNumber: 49
												}, this) }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1961,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("tbody", {
													className: "divide-y divide-slate-100 dark:divide-slate-800 text-xs",
													children: filteredSessions.map((session, idx) => {
														const isExpanded = expandedSessions.has(session.sessionId || `session-${idx}`);
														const maxSw = monitoringData?.maxTabSwitch || 3;
														const genuineViolationCount = getGenuineViolationCount(session);
														const isHighViolation = genuineViolationCount >= maxSw || session.tabSwitchCount >= maxSw;
														return /* @__PURE__ */ _jsxDEV(Fragment, { children: [/* @__PURE__ */ _jsxDEV("tr", {
															className: `hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors ${isHighViolation ? "bg-red-50/30 dark:bg-red-950/10" : ""}`,
															children: [
																/* @__PURE__ */ _jsxDEV("td", {
																	className: "py-3.5 px-4",
																	children: /* @__PURE__ */ _jsxDEV("div", {
																		className: "flex items-center gap-3",
																		children: [/* @__PURE__ */ _jsxDEV("div", {
																			className: "relative shrink-0",
																			children: [/* @__PURE__ */ _jsxDEV("div", {
																				className: "w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center font-bold text-slate-700 dark:text-slate-200 text-xs",
																				children: (session.respondentName || "A").charAt(0).toUpperCase()
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 1986,
																				columnNumber: 77
																			}, this), session.isOnline ? /* @__PURE__ */ _jsxDEV("span", {
																				className: "absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900",
																				title: "Sedang Online"
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 1990,
																				columnNumber: 81
																			}, this) : /* @__PURE__ */ _jsxDEV("span", {
																				className: "absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-600 ring-2 ring-white dark:ring-slate-900",
																				title: "Offline"
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 1992,
																				columnNumber: 81
																			}, this)]
																		}, void 0, true, {
																			fileName: _jsxFileName,
																			lineNumber: 1985,
																			columnNumber: 73
																		}, this), /* @__PURE__ */ _jsxDEV("div", {
																			className: "min-w-0",
																			children: [/* @__PURE__ */ _jsxDEV("div", {
																				className: "font-bold text-slate-900 dark:text-white flex items-center gap-1.5 flex-wrap",
																				children: [/* @__PURE__ */ _jsxDEV("span", {
																					className: "truncate",
																					children: session.respondentName || "Anonim"
																				}, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 1997,
																					columnNumber: 81
																				}, this), session.isOnline && /* @__PURE__ */ _jsxDEV("span", {
																					className: "text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded",
																					children: "Online"
																				}, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 1999,
																					columnNumber: 85
																				}, this)]
																			}, void 0, true, {
																				fileName: _jsxFileName,
																				lineNumber: 1996,
																				columnNumber: 77
																			}, this), /* @__PURE__ */ _jsxDEV("div", {
																				className: "text-[10px] text-slate-400 dark:text-slate-500 font-mono",
																				children: session.sessionId ? `Sesi: ${session.sessionId.slice(0, 8)}...` : session.responseId ? `Respons #${session.responseId}` : "Sesi Langsung"
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 2004,
																				columnNumber: 77
																			}, this)]
																		}, void 0, true, {
																			fileName: _jsxFileName,
																			lineNumber: 1995,
																			columnNumber: 73
																		}, this)]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 1984,
																		columnNumber: 69
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1983,
																	columnNumber: 65
																}, this),
																/* @__PURE__ */ _jsxDEV("td", {
																	className: "py-3.5 px-4",
																	children: session.status === "in_progress" ? /* @__PURE__ */ _jsxDEV("span", {
																		className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800",
																		children: [/* @__PURE__ */ _jsxDEV(Activity, {
																			size: 12,
																			className: "animate-pulse"
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 2014,
																			columnNumber: 77
																		}, this), "Sedang Mengerjakan"]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 2013,
																		columnNumber: 73
																	}, this) : /* @__PURE__ */ _jsxDEV("span", {
																		className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800",
																		children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 12 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 2019,
																			columnNumber: 77
																		}, this), "Sudah Submit"]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 2018,
																		columnNumber: 73
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2011,
																	columnNumber: 65
																}, this),
																/* @__PURE__ */ _jsxDEV("td", {
																	className: "py-3.5 px-4 font-semibold",
																	children: session.tabSwitchCount > 0 ? /* @__PURE__ */ _jsxDEV("span", {
																		className: `font-bold ${session.tabSwitchCount >= maxSw ? "text-red-600 dark:text-red-400" : "text-slate-700 dark:text-slate-300"}`,
																		children: [session.tabSwitchCount, "x"]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 2027,
																		columnNumber: 73
																	}, this) : /* @__PURE__ */ _jsxDEV("span", {
																		className: "text-slate-400",
																		children: "0x"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 2031,
																		columnNumber: 73
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2025,
																	columnNumber: 65
																}, this),
																/* @__PURE__ */ _jsxDEV("td", {
																	className: "py-3.5 px-4",
																	children: genuineViolationCount === 0 ? /* @__PURE__ */ _jsxDEV("span", {
																		className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800",
																		children: "✓ Bersih (0)"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 2037,
																		columnNumber: 9
																	}, this) : isHighViolation ? /* @__PURE__ */ _jsxDEV("span", {
																		className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-red-100 text-red-700 dark:bg-red-950/70 dark:text-red-300 border border-red-300 dark:border-red-800 animate-pulse",
																		children: [
																			/* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 12 }, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 2042,
																				columnNumber: 13
																			}, this),
																			genuineViolationCount,
																			" Pelanggaran (Tinggi)"
																		]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 2041,
																		columnNumber: 9
																	}, this) : /* @__PURE__ */ _jsxDEV("span", {
																		className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800",
																		children: [
																			"⚠️ ",
																			genuineViolationCount,
																			" Pelanggaran"
																		]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 2046,
																		columnNumber: 9
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2035,
																	columnNumber: 65
																}, this),
																/* @__PURE__ */ _jsxDEV("td", {
																	className: "py-3.5 px-4 text-slate-500 dark:text-slate-400 text-[11px]",
																	children: [/* @__PURE__ */ _jsxDEV("div", { children: formatDate(session.lastSeenAt || session.startedAt) }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 2053,
																		columnNumber: 69
																	}, this), /* @__PURE__ */ _jsxDEV("div", {
																		className: "text-[10px] text-slate-400",
																		children: ["Mulai: ", formatDate(session.startedAt)]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 2054,
																		columnNumber: 69
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 2052,
																	columnNumber: 65
																}, this),
																/* @__PURE__ */ _jsxDEV("td", {
																	className: "py-3.5 px-4 text-right",
																	children: /* @__PURE__ */ _jsxDEV("div", {
																		className: "flex items-center justify-end gap-1.5 flex-wrap",
																		children: [
																			session.sessionId && session.status === "in_progress" && /* @__PURE__ */ _jsxDEV("button", {
																				type: "button",
																				onClick: () => handleOpenForceSubmit(session),
																				className: "inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-800 rounded-lg transition-all cursor-pointer",
																				title: "Selesaikan paksa sesi ujian peserta ini",
																				children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, { size: 12 }, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 2068,
																					columnNumber: 81
																				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Force Submit" }, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 2069,
																					columnNumber: 81
																				}, this)]
																			}, void 0, true, {
																				fileName: _jsxFileName,
																				lineNumber: 2062,
																				columnNumber: 77
																			}, this),
																			session.sessionId && session.status === "submitted" && /* @__PURE__ */ _jsxDEV("button", {
																				type: "button",
																				onClick: () => handleOpenResetSession(session),
																				className: "inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-800 rounded-lg transition-all cursor-pointer",
																				title: "Reset jawaban yang sudah disubmit agar peserta dapat mengisi ulang",
																				children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 12 }, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 2079,
																					columnNumber: 81
																				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset Jawaban" }, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 2080,
																					columnNumber: 81
																				}, this)]
																			}, void 0, true, {
																				fileName: _jsxFileName,
																				lineNumber: 2073,
																				columnNumber: 77
																			}, this),
																			/* @__PURE__ */ _jsxDEV("button", {
																				type: "button",
																				onClick: () => toggleSessionExpand(session.sessionId || `session-${idx}`),
																				className: "inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900 rounded-lg transition-all cursor-pointer",
																				children: [/* @__PURE__ */ _jsxDEV("span", { children: [
																					"Log (",
																					session.violations?.length || 0,
																					")"
																				] }, void 0, true, {
																					fileName: _jsxFileName,
																					lineNumber: 2088,
																					columnNumber: 77
																				}, this), isExpanded ? /* @__PURE__ */ _jsxDEV(ChevronUp, { size: 13 }, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 2089,
																					columnNumber: 91
																				}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 13 }, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 2089,
																					columnNumber: 117
																				}, this)]
																			}, void 0, true, {
																				fileName: _jsxFileName,
																				lineNumber: 2083,
																				columnNumber: 73
																			}, this)
																		]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 2060,
																		columnNumber: 69
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2059,
																	columnNumber: 65
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1980,
															columnNumber: 61
														}, this), isExpanded && /* @__PURE__ */ _jsxDEV("tr", {
															className: "bg-slate-50/60 dark:bg-slate-900/60",
															children: /* @__PURE__ */ _jsxDEV("td", {
																colSpan: 6,
																className: "p-4 pl-14",
																children: /* @__PURE__ */ _jsxDEV("div", {
																	className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3",
																	children: [/* @__PURE__ */ _jsxDEV("div", {
																		className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2",
																		children: [/* @__PURE__ */ _jsxDEV("span", {
																			className: "text-xs font-bold text-slate-800 dark:text-slate-200",
																			children: ["Log Rekaman Pelanggaran — ", session.respondentName || "Anonim"]
																		}, void 0, true, {
																			fileName: _jsxFileName,
																			lineNumber: 2101,
																			columnNumber: 81
																		}, this), /* @__PURE__ */ _jsxDEV("span", {
																			className: "text-[11px] text-slate-400",
																			children: [
																				"Total: ",
																				session.violations?.length || 0,
																				" kejadian"
																			]
																		}, void 0, true, {
																			fileName: _jsxFileName,
																			lineNumber: 2104,
																			columnNumber: 81
																		}, this)]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 2100,
																		columnNumber: 77
																	}, this), !session.violations || session.violations.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
																		className: "text-xs text-slate-400 italic py-2",
																		children: "Tidak ada riwayat pelanggaran untuk sesi ini. Peserta mengerjakan dengan tertib."
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 2110,
																		columnNumber: 81
																	}, this) : /* @__PURE__ */ _jsxDEV("div", {
																		className: "space-y-2",
																		children: session.violations.map((violation, vIdx) => {
																			const vInfo = getViolationInfo(violation.type);
																			return /* @__PURE__ */ _jsxDEV("div", {
																				className: "flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 text-xs",
																				children: [/* @__PURE__ */ _jsxDEV("div", {
																					className: "flex items-center gap-2.5",
																					children: [/* @__PURE__ */ _jsxDEV("span", {
																						className: `p-1 rounded-md ${vInfo.bg} ${vInfo.color}`,
																						children: vInfo.icon
																					}, void 0, false, {
																						fileName: _jsxFileName,
																						lineNumber: 2123,
																						columnNumber: 101
																					}, this), /* @__PURE__ */ _jsxDEV("span", {
																						className: "font-bold text-slate-800 dark:text-slate-200",
																						children: vInfo.label
																					}, void 0, false, {
																						fileName: _jsxFileName,
																						lineNumber: 2126,
																						columnNumber: 101
																					}, this)]
																				}, void 0, true, {
																					fileName: _jsxFileName,
																					lineNumber: 2122,
																					columnNumber: 97
																				}, this), /* @__PURE__ */ _jsxDEV("span", {
																					className: "text-[11px] font-mono text-slate-400 dark:text-slate-500",
																					children: formatDateWithTime(violation.occurredAt)
																				}, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 2130,
																					columnNumber: 97
																				}, this)]
																			}, vIdx, true, {
																				fileName: _jsxFileName,
																				lineNumber: 2118,
																				columnNumber: 93
																			}, this);
																		})
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 2114,
																		columnNumber: 81
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 2099,
																	columnNumber: 73
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2098,
																columnNumber: 69
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2097,
															columnNumber: 65
														}, this)] }, session.sessionId || `session-${idx}`, true, {
															fileName: _jsxFileName,
															lineNumber: 1979,
															columnNumber: 57
														}, this);
													})
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1971,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1960,
												columnNumber: 41
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1959,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1946,
										columnNumber: 29
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1835,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1566,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1406,
				columnNumber: 13
			}, this),
			selectedRespondent && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-black/50 backdrop-blur-xs",
					onClick: () => setSelectedRespondent(null)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 2159,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 w-full max-w-3xl max-h-[90vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 animate-in fade-in zoom-in-95 duration-200",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50/50 dark:bg-slate-800/50",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "font-bold text-slate-900 dark:text-white text-base",
								children: "Review Jawaban Responden"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2169,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 dark:text-slate-500 mt-0.5",
								children: [
									"Responden: ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-700 dark:text-slate-300",
										children: selectedRespondent.respondentName || "Anonim"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2173,
										columnNumber: 48
									}, this),
									" (Respons #",
									selectedRespondent.responseId,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2172,
								columnNumber: 33
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2168,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setSelectedRespondent(null),
								className: "p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2180,
									columnNumber: 33
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2176,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2167,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-3.5 bg-slate-100/60 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center gap-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-1.5 shadow-xs",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500",
											children: "Skor Total"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2188,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "number",
												min: "0",
												max: "100",
												step: "0.5",
												value: selectedRespondent.score != null ? selectedRespondent.score : "",
												onChange: (e) => {
													const val = parseFloat(e.target.value) || 0;
													setSelectedRespondent((prev) => ({
														...prev,
														score: val
													}));
												},
												onBlur: (e) => handleSaveIndividualScore(selectedRespondent.responseId, e.target.value),
												className: "w-16 text-base font-extrabold text-slate-900 dark:text-white bg-transparent border-b border-slate-300 dark:border-slate-600 focus:border-[#00897B] outline-none"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2190,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold text-slate-500",
												children: "%"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2203,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2189,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2187,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-1.5 shadow-xs",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500",
											children: "Dijawab"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2207,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-base font-extrabold text-slate-900 dark:text-white",
											children: [
												selectedRespondent.answeredCount,
												"/",
												selectedRespondent.totalQuestions
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2208,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2206,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-1.5 shadow-xs",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500",
											children: "Benar"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2213,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-base font-extrabold text-emerald-600 dark:text-emerald-400",
											children: selectedRespondent.correctCount ?? 0
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2214,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2212,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-1.5 shadow-xs",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500",
											children: "Waktu Submit"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2219,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-bold text-slate-700 dark:text-slate-300 mt-1",
											children: formatDate(selectedRespondent.submittedAt)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2220,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2218,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2186,
								columnNumber: 29
							}, this), (selectedRespondent.answers || []).some((a) => a.typeId === 1) && /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("select", {
									value: aiModel,
									onChange: (e) => {
										setAiModel(e.target.value);
										localStorage.setItem("formup_selected_model_chat", e.target.value);
									},
									className: "max-w-36 px-2 py-2 text-[11px] font-bold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200",
									children: AVAILABLE_MODELS.map((model) => /* @__PURE__ */ _jsxDEV("option", {
										value: model.id,
										children: model.name
									}, model.id, false, {
										fileName: _jsxFileName,
										lineNumber: 2229,
										columnNumber: 68
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2228,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleAiHolisticScore(selectedRespondent),
									disabled: aiHolisticScoring,
									className: "flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 cursor-pointer disabled:opacity-60 transition-colors",
									children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 13 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2237,
										columnNumber: 37
									}, this), aiHolisticScoring ? "Menilai..." : "Penilaian Pintar"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2231,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2227,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2185,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 overflow-y-auto p-6 space-y-4",
							children: [(selectedRespondent.answers || []).map((answer, index) => {
								const qDef = (formQuestions || []).find((q) => Number(q.id) === Number(answer.questionId));
								const effIsCorrect = getEffectiveIsCorrect(answer, qDef);
								const status = getAnswerStatus(answer, qDef);
								const keyAnswer = answer.correctAnswer || resolveQuestionKey(qDef);
								const qPoints = qDef && Number(qDef.points) > 0 ? Number(qDef.points) : 1;
								return /* @__PURE__ */ _jsxDEV("div", {
									className: "border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 bg-white dark:bg-slate-900 flex items-start gap-3 justify-between",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-start gap-3 flex-1 min-w-0",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "shrink-0 w-7 h-7 flex items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300",
													children: index + 1
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2260,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "flex-1 min-w-0",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "text-sm font-semibold text-slate-900 dark:text-white leading-relaxed break-words flex items-center gap-2 flex-wrap",
														children: [/* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: answer.question }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2265,
															columnNumber: 57
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700",
															children: [
																"Bobot: ",
																qPoints,
																" poin"
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2266,
															columnNumber: 57
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2264,
														columnNumber: 53
													}, this), answer.questionImage && /* @__PURE__ */ _jsxDEV("div", {
														className: "my-2 max-w-xs relative group/img overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700 p-1 bg-white dark:bg-slate-900 shadow-xs",
														children: [/* @__PURE__ */ _jsxDEV("img", {
															src: assetUrl(answer.questionImage),
															alt: "Gambar Soal",
															className: "max-h-40 w-auto rounded-lg object-contain mx-auto cursor-zoom-in",
															onClick: () => setLightboxImage({
																src: assetUrl(answer.questionImage),
																alt: "Gambar Soal"
															})
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2272,
															columnNumber: 61
														}, this), /* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => setLightboxImage({
																src: assetUrl(answer.questionImage),
																alt: "Gambar Soal"
															}),
															className: "absolute bottom-2 right-2 p-1.5 bg-slate-900/80 hover:bg-slate-900 text-white rounded-lg text-xs font-bold flex items-center gap-1 opacity-0 group-hover/img:opacity-100 transition-opacity cursor-pointer",
															children: [/* @__PURE__ */ _jsxDEV(Maximize2, { size: 11 }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2283,
																columnNumber: 65
															}, this), " Perbesar"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2278,
															columnNumber: 61
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2271,
														columnNumber: 57
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2263,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2259,
												columnNumber: 45
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "shrink-0 flex flex-col items-end gap-1.5",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: `flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-bold ${status.className}`,
														children: [status.icon, /* @__PURE__ */ _jsxDEV("span", { children: status.label }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2295,
															columnNumber: 57
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2293,
														columnNumber: 53
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700",
														children: [/* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => handleSetQuestionCorrect(selectedRespondent.responseId, answer.questionId, true),
															className: `px-2 py-1 text-[11px] font-bold rounded cursor-pointer transition-all ${effIsCorrect === true && answer.manualScore == null ? "bg-emerald-500 text-white shadow-2xs" : "text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
															title: "Koreksi: Tandai Benar (100%)",
															children: "Benar"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2298,
															columnNumber: 57
														}, this), /* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => handleSetQuestionCorrect(selectedRespondent.responseId, answer.questionId, false),
															className: `px-2 py-1 text-[11px] font-bold rounded cursor-pointer transition-all ${effIsCorrect === false ? "bg-red-500 text-white shadow-2xs" : "text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
															title: "Koreksi: Tandai Salah (0%)",
															children: "Salah"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2310,
															columnNumber: 57
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2297,
														columnNumber: 53
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2292,
													columnNumber: 49
												}, this), (answer.typeId === 1 || qDef?.typeId === 1) && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [partialScoreEditingId === (answer.answerId || answer.id || answer.questionId) ? /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ _jsxDEV("input", {
															type: "number",
															min: "0",
															max: "100",
															step: "1",
															autoFocus: true,
															value: partialScoreInput,
															onChange: (e) => setPartialScoreInput(e.target.value),
															onKeyDown: (e) => {
																if (e.key === "Escape") setPartialScoreEditingId(null);
															},
															className: "w-16 px-2 py-1 bg-white dark:bg-slate-800 border border-amber-400 dark:border-amber-600 rounded-lg text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-amber-500 text-center",
															placeholder: "0–100"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2332,
															columnNumber: 65
														}, this),
														/* @__PURE__ */ _jsxDEV("span", {
															className: "text-[11px] font-bold text-slate-500 dark:text-slate-400",
															children: "%"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2346,
															columnNumber: 65
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => setPartialScoreEditingId(null),
															className: "px-2 py-1 text-slate-400 hover:text-slate-600 text-[11px] font-bold rounded-lg cursor-pointer",
															title: "Batal",
															children: "✕"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2347,
															columnNumber: 65
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2331,
													columnNumber: 61
												}, this) : /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => {
														const currentPct = answer.manualScore != null ? Math.round(Number(answer.manualScore) / qPoints * 100) : effIsCorrect === true ? 100 : effIsCorrect === false ? 0 : "";
														setPartialScoreInput(String(currentPct));
														setPartialScoreEditingId(answer.answerId || answer.id || answer.questionId);
													},
													className: `text-[11px] font-bold px-2 py-0.5 rounded-lg border cursor-pointer transition-all ${answer.manualScore != null ? "bg-amber-50 dark:bg-amber-950/50 border-amber-300 dark:border-amber-700 text-amber-700 dark:text-amber-300" : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-amber-300 hover:text-amber-600"}`,
													title: "Atur skor parsial (%)",
													children: answer.manualScore != null ? `${Math.round(Number(answer.manualScore) / qPoints * 100)}% parsial` : "± Skor Parsial"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2357,
													columnNumber: 61
												}, this), activeCorrectionId !== (answer.answerId || answer.id || answer.questionId) ? /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => {
														const ansKey = answer.answerId || answer.id || answer.questionId;
														setActiveCorrectionId(ansKey);
														setCorrectionNote(answer.overrideNote || "");
														setCorrectionIsCorrectOverride(answer.isCorrectOverride !== undefined ? answer.isCorrectOverride : undefined);
														if (partialScoreEditingId !== ansKey) {
															const currentPct = answer.manualScore != null ? Math.round(Number(answer.manualScore) / qPoints * 100) : effIsCorrect === true ? 100 : effIsCorrect === false ? 0 : "";
															setPartialScoreInput(String(currentPct));
															setPartialScoreEditingId(ansKey);
														}
													},
													className: "text-[11px] font-bold px-2 py-0.5 rounded-lg border border-indigo-300 dark:border-indigo-700 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 cursor-pointer hover:bg-indigo-100 transition-all",
													title: "Buka panel koreksi lengkap (catatan + override status)",
													children: "📝 Koreksi Lengkap"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2381,
													columnNumber: 61
												}, this) : null] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2329,
													columnNumber: 53
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2291,
												columnNumber: 45
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2258,
											columnNumber: 41
										}, this),
										(answer.typeId === 1 || qDef?.typeId === 1) && activeCorrectionId === (answer.answerId || answer.id || answer.questionId) && /* @__PURE__ */ _jsxDEV("div", {
											className: "mt-3 w-full p-4 rounded-2xl bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-indigo-950/40 dark:to-violet-950/40 border border-indigo-200/60 dark:border-indigo-900/40 space-y-3 animate-fadeIn",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-between gap-3",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ _jsxDEV("div", {
															className: "w-6 h-6 rounded-lg bg-gradient-to-tr from-indigo-600 to-violet-500 text-white flex items-center justify-center shadow-xs",
															children: /* @__PURE__ */ _jsxDEV(ShieldAlert, { size: 13 }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2418,
																columnNumber: 65
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2417,
															columnNumber: 61
														}, this), /* @__PURE__ */ _jsxDEV("p", {
															className: "text-xs font-extrabold text-slate-900 dark:text-white",
															children: "Panel Koreksi Jawaban Essay"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2420,
															columnNumber: 61
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2416,
														columnNumber: 57
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => {
															setActiveCorrectionId(null);
														},
														className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs",
														children: /* @__PURE__ */ _jsxDEV(X, { size: 14 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2429,
															columnNumber: 61
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2424,
														columnNumber: 57
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2415,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "space-y-1.5",
														children: [
															/* @__PURE__ */ _jsxDEV("label", {
																className: "text-[11px] uppercase tracking-wider font-bold text-indigo-600 dark:text-indigo-300 flex items-center gap-1.5",
																children: ["🏆 Skor Parsial (%)", /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-[9px] text-slate-400 normal-case font-medium",
																	children: [
																		"(maks. ",
																		qPoints,
																		" poin)"
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 2439,
																	columnNumber: 65
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 2437,
																columnNumber: 61
															}, this),
															/* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center gap-1.5",
																children: [/* @__PURE__ */ _jsxDEV("input", {
																	type: "number",
																	min: "0",
																	max: "100",
																	step: "1",
																	value: partialScoreInput,
																	onChange: (e) => setPartialScoreInput(e.target.value),
																	className: "flex-1 w-full px-3 py-2 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/60 text-center",
																	placeholder: "0–100"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2444,
																	columnNumber: 65
																}, this), /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-sm font-bold text-slate-600 dark:text-slate-300 w-6 text-center",
																	children: "%"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2454,
																	columnNumber: 65
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 2443,
																columnNumber: 61
															}, this),
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-[10px] text-slate-500 dark:text-slate-400 font-medium",
																children: [
																	"Skor parsial dalam persentase. Contoh: 80% = ",
																	(.8 * qPoints).toFixed(1),
																	" poin dari total ",
																	qPoints,
																	" poin."
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 2458,
																columnNumber: 61
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2436,
														columnNumber: 57
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "space-y-1.5",
														children: [/* @__PURE__ */ _jsxDEV("label", {
															className: "text-[11px] uppercase tracking-wider font-bold text-indigo-600 dark:text-indigo-300 flex items-center gap-1.5",
															children: "🔒 Override Status"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2466,
															columnNumber: 61
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "space-y-1.5",
															children: [
																/* @__PURE__ */ _jsxDEV("label", {
																	className: "flex items-center gap-2 p-2.5 rounded-xl bg-white/70 dark:bg-slate-900/60 border border-indigo-200/50 dark:border-indigo-800/50 cursor-pointer hover:border-indigo-400/60 transition-all",
																	children: [
																		/* @__PURE__ */ _jsxDEV("input", {
																			type: "checkbox",
																			checked: correctionIsCorrectOverride === true,
																			onChange: (e) => {
																				setCorrectionIsCorrectOverride(e.target.checked ? true : correctionIsCorrectOverride === true ? false : undefined);
																			},
																			className: "w-4 h-4 rounded-md text-emerald-600 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 2471,
																			columnNumber: 69
																		}, this),
																		/* @__PURE__ */ _jsxDEV("div", {
																			className: "flex-1",
																			children: [/* @__PURE__ */ _jsxDEV("p", {
																				className: "text-xs font-bold text-slate-800 dark:text-slate-100",
																				children: "Tandai Jawaban Ini Benar"
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 2480,
																				columnNumber: 73
																			}, this), /* @__PURE__ */ _jsxDEV("p", {
																				className: "text-[10px] text-slate-500 dark:text-slate-400 font-medium",
																				children: "Centang bila jawaban tidak exact match tapi konsepnya benar (override)."
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 2483,
																				columnNumber: 73
																			}, this)]
																		}, void 0, true, {
																			fileName: _jsxFileName,
																			lineNumber: 2479,
																			columnNumber: 69
																		}, this),
																		/* @__PURE__ */ _jsxDEV("span", {
																			className: `text-[10px] font-black px-2 py-0.5 rounded-full ${correctionIsCorrectOverride === true ? "bg-emerald-500 text-white" : correctionIsCorrectOverride === false ? "bg-red-500 text-white" : "bg-slate-300 dark:bg-slate-700 text-slate-600 dark:text-slate-300"}`,
																			children: correctionIsCorrectOverride === true ? "BENAR" : correctionIsCorrectOverride === false ? "SALAH" : "AUTO"
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 2487,
																			columnNumber: 69
																		}, this)
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 2470,
																	columnNumber: 65
																}, this),
																correctionIsCorrectOverride === false && /* @__PURE__ */ _jsxDEV("button", {
																	type: "button",
																	onClick: () => setCorrectionIsCorrectOverride(undefined),
																	className: "text-[10px] text-slate-500 hover:text-indigo-600 font-medium underline decoration-dotted",
																	children: "Reset ke status otomatis"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2498,
																	columnNumber: 69
																}, this),
																correctionIsCorrectOverride === true && /* @__PURE__ */ _jsxDEV("button", {
																	type: "button",
																	onClick: () => setCorrectionIsCorrectOverride(false),
																	className: "text-[10px] text-slate-500 hover:text-indigo-600 font-medium underline decoration-dotted",
																	children: "Tandai sebagai salah"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2507,
																	columnNumber: 69
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2469,
															columnNumber: 61
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2465,
														columnNumber: 57
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2434,
													columnNumber: 53
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-1.5 pt-1",
													children: [
														/* @__PURE__ */ _jsxDEV("label", {
															className: "text-[11px] uppercase tracking-wider font-bold text-indigo-600 dark:text-indigo-300 flex items-center gap-1.5",
															children: "💬 Catatan ke Siswa (Optional)"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2521,
															columnNumber: 57
														}, this),
														/* @__PURE__ */ _jsxDEV("textarea", {
															value: correctionNote,
															onChange: (e) => setCorrectionNote(e.target.value),
															rows: 3,
															placeholder: "Tulis catatan untuk siswa, misal: Bagus, tapi rumusnya kurang tepat di langkah kedua. Coba periksa kembali aturan integral.",
															className: "w-full px-3 py-2.5 text-sm rounded-xl border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/60 placeholder:text-slate-400 resize-y"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2524,
															columnNumber: 57
														}, this),
														/* @__PURE__ */ _jsxDEV("p", {
															className: "text-[10px] text-slate-500 dark:text-slate-400 font-medium",
															children: "Catatan ini akan ditampilkan kepada responden/siswa saat melihat hasil pengerjaan."
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2531,
															columnNumber: 57
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2520,
													columnNumber: 53
												}, this),
												answer.overrideNote && /* @__PURE__ */ _jsxDEV("div", {
													className: "p-3 rounded-xl bg-white/70 dark:bg-slate-900/60 border border-amber-200/60 dark:border-amber-800/60",
													children: [/* @__PURE__ */ _jsxDEV("p", {
														className: "text-[10px] uppercase tracking-wider font-bold text-amber-700 dark:text-amber-300 mb-1",
														children: "📌 Catatan Sebelumnya:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2539,
														columnNumber: 61
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: "text-xs text-slate-700 dark:text-slate-200 font-medium whitespace-pre-wrap",
														children: answer.overrideNote
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2542,
														columnNumber: 61
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2538,
													columnNumber: 57
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-end gap-2 pt-1",
													children: [/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => {
															setActiveCorrectionId(null);
															setPartialScoreEditingId(null);
														},
														className: "px-3 py-1.5 text-xs font-bold text-slate-600 dark:text-slate-300 bg-white/70 dark:bg-slate-800/50 hover:bg-white dark:hover:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer transition-all",
														children: "Batal"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2550,
														columnNumber: 57
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => handleSaveCompleteCorrection(selectedRespondent.responseId, answer.questionId, answer.answerId || answer.id, qPoints),
														className: "flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold bg-gradient-to-r from-indigo-600 to-violet-500 hover:from-indigo-700 hover:to-violet-600 text-white rounded-xl shadow-xs cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]",
														children: "💾 Simpan Koreksi Lengkap"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2560,
														columnNumber: 57
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2549,
													columnNumber: 53
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2414,
											columnNumber: 49
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "border-t border-slate-100 dark:border-slate-800 p-4 space-y-3 bg-slate-50 dark:bg-slate-800/50 text-xs",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500 mb-1",
												children: "Jawaban Responden:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2578,
												columnNumber: 49
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: `rounded-xl border p-3 font-medium ${effIsCorrect === true ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200" : effIsCorrect === false ? "bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800 text-red-900 dark:text-red-200" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"}`,
												children: answer.answerText || answer.answerValue || answer.optionText ? /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: answer.answerText || answer.answerValue || answer.optionText }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2589,
													columnNumber: 57
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-400 dark:text-slate-500 italic",
													children: "Tidak ada jawaban"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2591,
													columnNumber: 57
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2581,
												columnNumber: 49
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2577,
												columnNumber: 45
											}, this), keyAnswer && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] uppercase tracking-wider font-bold text-slate-400 dark:text-slate-500 mb-1",
												children: "Kunci / Jawaban Benar:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2598,
												columnNumber: 53
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 p-3 text-emerald-900 dark:text-emerald-200 font-bold",
												children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: keyAnswer }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2602,
													columnNumber: 57
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2601,
												columnNumber: 53
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2597,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2576,
											columnNumber: 41
										}, this)
									]
								}, answer.questionId || index, true, {
									fileName: _jsxFileName,
									lineNumber: 2254,
									columnNumber: 37
								}, this);
							}), (!selectedRespondent.answers || selectedRespondent.answers.length === 0) && /* @__PURE__ */ _jsxDEV("div", {
								className: "text-center py-12 text-sm text-slate-400 dark:text-slate-500",
								children: "Rincian jawaban tidak tersedia."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2613,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2245,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between shrink-0",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: goPrevious,
									disabled: currentIndex <= 0,
									className: "flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(ChevronLeft, { size: 15 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2626,
										columnNumber: 33
									}, this), " Sebelumnya"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2621,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-400 dark:text-slate-500 font-semibold",
									children: [
										currentIndex + 1,
										" dari ",
										respondentsList.length
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2629,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: goNext,
									disabled: currentIndex === respondentsList.length - 1,
									className: "flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer",
									children: ["Selanjutnya ", /* @__PURE__ */ _jsxDEV(ChevronRight, { size: 15 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2638,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2633,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2620,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2164,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2158,
				columnNumber: 17
			}, this),
			aiHolisticPreviewOpen && aiHolisticResult && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-[60] flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-black/60 backdrop-blur-xs",
					onClick: () => setAiHolisticPreviewOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 2649,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 w-full max-w-lg max-h-[85vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 z-10 animate-in fade-in zoom-in-95 duration-200",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0 bg-purple-50/50 dark:bg-purple-950/20",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl",
									children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2656,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2655,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-extrabold text-slate-900 dark:text-white",
									children: "Saran Skor AI — Review Holistic"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2659,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400 dark:text-slate-500",
									children: [aiHolisticResult.essaySuggestions.length, " soal essay dianalisis"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2660,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2658,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2654,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setAiHolisticPreviewOpen(false),
								className: "p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2664,
									columnNumber: 33
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2663,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2653,
							columnNumber: 25
						}, this),
						(aiHolisticResult.pgSummary || aiHolisticResult.totalEstimate !== null) && /* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-3 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800 flex flex-wrap gap-4 text-xs",
							children: [aiHolisticResult.pgSummary && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-600 dark:text-slate-300",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold",
										children: "PG:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2673,
										columnNumber: 41
									}, this),
									" ",
									aiHolisticResult.pgSummary
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2672,
								columnNumber: 37
							}, this), aiHolisticResult.totalEstimate !== null && /* @__PURE__ */ _jsxDEV("span", {
								className: "font-extrabold text-purple-700 dark:text-purple-300",
								children: [
									"Estimasi Skor Total: ",
									aiHolisticResult.totalEstimate,
									"%"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2677,
								columnNumber: 37
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2670,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 overflow-y-auto p-5 space-y-3",
							children: aiHolisticResult.essaySuggestions.map(({ answer, suggestion }, i) => /* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-white dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-bold text-slate-700 dark:text-slate-200 flex-1 line-clamp-2",
											children: (answer.question || "").replace(/<[^>]*>/g, "").substring(0, 100)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2689,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: `shrink-0 text-xs font-extrabold px-2 py-0.5 rounded-full ${suggestion.isCorrect ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300" : "bg-red-100 text-red-700 dark:bg-red-950/60 dark:text-red-300"}`,
											children: [suggestion.score, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2692,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2688,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500 dark:text-slate-400 italic",
										children: [
											"\"",
											suggestion.reason,
											"\""
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2696,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 dark:text-slate-500",
										children: ["Jawaban: ", /* @__PURE__ */ _jsxDEV("span", {
											className: "font-medium text-slate-600 dark:text-slate-300",
											children: (answer.answerText || answer.answerValue || "(kosong)").substring(0, 80)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2698,
											columnNumber: 50
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2697,
										columnNumber: 37
									}, this)
								]
							}, i, true, {
								fileName: _jsxFileName,
								lineNumber: 2687,
								columnNumber: 33
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2685,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-white dark:bg-slate-900",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setAiHolisticPreviewOpen(false),
								className: "px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer",
								children: "Batal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2706,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: handleApplyAllAiScores,
								className: "px-5 py-2.5 bg-slate-800 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 13 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2710,
										columnNumber: 33
									}, this),
									"Terapkan Semua Skor AI (",
									aiHolisticResult.essaySuggestions.length,
									" essay)"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2709,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2705,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2650,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2648,
				columnNumber: 17
			}, this),
			bulkModalOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-black/50 backdrop-blur-xs",
					onClick: () => setBulkModalOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 2721,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 w-full max-w-xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 flex flex-col animate-in fade-in zoom-in-95 duration-150 font-sans",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50/50 dark:bg-slate-800/50",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400 rounded-xl",
									children: /* @__PURE__ */ _jsxDEV(Sliders, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2732,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2731,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-extrabold text-slate-900 dark:text-white",
									children: "Penyesuaian Skor Massal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2735,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400 dark:text-slate-500",
									children: "Sesuaikan nilai responden dengan filter dan aturan fleksibel"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2738,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2734,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2730,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setBulkModalOpen(false),
								className: "p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2748,
									columnNumber: 33
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2743,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2729,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 overflow-y-auto space-y-5 flex-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2",
										children: "1. Target Responden yang Disesuaikan:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2757,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-3 gap-2",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setBulkFilter("all"),
												className: `p-2.5 rounded-xl border text-xs font-bold text-center cursor-pointer transition-all ${bulkFilter === "all" ? "bg-teal-50 dark:bg-teal-950/60 border-[#00897B] text-[#00897B] dark:text-teal-400 shadow-2xs" : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"}`,
												children: "Semua Responden"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2761,
												columnNumber: 37
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setBulkFilter("below"),
												className: `p-2.5 rounded-xl border text-xs font-bold text-center cursor-pointer transition-all ${bulkFilter === "below" ? "bg-teal-50 dark:bg-teal-950/60 border-[#00897B] text-[#00897B] dark:text-teal-400 shadow-2xs" : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"}`,
												children: "Nilai di Bawah Batas"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2772,
												columnNumber: 37
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setBulkFilter("range"),
												className: `p-2.5 rounded-xl border text-xs font-bold text-center cursor-pointer transition-all ${bulkFilter === "range" ? "bg-teal-50 dark:bg-teal-950/60 border-[#00897B] text-[#00897B] dark:text-teal-400 shadow-2xs" : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"}`,
												children: "Rentang Nilai Tertentu"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2783,
												columnNumber: 37
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2760,
										columnNumber: 33
									}, this),
									bulkFilter === "below" && /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-3 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-medium text-slate-600 dark:text-slate-300",
											children: "Hanya sesuaikan responden dengan nilai di bawah:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2798,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "number",
												min: "0",
												max: "100",
												value: filterThreshold,
												onChange: (e) => setFilterThreshold(parseFloat(e.target.value) || 0),
												className: "w-16 px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-center font-bold"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2800,
												columnNumber: 45
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-slate-500",
												children: "%"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2808,
												columnNumber: 45
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2799,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2797,
										columnNumber: 37
									}, this),
									bulkFilter === "range" && /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-3 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-medium text-slate-600 dark:text-slate-300",
											children: "Hanya sesuaikan responden dengan nilai antara:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2815,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [
												/* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													min: "0",
													max: "100",
													value: filterRangeMin,
													onChange: (e) => setFilterRangeMin(parseFloat(e.target.value) || 0),
													className: "w-14 px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-center font-bold"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2817,
													columnNumber: 45
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-400",
													children: "s/d"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2825,
													columnNumber: 45
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													min: "0",
													max: "100",
													value: filterRangeMax,
													onChange: (e) => setFilterRangeMax(parseFloat(e.target.value) || 0),
													className: "w-14 px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-center font-bold"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2826,
													columnNumber: 45
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold text-slate-500",
													children: "%"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2834,
													columnNumber: 45
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2816,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2814,
										columnNumber: 37
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2756,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2",
									children: "2. Metode Penyesuaian Nilai:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2842,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: `flex items-start gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${bulkType === "min" ? "border-[#00897B] bg-teal-50/40 dark:bg-teal-950/40" : "border-slate-200 dark:border-slate-700 hover:border-slate-300"}`,
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "radio",
												name: "bulkType",
												value: "min",
												checked: bulkType === "min",
												onChange: () => {
													setBulkType("min");
													setBulkValue(75);
												},
												className: "mt-0.5 text-[#00897B] cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2851,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex-1 text-xs",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "font-bold text-slate-900 dark:text-white",
													children: "Batas Skor Minimum (Threshold)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2860,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-500 dark:text-slate-400",
													children: "Nilai di bawah batas dinaikkan ke batas. Nilai yang sudah di atas batas tetap aman dan tidak akan turun."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2861,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2859,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2846,
											columnNumber: 37
										}, this),
										/* @__PURE__ */ _jsxDEV("label", {
											className: `flex items-start gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${bulkType === "bonus" ? "border-[#00897B] bg-teal-50/40 dark:bg-teal-950/40" : "border-slate-200 dark:border-slate-700 hover:border-slate-300"}`,
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "radio",
												name: "bulkType",
												value: "bonus",
												checked: bulkType === "bonus",
												onChange: () => {
													setBulkType("bonus");
													setBulkValue(10);
												},
												className: "mt-0.5 text-[#00897B] cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2870,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex-1 text-xs",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "font-bold text-slate-900 dark:text-white",
													children: "Tambah Nilai Bonus (+ Poin)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2879,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-500 dark:text-slate-400",
													children: "Tambahkan poin tetap ke setiap responden yang memenuhi kriteria (maksimal 100)."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2880,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2878,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2865,
											columnNumber: 37
										}, this),
										/* @__PURE__ */ _jsxDEV("label", {
											className: `flex items-start gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${bulkType === "scale" ? "border-[#00897B] bg-teal-50/40 dark:bg-teal-950/40" : "border-slate-200 dark:border-slate-700 hover:border-slate-300"}`,
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "radio",
												name: "bulkType",
												value: "scale",
												checked: bulkType === "scale",
												onChange: () => {
													setBulkType("scale");
													setBulkValue(110);
												},
												className: "mt-0.5 text-[#00897B] cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2889,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex-1 text-xs",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "font-bold text-slate-900 dark:text-white",
													children: "Kalikan Kurva Skala Persentase (x %)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2898,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-500 dark:text-slate-400",
													children: "Kalikan nilai saat ini dengan persentase tertentu (misal: 110% = nilai x 1.1)."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2899,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2897,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2884,
											columnNumber: 37
										}, this),
										/* @__PURE__ */ _jsxDEV("label", {
											className: `flex items-start gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${bulkType === "set_fixed" ? "border-[#00897B] bg-teal-50/40 dark:bg-teal-950/40" : "border-slate-200 dark:border-slate-700 hover:border-slate-300"}`,
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "radio",
												name: "bulkType",
												value: "set_fixed",
												checked: bulkType === "set_fixed",
												onChange: () => {
													setBulkType("set_fixed");
													setBulkValue(80);
												},
												className: "mt-0.5 text-[#00897B] cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2908,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex-1 text-xs",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "font-bold text-slate-900 dark:text-white",
													children: "Tetapkan Nilai Rata (= Nilai Tetap)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2917,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-500 dark:text-slate-400",
													children: "Ubah seluruh nilai responden yang memenuhi kriteria langsung menjadi nilai ini."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2918,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2916,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2903,
											columnNumber: 37
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2845,
									columnNumber: 33
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2841,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1.5",
									children: bulkType === "min" ? "Batas Nilai Minimum Target:" : bulkType === "bonus" ? "Jumlah Poin Bonus Tambahan (+):" : bulkType === "scale" ? "Faktor Skala Persentase (%):" : "Nilai Tetap yang Diterapkan:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2926,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										step: bulkType === "scale" ? "5" : "1",
										min: "0",
										max: bulkType === "scale" ? "200" : "100",
										value: bulkValue,
										onChange: (e) => setBulkValue(parseFloat(e.target.value) || 0),
										className: "w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-[#00897B]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2930,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-500",
										children: bulkType === "scale" ? "%" : "poin"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2939,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2929,
									columnNumber: 33
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2925,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 border-t border-slate-100 dark:border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between mb-2",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: "Live Preview Perubahan Nilai:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2948,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-bold text-teal-600 dark:text-teal-400",
											children: [
												previewAdjustments.filter((p) => p.meetsFilter && p.diff !== 0).length,
												" dari ",
												previewAdjustments.length,
												" responden terpengaruh"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2951,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2947,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "border border-slate-200 dark:border-slate-700 rounded-2xl overflow-hidden max-h-44 overflow-y-auto",
										children: /* @__PURE__ */ _jsxDEV("table", {
											className: "w-full text-xs text-left",
											children: [/* @__PURE__ */ _jsxDEV("thead", {
												className: "bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold sticky top-0",
												children: /* @__PURE__ */ _jsxDEV("tr", { children: [
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-2 px-3",
														children: "Responden"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2960,
														columnNumber: 49
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-2 px-3 text-center",
														children: "Skor Saat Ini"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2961,
														columnNumber: 49
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-2 px-3 text-center",
														children: "Skor Baru"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2962,
														columnNumber: 49
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-2 px-3 text-right",
														children: "Perubahan"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2963,
														columnNumber: 49
													}, this)
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2959,
													columnNumber: 45
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2958,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("tbody", {
												className: "divide-y divide-slate-100 dark:divide-slate-800",
												children: previewAdjustments.map((item, idx) => /* @__PURE__ */ _jsxDEV("tr", {
													className: "hover:bg-slate-50 dark:hover:bg-slate-800/50",
													children: [
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-2 px-3 font-medium text-slate-800 dark:text-slate-200",
															children: item.respondentName || "Anonim"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2969,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-2 px-3 text-center font-bold text-slate-600 dark:text-slate-300",
															children: [item.currentScore, "%"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2972,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-2 px-3 text-center font-extrabold text-slate-900 dark:text-white",
															children: [item.projectedScore, "%"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2975,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-2 px-3 text-right font-bold",
															children: item.diff > 0 ? /* @__PURE__ */ _jsxDEV("span", {
																className: "text-emerald-600 dark:text-emerald-400 font-extrabold",
																children: [
																	"+",
																	item.diff,
																	"%"
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 2980,
																columnNumber: 61
															}, this) : item.diff < 0 ? /* @__PURE__ */ _jsxDEV("span", {
																className: "text-red-500 dark:text-red-400 font-extrabold",
																children: [item.diff, "%"]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 2982,
																columnNumber: 61
															}, this) : /* @__PURE__ */ _jsxDEV("span", {
																className: "text-slate-400 font-normal",
																children: "Tetap"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2984,
																columnNumber: 61
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2978,
															columnNumber: 53
														}, this)
													]
												}, item.responseId || idx, true, {
													fileName: _jsxFileName,
													lineNumber: 2968,
													columnNumber: 49
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2966,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2957,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2956,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2946,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2753,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50/50 dark:bg-slate-800/50",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: handleResetAllScores,
								className: "flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-red-500 transition-colors cursor-pointer",
								title: "Kembalikan semua nilai ke perhitungan asli sistem",
								children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 13 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 3004,
									columnNumber: 33
								}, this), " Reset Semua"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2998,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setBulkModalOpen(false),
									className: "px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
									children: "Batal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 3008,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: handleApplyBulkScore,
									className: "px-5 py-2 bg-[#00897B] hover:bg-[#00796B] text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer",
									children: "Terapkan Perubahan"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 3015,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 3007,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2997,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2726,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2720,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV(ConfirmModal, {
				isOpen: proctorModal.isOpen,
				onClose: () => !proctorModal.loading && setProctorModal((prev) => ({
					...prev,
					isOpen: false
				})),
				onConfirm: handleConfirmProctorAction,
				isLoading: proctorModal.loading,
				variant: proctorModal.type === "force_submit" ? "warning" : "danger",
				title: proctorModal.type === "force_submit" ? "Selesaikan Paksa Sesi Ujian?" : "Reset Jawaban Peserta?",
				message: proctorModal.type === "force_submit" ? `Apakah Anda yakin ingin menyelesaikan paksa sesi ujian untuk peserta "${proctorModal.respondentName}"? Draft jawaban yang tersinkronisasi akan disimpan dan status sesi akan diubah menjadi submitted.` : `Apakah Anda yakin ingin me-reset jawaban yang sudah disubmit oleh "${proctorModal.respondentName}"? Data lama dipertahankan dan peserta diberi 1 jatah isi ulang. Hanya sesi yang sudah disubmit yang bisa di-reset.`,
				confirmText: proctorModal.type === "force_submit" ? "Ya, Selesaikan Paksa" : "Ya, Reset Jawaban",
				cancelText: "Batal"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 3030,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(ImageLightboxModal, {
				isOpen: !!lightboxImage,
				src: lightboxImage?.src,
				alt: lightboxImage?.alt,
				onClose: () => setLightboxImage(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 3047,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 1403,
		columnNumber: 9
	}, this);
}
_s(FormResponsesPage, "fO/opX3SiBpPdRxaXcfctbRHOps=", false, function() {
	return [useParams, useNavigate];
});
_c = FormResponsesPage;
var _c;
$RefreshReg$(_c, "FormResponsesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/form-responses/FormResponsesPage.jsx?t=1789530336114";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-responses/FormResponsesPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-responses/FormResponsesPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-responses/FormResponsesPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsYUFBYSxTQUFTLGdCQUFnQjtBQUNwRSxTQUFTLGFBQWEsaUJBQWlCO0FBQ3ZDLFNBQ0ksV0FBVyxVQUFVLEtBQUssR0FBRyxXQUFXLFNBQ3hDLGVBQWUsZUFBZSxjQUFjLFNBQzVDLGFBQWEsYUFBYSxjQUFjLFlBQVksVUFBVSxXQUM5RCxTQUFTLE9BQU8sV0FBVyxPQUFPLE1BQ2xDLGFBQWEsYUFBYSxVQUFVLE9BQU8sV0FBVyxhQUFhLFdBQ25FLFFBQVEsUUFBUSxhQUFhLGNBQWMsZ0JBQWdCLGNBQ3hEO0FBQ1AsT0FBTyxhQUFhO0FBQ3BCLE9BQU8sa0JBQWtCO0FBQ3pCLFNBQ0ksYUFBYSxrQkFBa0Isa0JBQy9CLG1CQUFtQixjQUFjLG1CQUFtQixxQkFDcEQsc0JBQXNCLGNBQWMscUJBQXFCLGtCQUFrQixVQUMzRSxxQkFBcUIsMEJBQTBCLG1CQUMvQyx3QkFBd0Isa0JBQWtCLGtCQUFrQixrQkFBa0Isb0JBQzlFLHlCQUNHO0FBQ1AsU0FBUyxpQkFBaUIsMEJBQTBCLHdCQUF3QjtBQUM1RSxPQUFPLHlCQUF5QjtBQUNoQyxPQUFPLHdCQUF3Qjs7OztBQUUvQixNQUFNLGlCQUFpQjtDQUNuQjtFQUFFLElBQUk7RUFBRyxPQUFPO0VBQVEsTUFBTTtDQUFNO0NBQ3BDO0VBQUUsSUFBSTtFQUFHLE9BQU87RUFBWSxNQUFNO0NBQVc7Q0FDN0M7RUFBRSxJQUFJO0VBQUcsT0FBTztFQUFZLE1BQU07Q0FBVztDQUM3QztFQUFFLElBQUk7RUFBRyxPQUFPO0VBQVcsTUFBTTtDQUFXO0FBQ2hEO0FBRUEsTUFBTSxZQUFZO0FBRWxCLFNBQVMsa0JBQWtCO0FBQzNCLE9BQU8sTUFBTSxzQkFBc0IsU0FBUyxpQkFBaUIsSUFBSTtBQUVqRSxPQUFPLE1BQU0sd0JBQXdCLFFBQVEsU0FBUztDQUNsRCxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLE1BQU0sUUFBUSxPQUFPLFFBQVEsY0FBYyxRQUFRLGVBQWUsUUFBUSxjQUFjLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFlBQVk7Q0FFL0csSUFBSSxLQUFLLFdBQVcsS0FBSyxLQUFLLFdBQVcsR0FBRztFQUN4QyxNQUFNLGNBQWMsS0FBSyxXQUFXLENBQUMsRUFBQyxDQUFFLE1BQUssTUFBSyxFQUFFLGNBQWMsSUFBSTtFQUN0RSxJQUFJLENBQUMsWUFBWSxPQUFPO0VBQ3hCLElBQUksUUFBUSxZQUFZLFdBQVcsSUFBSTtHQUNuQyxPQUFPLE9BQU8sT0FBTyxRQUFRLE1BQU0sT0FBTyxXQUFXLEVBQUU7RUFDM0Q7RUFDQSxJQUFJLENBQUMsT0FBTyxPQUFPO0VBQ25CLE9BQU8sVUFBVSxPQUFPLFdBQVcsY0FBYyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZO0NBQzVFO0NBRUEsSUFBSSxLQUFLLFdBQVcsR0FBRztFQUNuQixNQUFNLGVBQWUsS0FBSyxXQUFXLENBQUMsRUFBQyxDQUFFLFFBQU8sTUFBSyxFQUFFLGNBQWMsSUFBSTtFQUN6RSxJQUFJLFlBQVksV0FBVyxHQUFHLE9BQU87RUFDckMsSUFBSSxNQUFNLFFBQVEsUUFBUSxlQUFlLEtBQUssT0FBTyxnQkFBZ0IsU0FBUyxHQUFHO0dBQzdFLE1BQU0sV0FBVyxPQUFPLGdCQUFnQixLQUFJLE1BQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUs7R0FDdEYsTUFBTSxVQUFVLFlBQVksS0FBSSxNQUFLLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUs7R0FDckYsSUFBSSxTQUFTLFdBQVcsUUFBUSxRQUFRLE9BQU87R0FDL0MsT0FBTyxTQUFTLE9BQU8sS0FBSyxRQUFRLFFBQVEsUUFBUSxJQUFJO0VBQzVEO0VBQ0EsSUFBSSxDQUFDLE9BQU8sT0FBTztFQUNuQixNQUFNLGNBQWMsWUFBWSxLQUFJLE1BQUssT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxJQUFJO0VBQ3BHLE9BQU8sVUFBVTtDQUNyQjtDQUVBLElBQUksS0FBSyxpQkFBaUIsS0FBSyxjQUFjLEtBQUssR0FBRztFQUNqRCxJQUFJLENBQUMsT0FBTyxPQUFPO0VBQ25CLE9BQU8sVUFBVSxPQUFPLEtBQUssYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWTtDQUNuRTtDQUVBLE9BQU87QUFDWDtBQUVBLE9BQU8sTUFBTSx5QkFBeUIsUUFBUSxTQUFTO0NBQ25ELElBQUksQ0FBQyxRQUFRLE9BQU87Q0FDcEIsSUFBSSxPQUFPLHNCQUFzQixRQUFRLE9BQU8sc0JBQXNCLFdBQVc7RUFDN0UsT0FBTyxDQUFDLENBQUMsT0FBTztDQUNwQjtDQUNBLElBQUksT0FBTyxjQUFjLFFBQVEsT0FBTyxjQUFjLFdBQVc7RUFDN0QsT0FBTyxDQUFDLENBQUMsT0FBTztDQUNwQjtDQUNBLElBQUksTUFBTTtFQUNOLE1BQU0sT0FBTyxxQkFBcUIsUUFBUSxJQUFJO0VBQzlDLElBQUksU0FBUyxNQUFNLE9BQU87Q0FDOUI7Q0FDQSxJQUFJLE9BQU8sa0JBQWtCLE9BQU8sY0FBYyxPQUFPLGVBQWUsT0FBTyxhQUFhO0VBQ3hGLE1BQU0sUUFBUSxPQUFPLE9BQU8sY0FBYyxPQUFPLGVBQWUsT0FBTyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDNUcsTUFBTSxRQUFRLE9BQU8sT0FBTyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQzlELElBQUksU0FBUyxPQUFPLE9BQU8sVUFBVTtDQUN6QztDQUNBLE9BQU87QUFDWDtBQUVBLE9BQU8sTUFBTSx1QkFBdUIsU0FBUyxjQUFjO0NBQ3ZELE1BQU0sUUFBUSxNQUFNLFFBQVEsU0FBUyxLQUFLLFVBQVUsU0FBUyxJQUFJLFlBQVksQ0FBQztDQUM5RSxJQUFJLE1BQU0sV0FBVyxHQUFHO0VBQ3BCLE1BQU0sUUFBUSxTQUFTLFVBQVU7RUFDakMsTUFBTSxXQUFXLFdBQVcsQ0FBQyxFQUFDLENBQUUsUUFBTyxNQUFLLHNCQUFzQixDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7RUFDL0UsT0FBTztHQUNILE9BQU8sS0FBSyxNQUFPLFVBQVUsUUFBUyxNQUFNLEVBQUUsSUFBSTtHQUNsRCxjQUFjO0dBQ2QsWUFBWSxLQUFLLElBQUksR0FBRyxRQUFRLE9BQU87R0FDdkMsZ0JBQWdCO0dBQ2hCLGFBQWE7R0FDYixjQUFjO0VBQ2xCO0NBQ0o7Q0FFQSxJQUFJLGNBQWM7Q0FDbEIsSUFBSSxlQUFlO0NBQ25CLElBQUksZUFBZTtDQUNuQixJQUFJLGFBQWE7Q0FFakIsTUFBTSxTQUFRLE1BQUs7RUFDZixNQUFNLFVBQVUsT0FBTyxFQUFFLE1BQU0sSUFBSSxJQUFJLE9BQU8sRUFBRSxNQUFNLElBQUk7RUFDMUQsZUFBZTtFQUVmLE1BQU0sT0FBTyxXQUFXLENBQUMsRUFBQyxDQUFFLE1BQUssTUFBSyxPQUFPLEVBQUUsVUFBVSxNQUFNLE9BQU8sRUFBRSxFQUFFLENBQUM7Ozs7RUFLM0UsSUFBSSxPQUFPLElBQUksZUFBZSxRQUFRLElBQUksZ0JBQWdCLFdBQVc7R0FDakUsTUFBTSxNQUFNLE9BQU8sSUFBSSxXQUFXO0dBQ2xDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxPQUFPLEdBQUc7SUFDekIsZ0JBQWdCLEtBQUssSUFBSSxLQUFLLE9BQU87O0lBRXJDLElBQUksTUFBTSxHQUFHO1NBQ1I7SUFDTDtHQUNKO0VBQ0o7RUFFQSxNQUFNLFlBQVksc0JBQXNCLEtBQUssQ0FBQztFQUM5QyxJQUFJLGNBQWMsTUFBTTtHQUNwQixnQkFBZ0I7R0FDaEI7RUFDSixPQUFPLElBQUksY0FBYyxPQUFPO0dBQzVCO0VBQ0o7Q0FDSixDQUFDO0NBRUQsTUFBTSxRQUFRLGNBQWMsSUFBSSxLQUFLLE1BQU8sZUFBZSxjQUFlLE1BQU0sRUFBRSxJQUFJLEtBQUs7Q0FDM0YsT0FBTztFQUNIO0VBQ0E7RUFDQTtFQUNBLGdCQUFnQixNQUFNO0VBQ3RCO0VBQ0E7Q0FDSjtBQUNKO0FBRUEsTUFBTSwyQkFBMkIsV0FBVztDQUN4QyxJQUFJO0VBQ0EsTUFBTSxNQUFNLGFBQWEsUUFBUSxvQkFBb0IsUUFBUTtFQUM3RCxPQUFPLE1BQU0sS0FBSyxNQUFNLEdBQUcsSUFBSSxDQUFDO0NBQ3BDLFFBQVE7RUFDSixPQUFPLENBQUM7Q0FDWjtBQUNKO0FBRUEsTUFBTSwyQkFBMkIsUUFBUSxZQUFZLFlBQVksY0FBYztDQUMzRSxJQUFJO0VBQ0EsTUFBTSxNQUFNLHdCQUF3QixNQUFNO0VBQzFDLElBQUksQ0FBQyxJQUFJLGFBQWEsSUFBSSxjQUFjLENBQUM7RUFDekMsSUFBSSxXQUFXLENBQUMsY0FBYztFQUM5QixhQUFhLFFBQVEsb0JBQW9CLFVBQVUsS0FBSyxVQUFVLEdBQUcsQ0FBQztDQUMxRSxTQUFTLEdBQUc7RUFDUixRQUFRLEtBQUssMENBQTBDLENBQUM7Q0FDNUQ7QUFDSjtBQUVBLE1BQU0sdUJBQXVCLFVBQ3hCLFFBQVEsR0FBRSxDQUFFLFlBQVksTUFBTSxtQkFBbUIscUJBQXFCLFlBQVk7QUFFdkYsTUFBTSw0QkFBNEIsYUFDN0IsU0FBUyxjQUFjLENBQUMsRUFBQyxDQUFFLFFBQU8sTUFBSyxDQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7QUFFMUUsZUFBZSxTQUFTLG9CQUFvQjs7Q0FDeEMsTUFBTSxFQUFFLE9BQU8sVUFBVTtDQUN6QixNQUFNLFdBQVcsWUFBWTtDQUU3QixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxXQUFXO0NBRXRELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxJQUFJO0NBQ3JDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLENBQUMsQ0FBQztDQUNyRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDLENBQUM7Q0FDN0MsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsSUFBSTtDQUMvQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLElBQUk7Q0FDekQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxJQUFJOztDQUd2RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDLENBQUM7Q0FDN0MsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLOztDQUc1RCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLElBQUk7Q0FFakUsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxJQUFJO0NBQ3pELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsRUFBRTs7Q0FHM0QsTUFBTSxDQUFDLHVCQUF1Qiw0QkFBNEIsU0FBUyxJQUFJO0NBQ3ZFLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsRUFBRTs7Q0FHN0QsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBUyxJQUFJO0NBQ2pFLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUN2RCxNQUFNLENBQUMsNkJBQTZCLGtDQUFrQyxTQUFTLFNBQVM7O0NBR3hGLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsSUFBSTtDQUMvRCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLENBQUMsQ0FBQzs7Q0FFL0QsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxLQUFLO0NBQ2hFLE1BQU0sQ0FBQyxTQUFTLGNBQWMsZUFBZTtFQUFFLE1BQU0sSUFBSSxhQUFhLFFBQVEsNEJBQTRCO0VBQUcsT0FBTyxLQUFLLENBQUMsRUFBRSxTQUFTLE1BQU0sS0FBSyxpQkFBaUIsTUFBSyxVQUFTLE1BQU0sT0FBTyxDQUFDLElBQUksSUFBSTtDQUFvQixDQUFDO0NBQzFOLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsSUFBSTtDQUM3RCxNQUFNLENBQUMsdUJBQXVCLDRCQUE0QixTQUFTLEtBQUs7Q0FDeEUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUN4RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsS0FBSztDQUM5QyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxFQUFFO0NBQzdDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBQ3pELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsQ0FBQztDQUN0RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEVBQUU7O0NBR3ZELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsSUFBSTtDQUN6RCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FDaEUsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBQ3pELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEVBQUU7Q0FDM0QsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxJQUFJLElBQUksQ0FBQztDQUNsRSxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxJQUFJO0NBQ25ELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsSUFBSTtDQUMzRCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLElBQUk7O0NBRzdELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTO0VBQzdDLFFBQVE7RUFDUixNQUFNO0VBQ04sV0FBVztFQUNYLGdCQUFnQjtFQUNoQixTQUFTO0NBQ2IsQ0FBQztDQUVELE1BQU0seUJBQXlCLFlBQVk7RUFDdkMsZ0JBQWdCO0dBQ1osUUFBUTtHQUNSLE1BQU07R0FDTixXQUFXLFFBQVE7R0FDbkIsZ0JBQWdCLFFBQVEsa0JBQWtCO0dBQzFDLFNBQVM7RUFDYixDQUFDO0NBQ0w7Q0FFQSxNQUFNLDBCQUEwQixZQUFZO0VBQ3hDLGdCQUFnQjtHQUNaLFFBQVE7R0FDUixNQUFNO0dBQ04sV0FBVyxRQUFRO0dBQ25CLGdCQUFnQixRQUFRLGtCQUFrQjtHQUMxQyxTQUFTO0VBQ2IsQ0FBQztDQUNMO0NBRUEsTUFBTSw2QkFBNkIsWUFBWTtFQUMzQyxNQUFNLEVBQUUsTUFBTSxjQUFjO0VBQzVCLElBQUksQ0FBQyxXQUFXO0VBQ2hCLGlCQUFnQixVQUFTO0dBQUUsR0FBRztHQUFNLFNBQVM7RUFBSyxFQUFFO0VBQ3BELElBQUk7R0FDQSxJQUFJLFNBQVMsZ0JBQWdCO0lBQ3pCLE1BQU0sTUFBTSxNQUFNLHVCQUF1QixJQUFJLFNBQVM7SUFDdEQsSUFBSSxJQUFJLElBQUk7S0FDUixVQUFVLElBQUksV0FBVyx5Q0FBeUM7S0FDbEUsZ0JBQWdCO01BQUUsUUFBUTtNQUFPLE1BQU07TUFBTSxXQUFXO01BQU0sZ0JBQWdCO01BQUksU0FBUztLQUFNLENBQUM7S0FDbEcsb0JBQW9CLElBQUk7S0FDeEIsaUJBQWlCLElBQUk7TUFBRSxNQUFNO01BQUcsVUFBVTtLQUFVLENBQUMsQ0FBQyxDQUFDLE1BQUssWUFBVztNQUNuRSxJQUFJLFFBQVEsTUFBTSxRQUFRLE1BQU0sYUFBYSxRQUFRLEtBQUssYUFBYSxRQUFRLFFBQVEsQ0FBQyxDQUFDO0tBQzdGLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3JCLE9BQU87S0FDSCxVQUFVLElBQUksV0FBVyx5Q0FBeUMsT0FBTztLQUN6RSxpQkFBZ0IsVUFBUztNQUFFLEdBQUc7TUFBTSxTQUFTO0tBQU0sRUFBRTtJQUN6RDtHQUNKLE9BQU8sSUFBSSxTQUFTLFNBQVM7SUFDekIsTUFBTSxNQUFNLE1BQU0saUJBQWlCLElBQUksU0FBUztJQUNoRCxJQUFJLElBQUksSUFBSTtLQUNSLFVBQVUsSUFBSSxXQUFXLG9DQUFvQztLQUM3RCxnQkFBZ0I7TUFBRSxRQUFRO01BQU8sTUFBTTtNQUFNLFdBQVc7TUFBTSxnQkFBZ0I7TUFBSSxTQUFTO0tBQU0sQ0FBQztLQUNsRyxvQkFBb0IsSUFBSTtLQUN4QixpQkFBaUIsSUFBSTtNQUFFLE1BQU07TUFBRyxVQUFVO0tBQVUsQ0FBQyxDQUFDLENBQUMsTUFBSyxZQUFXO01BQ25FLElBQUksUUFBUSxNQUFNLFFBQVEsTUFBTSxhQUFhLFFBQVEsS0FBSyxhQUFhLFFBQVEsUUFBUSxDQUFDLENBQUM7S0FDN0YsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDckIsT0FBTztLQUNILFVBQVUsSUFBSSxXQUFXLG1DQUFtQyxPQUFPO0tBQ25FLGlCQUFnQixVQUFTO01BQUUsR0FBRztNQUFNLFNBQVM7S0FBTSxFQUFFO0lBQ3pEO0dBQ0o7RUFDSixTQUFTLEtBQUs7R0FDVixRQUFRLE1BQU0sR0FBRztHQUNqQixVQUFVLHFEQUFxRCxPQUFPO0dBQ3RFLGlCQUFnQixVQUFTO0lBQUUsR0FBRztJQUFNLFNBQVM7R0FBTSxFQUFFO0VBQ3pEO0NBQ0o7Q0FFQSxNQUFNLHVCQUF1QixjQUFjO0VBQ3ZDLHFCQUFvQixTQUFRO0dBQ3hCLE1BQU0sT0FBTyxJQUFJLElBQUksSUFBSTtHQUN6QixJQUFJLEtBQUssSUFBSSxTQUFTLEdBQUcsS0FBSyxPQUFPLFNBQVM7UUFDekMsS0FBSyxJQUFJLFNBQVM7R0FDdkIsT0FBTztFQUNYLENBQUM7Q0FDTDtDQUVBLE1BQU0sc0JBQXNCLFlBQVksT0FBTyxXQUFXLFVBQVU7RUFDaEUsSUFBSSxDQUFDLElBQUk7RUFDVCxJQUFJLENBQUMsVUFBVSxxQkFBcUIsSUFBSTtFQUN4QyxJQUFJO0dBQ0EsTUFBTSxNQUFNLE1BQU0sa0JBQWtCLEVBQUU7R0FDdEMsSUFBSSxJQUFJLE1BQU0sSUFBSSxNQUFNO0lBQ3BCLGtCQUFrQixJQUFJLElBQUk7SUFDMUIsbUJBQW1CLElBQUksS0FBSyxDQUFDO0lBQzdCLG1CQUFtQixFQUFFO0dBQ3pCLE9BQU8sSUFBSSxDQUFDLFVBQVU7SUFDbEIsbUJBQW1CLElBQUksV0FBVywrQkFBK0I7R0FDckU7RUFDSixTQUFTLEtBQUs7R0FDVixJQUFJLENBQUMsVUFBVSxtQkFBbUIsa0RBQWtEO0VBQ3hGLFVBQVU7R0FDTixJQUFJLENBQUMsVUFBVSxxQkFBcUIsS0FBSztFQUM3QztDQUNKLEdBQUcsQ0FBQyxFQUFFLENBQUM7O0NBR1AsZ0JBQWdCO0VBQ1osSUFBSSxjQUFjLGNBQWM7RUFFaEMsb0JBQW9CLEtBQUs7RUFFekIsSUFBSSxDQUFDLGFBQWE7RUFFbEIsTUFBTSxhQUFhLGtCQUFrQjtHQUNqQyxvQkFBb0IsSUFBSTtFQUM1QixHQUFHLEdBQUk7RUFFUCxhQUFhLGNBQWMsVUFBVTtDQUN6QyxHQUFHO0VBQUM7RUFBVztFQUFhO0NBQW1CLENBQUM7Q0FFaEQsTUFBTSxtQkFBbUIsY0FBYztFQUN2QyxNQUFNLE9BQU8sZ0JBQWdCLFlBQVksQ0FBQztFQUMxQyxNQUFNLFFBQVEsZ0JBQWdCLGdCQUFnQjtFQUM5QyxPQUFPLEtBQUssUUFBTyxNQUFLO0dBQ3BCLElBQUksa0JBQWtCO0lBQ2xCLE1BQU0sT0FBTyxpQkFBaUIsWUFBWTtJQUMxQyxNQUFNLFFBQVEsRUFBRSxrQkFBa0IsU0FBUSxDQUFFLFlBQVk7SUFDeEQsSUFBSSxDQUFDLEtBQUssU0FBUyxJQUFJLEdBQUcsT0FBTztHQUNyQztHQUNBLElBQUkscUJBQXFCLGVBQWUsT0FBTyxFQUFFLFdBQVc7R0FDNUQsSUFBSSxxQkFBcUIsYUFBYSxPQUFPLEVBQUUsV0FBVztHQUMxRCxJQUFJLHFCQUFxQixjQUFjLE9BQU8seUJBQXlCLENBQUMsSUFBSTtHQUM1RSxJQUFJLHFCQUFxQixtQkFBbUIsT0FBTyx5QkFBeUIsQ0FBQyxLQUFLLFNBQVMsRUFBRSxrQkFBa0I7R0FDL0csT0FBTztFQUNYLENBQUM7Q0FDTCxHQUFHO0VBQUM7RUFBZ0I7RUFBa0I7Q0FBZ0IsQ0FBQztDQUVuRCxNQUFNLG9CQUFvQixTQUFTO0VBQy9CLFFBQVEsTUFBUjtHQUNJLEtBQUssY0FDRCxPQUFPO0lBQ0gsT0FBTztJQUNQLE1BQU0sd0JBQUMsZ0JBQUQsRUFBZ0IsTUFBTSxHQUFLOzs7OztJQUNqQyxPQUFPO0lBQ1AsSUFBSTtHQUNSO0dBQ0osS0FBSyxlQUNELE9BQU87SUFDSCxPQUFPO0lBQ1AsTUFBTSx3QkFBQyxlQUFELEVBQWUsTUFBTSxHQUFLOzs7OztJQUNoQyxPQUFPO0lBQ1AsSUFBSTtHQUNSO0dBQ0osS0FBSyxnQkFDRCxPQUFPO0lBQ0gsT0FBTztJQUNQLE1BQU0sd0JBQUMsU0FBRCxFQUFTLE1BQU0sR0FBSzs7Ozs7SUFDMUIsT0FBTztJQUNQLElBQUk7R0FDUjtHQUNKLEtBQUssaUJBQ0QsT0FBTztJQUNILE9BQU87SUFDUCxNQUFNLHdCQUFDLFNBQUQsRUFBUyxNQUFNLEdBQUs7Ozs7O0lBQzFCLE9BQU87SUFDUCxJQUFJO0dBQ1I7R0FDSixLQUFLLGdCQUNELE9BQU87SUFDSCxPQUFPO0lBQ1AsTUFBTSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztJQUM5QixPQUFPO0lBQ1AsSUFBSTtHQUNSO0dBQ0osS0FBSztHQUNMLEtBQUssMkJBQ0QsT0FBTztJQUNILE9BQU87SUFDUCxNQUFNLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O0lBQzlCLE9BQU87SUFDUCxJQUFJO0dBQ1I7R0FDSixTQUNJLE9BQU87SUFDSCxPQUFPLGdCQUFnQjtJQUN2QixNQUFNLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O0lBQzlCLE9BQU87SUFDUCxJQUFJO0dBQ1I7RUFDUjtDQUNKO0NBRUEsTUFBTSxzQkFBc0IsTUFBTSxJQUM1QixJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsZUFBZSxTQUFTO0VBQUUsS0FBSztFQUFXLE9BQU87RUFBUyxNQUFNO0VBQVcsTUFBTTtFQUFXLFFBQVE7RUFBVyxRQUFRO0NBQVUsQ0FBQyxJQUM5STtDQUVOLGdCQUFnQjtFQUNaLE1BQU0sT0FBTyxZQUFZO0dBQ3JCLFdBQVcsSUFBSTtHQUNmLElBQUk7O0lBRUEsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLE1BQUssUUFBTztLQUM5QixJQUFJLElBQUksTUFBTSxJQUFJLE1BQU0sa0JBQWtCLElBQUksSUFBSTtJQUN0RCxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUVqQixNQUFNLENBQUMsU0FBUyxTQUFTLGNBQWMsZ0JBQWdCLE1BQU0sUUFBUSxJQUFJO0tBQ3JFLFlBQVksRUFBRTtLQUNkLGlCQUFpQixJQUFJO01BQUUsTUFBTTtNQUFHLFVBQVU7S0FBVSxDQUFDO0tBQ3JELGlCQUFpQixJQUFJLEdBQUcsR0FBRztLQUMzQixhQUFhLEVBQUU7SUFDbkIsQ0FBQztJQUVELElBQUksUUFBUSxXQUFXLEtBQUs7S0FDeEIsYUFBYTtLQUNiLFNBQVMsUUFBUTtLQUNqQjtJQUNKO0lBRUEsSUFBSSxRQUFRLElBQUksUUFBUSxRQUFRLElBQUk7SUFFcEMsSUFBSSxrQkFBa0IsQ0FBQztJQUN2QixJQUFJLGFBQWEsTUFBTSxNQUFNLFFBQVEsYUFBYSxJQUFJLEdBQUc7S0FDckQsa0JBQWtCLGFBQWE7S0FDL0IsaUJBQWlCLGVBQWU7SUFDcEM7SUFFQSxJQUFJLFFBQVEsSUFBSTtLQUNaLE1BQU0sT0FBTyxNQUFNLFFBQVEsUUFBUSxJQUFJLElBQ2pDLFFBQVEsT0FDUixRQUFRLE1BQU0sYUFBYSxRQUFRLE1BQU0sU0FBUyxDQUFDO0tBQ3pELGFBQWEsSUFBSTtJQUNyQjtJQUVBLElBQUksYUFBYSxNQUFNLGFBQWEsTUFBTTtLQUN0QyxNQUFNLGlCQUFpQix3QkFBd0IsRUFBRTtLQUNqRCxJQUFJLE9BQU8sYUFBYTtLQUN4QixJQUFJLEtBQUssYUFBYTtNQUNsQixLQUFLLGNBQWMsS0FBSyxZQUFZLEtBQUksTUFBSztPQUN6QyxNQUFNLGdCQUFnQixlQUFlLEVBQUUsZUFBZSxDQUFDO09BQ3ZELE1BQU0sa0JBQWtCLEVBQUUsV0FBVyxDQUFDLEVBQUMsQ0FBRSxLQUFJLE1BQUs7UUFDOUMsTUFBTSxPQUFPLGdCQUFnQixNQUFLLE1BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLEVBQUUsVUFBVSxDQUFDO1FBQzVFLE1BQU0sTUFBTSxFQUFFLGlCQUFpQixtQkFBbUIsSUFBSTtRQUN0RCxNQUFNLG1CQUFtQixjQUFjLEVBQUUsZ0JBQWdCO1FBQ3pELE1BQU0sY0FBYyxtQkFBbUIsY0FBYyxFQUFFLGNBQWMsRUFBRTtRQUN2RSxNQUFNLGVBQWUsc0JBQXNCO1NBQ3ZDLEdBQUc7U0FDSCxtQkFBbUI7UUFDdkIsR0FBRyxJQUFJO1FBQ1AsT0FBTztTQUNILEdBQUc7U0FDSCxlQUFlO1NBQ2YsbUJBQW1CO1NBQ25CLFdBQVc7UUFDZjtPQUNKLENBQUM7T0FDRCxNQUFNLFVBQVUsb0JBQW9CLGdCQUFnQixlQUFlO09BQ25FLE1BQU0saUJBQWlCLE9BQU8sS0FBSyxhQUFhLENBQUMsQ0FBQyxTQUFTLEtBQUssZUFBZSxNQUFLLE1BQUssRUFBRSxzQkFBc0IsUUFBUSxFQUFFLHNCQUFzQixTQUFTO09BQzFKLE9BQU87UUFDSCxHQUFHO1FBQ0gsU0FBUztRQUNULGNBQWMsUUFBUTtRQUN0QixZQUFZLFFBQVE7UUFDcEIsT0FBTyxRQUFRO1FBQ2YsZUFBZSxrQkFBa0IsRUFBRTtPQUN2QztNQUNKLENBQUM7S0FDTDtLQUNBLGFBQWEsSUFBSTtJQUNyQjtHQUNKLFNBQVMsS0FBSztJQUNWLFFBQVEsTUFBTSw0QkFBNEIsR0FBRztHQUNqRCxVQUFVO0lBQ04sV0FBVyxLQUFLO0dBQ3BCO0VBQ0o7RUFFQSxLQUFLO0NBQ1QsR0FBRyxDQUFDLElBQUksUUFBUSxDQUFDOzs7Ozs7Ozs7Q0FVakIsZ0JBQWdCO0VBQ1osSUFBSSxjQUFjLFlBQVk7RUFDOUIsTUFBTSxlQUFlLFlBQVk7R0FDN0IsbUJBQW1CLElBQUk7R0FDdkIsTUFBTSxNQUFNLE1BQU0saUJBQWlCLEVBQUU7R0FDckMsbUJBQW1CLEtBQUs7R0FDeEIsSUFBSSxJQUFJLElBQUk7SUFDUixNQUFNLE9BQU8sSUFBSTtJQUNqQixJQUFJLE9BQU8sQ0FBQztJQUNaLElBQUksTUFBTSxRQUFRLElBQUksR0FBRyxPQUFPO1NBQzNCLElBQUksTUFBTSxTQUFTLE1BQU0sUUFBUSxLQUFLLEtBQUssR0FBRyxPQUFPLEtBQUs7U0FDMUQsSUFBSSxRQUFRLE9BQU8sU0FBUyxVQUFVLE9BQU8sQ0FBQyxJQUFJO0lBQ3ZELGFBQWEsS0FBSyxRQUFPLE9BQU0sRUFBRSxHQUFHLFVBQVUsR0FBRSxDQUFFLFdBQVcsUUFBUSxDQUFDLENBQUM7R0FDM0UsT0FBTztJQUNILGFBQWEsQ0FBQyxDQUFDO0dBQ25CO0VBQ0o7RUFDQSxhQUFhO0NBQ2pCLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztDQUVsQixNQUFNLGFBQWEsS0FBSyxPQUFPLGNBQWM7RUFDekMsU0FBUztHQUFFO0dBQUs7RUFBSyxDQUFDO0VBQ3RCLGlCQUFpQixTQUFTLElBQUksR0FBRyxHQUFJO0NBQ3pDOztDQUdBLE1BQU0sa0JBQWtCLGNBQWM7RUFDbEMsSUFBSSxXQUFXLGVBQWUsVUFBVSxZQUFZLFNBQVMsR0FBRztHQUM1RCxPQUFPLFVBQVU7RUFDckI7RUFDQSxRQUFRLGFBQWEsQ0FBQyxFQUFDLENBQUUsS0FBSSxPQUFNO0dBQy9CLFlBQVksRUFBRTtHQUNkLGdCQUFnQixFQUFFO0dBQ2xCLGFBQWEsRUFBRTtHQUNmLFFBQVEsRUFBRTtHQUNWLGVBQWU7R0FDZixnQkFBZ0I7R0FDaEIsY0FBYztHQUNkLFlBQVk7R0FDWixPQUFPO0dBQ1AsU0FBUyxDQUFDO0VBQ2QsRUFBRTtDQUNOLEdBQUcsQ0FBQyxXQUFXLFNBQVMsQ0FBQztDQUV6QixNQUFNLGVBQWUsT0FBTyxRQUFRLFNBQVMsVUFBVTtFQUNuRCxJQUFJLENBQUMsVUFBVSxXQUFXO0VBQzFCLGFBQWEsSUFBSTtFQUNqQixJQUFJOztHQUVBLElBQUksV0FBVyxVQUFVLFdBQVcsT0FBTztJQUN2QyxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsUUFBUSxRQUFRLGdCQUFnQjtJQUN0RSxJQUFJLENBQUMsSUFBSSxJQUFJO0tBQ1QsVUFBVSxJQUFJLFdBQVcsb0JBQW9CLE9BQU8sWUFBWSxLQUFLLE9BQU87SUFDaEYsT0FBTztLQUNILFVBQVUsUUFBUSxPQUFPLFlBQVksRUFBRSxtQkFBbUI7SUFDOUQ7SUFDQTtHQUNKOztHQUdBLElBQUksQ0FBQyxtQkFBbUIsZ0JBQWdCLFdBQVcsR0FBRztJQUNsRCxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsUUFBUSxPQUFPLGdCQUFnQjtJQUNyRSxJQUFJLENBQUMsSUFBSSxJQUFJO0tBQ1QsVUFBVSxJQUFJLFdBQVcsMENBQTBDLE9BQU87SUFDOUUsT0FBTztLQUNILFVBQVUsNEJBQTRCO0lBQzFDO0lBQ0E7R0FDSjs7R0FHQSxNQUFNLGNBQWMsSUFBSSxJQUFJO0dBQzVCLGdCQUFnQixTQUFRLE1BQUs7SUFDekIsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxFQUFDLENBQUUsU0FBUSxNQUFLO0tBQzNCLElBQUksRUFBRSxjQUFjLENBQUMsWUFBWSxJQUFJLEVBQUUsVUFBVSxHQUFHO01BQ2hELE1BQU0sY0FBYyxFQUFFLFlBQVksU0FBUyxFQUFFLGFBQVksQ0FDcEQsUUFBUSxZQUFZLEVBQUUsQ0FBQyxDQUN2QixRQUFRLFFBQVEsR0FBRyxDQUFDLENBQ3BCLEtBQUs7TUFDVixZQUFZLElBQUksRUFBRSxZQUFZLFVBQVU7S0FDNUM7SUFDSixDQUFDO0dBQ0wsQ0FBQzs7R0FHRCxDQUFDLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxTQUFRLE1BQUs7SUFDL0IsSUFBSSxFQUFFLE1BQU0sQ0FBQyxZQUFZLElBQUksRUFBRSxFQUFFLEdBQUc7S0FDaEMsTUFBTSxjQUFjLEVBQUUsWUFBWSxFQUFFLGFBQWEsU0FBUyxFQUFFLEtBQUksQ0FDM0QsUUFBUSxZQUFZLEVBQUUsQ0FBQyxDQUN2QixRQUFRLFFBQVEsR0FBRyxDQUFDLENBQ3BCLEtBQUs7S0FDVixZQUFZLElBQUksRUFBRSxJQUFJLFVBQVU7SUFDcEM7R0FDSixDQUFDO0dBRUQsTUFBTSxhQUFhLFFBQVE7SUFDdkIsSUFBSSxRQUFRLFFBQVEsUUFBUSxXQUFXLE9BQU87SUFDOUMsTUFBTSxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQ2xCLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FDdkIsUUFBUSxZQUFZLEdBQUcsQ0FBQyxDQUN4QixLQUFLO0lBQ1YsT0FBTyxJQUFJLElBQUksUUFBUSxNQUFNLE1BQUksRUFBRTtHQUN2QztHQUVBLE1BQU0sWUFBWTtJQUNkO0lBQ0E7SUFDQTtJQUNBLEdBQUcsTUFBTSxLQUFLLFlBQVksT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLGlCQUFpQjtHQUM3RDtHQUVBLElBQUksT0FBTyxDQUFDOzs7O0dBS1osSUFBSSxrQkFBa0I7SUFDbEIsTUFBTSxlQUFlO0tBQ2pCO0tBQ0E7S0FDQTtLQUNBLEdBQUcsTUFBTSxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFJLFFBQU87TUFDekMsTUFBTSxRQUFRLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssRUFBRSxPQUFPLEdBQUc7TUFDekQsT0FBTyxrQkFBa0IsaUJBQWlCLElBQUksQ0FBQztLQUNuRCxDQUFDO0lBQ0w7SUFDQSxLQUFLLEtBQUssYUFBYSxJQUFJLFNBQVMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDO0dBQ25EO0dBRUEsTUFBTSxZQUFZLG1CQUFtQixDQUFDLEVBQUMsQ0FBRSxLQUFJLE1BQUs7SUFDOUMsTUFBTSxZQUFZLElBQUksS0FBSyxFQUFFLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSSxNQUFLLENBQUMsRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLGVBQWUsRUFBRSxjQUFjLEVBQUUsQ0FBQyxDQUFDO0lBRXpILE9BQU87S0FDSCxFQUFFO0tBQ0YsRUFBRSxjQUFjLFdBQVcsRUFBRSxXQUFXLElBQUk7S0FDNUMsRUFBRSxrQkFBa0I7S0FDcEIsR0FBRyxNQUFNLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUksUUFBTyxrQkFBa0IsVUFBVSxJQUFJLEdBQUcsS0FBSyxFQUFFLENBQUM7SUFDNUYsQ0FBQyxDQUFDLElBQUksU0FBUyxDQUFDLENBQUMsS0FBSyxHQUFHO0dBQzdCLENBQUM7R0FFRCxLQUFLLEtBQUssR0FBRyxRQUFRO0dBRXJCLE1BQU0sYUFBYSxNQUFXLENBQUMsVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsS0FBSyxNQUFNO0dBQ3ZGLE1BQU0sT0FBTyxJQUFJLEtBQUssQ0FBQyxVQUFVLEdBQUcsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0dBQ3ZFLE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0dBQ3BDLE1BQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztHQUN2QyxLQUFLLE9BQU87R0FDWixLQUFLLGFBQWEsWUFBWSxvQkFBb0IsTUFBTSxRQUFRLEtBQUssTUFBTSxRQUFRLFFBQVEsR0FBRyxJQUFJLE9BQU8sS0FBSztHQUM5RyxTQUFTLEtBQUssWUFBWSxJQUFJO0dBQzlCLEtBQUssTUFBTTtHQUNYLFNBQVMsS0FBSyxZQUFZLElBQUk7R0FDOUIsSUFBSSxnQkFBZ0IsR0FBRztHQUV2QixVQUFVLDRCQUE0QjtFQUMxQyxTQUFTLEtBQUs7R0FDVixRQUFRLE1BQU0sR0FBRztHQUNqQixVQUFVLHNDQUFzQyxPQUFPO0VBQzNELFVBQVU7R0FDTixhQUFhLEtBQUs7RUFDdEI7Q0FDSjtDQUVBLE1BQU0scUJBQXFCLE9BQU8sWUFBWSxhQUFhO0VBQ3ZELGtCQUFrQixVQUFVO0VBQzVCLE1BQU0sTUFBTSxNQUFNLHFCQUFxQixZQUFZLFFBQVE7RUFDM0QsSUFBSSxJQUFJLElBQUk7R0FDUixNQUFNLGNBQWMsZUFBZSxNQUFLLE1BQUssRUFBRSxPQUFPLFFBQVEsQ0FBQyxFQUFFLFFBQVE7R0FDekUsY0FBYSxTQUFRLEtBQUssS0FBSSxNQUMxQixFQUFFLE9BQU8sYUFDSDtJQUFFLEdBQUc7SUFBRyxRQUFRO0dBQVksSUFDNUIsQ0FDVixDQUFDO0dBQ0QsVUFBVSxvQ0FBb0M7RUFDbEQsT0FBTztHQUNILFVBQVUsSUFBSSxXQUFXLDRCQUE0QixPQUFPO0VBQ2hFO0VBQ0Esa0JBQWtCLElBQUk7Q0FDMUI7Q0FFQSxNQUFNLGNBQWMsTUFBTSxJQUNwQixJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsZUFBZSxTQUFTO0VBQUUsS0FBSztFQUFXLE9BQU87RUFBUyxNQUFNO0VBQVcsTUFBTTtFQUFXLFFBQVE7Q0FBVSxDQUFDLElBQzNIO0NBRU4sTUFBTSxlQUFlLFdBQVc7RUFDNUIsUUFBUSxRQUFRLFlBQVksR0FBNUI7R0FDSSxLQUFLO0dBQ0wsS0FBSyxRQUFRLE9BQU87R0FDcEIsS0FBSztHQUNMLEtBQUssWUFBWSxPQUFPO0dBQ3hCLEtBQUs7R0FDTCxLQUFLLFlBQVksT0FBTztHQUN4QixLQUFLO0dBQ0wsS0FBSyxXQUFXLE9BQU87R0FDdkIsU0FBUyxPQUFPO0VBQ3BCO0NBQ0o7Q0FFQSxNQUFNLDRCQUE0QixPQUFPLFlBQVksYUFBYTtFQUM5RCxNQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssV0FBVyxRQUFRLEtBQUssQ0FBQyxDQUFDOztFQUVuRSxjQUFhLFNBQVE7R0FDakIsSUFBSSxDQUFDLE1BQU0sYUFBYSxPQUFPO0dBQy9CLE9BQU87SUFDSCxHQUFHO0lBQ0gsYUFBYSxLQUFLLFlBQVksS0FBSSxNQUM5QixFQUFFLGVBQWUsYUFBYTtLQUFFLEdBQUc7S0FBRyxPQUFPO0tBQVEsZUFBZTtJQUFLLElBQUksQ0FDakY7R0FDSjtFQUNKLENBQUM7RUFDRCxrQkFBa0IsSUFBSTtFQUN0QixVQUFVLG1CQUFtQixXQUFXLHNCQUFzQixPQUFPLEVBQUU7Q0FDM0U7Q0FFQSxNQUFNLHVCQUF1QixPQUFPLGVBQWU7RUFDL0MsTUFBTSxpQkFBaUIsd0JBQXdCLEVBQUUsQ0FBQyxDQUFDLFdBQVcsZUFBZSxDQUFDO0VBQzlFLE1BQU0sa0JBQWtCLFdBQVcsV0FBVyxDQUFDLEVBQUMsQ0FBRSxLQUFJLE1BQUs7R0FDdkQsTUFBTSxPQUFPLGNBQWMsTUFBSyxNQUFLLE9BQU8sRUFBRSxFQUFFLE1BQU0sT0FBTyxFQUFFLFVBQVUsQ0FBQztHQUMxRSxNQUFNLE1BQU0sRUFBRSxpQkFBaUIsbUJBQW1CLElBQUk7R0FDdEQsTUFBTSxtQkFBbUIsZUFBZSxFQUFFLGdCQUFnQjtHQUMxRCxNQUFNLGNBQWMsbUJBQW1CLGVBQWUsRUFBRSxjQUFjLEVBQUU7R0FDeEUsTUFBTSxlQUFlLHNCQUFzQjtJQUFFLEdBQUc7SUFBRyxtQkFBbUI7R0FBWSxHQUFHLElBQUk7R0FDekYsT0FBTztJQUNILEdBQUc7SUFDSCxlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLFdBQVc7R0FDZjtFQUNKLENBQUM7RUFDRCxNQUFNLGlCQUFpQixvQkFBb0IsZ0JBQWdCLGFBQWE7RUFDeEUsc0JBQXNCO0dBQ2xCLEdBQUc7R0FDSCxTQUFTO0dBQ1QsY0FBYyxlQUFlO0dBQzdCLFlBQVksZUFBZTtHQUMzQixPQUFPLGVBQWU7R0FDdEIsZ0JBQWdCLGVBQWU7RUFDbkMsQ0FBQzs7RUFHRCxNQUFNLE1BQU0sTUFBTSxrQkFBa0IsSUFBSSxXQUFXLFVBQVU7RUFDN0QsSUFBSSxJQUFJLE1BQU0sSUFBSSxNQUFNO0dBQ3BCLE1BQU0sZ0JBQWdCLElBQUksS0FBSyxXQUFXLFdBQVcsV0FBVyxDQUFDO0dBQ2pFLE1BQU0sZ0JBQWdCLGNBQWMsS0FBSSxNQUFLO0lBQ3pDLE1BQU0sT0FBTyxjQUFjLE1BQUssTUFBSyxPQUFPLEVBQUUsRUFBRSxNQUFNLE9BQU8sRUFBRSxVQUFVLENBQUM7SUFDMUUsTUFBTSxNQUFNLEVBQUUsaUJBQWlCLG1CQUFtQixJQUFJO0lBQ3RELE1BQU0sbUJBQW1CLGVBQWUsRUFBRSxnQkFBZ0I7SUFDMUQsTUFBTSxvQkFBb0IsbUJBQW1CLGVBQWUsRUFBRSxjQUFjLEVBQUU7SUFDOUUsTUFBTSxlQUFlLHNCQUFzQjtLQUN2QyxHQUFHO0tBQ0gsbUJBQW1CO0tBQ25CLFdBQVcsRUFBRTtJQUNqQixHQUFHLElBQUk7SUFFUCxPQUFPO0tBQ0gsR0FBRztLQUNILGVBQWU7S0FDZixtQkFBbUI7S0FDbkIsV0FBVztJQUNmO0dBQ0osQ0FBQztHQUVELE1BQU0sVUFBVSxvQkFBb0IsZUFBZSxhQUFhO0dBRWhFLHVCQUFzQixVQUFTO0lBQzNCLEdBQUc7SUFDSCxHQUFHLElBQUk7SUFDUCxTQUFTO0lBQ1QsY0FBYyxRQUFRO0lBQ3RCLFlBQVksUUFBUTtJQUNwQixPQUFPLFFBQVE7SUFDZixnQkFBZ0IsUUFBUTtHQUM1QixFQUFFO0VBQ047Q0FDSjtDQUVBLE1BQU0sMkJBQTJCLE9BQU8sWUFBWSxZQUFZLG9CQUFvQjtFQUNoRixJQUFJLFdBQVcsb0JBQW9CLFNBQVMsTUFBSyxNQUFLLE9BQU8sRUFBRSxVQUFVLE1BQU0sT0FBTyxVQUFVLENBQUM7RUFDakcsSUFBSSxXQUFXLFVBQVUsWUFBWSxVQUFVO0VBRS9DLElBQUksQ0FBQyxVQUFVO0dBQ1gsTUFBTSxRQUFRLE1BQU0sa0JBQWtCLElBQUksVUFBVTtHQUNwRCxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sU0FBUztJQUNqQyxNQUFNLFFBQVEsTUFBTSxLQUFLLFFBQVEsTUFBSyxNQUFLLE9BQU8sRUFBRSxVQUFVLE1BQU0sT0FBTyxVQUFVLENBQUM7SUFDdEYsV0FBVyxPQUFPLFlBQVksT0FBTztHQUN6QztFQUNKO0VBRUEsTUFBTSxpQkFBaUIsU0FBUyxVQUFVLEVBQUU7RUFDNUMsSUFBSSxDQUFDLGtCQUFrQixNQUFNLGNBQWMsR0FBRztHQUMxQyxVQUFVLHVEQUF1RCxPQUFPO0dBQ3hFO0VBQ0o7RUFFQSxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsWUFBWSxnQkFBZ0I7R0FDOUQsbUJBQW1CO0dBQ25CLGFBQWE7R0FDYixjQUFjO0VBQ2xCLENBQUM7RUFFRCxJQUFJLElBQUksSUFBSTtHQUNSLHdCQUF3QixJQUFJLFlBQVksWUFBWSxlQUFlO0dBRW5FLHVCQUFzQixTQUFRO0lBQzFCLElBQUksQ0FBQyxNQUFNLE9BQU87SUFDbEIsTUFBTSxjQUFjLEtBQUssV0FBVyxDQUFDLEVBQUMsQ0FBRSxLQUFJLE1BQUs7S0FDN0MsSUFBSSxPQUFPLEVBQUUsVUFBVSxNQUFNLE9BQU8sVUFBVSxHQUFHO01BQzdDLE9BQU87T0FBRSxHQUFHO09BQUcsbUJBQW1CO09BQWlCLFdBQVc7TUFBZ0I7S0FDbEY7S0FDQSxPQUFPO0lBQ1gsQ0FBQztJQUNELE1BQU0sVUFBVSxvQkFBb0IsWUFBWSxhQUFhO0lBQzdELE9BQU87S0FDSCxHQUFHO0tBQ0gsU0FBUztLQUNULGNBQWMsUUFBUTtLQUN0QixZQUFZLFFBQVE7S0FDcEIsT0FBTyxRQUFRO0lBQ25CO0dBQ0osQ0FBQzs7R0FHRCxjQUFhLFNBQVE7SUFDakIsSUFBSSxDQUFDLE1BQU0sYUFBYSxPQUFPO0lBQy9CLE9BQU87S0FDSCxHQUFHO0tBQ0gsYUFBYSxLQUFLLFlBQVksS0FBSSxNQUFLO01BQ25DLElBQUksRUFBRSxlQUFlLFlBQVksT0FBTztNQUN4QyxNQUFNLGNBQWMsRUFBRSxXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUksTUFBSztPQUMxQyxJQUFJLE9BQU8sRUFBRSxVQUFVLE1BQU0sT0FBTyxVQUFVLEdBQUc7UUFDN0MsT0FBTztTQUFFLEdBQUc7U0FBRyxtQkFBbUI7U0FBaUIsV0FBVztRQUFnQjtPQUNsRjtPQUNBLE9BQU87TUFDWCxDQUFDO01BQ0QsTUFBTSxVQUFVLG9CQUFvQixZQUFZLGFBQWE7TUFDN0QsT0FBTztPQUNILEdBQUc7T0FDSCxTQUFTO09BQ1QsY0FBYyxRQUFRO09BQ3RCLFlBQVksUUFBUTtPQUNwQixPQUFPLFFBQVE7T0FDZixlQUFlO01BQ25CO0tBQ0osQ0FBQztJQUNMO0dBQ0osQ0FBQztHQUVELFVBQVUsOEJBQThCLGtCQUFrQixVQUFVLFNBQVM7RUFDakYsT0FBTztHQUNILFVBQVUsSUFBSSxXQUFXLCtCQUErQixPQUFPO0VBQ25FO0NBQ0o7Ozs7OztDQU9BLE1BQU0sd0JBQXdCLE9BQU8sWUFBWSxZQUFZLFVBQVUsUUFBUSxZQUFZO0VBQ3ZGLE1BQU0sTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxXQUFXLE1BQU0sS0FBSyxDQUFDLENBQUM7RUFDOUQsTUFBTSxZQUFZLEtBQUssTUFBTyxNQUFNLE1BQU8sVUFBVSxHQUFHLElBQUk7RUFDNUQsTUFBTSxvQkFBb0IsTUFBTTtFQUVoQyxNQUFNLGlCQUFpQixTQUFTLFVBQVUsRUFBRTtFQUM1QyxJQUFJLENBQUMsa0JBQWtCLE1BQU0sY0FBYyxHQUFHOztHQUUxQyxNQUFNLFFBQVEsTUFBTSxrQkFBa0IsSUFBSSxVQUFVO0dBQ3BELElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxTQUFTO0lBQ2pDLE1BQU0sUUFBUSxNQUFNLEtBQUssUUFBUSxNQUFLLE1BQUssT0FBTyxFQUFFLFVBQVUsTUFBTSxPQUFPLFVBQVUsQ0FBQztJQUN0RixNQUFNLFlBQVksT0FBTyxZQUFZLE9BQU87SUFDNUMsSUFBSSxDQUFDLFdBQVc7S0FBRSxVQUFVLCtCQUErQixPQUFPO0tBQUc7SUFBUTtJQUM3RSxPQUFPLHNCQUFzQixZQUFZLFlBQVksV0FBVyxRQUFRLE9BQU87R0FDbkY7R0FDQSxVQUFVLCtCQUErQixPQUFPO0dBQ2hEO0VBQ0o7RUFFQSxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsWUFBWSxnQkFBZ0I7R0FDOUQ7R0FDQSxhQUFhO0dBQ2IsY0FBYyxnQkFBZ0IsSUFBSTtFQUN0QyxDQUFDO0VBRUQsSUFBSSxJQUFJLElBQUk7O0dBRVIsSUFBSTtJQUNBLE1BQU0sTUFBTSx3QkFBd0IsRUFBRTtJQUN0QyxJQUFJLENBQUMsSUFBSSxhQUFhLElBQUksY0FBYyxDQUFDO0lBQ3pDLElBQUksV0FBVyxDQUFDLGNBQWM7S0FBRSxXQUFXO0tBQW1CLGFBQWE7S0FBVztJQUFJO0lBQzFGLGFBQWEsUUFBUSxvQkFBb0IsTUFBTSxLQUFLLFVBQVUsR0FBRyxDQUFDO0dBQ3RFLFFBQVEsQ0FBQzs7R0FHVCx1QkFBc0IsU0FBUTtJQUMxQixJQUFJLENBQUMsTUFBTSxPQUFPO0lBQ2xCLE1BQU0sY0FBYyxLQUFLLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSSxNQUFLO0tBQzdDLElBQUksT0FBTyxFQUFFLFVBQVUsTUFBTSxPQUFPLFVBQVUsR0FBRztNQUM3QyxPQUFPO09BQ0gsR0FBRztPQUNIO09BQ0EsV0FBVztPQUNYLGFBQWE7TUFDakI7S0FDSjtLQUNBLE9BQU87SUFDWCxDQUFDO0lBQ0QsTUFBTSxVQUFVLG9CQUFvQixZQUFZLGFBQWE7SUFDN0QsT0FBTztLQUNILEdBQUc7S0FDSCxTQUFTO0tBQ1QsY0FBYyxRQUFRO0tBQ3RCLFlBQVksUUFBUTtLQUNwQixPQUFPLFFBQVE7SUFDbkI7R0FDSixDQUFDOztHQUdELGNBQWEsU0FBUTtJQUNqQixJQUFJLENBQUMsTUFBTSxhQUFhLE9BQU87SUFDL0IsT0FBTztLQUNILEdBQUc7S0FDSCxhQUFhLEtBQUssWUFBWSxLQUFJLE1BQUs7TUFDbkMsSUFBSSxFQUFFLGVBQWUsWUFBWSxPQUFPO01BQ3hDLE1BQU0sY0FBYyxFQUFFLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSSxNQUFLO09BQzFDLElBQUksT0FBTyxFQUFFLFVBQVUsTUFBTSxPQUFPLFVBQVUsR0FBRztRQUM3QyxPQUFPO1NBQ0gsR0FBRztTQUNIO1NBQ0EsV0FBVztTQUNYLGFBQWE7UUFDakI7T0FDSjtPQUNBLE9BQU87TUFDWCxDQUFDO01BQ0QsTUFBTSxVQUFVLG9CQUFvQixZQUFZLGFBQWE7TUFDN0QsT0FBTztPQUNILEdBQUc7T0FDSCxTQUFTO09BQ1QsY0FBYyxRQUFRO09BQ3RCLFlBQVksUUFBUTtPQUNwQixPQUFPLFFBQVE7T0FDZixlQUFlO01BQ25CO0tBQ0osQ0FBQztJQUNMO0dBQ0osQ0FBQztHQUVELHlCQUF5QixJQUFJO0dBQzdCLFVBQVUsZ0JBQWdCLElBQUksS0FBSyxVQUFVLHlCQUF5QjtFQUMxRSxPQUFPO0dBQ0gsVUFBVSxJQUFJLFdBQVcsaUNBQWlDLE9BQU87RUFDckU7Q0FDSjs7Q0FHQSxNQUFNLCtCQUErQixPQUFPLFlBQVksWUFBWSxVQUFVLFlBQVk7RUFDdEYsTUFBTSxpQkFBaUIsU0FBUyxVQUFVLEVBQUU7RUFDNUMsSUFBSSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLGtCQUFrQixNQUFNLGNBQWMsR0FBRztHQUMxQyxNQUFNLFFBQVEsTUFBTSxrQkFBa0IsSUFBSSxVQUFVO0dBQ3BELElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxTQUFTO0lBQ2pDLE1BQU0sUUFBUSxNQUFNLEtBQUssUUFBUSxNQUFLLE1BQUssT0FBTyxFQUFFLFVBQVUsTUFBTSxPQUFPLFVBQVUsQ0FBQztJQUN0RixNQUFNLFlBQVksT0FBTyxZQUFZLE9BQU87SUFDNUMsSUFBSSxDQUFDLFdBQVc7S0FBRSxVQUFVLCtCQUErQixPQUFPO0tBQUc7SUFBUTtJQUM3RSxnQkFBZ0IsU0FBUyxXQUFXLEVBQUU7R0FDMUMsT0FBTztJQUNILFVBQVUsK0JBQStCLE9BQU87SUFBRztHQUN2RDtFQUNKO0VBRUEsSUFBSSxtQkFBbUI7RUFDdkIsSUFBSSx5QkFBeUI7RUFFN0IsSUFBSSwwQkFBMEIsWUFBWSwwQkFBMEIsWUFBWTtHQUM1RSxNQUFNLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssV0FBVyxpQkFBaUIsS0FBSyxDQUFDLENBQUM7R0FDekUsbUJBQW1CLEtBQUssTUFBTyxNQUFNLE1BQU8sVUFBVSxHQUFHLElBQUk7R0FDN0QsSUFBSSwyQkFBMkIsYUFBYSwyQkFBMkIsTUFBTTtJQUN6RSx5QkFBeUIsTUFBTTtHQUNuQztFQUNKLE9BQU8sSUFBSSwyQkFBMkIsYUFBYSwyQkFBMkIsTUFBTTtHQUNoRixNQUFNLGlCQUFpQixvQkFBb0IsV0FBVyxDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssT0FBTyxFQUFFLFVBQVUsTUFBTSxPQUFPLFVBQVUsQ0FBQztHQUMvRyx5QkFBeUIsZUFBZSxxQkFBcUIsZUFBZSxhQUFhO0VBQzdGO0VBRUEsTUFBTSxVQUFVO0dBQ1osbUJBQW1CO0dBQ25CLGFBQWE7R0FDYixjQUFjLGdCQUFnQixLQUFLLEtBQUs7RUFDNUM7RUFFQSxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsWUFBWSxlQUFlLE9BQU87RUFFeEUsSUFBSSxJQUFJLElBQUk7R0FDUixJQUFJO0lBQ0EsTUFBTSxNQUFNLHdCQUF3QixFQUFFO0lBQ3RDLElBQUksQ0FBQyxJQUFJLGFBQWEsSUFBSSxjQUFjLENBQUM7SUFDekMsTUFBTSxTQUFTLG9CQUFvQixPQUM3QixLQUFLLE1BQU8sT0FBTyxnQkFBZ0IsSUFBSSxVQUFXLEdBQUcsSUFDcEQseUJBQXlCLE1BQU07SUFDdEMsSUFBSSxXQUFXLENBQUMsY0FBYztLQUMxQixXQUFXO0tBQ1gsYUFBYTtLQUNiLEtBQUs7S0FDTCxNQUFNLGdCQUFnQixLQUFLLEtBQUs7SUFDcEM7SUFDQSxhQUFhLFFBQVEsb0JBQW9CLE1BQU0sS0FBSyxVQUFVLEdBQUcsQ0FBQztHQUN0RSxRQUFRLENBQUM7R0FFVCx1QkFBc0IsU0FBUTtJQUMxQixJQUFJLENBQUMsTUFBTSxPQUFPO0lBQ2xCLE1BQU0sY0FBYyxLQUFLLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSSxNQUFLO0tBQzdDLElBQUksT0FBTyxFQUFFLFVBQVUsTUFBTSxPQUFPLFVBQVUsR0FBRztNQUM3QyxPQUFPO09BQ0gsR0FBRztPQUNILG1CQUFtQjtPQUNuQixXQUFXO09BQ1gsYUFBYTtPQUNiLGNBQWMsUUFBUSxnQkFBZ0IsRUFBRTtNQUM1QztLQUNKO0tBQ0EsT0FBTztJQUNYLENBQUM7SUFDRCxNQUFNLFVBQVUsb0JBQW9CLFlBQVksYUFBYTtJQUM3RCxPQUFPO0tBQ0gsR0FBRztLQUNILFNBQVM7S0FDVCxjQUFjLFFBQVE7S0FDdEIsWUFBWSxRQUFRO0tBQ3BCLE9BQU8sUUFBUTtJQUNuQjtHQUNKLENBQUM7R0FFRCxjQUFhLFNBQVE7SUFDakIsSUFBSSxDQUFDLE1BQU0sYUFBYSxPQUFPO0lBQy9CLE9BQU87S0FDSCxHQUFHO0tBQ0gsYUFBYSxLQUFLLFlBQVksS0FBSSxNQUFLO01BQ25DLElBQUksRUFBRSxlQUFlLFlBQVksT0FBTztNQUN4QyxNQUFNLGNBQWMsRUFBRSxXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUksTUFBSztPQUMxQyxJQUFJLE9BQU8sRUFBRSxVQUFVLE1BQU0sT0FBTyxVQUFVLEdBQUc7UUFDN0MsT0FBTztTQUNILEdBQUc7U0FDSCxtQkFBbUI7U0FDbkIsV0FBVztTQUNYLGFBQWE7U0FDYixjQUFjLFFBQVEsZ0JBQWdCLEVBQUU7UUFDNUM7T0FDSjtPQUNBLE9BQU87TUFDWCxDQUFDO01BQ0QsTUFBTSxVQUFVLG9CQUFvQixZQUFZLGFBQWE7TUFDN0QsT0FBTztPQUNILEdBQUc7T0FDSCxTQUFTO09BQ1QsY0FBYyxRQUFRO09BQ3RCLFlBQVksUUFBUTtPQUNwQixPQUFPLFFBQVE7T0FDZixlQUFlO01BQ25CO0tBQ0osQ0FBQztJQUNMO0dBQ0osQ0FBQztHQUVELHNCQUFzQixJQUFJO0dBQzFCLHlCQUF5QixJQUFJO0dBQzdCLFVBQVUsb0NBQW9DO0VBQ2xELE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyw0QkFBNEIsT0FBTztFQUNoRTtDQUNKOztDQUdBLE1BQU0sd0JBQXdCLE9BQU8sZUFBZTtFQUNoRCxJQUFJLFVBQVUsV0FBVyxXQUFXLENBQUM7RUFDckMsTUFBTSxxQkFBcUIsUUFBUSxNQUFLLE1BQUssQ0FBQyxFQUFFLFlBQVksQ0FBQyxFQUFFLEVBQUU7RUFDakUsSUFBSSxzQkFBc0IsUUFBUSxXQUFXLEdBQUc7R0FDNUMsTUFBTSxRQUFRLE1BQU0sa0JBQWtCLElBQUksV0FBVyxVQUFVO0dBQy9ELElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxTQUFTO0lBQ2pDLFVBQVUsTUFBTSxLQUFLO0lBQ3JCLHVCQUFzQixVQUFTO0tBQUUsR0FBRztLQUFNLEdBQUcsTUFBTTtJQUFLLEVBQUU7R0FDOUQ7RUFDSjtFQUVBLE1BQU0sZUFBZSxRQUFRLFFBQU8sTUFBSyxFQUFFLFdBQVcsQ0FBQztFQUN2RCxJQUFJLGFBQWEsV0FBVyxHQUFHO0dBQUUsVUFBVSw4Q0FBOEMsT0FBTztHQUFHO0VBQVE7RUFFM0cscUJBQXFCLElBQUk7RUFDekIsSUFBSTtHQUNBLE1BQU0sWUFBWSxRQUFRLFFBQU8sTUFBSyxFQUFFLFdBQVcsQ0FBQztHQUNwRCxNQUFNLFlBQVksVUFBVSxRQUFPLE1BQUs7SUFDcEMsTUFBTSxRQUFRLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLEVBQUUsVUFBVSxDQUFDO0lBQ2xGLE9BQU8sc0JBQXNCLEdBQUcsSUFBSSxNQUFNO0dBQzlDLENBQUMsQ0FBQyxDQUFDO0dBQ0gsTUFBTSxVQUFVLFVBQVU7R0FFMUIsTUFBTSxzQkFBc0IsYUFBYSxLQUFLLE1BQU07SUFDaEQsTUFBTSxRQUFRLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLEVBQUUsVUFBVSxDQUFDO0lBQ2xGLE9BQU87S0FDSCxHQUFHO0tBQ0gsZUFBZSxFQUFFLGlCQUFpQixtQkFBbUIsSUFBSSxLQUFLO0lBQ2xFO0dBQ0osQ0FBQztHQUVELE1BQU0sWUFBWSxVQUFVLElBQUkscUJBQXFCLFVBQVUsR0FBRyxRQUFRLFVBQVUsS0FBSyxNQUFPLFlBQVUsVUFBUyxHQUFHLEVBQUUsTUFBTTtHQUU5SCxNQUFNLE1BQU0sTUFBTSx5QkFBeUI7SUFDdkMsY0FBYztJQUNkO0lBQ0EsZUFBZTtJQUNmLGNBQWMsZ0JBQWdCO0dBQ2xDLENBQUM7R0FFRCxJQUFJLENBQUMsSUFBSSxJQUFJO0lBQ1QsVUFBVSxJQUFJLFdBQVcsa0NBQWtDLE9BQU87SUFDbEU7R0FDSjtHQUVBLE1BQU0sY0FBYyxJQUFJLFFBQVEsQ0FBQzs7R0FHakMsTUFBTSxTQUFTLFlBQVksS0FBSyxHQUFHLE1BQU07SUFDckMsTUFBTSxTQUFTLGFBQWE7SUFDNUIsT0FBTztLQUFFO0tBQVEsWUFBWTtLQUFHLFVBQVUsRUFBRSxZQUFZLFFBQVEsWUFBWSxRQUFRO0lBQUc7R0FDM0YsQ0FBQyxDQUFDLENBQUMsUUFBTyxNQUFLLEVBQUUsTUFBTTs7R0FHdkIsTUFBTSxvQkFBb0Isb0JBQW9CLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSSxNQUFLO0lBQ2xFLE1BQU0sYUFBYSxPQUFPLE1BQUssTUFBSyxPQUFPLEVBQUUsUUFBUSxVQUFVLE1BQU0sT0FBTyxFQUFFLFVBQVUsQ0FBQztJQUN6RixJQUFJLFlBQVk7S0FDWixPQUFPO01BQUUsR0FBRztNQUFHLFdBQVcsV0FBVyxXQUFXO01BQVcsbUJBQW1CLFdBQVcsV0FBVztLQUFVO0lBQ2xIO0lBQ0EsTUFBTSxRQUFRLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLEVBQUUsVUFBVSxDQUFDO0lBQ2xGLE9BQU87S0FBRSxHQUFHO0tBQUcsV0FBVyxzQkFBc0IsR0FBRyxJQUFJO0lBQUU7R0FDN0QsQ0FBQztHQUNELE1BQU0sYUFBYSxvQkFBb0Isa0JBQWtCLGFBQWE7R0FDdEUsTUFBTSxnQkFBZ0IsV0FBVztHQUVqQyxvQkFBb0I7SUFBRSxrQkFBa0I7SUFBUSxXQUFXLFVBQVUsSUFBSSxHQUFHLFVBQVUsR0FBRyxRQUFRLFVBQVU7SUFBTTtHQUFjLENBQUM7R0FDaEkseUJBQXlCLElBQUk7RUFDakMsU0FBUyxLQUFLO0dBQ1YsVUFBVSx3QkFBd0IsSUFBSSxTQUFTLE9BQU87RUFDMUQsVUFBVTtHQUNOLHFCQUFxQixLQUFLO0VBQzlCO0NBQ0o7OztDQUlBLE1BQU0seUJBQXlCLFlBQVk7RUFDdkMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLG9CQUFvQjtFQUM5QyxNQUFNLGFBQWEsbUJBQW1CO0VBQ3RDLE1BQU0sWUFBWSxpQkFBaUIsaUJBQzlCLEtBQUksTUFBSztHQUNOLE1BQU0sTUFBTSxTQUFTLEVBQUUsVUFBVSxFQUFFO0dBQ25DLElBQUksQ0FBQyxPQUFPLE1BQU0sR0FBRyxHQUFHLE9BQU87Ozs7Ozs7R0FPL0IsTUFBTSxRQUFRLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLEVBQUUsUUFBUSxVQUFVLENBQUM7R0FDMUYsTUFBTSxVQUFVLFFBQVEsT0FBTyxLQUFLLE1BQU0sSUFBSSxJQUFJLE9BQU8sS0FBSyxNQUFNLElBQUk7R0FDeEUsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxLQUFLLE9BQU8sRUFBRSxXQUFXLEtBQUssS0FBSyxDQUFDLENBQUM7R0FDdEUsTUFBTSxZQUFZLEtBQUssTUFBTyxNQUFNLE1BQU8sVUFBVSxHQUFHLElBQUk7R0FDNUQsT0FBTztJQUNILFVBQVU7SUFDVixhQUFhO0lBQ2IsbUJBQW1CLE1BQU07SUFDekIsY0FBYyxnQkFBZ0IsRUFBRSxXQUFXLE9BQU8sV0FBVyxFQUFFLFdBQVcsTUFBTTtHQUNwRjtFQUNKLENBQUMsQ0FBQyxDQUNELE9BQU8sT0FBTztFQUVuQixJQUFJLFVBQVUsV0FBVyxHQUFHO0dBQUUsVUFBVSxxREFBcUQsT0FBTztHQUFHO0VBQVE7RUFFL0csTUFBTSxNQUFNLE1BQU0seUJBQXlCLFlBQVksU0FBUztFQUNoRSxJQUFJLElBQUksSUFBSTtHQUNSLFVBQVUsU0FBUSxNQUFLO0lBQ25CLE1BQU0sZUFBZSxpQkFBaUIsaUJBQWlCLE1BQUssTUFBSyxTQUFTLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxRQUFRO0lBQ3hHLE1BQU0sTUFBTSxjQUFjLFFBQVE7SUFDbEMsSUFBSSxLQUFLO0tBQ0wsd0JBQXdCLElBQUksWUFBWSxLQUFLLEVBQUUsaUJBQWlCO0lBQ3BFO0dBQ0osQ0FBQztHQUVXLHVCQUFzQixTQUFRO0lBQ3RDLElBQUksQ0FBQyxNQUFNLE9BQU87SUFDbEIsTUFBTSxrQkFBa0IsS0FBSyxXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUksTUFBSztLQUNqRCxNQUFNLGFBQWEsaUJBQWlCLGlCQUFpQixNQUFLLE1BQUssT0FBTyxFQUFFLFFBQVEsVUFBVSxNQUFNLE9BQU8sRUFBRSxVQUFVLENBQUM7S0FDcEgsSUFBSSxZQUFZO01BQ1osTUFBTSxRQUFRLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLEVBQUUsVUFBVSxDQUFDO01BQ2xGLE1BQU0sVUFBVSxRQUFRLE9BQU8sS0FBSyxNQUFNLElBQUksSUFBSSxPQUFPLEtBQUssTUFBTSxJQUFJO01BQ3hFLE1BQU0sTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxPQUFPLFdBQVcsV0FBVyxLQUFLLEtBQUssQ0FBQyxDQUFDO01BQy9FLE1BQU0sWUFBWSxLQUFLLE1BQU8sTUFBTSxNQUFPLFVBQVUsR0FBRyxJQUFJO01BQzVELE9BQU87T0FDSCxHQUFHO09BQ0gsbUJBQW1CLE1BQU07T0FDekIsV0FBVyxNQUFNO09BQ2pCLGFBQWE7TUFDakI7S0FDSjtLQUNBLE9BQU87SUFDWCxDQUFDO0lBQ0QsTUFBTSxVQUFVLG9CQUFvQixnQkFBZ0IsYUFBYTtJQUNqRSxPQUFPO0tBQ0gsR0FBRztLQUNILFNBQVM7S0FDVCxjQUFjLFFBQVE7S0FDdEIsWUFBWSxRQUFRO0tBQ3BCLE9BQU8sUUFBUTtJQUNuQjtHQUNKLENBQUM7O0dBR0QsY0FBYSxTQUFRO0lBQ2pCLElBQUksQ0FBQyxNQUFNLGFBQWEsT0FBTztJQUMvQixPQUFPO0tBQ0gsR0FBRztLQUNILGFBQWEsS0FBSyxZQUFZLEtBQUksTUFBSztNQUNuQyxJQUFJLEVBQUUsZUFBZSxZQUFZLE9BQU87TUFDeEMsTUFBTSxrQkFBa0IsRUFBRSxXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUksTUFBSztPQUM5QyxNQUFNLGFBQWEsaUJBQWlCLGlCQUFpQixNQUFLLE1BQUssT0FBTyxFQUFFLFFBQVEsVUFBVSxNQUFNLE9BQU8sRUFBRSxVQUFVLENBQUM7T0FDcEgsSUFBSSxZQUFZO1FBQ1osTUFBTSxRQUFRLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLEVBQUUsVUFBVSxDQUFDO1FBQ2xGLE1BQU0sVUFBVSxRQUFRLE9BQU8sS0FBSyxNQUFNLElBQUksSUFBSSxPQUFPLEtBQUssTUFBTSxJQUFJO1FBQ3hFLE1BQU0sTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxPQUFPLFdBQVcsV0FBVyxLQUFLLEtBQUssQ0FBQyxDQUFDO1FBQy9FLE1BQU0sWUFBWSxLQUFLLE1BQU8sTUFBTSxNQUFPLFVBQVUsR0FBRyxJQUFJO1FBQzVELE9BQU87U0FDSCxHQUFHO1NBQ0gsbUJBQW1CLE1BQU07U0FDekIsV0FBVyxNQUFNO1NBQ2pCLGFBQWE7UUFDakI7T0FDSjtPQUNBLE9BQU87TUFDWCxDQUFDO01BQ0QsTUFBTSxVQUFVLG9CQUFvQixnQkFBZ0IsYUFBYTtNQUNqRSxPQUFPO09BQ0gsR0FBRztPQUNILFNBQVM7T0FDVCxjQUFjLFFBQVE7T0FDdEIsWUFBWSxRQUFRO09BQ3BCLE9BQU8sUUFBUTtPQUNmLGVBQWU7TUFDbkI7S0FDSixDQUFDO0lBQ0w7R0FDSixDQUFDO0dBR0QseUJBQXlCLEtBQUs7R0FDOUIsb0JBQW9CLElBQUk7R0FDeEIsVUFBVSxHQUFHLFVBQVUsT0FBTyxvQ0FBb0M7RUFDdEUsT0FBTztHQUNILFVBQVUsSUFBSSxXQUFXLDZCQUE2QixPQUFPO0VBQ2pFO0NBQ0o7O0NBR0EsTUFBTSxxQkFBcUIsY0FBYztFQUNyQyxPQUFPLGdCQUFnQixLQUFJLE1BQUs7R0FDNUIsTUFBTSxVQUFVLEVBQUUsU0FBUyxPQUFPLEVBQUUsUUFBUTtHQUM1QyxJQUFJLGNBQWM7R0FDbEIsSUFBSSxlQUFlLFNBQVM7SUFDeEIsY0FBYyxVQUFVO0dBQzVCLE9BQU8sSUFBSSxlQUFlLFNBQVM7SUFDL0IsY0FBYyxXQUFXLGtCQUFrQixXQUFXO0dBQzFEO0dBRUEsSUFBSSxZQUFZO0dBQ2hCLElBQUksYUFBYTtJQUNiLElBQUksYUFBYSxPQUFPO0tBQ3BCLFlBQVksS0FBSyxJQUFJLFNBQVMsU0FBUztJQUMzQyxPQUFPLElBQUksYUFBYSxTQUFTO0tBQzdCLFlBQVksS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEdBQUcsVUFBVSxTQUFTLENBQUM7SUFDOUQsT0FBTyxJQUFJLGFBQWEsU0FBUztLQUM3QixZQUFZLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxXQUFXLFlBQVksT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDO0lBQzVGLE9BQU8sSUFBSSxhQUFhLGFBQWE7S0FDakMsWUFBWSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksR0FBRyxTQUFTLENBQUM7SUFDcEQ7R0FDSjtHQUVBLE9BQU87SUFDSCxHQUFHO0lBQ0gsY0FBYztJQUNkLGdCQUFnQixLQUFLLE1BQU0sWUFBWSxFQUFFLElBQUk7SUFDN0MsTUFBTSxLQUFLLE9BQU8sWUFBWSxXQUFXLEVBQUUsSUFBSTtJQUMvQztHQUNKO0VBQ0osQ0FBQztDQUNMLEdBQUc7RUFBQztFQUFpQjtFQUFVO0VBQVk7RUFBaUI7RUFBZ0I7RUFBZ0I7Q0FBUyxDQUFDO0NBRXRHLE1BQU0sNkJBQTZCO0VBQy9CLGNBQWEsU0FBUTtHQUNqQixJQUFJLENBQUMsTUFBTSxhQUFhLE9BQU87R0FDL0IsTUFBTSxVQUFVLEtBQUssWUFBWSxLQUFJLE1BQUs7SUFDdEMsTUFBTSxPQUFPLG1CQUFtQixNQUFLLE1BQUssRUFBRSxlQUFlLEVBQUUsVUFBVTtJQUN2RSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssYUFBYSxPQUFPO0lBQ3ZDLE9BQU87S0FBRSxHQUFHO0tBQUcsT0FBTyxLQUFLO0tBQWdCLGVBQWU7SUFBSztHQUNuRSxDQUFDO0dBQ0QsT0FBTztJQUFFLEdBQUc7SUFBTSxhQUFhO0dBQVE7RUFDM0MsQ0FBQztFQUNELGlCQUFpQixLQUFLO0VBQ3RCLFVBQVUsOENBQThDO0NBQzVEO0NBRUEsTUFBTSx1QkFBdUIsWUFBWTtFQUNyQyxpQkFBaUIsS0FBSzs7RUFFdEIsTUFBTSxNQUFNLE1BQU0saUJBQWlCLElBQUksR0FBRyxHQUFHO0VBQzdDLElBQUksSUFBSSxNQUFNLElBQUksTUFBTSxhQUFhLElBQUksSUFBSTtFQUM3QyxVQUFVLDBDQUEwQztDQUN4RDs7Q0FHQSxNQUFNLFlBQVksY0FBYztFQUM1QixJQUFJLENBQUMsbUJBQW1CLGdCQUFnQixXQUFXLEdBQUcsT0FBTyxDQUFDO0VBQzlELE1BQU0sVUFBVSxDQUFDO0VBQ2pCLGdCQUFnQixTQUFRLE1BQUs7R0FDekIsSUFBSSxDQUFDLEVBQUUsYUFBYTtHQUNwQixNQUFNLElBQUksSUFBSSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsbUJBQW1CLFNBQVM7SUFDMUQsS0FBSztJQUNMLE9BQU87R0FDWCxDQUFDO0dBQ0QsUUFBUSxNQUFNLFFBQVEsTUFBTSxLQUFLO0VBQ3JDLENBQUM7RUFDRCxPQUFPLE9BQU8sUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxZQUFZO0dBQUU7R0FBTTtFQUFNLEVBQUU7Q0FDM0UsR0FBRyxDQUFDLGVBQWUsQ0FBQztDQUVwQixNQUFNLFdBQVcsY0FBYztFQUMzQixJQUFJLFVBQVUsV0FBVyxHQUFHLE9BQU87RUFDbkMsT0FBTyxLQUFLLElBQUksR0FBRyxVQUFVLEtBQUksTUFBSyxFQUFFLEtBQUssR0FBRyxDQUFDO0NBQ3JELEdBQUcsQ0FBQyxTQUFTLENBQUM7Q0FFZCxNQUFNLGVBQWUscUJBQ2YsZ0JBQWdCLFdBQVUsTUFBSyxFQUFFLGVBQWUsbUJBQW1CLFVBQVUsSUFDN0UsQ0FBQztDQUVQLE1BQU0sbUJBQW1CO0VBQ3JCLElBQUksZUFBZSxHQUFHO0dBQ2xCLHFCQUFxQixnQkFBZ0IsZUFBZSxFQUFFO0VBQzFEO0NBQ0o7Q0FFQSxNQUFNLGVBQWU7RUFDakIsSUFBSSxlQUFlLGdCQUFnQixTQUFTLEdBQUc7R0FDM0MscUJBQXFCLGdCQUFnQixlQUFlLEVBQUU7RUFDMUQ7Q0FDSjtDQUVBLE1BQU0sbUJBQW1CLFFBQVEsT0FBTyxTQUFTO0VBQzdDLE1BQU0sSUFBSSxTQUFTLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLFFBQVEsVUFBVSxDQUFDO0VBQzdGLE1BQU0sWUFBWSxzQkFBc0IsUUFBUSxDQUFDO0VBQ2pELElBQUksY0FBYyxNQUFNO0dBQ3BCLE9BQU87SUFDSCxPQUFPO0lBQ1AsTUFBTSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OztJQUMvQixXQUFXO0dBQ2Y7RUFDSjtFQUNBLElBQUksY0FBYyxPQUFPO0dBQ3JCLE9BQU87SUFDSCxPQUFPO0lBQ1AsTUFBTSx3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7OztJQUMxQixXQUFXO0dBQ2Y7RUFDSjtFQUNBLE9BQU87R0FDSCxPQUFPO0dBQ1AsTUFBTSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztHQUM5QixXQUFXO0VBQ2Y7Q0FDSjtDQUVBLElBQUksU0FBUyxPQUNULHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1gsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNJLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGlFQUFrRTs7OzthQUNyRix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF5RDtHQUFvQjs7OztXQUN6Rjs7Ozs7O0NBQ0o7Ozs7O0NBR1QsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0ksd0JBQUMsU0FBRCxDQUFVOzs7OztHQUVWLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsVUFBRDtRQUNJLGVBQWUsU0FBUyxXQUFXO1FBQ25DLFdBQVU7a0JBRVYsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7T0FDbEI7Ozs7aUJBQ1Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDVCxNQUFNLFNBQVM7UUFDaEI7Ozs7a0JBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWIsQ0FDSyxnQkFBZ0IsUUFBTyxzQkFDekI7Ozs7O2dCQUNGOzs7OztlQUNKOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNJLHdCQUFDLFVBQUQ7U0FDSSxlQUFlLFNBQVMsVUFBVSxHQUFHLFdBQVc7U0FDaEQsV0FBVTttQkFGZCxDQUlJLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7bUJBQUMsV0FDbkI7Ozs7OztRQUVSLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUNJLHdCQUFDLFNBQUQ7VUFDSSxNQUFLO1VBQ0wsU0FBUztVQUNULFdBQVUsTUFBSyxvQkFBb0IsRUFBRSxPQUFPLE9BQU87VUFDbkQsV0FBVTtTQUNiOzs7O21CQUNELHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7aUJBQ3RCOzs7Ozs7UUFFUCx3QkFBQyxVQUFEO1NBQ0ksTUFBSztTQUNMLGVBQWUsYUFBYSxJQUFJLEtBQUs7U0FDckMsVUFBVTtTQUNWLFdBQVU7U0FDVixPQUFNO21CQUxWLENBT0ssWUFBWSx3QkFBQyxTQUFEO1VBQVMsTUFBTTtVQUFJLFdBQVU7U0FBZ0I7Ozs7b0JBQUksd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OzttQkFDbkYsd0JBQUMsUUFBRCxZQUFNLE1BQVM7Ozs7aUJBQ1g7Ozs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDSSxNQUFLO1NBQ0wsZUFBZSxhQUFhLElBQUksTUFBTTtTQUN0QyxVQUFVO1NBQ1YsV0FBVTtTQUNWLE9BQU07bUJBTFYsQ0FPSSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7O21CQUNyQix3QkFBQyxRQUFELFlBQU0sUUFBVzs7OztpQkFDYjs7Ozs7O1FBRVIsd0JBQUMsVUFBRDtTQUNJLE1BQUs7U0FDTCxlQUFlLGFBQWEsSUFBSSxLQUFLO1NBQ3JDLFVBQVU7U0FDVixXQUFVO1NBQ1YsT0FBTTttQkFMVixDQU9JLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7bUJBQ3JCLHdCQUFDLFFBQUQsWUFBTSxNQUFTOzs7O2lCQUNYOzs7Ozs7T0FDUDs7Ozs7Y0FDSjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNJLHdCQUFDLFVBQUQ7U0FDSSxlQUFlLGFBQWEsV0FBVztTQUN2QyxXQUFXLHlHQUNQLGNBQWMsY0FDUiw0RUFDQTttQkFMZCxDQVFJLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7bUJBQUMsVUFDYjs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNJLGVBQWUsYUFBYSxVQUFVO1NBQ3RDLFdBQVcseUdBQ1AsY0FBYyxhQUNSLDhFQUNBO21CQUxkO1VBUUksd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7Ozs7VUFBQztVQUMxQixVQUFVLFNBQVMsS0FDaEIsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ1gsVUFBVTtVQUNUOzs7OztTQUVOOzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0ksZUFBZSxhQUFhLFlBQVk7U0FDeEMsV0FBVyx1R0FDUCxjQUFjLGVBQ1Isa0ZBQ0E7bUJBTGQ7VUFRSSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztVQUN4Qix3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7O1VBQ3JCLGdCQUFnQixjQUFjLEtBQzNCLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUNJLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHlGQUErRjs7OztxQkFDL0csd0JBQUMsUUFBRCxFQUFNLFdBQVUsMkRBQWlFOzs7O21CQUMvRTs7Ozs7O1VBRVQsZ0JBQWdCLFlBQ2Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ1gsZUFBZSxTQUFTO1VBQ3ZCOzs7OztTQUVOOzs7Ozs7T0FDUDs7Ozs7Z0JBRUosY0FBYyxnQkFDWCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNJLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUNJLHdCQUFDLFNBQUQ7VUFDSSxNQUFLO1VBQ0wsU0FBUztVQUNULFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxPQUFPO1VBQ2hELFdBQVU7U0FDYjs7OzttQkFDRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUI7U0FBdUI7Ozs7aUJBQ3ZEOzs7Ozs7UUFDUCx3QkFBQyxVQUFEO1NBQ0ksTUFBSztTQUNMLGVBQWUsb0JBQW9CLEtBQUs7U0FDeEMsVUFBVTtTQUNWLFdBQVU7U0FDVixPQUFNO21CQUxWLENBT0ksd0JBQUMsV0FBRDtVQUFXLE1BQU07VUFBSSxXQUFXLG9CQUFvQixpQkFBaUI7U0FBSzs7OzttQkFDMUUsd0JBQUMsUUFBRCxZQUFNLFdBQWM7Ozs7aUJBQ2hCOzs7Ozs7UUFDUCxtQkFDRyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDWCxnQkFBZ0IsbUJBQW1CLE9BQU87UUFDekM7Ozs7O09BRVQ7Ozs7O2NBRVI7Ozs7OztLQUVKLFNBQ0csd0JBQUMsT0FBRDtNQUFLLFdBQVcsd0dBQXdHLE1BQU0sU0FBUyxVQUFVLGVBQWU7Z0JBQzNKLE1BQU07S0FDTjs7Ozs7S0FHVCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUdLLGNBQWMsZUFDWCxnREFFSyxVQUFVLFNBQVMsS0FDaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNJLHdCQUFDLFlBQUQ7V0FBWSxNQUFNO1dBQUksV0FBVTtVQUFxQzs7OztvQkFBQywrQkFFdEU7Ozs7O21CQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFvRDtTQUU5RDs7OztpQkFDRjs7OzttQkFDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDSyxVQUFVLFFBQU8sYUFDaEI7Ozs7O2lCQUNMOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDVixVQUFVLEtBQUssTUFBTSxRQUFRO1VBQzFCLE1BQU0sZ0JBQWdCLEtBQUssSUFBSyxLQUFLLFFBQVEsV0FBWSxLQUFLLEVBQUU7VUFDaEUsT0FDSSx3QkFBQyxPQUFEO1dBQWUsV0FBVTtxQkFBekI7WUFDSSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFDWCxLQUFLO1lBQ0o7Ozs7O1lBQ04sd0JBQUMsT0FBRDthQUNJLFdBQVU7YUFDVixPQUFPLEVBQUUsUUFBUSxHQUFHLGNBQWMsR0FBRztZQUN4Qzs7Ozs7WUFDRCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFDWCxLQUFLO1lBQ0o7Ozs7O1dBQ0w7YUFYSzs7OztpQkFXTDtTQUViLENBQUM7UUFDQTs7OztnQkFDSjs7Ozs7aUJBR1IsZ0JBQWdCLFdBQVcsSUFDeEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWCx3QkFBQyxlQUFELEVBQWUsTUFBTSxHQUFLOzs7OztTQUN6Qjs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFxRDtVQUUvRDs7OztvQkFDSix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBNkQ7VUFFdkU7Ozs7a0JBQ0Y7Ozs7OztTQUNKLE1BQU0sWUFDSCx3QkFBQyxVQUFEO1VBQ0ksTUFBSztVQUNMLGVBQWU7V0FDWCxNQUFNLE1BQU0sR0FBRyxPQUFPLFNBQVMsT0FBTyxLQUFLLEtBQUs7V0FDaEQsVUFBVSxVQUFVLFVBQVUsR0FBRztXQUNqQyxVQUFVLGdEQUFnRDtVQUM5RDtVQUNBLFdBQVU7b0JBUGQsQ0FTSSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7O29CQUNuQix3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O2tCQUM3Qjs7Ozs7O1FBRVg7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFtRDtVQUF3Qjs7OztvQkFDekYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQXdFLGdCQUFnQixRQUFPLGdCQUFvQjs7Ozs7a0JBQ2xIOzs7OzttQkFFSixnQkFBZ0IsU0FBUyxLQUN0Qix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWCx3QkFBQyxVQUFEO1dBQ0ksTUFBSztXQUNMLGVBQWUsaUJBQWlCLElBQUk7V0FDcEMsV0FBVTtXQUNWLE9BQU07cUJBSlYsQ0FNSSx3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7O3FCQUFDLDBCQUNqQjs7Ozs7O1NBQ1A7Ozs7aUJBRVI7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNYLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUNJLHdCQUFDLFNBQUQsWUFDSSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBZDtZQUNJLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFZO1lBQUs7Ozs7O1lBQy9CLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFZO1lBQWE7Ozs7O1lBQ3ZDLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFZO1lBQWdCOzs7OztZQUMxQyx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBWTtZQUFTOzs7OztZQUNuQyx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBWTtZQUFTOzs7OztZQUNuQyx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBWTtZQUFROzs7OztZQUNsQyx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBWTtZQUFVOzs7OztZQUNwQyx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBWTtZQUFnQjs7Ozs7WUFDMUMsd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQXVCO1lBQVE7Ozs7O1dBQzdDOzs7OzttQkFDRDs7OztvQkFDUCx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFDWixnQkFBZ0IsS0FBSyxHQUFHLE1BQU07WUFDM0IsTUFBTSxXQUFXLEVBQUUscUJBQXFCO1lBQ3hDLE1BQU0sVUFBVSxFQUFFLGdCQUFnQjtZQUNsQyxNQUFNLFFBQVEsRUFBRSxjQUFjLE9BQU8sRUFBRSxhQUFhLEtBQUssSUFBSSxXQUFXLFNBQVMsQ0FBQztZQUNsRixNQUFNLFlBQVksbUJBQW1CLEVBQUU7WUFFdkMsT0FDSSx3QkFBQyxNQUFEO2FBQTRCLFdBQVU7dUJBQXRDO2NBQ0ksd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQTBDLElBQUk7Y0FBTTs7Ozs7Y0FDbEUsd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQWQsQ0FDSSx3QkFBQyxPQUFEO2dCQUFLLFdBQVU7MEJBQTRDLEVBQUUsa0JBQWtCO2VBQWM7Ozs7eUJBQzdGLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFBZixDQUFnRSxLQUFFLEVBQUUsVUFBZ0I7Ozs7O3VCQUNwRjs7Ozs7O2NBQ0osd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQWQ7Z0JBQ0ssRUFBRSxpQkFBaUI7Z0JBQUU7Z0JBQUUsRUFBRSxrQkFBa0I7ZUFDNUM7Ozs7OztjQUNKLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUNUO2NBQ0Q7Ozs7O2NBQ0osd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQ1Q7Y0FDRDs7Ozs7Y0FDSix3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFDVCxZQUNHLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFBZjtpQkFDSSx3QkFBQyxTQUFEO2tCQUNJLE1BQUs7a0JBQ0wsS0FBSTtrQkFDSixLQUFJO2tCQUNKLE1BQUs7a0JBQ0wsT0FBTztrQkFDUCxXQUFVLE1BQUssb0JBQW9CLEVBQUUsT0FBTyxLQUFLO2tCQUNqRCxXQUFVO2tCQUNWO2tCQUNBLFlBQVcsTUFBSyxFQUFFLFFBQVEsV0FBVywwQkFBMEIsRUFBRSxZQUFZLGdCQUFnQjtpQkFDaEc7Ozs7O2lCQUNELHdCQUFDLFVBQUQ7a0JBQ0ksTUFBSztrQkFDTCxlQUFlLDBCQUEwQixFQUFFLFlBQVksZ0JBQWdCO2tCQUN2RSxXQUFVO2tCQUNWLE9BQU07NEJBRU4sd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7Ozs7aUJBQ2Q7Ozs7O2lCQUNSLHdCQUFDLFVBQUQ7a0JBQ0ksTUFBSztrQkFDTCxlQUFlLGtCQUFrQixJQUFJO2tCQUNyQyxXQUFVO2tCQUNWLE9BQU07NEJBRU4sd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7aUJBQ1Y7Ozs7O2dCQUNQOzs7OzswQkFFTCx3QkFBQyxPQUFEO2dCQUFLLFdBQVU7MEJBQWYsQ0FDSyxFQUFFLFNBQVMsT0FDUix3QkFBQyxRQUFEO2lCQUFNLFdBQVcsOENBQ2IsRUFBRSxTQUFTLEtBQ0wsZ0ZBQ0E7MkJBSFY7a0JBS0ssRUFBRTtrQkFBTTtrQkFDUixFQUFFLGlCQUFpQix3QkFBQyxRQUFEO21CQUFNLFdBQVU7NkJBQXlDO2tCQUFXOzs7OztpQkFDdEY7Ozs7OzJCQUVOLHdCQUFDLFFBQUQ7aUJBQU0sV0FBVTsyQkFBeUQ7Z0JBQVM7Ozs7MEJBRXRGLHdCQUFDLFVBQUQ7aUJBQ0ksTUFBSztpQkFDTCxlQUFlO2tCQUNYLGtCQUFrQixFQUFFLFVBQVU7a0JBQzlCLG9CQUFvQixFQUFFLFNBQVMsT0FBTyxPQUFPLEVBQUUsS0FBSyxJQUFJLEtBQUs7aUJBQ2pFO2lCQUNBLFdBQVU7aUJBQ1YsT0FBTTsyQkFFTix3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztnQkFDZDs7Ozt3QkFDUDs7Ozs7O2NBRVQ7Ozs7O2NBQ0osd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQ1Ysd0JBQUMsVUFBRDtnQkFDSSxPQUFPLGVBQWUsTUFBSyxNQUFLLEVBQUUsU0FBUyxFQUFFLFFBQVEsWUFBWSxDQUFDLENBQUMsRUFBRSxNQUFNO2dCQUMzRSxXQUFVLE1BQUssbUJBQW1CLEVBQUUsWUFBWSxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUM7Z0JBQ3hFLFVBQVUsbUJBQW1CLEVBQUU7Z0JBQy9CLFdBQVcsa0pBQWtKLFlBQVksRUFBRSxNQUFNOzBCQUVoTCxlQUFlLEtBQUksTUFDaEIsd0JBQUMsVUFBRDtpQkFBbUIsT0FBTyxFQUFFOzJCQUFLLEVBQUU7Z0JBQWMsR0FBcEMsRUFBRTs7Ozt1QkFBa0MsQ0FDcEQ7ZUFDRzs7Ozs7Y0FDUjs7Ozs7Y0FDSix3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFDVCxXQUFXLEVBQUUsV0FBVztjQUN6Qjs7Ozs7Y0FDSix3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFDVix3QkFBQyxVQUFEO2dCQUNJLGVBQWUscUJBQXFCLENBQUM7Z0JBQ3JDLFdBQVU7MEJBRmQsQ0FJSSx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OzBCQUFDLGlCQUNiOzs7Ozs7Y0FDUjs7Ozs7YUFDSjtlQWpHSyxFQUFFLGNBQWM7Ozs7bUJBaUdyQjtXQUVaLENBQUM7VUFDRTs7OztrQkFDSjs7Ozs7O1FBQ047Ozs7Z0JBQ0o7Ozs7O2VBRVg7Ozs7O09BSUwsY0FBYyxjQUNYLCtDQUNLLGtCQUNHLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUEyRTtPQUE4Qjs7OztrQkFDeEgsVUFBVSxXQUFXLElBQ3JCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0ksd0JBQUMsZUFBRDtVQUFlLE1BQU07VUFBSSxXQUFVO1NBQThDOzs7OztTQUNqRix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBdUQ7U0FBZ0Q7Ozs7O1NBQ3BILHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUE2QztTQUFvRTs7Ozs7UUFDN0g7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNWLFVBQVUsS0FBSyxJQUFJLE1BQ2hCLHdCQUFDLE9BQUQ7U0FBc0IsV0FBVTttQkFBaEM7VUFDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQjthQUNJLHdCQUFDLGVBQUQsRUFBZSxNQUFNLEdBQUs7Ozs7O2FBQUM7YUFBRSxHQUFHO1lBQzlCOzs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBbUUsV0FBVyxHQUFHLFNBQVM7V0FBUTs7OzttQkFDakg7Ozs7OztVQUVKLEdBQUcsZUFDQSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDUixHQUFHO1VBQ0w7Ozs7O1VBR1Asd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1lBQUssV0FBVTt1QkFDVCxHQUFHLFlBQVksSUFBRyxDQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWTtXQUMzQzs7OztxQkFDTCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBd0QsR0FBRyxZQUFZO1dBQWU7Ozs7bUJBQ3JHOzs7Ozs7U0FDSjtXQXBCSyxHQUFHLE1BQU07Ozs7ZUFvQmQsQ0FDUjtPQUNBOzs7O2dCQUVYOzs7OztPQUlMLGNBQWMsZ0JBQ1gsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FFSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNJLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQ0ksd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDSSx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBNkM7Y0FBZ0I7Ozs7d0JBQzdFLHdCQUFDLGFBQUQ7ZUFBYSxNQUFNO2VBQUksV0FBVyxnQkFBZ0IsY0FBYyxnQkFBZ0Isa0JBQWtCLHFCQUFxQjtjQUFtQjs7OztzQkFDekk7Ozs7OzthQUNMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUNYLHdCQUFDLFFBQUQ7ZUFBTSxXQUFXLCtEQUNiLGdCQUFnQixjQUFjLGdCQUFnQixrQkFDeEMsa0lBQ0E7eUJBRUwsZ0JBQWdCLGNBQWMsZ0JBQWdCLGtCQUFrQixVQUFVO2NBQ3pFOzs7OzthQUNMOzs7OzthQUNMLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUNSLGdCQUFnQix3QkFDWCxxQkFBcUIsZUFBZSxnQkFBZ0IsRUFBRSxnQkFDdEQ7YUFDUDs7Ozs7WUFDRjs7Ozs7O1dBRUwsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDSSx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUE2QztjQUF3Qjs7Ozt3QkFDckYsd0JBQUMsVUFBRDtlQUFVLE1BQU07ZUFBSSxXQUFVO2NBQWtCOzs7O3NCQUMvQzs7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDSSx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFDWCxnQkFBZ0IsbUJBQW1CO2NBQ2xDOzs7O3dCQUNOLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUF1QztjQUFhOzs7O3NCQUNuRTs7Ozs7O2FBQ0wsd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQW9FO2FBRTlFOzs7OztZQUNGOzs7Ozs7V0FFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNJLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQTZDO2NBQWlCOzs7O3dCQUM5RSx3QkFBQyxPQUFEO2VBQU8sTUFBTTtlQUFJLFdBQVU7Y0FBa0M7Ozs7c0JBQzVEOzs7Ozs7YUFDTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUNYLGdCQUFnQixlQUFlO2NBQzlCOzs7O3dCQUNOLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUF1QztjQUFvQjs7OztzQkFDMUU7Ozs7OzthQUNMLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUFzRDthQUVoRTs7Ozs7WUFDRjs7Ozs7O1dBRUwsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDSSx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUE2QztjQUFrQjs7Ozt3QkFDL0Usd0JBQUMsY0FBRDtlQUFjLE1BQU07ZUFBSSxXQUFVO2NBQWlCOzs7O3NCQUNsRDs7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDSSx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFDWCxnQkFBZ0Isa0JBQWtCO2NBQ2pDOzs7O3dCQUNOLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUF1QztjQUFhOzs7O3NCQUNuRTs7Ozs7O2FBQ0wsd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQXNEO2FBRWhFOzs7OztZQUNGOzs7Ozs7VUFDSjs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDVjtZQUNHO2FBQUUsSUFBSTthQUFPLE9BQU87WUFBZ0I7WUFDcEM7YUFBRSxJQUFJO2FBQWUsT0FBTztZQUFxQjtZQUNqRDthQUFFLElBQUk7YUFBYSxPQUFPO1lBQWU7WUFDekM7YUFBRSxJQUFJO2FBQWMsT0FBTztZQUFrQjtZQUM3QzthQUFFLElBQUk7YUFBbUIsT0FBTztZQUFxQjtXQUN6RCxDQUFDLENBQUMsS0FBSSxRQUNGLHdCQUFDLFVBQUQ7WUFFSSxNQUFLO1lBQ0wsZUFBZSxvQkFBb0IsSUFBSSxFQUFFO1lBQ3pDLFdBQVcsOEZBQ1AscUJBQXFCLElBQUksS0FDbkIsdUNBQ0E7c0JBR1QsSUFBSTtXQUNELEdBVkMsSUFBSTs7OztrQkFVTCxDQUNYO1VBQ0E7Ozs7b0JBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxRQUFEO1lBQVEsTUFBTTtZQUFJLFdBQVU7V0FBNkQ7Ozs7cUJBQ3pGLHdCQUFDLFNBQUQ7WUFDSSxNQUFLO1lBQ0wsYUFBWTtZQUNaLE9BQU87WUFDUCxXQUFVLE1BQUssb0JBQW9CLEVBQUUsT0FBTyxLQUFLO1lBQ2pELFdBQVU7V0FDYjs7OzttQkFDQTs7Ozs7a0JBQ0o7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNWLHFCQUFxQixDQUFDLGlCQUNuQix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFNBQUQ7WUFBUyxNQUFNO1lBQUksV0FBVTtXQUFnQzs7OztxQkFDN0Qsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQW9CO1dBQStCOzs7O21CQUNsRTs7Ozs7cUJBQ0wsaUJBQWlCLFdBQVcsSUFDNUIsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDSSx3QkFBQyxhQUFEO2FBQWEsTUFBTTthQUFJLFdBQVU7WUFBbUQ7Ozs7O1lBQ3BGLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUF1RDtZQUFvQzs7Ozs7WUFDeEcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWU7WUFBaUc7Ozs7O1dBQzVIOzs7OztxQkFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWCx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBakIsQ0FDSSx3QkFBQyxTQUFELFlBQ0ksd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQWQ7Y0FDSSx3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFBWTtjQUFhOzs7OztjQUN2Qyx3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFBWTtjQUFxQjs7Ozs7Y0FDL0Msd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQVk7Y0FBYzs7Ozs7Y0FDeEMsd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQVk7Y0FBcUI7Ozs7O2NBQy9DLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUFZO2NBQXNCOzs7OztjQUNoRCx3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFBdUI7Y0FBYzs7Ozs7YUFDbkQ7Ozs7O3FCQUNEOzs7O3NCQUNQLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUNaLGlCQUFpQixLQUFLLFNBQVMsUUFBUTtjQUNwQyxNQUFNLGFBQWEsaUJBQWlCLElBQUksUUFBUSxhQUFhLFdBQVcsS0FBSztjQUM3RSxNQUFNLFFBQVEsZ0JBQWdCLGdCQUFnQjtjQUM5QyxNQUFNLHdCQUF3Qix5QkFBeUIsT0FBTztjQUM5RCxNQUFNLGtCQUFrQix5QkFBeUIsU0FBUyxRQUFRLGtCQUFrQjtjQUVwRixPQUNJLHdCQUFDLFVBQUQsYUFDSSx3QkFBQyxNQUFEO2VBQUksV0FBVyxxRUFDWCxrQkFBa0Isb0NBQW9DO3lCQUQxRDtnQkFHSSx3QkFBQyxNQUFEO2lCQUFJLFdBQVU7MkJBQ1Ysd0JBQUMsT0FBRDtrQkFBSyxXQUFVOzRCQUFmLENBQ0ksd0JBQUMsT0FBRDttQkFBSyxXQUFVOzZCQUFmLENBQ0ksd0JBQUMsT0FBRDtvQkFBSyxXQUFVOytCQUNULFFBQVEsa0JBQWtCLElBQUcsQ0FBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVk7bUJBQ3REOzs7OzZCQUNKLFFBQVEsV0FDTCx3QkFBQyxRQUFEO29CQUFNLFdBQVU7b0JBQTBHLE9BQU07bUJBQWlCOzs7OzhCQUVqSix3QkFBQyxRQUFEO29CQUFNLFdBQVU7b0JBQTBILE9BQU07bUJBQVc7Ozs7MkJBRTlKOzs7Ozs0QkFDTCx3QkFBQyxPQUFEO21CQUFLLFdBQVU7NkJBQWYsQ0FDSSx3QkFBQyxPQUFEO29CQUFLLFdBQVU7OEJBQWYsQ0FDSSx3QkFBQyxRQUFEO3FCQUFNLFdBQVU7K0JBQVksUUFBUSxrQkFBa0I7b0JBQWU7Ozs7OEJBQ3BFLFFBQVEsWUFDTCx3QkFBQyxRQUFEO3FCQUFNLFdBQVU7K0JBQTBIO29CQUVwSTs7Ozs0QkFFVDs7Ozs7NkJBQ0wsd0JBQUMsT0FBRDtvQkFBSyxXQUFVOzhCQUNWLFFBQVEsWUFBWSxTQUFTLFFBQVEsVUFBVSxNQUFNLEdBQUcsQ0FBQyxFQUFFLE9BQVEsUUFBUSxhQUFhLFlBQVksUUFBUSxlQUFlO21CQUMzSDs7OzsyQkFDSjs7Ozs7MEJBQ0o7Ozs7OztnQkFDTDs7Ozs7Z0JBRUosd0JBQUMsTUFBRDtpQkFBSSxXQUFVOzJCQUNULFFBQVEsV0FBVyxnQkFDaEIsd0JBQUMsUUFBRDtrQkFBTSxXQUFVOzRCQUFoQixDQUNJLHdCQUFDLFVBQUQ7bUJBQVUsTUFBTTttQkFBSSxXQUFVO2tCQUFpQjs7Ozs0QkFBQyxvQkFFOUM7Ozs7OzRCQUVOLHdCQUFDLFFBQUQ7a0JBQU0sV0FBVTs0QkFBaEIsQ0FDSSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OzRCQUFDLGNBRXhCOzs7Ozs7Z0JBRVY7Ozs7O2dCQUVKLHdCQUFDLE1BQUQ7aUJBQUksV0FBVTsyQkFDVCxRQUFRLGlCQUFpQixJQUN0Qix3QkFBQyxRQUFEO2tCQUFNLFdBQVcsYUFBYSxRQUFRLGtCQUFrQixRQUFRLG1DQUFtQzs0QkFBbkcsQ0FDSyxRQUFRLGdCQUFlLEdBQ3RCOzs7Ozs0QkFFTix3QkFBQyxRQUFEO2tCQUFNLFdBQVU7NEJBQWlCO2lCQUFROzs7OztnQkFFN0M7Ozs7O2dCQUVKLHdCQUFDLE1BQUQ7aUJBQUksV0FBVTsyQkFDekUsMEJBQTBCLElBQ3ZCLHdCQUFDLFFBQUQ7a0JBQU0sV0FBVTs0QkFBZ047aUJBRTFOOzs7OzRCQUNOLGtCQUNBLHdCQUFDLFFBQUQ7a0JBQU0sV0FBVTs0QkFBaEI7bUJBQ0ksd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7Ozs7bUJBQ3pCO21CQUFzQjtrQkFDckI7Ozs7OzRCQUVOLHdCQUFDLFFBQUQ7a0JBQU0sV0FBVTs0QkFBaEI7bUJBQW9OO21CQUM1TTttQkFBc0I7a0JBQ3hCOzs7Ozs7Z0JBRVY7Ozs7O2dCQUU0RCx3QkFBQyxNQUFEO2lCQUFJLFdBQVU7MkJBQWQsQ0FDSSx3QkFBQyxPQUFELFlBQU0sV0FBVyxRQUFRLGNBQWMsUUFBUSxTQUFTLEVBQU87Ozs7MkJBQy9ELHdCQUFDLE9BQUQ7a0JBQUssV0FBVTs0QkFBZixDQUE0QyxXQUNoQyxXQUFXLFFBQVEsU0FBUyxDQUNuQzs7Ozs7eUJBQ0w7Ozs7OztnQkFFSix3QkFBQyxNQUFEO2lCQUFJLFdBQVU7MkJBQ1Ysd0JBQUMsT0FBRDtrQkFBSyxXQUFVOzRCQUFmO21CQUNLLFFBQVEsYUFBYSxRQUFRLFdBQVcsaUJBQ3JDLHdCQUFDLFVBQUQ7b0JBQ0ksTUFBSztvQkFDTCxlQUFlLHNCQUFzQixPQUFPO29CQUM1QyxXQUFVO29CQUNWLE9BQU07OEJBSlYsQ0FNSSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OzhCQUN4Qix3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7NEJBQ3BCOzs7Ozs7bUJBRVgsUUFBUSxhQUFhLFFBQVEsV0FBVyxlQUNyQyx3QkFBQyxVQUFEO29CQUNJLE1BQUs7b0JBQ0wsZUFBZSx1QkFBdUIsT0FBTztvQkFDN0MsV0FBVTtvQkFDVixPQUFNOzhCQUpWLENBTUksd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs4QkFDdEIsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7Ozs0QkFDckI7Ozs7OzttQkFFWix3QkFBQyxVQUFEO29CQUNJLE1BQUs7b0JBQ0wsZUFBZSxvQkFBb0IsUUFBUSxhQUFhLFdBQVcsS0FBSztvQkFDeEUsV0FBVTs4QkFIZCxDQUtJLHdCQUFDLFFBQUQ7cUJBQU07cUJBQU0sUUFBUSxZQUFZLFVBQVU7cUJBQUU7b0JBQU87Ozs7OEJBQ2xELGFBQWEsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OzsrQkFBSSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OzRCQUM1RDs7Ozs7O2tCQUNQOzs7Ozs7Z0JBQ0w7Ozs7O2VBQ0o7Ozs7O3dCQUdILGNBQ0csd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQ1Ysd0JBQUMsTUFBRDtnQkFBSSxTQUFTO2dCQUFHLFdBQVU7MEJBQ3RCLHdCQUFDLE9BQUQ7aUJBQUssV0FBVTsyQkFBZixDQUNJLHdCQUFDLE9BQUQ7a0JBQUssV0FBVTs0QkFBZixDQUNJLHdCQUFDLFFBQUQ7bUJBQU0sV0FBVTs2QkFBaEIsQ0FBdUUsOEJBQ3hDLFFBQVEsa0JBQWtCLFFBQ25EOzs7Ozs0QkFDTix3QkFBQyxRQUFEO21CQUFNLFdBQVU7NkJBQWhCO29CQUE2QztvQkFDakMsUUFBUSxZQUFZLFVBQVU7b0JBQUU7bUJBQ3RDOzs7OzswQkFDTDs7Ozs7MkJBRUgsQ0FBQyxRQUFRLGNBQWMsUUFBUSxXQUFXLFdBQVcsSUFDbkQsd0JBQUMsS0FBRDtrQkFBRyxXQUFVOzRCQUFxQztpQkFFL0M7Ozs7NEJBRUgsd0JBQUMsT0FBRDtrQkFBSyxXQUFVOzRCQUNWLFFBQVEsV0FBVyxLQUFLLFdBQVcsU0FBUzttQkFDekMsTUFBTSxRQUFRLGlCQUFpQixVQUFVLElBQUk7bUJBQzdDLE9BQ0ksd0JBQUMsT0FBRDtvQkFFSSxXQUFVOzhCQUZkLENBSUksd0JBQUMsT0FBRDtxQkFBSyxXQUFVOytCQUFmLENBQ0ksd0JBQUMsUUFBRDtzQkFBTSxXQUFXLGtCQUFrQixNQUFNLEdBQUcsR0FBRyxNQUFNO2dDQUNoRCxNQUFNO3FCQUNMOzs7OytCQUNOLHdCQUFDLFFBQUQ7c0JBQU0sV0FBVTtnQ0FDWCxNQUFNO3FCQUNMOzs7OzZCQUNMOzs7Ozs4QkFDTCx3QkFBQyxRQUFEO3FCQUFNLFdBQVU7K0JBQ1gsbUJBQW1CLFVBQVUsVUFBVTtvQkFDdEM7Ozs7NEJBQ0w7c0JBZEk7Ozs7MEJBY0o7a0JBRWIsQ0FBQztpQkFDQTs7Ozt5QkFFUjs7Ozs7O2VBQ0w7Ozs7O2NBQ0o7Ozs7c0JBRUYsS0FuS0ssUUFBUSxhQUFhLFdBQVc7Ozs7cUJBbUtyQzthQUVsQixDQUFDO1lBQ0U7Ozs7b0JBQ0o7Ozs7OztVQUNOOzs7OztTQUVSOzs7OztRQUNKOzs7Ozs7TUFHUjs7Ozs7O0lBQ0o7Ozs7OztHQUdKLHNCQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFEO0tBQ0ksV0FBVTtLQUNWLGVBQWUsc0JBQXNCLElBQUk7SUFDNUM7Ozs7Y0FFRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BR0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXFEO09BRS9EOzs7O2lCQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQWlFO1NBQ2xELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnRCxtQkFBbUIsa0JBQWtCO1NBQWU7Ozs7O1NBQUM7U0FBWSxtQkFBbUI7U0FBVztRQUMzSzs7Ozs7ZUFDRjs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0ksZUFBZSxzQkFBc0IsSUFBSTtRQUN6QyxXQUFVO2tCQUVWLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O09BQ1Y7Ozs7ZUFDUDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNJLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXFFO1VBQWE7Ozs7b0JBQy9GLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsU0FBRDtZQUNJLE1BQUs7WUFDTCxLQUFJO1lBQ0osS0FBSTtZQUNKLE1BQUs7WUFDTCxPQUFPLG1CQUFtQixTQUFTLE9BQU8sbUJBQW1CLFFBQVE7WUFDckUsV0FBVSxNQUFLO2FBQ1gsTUFBTSxNQUFNLFdBQVcsRUFBRSxPQUFPLEtBQUssS0FBSzthQUMxQyx1QkFBc0IsVUFBUztjQUFFLEdBQUc7Y0FBTSxPQUFPO2FBQUksRUFBRTtZQUMzRDtZQUNBLFNBQVEsTUFBSywwQkFBMEIsbUJBQW1CLFlBQVksRUFBRSxPQUFPLEtBQUs7WUFDcEYsV0FBVTtXQUNiOzs7O3FCQUNELHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFtQztXQUFPOzs7O21CQUN6RDs7Ozs7a0JBQ0o7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXFFO1VBQVU7Ozs7b0JBQzVGLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiO1lBQ0ssbUJBQW1CO1lBQWM7WUFBRSxtQkFBbUI7V0FDeEQ7Ozs7O2tCQUNGOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFxRTtVQUFROzs7O29CQUMxRix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDUixtQkFBbUIsZ0JBQWdCO1VBQ3JDOzs7O2tCQUNGOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFxRTtVQUFlOzs7O29CQUNqRyx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDUixXQUFXLG1CQUFtQixXQUFXO1VBQzNDOzs7O2tCQUNGOzs7Ozs7UUFDSjs7Ozs7a0JBRUgsbUJBQW1CLFdBQVcsQ0FBQyxFQUFDLENBQUUsTUFBSyxNQUFLLEVBQUUsV0FBVyxDQUFDLEtBQ3hELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Esd0JBQUMsVUFBRDtTQUFRLE9BQU87U0FBUyxXQUFVLE1BQUs7VUFBRSxXQUFXLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBYSxRQUFRLDhCQUE4QixFQUFFLE9BQU8sS0FBSztTQUFHO1NBQUcsV0FBVTttQkFDakosaUJBQWlCLEtBQUksVUFBUyx3QkFBQyxVQUFEO1VBQXVCLE9BQU8sTUFBTTtvQkFBSyxNQUFNO1NBQWEsR0FBL0MsTUFBTTs7OztnQkFBeUMsQ0FBQztRQUN4Rjs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0ksTUFBSztTQUNMLGVBQWUsc0JBQXNCLGtCQUFrQjtTQUN2RCxVQUFVO1NBQ1YsV0FBVTttQkFKZCxDQU1JLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7bUJBQ3hCLG9CQUFvQixlQUFlLGtCQUNoQzs7Ozs7Z0JBQ0g7Ozs7O2VBRVI7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLEVBQ00sbUJBQW1CLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSyxRQUFRLFVBQVU7UUFDdkQsTUFBTSxRQUFRLGlCQUFpQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLE9BQU8sVUFBVSxDQUFDO1FBQ3ZGLE1BQU0sZUFBZSxzQkFBc0IsUUFBUSxJQUFJO1FBQ3ZELE1BQU0sU0FBUyxnQkFBZ0IsUUFBUSxJQUFJO1FBQzNDLE1BQU0sWUFBWSxPQUFPLGlCQUFpQixtQkFBbUIsSUFBSTtRQUNqRSxNQUFNLFVBQVUsUUFBUSxPQUFPLEtBQUssTUFBTSxJQUFJLElBQUksT0FBTyxLQUFLLE1BQU0sSUFBSTtRQUV4RSxPQUNJLHdCQUFDLE9BQUQ7U0FFSSxXQUFVO21CQUZkO1VBSUksd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUNYLFFBQVE7WUFDUDs7OztzQkFDTix3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNJLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMscUJBQUQsRUFBcUIsU0FBUyxPQUFPLFNBQVc7Ozs7d0JBQ2hELHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUFoQjtnQkFBK0s7Z0JBQ25LO2dCQUFRO2VBQ2Q7Ozs7O3NCQUNMOzs7Ozt1QkFDSixPQUFPLGlCQUNKLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsT0FBRDtlQUNJLEtBQUssU0FBUyxPQUFPLGFBQWE7ZUFDbEMsS0FBSTtlQUNKLFdBQVU7ZUFDVixlQUFlLGlCQUFpQjtnQkFBRSxLQUFLLFNBQVMsT0FBTyxhQUFhO2dCQUFHLEtBQUs7ZUFBYyxDQUFDO2NBQzlGOzs7O3dCQUNELHdCQUFDLFVBQUQ7ZUFDSSxNQUFLO2VBQ0wsZUFBZSxpQkFBaUI7Z0JBQUUsS0FBSyxTQUFTLE9BQU8sYUFBYTtnQkFBRyxLQUFLO2VBQWMsQ0FBQztlQUMzRixXQUFVO3lCQUhkLENBS0ksd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozt5QkFBQyxXQUNuQjs7Ozs7c0JBQ1A7Ozs7O3FCQUVSOzs7OztvQkFDSjs7Ozs7cUJBR0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNJLHdCQUFDLE9BQUQ7Y0FBSyxXQUFXLG1GQUFtRixPQUFPO3dCQUExRyxDQUNLLE9BQU8sTUFDUix3QkFBQyxRQUFELFlBQU8sT0FBTyxNQUFZOzs7O3NCQUN6Qjs7Ozs7dUJBQ0wsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDSSx3QkFBQyxVQUFEO2VBQ0ksTUFBSztlQUNMLGVBQWUseUJBQXlCLG1CQUFtQixZQUFZLE9BQU8sWUFBWSxJQUFJO2VBQzlGLFdBQVcseUVBQ1AsaUJBQWlCLFFBQVEsT0FBTyxlQUFlLE9BQ3pDLHlDQUNBO2VBRVYsT0FBTTt5QkFDVDtjQUVPOzs7O3dCQUNSLHdCQUFDLFVBQUQ7ZUFDSSxNQUFLO2VBQ0wsZUFBZSx5QkFBeUIsbUJBQW1CLFlBQVksT0FBTyxZQUFZLEtBQUs7ZUFDL0YsV0FBVyx5RUFDUCxpQkFBaUIsUUFDWCxxQ0FDQTtlQUVWLE9BQU07eUJBQ1Q7Y0FFTzs7OztzQkFDUDs7Ozs7cUJBQ0o7Ozs7O3VCQUtILE9BQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxNQUN0QyxnREFDSywyQkFBMkIsT0FBTyxZQUFZLE9BQU8sTUFBTSxPQUFPLGNBQy9ELHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmO2NBQ0ksd0JBQUMsU0FBRDtlQUNJLE1BQUs7ZUFDTCxLQUFJO2VBQ0osS0FBSTtlQUNKLE1BQUs7ZUFDTDtlQUNBLE9BQU87ZUFDUCxXQUFVLE1BQUsscUJBQXFCLEVBQUUsT0FBTyxLQUFLO2VBQ2xELFlBQVcsTUFBSztnQkFDWixJQUFJLEVBQUUsUUFBUSxVQUFVLHlCQUF5QixJQUFJO2VBQ3pEO2VBQ0EsV0FBVTtlQUNWLGFBQVk7Y0FDZjs7Ozs7Y0FDRCx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBMkQ7Y0FBTzs7Ozs7Y0FDbEYsd0JBQUMsVUFBRDtlQUNJLE1BQUs7ZUFDTCxlQUFlLHlCQUF5QixJQUFJO2VBQzVDLFdBQVU7ZUFDVixPQUFNO3lCQUNUO2NBRU87Ozs7O2FBQ1A7Ozs7O3VCQUVMLHdCQUFDLFVBQUQ7YUFDSSxNQUFLO2FBQ0wsZUFBZTtjQUNYLE1BQU0sYUFBYSxPQUFPLGVBQWUsT0FDbkMsS0FBSyxNQUFPLE9BQU8sT0FBTyxXQUFXLElBQUksVUFBVyxHQUFHLElBQ3ZELGlCQUFpQixPQUFPLE1BQU0saUJBQWlCLFFBQVEsSUFBSTtjQUNqRSxxQkFBcUIsT0FBTyxVQUFVLENBQUM7Y0FDdkMseUJBQXlCLE9BQU8sWUFBWSxPQUFPLE1BQU0sT0FBTyxVQUFVO2FBQzlFO2FBQ0EsV0FBVyxxRkFDUCxPQUFPLGVBQWUsT0FDaEIsK0dBQ0E7YUFFVixPQUFNO3VCQUVMLE9BQU8sZUFBZSxPQUNqQixHQUFHLEtBQUssTUFBTyxPQUFPLE9BQU8sV0FBVyxJQUFJLFVBQVcsR0FBRyxFQUFFLGFBQzVEO1lBQ0Y7Ozs7c0JBSVgsd0JBQXdCLE9BQU8sWUFBWSxPQUFPLE1BQU0sT0FBTyxjQUM1RCx3QkFBQyxVQUFEO2FBQ0ksTUFBSzthQUNMLGVBQWU7Y0FDWCxNQUFNLFNBQVMsT0FBTyxZQUFZLE9BQU8sTUFBTSxPQUFPO2NBQ3RELHNCQUFzQixNQUFNO2NBQzVCLGtCQUFrQixPQUFPLGdCQUFnQixFQUFFO2NBQzNDLCtCQUNJLE9BQU8sc0JBQXNCLFlBQ3ZCLE9BQU8sb0JBQ1AsU0FDVjtjQUNBLElBQUksMEJBQTBCLFFBQVE7ZUFDbEMsTUFBTSxhQUFhLE9BQU8sZUFBZSxPQUNuQyxLQUFLLE1BQU8sT0FBTyxPQUFPLFdBQVcsSUFBSSxVQUFXLEdBQUcsSUFDdkQsaUJBQWlCLE9BQU8sTUFBTSxpQkFBaUIsUUFBUSxJQUFJO2VBQ2pFLHFCQUFxQixPQUFPLFVBQVUsQ0FBQztlQUN2Qyx5QkFBeUIsTUFBTTtjQUNuQzthQUNKO2FBQ0EsV0FBVTthQUNWLE9BQU07dUJBQ1Q7WUFFTzs7Ozt1QkFDUixJQUNOOzs7O29CQUVMOzs7OzttQkFDSjs7Ozs7O1dBR0gsT0FBTyxXQUFXLEtBQUssTUFBTSxXQUFXLE1BQ3RDLHdCQUF3QixPQUFPLFlBQVksT0FBTyxNQUFNLE9BQU8sZUFDM0Qsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDSSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNJLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQ1gsd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7Ozs7Y0FDdkI7Ozs7d0JBQ0wsd0JBQUMsS0FBRDtlQUFHLFdBQVU7eUJBQXdEO2NBRWxFOzs7O3NCQUNGOzs7Ozt1QkFDTCx3QkFBQyxVQUFEO2NBQ0ksTUFBSztjQUNMLGVBQWU7ZUFBRSxzQkFBc0IsSUFBSTtjQUFHO2NBQzlDLFdBQVU7d0JBRVYsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7YUFDVjs7OztxQkFDUDs7Ozs7O1lBR0wsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FFSSx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZjtlQUNJLHdCQUFDLFNBQUQ7Z0JBQU8sV0FBVTswQkFBakIsQ0FBaUksdUJBRTdILHdCQUFDLFFBQUQ7aUJBQU0sV0FBVTsyQkFBaEI7a0JBQW9FO2tCQUN4RDtrQkFBUTtpQkFDZDs7Ozs7d0JBQ0g7Ozs7OztlQUNQLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFBZixDQUNJLHdCQUFDLFNBQUQ7aUJBQ0ksTUFBSztpQkFDTCxLQUFJO2lCQUNKLEtBQUk7aUJBQ0osTUFBSztpQkFDTCxPQUFPO2lCQUNQLFdBQVUsTUFBSyxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7aUJBQ2xELFdBQVU7aUJBQ1YsYUFBWTtnQkFDZjs7OzswQkFDRCx3QkFBQyxRQUFEO2lCQUFNLFdBQVU7MkJBQXVFO2dCQUVqRjs7Ozt3QkFDTDs7Ozs7O2VBQ0wsd0JBQUMsS0FBRDtnQkFBRyxXQUFVOzBCQUFiO2lCQUEwRTtrQkFDdkIsS0FBTSxRQUFPLENBQUUsUUFBUSxDQUFDO2lCQUFFO2lCQUM3RDtpQkFBUTtnQkFDckI7Ozs7OztjQUNGOzs7Ozt1QkFHTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLFNBQUQ7ZUFBTyxXQUFVO3lCQUFnSDtjQUUxSDs7Ozt3QkFDUCx3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFBZjtnQkFDSSx3QkFBQyxTQUFEO2lCQUFPLFdBQVU7MkJBQWpCO2tCQUNJLHdCQUFDLFNBQUQ7bUJBQ0ksTUFBSzttQkFDTCxTQUFTLGdDQUFnQzttQkFDekMsV0FBVSxNQUFLO29CQUNYLCtCQUErQixFQUFFLE9BQU8sVUFBVSxPQUFRLGdDQUFnQyxPQUFPLFFBQVEsU0FBVTttQkFDdkg7bUJBQ0EsV0FBVTtrQkFDYjs7Ozs7a0JBQ0Qsd0JBQUMsT0FBRDttQkFBSyxXQUFVOzZCQUFmLENBQ0ksd0JBQUMsS0FBRDtvQkFBRyxXQUFVOzhCQUF1RDttQkFFakU7Ozs7NkJBQ0gsd0JBQUMsS0FBRDtvQkFBRyxXQUFVOzhCQUE2RDttQkFFdkU7Ozs7MkJBQ0Y7Ozs7OztrQkFDTCx3QkFBQyxRQUFEO21CQUFNLFdBQVcsbURBQ2IsZ0NBQWdDLE9BQzFCLDhCQUNBLGdDQUFnQyxRQUM1QiwwQkFDQTs2QkFFVCxnQ0FBZ0MsT0FBTyxVQUFVLGdDQUFnQyxRQUFRLFVBQVU7a0JBQ2xHOzs7OztpQkFDSDs7Ozs7O2dCQUNOLGdDQUFnQyxTQUM3Qix3QkFBQyxVQUFEO2lCQUNJLE1BQUs7aUJBQ0wsZUFBZSwrQkFBK0IsU0FBUztpQkFDdkQsV0FBVTsyQkFDYjtnQkFFTzs7Ozs7Z0JBRVgsZ0NBQWdDLFFBQzdCLHdCQUFDLFVBQUQ7aUJBQ0ksTUFBSztpQkFDTCxlQUFlLCtCQUErQixLQUFLO2lCQUNuRCxXQUFVOzJCQUNiO2dCQUVPOzs7OztlQUVYOzs7OztzQkFDSjs7Ozs7cUJBQ0o7Ozs7OztZQUdMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmO2NBQ0ksd0JBQUMsU0FBRDtlQUFPLFdBQVU7eUJBQWdIO2NBRTFIOzs7OztjQUNQLHdCQUFDLFlBQUQ7ZUFDSSxPQUFPO2VBQ1AsV0FBVSxNQUFLLGtCQUFrQixFQUFFLE9BQU8sS0FBSztlQUMvQyxNQUFNO2VBQ04sYUFBWTtlQUNaLFdBQVU7Y0FDYjs7Ozs7Y0FDRCx3QkFBQyxLQUFEO2VBQUcsV0FBVTt5QkFBNkQ7Y0FFdkU7Ozs7O2FBQ0Y7Ozs7OztZQUdKLE9BQU8sZ0JBQ0osd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDSSx3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFBeUY7YUFFbkc7Ozs7dUJBQ0gsd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQ1IsT0FBTzthQUNUOzs7O3FCQUNGOzs7Ozs7WUFJVCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNJLHdCQUFDLFVBQUQ7Y0FDSSxNQUFLO2NBQ0wsZUFBZTtlQUNYLHNCQUFzQixJQUFJO2VBQzFCLHlCQUF5QixJQUFJO2NBQ2pDO2NBQ0EsV0FBVTt3QkFDYjthQUVPOzs7O3VCQUNSLHdCQUFDLFVBQUQ7Y0FDSSxNQUFLO2NBQ0wsZUFBZSw2QkFDWCxtQkFBbUIsWUFDbkIsT0FBTyxZQUNQLE9BQU8sWUFBWSxPQUFPLElBQzFCLE9BQ0o7Y0FDQSxXQUFVO3dCQUNiO2FBRU87Ozs7cUJBQ1A7Ozs7OztXQUNKOzs7Ozs7VUFHYix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBeUY7V0FFbkc7Ozs7cUJBQ0gsd0JBQUMsT0FBRDtZQUFLLFdBQVcscUNBQ1osaUJBQWlCLE9BQ1gsMkhBQ0EsaUJBQWlCLFFBQ2pCLG1HQUNBO3NCQUVMLE9BQU8sY0FBYyxPQUFPLGVBQWUsT0FBTyxhQUMvQyx3QkFBQyxxQkFBRCxFQUFxQixTQUFTLE9BQU8sY0FBYyxPQUFPLGVBQWUsT0FBTyxXQUFhOzs7O3VCQUU3Rix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBNEM7WUFBdUI7Ozs7O1dBRXRGOzs7O21CQUNKOzs7O3FCQUVKLGFBQ0csd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUF5RjtXQUVuRzs7OztxQkFDSCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDWCx3QkFBQyxxQkFBRCxFQUFxQixTQUFTLFVBQVk7Ozs7O1dBQ3pDOzs7O21CQUNKOzs7O21CQUdSOzs7Ozs7U0FDSjtXQWpXSSxPQUFPLGNBQWM7Ozs7ZUFpV3pCO09BRWIsQ0FBQyxJQUVDLENBQUMsbUJBQW1CLFdBQVcsbUJBQW1CLFFBQVEsV0FBVyxNQUNuRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBK0Q7T0FFekU7Ozs7ZUFFUjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDSSx3QkFBQyxVQUFEO1NBQ0ksU0FBUztTQUNULFVBQVUsZ0JBQWdCO1NBQzFCLFdBQVU7bUJBSGQsQ0FLSSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7O21CQUFDLGFBQ3JCOzs7Ozs7UUFFUix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEI7VUFDSyxlQUFlO1VBQUU7VUFBTyxnQkFBZ0I7U0FDdkM7Ozs7OztRQUVOLHdCQUFDLFVBQUQ7U0FDSSxTQUFTO1NBQ1QsVUFBVSxpQkFBaUIsZ0JBQWdCLFNBQVM7U0FDcEQsV0FBVTttQkFIZCxDQUlDLGdCQUNlLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7aUJBQ2pDOzs7Ozs7T0FDUDs7Ozs7O0tBRUo7Ozs7O1lBQ0o7Ozs7OztHQUlSLHlCQUF5QixvQkFDdEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWdELGVBQWUseUJBQXlCLEtBQUs7SUFBSTs7OztjQUNoSCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BR0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNRLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNmLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O1FBQ3hCOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBd0Q7UUFBbUM7Ozs7a0JBQ3pHLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQStELGlCQUFpQixpQkFBaUIsUUFBTyx3QkFBeUI7Ozs7O2dCQUNoSTs7OztnQkFDSjs7Ozs7aUJBQ0wsd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxlQUFlLHlCQUF5QixLQUFLO1FBQUcsV0FBVTtrQkFDNUUsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7T0FDVjs7OztlQUNQOzs7Ozs7T0FHSCxpQkFBaUIsYUFBYSxpQkFBaUIsa0JBQWtCLFNBQy9ELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ssaUJBQWlCLGFBQ2Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQ0ksd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQVk7U0FBUzs7Ozs7U0FBQztTQUFFLGlCQUFpQjtRQUN2RDs7Ozs7aUJBRVQsaUJBQWlCLGtCQUFrQixRQUNoQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FBc0U7U0FDNUMsaUJBQWlCO1NBQWM7UUFDbkQ7Ozs7O2VBRVQ7Ozs7OztNQUlULHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNWLGlCQUFpQixpQkFBaUIsS0FBSyxFQUFFLFFBQVEsY0FBYyxNQUM1RCx3QkFBQyxPQUFEO1FBQWEsV0FBVTtrQkFBdkI7U0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3NCQUNQLE9BQU8sWUFBWSxHQUFFLENBQUUsUUFBUSxZQUFZLEVBQUUsQ0FBQyxDQUFDLFVBQVUsR0FBRyxHQUFHO1VBQ2xFOzs7O29CQUNILHdCQUFDLFFBQUQ7V0FBTSxXQUFXLDREQUE0RCxXQUFXLFlBQVksaUZBQWlGO3FCQUFyTCxDQUNLLFdBQVcsT0FBTSxHQUNoQjs7Ozs7a0JBQ0w7Ozs7OztTQUNMLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiO1dBQXFFO1dBQUUsV0FBVztXQUFPO1VBQUk7Ozs7OztTQUM3Rix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUFnRSxhQUNuRCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtzQkFBb0QsT0FBTyxjQUFjLE9BQU8sZUFBZSxXQUFVLENBQUcsVUFBVSxHQUFHLEVBQUU7VUFBUTs7OztrQkFDM0o7Ozs7OztRQUNKO1VBYks7Ozs7Y0FhTCxDQUNSO01BQ0E7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLGVBQWUseUJBQXlCLEtBQUs7UUFBRyxXQUFVO2tCQUFtTDtPQUUzUDs7OztpQkFDUix3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFNBQVM7UUFBd0IsV0FBVTtrQkFBakU7U0FDSSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OztTQUFDO1NBQ0QsaUJBQWlCLGlCQUFpQjtTQUFPO1FBQzlEOzs7OztlQUNQOzs7Ozs7S0FDSjs7Ozs7WUFDSjs7Ozs7O0dBSVIsaUJBQ0csd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLE9BQUQ7S0FDSSxXQUFVO0tBQ1YsZUFBZSxpQkFBaUIsS0FBSztJQUN4Qzs7OztjQUVELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFHSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1gsd0JBQUMsU0FBRCxFQUFTLE1BQU0sR0FBSzs7Ozs7UUFDbkI7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF3RDtRQUVsRTs7OztrQkFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBaUQ7UUFFM0Q7Ozs7Z0JBQ0Y7Ozs7Z0JBQ0o7Ozs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsZUFBZSxpQkFBaUIsS0FBSztRQUNyQyxXQUFVO2tCQUVWLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O09BQ1Y7Ozs7ZUFDUDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFHSSx3QkFBQyxPQUFEO1NBQ0ksd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWtFO1NBRTVFOzs7OztTQUNQLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0ksd0JBQUMsVUFBRDtZQUNJLE1BQUs7WUFDTCxlQUFlLGNBQWMsS0FBSztZQUNsQyxXQUFXLHVGQUNQLGVBQWUsUUFDVCxpR0FDQTtzQkFFYjtXQUVPOzs7OztXQUNSLHdCQUFDLFVBQUQ7WUFDSSxNQUFLO1lBQ0wsZUFBZSxjQUFjLE9BQU87WUFDcEMsV0FBVyx1RkFDUCxlQUFlLFVBQ1QsaUdBQ0E7c0JBRWI7V0FFTzs7Ozs7V0FDUix3QkFBQyxVQUFEO1lBQ0ksTUFBSztZQUNMLGVBQWUsY0FBYyxPQUFPO1lBQ3BDLFdBQVcsdUZBQ1AsZUFBZSxVQUNULGlHQUNBO3NCQUViO1dBRU87Ozs7O1VBQ1A7Ozs7OztTQUVKLGVBQWUsV0FDWix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFpRDtVQUFzRDs7OztvQkFDdkgsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxTQUFEO1lBQ0ksTUFBSztZQUNMLEtBQUk7WUFDSixLQUFJO1lBQ0osT0FBTztZQUNQLFdBQVUsTUFBSyxtQkFBbUIsV0FBVyxFQUFFLE9BQU8sS0FBSyxLQUFLLENBQUM7WUFDakUsV0FBVTtXQUNiOzs7O3FCQUNELHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUEyQjtXQUFPOzs7O21CQUNqRDs7Ozs7a0JBQ0o7Ozs7OztTQUdSLGVBQWUsV0FDWix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFpRDtVQUFvRDs7OztvQkFDckgsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDSSx3QkFBQyxTQUFEO2FBQ0ksTUFBSzthQUNMLEtBQUk7YUFDSixLQUFJO2FBQ0osT0FBTzthQUNQLFdBQVUsTUFBSyxrQkFBa0IsV0FBVyxFQUFFLE9BQU8sS0FBSyxLQUFLLENBQUM7YUFDaEUsV0FBVTtZQUNiOzs7OztZQUNELHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFpQjtZQUFTOzs7OztZQUMxQyx3QkFBQyxTQUFEO2FBQ0ksTUFBSzthQUNMLEtBQUk7YUFDSixLQUFJO2FBQ0osT0FBTzthQUNQLFdBQVUsTUFBSyxrQkFBa0IsV0FBVyxFQUFFLE9BQU8sS0FBSyxLQUFLLENBQUM7YUFDaEUsV0FBVTtZQUNiOzs7OztZQUNELHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUEyQjtZQUFPOzs7OztXQUNqRDs7Ozs7a0JBQ0o7Ozs7OztRQUVSOzs7OztRQUdMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBa0U7UUFFNUU7Ozs7a0JBQ1Asd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDSSx3QkFBQyxTQUFEO1dBQU8sV0FBVywrRUFDZCxhQUFhLFFBQ1AsdURBQ0E7cUJBSFYsQ0FLSSx3QkFBQyxTQUFEO1lBQ0ksTUFBSztZQUNMLE1BQUs7WUFDTCxPQUFNO1lBQ04sU0FBUyxhQUFhO1lBQ3RCLGdCQUFnQjthQUFFLFlBQVksS0FBSzthQUFHLGFBQWEsRUFBRTtZQUFHO1lBQ3hELFdBQVU7V0FDYjs7OztxQkFDRCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUEyQztZQUFpQzs7OztzQkFDekYsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQXFDO1lBQTJHOzs7O29CQUM1Sjs7Ozs7bUJBQ0Y7Ozs7OztVQUVQLHdCQUFDLFNBQUQ7V0FBTyxXQUFXLCtFQUNkLGFBQWEsVUFDUCx1REFDQTtxQkFIVixDQUtJLHdCQUFDLFNBQUQ7WUFDSSxNQUFLO1lBQ0wsTUFBSztZQUNMLE9BQU07WUFDTixTQUFTLGFBQWE7WUFDdEIsZ0JBQWdCO2FBQUUsWUFBWSxPQUFPO2FBQUcsYUFBYSxFQUFFO1lBQUc7WUFDMUQsV0FBVTtXQUNiOzs7O3FCQUNELHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0ksd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTJDO1lBQThCOzs7O3NCQUN0Rix3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBcUM7WUFBa0Y7Ozs7b0JBQ25JOzs7OzttQkFDRjs7Ozs7O1VBRVAsd0JBQUMsU0FBRDtXQUFPLFdBQVcsK0VBQ2QsYUFBYSxVQUNQLHVEQUNBO3FCQUhWLENBS0ksd0JBQUMsU0FBRDtZQUNJLE1BQUs7WUFDTCxNQUFLO1lBQ0wsT0FBTTtZQUNOLFNBQVMsYUFBYTtZQUN0QixnQkFBZ0I7YUFBRSxZQUFZLE9BQU87YUFBRyxhQUFhLEdBQUc7WUFBRztZQUMzRCxXQUFVO1dBQ2I7Ozs7cUJBQ0Qsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBMkM7WUFBdUM7Ozs7c0JBQy9GLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFxQztZQUFpRjs7OztvQkFDbEk7Ozs7O21CQUNGOzs7Ozs7VUFFUCx3QkFBQyxTQUFEO1dBQU8sV0FBVywrRUFDZCxhQUFhLGNBQ1AsdURBQ0E7cUJBSFYsQ0FLSSx3QkFBQyxTQUFEO1lBQ0ksTUFBSztZQUNMLE1BQUs7WUFDTCxPQUFNO1lBQ04sU0FBUyxhQUFhO1lBQ3RCLGdCQUFnQjthQUFFLFlBQVksV0FBVzthQUFHLGFBQWEsRUFBRTtZQUFHO1lBQzlELFdBQVU7V0FDYjs7OztxQkFDRCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUEyQztZQUFzQzs7OztzQkFDOUYsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQXFDO1lBQWtGOzs7O29CQUNuSTs7Ozs7bUJBQ0Y7Ozs7OztTQUNOOzs7OztnQkFDSjs7Ozs7UUFHTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQ1osYUFBYSxRQUFRLGdDQUFnQyxhQUFhLFVBQVUsb0NBQW9DLGFBQWEsVUFBVSxpQ0FBaUM7UUFDdEs7Ozs7a0JBQ1Asd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxTQUFEO1VBQ0ksTUFBSztVQUNMLE1BQU0sYUFBYSxVQUFVLE1BQU07VUFDbkMsS0FBSTtVQUNKLEtBQUssYUFBYSxVQUFVLFFBQVE7VUFDcEMsT0FBTztVQUNQLFdBQVUsTUFBSyxhQUFhLFdBQVcsRUFBRSxPQUFPLEtBQUssS0FBSyxDQUFDO1VBQzNELFdBQVU7U0FDYjs7OzttQkFDRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDWCxhQUFhLFVBQVUsTUFBTTtTQUM1Qjs7OztpQkFDTDs7Ozs7Z0JBQ0o7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUF1RDtVQUVqRTs7OztvQkFDUCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFDSyxtQkFBbUIsUUFBTyxNQUFLLEVBQUUsZUFBZSxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFBTztZQUFPLG1CQUFtQjtZQUFPO1dBQ3JHOzs7OztrQkFDTDs7Ozs7bUJBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1gsd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0ksd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQ2Isd0JBQUMsTUFBRDthQUNJLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUFZO2FBQWE7Ozs7O2FBQ3ZDLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUF3QjthQUFpQjs7Ozs7YUFDdkQsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQXdCO2FBQWE7Ozs7O2FBQ25ELHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUF1QjthQUFhOzs7OztZQUNsRDs7Ozs7V0FDRDs7OztxQkFDUCx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFDWixtQkFBbUIsS0FBSyxNQUFNLFFBQzNCLHdCQUFDLE1BQUQ7YUFBaUMsV0FBVTt1QkFBM0M7Y0FDSSx3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFDVCxLQUFLLGtCQUFrQjtjQUN4Qjs7Ozs7Y0FDSix3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFBZCxDQUNLLEtBQUssY0FBYSxHQUNuQjs7Ozs7O2NBQ0osd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQWQsQ0FDSyxLQUFLLGdCQUFlLEdBQ3JCOzs7Ozs7Y0FDSix3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFDVCxLQUFLLE9BQU8sSUFDVCx3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQWhCO2lCQUF3RTtpQkFBRSxLQUFLO2lCQUFLO2dCQUFPOzs7OzswQkFDM0YsS0FBSyxPQUFPLElBQ1osd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUFoQixDQUFpRSxLQUFLLE1BQUssR0FBTzs7Ozs7MEJBRWxGLHdCQUFDLFFBQUQ7Z0JBQU0sV0FBVTswQkFBNkI7ZUFBVzs7Ozs7Y0FFNUQ7Ozs7O2FBQ0o7ZUFuQkssS0FBSyxjQUFjOzs7O21CQW1CeEIsQ0FDUDtXQUNFOzs7O21CQUNKOzs7Ozs7U0FDTjs7OztpQkFDSjs7Ozs7O09BRUo7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsVUFBRDtRQUNJLE1BQUs7UUFDTCxTQUFTO1FBQ1QsV0FBVTtRQUNWLE9BQU07a0JBSlYsQ0FNSSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O2tCQUFDLGNBQ25COzs7OztpQkFFUix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLFVBQUQ7U0FDSSxNQUFLO1NBQ0wsZUFBZSxpQkFBaUIsS0FBSztTQUNyQyxXQUFVO21CQUNiO1FBRU87Ozs7a0JBQ1Isd0JBQUMsVUFBRDtTQUNJLE1BQUs7U0FDTCxTQUFTO1NBQ1QsV0FBVTttQkFDYjtRQUVPOzs7O2dCQUNQOzs7OztlQUNKOzs7Ozs7S0FFSjs7Ozs7WUFDSjs7Ozs7O0dBSVQsd0JBQUMsY0FBRDtJQUNJLFFBQVEsYUFBYTtJQUNyQixlQUFlLENBQUMsYUFBYSxXQUFXLGlCQUFnQixVQUFTO0tBQUUsR0FBRztLQUFNLFFBQVE7SUFBTSxFQUFFO0lBQzVGLFdBQVc7SUFDWCxXQUFXLGFBQWE7SUFDeEIsU0FBUyxhQUFhLFNBQVMsaUJBQWlCLFlBQVk7SUFDNUQsT0FBTyxhQUFhLFNBQVMsaUJBQWlCLGlDQUFpQztJQUMvRSxTQUNJLGFBQWEsU0FBUyxpQkFDaEIseUVBQXlFLGFBQWEsZUFBZSxzR0FDckcsc0VBQXNFLGFBQWEsZUFBZTtJQUU1RyxhQUFhLGFBQWEsU0FBUyxpQkFBaUIseUJBQXlCO0lBQzdFLFlBQVc7R0FDZDs7Ozs7R0FHRCx3QkFBQyxvQkFBRDtJQUNJLFFBQVEsQ0FBQyxDQUFDO0lBQ1YsS0FBSyxlQUFlO0lBQ3BCLEtBQUssZUFBZTtJQUNwQixlQUFlLGlCQUFpQixJQUFJO0dBQ3ZDOzs7OztFQUNBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJGb3JtUmVzcG9uc2VzUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2ssIHVzZU1lbW8sIEZyYWdtZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgXG4gICAgQXJyb3dMZWZ0LCBEb3dubG9hZCwgRXllLCBYLCBCYXJDaGFydDIsIExvYWRlcjIsIFxuICAgIE1lc3NhZ2VTcXVhcmUsIEFsZXJ0VHJpYW5nbGUsIENoZWNrQ2lyY2xlMiwgWENpcmNsZSwgXG4gICAgTWludXNDaXJjbGUsIENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQsIFRyZW5kaW5nVXAsIENhbGVuZGFyLCBNYXhpbWl6ZTIsXG4gICAgU2xpZGVycywgRWRpdDIsIFJvdGF0ZUNjdywgQ2hlY2ssIFNhdmUsXG4gICAgU2hpZWxkQWxlcnQsIFNoaWVsZENoZWNrLCBBY3Rpdml0eSwgUmFkaW8sIFJlZnJlc2hDdywgQ2hldnJvbkRvd24sIENoZXZyb25VcCxcbiAgICBTZWFyY2gsIEZpbHRlciwgQWxlcnRDaXJjbGUsIEFycm93UmlnaHQgYXMgQXJyb3dSaWdodEljb24sIFNoYXJlMlxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IFNpZGViYXIgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9sYXlvdXQvU2lkZWJhcic7XG5pbXBvcnQgQ29uZmlybU1vZGFsIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdWkvQ29uZmlybU1vZGFsJztcbmltcG9ydCB7XG4gICAgZ2V0Rm9ybUJ5SWQsIGdldEZvcm1SZXNwb25zZXMsIGdldEZvcm1BbmFseXRpY3MsXG4gICAgZ2V0UmVzcG9uc2VSZXN1bHQsIGdldFF1ZXN0aW9ucywgZ2V0UmVzcG9uc2VEZXRhaWwsIGdldFJlc3BvbnNlQXR0ZW1wdHMsXG4gICAgdXBkYXRlUmVzcG9uc2VTdGF0dXMsIGNsZWFyU2Vzc2lvbiwgZXhwb3J0Rm9ybVJlc3BvbnNlcywgZ2V0Rm9ybUZlZWRiYWNrcywgYXNzZXRVcmwsXG4gICAgb3ZlcnJpZGVBbnN3ZXJTY29yZSwgYnVsa092ZXJyaWRlQW5zd2VyU2NvcmVzLCBnZXRFeGFtTW9uaXRvcmluZyxcbiAgICBmb3JjZVN1Ym1pdEV4YW1TZXNzaW9uLCByZXNldEV4YW1TZXNzaW9uLCByZXNvbHZlQW5zd2VyS2V5LCBSZXNvbHZlQW5zd2VyS2V5LCBFeGFtUHJvY3RvckFjdGlvbnMsXG4gICAgc3RyaXBNYXRoTm90YXRpb25cbn0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyBnZXRHZW1pbmlBcGlLZXksIHNjb3JlSG9saXN0aWNFc3NheVdpdGhBSSwgQVZBSUxBQkxFX01PREVMUyB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FpU2VydmljZSc7XG5pbXBvcnQgUmljaENvbnRlbnRSZW5kZXJlciBmcm9tICcuLi8uLi91dGlscy9SaWNoQ29udGVudFJlbmRlcmVyJztcbmltcG9ydCBJbWFnZUxpZ2h0Ym94TW9kYWwgZnJvbSAnLi4vLi4vY29tcG9uZW50cy91aS9JbWFnZUxpZ2h0Ym94TW9kYWwnO1xuXG5jb25zdCBTVEFUVVNfT1BUSU9OUyA9IFtcbiAgICB7IGlkOiAxLCBsYWJlbDogJ0JhcnUnLCBjb2RlOiAnbmV3JyB9LFxuICAgIHsgaWQ6IDIsIGxhYmVsOiAnRGl0aW5qYXUnLCBjb2RlOiAncmV2aWV3ZWQnIH0sXG4gICAgeyBpZDogMywgbGFiZWw6ICdEaXRlcmltYScsIGNvZGU6ICdhY2NlcHRlZCcgfSxcbiAgICB7IGlkOiA0LCBsYWJlbDogJ0RpdG9sYWsnLCBjb2RlOiAncmVqZWN0ZWQnIH0sXG5dO1xuXG5jb25zdCBQQUdFX1NJWkUgPSAyNTtcblxuZXhwb3J0IHsgcmVzb2x2ZUFuc3dlcktleSwgUmVzb2x2ZUFuc3dlcktleSB9O1xuZXhwb3J0IGNvbnN0IHJlc29sdmVRdWVzdGlvbktleSA9IChxRGVmKSA9PiByZXNvbHZlQW5zd2VyS2V5KHFEZWYpO1xuXG5leHBvcnQgY29uc3QgcmVzb2x2ZUJhc2VJc0NvcnJlY3QgPSAoYW5zd2VyLCBxRGVmKSA9PiB7XG4gICAgaWYgKCFxRGVmKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBhVGV4dCA9IFN0cmluZyhhbnN3ZXI/LmFuc3dlclRleHQgfHwgYW5zd2VyPy5hbnN3ZXJWYWx1ZSB8fCBhbnN3ZXI/Lm9wdGlvblRleHQgfHwgJycpLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgIFxuICAgIGlmIChxRGVmLnR5cGVJZCA9PT0gMiB8fCBxRGVmLnR5cGVJZCA9PT0gNSkge1xuICAgICAgICBjb25zdCBjb3JyZWN0T3B0ID0gKHFEZWYub3B0aW9ucyB8fCBbXSkuZmluZChvID0+IG8uaXNDb3JyZWN0ID09PSB0cnVlKTtcbiAgICAgICAgaWYgKCFjb3JyZWN0T3B0KSByZXR1cm4gbnVsbDtcbiAgICAgICAgaWYgKGFuc3dlcj8ub3B0aW9uSWQgJiYgY29ycmVjdE9wdC5pZCkge1xuICAgICAgICAgICAgcmV0dXJuIE51bWJlcihhbnN3ZXIub3B0aW9uSWQpID09PSBOdW1iZXIoY29ycmVjdE9wdC5pZCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFhVGV4dCkgcmV0dXJuIGZhbHNlO1xuICAgICAgICByZXR1cm4gYVRleHQgPT09IFN0cmluZyhjb3JyZWN0T3B0Lm9wdGlvblRleHQgfHwgJycpLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgIH1cbiAgICBcbiAgICBpZiAocURlZi50eXBlSWQgPT09IDMpIHtcbiAgICAgICAgY29uc3QgY29ycmVjdE9wdHMgPSAocURlZi5vcHRpb25zIHx8IFtdKS5maWx0ZXIobyA9PiBvLmlzQ29ycmVjdCA9PT0gdHJ1ZSk7XG4gICAgICAgIGlmIChjb3JyZWN0T3B0cy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShhbnN3ZXI/LnNlbGVjdGVkT3B0aW9ucykgJiYgYW5zd2VyLnNlbGVjdGVkT3B0aW9ucy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBzZWxlY3RlZCA9IGFuc3dlci5zZWxlY3RlZE9wdGlvbnMubWFwKHMgPT4gU3RyaW5nKHMpLnRyaW0oKS50b0xvd2VyQ2FzZSgpKS5zb3J0KCk7XG4gICAgICAgICAgICBjb25zdCBjb3JyZWN0ID0gY29ycmVjdE9wdHMubWFwKGMgPT4gU3RyaW5nKGMub3B0aW9uVGV4dCkudHJpbSgpLnRvTG93ZXJDYXNlKCkpLnNvcnQoKTtcbiAgICAgICAgICAgIGlmIChzZWxlY3RlZC5sZW5ndGggIT09IGNvcnJlY3QubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICByZXR1cm4gc2VsZWN0ZWQuZXZlcnkoKHZhbCwgaWR4KSA9PiB2YWwgPT09IGNvcnJlY3RbaWR4XSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFhVGV4dCkgcmV0dXJuIGZhbHNlO1xuICAgICAgICBjb25zdCBjb3JyZWN0VGV4dCA9IGNvcnJlY3RPcHRzLm1hcChjID0+IFN0cmluZyhjLm9wdGlvblRleHQpLnRyaW0oKS50b0xvd2VyQ2FzZSgpKS5zb3J0KCkuam9pbignLCAnKTtcbiAgICAgICAgcmV0dXJuIGFUZXh0ID09PSBjb3JyZWN0VGV4dDtcbiAgICB9XG4gICAgXG4gICAgaWYgKHFEZWYuY29ycmVjdEFuc3dlciAmJiBxRGVmLmNvcnJlY3RBbnN3ZXIudHJpbSgpKSB7XG4gICAgICAgIGlmICghYVRleHQpIHJldHVybiBmYWxzZTtcbiAgICAgICAgcmV0dXJuIGFUZXh0ID09PSBTdHJpbmcocURlZi5jb3JyZWN0QW5zd2VyKS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIG51bGw7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0RWZmZWN0aXZlSXNDb3JyZWN0ID0gKGFuc3dlciwgcURlZikgPT4ge1xuICAgIGlmICghYW5zd2VyKSByZXR1cm4gbnVsbDtcbiAgICBpZiAoYW5zd2VyLmlzQ29ycmVjdE92ZXJyaWRlICE9PSBudWxsICYmIGFuc3dlci5pc0NvcnJlY3RPdmVycmlkZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiAhIWFuc3dlci5pc0NvcnJlY3RPdmVycmlkZTtcbiAgICB9XG4gICAgaWYgKGFuc3dlci5pc0NvcnJlY3QgIT09IG51bGwgJiYgYW5zd2VyLmlzQ29ycmVjdCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiAhIWFuc3dlci5pc0NvcnJlY3Q7XG4gICAgfVxuICAgIGlmIChxRGVmKSB7XG4gICAgICAgIGNvbnN0IGJhc2UgPSByZXNvbHZlQmFzZUlzQ29ycmVjdChhbnN3ZXIsIHFEZWYpO1xuICAgICAgICBpZiAoYmFzZSAhPT0gbnVsbCkgcmV0dXJuIGJhc2U7XG4gICAgfVxuICAgIGlmIChhbnN3ZXIuY29ycmVjdEFuc3dlciAmJiAoYW5zd2VyLmFuc3dlclRleHQgfHwgYW5zd2VyLmFuc3dlclZhbHVlIHx8IGFuc3dlci5vcHRpb25UZXh0KSkge1xuICAgICAgICBjb25zdCBhVGV4dCA9IFN0cmluZyhhbnN3ZXIuYW5zd2VyVGV4dCB8fCBhbnN3ZXIuYW5zd2VyVmFsdWUgfHwgYW5zd2VyLm9wdGlvblRleHQgfHwgJycpLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBjb25zdCBjVGV4dCA9IFN0cmluZyhhbnN3ZXIuY29ycmVjdEFuc3dlcikudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGlmIChhVGV4dCAmJiBjVGV4dCkgcmV0dXJuIGFUZXh0ID09PSBjVGV4dDtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59O1xuXG5leHBvcnQgY29uc3QgY2FsY3VsYXRlVG90YWxTY29yZSA9IChhbnN3ZXJzLCBxdWVzdGlvbnMpID0+IHtcbiAgICBjb25zdCBxTGlzdCA9IEFycmF5LmlzQXJyYXkocXVlc3Rpb25zKSAmJiBxdWVzdGlvbnMubGVuZ3RoID4gMCA/IHF1ZXN0aW9ucyA6IFtdO1xuICAgIGlmIChxTGlzdC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc3QgdG90YWwgPSBhbnN3ZXJzPy5sZW5ndGggfHwgMTtcbiAgICAgICAgY29uc3QgY29ycmVjdCA9IChhbnN3ZXJzIHx8IFtdKS5maWx0ZXIoYSA9PiBnZXRFZmZlY3RpdmVJc0NvcnJlY3QoYSkgPT09IHRydWUpLmxlbmd0aDtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNjb3JlOiBNYXRoLnJvdW5kKChjb3JyZWN0IC8gdG90YWwpICogMTAwICogMTApIC8gMTAsXG4gICAgICAgICAgICBjb3JyZWN0Q291bnQ6IGNvcnJlY3QsXG4gICAgICAgICAgICB3cm9uZ0NvdW50OiBNYXRoLm1heCgwLCB0b3RhbCAtIGNvcnJlY3QpLFxuICAgICAgICAgICAgdG90YWxRdWVzdGlvbnM6IHRvdGFsLFxuICAgICAgICAgICAgdG90YWxQb2ludHM6IHRvdGFsLFxuICAgICAgICAgICAgZWFybmVkUG9pbnRzOiBjb3JyZWN0LFxuICAgICAgICB9O1xuICAgIH1cblxuICAgIGxldCB0b3RhbFBvaW50cyA9IDA7XG4gICAgbGV0IGVhcm5lZFBvaW50cyA9IDA7XG4gICAgbGV0IGNvcnJlY3RDb3VudCA9IDA7XG4gICAgbGV0IHdyb25nQ291bnQgPSAwO1xuXG4gICAgcUxpc3QuZm9yRWFjaChxID0+IHtcbiAgICAgICAgY29uc3QgcVBvaW50cyA9IE51bWJlcihxLnBvaW50cykgPiAwID8gTnVtYmVyKHEucG9pbnRzKSA6IDE7XG4gICAgICAgIHRvdGFsUG9pbnRzICs9IHFQb2ludHM7XG5cbiAgICAgICAgY29uc3QgYW5zID0gKGFuc3dlcnMgfHwgW10pLmZpbmQoYSA9PiBOdW1iZXIoYS5xdWVzdGlvbklkKSA9PT0gTnVtYmVyKHEuaWQpKTtcblxuICAgICAgICAvLyBCVUctMyBGSVg6IGhvbm91ciBwYXJ0aWFsIChmcmFjdGlvbmFsKSBlYXJuZWQgcG9pbnRzIHdoZW4gdGhlIG93bmVyIGhhc1xuICAgICAgICAvLyBzZXQgYSBtYW51YWxTY29yZSBvdmVycmlkZSAoZS5nLiA5MCUgb2YgYW4gZXNzYXkpLiBtYW51YWxTY29yZSBpcyByYXdcbiAgICAgICAgLy8gZWFybmVkIHBvaW50cyAoc2FtZSB1bml0IGFzIHFQb2ludHMpLCBOT1QgYSBwZXJjZW50YWdlLlxuICAgICAgICBpZiAoYW5zICYmIGFucy5tYW51YWxTY29yZSAhPSBudWxsICYmIGFucy5tYW51YWxTY29yZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBjb25zdCByYXcgPSBOdW1iZXIoYW5zLm1hbnVhbFNjb3JlKTtcbiAgICAgICAgICAgIGlmICghaXNOYU4ocmF3KSAmJiByYXcgPj0gMCkge1xuICAgICAgICAgICAgICAgIGVhcm5lZFBvaW50cyArPSBNYXRoLm1pbihyYXcsIHFQb2ludHMpO1xuICAgICAgICAgICAgICAgIC8vIENvdW50IGFzIGNvcnJlY3Qgb25seSBpZiB0aGV5IGVhcm5lZCA+IDAgKHNvIHN0YXR1cyBiYWRnZSBzaG93cyBzb21ldGhpbmcgc2Vuc2libGUpXG4gICAgICAgICAgICAgICAgaWYgKHJhdyA+IDApIGNvcnJlY3RDb3VudCsrO1xuICAgICAgICAgICAgICAgIGVsc2Ugd3JvbmdDb3VudCsrO1xuICAgICAgICAgICAgICAgIHJldHVybjsgLy8gaGFuZGxlZCDigJQgc2tpcCB0aGUgYm9vbGVhbiBicmFuY2ggYmVsb3dcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGVmZmVjdGl2ZSA9IGdldEVmZmVjdGl2ZUlzQ29ycmVjdChhbnMsIHEpO1xuICAgICAgICBpZiAoZWZmZWN0aXZlID09PSB0cnVlKSB7XG4gICAgICAgICAgICBlYXJuZWRQb2ludHMgKz0gcVBvaW50cztcbiAgICAgICAgICAgIGNvcnJlY3RDb3VudCsrO1xuICAgICAgICB9IGVsc2UgaWYgKGVmZmVjdGl2ZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgIHdyb25nQ291bnQrKztcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgY29uc3Qgc2NvcmUgPSB0b3RhbFBvaW50cyA+IDAgPyBNYXRoLnJvdW5kKChlYXJuZWRQb2ludHMgLyB0b3RhbFBvaW50cykgKiAxMDAgKiAxMCkgLyAxMCA6IDA7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgc2NvcmUsXG4gICAgICAgIGNvcnJlY3RDb3VudCxcbiAgICAgICAgd3JvbmdDb3VudCxcbiAgICAgICAgdG90YWxRdWVzdGlvbnM6IHFMaXN0Lmxlbmd0aCxcbiAgICAgICAgdG90YWxQb2ludHMsXG4gICAgICAgIGVhcm5lZFBvaW50cyxcbiAgICB9O1xufTtcblxuY29uc3QgZ2V0TG9jYWxNYW51YWxPdmVycmlkZXMgPSAoZm9ybUlkKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmF3ID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oYGZvcm11cF9vdmVycmlkZXNfJHtmb3JtSWR9YCk7XG4gICAgICAgIHJldHVybiByYXcgPyBKU09OLnBhcnNlKHJhdykgOiB7fTtcbiAgICB9IGNhdGNoIHtcbiAgICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbn07XG5cbmNvbnN0IHNhdmVMb2NhbE1hbnVhbE92ZXJyaWRlID0gKGZvcm1JZCwgcmVzcG9uc2VJZCwgcXVlc3Rpb25JZCwgaXNDb3JyZWN0KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY3VyID0gZ2V0TG9jYWxNYW51YWxPdmVycmlkZXMoZm9ybUlkKTtcbiAgICAgICAgaWYgKCFjdXJbcmVzcG9uc2VJZF0pIGN1cltyZXNwb25zZUlkXSA9IHt9O1xuICAgICAgICBjdXJbcmVzcG9uc2VJZF1bcXVlc3Rpb25JZF0gPSBpc0NvcnJlY3Q7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGBmb3JtdXBfb3ZlcnJpZGVzXyR7Zm9ybUlkfWAsIEpTT04uc3RyaW5naWZ5KGN1cikpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS53YXJuKCdGYWlsZWQgdG8gc2F2ZSBtYW51YWwgb3ZlcnJpZGUgbG9jYWxseScsIGUpO1xuICAgIH1cbn07XG5cbmNvbnN0IGlzUHJvY3RvckFjdGlvblR5cGUgPSAodHlwZSkgPT5cbiAgICAodHlwZSB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gRXhhbVByb2N0b3JBY3Rpb25zLkZvcmNlU3VibWl0QnlQcm9jdG9yLnRvTG93ZXJDYXNlKCk7XG5cbmNvbnN0IGdldEdlbnVpbmVWaW9sYXRpb25Db3VudCA9IChzZXNzaW9uKSA9PlxuICAgIChzZXNzaW9uPy52aW9sYXRpb25zIHx8IFtdKS5maWx0ZXIodiA9PiAhaXNQcm9jdG9yQWN0aW9uVHlwZSh2LnR5cGUpKS5sZW5ndGg7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZvcm1SZXNwb25zZXNQYWdlKCkge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtcygpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICAgIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZSgncmVzcG9uc2VzJyk7XG5cbiAgICBjb25zdCBbZm9ybSwgc2V0Rm9ybV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbZm9ybVF1ZXN0aW9ucywgc2V0Rm9ybVF1ZXN0aW9uc10gPSB1c2VTdGF0ZShbXSk7XG4gICAgY29uc3QgW3Jlc3BvbnNlcywgc2V0UmVzcG9uc2VzXSA9IHVzZVN0YXRlKFtdKTtcbiAgICBjb25zdCBbYW5hbHl0aWNzLCBzZXRBbmFseXRpY3NdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW3N0YXR1c1VwZGF0aW5nLCBzZXRTdGF0dXNVcGRhdGluZ10gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbdG9hc3QsIHNldFRvYXN0XSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtleHBvcnRpbmcsIHNldEV4cG9ydGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2xpZ2h0Ym94SW1hZ2UsIHNldExpZ2h0Ym94SW1hZ2VdID0gdXNlU3RhdGUobnVsbCk7XG5cbiAgICAvLyBGZWVkYmFja1xuICAgIGNvbnN0IFtmZWVkYmFja3MsIHNldEZlZWRiYWNrc10gPSB1c2VTdGF0ZShbXSk7XG4gICAgY29uc3QgW2ZlZWRiYWNrTG9hZGluZywgc2V0RmVlZGJhY2tMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIC8vIFJldmlldyBBbnN3ZXJzIE1vZGFsXG4gICAgY29uc3QgW3NlbGVjdGVkUmVzcG9uZGVudCwgc2V0U2VsZWN0ZWRSZXNwb25kZW50XSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gICAgY29uc3QgW2VkaXRpbmdTY29yZUlkLCBzZXRFZGl0aW5nU2NvcmVJZF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbaW5saW5lU2NvcmVJbnB1dCwgc2V0SW5saW5lU2NvcmVJbnB1dF0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgICAvLyBCVUctMzogcGFydGlhbCBwZXItYW5zd2VyIHNjb3JlIG92ZXJyaWRlIHN0YXRlIChlc3NheSBxdWVzdGlvbnMgb25seSlcbiAgICBjb25zdCBbcGFydGlhbFNjb3JlRWRpdGluZ0lkLCBzZXRQYXJ0aWFsU2NvcmVFZGl0aW5nSWRdID0gdXNlU3RhdGUobnVsbCk7IC8vIGFuc3dlcklkIGJlaW5nIGVkaXRlZFxuICAgIGNvbnN0IFtwYXJ0aWFsU2NvcmVJbnB1dCwgc2V0UGFydGlhbFNjb3JlSW5wdXRdID0gdXNlU3RhdGUoJycpOyAvLyBzdHJpbmcgXCIwXCLigJNcIjEwMFwiXG5cbiAgICAvLyBCLTI6IENvbXBsZXRlIGNvcnJlY3Rpb24gcGFuZWwgc3RhdGUgKGVzc2F5KSDigJQgSXNDb3JyZWN0T3ZlcnJpZGUgZXhwbGljaXQgKyBPdmVycmlkZU5vdGVcbiAgICBjb25zdCBbYWN0aXZlQ29ycmVjdGlvbklkLCBzZXRBY3RpdmVDb3JyZWN0aW9uSWRdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2NvcnJlY3Rpb25Ob3RlLCBzZXRDb3JyZWN0aW9uTm90ZV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2NvcnJlY3Rpb25Jc0NvcnJlY3RPdmVycmlkZSwgc2V0Q29ycmVjdGlvbklzQ29ycmVjdE92ZXJyaWRlXSA9IHVzZVN0YXRlKHVuZGVmaW5lZCk7XG5cbiAgICAvLyBCLTM6IEFJIEVzc2F5IFNjb3Jpbmcg4oCUIHJlZGVzaWduZWQgdG8gaG9saXN0aWMgcGVyLXN1Ym1pc3Npb24gKEEtOClcbiAgICBjb25zdCBbYWlTY29yaW5nQW5zd2VySWQsIHNldEFpU2NvcmluZ0Fuc3dlcklkXSA9IHVzZVN0YXRlKG51bGwpOyAvLyBhbnN3ZXJJZCBiZWluZyBzY29yZWRcbiAgICBjb25zdCBbYWlTY29yZVN1Z2dlc3Rpb25zLCBzZXRBaVNjb3JlU3VnZ2VzdGlvbnNdID0gdXNlU3RhdGUoe30pO1xuICAgIC8vIEEtODogSG9saXN0aWMgc2NvcmluZyBzdGF0ZVxuICAgIGNvbnN0IFthaUhvbGlzdGljU2NvcmluZywgc2V0QWlIb2xpc3RpY1Njb3JpbmddID0gdXNlU3RhdGUoZmFsc2UpOyAvLyBsb2FkaW5nIHN0YXRlIGZvciBob2xpc3RpYyBhbmFseXNpc1xuICAgIGNvbnN0IFthaU1vZGVsLCBzZXRBaU1vZGVsXSA9IHVzZVN0YXRlKCgpID0+IHsgY29uc3QgbSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdmb3JtdXBfc2VsZWN0ZWRfbW9kZWxfY2hhdCcpOyByZXR1cm4gbSAmJiAhbS5pbmNsdWRlcygnLXBybycpICYmIEFWQUlMQUJMRV9NT0RFTFMuc29tZShtb2RlbCA9PiBtb2RlbC5pZCA9PT0gbSkgPyBtIDogJ2dlbWluaS0zLjYtZmxhc2gnOyB9KTtcbiAgICBjb25zdCBbYWlIb2xpc3RpY1Jlc3VsdCwgc2V0QWlIb2xpc3RpY1Jlc3VsdF0gPSB1c2VTdGF0ZShudWxsKTsgLy8geyBlc3NheVN1Z2dlc3Rpb25zOiBbe2Fuc3dlcklkLCBzY29yZSwgcmVhc29uLCBpc0NvcnJlY3R9XSwgcGdTdW1tYXJ5LCB0b3RhbEVzdGltYXRlIH1cbiAgICBjb25zdCBbYWlIb2xpc3RpY1ByZXZpZXdPcGVuLCBzZXRBaUhvbGlzdGljUHJldmlld09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtidWxrTW9kYWxPcGVuLCBzZXRCdWxrTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbYnVsa1R5cGUsIHNldEJ1bGtUeXBlXSA9IHVzZVN0YXRlKCdtaW4nKTsgLy8gJ21pbicgfCAnYm9udXMnIHwgJ3NjYWxlJyB8ICdzZXRfZml4ZWQnXG4gICAgY29uc3QgW2J1bGtWYWx1ZSwgc2V0QnVsa1ZhbHVlXSA9IHVzZVN0YXRlKDc1KTtcbiAgICBjb25zdCBbYnVsa0ZpbHRlciwgc2V0QnVsa0ZpbHRlcl0gPSB1c2VTdGF0ZSgnYWxsJyk7IC8vICdhbGwnIHwgJ2JlbG93JyB8ICdyYW5nZSdcbiAgICBjb25zdCBbZmlsdGVyVGhyZXNob2xkLCBzZXRGaWx0ZXJUaHJlc2hvbGRdID0gdXNlU3RhdGUoNzUpO1xuICAgIGNvbnN0IFtmaWx0ZXJSYW5nZU1pbiwgc2V0RmlsdGVyUmFuZ2VNaW5dID0gdXNlU3RhdGUoMCk7XG4gICAgY29uc3QgW2ZpbHRlclJhbmdlTWF4LCBzZXRGaWx0ZXJSYW5nZU1heF0gPSB1c2VTdGF0ZSg3MCk7XG5cbiAgICAvLyBFeGFtIE1vbml0b3JpbmcgU3RhdGVcbiAgICBjb25zdCBbbW9uaXRvcmluZ0RhdGEsIHNldE1vbml0b3JpbmdEYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFttb25pdG9yaW5nTG9hZGluZywgc2V0TW9uaXRvcmluZ0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFttb25pdG9yaW5nRXJyb3IsIHNldE1vbml0b3JpbmdFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW21vbml0b3JpbmdGaWx0ZXIsIHNldE1vbml0b3JpbmdGaWx0ZXJdID0gdXNlU3RhdGUoJ2FsbCcpOyAvLyBhbGwsIGluX3Byb2dyZXNzLCBzdWJtaXR0ZWQsIHZpb2xhdGlvbnMsIGhpZ2hfdmlvbGF0aW9uc1xuICAgIGNvbnN0IFttb25pdG9yaW5nU2VhcmNoLCBzZXRNb25pdG9yaW5nU2VhcmNoXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbZXhwYW5kZWRTZXNzaW9ucywgc2V0RXhwYW5kZWRTZXNzaW9uc10gPSB1c2VTdGF0ZShuZXcgU2V0KCkpO1xuICAgIGNvbnN0IFthdXRvUmVmcmVzaCwgc2V0QXV0b1JlZnJlc2hdID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW2xhc3RSZWZyZXNoZWRBdCwgc2V0TGFzdFJlZnJlc2hlZEF0XSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtpbmNsdWRlQW5zd2VyS2V5LCBzZXRJbmNsdWRlQW5zd2VyS2V5XSA9IHVzZVN0YXRlKHRydWUpO1xuXG4gICAgLy8gUHJvY3RvcmluZyBhY3Rpb24gbW9kYWwgc3RhdGVcbiAgICBjb25zdCBbcHJvY3Rvck1vZGFsLCBzZXRQcm9jdG9yTW9kYWxdID0gdXNlU3RhdGUoe1xuICAgICAgICBpc09wZW46IGZhbHNlLFxuICAgICAgICB0eXBlOiBudWxsLCAvLyAnZm9yY2Vfc3VibWl0JyB8ICdyZXNldCdcbiAgICAgICAgc2Vzc2lvbklkOiBudWxsLFxuICAgICAgICByZXNwb25kZW50TmFtZTogJycsXG4gICAgICAgIGxvYWRpbmc6IGZhbHNlLFxuICAgIH0pO1xuXG4gICAgY29uc3QgaGFuZGxlT3BlbkZvcmNlU3VibWl0ID0gKHNlc3Npb24pID0+IHtcbiAgICAgICAgc2V0UHJvY3Rvck1vZGFsKHtcbiAgICAgICAgICAgIGlzT3BlbjogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdmb3JjZV9zdWJtaXQnLFxuICAgICAgICAgICAgc2Vzc2lvbklkOiBzZXNzaW9uLnNlc3Npb25JZCxcbiAgICAgICAgICAgIHJlc3BvbmRlbnROYW1lOiBzZXNzaW9uLnJlc3BvbmRlbnROYW1lIHx8ICdBbm9uaW0nLFxuICAgICAgICAgICAgbG9hZGluZzogZmFsc2UsXG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVPcGVuUmVzZXRTZXNzaW9uID0gKHNlc3Npb24pID0+IHtcbiAgICAgICAgc2V0UHJvY3Rvck1vZGFsKHtcbiAgICAgICAgICAgIGlzT3BlbjogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdyZXNldCcsXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHNlc3Npb24uc2Vzc2lvbklkLFxuICAgICAgICAgICAgcmVzcG9uZGVudE5hbWU6IHNlc3Npb24ucmVzcG9uZGVudE5hbWUgfHwgJ0Fub25pbScsXG4gICAgICAgICAgICBsb2FkaW5nOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNvbmZpcm1Qcm9jdG9yQWN0aW9uID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCB7IHR5cGUsIHNlc3Npb25JZCB9ID0gcHJvY3Rvck1vZGFsO1xuICAgICAgICBpZiAoIXNlc3Npb25JZCkgcmV0dXJuO1xuICAgICAgICBzZXRQcm9jdG9yTW9kYWwocHJldiA9PiAoeyAuLi5wcmV2LCBsb2FkaW5nOiB0cnVlIH0pKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmICh0eXBlID09PSAnZm9yY2Vfc3VibWl0Jykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZvcmNlU3VibWl0RXhhbVNlc3Npb24oaWQsIHNlc3Npb25JZCk7XG4gICAgICAgICAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ1Nlc2kgdWppYW4gYmVyaGFzaWwgZGlzZWxlc2Fpa2FuIHBha3NhLicpO1xuICAgICAgICAgICAgICAgICAgICBzZXRQcm9jdG9yTW9kYWwoeyBpc09wZW46IGZhbHNlLCB0eXBlOiBudWxsLCBzZXNzaW9uSWQ6IG51bGwsIHJlc3BvbmRlbnROYW1lOiAnJywgbG9hZGluZzogZmFsc2UgfSk7XG4gICAgICAgICAgICAgICAgICAgIGZldGNoRXhhbU1vbml0b3JpbmcodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIGdldEZvcm1SZXNwb25zZXMoaWQsIHsgcGFnZTogMSwgcGFnZVNpemU6IFBBR0VfU0laRSB9KS50aGVuKHJlc3BSZXMgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BSZXMub2sgJiYgcmVzcFJlcy5kYXRhKSBzZXRSZXNwb25zZXMocmVzcFJlcy5kYXRhLnJlc3BvbnNlcyB8fCByZXNwUmVzLmRhdGEgfHwgW10pO1xuICAgICAgICAgICAgICAgICAgICB9KS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW55ZWxlc2Fpa2FuIHBha3NhIHNlc2kgdWppYW4uJywgJ2Vycm9yJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldFByb2N0b3JNb2RhbChwcmV2ID0+ICh7IC4uLnByZXYsIGxvYWRpbmc6IGZhbHNlIH0pKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdyZXNldCcpIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCByZXNldEV4YW1TZXNzaW9uKGlkLCBzZXNzaW9uSWQpO1xuICAgICAgICAgICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdKYXdhYmFuIHBlc2VydGEgYmVyaGFzaWwgZGktcmVzZXQuJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldFByb2N0b3JNb2RhbCh7IGlzT3BlbjogZmFsc2UsIHR5cGU6IG51bGwsIHNlc3Npb25JZDogbnVsbCwgcmVzcG9uZGVudE5hbWU6ICcnLCBsb2FkaW5nOiBmYWxzZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgZmV0Y2hFeGFtTW9uaXRvcmluZyh0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgZ2V0Rm9ybVJlc3BvbnNlcyhpZCwgeyBwYWdlOiAxLCBwYWdlU2l6ZTogUEFHRV9TSVpFIH0pLnRoZW4ocmVzcFJlcyA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcFJlcy5vayAmJiByZXNwUmVzLmRhdGEpIHNldFJlc3BvbnNlcyhyZXNwUmVzLmRhdGEucmVzcG9uc2VzIHx8IHJlc3BSZXMuZGF0YSB8fCBbXSk7XG4gICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lLXJlc2V0IGphd2FiYW4gcGVzZXJ0YS4nLCAnZXJyb3InKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0UHJvY3Rvck1vZGFsKHByZXYgPT4gKHsgLi4ucHJldiwgbG9hZGluZzogZmFsc2UgfSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ1RlcmphZGkga2VzYWxhaGFuIHNhYXQgbWVtcHJvc2VzIGFrc2kgcHJvY3RvcmluZy4nLCAnZXJyb3InKTtcbiAgICAgICAgICAgIHNldFByb2N0b3JNb2RhbChwcmV2ID0+ICh7IC4uLnByZXYsIGxvYWRpbmc6IGZhbHNlIH0pKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCB0b2dnbGVTZXNzaW9uRXhwYW5kID0gKHNlc3Npb25JZCkgPT4ge1xuICAgICAgICBzZXRFeHBhbmRlZFNlc3Npb25zKHByZXYgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBTZXQocHJldik7XG4gICAgICAgICAgICBpZiAobmV4dC5oYXMoc2Vzc2lvbklkKSkgbmV4dC5kZWxldGUoc2Vzc2lvbklkKTtcbiAgICAgICAgICAgIGVsc2UgbmV4dC5hZGQoc2Vzc2lvbklkKTtcbiAgICAgICAgICAgIHJldHVybiBuZXh0O1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgZmV0Y2hFeGFtTW9uaXRvcmluZyA9IHVzZUNhbGxiYWNrKGFzeW5jIChpc1NpbGVudCA9IGZhbHNlKSA9PiB7XG4gICAgICAgIGlmICghaWQpIHJldHVybjtcbiAgICAgICAgaWYgKCFpc1NpbGVudCkgc2V0TW9uaXRvcmluZ0xvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBnZXRFeGFtTW9uaXRvcmluZyhpZCk7XG4gICAgICAgICAgICBpZiAocmVzLm9rICYmIHJlcy5kYXRhKSB7XG4gICAgICAgICAgICAgICAgc2V0TW9uaXRvcmluZ0RhdGEocmVzLmRhdGEpO1xuICAgICAgICAgICAgICAgIHNldExhc3RSZWZyZXNoZWRBdChuZXcgRGF0ZSgpKTtcbiAgICAgICAgICAgICAgICBzZXRNb25pdG9yaW5nRXJyb3IoJycpO1xuICAgICAgICAgICAgfSBlbHNlIGlmICghaXNTaWxlbnQpIHtcbiAgICAgICAgICAgICAgICBzZXRNb25pdG9yaW5nRXJyb3IocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbXVhdCBkYXRhIG1vbml0b3JpbmcuJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgaWYgKCFpc1NpbGVudCkgc2V0TW9uaXRvcmluZ0Vycm9yKCdLb25la3NpIHRlcnB1dHVzIHNhYXQgbWVuZ2FtYmlsIGRhdGEgbW9uaXRvcmluZy4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIGlmICghaXNTaWxlbnQpIHNldE1vbml0b3JpbmdMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH0sIFtpZF0pO1xuXG4gICAgLy8gUG9sbGluZyBlZmZlY3Qgd2hlbiBhY3RpdmVUYWIgPT09ICdtb25pdG9yaW5nJ1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChhY3RpdmVUYWIgIT09ICdtb25pdG9yaW5nJykgcmV0dXJuO1xuXG4gICAgICAgIGZldGNoRXhhbU1vbml0b3JpbmcoZmFsc2UpO1xuXG4gICAgICAgIGlmICghYXV0b1JlZnJlc2gpIHJldHVybjtcblxuICAgICAgICBjb25zdCBpbnRlcnZhbElkID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICAgICAgZmV0Y2hFeGFtTW9uaXRvcmluZyh0cnVlKTtcbiAgICAgICAgfSwgNTAwMCk7XG5cbiAgICAgICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJZCk7XG4gICAgfSwgW2FjdGl2ZVRhYiwgYXV0b1JlZnJlc2gsIGZldGNoRXhhbU1vbml0b3JpbmddKTtcblxuICAgIGNvbnN0IGZpbHRlcmVkU2Vzc2lvbnMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBsaXN0ID0gbW9uaXRvcmluZ0RhdGE/LnNlc3Npb25zIHx8IFtdO1xuICAgIGNvbnN0IG1heFN3ID0gbW9uaXRvcmluZ0RhdGE/Lm1heFRhYlN3aXRjaCB8fCAzO1xuICAgIHJldHVybiBsaXN0LmZpbHRlcihzID0+IHtcbiAgICAgICAgaWYgKG1vbml0b3JpbmdTZWFyY2gpIHtcbiAgICAgICAgICAgIGNvbnN0IHRlcm0gPSBtb25pdG9yaW5nU2VhcmNoLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICBjb25zdCBuYW1lID0gKHMucmVzcG9uZGVudE5hbWUgfHwgJ0Fub25pbScpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICBpZiAoIW5hbWUuaW5jbHVkZXModGVybSkpIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobW9uaXRvcmluZ0ZpbHRlciA9PT0gJ2luX3Byb2dyZXNzJykgcmV0dXJuIHMuc3RhdHVzID09PSAnaW5fcHJvZ3Jlc3MnO1xuICAgICAgICBpZiAobW9uaXRvcmluZ0ZpbHRlciA9PT0gJ3N1Ym1pdHRlZCcpIHJldHVybiBzLnN0YXR1cyA9PT0gJ3N1Ym1pdHRlZCc7XG4gICAgICAgIGlmIChtb25pdG9yaW5nRmlsdGVyID09PSAndmlvbGF0aW9ucycpIHJldHVybiBnZXRHZW51aW5lVmlvbGF0aW9uQ291bnQocykgPiAwO1xuICAgICAgICBpZiAobW9uaXRvcmluZ0ZpbHRlciA9PT0gJ2hpZ2hfdmlvbGF0aW9ucycpIHJldHVybiBnZXRHZW51aW5lVmlvbGF0aW9uQ291bnQocykgPj0gbWF4U3cgfHwgcy50YWJTd2l0Y2hDb3VudCA+PSBtYXhTdztcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSk7XG59LCBbbW9uaXRvcmluZ0RhdGEsIG1vbml0b3JpbmdGaWx0ZXIsIG1vbml0b3JpbmdTZWFyY2hdKTtcblxuICAgIGNvbnN0IGdldFZpb2xhdGlvbkluZm8gPSAodHlwZSkgPT4ge1xuICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ3RhYl9zd2l0Y2gnOlxuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnUGluZGFoIFRhYiAvIExheWFyIFVqaWFuJyxcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogPEFycm93UmlnaHRJY29uIHNpemU9ezEzfSAvPixcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICd0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAnLFxuICAgICAgICAgICAgICAgICAgICBiZzogJ2JnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNjAnLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICBjYXNlICd3aW5kb3dfYmx1cic6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdKZW5kZWxhIEJyb3dzZXIgS2VoaWxhbmdhbiBGb2t1cycsXG4gICAgICAgICAgICAgICAgICAgIGljb246IDxBbGVydFRyaWFuZ2xlIHNpemU9ezEzfSAvPixcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICd0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwJyxcbiAgICAgICAgICAgICAgICAgICAgYmc6ICdiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC82MCcsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGNhc2UgJ2NvcHlfYXR0ZW1wdCc6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdQZXJjb2JhYW4gTWVueWFsaW4gVGVrcyAoQ29weSknLFxuICAgICAgICAgICAgICAgICAgICBpY29uOiA8WENpcmNsZSBzaXplPXsxM30gLz4sXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAndGV4dC1wdXJwbGUtNjAwIGRhcms6dGV4dC1wdXJwbGUtNDAwJyxcbiAgICAgICAgICAgICAgICAgICAgYmc6ICdiZy1wdXJwbGUtNTAgZGFyazpiZy1wdXJwbGUtOTUwLzYwJyxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgY2FzZSAncGFzdGVfYXR0ZW1wdCc6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdQZXJjb2JhYW4gTWVuZW1wZWwgVGVrcyAoUGFzdGUpJyxcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogPFhDaXJjbGUgc2l6ZT17MTN9IC8+LFxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogJ3RleHQtaW5kaWdvLTYwMCBkYXJrOnRleHQtaW5kaWdvLTQwMCcsXG4gICAgICAgICAgICAgICAgICAgIGJnOiAnYmctaW5kaWdvLTUwIGRhcms6YmctaW5kaWdvLTk1MC82MCcsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGNhc2UgJ2NvbnRleHRfbWVudSc6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdLbGlrIEthbmFuIChDb250ZXh0IE1lbnUpJyxcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogPE1pbnVzQ2lyY2xlIHNpemU9ezEzfSAvPixcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICd0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwJyxcbiAgICAgICAgICAgICAgICAgICAgYmc6ICdiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAnLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICBjYXNlICdGT1JDRV9TVUJNSVRfQllfUFJPQ1RPUic6XG4gICAgICAgICAgICBjYXNlICdmb3JjZV9zdWJtaXRfYnlfcHJvY3Rvcic6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdEaXNlbGVzYWlrYW4gUGFrc2Egb2xlaCBQZW5nYXdhcyAoRm9yY2UgU3VibWl0KScsXG4gICAgICAgICAgICAgICAgICAgIGljb246IDxTaGllbGRBbGVydCBzaXplPXsxM30gLz4sXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAndGV4dC1yZWQtNzAwIGRhcms6dGV4dC1yZWQtMzAwJyxcbiAgICAgICAgICAgICAgICAgICAgYmc6ICdiZy1yZWQtMTAwIGRhcms6YmctcmVkLTk1MC84MCcsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGBQZWxhbmdnYXJhbjogJHt0eXBlfWAsXG4gICAgICAgICAgICAgICAgICAgIGljb246IDxBbGVydENpcmNsZSBzaXplPXsxM30gLz4sXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAndGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwJyxcbiAgICAgICAgICAgICAgICAgICAgYmc6ICdiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTUwLzYwJyxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGZvcm1hdERhdGVXaXRoVGltZSA9IChkKSA9PiBkXG4gICAgICAgID8gbmV3IERhdGUoZCkudG9Mb2NhbGVTdHJpbmcoJ2lkLUlEJywgeyBkYXk6ICdudW1lcmljJywgbW9udGg6ICdzaG9ydCcsIHllYXI6ICdudW1lcmljJywgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0Jywgc2Vjb25kOiAnMi1kaWdpdCcgfSlcbiAgICAgICAgOiAn4oCUJztcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGxvYWQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAvLyBTaWxlbnRseSBsb2FkIG1vbml0b3JpbmcgZGF0YSBpbiBwYXJhbGxlbCBpZiBhdmFpbGFibGVcbiAgICAgICAgICAgICAgICBnZXRFeGFtTW9uaXRvcmluZyhpZCkudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzLm9rICYmIHJlcy5kYXRhKSBzZXRNb25pdG9yaW5nRGF0YShyZXMuZGF0YSk7XG4gICAgICAgICAgICAgICAgfSkuY2F0Y2goKCkgPT4ge30pO1xuXG4gICAgICAgICAgICAgICAgY29uc3QgW2Zvcm1SZXMsIHJlc3BSZXMsIGFuYWx5dGljc1JlcywgcXVlc3Rpb25zUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgICAgICAgZ2V0Rm9ybUJ5SWQoaWQpLFxuICAgICAgICAgICAgICAgICAgICBnZXRGb3JtUmVzcG9uc2VzKGlkLCB7IHBhZ2U6IDEsIHBhZ2VTaXplOiBQQUdFX1NJWkUgfSksXG4gICAgICAgICAgICAgICAgICAgIGdldEZvcm1BbmFseXRpY3MoaWQsIDEsIDEwMCksXG4gICAgICAgICAgICAgICAgICAgIGdldFF1ZXN0aW9ucyhpZCksXG4gICAgICAgICAgICAgICAgXSk7XG5cbiAgICAgICAgICAgICAgICBpZiAoZm9ybVJlcy5zdGF0dXMgPT09IDQwMSkgeyBcbiAgICAgICAgICAgICAgICAgICAgY2xlYXJTZXNzaW9uKCk7IFxuICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZSgnL2xvZ2luJyk7IFxuICAgICAgICAgICAgICAgICAgICByZXR1cm47IFxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChmb3JtUmVzLm9rKSBzZXRGb3JtKGZvcm1SZXMuZGF0YSk7XG5cbiAgICAgICAgICAgICAgICBsZXQgbG9hZGVkUXVlc3Rpb25zID0gW107XG4gICAgICAgICAgICAgICAgaWYgKHF1ZXN0aW9uc1Jlcy5vayAmJiBBcnJheS5pc0FycmF5KHF1ZXN0aW9uc1Jlcy5kYXRhKSkge1xuICAgICAgICAgICAgICAgICAgICBsb2FkZWRRdWVzdGlvbnMgPSBxdWVzdGlvbnNSZXMuZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybVF1ZXN0aW9ucyhsb2FkZWRRdWVzdGlvbnMpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChyZXNwUmVzLm9rKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpc3QgPSBBcnJheS5pc0FycmF5KHJlc3BSZXMuZGF0YSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gcmVzcFJlcy5kYXRhXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHJlc3BSZXMuZGF0YT8ucmVzcG9uc2VzIHx8IHJlc3BSZXMuZGF0YT8uaXRlbXMgfHwgW107XG4gICAgICAgICAgICAgICAgICAgIHNldFJlc3BvbnNlcyhsaXN0KTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAoYW5hbHl0aWNzUmVzLm9rICYmIGFuYWx5dGljc1Jlcy5kYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGxvY2FsT3ZlcnJpZGVzID0gZ2V0TG9jYWxNYW51YWxPdmVycmlkZXMoaWQpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgZGF0YSA9IGFuYWx5dGljc1Jlcy5kYXRhO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YS5yZXNwb25kZW50cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS5yZXNwb25kZW50cyA9IGRhdGEucmVzcG9uZGVudHMubWFwKHIgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BPdmVycmlkZXMgPSBsb2NhbE92ZXJyaWRlc1tyLnJlc3BvbnNlSWRdIHx8IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRBbnN3ZXJzID0gKHIuYW5zd2VycyB8fCBbXSkubWFwKGEgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBxRGVmID0gbG9hZGVkUXVlc3Rpb25zLmZpbmQocSA9PiBOdW1iZXIocS5pZCkgPT09IE51bWJlcihhLnF1ZXN0aW9uSWQpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qga2V5ID0gYS5jb3JyZWN0QW5zd2VyIHx8IHJlc29sdmVRdWVzdGlvbktleShxRGVmKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaGFzTG9jYWxPdmVycmlkZSA9IHJlc3BPdmVycmlkZXNbYS5xdWVzdGlvbklkXSAhPT0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBlZmZPdmVycmlkZSA9IGhhc0xvY2FsT3ZlcnJpZGUgPyByZXNwT3ZlcnJpZGVzW2EucXVlc3Rpb25JZF0gOiBhLmlzQ29ycmVjdE92ZXJyaWRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBlZmZJc0NvcnJlY3QgPSBnZXRFZmZlY3RpdmVJc0NvcnJlY3Qoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uYSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdE92ZXJyaWRlOiBlZmZPdmVycmlkZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgcURlZik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5hLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29ycmVjdEFuc3dlcjoga2V5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0T3ZlcnJpZGU6IGVmZk92ZXJyaWRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0OiBlZmZJc0NvcnJlY3QsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2NvcmluZyA9IGNhbGN1bGF0ZVRvdGFsU2NvcmUodXBkYXRlZEFuc3dlcnMsIGxvYWRlZFF1ZXN0aW9ucyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaGFzQW55T3ZlcnJpZGUgPSBPYmplY3Qua2V5cyhyZXNwT3ZlcnJpZGVzKS5sZW5ndGggPiAwIHx8IHVwZGF0ZWRBbnN3ZXJzLnNvbWUoYSA9PiBhLmlzQ29ycmVjdE92ZXJyaWRlICE9PSBudWxsICYmIGEuaXNDb3JyZWN0T3ZlcnJpZGUgIT09IHVuZGVmaW5lZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyczogdXBkYXRlZEFuc3dlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvcnJlY3RDb3VudDogc2NvcmluZy5jb3JyZWN0Q291bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdyb25nQ291bnQ6IHNjb3Jpbmcud3JvbmdDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2NvcmU6IHNjb3Jpbmcuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ3VzdG9tU2NvcmU6IGhhc0FueU92ZXJyaWRlIHx8IHIuaXNDdXN0b21TY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgc2V0QW5hbHl0aWNzKGRhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxvYWRpbmcgcmVzcG9uc2VzOicsIGVycik7XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGxvYWQoKTtcbiAgICB9LCBbaWQsIG5hdmlnYXRlXSk7XG5cbiAgICAvLyBMb2FkIGZlZWRiYWNrIHRhYlxuICAgICAgICAvLyBMb2FkIGZlZWRiYWNrIHRhYlxuICAgICAgICAvLyBMb2FkIGZlZWRiYWNrIHRhYiDigJQgR0VUIC9hcGkvZm9ybXMve2Zvcm1JZH0vZmVlZGJhY2tzIChwbHVyYWwpIGlzIHRoZVxuICAgIC8vIGVuZHBvaW50IHRoYXQgcmV0dXJucyBBTEwgZmVlZGJhY2sgc3VibWl0dGVkIGJ5IHJlc3BvbmRlbnRzIG9uIHRoaXNcbiAgICAvLyBmb3JtLCB3aGljaCBpcyB3aGF0IHRoZSBvd25lciBuZWVkcyB0byBzZWUgaGVyZS4gR0VUIC9hcGkvZm9ybXMve2Zvcm1JZH0vZmVlZGJhY2tcbiAgICAvLyAoc2luZ3VsYXIsIFwiZ2V0TXlGZWVkYmFja1wiKSByZXR1cm5zIG9ubHkgdGhlIGxvZ2dlZC1pbiB1c2VyJ3Mgb3duXG4gICAgLy8gZmVlZGJhY2sgc3VibWlzc2lvbnMgYW5kIHJldHVybmVkIDQwNCBmb3Igb3duZXJzIHdobyBuZXZlciBzdWJtaXR0ZWRcbiAgICAvLyBmZWVkYmFjayB0aGVtc2VsdmVzIOKAlCB0aGUgd3JvbmcgZW5kcG9pbnQgZm9yIHRoaXMgcHVycG9zZS5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoYWN0aXZlVGFiICE9PSAnZmVlZGJhY2snKSByZXR1cm47XG4gICAgICAgIGNvbnN0IGxvYWRGZWVkYmFjayA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHNldEZlZWRiYWNrTG9hZGluZyh0cnVlKTtcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdldEZvcm1GZWVkYmFja3MoaWQpO1xuICAgICAgICAgICAgc2V0RmVlZGJhY2tMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gcmVzLmRhdGE7XG4gICAgICAgICAgICAgICAgbGV0IGxpc3QgPSBbXTtcbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShkYXRhKSkgbGlzdCA9IGRhdGE7XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoZGF0YT8uaXRlbXMgJiYgQXJyYXkuaXNBcnJheShkYXRhLml0ZW1zKSkgbGlzdCA9IGRhdGEuaXRlbXM7XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoZGF0YSAmJiB0eXBlb2YgZGF0YSA9PT0gJ29iamVjdCcpIGxpc3QgPSBbZGF0YV07XG4gICAgICAgICAgICAgICAgc2V0RmVlZGJhY2tzKGxpc3QuZmlsdGVyKGZiID0+ICEoZmIucmVhc29uIHx8ICcnKS5zdGFydHNXaXRoKCdBRE1JTl8nKSkpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRGZWVkYmFja3MoW10pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBsb2FkRmVlZGJhY2soKTtcbiAgICB9LCBbYWN0aXZlVGFiLCBpZF0pO1xuXG4gICAgY29uc3Qgc2hvd1RvYXN0ID0gKG1zZywgdHlwZSA9ICdzdWNjZXNzJykgPT4ge1xuICAgICAgICBzZXRUb2FzdCh7IG1zZywgdHlwZSB9KTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRUb2FzdChudWxsKSwgMzAwMCk7XG4gICAgfTtcblxuICAgIC8vIE1lcmdlIHJlc3BvbmRlbnQgZGF0YSBmcm9tIGFuYWx5dGljcyB3aXRoIHJlc3BvbnNlIGxpc3RcbiAgICBjb25zdCByZXNwb25kZW50c0xpc3QgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKGFuYWx5dGljcz8ucmVzcG9uZGVudHMgJiYgYW5hbHl0aWNzLnJlc3BvbmRlbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiBhbmFseXRpY3MucmVzcG9uZGVudHM7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIChyZXNwb25zZXMgfHwgW10pLm1hcChyID0+ICh7XG4gICAgICAgICAgICByZXNwb25zZUlkOiByLmlkLFxuICAgICAgICAgICAgcmVzcG9uZGVudE5hbWU6IHIucmVzcG9uZGVudE5hbWUsXG4gICAgICAgICAgICBzdWJtaXR0ZWRBdDogci5zdWJtaXR0ZWRBdCxcbiAgICAgICAgICAgIHN0YXR1czogci5zdGF0dXMsXG4gICAgICAgICAgICBhbnN3ZXJlZENvdW50OiAwLFxuICAgICAgICAgICAgdG90YWxRdWVzdGlvbnM6IDAsXG4gICAgICAgICAgICBjb3JyZWN0Q291bnQ6IDAsXG4gICAgICAgICAgICB3cm9uZ0NvdW50OiAwLFxuICAgICAgICAgICAgc2NvcmU6IG51bGwsXG4gICAgICAgICAgICBhbnN3ZXJzOiBbXVxuICAgICAgICB9KSk7XG4gICAgfSwgW2FuYWx5dGljcywgcmVzcG9uc2VzXSk7XG5cbiAgICBjb25zdCBoYW5kbGVFeHBvcnQgPSBhc3luYyAoZm9ybUlkLCBmb3JtYXQgPSAnY3N2JykgPT4ge1xuICAgICAgICBpZiAoIWZvcm1JZCB8fCBleHBvcnRpbmcpIHJldHVybjtcbiAgICAgICAgc2V0RXhwb3J0aW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gRm9yIEV4Y2VsIC8gUERGLCB1c2Ugc2VydmVyLXNpZGUgZXhwb3J0IGVuZHBvaW50XG4gICAgICAgICAgICBpZiAoZm9ybWF0ID09PSAneGxzeCcgfHwgZm9ybWF0ID09PSAncGRmJykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGV4cG9ydEZvcm1SZXNwb25zZXMoZm9ybUlkLCBmb3JtYXQsIGluY2x1ZGVBbnN3ZXJLZXkpO1xuICAgICAgICAgICAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgICAgICAgICAgICAgIHNob3dUb2FzdChyZXMubWVzc2FnZSB8fCBgR2FnYWwgbWVuZ2Vrc3BvciAke2Zvcm1hdC50b1VwcGVyQ2FzZSgpfWAsICdlcnJvcicpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHNob3dUb2FzdChgRmlsZSAke2Zvcm1hdC50b1VwcGVyQ2FzZSgpfSBiZXJoYXNpbCBkaXVuZHVoIWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIEZvciBDU1Y6IElmIG5vIGxvY2FsIHJlc3BvbnNlcyBsaXN0LCBmYWxsYmFjayB0byBzZXJ2ZXItc2lkZSBDU1ZcbiAgICAgICAgICAgIGlmICghcmVzcG9uZGVudHNMaXN0IHx8IHJlc3BvbmRlbnRzTGlzdC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBleHBvcnRGb3JtUmVzcG9uc2VzKGZvcm1JZCwgJ2NzdicsIGluY2x1ZGVBbnN3ZXJLZXkpO1xuICAgICAgICAgICAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgICAgICAgICAgICAgIHNob3dUb2FzdChyZXMubWVzc2FnZSB8fCAnQmVsdW0gYWRhIGRhdGEgcmVzcG9ucyB1bnR1ayBkaWVrc3Bvci4nLCAnZXJyb3InKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzaG93VG9hc3QoJ0ZpbGUgQ1NWIGJlcmhhc2lsIGRpdW5kdWghJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gRXh0cmFjdCB1bmlxdWUgcXVlc3Rpb24gdGl0bGVzXG4gICAgICAgICAgICBjb25zdCBxdWVzdGlvbk1hcCA9IG5ldyBNYXAoKTtcbiAgICAgICAgICAgIHJlc3BvbmRlbnRzTGlzdC5mb3JFYWNoKHIgPT4ge1xuICAgICAgICAgICAgICAgIChyLmFuc3dlcnMgfHwgW10pLmZvckVhY2goYSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhLnF1ZXN0aW9uSWQgJiYgIXF1ZXN0aW9uTWFwLmhhcyhhLnF1ZXN0aW9uSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGVhblRpdGxlID0gKGEucXVlc3Rpb24gfHwgYFNvYWwgIyR7YS5xdWVzdGlvbklkfWApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoLzxbXj5dKj4vZywgJycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xccysvZywgJyAnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbk1hcC5zZXQoYS5xdWVzdGlvbklkLCBjbGVhblRpdGxlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIC8vIEFsc28gZW5zdXJlIGFueSBsb2FkZWQgcXVlc3Rpb25zIGFyZSBpbmNsdWRlZFxuICAgICAgICAgICAgKGZvcm1RdWVzdGlvbnMgfHwgW10pLmZvckVhY2gocSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHEuaWQgJiYgIXF1ZXN0aW9uTWFwLmhhcyhxLmlkKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGVhblRpdGxlID0gKHEucXVlc3Rpb24gfHwgcS5xdWVzdGlvbjEgfHwgYFNvYWwgIyR7cS5pZH1gKVxuICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoLzxbXj5dKj4vZywgJycpXG4gICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxzKy9nLCAnICcpXG4gICAgICAgICAgICAgICAgICAgICAgICAudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbk1hcC5zZXQocS5pZCwgY2xlYW5UaXRsZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGNvbnN0IGVzY2FwZUNzdiA9ICh2YWwpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAodmFsID09PSBudWxsIHx8IHZhbCA9PT0gdW5kZWZpbmVkKSByZXR1cm4gJ1wiXCInO1xuICAgICAgICAgICAgICAgIGNvbnN0IHN0ciA9IFN0cmluZyh2YWwpXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC88W14+XSo+L2csICcnKVxuICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvW1xcclxcbl0rL2csICcgJylcbiAgICAgICAgICAgICAgICAgICAgLnRyaW0oKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYFwiJHtzdHIucmVwbGFjZSgvXCIvZywgJ1wiXCInKX1cImA7XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICBjb25zdCBoZWFkZXJSb3cgPSBbXG4gICAgICAgICAgICAgICAgJ1Jlc3BvbnNlIElEJyxcbiAgICAgICAgICAgICAgICAnU3VibWl0dGVkIEF0JyxcbiAgICAgICAgICAgICAgICAnUmVzcG9uZGVudCcsXG4gICAgICAgICAgICAgICAgLi4uQXJyYXkuZnJvbShxdWVzdGlvbk1hcC52YWx1ZXMoKSkubWFwKHN0cmlwTWF0aE5vdGF0aW9uKVxuICAgICAgICAgICAgXTtcblxuICAgICAgICAgICAgbGV0IHJvd3MgPSBbXTtcblxuICAgICAgICAgICAgLy8gQTUgU3BlYzpcbiAgICAgICAgICAgIC8vIFwiRm9ybWF0IENTVjogdGFtYmFoa2FuIGJhcmlzIGtlLTIgYmVyaXNpIEtVTkNJLEpBV0FCQU4sLSw8a3VuY2kgcGVyIHNvYWw+LCB0ZXBhdCBkaSBiYXdhaCBoZWFkZXIuIEhhcHVzIGtvbG9tIEt1bmNpXyogdmVyc2kgbGFtYS5cIlxuICAgICAgICAgICAgLy8gXCJQYXJhbWV0ZXIgP2luY2x1ZGVBbnN3ZXJLZXk9ZmFsc2UgaGFydXMgdGV0YXAgYmlzYSBtZW1hdGlrYW4gYmFyaXMga3VuY2kgamF3YWJhbi5cIlxuICAgICAgICAgICAgaWYgKGluY2x1ZGVBbnN3ZXJLZXkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhbnN3ZXJLZXlSb3cgPSBbXG4gICAgICAgICAgICAgICAgICAgICdLVU5DSScsXG4gICAgICAgICAgICAgICAgICAgICdKQVdBQkFOJyxcbiAgICAgICAgICAgICAgICAgICAgJy0nLFxuICAgICAgICAgICAgICAgICAgICAuLi5BcnJheS5mcm9tKHF1ZXN0aW9uTWFwLmtleXMoKSkubWFwKHFJZCA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBxRGVmID0gKGZvcm1RdWVzdGlvbnMgfHwgW10pLmZpbmQocSA9PiBxLmlkID09PSBxSWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHN0cmlwTWF0aE5vdGF0aW9uKHJlc29sdmVBbnN3ZXJLZXkocURlZikpO1xuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgcm93cy5wdXNoKGFuc3dlcktleVJvdy5tYXAoZXNjYXBlQ3N2KS5qb2luKCcsJykpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCBkYXRhUm93cyA9IChyZXNwb25kZW50c0xpc3QgfHwgW10pLm1hcChyID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBhbnN3ZXJCeVEgPSBuZXcgTWFwKChyLmFuc3dlcnMgfHwgW10pLm1hcChhID0+IFthLnF1ZXN0aW9uSWQsIGEuYW5zd2VyVGV4dCB8fCBhLmFuc3dlclZhbHVlIHx8IGEub3B0aW9uVGV4dCB8fCAnJ10pKTtcblxuICAgICAgICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAgICAgICAgIHIucmVzcG9uc2VJZCxcbiAgICAgICAgICAgICAgICAgICAgci5zdWJtaXR0ZWRBdCA/IGZvcm1hdERhdGUoci5zdWJtaXR0ZWRBdCkgOiAnLScsXG4gICAgICAgICAgICAgICAgICAgIHIucmVzcG9uZGVudE5hbWUgfHwgJ0Fub25pbScsXG4gICAgICAgICAgICAgICAgICAgIC4uLkFycmF5LmZyb20ocXVlc3Rpb25NYXAua2V5cygpKS5tYXAocUlkID0+IHN0cmlwTWF0aE5vdGF0aW9uKGFuc3dlckJ5US5nZXQocUlkKSB8fCAnJykpXG4gICAgICAgICAgICAgICAgXS5tYXAoZXNjYXBlQ3N2KS5qb2luKCcsJyk7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgcm93cy5wdXNoKC4uLmRhdGFSb3dzKTtcblxuICAgICAgICAgICAgY29uc3QgY3N2Q29udGVudCA9ICdcXHVGRUZGJyArIFtoZWFkZXJSb3cubWFwKGVzY2FwZUNzdikuam9pbignLCcpLCAuLi5yb3dzXS5qb2luKCdcXHJcXG4nKTtcbiAgICAgICAgICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbY3N2Q29udGVudF0sIHsgdHlwZTogJ3RleHQvY3N2O2NoYXJzZXQ9dXRmLTg7JyB9KTtcbiAgICAgICAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgICAgICAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgICAgICAgbGluay5ocmVmID0gdXJsO1xuICAgICAgICAgICAgbGluay5zZXRBdHRyaWJ1dGUoJ2Rvd25sb2FkJywgYHJlc3BvbnMtZm9ybXVsaXItJHtmb3JtPy50aXRsZSA/IGZvcm0udGl0bGUucmVwbGFjZSgvXFxzKy9nLCAnXycpIDogZm9ybUlkfS5jc3ZgKTtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgICAgICAgICBsaW5rLmNsaWNrKCk7XG4gICAgICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGxpbmspO1xuICAgICAgICAgICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuXG4gICAgICAgICAgICBzaG93VG9hc3QoJ0ZpbGUgQ1NWIGJlcmhhc2lsIGRpdW5kdWghJyk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KCdUZXJqYWRpIGtlc2FsYWhhbiBzYWF0IG1lbmdla3Nwb3IuJywgJ2Vycm9yJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRFeHBvcnRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVN0YXR1c0NoYW5nZSA9IGFzeW5jIChyZXNwb25zZUlkLCBzdGF0dXNJZCkgPT4ge1xuICAgICAgICBzZXRTdGF0dXNVcGRhdGluZyhyZXNwb25zZUlkKTtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdXBkYXRlUmVzcG9uc2VTdGF0dXMocmVzcG9uc2VJZCwgc3RhdHVzSWQpO1xuICAgICAgICBpZiAocmVzLm9rKSB7XG4gICAgICAgICAgICBjb25zdCBzdGF0dXNMYWJlbCA9IFNUQVRVU19PUFRJT05TLmZpbmQocyA9PiBzLmlkID09PSBzdGF0dXNJZCk/LmNvZGUgPz8gJ25ldyc7XG4gICAgICAgICAgICBzZXRSZXNwb25zZXMocHJldiA9PiBwcmV2Lm1hcChyID0+XG4gICAgICAgICAgICAgICAgci5pZCA9PT0gcmVzcG9uc2VJZFxuICAgICAgICAgICAgICAgICAgICA/IHsgLi4uciwgc3RhdHVzOiBzdGF0dXNMYWJlbCB9XG4gICAgICAgICAgICAgICAgICAgIDogclxuICAgICAgICAgICAgKSk7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ1N0YXR1cyByZXNwb25zIGJlcmhhc2lsIGRpcGVyYmFydWknKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNob3dUb2FzdChyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVtcGVyYmFydWkgc3RhdHVzJywgJ2Vycm9yJyk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0U3RhdHVzVXBkYXRpbmcobnVsbCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZCkgPT4gZFxuICAgICAgICA/IG5ldyBEYXRlKGQpLnRvTG9jYWxlU3RyaW5nKCdpZC1JRCcsIHsgZGF5OiAnbnVtZXJpYycsIG1vbnRoOiAnc2hvcnQnLCB5ZWFyOiAnbnVtZXJpYycsIGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSlcbiAgICAgICAgOiAn4oCUJztcblxuICAgIGNvbnN0IHN0YXR1c1N0eWxlID0gKHN0YXR1cykgPT4ge1xuICAgICAgICBzd2l0Y2ggKHN0YXR1cz8udG9Mb3dlckNhc2UoKSkge1xuICAgICAgICAgICAgY2FzZSAnbmV3JzogXG4gICAgICAgICAgICBjYXNlICdiYXJ1JzogcmV0dXJuICdiZy1ibHVlLTUwIHRleHQtYmx1ZS02MDAgZGFyazpiZy1ibHVlLTk1MC82MCBkYXJrOnRleHQtYmx1ZS00MDAnO1xuICAgICAgICAgICAgY2FzZSAncmV2aWV3ZWQnOiBcbiAgICAgICAgICAgIGNhc2UgJ2RpdGluamF1JzogcmV0dXJuICdiZy15ZWxsb3ctNTAgdGV4dC15ZWxsb3ctNjAwIGRhcms6YmcteWVsbG93LTk1MC82MCBkYXJrOnRleHQteWVsbG93LTQwMCc7XG4gICAgICAgICAgICBjYXNlICdhY2NlcHRlZCc6IFxuICAgICAgICAgICAgY2FzZSAnZGl0ZXJpbWEnOiByZXR1cm4gJ2JnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCc7XG4gICAgICAgICAgICBjYXNlICdyZWplY3RlZCc6IFxuICAgICAgICAgICAgY2FzZSAnZGl0b2xhayc6IHJldHVybiAnYmctcmVkLTUwIHRleHQtcmVkLTYwMCBkYXJrOmJnLXJlZC05NTAvNjAgZGFyazp0ZXh0LXJlZC00MDAnO1xuICAgICAgICAgICAgZGVmYXVsdDogcmV0dXJuICdiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS01MDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCc7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZUluZGl2aWR1YWxTY29yZSA9IGFzeW5jIChyZXNwb25zZUlkLCBuZXdTY29yZSkgPT4ge1xuICAgICAgICBjb25zdCBwYXJzZWQgPSBNYXRoLm1heCgwLCBNYXRoLm1pbigxMDAsIHBhcnNlRmxvYXQobmV3U2NvcmUpIHx8IDApKTtcbiAgICAgICAgLy8gVXBkYXRlIGxvY2FsIGRpc3BsYXkgc3RhdGUgb3B0aW1pc3RpY2FsbHlcbiAgICAgICAgc2V0QW5hbHl0aWNzKHByZXYgPT4ge1xuICAgICAgICAgICAgaWYgKCFwcmV2Py5yZXNwb25kZW50cykgcmV0dXJuIHByZXY7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgcmVzcG9uZGVudHM6IHByZXYucmVzcG9uZGVudHMubWFwKHIgPT5cbiAgICAgICAgICAgICAgICAgICAgci5yZXNwb25zZUlkID09PSByZXNwb25zZUlkID8geyAuLi5yLCBzY29yZTogcGFyc2VkLCBpc0N1c3RvbVNjb3JlOiB0cnVlIH0gOiByXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSk7XG4gICAgICAgIHNldEVkaXRpbmdTY29yZUlkKG51bGwpO1xuICAgICAgICBzaG93VG9hc3QoYFNrb3IgcmVzcG9uZGVuICMke3Jlc3BvbnNlSWR9IGRpcGVyYmFydWkgbWVuamFkaSAke3BhcnNlZH0lYCk7XG4gICAgfTtcblxuICAgIGNvbnN0IG9wZW5SZXNwb25kZW50UmV2aWV3ID0gYXN5bmMgKHJlc3BvbmRlbnQpID0+IHtcbiAgICAgICAgY29uc3QgbG9jYWxPdmVycmlkZXMgPSBnZXRMb2NhbE1hbnVhbE92ZXJyaWRlcyhpZClbcmVzcG9uZGVudC5yZXNwb25zZUlkXSB8fCB7fTtcbiAgICAgICAgY29uc3QgY3VycmVudEFuc3dlcnMgPSAocmVzcG9uZGVudC5hbnN3ZXJzIHx8IFtdKS5tYXAoYSA9PiB7XG4gICAgICAgICAgICBjb25zdCBxRGVmID0gZm9ybVF1ZXN0aW9ucy5maW5kKHEgPT4gTnVtYmVyKHEuaWQpID09PSBOdW1iZXIoYS5xdWVzdGlvbklkKSk7XG4gICAgICAgICAgICBjb25zdCBrZXkgPSBhLmNvcnJlY3RBbnN3ZXIgfHwgcmVzb2x2ZVF1ZXN0aW9uS2V5KHFEZWYpO1xuICAgICAgICAgICAgY29uc3QgaGFzTG9jYWxPdmVycmlkZSA9IGxvY2FsT3ZlcnJpZGVzW2EucXVlc3Rpb25JZF0gIT09IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGNvbnN0IGVmZk92ZXJyaWRlID0gaGFzTG9jYWxPdmVycmlkZSA/IGxvY2FsT3ZlcnJpZGVzW2EucXVlc3Rpb25JZF0gOiBhLmlzQ29ycmVjdE92ZXJyaWRlO1xuICAgICAgICAgICAgY29uc3QgZWZmSXNDb3JyZWN0ID0gZ2V0RWZmZWN0aXZlSXNDb3JyZWN0KHsgLi4uYSwgaXNDb3JyZWN0T3ZlcnJpZGU6IGVmZk92ZXJyaWRlIH0sIHFEZWYpO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5hLFxuICAgICAgICAgICAgICAgIGNvcnJlY3RBbnN3ZXI6IGtleSxcbiAgICAgICAgICAgICAgICBpc0NvcnJlY3RPdmVycmlkZTogZWZmT3ZlcnJpZGUsXG4gICAgICAgICAgICAgICAgaXNDb3JyZWN0OiBlZmZJc0NvcnJlY3QsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaW5pdGlhbFNjb3JpbmcgPSBjYWxjdWxhdGVUb3RhbFNjb3JlKGN1cnJlbnRBbnN3ZXJzLCBmb3JtUXVlc3Rpb25zKTtcbiAgICAgICAgc2V0U2VsZWN0ZWRSZXNwb25kZW50KHtcbiAgICAgICAgICAgIC4uLnJlc3BvbmRlbnQsXG4gICAgICAgICAgICBhbnN3ZXJzOiBjdXJyZW50QW5zd2VycyxcbiAgICAgICAgICAgIGNvcnJlY3RDb3VudDogaW5pdGlhbFNjb3JpbmcuY29ycmVjdENvdW50LFxuICAgICAgICAgICAgd3JvbmdDb3VudDogaW5pdGlhbFNjb3Jpbmcud3JvbmdDb3VudCxcbiAgICAgICAgICAgIHNjb3JlOiBpbml0aWFsU2NvcmluZy5zY29yZSxcbiAgICAgICAgICAgIHRvdGFsUXVlc3Rpb25zOiBpbml0aWFsU2NvcmluZy50b3RhbFF1ZXN0aW9ucyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gQWx3YXlzIGxvYWQgZnVsbCByZXNwb25zZSByZXN1bHQgc28gYW5zd2VycyBjb250YWluIHByb3BlciBBbnN3ZXJJZCBhbmQgc2VydmVyLWNhbGN1bGF0ZWQgc2NvcmVzXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdldFJlc3BvbnNlUmVzdWx0KGlkLCByZXNwb25kZW50LnJlc3BvbnNlSWQpO1xuICAgICAgICBpZiAocmVzLm9rICYmIHJlcy5kYXRhKSB7XG4gICAgICAgICAgICBjb25zdCBzZXJ2ZXJBbnN3ZXJzID0gcmVzLmRhdGEuYW5zd2VycyB8fCByZXNwb25kZW50LmFuc3dlcnMgfHwgW107XG4gICAgICAgICAgICBjb25zdCBtZXJnZWRBbnN3ZXJzID0gc2VydmVyQW5zd2Vycy5tYXAoYSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgcURlZiA9IGZvcm1RdWVzdGlvbnMuZmluZChxID0+IE51bWJlcihxLmlkKSA9PT0gTnVtYmVyKGEucXVlc3Rpb25JZCkpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGtleSA9IGEuY29ycmVjdEFuc3dlciB8fCByZXNvbHZlUXVlc3Rpb25LZXkocURlZik7XG4gICAgICAgICAgICAgICAgY29uc3QgaGFzTG9jYWxPdmVycmlkZSA9IGxvY2FsT3ZlcnJpZGVzW2EucXVlc3Rpb25JZF0gIT09IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICBjb25zdCBlZmZlY3RpdmVPdmVycmlkZSA9IGhhc0xvY2FsT3ZlcnJpZGUgPyBsb2NhbE92ZXJyaWRlc1thLnF1ZXN0aW9uSWRdIDogYS5pc0NvcnJlY3RPdmVycmlkZTtcbiAgICAgICAgICAgICAgICBjb25zdCBlZmZJc0NvcnJlY3QgPSBnZXRFZmZlY3RpdmVJc0NvcnJlY3Qoe1xuICAgICAgICAgICAgICAgICAgICAuLi5hLFxuICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3RPdmVycmlkZTogZWZmZWN0aXZlT3ZlcnJpZGUsXG4gICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdDogYS5pc0NvcnJlY3QsXG4gICAgICAgICAgICAgICAgfSwgcURlZik7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAuLi5hLFxuICAgICAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiBrZXksXG4gICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdE92ZXJyaWRlOiBlZmZlY3RpdmVPdmVycmlkZSxcbiAgICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0OiBlZmZJc0NvcnJlY3QsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBjb25zdCBzY29yaW5nID0gY2FsY3VsYXRlVG90YWxTY29yZShtZXJnZWRBbnN3ZXJzLCBmb3JtUXVlc3Rpb25zKTtcblxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRSZXNwb25kZW50KHByZXYgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5yZXNwb25kZW50LFxuICAgICAgICAgICAgICAgIC4uLnJlcy5kYXRhLFxuICAgICAgICAgICAgICAgIGFuc3dlcnM6IG1lcmdlZEFuc3dlcnMsXG4gICAgICAgICAgICAgICAgY29ycmVjdENvdW50OiBzY29yaW5nLmNvcnJlY3RDb3VudCxcbiAgICAgICAgICAgICAgICB3cm9uZ0NvdW50OiBzY29yaW5nLndyb25nQ291bnQsXG4gICAgICAgICAgICAgICAgc2NvcmU6IHNjb3Jpbmcuc2NvcmUsXG4gICAgICAgICAgICAgICAgdG90YWxRdWVzdGlvbnM6IHNjb3JpbmcudG90YWxRdWVzdGlvbnMsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2V0UXVlc3Rpb25Db3JyZWN0ID0gYXN5bmMgKHJlc3BvbnNlSWQsIHF1ZXN0aW9uSWQsIHRhcmdldElzQ29ycmVjdCkgPT4ge1xuICAgICAgICBsZXQgc3JBbnN3ZXIgPSBzZWxlY3RlZFJlc3BvbmRlbnQ/LmFuc3dlcnM/LmZpbmQoYSA9PiBOdW1iZXIoYS5xdWVzdGlvbklkKSA9PT0gTnVtYmVyKHF1ZXN0aW9uSWQpKTtcbiAgICAgICAgbGV0IGFuc3dlcklkID0gc3JBbnN3ZXI/LmFuc3dlcklkIHx8IHNyQW5zd2VyPy5pZDtcblxuICAgICAgICBpZiAoIWFuc3dlcklkKSB7XG4gICAgICAgICAgICBjb25zdCBmcmVzaCA9IGF3YWl0IGdldFJlc3BvbnNlUmVzdWx0KGlkLCByZXNwb25zZUlkKTtcbiAgICAgICAgICAgIGlmIChmcmVzaC5vayAmJiBmcmVzaC5kYXRhPy5hbnN3ZXJzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZm91bmQgPSBmcmVzaC5kYXRhLmFuc3dlcnMuZmluZChhID0+IE51bWJlcihhLnF1ZXN0aW9uSWQpID09PSBOdW1iZXIocXVlc3Rpb25JZCkpO1xuICAgICAgICAgICAgICAgIGFuc3dlcklkID0gZm91bmQ/LmFuc3dlcklkIHx8IGZvdW5kPy5pZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHBhcnNlZEFuc3dlcklkID0gcGFyc2VJbnQoYW5zd2VySWQsIDEwKTtcbiAgICAgICAgaWYgKCFwYXJzZWRBbnN3ZXJJZCB8fCBpc05hTihwYXJzZWRBbnN3ZXJJZCkpIHtcbiAgICAgICAgICAgIHNob3dUb2FzdCgnVGlkYWsgZGFwYXQgbWVuZW11a2FuIElEIGphd2FiYW4gdmFsaWQgZGFyaSBzZXJ2ZXIuJywgJ2Vycm9yJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBvdmVycmlkZUFuc3dlclNjb3JlKHJlc3BvbnNlSWQsIHBhcnNlZEFuc3dlcklkLCB7XG4gICAgICAgICAgICBpc0NvcnJlY3RPdmVycmlkZTogdGFyZ2V0SXNDb3JyZWN0LFxuICAgICAgICAgICAgbWFudWFsU2NvcmU6IG51bGwsXG4gICAgICAgICAgICBvdmVycmlkZU5vdGU6ICdNYW51YWwgY29ycmVjdGlvbiBieSBmb3JtIG93bmVyJyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgc2F2ZUxvY2FsTWFudWFsT3ZlcnJpZGUoaWQsIHJlc3BvbnNlSWQsIHF1ZXN0aW9uSWQsIHRhcmdldElzQ29ycmVjdCk7XG5cbiAgICAgICAgICAgIHNldFNlbGVjdGVkUmVzcG9uZGVudChwcmV2ID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIXByZXYpIHJldHVybiBwcmV2O1xuICAgICAgICAgICAgICAgIGNvbnN0IG5ld0Fuc3dlcnMgPSAocHJldi5hbnN3ZXJzIHx8IFtdKS5tYXAoYSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChOdW1iZXIoYS5xdWVzdGlvbklkKSA9PT0gTnVtYmVyKHF1ZXN0aW9uSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5hLCBpc0NvcnJlY3RPdmVycmlkZTogdGFyZ2V0SXNDb3JyZWN0LCBpc0NvcnJlY3Q6IHRhcmdldElzQ29ycmVjdCB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGNvbnN0IHNjb3JpbmcgPSBjYWxjdWxhdGVUb3RhbFNjb3JlKG5ld0Fuc3dlcnMsIGZvcm1RdWVzdGlvbnMpO1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgICAgIGFuc3dlcnM6IG5ld0Fuc3dlcnMsXG4gICAgICAgICAgICAgICAgICAgIGNvcnJlY3RDb3VudDogc2NvcmluZy5jb3JyZWN0Q291bnQsXG4gICAgICAgICAgICAgICAgICAgIHdyb25nQ291bnQ6IHNjb3Jpbmcud3JvbmdDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgc2NvcmU6IHNjb3Jpbmcuc2NvcmUsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyBVcGRhdGUgcmVzcG9uZGVudCByb3cgaW4gdGFibGVcbiAgICAgICAgICAgIHNldEFuYWx5dGljcyhwcmV2ID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIXByZXY/LnJlc3BvbmRlbnRzKSByZXR1cm4gcHJldjtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgICAgICByZXNwb25kZW50czogcHJldi5yZXNwb25kZW50cy5tYXAociA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoci5yZXNwb25zZUlkICE9PSByZXNwb25zZUlkKSByZXR1cm4gcjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0Fuc3dlcnMgPSAoci5hbnN3ZXJzIHx8IFtdKS5tYXAoYSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKE51bWJlcihhLnF1ZXN0aW9uSWQpID09PSBOdW1iZXIocXVlc3Rpb25JZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgLi4uYSwgaXNDb3JyZWN0T3ZlcnJpZGU6IHRhcmdldElzQ29ycmVjdCwgaXNDb3JyZWN0OiB0YXJnZXRJc0NvcnJlY3QgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNjb3JpbmcgPSBjYWxjdWxhdGVUb3RhbFNjb3JlKG5ld0Fuc3dlcnMsIGZvcm1RdWVzdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5yLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcnM6IG5ld0Fuc3dlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29ycmVjdENvdW50OiBzY29yaW5nLmNvcnJlY3RDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3cm9uZ0NvdW50OiBzY29yaW5nLndyb25nQ291bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2NvcmU6IHNjb3Jpbmcuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDdXN0b21TY29yZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBzaG93VG9hc3QoYFN0YXR1cyBzb2FsIGRpdWJhaCBtZW5qYWRpICR7dGFyZ2V0SXNDb3JyZWN0ID8gJ0JlbmFyJyA6ICdTYWxhaCd9YCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbmd1YmFoIHN0YXR1cyBzb2FsLicsICdlcnJvcicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIEJVRy0zIEZJWDogcGFydGlhbCBzY29yZSBvdmVycmlkZSBmb3IgZXNzYXkgYW5zd2Vycy5cbiAgICAvLyBwY3RTdHIgaXMgYSBzdHJpbmcgXCIwXCLigJNcIjEwMFwiLiBDb252ZXJ0cyB0byByYXcgZWFybmVkIHBvaW50cyByZWxhdGl2ZSB0byB0aGVcbiAgICAvLyBxdWVzdGlvbiB3ZWlnaHQgYW5kIHNlbmRzIHRvIHRoZSBiYWNrZW5kJ3MgZXhpc3RpbmcgbWFudWFsU2NvcmUgZmllbGQuXG4gICAgLy8gVGhlIGJvb2xlYW4gaXNDb3JyZWN0T3ZlcnJpZGUgaXMgc2V0IHRvIHRydWUgd2hlbiBwY3QgPiAwIHNvIHRoZSBhbnN3ZXIgaXNcbiAgICAvLyBub3Qgc2hvd24gYXMgXCJTYWxhaFwiIGluIHRoZSBVSSwgYW5kIGZhbHNlIG9ubHkgd2hlbiBwY3QgPT09IDAuXG4gICAgY29uc3QgaGFuZGxlU2V0UGFydGlhbFNjb3JlID0gYXN5bmMgKHJlc3BvbnNlSWQsIHF1ZXN0aW9uSWQsIGFuc3dlcklkLCBwY3RTdHIsIHFQb2ludHMpID0+IHtcbiAgICAgICAgY29uc3QgcGN0ID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMTAwLCBwYXJzZUZsb2F0KHBjdFN0cikgfHwgMCkpO1xuICAgICAgICBjb25zdCByYXdQb2ludHMgPSBNYXRoLnJvdW5kKChwY3QgLyAxMDApICogcVBvaW50cyAqIDEwMCkgLyAxMDA7IC8vIHJhdyBlYXJuZWQgcG9pbnRzXG4gICAgICAgIGNvbnN0IGlzQ29ycmVjdE92ZXJyaWRlID0gcGN0ID4gMDtcblxuICAgICAgICBjb25zdCBwYXJzZWRBbnN3ZXJJZCA9IHBhcnNlSW50KGFuc3dlcklkLCAxMCk7XG4gICAgICAgIGlmICghcGFyc2VkQW5zd2VySWQgfHwgaXNOYU4ocGFyc2VkQW5zd2VySWQpKSB7XG4gICAgICAgICAgICAvLyBmZXRjaCBhbnN3ZXJJZCBvbiBkZW1hbmQgKHNhbWUgZmFsbGJhY2sgYXMgaGFuZGxlU2V0UXVlc3Rpb25Db3JyZWN0KVxuICAgICAgICAgICAgY29uc3QgZnJlc2ggPSBhd2FpdCBnZXRSZXNwb25zZVJlc3VsdChpZCwgcmVzcG9uc2VJZCk7XG4gICAgICAgICAgICBpZiAoZnJlc2gub2sgJiYgZnJlc2guZGF0YT8uYW5zd2Vycykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gZnJlc2guZGF0YS5hbnN3ZXJzLmZpbmQoYSA9PiBOdW1iZXIoYS5xdWVzdGlvbklkKSA9PT0gTnVtYmVyKHF1ZXN0aW9uSWQpKTtcbiAgICAgICAgICAgICAgICBjb25zdCBmZXRjaGVkSWQgPSBmb3VuZD8uYW5zd2VySWQgfHwgZm91bmQ/LmlkO1xuICAgICAgICAgICAgICAgIGlmICghZmV0Y2hlZElkKSB7IHNob3dUb2FzdCgnSUQgamF3YWJhbiB0aWRhayBkaXRlbXVrYW4uJywgJ2Vycm9yJyk7IHJldHVybjsgfVxuICAgICAgICAgICAgICAgIHJldHVybiBoYW5kbGVTZXRQYXJ0aWFsU2NvcmUocmVzcG9uc2VJZCwgcXVlc3Rpb25JZCwgZmV0Y2hlZElkLCBwY3RTdHIsIHFQb2ludHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2hvd1RvYXN0KCdJRCBqYXdhYmFuIHRpZGFrIGRpdGVtdWthbi4nLCAnZXJyb3InKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IG92ZXJyaWRlQW5zd2VyU2NvcmUocmVzcG9uc2VJZCwgcGFyc2VkQW5zd2VySWQsIHtcbiAgICAgICAgICAgIGlzQ29ycmVjdE92ZXJyaWRlLFxuICAgICAgICAgICAgbWFudWFsU2NvcmU6IHJhd1BvaW50cyxcbiAgICAgICAgICAgIG92ZXJyaWRlTm90ZTogYFNrb3IgcGFyc2lhbCAke3BjdH0lIG9sZWggcGVtaWxpayBmb3JtdWxpcmAsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIC8vIFBlcnNpc3QgbG9jYWxseSAoZXh0ZW5kIGV4aXN0aW5nIG92ZXJyaWRlIG1hcCB3aXRoIG1hbnVhbFNjb3JlIGluZm8pXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGN1ciA9IGdldExvY2FsTWFudWFsT3ZlcnJpZGVzKGlkKTtcbiAgICAgICAgICAgICAgICBpZiAoIWN1cltyZXNwb25zZUlkXSkgY3VyW3Jlc3BvbnNlSWRdID0ge307XG4gICAgICAgICAgICAgICAgY3VyW3Jlc3BvbnNlSWRdW3F1ZXN0aW9uSWRdID0geyBpc0NvcnJlY3Q6IGlzQ29ycmVjdE92ZXJyaWRlLCBtYW51YWxTY29yZTogcmF3UG9pbnRzLCBwY3QgfTtcbiAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShgZm9ybXVwX292ZXJyaWRlc18ke2lkfWAsIEpTT04uc3RyaW5naWZ5KGN1cikpO1xuICAgICAgICAgICAgfSBjYXRjaCB7fVxuXG4gICAgICAgICAgICAvLyBVcGRhdGUgcmV2aWV3IG1vZGFsIHN0YXRlXG4gICAgICAgICAgICBzZXRTZWxlY3RlZFJlc3BvbmRlbnQocHJldiA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFwcmV2KSByZXR1cm4gcHJldjtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXdBbnN3ZXJzID0gKHByZXYuYW5zd2VycyB8fCBbXSkubWFwKGEgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoTnVtYmVyKGEucXVlc3Rpb25JZCkgPT09IE51bWJlcihxdWVzdGlvbklkKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5hLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdE92ZXJyaWRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdDogaXNDb3JyZWN0T3ZlcnJpZGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFudWFsU2NvcmU6IHJhd1BvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGE7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2NvcmluZyA9IGNhbGN1bGF0ZVRvdGFsU2NvcmUobmV3QW5zd2VycywgZm9ybVF1ZXN0aW9ucyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgYW5zd2VyczogbmV3QW5zd2VycyxcbiAgICAgICAgICAgICAgICAgICAgY29ycmVjdENvdW50OiBzY29yaW5nLmNvcnJlY3RDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgd3JvbmdDb3VudDogc2NvcmluZy53cm9uZ0NvdW50LFxuICAgICAgICAgICAgICAgICAgICBzY29yZTogc2NvcmluZy5zY29yZSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIC8vIFVwZGF0ZSByZXNwb25kZW50IHJvdyBpbiBzdW1tYXJ5IHRhYmxlXG4gICAgICAgICAgICBzZXRBbmFseXRpY3MocHJldiA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFwcmV2Py5yZXNwb25kZW50cykgcmV0dXJuIHByZXY7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uZGVudHM6IHByZXYucmVzcG9uZGVudHMubWFwKHIgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHIucmVzcG9uc2VJZCAhPT0gcmVzcG9uc2VJZCkgcmV0dXJuIHI7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdBbnN3ZXJzID0gKHIuYW5zd2VycyB8fCBbXSkubWFwKGEgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChOdW1iZXIoYS5xdWVzdGlvbklkKSA9PT0gTnVtYmVyKHF1ZXN0aW9uSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5hLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0T3ZlcnJpZGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3Q6IGlzQ29ycmVjdE92ZXJyaWRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFudWFsU2NvcmU6IHJhd1BvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNjb3JpbmcgPSBjYWxjdWxhdGVUb3RhbFNjb3JlKG5ld0Fuc3dlcnMsIGZvcm1RdWVzdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5yLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcnM6IG5ld0Fuc3dlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29ycmVjdENvdW50OiBzY29yaW5nLmNvcnJlY3RDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3cm9uZ0NvdW50OiBzY29yaW5nLndyb25nQ291bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2NvcmU6IHNjb3Jpbmcuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDdXN0b21TY29yZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgc2V0UGFydGlhbFNjb3JlRWRpdGluZ0lkKG51bGwpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KGBTa29yIHBhcnNpYWwgJHtwY3R9JSAoJHtyYXdQb2ludHN9IHBvaW4pIGJlcmhhc2lsIGRpc2ltcGFuYCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbnlpbXBhbiBza29yIHBhcnNpYWwuJywgJ2Vycm9yJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gQi0yOiBTYXZlIGNvbXBsZXRlIGNvcnJlY3Rpb24gKHBhcnRpYWwgc2NvcmUgKyBleHBsaWNpdCBpc0NvcnJlY3RPdmVycmlkZSArIG92ZXJyaWRlTm90ZSlcbiAgICBjb25zdCBoYW5kbGVTYXZlQ29tcGxldGVDb3JyZWN0aW9uID0gYXN5bmMgKHJlc3BvbnNlSWQsIHF1ZXN0aW9uSWQsIGFuc3dlcklkLCBxUG9pbnRzKSA9PiB7XG4gICAgICAgIGNvbnN0IHBhcnNlZEFuc3dlcklkID0gcGFyc2VJbnQoYW5zd2VySWQsIDEwKTtcbiAgICAgICAgbGV0IGZpbmFsQW5zd2VySWQgPSBwYXJzZWRBbnN3ZXJJZDtcbiAgICAgICAgaWYgKCFwYXJzZWRBbnN3ZXJJZCB8fCBpc05hTihwYXJzZWRBbnN3ZXJJZCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGZyZXNoID0gYXdhaXQgZ2V0UmVzcG9uc2VSZXN1bHQoaWQsIHJlc3BvbnNlSWQpO1xuICAgICAgICAgICAgaWYgKGZyZXNoLm9rICYmIGZyZXNoLmRhdGE/LmFuc3dlcnMpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmb3VuZCA9IGZyZXNoLmRhdGEuYW5zd2Vycy5maW5kKGEgPT4gTnVtYmVyKGEucXVlc3Rpb25JZCkgPT09IE51bWJlcihxdWVzdGlvbklkKSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZmV0Y2hlZElkID0gZm91bmQ/LmFuc3dlcklkIHx8IGZvdW5kPy5pZDtcbiAgICAgICAgICAgICAgICBpZiAoIWZldGNoZWRJZCkgeyBzaG93VG9hc3QoJ0lEIGphd2FiYW4gdGlkYWsgZGl0ZW11a2FuLicsICdlcnJvcicpOyByZXR1cm47IH1cbiAgICAgICAgICAgICAgICBmaW5hbEFuc3dlcklkID0gcGFyc2VJbnQoZmV0Y2hlZElkLCAxMCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHNob3dUb2FzdCgnSUQgamF3YWJhbiB0aWRhayBkaXRlbXVrYW4uJywgJ2Vycm9yJyk7IHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBmaW5hbE1hbnVhbFNjb3JlID0gbnVsbDtcbiAgICAgICAgbGV0IGZpbmFsSXNDb3JyZWN0T3ZlcnJpZGUgPSBjb3JyZWN0aW9uSXNDb3JyZWN0T3ZlcnJpZGU7XG5cbiAgICAgICAgaWYgKHBhcnRpYWxTY29yZUVkaXRpbmdJZCA9PT0gYW5zd2VySWQgfHwgcGFydGlhbFNjb3JlRWRpdGluZ0lkID09PSBxdWVzdGlvbklkKSB7XG4gICAgICAgICAgICBjb25zdCBwY3QgPSBNYXRoLm1heCgwLCBNYXRoLm1pbigxMDAsIHBhcnNlRmxvYXQocGFydGlhbFNjb3JlSW5wdXQpIHx8IDApKTtcbiAgICAgICAgICAgIGZpbmFsTWFudWFsU2NvcmUgPSBNYXRoLnJvdW5kKChwY3QgLyAxMDApICogcVBvaW50cyAqIDEwMCkgLyAxMDA7XG4gICAgICAgICAgICBpZiAoZmluYWxJc0NvcnJlY3RPdmVycmlkZSA9PT0gdW5kZWZpbmVkIHx8IGZpbmFsSXNDb3JyZWN0T3ZlcnJpZGUgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICBmaW5hbElzQ29ycmVjdE92ZXJyaWRlID0gcGN0ID4gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChmaW5hbElzQ29ycmVjdE92ZXJyaWRlID09PSB1bmRlZmluZWQgfHwgZmluYWxJc0NvcnJlY3RPdmVycmlkZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudEFuc3dlciA9IChzZWxlY3RlZFJlc3BvbmRlbnQ/LmFuc3dlcnMgfHwgW10pLmZpbmQoYSA9PiBOdW1iZXIoYS5xdWVzdGlvbklkKSA9PT0gTnVtYmVyKHF1ZXN0aW9uSWQpKTtcbiAgICAgICAgICAgIGZpbmFsSXNDb3JyZWN0T3ZlcnJpZGUgPSBjdXJyZW50QW5zd2VyPy5pc0NvcnJlY3RPdmVycmlkZSA/PyBjdXJyZW50QW5zd2VyPy5pc0NvcnJlY3QgPz8gZmFsc2U7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgICAgICAgaXNDb3JyZWN0T3ZlcnJpZGU6IGZpbmFsSXNDb3JyZWN0T3ZlcnJpZGUsXG4gICAgICAgICAgICBtYW51YWxTY29yZTogZmluYWxNYW51YWxTY29yZSxcbiAgICAgICAgICAgIG92ZXJyaWRlTm90ZTogY29ycmVjdGlvbk5vdGU/LnRyaW0oKSB8fCBudWxsLFxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IG92ZXJyaWRlQW5zd2VyU2NvcmUocmVzcG9uc2VJZCwgZmluYWxBbnN3ZXJJZCwgcGF5bG9hZCk7XG5cbiAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjdXIgPSBnZXRMb2NhbE1hbnVhbE92ZXJyaWRlcyhpZCk7XG4gICAgICAgICAgICAgICAgaWYgKCFjdXJbcmVzcG9uc2VJZF0pIGN1cltyZXNwb25zZUlkXSA9IHt9O1xuICAgICAgICAgICAgICAgIGNvbnN0IHBjdFZhbCA9IGZpbmFsTWFudWFsU2NvcmUgIT0gbnVsbFxuICAgICAgICAgICAgICAgICAgICA/IE1hdGgucm91bmQoKE51bWJlcihmaW5hbE1hbnVhbFNjb3JlKSAvIHFQb2ludHMpICogMTAwKVxuICAgICAgICAgICAgICAgICAgICA6IChmaW5hbElzQ29ycmVjdE92ZXJyaWRlID8gMTAwIDogMCk7XG4gICAgICAgICAgICAgICAgY3VyW3Jlc3BvbnNlSWRdW3F1ZXN0aW9uSWRdID0ge1xuICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3Q6IGZpbmFsSXNDb3JyZWN0T3ZlcnJpZGUsXG4gICAgICAgICAgICAgICAgICAgIG1hbnVhbFNjb3JlOiBmaW5hbE1hbnVhbFNjb3JlLFxuICAgICAgICAgICAgICAgICAgICBwY3Q6IHBjdFZhbCxcbiAgICAgICAgICAgICAgICAgICAgbm90ZTogY29ycmVjdGlvbk5vdGU/LnRyaW0oKSB8fCBudWxsLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oYGZvcm11cF9vdmVycmlkZXNfJHtpZH1gLCBKU09OLnN0cmluZ2lmeShjdXIpKTtcbiAgICAgICAgICAgIH0gY2F0Y2gge31cblxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRSZXNwb25kZW50KHByZXYgPT4ge1xuICAgICAgICAgICAgICAgIGlmICghcHJldikgcmV0dXJuIHByZXY7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV3QW5zd2VycyA9IChwcmV2LmFuc3dlcnMgfHwgW10pLm1hcChhID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKE51bWJlcihhLnF1ZXN0aW9uSWQpID09PSBOdW1iZXIocXVlc3Rpb25JZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uYSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3RPdmVycmlkZTogZmluYWxJc0NvcnJlY3RPdmVycmlkZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3Q6IGZpbmFsSXNDb3JyZWN0T3ZlcnJpZGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFudWFsU2NvcmU6IGZpbmFsTWFudWFsU2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3ZlcnJpZGVOb3RlOiBwYXlsb2FkLm92ZXJyaWRlTm90ZSA/PyBhLm92ZXJyaWRlTm90ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGE7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2NvcmluZyA9IGNhbGN1bGF0ZVRvdGFsU2NvcmUobmV3QW5zd2VycywgZm9ybVF1ZXN0aW9ucyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgYW5zd2VyczogbmV3QW5zd2VycyxcbiAgICAgICAgICAgICAgICAgICAgY29ycmVjdENvdW50OiBzY29yaW5nLmNvcnJlY3RDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgd3JvbmdDb3VudDogc2NvcmluZy53cm9uZ0NvdW50LFxuICAgICAgICAgICAgICAgICAgICBzY29yZTogc2NvcmluZy5zY29yZSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHNldEFuYWx5dGljcyhwcmV2ID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIXByZXY/LnJlc3BvbmRlbnRzKSByZXR1cm4gcHJldjtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgICAgICByZXNwb25kZW50czogcHJldi5yZXNwb25kZW50cy5tYXAociA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoci5yZXNwb25zZUlkICE9PSByZXNwb25zZUlkKSByZXR1cm4gcjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0Fuc3dlcnMgPSAoci5hbnN3ZXJzIHx8IFtdKS5tYXAoYSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKE51bWJlcihhLnF1ZXN0aW9uSWQpID09PSBOdW1iZXIocXVlc3Rpb25JZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3RPdmVycmlkZTogZmluYWxJc0NvcnJlY3RPdmVycmlkZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdDogZmluYWxJc0NvcnJlY3RPdmVycmlkZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hbnVhbFNjb3JlOiBmaW5hbE1hbnVhbFNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3ZlcnJpZGVOb3RlOiBwYXlsb2FkLm92ZXJyaWRlTm90ZSA/PyBhLm92ZXJyaWRlTm90ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNjb3JpbmcgPSBjYWxjdWxhdGVUb3RhbFNjb3JlKG5ld0Fuc3dlcnMsIGZvcm1RdWVzdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5yLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcnM6IG5ld0Fuc3dlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29ycmVjdENvdW50OiBzY29yaW5nLmNvcnJlY3RDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3cm9uZ0NvdW50OiBzY29yaW5nLndyb25nQ291bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2NvcmU6IHNjb3Jpbmcuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDdXN0b21TY29yZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgc2V0QWN0aXZlQ29ycmVjdGlvbklkKG51bGwpO1xuICAgICAgICAgICAgc2V0UGFydGlhbFNjb3JlRWRpdGluZ0lkKG51bGwpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KCdLb3Jla3NpIGphd2FiYW4gYmVyaGFzaWwgZGlzaW1wYW4uJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbnlpbXBhbiBrb3Jla3NpLicsICdlcnJvcicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIEEtODogSG9saXN0aWMgQUkgYW5hbHlzaXMg4oCUIGtpcmltIHNlbXVhIGphd2FiYW4gZXNzYXkgKyByaW5na2FzYW4gUEcgc2VrYWxpZ3VzXG4gICAgY29uc3QgaGFuZGxlQWlIb2xpc3RpY1Njb3JlID0gYXN5bmMgKHJlc3BvbmRlbnQpID0+IHtcbiAgICAgICAgbGV0IGFuc3dlcnMgPSByZXNwb25kZW50LmFuc3dlcnMgfHwgW107XG4gICAgICAgIGNvbnN0IGhhc01pc3NpbmdBbnN3ZXJJZCA9IGFuc3dlcnMuc29tZShhID0+ICFhLmFuc3dlcklkICYmICFhLmlkKTtcbiAgICAgICAgaWYgKGhhc01pc3NpbmdBbnN3ZXJJZCB8fCBhbnN3ZXJzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgY29uc3QgZnJlc2ggPSBhd2FpdCBnZXRSZXNwb25zZVJlc3VsdChpZCwgcmVzcG9uZGVudC5yZXNwb25zZUlkKTtcbiAgICAgICAgICAgIGlmIChmcmVzaC5vayAmJiBmcmVzaC5kYXRhPy5hbnN3ZXJzKSB7XG4gICAgICAgICAgICAgICAgYW5zd2VycyA9IGZyZXNoLmRhdGEuYW5zd2VycztcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFJlc3BvbmRlbnQocHJldiA9PiAoeyAuLi5wcmV2LCAuLi5mcmVzaC5kYXRhIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGVzc2F5QW5zd2VycyA9IGFuc3dlcnMuZmlsdGVyKGEgPT4gYS50eXBlSWQgPT09IDEpO1xuICAgICAgICBpZiAoZXNzYXlBbnN3ZXJzLmxlbmd0aCA9PT0gMCkgeyBzaG93VG9hc3QoJ1RpZGFrIGFkYSBzb2FsIGVzc2F5IGRhbGFtIHN1Ym1pc3Npb24gaW5pLicsICdlcnJvcicpOyByZXR1cm47IH1cblxuICAgICAgICBzZXRBaUhvbGlzdGljU2NvcmluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHBnQW5zd2VycyA9IGFuc3dlcnMuZmlsdGVyKGEgPT4gYS50eXBlSWQgIT09IDEpO1xuICAgICAgICAgICAgY29uc3QgcGdDb3JyZWN0ID0gcGdBbnN3ZXJzLmZpbHRlcihhID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBxRGVmID0gKGZvcm1RdWVzdGlvbnMgfHwgW10pLmZpbmQocSA9PiBOdW1iZXIocS5pZCkgPT09IE51bWJlcihhLnF1ZXN0aW9uSWQpKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2V0RWZmZWN0aXZlSXNDb3JyZWN0KGEsIHFEZWYpID09PSB0cnVlO1xuICAgICAgICAgICAgfSkubGVuZ3RoO1xuICAgICAgICAgICAgY29uc3QgcGdUb3RhbCA9IHBnQW5zd2Vycy5sZW5ndGg7XG5cbiAgICAgICAgICAgIGNvbnN0IGVzc2F5U2VjdGlvbkFuc3dlcnMgPSBlc3NheUFuc3dlcnMubWFwKChhKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgcURlZiA9IChmb3JtUXVlc3Rpb25zIHx8IFtdKS5maW5kKHEgPT4gTnVtYmVyKHEuaWQpID09PSBOdW1iZXIoYS5xdWVzdGlvbklkKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4uYSxcbiAgICAgICAgICAgICAgICAgICAgY29ycmVjdEFuc3dlcjogYS5jb3JyZWN0QW5zd2VyIHx8IHJlc29sdmVRdWVzdGlvbktleShxRGVmKSB8fCAnKHRpZGFrIGFkYSBrdW5jaSknXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBjb25zdCBwZ1NlY3Rpb24gPSBwZ1RvdGFsID4gMCA/IGBcXG5cXG5SaW5na2FzYW4gUEc6ICR7cGdDb3JyZWN0fS8ke3BnVG90YWx9IGJlbmFyICgke01hdGgucm91bmQoKHBnQ29ycmVjdC9wZ1RvdGFsKSoxMDApfSUpYCA6ICcnO1xuXG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBzY29yZUhvbGlzdGljRXNzYXlXaXRoQUkoe1xuICAgICAgICAgICAgICAgIGVzc2F5QW5zd2VyczogZXNzYXlTZWN0aW9uQW5zd2VycyxcbiAgICAgICAgICAgICAgICBwZ1NlY3Rpb24sXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRNb2RlbDogYWlNb2RlbCxcbiAgICAgICAgICAgICAgICBjdXN0b21BcGlLZXk6IGdldEdlbWluaUFwaUtleSgpLFxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW5pbGFpIGVzc2F5IGRlbmdhbiBBSS4nLCAnZXJyb3InKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IHN1Z2dlc3Rpb25zID0gcmVzLmRhdGEgfHwgW107XG5cbiAgICAgICAgICAgIC8vIE1hcCBzdWdnZXN0aW9ucyBiYWNrIHRvIGFuc3dlciBvYmplY3RzXG4gICAgICAgICAgICBjb25zdCBtYXBwZWQgPSBzdWdnZXN0aW9ucy5tYXAoKHMsIGkpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBhbnN3ZXIgPSBlc3NheUFuc3dlcnNbaV07XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgYW5zd2VyLCBzdWdnZXN0aW9uOiBzLCBhbnN3ZXJJZDogcy5hbnN3ZXJJZCB8fCBhbnN3ZXI/LmFuc3dlcklkIHx8IGFuc3dlcj8uaWQgfTtcbiAgICAgICAgICAgIH0pLmZpbHRlcih4ID0+IHguYW5zd2VyKTtcblxuICAgICAgICAgICAgLy8gQ2FsY3VsYXRlIGVzdGltYXRlZCB0b3RhbCBzY29yZSB1c2luZyBjYWxjdWxhdGVUb3RhbFNjb3JlXG4gICAgICAgICAgICBjb25zdCBzaW11bGF0ZWRBbnN3ZXJzID0gKHNlbGVjdGVkUmVzcG9uZGVudD8uYW5zd2VycyB8fCBbXSkubWFwKGEgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG1hdGNoZWRTdWcgPSBtYXBwZWQuZmluZCh4ID0+IE51bWJlcih4LmFuc3dlcj8ucXVlc3Rpb25JZCkgPT09IE51bWJlcihhLnF1ZXN0aW9uSWQpKTtcbiAgICAgICAgICAgICAgICBpZiAobWF0Y2hlZFN1Zykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5hLCBpc0NvcnJlY3Q6IG1hdGNoZWRTdWcuc3VnZ2VzdGlvbi5pc0NvcnJlY3QsIGlzQ29ycmVjdE92ZXJyaWRlOiBtYXRjaGVkU3VnLnN1Z2dlc3Rpb24uaXNDb3JyZWN0IH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHFEZWYgPSAoZm9ybVF1ZXN0aW9ucyB8fCBbXSkuZmluZChxID0+IE51bWJlcihxLmlkKSA9PT0gTnVtYmVyKGEucXVlc3Rpb25JZCkpO1xuICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLmEsIGlzQ29ycmVjdDogZ2V0RWZmZWN0aXZlSXNDb3JyZWN0KGEsIHFEZWYpIH07XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnN0IHNpbVNjb3JpbmcgPSBjYWxjdWxhdGVUb3RhbFNjb3JlKHNpbXVsYXRlZEFuc3dlcnMsIGZvcm1RdWVzdGlvbnMpO1xuICAgICAgICAgICAgY29uc3QgdG90YWxFc3RpbWF0ZSA9IHNpbVNjb3Jpbmcuc2NvcmU7XG5cbiAgICAgICAgICAgIHNldEFpSG9saXN0aWNSZXN1bHQoeyBlc3NheVN1Z2dlc3Rpb25zOiBtYXBwZWQsIHBnU3VtbWFyeTogcGdUb3RhbCA+IDAgPyBgJHtwZ0NvcnJlY3R9LyR7cGdUb3RhbH0gYmVuYXJgIDogbnVsbCwgdG90YWxFc3RpbWF0ZSB9KTtcbiAgICAgICAgICAgIHNldEFpSG9saXN0aWNQcmV2aWV3T3Blbih0cnVlKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ0dhZ2FsIGFuYWxpc2lzIEFJOiAnICsgZXJyLm1lc3NhZ2UsICdlcnJvcicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0QWlIb2xpc3RpY1Njb3JpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIEEtODogQXBwbHkgYWxsIEFJIHN1Z2dlc3Rpb25zIGF0IG9uY2UgdmlhIGJ1bGsgZW5kcG9pbnRcbiAgICAgICAgLy8gQS04OiBBcHBseSBhbGwgQUkgc3VnZ2VzdGlvbnMgYXQgb25jZSB2aWEgYnVsayBlbmRwb2ludFxuICAgIGNvbnN0IGhhbmRsZUFwcGx5QWxsQWlTY29yZXMgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghYWlIb2xpc3RpY1Jlc3VsdCB8fCAhc2VsZWN0ZWRSZXNwb25kZW50KSByZXR1cm47XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlSWQgPSBzZWxlY3RlZFJlc3BvbmRlbnQucmVzcG9uc2VJZDtcbiAgICAgICAgY29uc3Qgb3ZlcnJpZGVzID0gYWlIb2xpc3RpY1Jlc3VsdC5lc3NheVN1Z2dlc3Rpb25zXG4gICAgICAgICAgICAubWFwKHggPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFJZCA9IHBhcnNlSW50KHguYW5zd2VySWQsIDEwKTtcbiAgICAgICAgICAgICAgICBpZiAoIWFJZCB8fCBpc05hTihhSWQpKSByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICAvLyBGSVg6IGNvbnZlcnQgdGhlIEFJJ3MgcGVyY2VudGFnZSBzY29yZSBpbnRvIHJhdyBlYXJuZWQgcG9pbnRzXG4gICAgICAgICAgICAgICAgLy8gKG1hbnVhbFNjb3JlKSwgdGhlIHNhbWUgdW5pdCBjYWxjdWxhdGVUb3RhbFNjb3JlIGV4cGVjdHMgZm9yXG4gICAgICAgICAgICAgICAgLy8gcGFydGlhbCBjcmVkaXQuIFNlbmRpbmcgbWFudWFsU2NvcmU6IG51bGwgZGlzY2FyZGVkIHRoZSBBSSdzXG4gICAgICAgICAgICAgICAgLy8gYWN0dWFsIHNjb3JlIGFuZCBmZWxsIGJhY2sgdG8gdGhlIGJvb2xlYW4gaXNDb3JyZWN0T3ZlcnJpZGVcbiAgICAgICAgICAgICAgICAvLyBwYXRoLCB3aGljaCBhbHdheXMgYXdhcmRzIGZ1bGwgcG9pbnRzIOKAlCB0dXJuaW5nIGEgOTUlIGVzc2F5XG4gICAgICAgICAgICAgICAgLy8gaW50byAxMDAlIG9uY2UgYXBwbGllZC5cbiAgICAgICAgICAgICAgICBjb25zdCBxRGVmID0gKGZvcm1RdWVzdGlvbnMgfHwgW10pLmZpbmQocSA9PiBOdW1iZXIocS5pZCkgPT09IE51bWJlcih4LmFuc3dlcj8ucXVlc3Rpb25JZCkpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHFQb2ludHMgPSBxRGVmICYmIE51bWJlcihxRGVmLnBvaW50cykgPiAwID8gTnVtYmVyKHFEZWYucG9pbnRzKSA6IDE7XG4gICAgICAgICAgICAgICAgY29uc3QgcGN0ID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMTAwLCBOdW1iZXIoeC5zdWdnZXN0aW9uLnNjb3JlKSB8fCAwKSk7XG4gICAgICAgICAgICAgICAgY29uc3QgcmF3UG9pbnRzID0gTWF0aC5yb3VuZCgocGN0IC8gMTAwKSAqIHFQb2ludHMgKiAxMDApIC8gMTAwO1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIGFuc3dlcklkOiBhSWQsXG4gICAgICAgICAgICAgICAgICAgIG1hbnVhbFNjb3JlOiByYXdQb2ludHMsXG4gICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdE92ZXJyaWRlOiBwY3QgPiAwLFxuICAgICAgICAgICAgICAgICAgICBvdmVycmlkZU5vdGU6IGBBSSBIb2xpc3RpYzogJHt4LnN1Z2dlc3Rpb24ucmVhc29ufSAoTmlsYWk6ICR7eC5zdWdnZXN0aW9uLnNjb3JlfSlgLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKTtcblxuICAgICAgICBpZiAob3ZlcnJpZGVzLmxlbmd0aCA9PT0gMCkgeyBzaG93VG9hc3QoJ1RpZGFrIGFkYSBqYXdhYmFuIGRlbmdhbiBJRCB2YWxpZCB1bnR1ayBkaS1hcHBseS4nLCAnZXJyb3InKTsgcmV0dXJuOyB9XG5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYnVsa092ZXJyaWRlQW5zd2VyU2NvcmVzKHJlc3BvbnNlSWQsIG92ZXJyaWRlcyk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIG92ZXJyaWRlcy5mb3JFYWNoKG8gPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG1hdGNoZWRFc3NheSA9IGFpSG9saXN0aWNSZXN1bHQuZXNzYXlTdWdnZXN0aW9ucy5maW5kKHggPT4gcGFyc2VJbnQoeC5hbnN3ZXJJZCwgMTApID09PSBvLmFuc3dlcklkKTtcbiAgICAgICAgICAgICAgICBjb25zdCBxSWQgPSBtYXRjaGVkRXNzYXk/LmFuc3dlcj8ucXVlc3Rpb25JZDtcbiAgICAgICAgICAgICAgICBpZiAocUlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHNhdmVMb2NhbE1hbnVhbE92ZXJyaWRlKGlkLCByZXNwb25zZUlkLCBxSWQsIG8uaXNDb3JyZWN0T3ZlcnJpZGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFJlc3BvbmRlbnQocHJldiA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFwcmV2KSByZXR1cm4gcHJldjtcbiAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkQW5zd2VycyA9IChwcmV2LmFuc3dlcnMgfHwgW10pLm1hcChhID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbWF0Y2hlZFN1ZyA9IGFpSG9saXN0aWNSZXN1bHQuZXNzYXlTdWdnZXN0aW9ucy5maW5kKHggPT4gTnVtYmVyKHguYW5zd2VyPy5xdWVzdGlvbklkKSA9PT0gTnVtYmVyKGEucXVlc3Rpb25JZCkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWF0Y2hlZFN1Zykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcURlZiA9IChmb3JtUXVlc3Rpb25zIHx8IFtdKS5maW5kKHEgPT4gTnVtYmVyKHEuaWQpID09PSBOdW1iZXIoYS5xdWVzdGlvbklkKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBxUG9pbnRzID0gcURlZiAmJiBOdW1iZXIocURlZi5wb2ludHMpID4gMCA/IE51bWJlcihxRGVmLnBvaW50cykgOiAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGN0ID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMTAwLCBOdW1iZXIobWF0Y2hlZFN1Zy5zdWdnZXN0aW9uLnNjb3JlKSB8fCAwKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByYXdQb2ludHMgPSBNYXRoLnJvdW5kKChwY3QgLyAxMDApICogcVBvaW50cyAqIDEwMCkgLyAxMDA7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0T3ZlcnJpZGU6IHBjdCA+IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0OiBwY3QgPiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hbnVhbFNjb3JlOiByYXdQb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGNvbnN0IHNjb3JpbmcgPSBjYWxjdWxhdGVUb3RhbFNjb3JlKHVwZGF0ZWRBbnN3ZXJzLCBmb3JtUXVlc3Rpb25zKTtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgICAgICBhbnN3ZXJzOiB1cGRhdGVkQW5zd2VycyxcbiAgICAgICAgICAgICAgICAgICAgY29ycmVjdENvdW50OiBzY29yaW5nLmNvcnJlY3RDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgd3JvbmdDb3VudDogc2NvcmluZy53cm9uZ0NvdW50LFxuICAgICAgICAgICAgICAgICAgICBzY29yZTogc2NvcmluZy5zY29yZSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIC8vIEFsc28gdXBkYXRlIGFuYWx5dGljcyBsaXN0XG4gICAgICAgICAgICBzZXRBbmFseXRpY3MocHJldiA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFwcmV2Py5yZXNwb25kZW50cykgcmV0dXJuIHByZXY7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uZGVudHM6IHByZXYucmVzcG9uZGVudHMubWFwKHIgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHIucmVzcG9uc2VJZCAhPT0gcmVzcG9uc2VJZCkgcmV0dXJuIHI7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkQW5zd2VycyA9IChyLmFuc3dlcnMgfHwgW10pLm1hcChhID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtYXRjaGVkU3VnID0gYWlIb2xpc3RpY1Jlc3VsdC5lc3NheVN1Z2dlc3Rpb25zLmZpbmQoeCA9PiBOdW1iZXIoeC5hbnN3ZXI/LnF1ZXN0aW9uSWQpID09PSBOdW1iZXIoYS5xdWVzdGlvbklkKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1hdGNoZWRTdWcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcURlZiA9IChmb3JtUXVlc3Rpb25zIHx8IFtdKS5maW5kKHEgPT4gTnVtYmVyKHEuaWQpID09PSBOdW1iZXIoYS5xdWVzdGlvbklkKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHFQb2ludHMgPSBxRGVmICYmIE51bWJlcihxRGVmLnBvaW50cykgPiAwID8gTnVtYmVyKHFEZWYucG9pbnRzKSA6IDE7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBjdCA9IE1hdGgubWF4KDAsIE1hdGgubWluKDEwMCwgTnVtYmVyKG1hdGNoZWRTdWcuc3VnZ2VzdGlvbi5zY29yZSkgfHwgMCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByYXdQb2ludHMgPSBNYXRoLnJvdW5kKChwY3QgLyAxMDApICogcVBvaW50cyAqIDEwMCkgLyAxMDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5hLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0T3ZlcnJpZGU6IHBjdCA+IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3Q6IHBjdCA+IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYW51YWxTY29yZTogcmF3UG9pbnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2NvcmluZyA9IGNhbGN1bGF0ZVRvdGFsU2NvcmUodXBkYXRlZEFuc3dlcnMsIGZvcm1RdWVzdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5yLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcnM6IHVwZGF0ZWRBbnN3ZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvcnJlY3RDb3VudDogc2NvcmluZy5jb3JyZWN0Q291bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd3JvbmdDb3VudDogc2NvcmluZy53cm9uZ0NvdW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjb3JlOiBzY29yaW5nLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ3VzdG9tU2NvcmU6IHRydWVcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pO1xuXG5cbiAgICAgICAgICAgIHNldEFpSG9saXN0aWNQcmV2aWV3T3BlbihmYWxzZSk7XG4gICAgICAgICAgICBzZXRBaUhvbGlzdGljUmVzdWx0KG51bGwpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KGAke292ZXJyaWRlcy5sZW5ndGh9IHNrb3IgZXNzYXkgQUkgYmVyaGFzaWwgZGl0ZXJhcGthbiFgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNob3dUb2FzdChyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVuZXJhcGthbiBza29yIEFJLicsICdlcnJvcicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIFByZXZpZXcgYWRqdXN0bWVudHMgYmVmb3JlIGFwcGx5aW5nXG4gICAgY29uc3QgcHJldmlld0FkanVzdG1lbnRzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIHJldHVybiByZXNwb25kZW50c0xpc3QubWFwKHIgPT4ge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudCA9IHIuc2NvcmUgIT0gbnVsbCA/IHIuc2NvcmUgOiAwO1xuICAgICAgICAgICAgbGV0IG1lZXRzRmlsdGVyID0gdHJ1ZTtcbiAgICAgICAgICAgIGlmIChidWxrRmlsdGVyID09PSAnYmVsb3cnKSB7XG4gICAgICAgICAgICAgICAgbWVldHNGaWx0ZXIgPSBjdXJyZW50IDwgZmlsdGVyVGhyZXNob2xkO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChidWxrRmlsdGVyID09PSAncmFuZ2UnKSB7XG4gICAgICAgICAgICAgICAgbWVldHNGaWx0ZXIgPSBjdXJyZW50ID49IGZpbHRlclJhbmdlTWluICYmIGN1cnJlbnQgPD0gZmlsdGVyUmFuZ2VNYXg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxldCBwcm9qZWN0ZWQgPSBjdXJyZW50O1xuICAgICAgICAgICAgaWYgKG1lZXRzRmlsdGVyKSB7XG4gICAgICAgICAgICAgICAgaWYgKGJ1bGtUeXBlID09PSAnbWluJykge1xuICAgICAgICAgICAgICAgICAgICBwcm9qZWN0ZWQgPSBNYXRoLm1heChjdXJyZW50LCBidWxrVmFsdWUpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoYnVsa1R5cGUgPT09ICdib251cycpIHtcbiAgICAgICAgICAgICAgICAgICAgcHJvamVjdGVkID0gTWF0aC5taW4oMTAwLCBNYXRoLm1heCgwLCBjdXJyZW50ICsgYnVsa1ZhbHVlKSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChidWxrVHlwZSA9PT0gJ3NjYWxlJykge1xuICAgICAgICAgICAgICAgICAgICBwcm9qZWN0ZWQgPSBNYXRoLm1pbigxMDAsIE1hdGgubWF4KDAsIE1hdGgucm91bmQoY3VycmVudCAqIChidWxrVmFsdWUgLyAxMDApICogMTApIC8gMTApKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGJ1bGtUeXBlID09PSAnc2V0X2ZpeGVkJykge1xuICAgICAgICAgICAgICAgICAgICBwcm9qZWN0ZWQgPSBNYXRoLm1pbigxMDAsIE1hdGgubWF4KDAsIGJ1bGtWYWx1ZSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5yLFxuICAgICAgICAgICAgICAgIGN1cnJlbnRTY29yZTogY3VycmVudCxcbiAgICAgICAgICAgICAgICBwcm9qZWN0ZWRTY29yZTogTWF0aC5yb3VuZChwcm9qZWN0ZWQgKiAxMCkgLyAxMCxcbiAgICAgICAgICAgICAgICBkaWZmOiBNYXRoLnJvdW5kKChwcm9qZWN0ZWQgLSBjdXJyZW50KSAqIDEwKSAvIDEwLFxuICAgICAgICAgICAgICAgIG1lZXRzRmlsdGVyXG4gICAgICAgICAgICB9O1xuICAgICAgICB9KTtcbiAgICB9LCBbcmVzcG9uZGVudHNMaXN0LCBidWxrVHlwZSwgYnVsa0ZpbHRlciwgZmlsdGVyVGhyZXNob2xkLCBmaWx0ZXJSYW5nZU1pbiwgZmlsdGVyUmFuZ2VNYXgsIGJ1bGtWYWx1ZV0pO1xuXG4gICAgY29uc3QgaGFuZGxlQXBwbHlCdWxrU2NvcmUgPSAoKSA9PiB7XG4gICAgICAgIHNldEFuYWx5dGljcyhwcmV2ID0+IHtcbiAgICAgICAgICAgIGlmICghcHJldj8ucmVzcG9uZGVudHMpIHJldHVybiBwcmV2O1xuICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IHByZXYucmVzcG9uZGVudHMubWFwKHIgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBwcmV2aWV3QWRqdXN0bWVudHMuZmluZChwID0+IHAucmVzcG9uc2VJZCA9PT0gci5yZXNwb25zZUlkKTtcbiAgICAgICAgICAgICAgICBpZiAoIWl0ZW0gfHwgIWl0ZW0ubWVldHNGaWx0ZXIpIHJldHVybiByO1xuICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLnIsIHNjb3JlOiBpdGVtLnByb2plY3RlZFNjb3JlLCBpc0N1c3RvbVNjb3JlOiB0cnVlIH07XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiB7IC4uLnByZXYsIHJlc3BvbmRlbnRzOiB1cGRhdGVkIH07XG4gICAgICAgIH0pO1xuICAgICAgICBzZXRCdWxrTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgc2hvd1RvYXN0KCdQZW55ZXN1YWlhbiBza29yIG1hc3NhbCBiZXJoYXNpbCBkaXRlcmFwa2FuIScpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVSZXNldEFsbFNjb3JlcyA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0QnVsa01vZGFsT3BlbihmYWxzZSk7XG4gICAgICAgIC8vIFJlbG9hZCBhbmFseXRpY3MgZnJlc2ggZnJvbSBzZXJ2ZXJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZ2V0Rm9ybUFuYWx5dGljcyhpZCwgMSwgMTAwKTtcbiAgICAgICAgaWYgKHJlcy5vayAmJiByZXMuZGF0YSkgc2V0QW5hbHl0aWNzKHJlcy5kYXRhKTtcbiAgICAgICAgc2hvd1RvYXN0KCdTa29yIGRpa2VtYmFsaWthbiBrZSBwZXJoaXR1bmdhbiBzaXN0ZW0uJyk7XG4gICAgfTtcblxuICAgIC8vIFRyZW5kIGNhbGN1bGF0aW9uc1xuICAgIGNvbnN0IHRyZW5kRGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIXJlc3BvbmRlbnRzTGlzdCB8fCByZXNwb25kZW50c0xpc3QubGVuZ3RoID09PSAwKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGVNYXAgPSB7fTtcbiAgICAgICAgcmVzcG9uZGVudHNMaXN0LmZvckVhY2gociA9PiB7XG4gICAgICAgICAgICBpZiAoIXIuc3VibWl0dGVkQXQpIHJldHVybjtcbiAgICAgICAgICAgIGNvbnN0IGQgPSBuZXcgRGF0ZShyLnN1Ym1pdHRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2lkLUlEJywge1xuICAgICAgICAgICAgICAgIGRheTogJzItZGlnaXQnLFxuICAgICAgICAgICAgICAgIG1vbnRoOiAnc2hvcnQnXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGRhdGVNYXBbZF0gPSAoZGF0ZU1hcFtkXSB8fCAwKSArIDE7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gT2JqZWN0LmVudHJpZXMoZGF0ZU1hcCkubWFwKChbZGF0ZSwgY291bnRdKSA9PiAoeyBkYXRlLCBjb3VudCB9KSk7XG4gICAgfSwgW3Jlc3BvbmRlbnRzTGlzdF0pO1xuXG4gICAgY29uc3QgbWF4Q291bnQgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKHRyZW5kRGF0YS5sZW5ndGggPT09IDApIHJldHVybiAxO1xuICAgICAgICByZXR1cm4gTWF0aC5tYXgoLi4udHJlbmREYXRhLm1hcChkID0+IGQuY291bnQpLCAxKTtcbiAgICB9LCBbdHJlbmREYXRhXSk7XG5cbiAgICBjb25zdCBjdXJyZW50SW5kZXggPSBzZWxlY3RlZFJlc3BvbmRlbnRcbiAgICAgICAgPyByZXNwb25kZW50c0xpc3QuZmluZEluZGV4KHIgPT4gci5yZXNwb25zZUlkID09PSBzZWxlY3RlZFJlc3BvbmRlbnQucmVzcG9uc2VJZClcbiAgICAgICAgOiAtMTtcblxuICAgIGNvbnN0IGdvUHJldmlvdXMgPSAoKSA9PiB7XG4gICAgICAgIGlmIChjdXJyZW50SW5kZXggPiAwKSB7XG4gICAgICAgICAgICBvcGVuUmVzcG9uZGVudFJldmlldyhyZXNwb25kZW50c0xpc3RbY3VycmVudEluZGV4IC0gMV0pO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGdvTmV4dCA9ICgpID0+IHtcbiAgICAgICAgaWYgKGN1cnJlbnRJbmRleCA8IHJlc3BvbmRlbnRzTGlzdC5sZW5ndGggLSAxKSB7XG4gICAgICAgICAgICBvcGVuUmVzcG9uZGVudFJldmlldyhyZXNwb25kZW50c0xpc3RbY3VycmVudEluZGV4ICsgMV0pO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGdldEFuc3dlclN0YXR1cyA9IChhbnN3ZXIsIHFEZWYgPSBudWxsKSA9PiB7XG4gICAgICAgIGNvbnN0IHEgPSBxRGVmIHx8IChmb3JtUXVlc3Rpb25zIHx8IFtdKS5maW5kKGYgPT4gTnVtYmVyKGYuaWQpID09PSBOdW1iZXIoYW5zd2VyPy5xdWVzdGlvbklkKSk7XG4gICAgICAgIGNvbnN0IGVmZmVjdGl2ZSA9IGdldEVmZmVjdGl2ZUlzQ29ycmVjdChhbnN3ZXIsIHEpO1xuICAgICAgICBpZiAoZWZmZWN0aXZlID09PSB0cnVlKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGxhYmVsOiAnQmVuYXInLFxuICAgICAgICAgICAgICAgIGljb246IDxDaGVja0NpcmNsZTIgc2l6ZT17MTZ9IC8+LFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogJ3RleHQtZW1lcmFsZC02MDAgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAnXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChlZmZlY3RpdmUgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGxhYmVsOiAnU2FsYWgnLFxuICAgICAgICAgICAgICAgIGljb246IDxYQ2lyY2xlIHNpemU9ezE2fSAvPixcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6ICd0ZXh0LXJlZC02MDAgYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC82MCBkYXJrOnRleHQtcmVkLTQwMCBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwJ1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbGFiZWw6ICdUaWRhayBEaW5pbGFpJyxcbiAgICAgICAgICAgIGljb246IDxNaW51c0NpcmNsZSBzaXplPXsxNn0gLz4sXG4gICAgICAgICAgICBjbGFzc05hbWU6ICd0ZXh0LXNsYXRlLTUwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICB9O1xuICAgIH07XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1zY3JlZW4gYmctWyNGNEY4RjddIGRhcms6Ymctc2xhdGUtOTUwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctOCBoLTggYW5pbWF0ZS1zcGluIG14LWF1dG8gdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIHRleHQtc20gZm9udC1tZWRpdW1cIj5NZW11YXQgcmVzcG9ucy4uLjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctWyNGNEY4RjddIGRhcms6Ymctc2xhdGUtOTUwIGZvbnQtc2FucyBhbnRpYWxpYXNlZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICA8U2lkZWJhciAvPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGZsZXgtY29sIG1pbi13LTAgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHB4LTYgcHktNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvbXktZm9ybXMnKX0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd0xlZnQgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtPy50aXRsZSB8fCAnRm9ybXVsaXInfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXNwb25kZW50c0xpc3QubGVuZ3RofSB0b3RhbCByZXNwb25zIG1hc3VrXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9mb3Jtcy8ke2lkfS9hbmFseXRpY3NgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMuNSBweS0yIGJnLXRlYWwtNTAgaG92ZXI6YmctdGVhbC0xMDAgZGFyazpiZy10ZWFsLTk1MC82MCBkYXJrOmhvdmVyOmJnLXRlYWwtOTAwIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyQ2hhcnQyIHNpemU9ezE0fSAvPiBBbmFsaXNpc1xuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBzZWxlY3Qtbm9uZSBjdXJzb3ItcG9pbnRlciBmb250LW1lZGl1bSBweC0yIHB5LTEuNSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtpbmNsdWRlQW5zd2VyS2V5fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRJbmNsdWRlQW5zd2VyS2V5KGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1pbmRpZ28tNjAwIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5LdW5jaSBKYXdhYmFuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUV4cG9ydChpZCwgJ2NzdicpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtleHBvcnRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXhzIGRpc2FibGVkOm9wYWNpdHktNjAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVW5kdWggZm9ybWF0IENTVlwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2V4cG9ydGluZyA/IDxMb2FkZXIyIHNpemU9ezEzfSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW5cIiAvPiA6IDxEb3dubG9hZCBzaXplPXsxM30gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q1NWPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVFeHBvcnQoaWQsICd4bHN4Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2V4cG9ydGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXhzIGRpc2FibGVkOm9wYWNpdHktNjAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVW5kdWggZm9ybWF0IEV4Y2VsICgueGxzeClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5FeGNlbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRXhwb3J0KGlkLCAncGRmJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2V4cG9ydGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiBiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTcwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXhzIGRpc2FibGVkOm9wYWNpdHktNjAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVW5kdWggZm9ybWF0IFBERiAoLnBkZilcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QREY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1Yi10YWJzOiBSZXNwb25zIC8gRmVlZGJhY2sgLyBNb25pdG9yaW5nICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHB4LTZcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdyZXNwb25zZXMnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB5LTMuNSBweC01IHRleHQteHMgZm9udC1leHRyYWJvbGQgYm9yZGVyLWItMiB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdyZXNwb25zZXMnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLVsjMDA4OTdCXSB0ZXh0LVsjMDA4OTdCXSBkYXJrOmJvcmRlci10ZWFsLTQwMCBkYXJrOnRleHQtdGVhbC00MDAnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIHNpemU9ezE0fSAvPiBSZXNwb25zXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2ZlZWRiYWNrJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweS0zLjUgcHgtNSB0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnZmVlZGJhY2snIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWFtYmVyLTUwMCB0ZXh0LWFtYmVyLTYwMCBkYXJrOmJvcmRlci1hbWJlci00MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZXNzYWdlU3F1YXJlIHNpemU9ezE0fSAvPiBNYXN1a2FuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZlZWRiYWNrcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMS41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gYmctYW1iZXItMTAwIGRhcms6YmctYW1iZXItOTUwLzYwIHRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmZWVkYmFja3MubGVuZ3RofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignbW9uaXRvcmluZycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB5LTMuNSBweC01IHRleHQteHMgZm9udC1leHRyYWJvbGQgYm9yZGVyLWItMiB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdtb25pdG9yaW5nJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1pbmRpZ28tNjAwIHRleHQtaW5kaWdvLTYwMCBkYXJrOmJvcmRlci1pbmRpZ28tNDAwIGRhcms6dGV4dC1pbmRpZ28tNDAwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk1vbml0b3Jpbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge21vbml0b3JpbmdEYXRhPy5vbmxpbmVDb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGgtMiB3LTIgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFuaW1hdGUtcGluZyBhYnNvbHV0ZSBpbmxpbmUtZmxleCBoLWZ1bGwgdy1mdWxsIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTQwMCBvcGFjaXR5LTc1XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgaW5saW5lLWZsZXggcm91bmRlZC1mdWxsIGgtMiB3LTIgYmctZW1lcmFsZC01MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttb25pdG9yaW5nRGF0YT8uc2Vzc2lvbnMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0xLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge21vbml0b3JpbmdEYXRhLnNlc3Npb25zLmxlbmd0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ21vbml0b3JpbmcnICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2F1dG9SZWZyZXNofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBdXRvUmVmcmVzaChlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMy41IGgtMy41IGFjY2VudC1pbmRpZ28tNjAwIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+QXV0by1yZWZyZXNoICg1cyk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmZXRjaEV4YW1Nb25pdG9yaW5nKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e21vbml0b3JpbmdMb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlNlZ2Fya2FuIERhdGEgTW9uaXRvcmluZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVmcmVzaEN3IHNpemU9ezEyfSBjbGFzc05hbWU9e21vbml0b3JpbmdMb2FkaW5nID8gJ2FuaW1hdGUtc3BpbicgOiAnJ30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2VnYXJrYW48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2xhc3RSZWZyZXNoZWRBdCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgaGlkZGVuIG1kOmlubGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xhc3RSZWZyZXNoZWRBdC50b0xvY2FsZVRpbWVTdHJpbmcoJ2lkLUlEJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7dG9hc3QgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZpeGVkIHRvcC00IHJpZ2h0LTQgei01MCBweC00IHB5LTMgcm91bmRlZC0yeGwgc2hhZG93LXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgJHt0b2FzdC50eXBlID09PSAnZXJyb3InID8gJ2JnLXJlZC01MDAnIDogJ2JnLVsjMDA4OTdCXSd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dG9hc3QubXNnfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgbWF4LXctNnhsIG14LWF1dG8gdy1mdWxsIHNwYWNlLXktNlwiPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiDilIDilIAgUkVTUE9OU0VTIFRBQiDilIDilIAgKi99XG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdyZXNwb25zZXMnICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRyZW5kIERpYWdyYW0gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3RyZW5kRGF0YS5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTYgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy1zbSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEaWFncmFtIFRyZW4gUmVzcG9ucyBGb3JtdWxpclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZXJrZW1iYW5nYW4ganVtbGFoIHBlbmdpcmltYW4gYmVyZGFzYXJrYW4gdGFuZ2dhbCBzdWJtaXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHJlbmREYXRhLmxlbmd0aH0gVGl0aWsgRGF0YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNDQgZmxleCBpdGVtcy1lbmQgZ2FwLTMgcHQtNiBwYi0yIHB4LTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHJlbmREYXRhLm1hcCgoaXRlbSwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGhlaWdodFBlcmNlbnQgPSBNYXRoLm1heCgoaXRlbS5jb3VudCAvIG1heENvdW50KSAqIDEwMCwgMTUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0yIGgtZnVsbCBqdXN0aWZ5LWVuZCBncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtZXh0cmFib2xkIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmNvdW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1saW5lYXItdG8tdCBmcm9tLVsjMDA4OTdCXSB0by1bIzREQjZBQ10gZGFyazpmcm9tLXRlYWwtNjAwIGRhcms6dG8tdGVhbC00MDAgcm91bmRlZC10LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCBncm91cC1ob3ZlcjpicmlnaHRuZXNzLTExMCBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IGAke2hlaWdodFBlcmNlbnR9JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB0cnVuY2F0ZSB3LWZ1bGwgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3BvbmRlbnRzTGlzdC5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTYgcHgtNCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTN4bCBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNwYWNlLXktNCBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQtMnhsIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVzc2FnZVNxdWFyZSBzaXplPXsyOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEgbWF4LXctc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmVsdW0gQWRhIFJlc3BvbnMgTWFzdWtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRm9ybXVsaXIgaW5pIGJlbHVtIG1lbmVyaW1hIGtpcmltYW4gamF3YWJhbiBkYXJpIGF1ZGllbnMuIEJhZ2lrYW4gdGF1dGFuIGZvcm11bGlyIEFuZGEgYWdhciByZXNwb25kZW4gZGFwYXQgbXVsYWkgbWVuZ2lzaS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtPy5mb3JtTGluayAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXJsID0gYCR7d2luZG93LmxvY2F0aW9uLm9yaWdpbn0vZi8ke2Zvcm0uZm9ybUxpbmt9YDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93VG9hc3QoJ1RhdXRhbiBmb3JtdWxpciBiZXJoYXNpbCBkaXNhbGluIGtlIGNsaXBib2FyZCEnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHJvdW5kZWQteGwgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsIGFjdGl2ZTpzY2FsZS05NSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hhcmUyIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TYWxpbiBUYXV0YW4gRm9ybXVsaXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+RGFmdGFyIFJlc3BvbnMgTWFzdWs8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+e3Jlc3BvbmRlbnRzTGlzdC5sZW5ndGh9IFRvdGFsIFJlc3BvbnM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzcG9uZGVudHNMaXN0Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QnVsa01vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBob3ZlcjpiZy10ZWFsLTEwMCBkYXJrOmhvdmVyOmJnLXRlYWwtOTAwLzYwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgc2hhZG93LTJ4cyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJVYmFoIHNrb3Igc2VsdXJ1aCByZXNwb25kZW4gc2VjYXJhIG1hc3NhbCAoYm9udXMsIHNrYWxhLCBkbGwpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2xpZGVycyBzaXplPXsxM30gLz4gUGVueWVzdWFpYW4gU2tvciBNYXNzYWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIHctZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1zbSB0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIHRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj4jPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+UmVzcG9uZGVuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+U29hbCBEaWphd2FiPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+QmVuYXI8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5TYWxhaDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlNrb3I8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5TdGF0dXM8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5XYWt0dSBTdWJtaXQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1yaWdodFwiPkFrc2k8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzcG9uZGVudHNMaXN0Lm1hcCgociwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNjb3JhYmxlID0gci5zY29yYWJsZVF1ZXN0aW9ucyA/PyAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvcnJlY3QgPSByLmNvcnJlY3RDb3VudCA/PyAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHdyb25nID0gci53cm9uZ0NvdW50ICE9IG51bGwgPyByLndyb25nQ291bnQgOiBNYXRoLm1heChzY29yYWJsZSAtIGNvcnJlY3QsIDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRWRpdGluZyA9IGVkaXRpbmdTY29yZUlkID09PSByLnJlc3BvbnNlSWQ7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyLnJlc3BvbnNlSWQgfHwgaX0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCB0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPntpICsgMX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3IucmVzcG9uZGVudE5hbWUgfHwgJ0Fub25pbSd9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+I3tyLnJlc3BvbnNlSWR9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ci5hbnN3ZXJlZENvdW50ID8/IDB9L3tyLnRvdGFsUXVlc3Rpb25zID8/IDB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb3JyZWN0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCB0ZXh0LXJlZC01MDAgZGFyazp0ZXh0LXJlZC00MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3dyb25nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heD1cIjEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuNVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2lubGluZVNjb3JlSW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0SW5saW5lU2NvcmVJbnB1dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xNiBweC0yIHB5LTEgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1bIzAwODk3Ql0gcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbktleURvd249e2UgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgaGFuZGxlU2F2ZUluZGl2aWR1YWxTY29yZShyLnJlc3BvbnNlSWQsIGlubGluZVNjb3JlSW5wdXQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTYXZlSW5kaXZpZHVhbFNjb3JlKHIucmVzcG9uc2VJZCwgaW5saW5lU2NvcmVJbnB1dCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIGJnLVsjMDA4OTdCXSB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgaG92ZXI6YmctWyMwMDc5NkJdIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlNpbXBhbiBTa29yXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgc2l6ZT17MTJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFZGl0aW5nU2NvcmVJZChudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQmF0YWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezEyfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Iuc2NvcmUgIT0gbnVsbCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXhzIGZvbnQtYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgci5zY29yZSA+PSA3MFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6YmctZW1lcmFsZC05NTAvNjAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctcmVkLTUwIHRleHQtcmVkLTYwMCBkYXJrOmJnLXJlZC05NTAvNjAgZGFyazp0ZXh0LXJlZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ci5zY29yZX0lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyLmlzQ3VzdG9tU2NvcmUgJiYgPHNwYW4gY2xhc3NOYW1lPVwibWwtMSB0ZXh0LVs5cHhdIG9wYWNpdHktNzUgZm9udC1ub3JtYWxcIj4qZWRpdDwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW1cIj5OL0E8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1Njb3JlSWQoci5yZXNwb25zZUlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SW5saW5lU2NvcmVJbnB1dChyLnNjb3JlICE9IG51bGwgPyBTdHJpbmcoci5zY29yZSkgOiAnMTAwJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgcC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtWyMwMDg5N0JdIHJvdW5kZWQgdHJhbnNpdGlvbi1vcGFjaXR5IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlViYWggTmlsYWkgUmVzcG9uZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RWRpdDIgc2l6ZT17MTJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtTVEFUVVNfT1BUSU9OUy5maW5kKHMgPT4gcy5jb2RlID09PSByLnN0YXR1cz8udG9Mb3dlckNhc2UoKSk/LmlkID8/IDF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZVN0YXR1c0NoYW5nZShyLnJlc3BvbnNlSWQsIHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzdGF0dXNVcGRhdGluZyA9PT0gci5yZXNwb25zZUlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LVsxMXB4XSBmb250LWJvbGQgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIGJvcmRlci0wIGN1cnNvci1wb2ludGVyIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy10ZWFsLTQwMCBkaXNhYmxlZDpvcGFjaXR5LTYwICR7c3RhdHVzU3R5bGUoci5zdGF0dXMpfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7U1RBVFVTX09QVElPTlMubWFwKHMgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3MuaWR9IHZhbHVlPXtzLmlkfT57cy5sYWJlbH08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKHIuc3VibWl0dGVkQXQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuUmVzcG9uZGVudFJldmlldyhyKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFeWUgc2l6ZT17MTN9IC8+IFJldmlldyBKYXdhYmFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7Lyog4pSA4pSAIEZFRURCQUNLIFRBQiDilIDilIAgKi99XG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdmZWVkYmFjaycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmVlZGJhY2tMb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTE2IHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPk1lbXVhdCBsYXBvcmFuIG1hc3VrYW4uLi48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogZmVlZGJhY2tzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xNiBzcGFjZS15LTIgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVzc2FnZVNxdWFyZSBzaXplPXszMn0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZGFyazp0ZXh0LXNsYXRlLTYwMCBteC1hdXRvXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBmb250LWJvbGRcIj5CZWx1bSBhZGEgbGFwb3JhbiBtYXN1a2FuIHVudHVrIGZvcm11bGlyIGluaS48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5NYXN1a2FuIGRpa2lyaW1rYW4gb2xlaCByZXNwb25kZW4gc2V0ZWxhaCBtZW55ZWxlc2Fpa2FuIGZvcm11bGlyLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmZWVkYmFja3MubWFwKChmYiwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtmYi5pZCA/PyBpfSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC01IHNoYWRvdy14cyBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWV4dHJhYm9sZCBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzYwIHRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci00MDAgYm9yZGVyIGJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBzaXplPXsxM30gLz4ge2ZiLnJlYXNvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bSBzaHJpbmstMFwiPntmb3JtYXREYXRlKGZiLmNyZWF0ZWRBdCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmIuZGVzY3JpcHRpb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGxlYWRpbmctcmVsYXhlZCBib3JkZXItbC0yIGJvcmRlci1hbWJlci0zMDAgZGFyazpib3JkZXItYW1iZXItNTAwIHBsLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmIuZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwdC0xIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYmctdGVhbC0xMDAgZGFyazpiZy10ZWFsLTk1MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtWzEwcHhdIGZvbnQtYmxhY2sgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGZiLnVzZXJOYW1lIHx8ICdVJykuY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj57ZmIudXNlck5hbWUgfHwgJ0Fub25pbSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIOKUgOKUgCBFWEFNIE1PTklUT1JJTkcgVEFCIOKUgOKUgCAqL31cbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ21vbml0b3JpbmcnICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1bW1hcnkgTWV0cmljcyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+TW9kZSBVamlhbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgc2l6ZT17MTh9IGNsYXNzTmFtZT17bW9uaXRvcmluZ0RhdGE/LmlzRXhhbU1vZGUgfHwgbW9uaXRvcmluZ0RhdGE/LmRldGVjdFRhYlN3aXRjaCA/ICd0ZXh0LWVtZXJhbGQtNTAwJyA6ICd0ZXh0LXNsYXRlLTQwMCd9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LWJhc2UgZm9udC1leHRyYWJvbGQgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb25pdG9yaW5nRGF0YT8uaXNFeGFtTW9kZSB8fCBtb25pdG9yaW5nRGF0YT8uZGV0ZWN0VGFiU3dpdGNoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgZGFyazpiZy1lbWVyYWxkLTk1MC82MCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge21vbml0b3JpbmdEYXRhPy5pc0V4YW1Nb2RlIHx8IG1vbml0b3JpbmdEYXRhPy5kZXRlY3RUYWJTd2l0Y2ggPyAnQWt0aWYnIDogJ05vbmFrdGlmJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttb25pdG9yaW5nRGF0YT8uYXV0b1N1Ym1pdE9uVGFiU3dpdGNoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYEF1dG8tc3VibWl0OiBNYWtzICR7bW9uaXRvcmluZ0RhdGEubWF4VGFiU3dpdGNoIHx8IDN9eCB0YWIgc3dpdGNoYFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdQZW5jYXRhdGFuIHBlbGFuZ2dhcmFuIGFrdGlmJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+U2VkYW5nIE1lbmdlcmpha2FuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBY3Rpdml0eSBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bW9uaXRvcmluZ0RhdGE/LmluUHJvZ3Jlc3NDb3VudCA/PyAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZvbnQtc2VtaWJvbGRcIj5wZXNlcnRhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwIGZvbnQtc2VtaWJvbGQgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJlbHVtIG1lbmdpcmlta2FuIGphd2FiYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+T25saW5lIExpdmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJhZGlvIHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNTAwIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttb25pdG9yaW5nRGF0YT8ub25saW5lQ291bnQgPz8gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBmb250LXNlbWlib2xkXCI+YWt0aWYgc2FhdCBpbmk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkYSBha3Rpdml0YXMgOTAgZGV0aWsgdGVyYWtoaXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+U3VkYWggU3VibWl0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MTh9IGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bW9uaXRvcmluZ0RhdGE/LnN1Ym1pdHRlZENvdW50ID8/IDB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZm9udC1zZW1pYm9sZFwiPnNlbGVzYWk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEphd2FiYW4gdGVsYWggdGVyc2ltcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZpbHRlciBhbmQgU2VhcmNoICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3cteHMgZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIG1kOnctYXV0byBvdmVyZmxvdy14LWF1dG8gcGItMSBtZDpwYi0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdhbGwnLCBsYWJlbDogJ1NlbXVhIFBlc2VydGEnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJ2luX3Byb2dyZXNzJywgbGFiZWw6ICdTZWRhbmcgTWVuZ2VyamFrYW4nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3N1Ym1pdHRlZCcsIGxhYmVsOiAnU3VkYWggU3VibWl0JyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICd2aW9sYXRpb25zJywgbGFiZWw6ICdBZGEgUGVsYW5nZ2FyYW4nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJ2hpZ2hfdmlvbGF0aW9ucycsIGxhYmVsOiAnUGVsYW5nZ2FyYW4gVGluZ2dpJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXS5tYXAodGFiID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dGFiLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9uaXRvcmluZ0ZpbHRlcih0YWIuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zLjUgcHktMS41IHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbml0b3JpbmdGaWx0ZXIgPT09IHRhYi5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWluZGlnby02MDAgdGV4dC13aGl0ZSBzaGFkb3cteHMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YWIubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWQ6dy02NFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlYXJjaCBzaXplPXsxNH0gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc2xhdGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNhcmkgbmFtYSByZXNwb25kZW4uLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttb25pdG9yaW5nU2VhcmNofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldE1vbml0b3JpbmdTZWFyY2goZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC05IHByLTMuNSBweS0xLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQteHMgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNlc3Npb25zIFRhYmxlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy14cyBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge21vbml0b3JpbmdMb2FkaW5nICYmICFtb25pdG9yaW5nRGF0YSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0xMiB0ZXh0LXNsYXRlLTQwMCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIHNpemU9ezE4fSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gdGV4dC1pbmRpZ28tNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZFwiPk1lbXVhdCBkYXRhIG1vbml0b3JpbmcuLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IGZpbHRlcmVkU2Vzc2lvbnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTEyIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQWxlcnQgc2l6ZT17MzZ9IGNsYXNzTmFtZT1cIm14LWF1dG8gbWItMiB0ZXh0LXNsYXRlLTMwMCBkYXJrOnRleHQtc2xhdGUtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+QmVsdW0gYWRhIHBlc2VydGEgdWppYW4gZGl0ZW11a2FuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgbXQtMVwiPlBlc2VydGEgeWFuZyBtZW1idWthIGhhbGFtYW4gdWppYW4gYWthbiBvdG9tYXRpcyB0ZXJjYXRhdCBkYW4gbXVuY3VsIGRpIHNpbmkgc2VjYXJhIHJlYWwtdGltZS48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LVsxMXB4XSBmb250LWV4dHJhYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBiZy1zbGF0ZS01MC83MCBkYXJrOmJnLXNsYXRlLTgwMC81MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5SZXNwb25kZW48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5TdGF0dXMgUGVuZ2VyamFhbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlBpbmRhaCBUYWI8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5Ub3RhbCBQZWxhbmdnYXJhbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPkFrdGl2aXRhcyBUZXJha2hpcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXJpZ2h0XCI+QWtzaSAmIExvZzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCBkYXJrOmRpdmlkZS1zbGF0ZS04MDAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkU2Vzc2lvbnMubWFwKChzZXNzaW9uLCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0V4cGFuZGVkID0gZXhwYW5kZWRTZXNzaW9ucy5oYXMoc2Vzc2lvbi5zZXNzaW9uSWQgfHwgYHNlc3Npb24tJHtpZHh9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbWF4U3cgPSBtb25pdG9yaW5nRGF0YT8ubWF4VGFiU3dpdGNoIHx8IDM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZ2VudWluZVZpb2xhdGlvbkNvdW50ID0gZ2V0R2VudWluZVZpb2xhdGlvbkNvdW50KHNlc3Npb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzSGlnaFZpb2xhdGlvbiA9IGdlbnVpbmVWaW9sYXRpb25Db3VudCA+PSBtYXhTdyB8fCBzZXNzaW9uLnRhYlN3aXRjaENvdW50ID49IG1heFN3O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZyYWdtZW50IGtleT17c2Vzc2lvbi5zZXNzaW9uSWQgfHwgYHNlc3Npb24tJHtpZHh9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPXtgaG92ZXI6Ymctc2xhdGUtNTAvODAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNTAgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0hpZ2hWaW9sYXRpb24gPyAnYmctcmVkLTUwLzMwIGRhcms6YmctcmVkLTk1MC8xMCcgOiAnJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhzZXNzaW9uLnJlc3BvbmRlbnROYW1lIHx8ICdBJykuY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24uaXNPbmxpbmUgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIHJpZ2h0LTAgdy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNTAwIHJpbmctMiByaW5nLXdoaXRlIGRhcms6cmluZy1zbGF0ZS05MDBcIiB0aXRsZT1cIlNlZGFuZyBPbmxpbmVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIHJpZ2h0LTAgdy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTMwMCBkYXJrOmJnLXNsYXRlLTYwMCByaW5nLTIgcmluZy13aGl0ZSBkYXJrOnJpbmctc2xhdGUtOTAwXCIgdGl0bGU9XCJPZmZsaW5lXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57c2Vzc2lvbi5yZXNwb25kZW50TmFtZSB8fCAnQW5vbmltJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLmlzT25saW5lICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNjAgcHgtMS41IHB5LTAuNSByb3VuZGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT25saW5lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2Vzc2lvbi5zZXNzaW9uSWQgPyBgU2VzaTogJHtzZXNzaW9uLnNlc3Npb25JZC5zbGljZSgwLCA4KX0uLi5gIDogKHNlc3Npb24ucmVzcG9uc2VJZCA/IGBSZXNwb25zICMke3Nlc3Npb24ucmVzcG9uc2VJZH1gIDogJ1Nlc2kgTGFuZ3N1bmcnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLnN0YXR1cyA9PT0gJ2luX3Byb2dyZXNzJyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgZGFyazpiZy1hbWJlci05NTAvNjAgZGFyazp0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWN0aXZpdHkgc2l6ZT17MTJ9IGNsYXNzTmFtZT1cImFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlZGFuZyBNZW5nZXJqYWthblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtYm9sZCBiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgZGFyazpiZy1lbWVyYWxkLTk1MC82MCBkYXJrOnRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MTJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3VkYWggU3VibWl0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLnRhYlN3aXRjaENvdW50ID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGZvbnQtYm9sZCAke3Nlc3Npb24udGFiU3dpdGNoQ291bnQgPj0gbWF4U3cgPyAndGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwJyA6ICd0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2Vzc2lvbi50YWJTd2l0Y2hDb3VudH14XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPjB4PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cbiAgICB7Z2VudWluZVZpb2xhdGlvbkNvdW50ID09PSAwID8gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1ib2xkIGJnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwXCI+XG4gICAgICAgICAgICDinJMgQmVyc2loICgwKVxuICAgICAgICA8L3NwYW4+XG4gICAgKSA6IGlzSGlnaFZpb2xhdGlvbiA/IChcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAgZGFyazpiZy1yZWQtOTUwLzcwIGRhcms6dGV4dC1yZWQtMzAwIGJvcmRlciBib3JkZXItcmVkLTMwMCBkYXJrOmJvcmRlci1yZWQtODAwIGFuaW1hdGUtcHVsc2VcIj5cbiAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIHNpemU9ezEyfSAvPlxuICAgICAgICAgICAge2dlbnVpbmVWaW9sYXRpb25Db3VudH0gUGVsYW5nZ2FyYW4gKFRpbmdnaSlcbiAgICAgICAgPC9zcGFuPlxuICAgICkgOiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgZGFyazpiZy1hbWJlci05NTAvNjAgZGFyazp0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDBcIj5cbiAgICAgICAgICAgIOKaoO+4jyB7Z2VudWluZVZpb2xhdGlvbkNvdW50fSBQZWxhbmdnYXJhblxuICAgICAgICA8L3NwYW4+XG4gICAgKX1cbjwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2Pntmb3JtYXREYXRlKHNlc3Npb24ubGFzdFNlZW5BdCB8fCBzZXNzaW9uLnN0YXJ0ZWRBdCl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE11bGFpOiB7Zm9ybWF0RGF0ZShzZXNzaW9uLnN0YXJ0ZWRBdCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0xLjUgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2Vzc2lvbi5zZXNzaW9uSWQgJiYgc2Vzc2lvbi5zdGF0dXMgPT09ICdpbl9wcm9ncmVzcycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Gb3JjZVN1Ym1pdChzZXNzaW9uKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTcwMCBkYXJrOnRleHQtYW1iZXItMzAwIGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzYwIGhvdmVyOmJnLWFtYmVyLTEwMCBkYXJrOmhvdmVyOmJnLWFtYmVyLTkwMC82MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU2VsZXNhaWthbiBwYWtzYSBzZXNpIHVqaWFuIHBlc2VydGEgaW5pXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTaGllbGRBbGVydCBzaXplPXsxMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Rm9yY2UgU3VibWl0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLnNlc3Npb25JZCAmJiBzZXNzaW9uLnN0YXR1cyA9PT0gJ3N1Ym1pdHRlZCcgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5SZXNldFNlc3Npb24oc2Vzc2lvbil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yLjUgcHktMSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1yb3NlLTcwMCBkYXJrOnRleHQtcm9zZS0zMDAgYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzYwIGhvdmVyOmJnLXJvc2UtMTAwIGRhcms6aG92ZXI6Ymctcm9zZS05MDAvNjAgYm9yZGVyIGJvcmRlci1yb3NlLTIwMCBkYXJrOmJvcmRlci1yb3NlLTgwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZXNldCBqYXdhYmFuIHlhbmcgc3VkYWggZGlzdWJtaXQgYWdhciBwZXNlcnRhIGRhcGF0IG1lbmdpc2kgdWxhbmdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBzaXplPXsxMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVzZXQgSmF3YWJhbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2Vzc2lvbkV4cGFuZChzZXNzaW9uLnNlc3Npb25JZCB8fCBgc2Vzc2lvbi0ke2lkeH1gKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwIGRhcms6dGV4dC1pbmRpZ28tNDAwIGJnLWluZGlnby01MCBkYXJrOmJnLWluZGlnby05NTAvNjAgaG92ZXI6YmctaW5kaWdvLTEwMCBkYXJrOmhvdmVyOmJnLWluZGlnby05MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+TG9nICh7c2Vzc2lvbi52aW9sYXRpb25zPy5sZW5ndGggfHwgMH0pPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0V4cGFuZGVkID8gPENoZXZyb25VcCBzaXplPXsxM30gLz4gOiA8Q2hldnJvbkRvd24gc2l6ZT17MTN9IC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRXhwYW5kZWQgVmlvbGF0aW9ucyBMb2cgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNFeHBhbmRlZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwLzYwIGRhcms6Ymctc2xhdGUtOTAwLzYwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs2fSBjbGFzc05hbWU9XCJwLTQgcGwtMTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC00IHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTG9nIFJla2FtYW4gUGVsYW5nZ2FyYW4g4oCUIHtzZXNzaW9uLnJlc3BvbmRlbnROYW1lIHx8ICdBbm9uaW0nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbDoge3Nlc3Npb24udmlvbGF0aW9ucz8ubGVuZ3RoIHx8IDB9IGtlamFkaWFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoIXNlc3Npb24udmlvbGF0aW9ucyB8fCBzZXNzaW9uLnZpb2xhdGlvbnMubGVuZ3RoID09PSAwKSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBpdGFsaWMgcHktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlkYWsgYWRhIHJpd2F5YXQgcGVsYW5nZ2FyYW4gdW50dWsgc2VzaSBpbmkuIFBlc2VydGEgbWVuZ2VyamFrYW4gZGVuZ2FuIHRlcnRpYi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2Vzc2lvbi52aW9sYXRpb25zLm1hcCgodmlvbGF0aW9uLCB2SWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdkluZm8gPSBnZXRWaW9sYXRpb25JbmZvKHZpb2xhdGlvbi50eXBlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3ZJZHh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0yIHJvdW5kZWQtbGcgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHAtMSByb3VuZGVkLW1kICR7dkluZm8uYmd9ICR7dkluZm8uY29sb3J9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2SW5mby5pY29ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dkluZm8ubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlV2l0aFRpbWUodmlvbGF0aW9uLm9jY3VycmVkQXQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9GcmFnbWVudD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7Lyog4pSA4pSAIFJFVklFVyBKQVdBQkFOIE1PREFMIOKUgOKUgCAqL31cbiAgICAgICAgICAgIHtzZWxlY3RlZFJlc3BvbmRlbnQgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzUwIGJhY2tkcm9wLWJsdXIteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRSZXNwb25kZW50KG51bGwpfVxuICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdy1mdWxsIG1heC13LTN4bCBtYXgtaC1bOTB2aF0gcm91bmRlZC0zeGwgc2hhZG93LTJ4bCBmbGV4IGZsZXgtY29sIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzaHJpbmstMCBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC81MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtYmFzZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmV2aWV3IEphd2FiYW4gUmVzcG9uZGVuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlc3BvbmRlbjogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj57c2VsZWN0ZWRSZXNwb25kZW50LnJlc3BvbmRlbnROYW1lIHx8ICdBbm9uaW0nfTwvc3Bhbj4gKFJlc3BvbnMgI3tzZWxlY3RlZFJlc3BvbmRlbnQucmVzcG9uc2VJZH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkUmVzcG9uZGVudChudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1bW1hcnkgQmFyIHdpdGggRWRpdGFibGUgU2NvcmUgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktMy41IGJnLXNsYXRlLTEwMC82MCBkYXJrOmJnLXNsYXRlLTgwMC84MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zLjUgcHktMS41IHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+U2tvciBUb3RhbDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heD1cIjEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRSZXNwb25kZW50LnNjb3JlICE9IG51bGwgPyBzZWxlY3RlZFJlc3BvbmRlbnQuc2NvcmUgOiAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gcGFyc2VGbG9hdChlLnRhcmdldC52YWx1ZSkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUmVzcG9uZGVudChwcmV2ID0+ICh7IC4uLnByZXYsIHNjb3JlOiB2YWwgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkJsdXI9e2UgPT4gaGFuZGxlU2F2ZUluZGl2aWR1YWxTY29yZShzZWxlY3RlZFJlc3BvbmRlbnQucmVzcG9uc2VJZCwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE2IHRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgYmctdHJhbnNwYXJlbnQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS02MDAgZm9jdXM6Ym9yZGVyLVsjMDA4OTdCXSBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDBcIj4lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0xLjUgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5EaWphd2FiPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJlc3BvbmRlbnQuYW5zd2VyZWRDb3VudH0ve3NlbGVjdGVkUmVzcG9uZGVudC50b3RhbFF1ZXN0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTEuNSBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPkJlbmFyPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUmVzcG9uZGVudC5jb3JyZWN0Q291bnQgPz8gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTEuNSBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPldha3R1IFN1Ym1pdDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKHNlbGVjdGVkUmVzcG9uZGVudC5zdWJtaXR0ZWRBdCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBLTg6IEhvbGlzdGljIEFJIEFuYWx5c2lzIGJ1dHRvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KHNlbGVjdGVkUmVzcG9uZGVudC5hbnN3ZXJzIHx8IFtdKS5zb21lKGEgPT4gYS50eXBlSWQgPT09IDEpICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXthaU1vZGVsfSBvbkNoYW5nZT17ZSA9PiB7IHNldEFpTW9kZWwoZS50YXJnZXQudmFsdWUpOyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZm9ybXVwX3NlbGVjdGVkX21vZGVsX2NoYXQnLCBlLnRhcmdldC52YWx1ZSk7IH19IGNsYXNzTmFtZT1cIm1heC13LTM2IHB4LTIgcHktMiB0ZXh0LVsxMXB4XSBmb250LWJvbGQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge0FWQUlMQUJMRV9NT0RFTFMubWFwKG1vZGVsID0+IDxvcHRpb24ga2V5PXttb2RlbC5pZH0gdmFsdWU9e21vZGVsLmlkfT57bW9kZWwubmFtZX08L29wdGlvbj4pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBaUhvbGlzdGljU2NvcmUoc2VsZWN0ZWRSZXNwb25kZW50KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXthaUhvbGlzdGljU2NvcmluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0yIGJnLXdoaXRlIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS02MCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWlIb2xpc3RpY1Njb3JpbmcgPyAnTWVuaWxhaS4uLicgOiAnUGVuaWxhaWFuIFBpbnRhcid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBbnN3ZXJzIExpc3QgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC02IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoc2VsZWN0ZWRSZXNwb25kZW50LmFuc3dlcnMgfHwgW10pLm1hcCgoYW5zd2VyLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBxRGVmID0gKGZvcm1RdWVzdGlvbnMgfHwgW10pLmZpbmQocSA9PiBOdW1iZXIocS5pZCkgPT09IE51bWJlcihhbnN3ZXIucXVlc3Rpb25JZCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBlZmZJc0NvcnJlY3QgPSBnZXRFZmZlY3RpdmVJc0NvcnJlY3QoYW5zd2VyLCBxRGVmKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3RhdHVzID0gZ2V0QW5zd2VyU3RhdHVzKGFuc3dlciwgcURlZik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGtleUFuc3dlciA9IGFuc3dlci5jb3JyZWN0QW5zd2VyIHx8IHJlc29sdmVRdWVzdGlvbktleShxRGVmKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcVBvaW50cyA9IHFEZWYgJiYgTnVtYmVyKHFEZWYucG9pbnRzKSA+IDAgPyBOdW1iZXIocURlZi5wb2ludHMpIDogMTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17YW5zd2VyLnF1ZXN0aW9uSWQgfHwgaW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMyBmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2hyaW5rLTAgdy03IGgtNyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2luZGV4ICsgMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy1yZWxheGVkIGJyZWFrLXdvcmRzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXthbnN3ZXIucXVlc3Rpb259IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLW1kIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQm9ib3Q6IHtxUG9pbnRzfSBwb2luXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YW5zd2VyLnF1ZXN0aW9uSW1hZ2UgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTIgbWF4LXcteHMgcmVsYXRpdmUgZ3JvdXAvaW1nIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTEgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXthc3NldFVybChhbnN3ZXIucXVlc3Rpb25JbWFnZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiR2FtYmFyIFNvYWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1heC1oLTQwIHctYXV0byByb3VuZGVkLWxnIG9iamVjdC1jb250YWluIG14LWF1dG8gY3Vyc29yLXpvb20taW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExpZ2h0Ym94SW1hZ2UoeyBzcmM6IGFzc2V0VXJsKGFuc3dlci5xdWVzdGlvbkltYWdlKSwgYWx0OiAnR2FtYmFyIFNvYWwnIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRMaWdodGJveEltYWdlKHsgc3JjOiBhc3NldFVybChhbnN3ZXIucXVlc3Rpb25JbWFnZSksIGFsdDogJ0dhbWJhciBTb2FsJyB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMiByaWdodC0yIHAtMS41IGJnLXNsYXRlLTkwMC84MCBob3ZlcjpiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIG9wYWNpdHktMCBncm91cC1ob3Zlci9pbWc6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWF4aW1pemUyIHNpemU9ezExfSAvPiBQZXJiZXNhclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN0YXR1cyBCYWRnZSAmIFBlci1xdWVzdGlvbiBTY29yZSBDb3JyZWN0aW9uIENvbnRyb2xzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNocmluay0wIGZsZXggZmxleC1jb2wgaXRlbXMtZW5kIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIGJvcmRlciB0ZXh0LVsxMXB4XSBmb250LWJvbGQgJHtzdGF0dXMuY2xhc3NOYW1lfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzLmljb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntzdGF0dXMubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHAtMC41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2V0UXVlc3Rpb25Db3JyZWN0KHNlbGVjdGVkUmVzcG9uZGVudC5yZXNwb25zZUlkLCBhbnN3ZXIucXVlc3Rpb25JZCwgdHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yIHB5LTEgdGV4dC1bMTFweF0gZm9udC1ib2xkIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlZmZJc0NvcnJlY3QgPT09IHRydWUgJiYgYW5zd2VyLm1hbnVhbFNjb3JlID09IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAgdGV4dC13aGl0ZSBzaGFkb3ctMnhzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJLb3Jla3NpOiBUYW5kYWkgQmVuYXIgKDEwMCUpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmVuYXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2V0UXVlc3Rpb25Db3JyZWN0KHNlbGVjdGVkUmVzcG9uZGVudC5yZXNwb25zZUlkLCBhbnN3ZXIucXVlc3Rpb25JZCwgZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0xIHRleHQtWzExcHhdIGZvbnQtYm9sZCByb3VuZGVkIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWZmSXNDb3JyZWN0ID09PSBmYWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1yZWQtNTAwIHRleHQtd2hpdGUgc2hhZG93LTJ4cydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiS29yZWtzaTogVGFuZGFpIFNhbGFoICgwJSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTYWxhaFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQlVHLTMgRklYOiBwYXJ0aWFsIHNjb3JlIGlucHV0IOKAlCBvbmx5IHNob3duIGZvciBlc3NheSAodHlwZUlkIDEpLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExldHMgdGhlIG93bmVyIGF3YXJkIGUuZy4gOTAlIGZvciBhIG5lYXItY29ycmVjdCBhbnN3ZXIgaW5zdGVhZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9mIHRoZSBhbGwtb3Itbm90aGluZyBCZW5hci9TYWxhaCB0b2dnbGUuICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhhbnN3ZXIudHlwZUlkID09PSAxIHx8IHFEZWY/LnR5cGVJZCA9PT0gMSkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXJ0aWFsU2NvcmVFZGl0aW5nSWQgPT09IChhbnN3ZXIuYW5zd2VySWQgfHwgYW5zd2VyLmlkIHx8IGFuc3dlci5xdWVzdGlvbklkKSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9XCIxMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGFydGlhbFNjb3JlSW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFBhcnRpYWxTY29yZUlucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXtlID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gJ0VzY2FwZScpIHNldFBhcnRpYWxTY29yZUVkaXRpbmdJZChudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xNiBweC0yIHB5LTEgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1hbWJlci00MDAgZGFyazpib3JkZXItYW1iZXItNjAwIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgdGV4dC1jZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjDigJMxMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj4lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBhcnRpYWxTY29yZUVkaXRpbmdJZChudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIHRleHQtWzExcHhdIGZvbnQtYm9sZCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJCYXRhbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDinJVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFBjdCA9IGFuc3dlci5tYW51YWxTY29yZSAhPSBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IE1hdGgucm91bmQoKE51bWJlcihhbnN3ZXIubWFudWFsU2NvcmUpIC8gcVBvaW50cykgKiAxMDApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGVmZklzQ29ycmVjdCA9PT0gdHJ1ZSA/IDEwMCA6IGVmZklzQ29ycmVjdCA9PT0gZmFsc2UgPyAwIDogJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBhcnRpYWxTY29yZUlucHV0KFN0cmluZyhjdXJyZW50UGN0KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBhcnRpYWxTY29yZUVkaXRpbmdJZChhbnN3ZXIuYW5zd2VySWQgfHwgYW5zd2VyLmlkIHx8IGFuc3dlci5xdWVzdGlvbklkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtWzExcHhdIGZvbnQtYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLWxnIGJvcmRlciBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXIubWFudWFsU2NvcmUgIT0gbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNTAgYm9yZGVyLWFtYmVyLTMwMCBkYXJrOmJvcmRlci1hbWJlci03MDAgdGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTMwMCBob3Zlcjp0ZXh0LWFtYmVyLTYwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkF0dXIgc2tvciBwYXJzaWFsICglKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Fuc3dlci5tYW51YWxTY29yZSAhPSBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYCR7TWF0aC5yb3VuZCgoTnVtYmVyKGFuc3dlci5tYW51YWxTY29yZSkgLyBxUG9pbnRzKSAqIDEwMCl9JSBwYXJzaWFsYFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICfCsSBTa29yIFBhcnNpYWwnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEItMjogQ29tcGxldGUgY29ycmVjdGlvbiBwYW5lbCB0b2dnbGUg4oCUIGV4cGxpY2l0IG92ZXJyaWRlICsgbm90ZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZUNvcnJlY3Rpb25JZCAhPT0gKGFuc3dlci5hbnN3ZXJJZCB8fCBhbnN3ZXIuaWQgfHwgYW5zd2VyLnF1ZXN0aW9uSWQpID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYW5zS2V5ID0gYW5zd2VyLmFuc3dlcklkIHx8IGFuc3dlci5pZCB8fCBhbnN3ZXIucXVlc3Rpb25JZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlQ29ycmVjdGlvbklkKGFuc0tleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENvcnJlY3Rpb25Ob3RlKGFuc3dlci5vdmVycmlkZU5vdGUgfHwgJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDb3JyZWN0aW9uSXNDb3JyZWN0T3ZlcnJpZGUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXIuaXNDb3JyZWN0T3ZlcnJpZGUgIT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYW5zd2VyLmlzQ29ycmVjdE92ZXJyaWRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBhcnRpYWxTY29yZUVkaXRpbmdJZCAhPT0gYW5zS2V5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50UGN0ID0gYW5zd2VyLm1hbnVhbFNjb3JlICE9IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IE1hdGgucm91bmQoKE51bWJlcihhbnN3ZXIubWFudWFsU2NvcmUpIC8gcVBvaW50cykgKiAxMDApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBlZmZJc0NvcnJlY3QgPT09IHRydWUgPyAxMDAgOiBlZmZJc0NvcnJlY3QgPT09IGZhbHNlID8gMCA6ICcnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGFydGlhbFNjb3JlSW5wdXQoU3RyaW5nKGN1cnJlbnRQY3QpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBhcnRpYWxTY29yZUVkaXRpbmdJZChhbnNLZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWluZGlnby0zMDAgZGFyazpib3JkZXItaW5kaWdvLTcwMCBiZy1pbmRpZ28tNTAgZGFyazpiZy1pbmRpZ28tOTUwLzUwIHRleHQtaW5kaWdvLTcwMCBkYXJrOnRleHQtaW5kaWdvLTMwMCBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1pbmRpZ28tMTAwIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkJ1a2EgcGFuZWwga29yZWtzaSBsZW5na2FwIChjYXRhdGFuICsgb3ZlcnJpZGUgc3RhdHVzKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+TnSBLb3Jla3NpIExlbmdrYXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEItMjogRXhwYW5kYWJsZSBDb21wbGV0ZSBDb3JyZWN0aW9uIFBhbmVsIChFc3NheSBvbmx5KSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGFuc3dlci50eXBlSWQgPT09IDEgfHwgcURlZj8udHlwZUlkID09PSAxKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVDb3JyZWN0aW9uSWQgPT09IChhbnN3ZXIuYW5zd2VySWQgfHwgYW5zd2VyLmlkIHx8IGFuc3dlci5xdWVzdGlvbklkKSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgdy1mdWxsIHAtNCByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLWluZGlnby01MCB0by12aW9sZXQtNTAgZGFyazpmcm9tLWluZGlnby05NTAvNDAgZGFyazp0by12aW9sZXQtOTUwLzQwIGJvcmRlciBib3JkZXItaW5kaWdvLTIwMC82MCBkYXJrOmJvcmRlci1pbmRpZ28tOTAwLzQwIHNwYWNlLXktMyBhbmltYXRlLWZhZGVJblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02IGgtNiByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLXRyIGZyb20taW5kaWdvLTYwMCB0by12aW9sZXQtNTAwIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBhbmVsIEtvcmVrc2kgSmF3YWJhbiBFc3NheVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldEFjdGl2ZUNvcnJlY3Rpb25JZChudWxsKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAxIOKAlCBTa29yIFBhcnNpYWwgKHBlcmNlbnRhZ2UgaW5wdXQgYWxyZWFkeSBzaG93biBhYm92ZSwgcmVwZWF0IGhlcmUgZm9yIFVYKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTMgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQS4gU2tvciBQYXJzaWFsICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZvbnQtYm9sZCB0ZXh0LWluZGlnby02MDAgZGFyazp0ZXh0LWluZGlnby0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCfj4YgU2tvciBQYXJzaWFsICglKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS00MDAgbm9ybWFsLWNhc2UgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKG1ha3MuIHtxUG9pbnRzfSBwb2luKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9XCIxMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXJ0aWFsU2NvcmVJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0UGFydGlhbFNjb3JlSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgdy1mdWxsIHB4LTMgcHktMiBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAgZGFyazpib3JkZXItaW5kaWdvLTgwMCByb3VuZGVkLXhsIHRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMC80MCBmb2N1czpib3JkZXItaW5kaWdvLTUwMC82MCB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMOKAkzEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHctNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2tvciBwYXJzaWFsIGRhbGFtIHBlcnNlbnRhc2UuIENvbnRvaDogODAlID0geygwLjggKiBxUG9pbnRzKS50b0ZpeGVkKDEpfSBwb2luXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGFyaSB0b3RhbCB7cVBvaW50c30gcG9pbi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEIuIE92ZXJyaWRlIFN0YXR1cyBCZW5hci9TYWxhaCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwIGRhcms6dGV4dC1pbmRpZ28tMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5SSIE92ZXJyaWRlIFN0YXR1c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcC0yLjUgcm91bmRlZC14bCBiZy13aGl0ZS83MCBkYXJrOmJnLXNsYXRlLTkwMC82MCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAvNTAgZGFyazpib3JkZXItaW5kaWdvLTgwMC81MCBjdXJzb3ItcG9pbnRlciBob3Zlcjpib3JkZXItaW5kaWdvLTQwMC82MCB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtjb3JyZWN0aW9uSXNDb3JyZWN0T3ZlcnJpZGUgPT09IHRydWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29ycmVjdGlvbklzQ29ycmVjdE92ZXJyaWRlKGUudGFyZ2V0LmNoZWNrZWQgPyB0cnVlIDogKGNvcnJlY3Rpb25Jc0NvcnJlY3RPdmVycmlkZSA9PT0gdHJ1ZSA/IGZhbHNlIDogdW5kZWZpbmVkKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCByb3VuZGVkLW1kIHRleHQtZW1lcmFsZC02MDAgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBjdXJzb3ItcG9pbnRlciBhY2NlbnQtZW1lcmFsZC02MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhbmRhaSBKYXdhYmFuIEluaSBCZW5hclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENlbnRhbmcgYmlsYSBqYXdhYmFuIHRpZGFrIGV4YWN0IG1hdGNoIHRhcGkga29uc2VwbnlhIGJlbmFyIChvdmVycmlkZSkuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMHB4XSBmb250LWJsYWNrIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29ycmVjdGlvbklzQ29ycmVjdE92ZXJyaWRlID09PSB0cnVlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGNvcnJlY3Rpb25Jc0NvcnJlY3RPdmVycmlkZSA9PT0gZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcmVkLTUwMCB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0zMDAgZGFyazpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvcnJlY3Rpb25Jc0NvcnJlY3RPdmVycmlkZSA9PT0gdHJ1ZSA/ICdCRU5BUicgOiBjb3JyZWN0aW9uSXNDb3JyZWN0T3ZlcnJpZGUgPT09IGZhbHNlID8gJ1NBTEFIJyA6ICdBVVRPJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvcnJlY3Rpb25Jc0NvcnJlY3RPdmVycmlkZSA9PT0gZmFsc2UgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENvcnJlY3Rpb25Jc0NvcnJlY3RPdmVycmlkZSh1bmRlZmluZWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1pbmRpZ28tNjAwIGZvbnQtbWVkaXVtIHVuZGVybGluZSBkZWNvcmF0aW9uLWRvdHRlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlc2V0IGtlIHN0YXR1cyBvdG9tYXRpc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb3JyZWN0aW9uSXNDb3JyZWN0T3ZlcnJpZGUgPT09IHRydWUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENvcnJlY3Rpb25Jc0NvcnJlY3RPdmVycmlkZShmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LWluZGlnby02MDAgZm9udC1tZWRpdW0gdW5kZXJsaW5lIGRlY29yYXRpb24tZG90dGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFuZGFpIHNlYmFnYWkgc2FsYWhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAyIOKAlCBDYXRhdGFuIGtlIFNpc3dhIChPdmVycmlkZU5vdGUpICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZvbnQtYm9sZCB0ZXh0LWluZGlnby02MDAgZGFyazp0ZXh0LWluZGlnby0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+SrCBDYXRhdGFuIGtlIFNpc3dhIChPcHRpb25hbClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29ycmVjdGlvbk5vdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRDb3JyZWN0aW9uTm90ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUdWxpcyBjYXRhdGFuIHVudHVrIHNpc3dhLCBtaXNhbDogQmFndXMsIHRhcGkgcnVtdXNueWEga3VyYW5nIHRlcGF0IGRpIGxhbmdrYWgga2VkdWEuIENvYmEgcGVyaWtzYSBrZW1iYWxpIGF0dXJhbiBpbnRlZ3JhbC5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMi41IHRleHQtc20gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAgZGFyazpib3JkZXItaW5kaWdvLTgwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwLzQwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwLzYwIHBsYWNlaG9sZGVyOnRleHQtc2xhdGUtNDAwIHJlc2l6ZS15XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2F0YXRhbiBpbmkgYWthbiBkaXRhbXBpbGthbiBrZXBhZGEgcmVzcG9uZGVuL3Npc3dhIHNhYXQgbWVsaWhhdCBoYXNpbCBwZW5nZXJqYWFuLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogMyDigJQgRGlzcGxheSBleGlzdGluZyBub3RlIChpZiBhbnkpICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthbnN3ZXIub3ZlcnJpZGVOb3RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC14bCBiZy13aGl0ZS83MCBkYXJrOmJnLXNsYXRlLTkwMC82MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMC82MCBkYXJrOmJvcmRlci1hbWJlci04MDAvNjBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb250LWJvbGQgdGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+TjCBDYXRhdGFuIFNlYmVsdW1ueWE6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9udC1tZWRpdW0gd2hpdGVzcGFjZS1wcmUtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthbnN3ZXIub3ZlcnJpZGVOb3RlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDQg4oCUIFNpbXBhbiBLb3Jla3NpIExlbmdrYXAgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMiBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZUNvcnJlY3Rpb25JZChudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQYXJ0aWFsU2NvcmVFZGl0aW5nSWQobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBiZy13aGl0ZS83MCBkYXJrOmJnLXNsYXRlLTgwMC81MCBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhdGFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmVDb21wbGV0ZUNvcnJlY3Rpb24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRSZXNwb25kZW50LnJlc3BvbnNlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyLnF1ZXN0aW9uSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyLmFuc3dlcklkIHx8IGFuc3dlci5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxUG9pbnRzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCBiZy1ncmFkaWVudC10by1yIGZyb20taW5kaWdvLTYwMCB0by12aW9sZXQtNTAwIGhvdmVyOmZyb20taW5kaWdvLTcwMCBob3Zlcjp0by12aW9sZXQtNjAwIHRleHQtd2hpdGUgcm91bmRlZC14bCBzaGFkb3cteHMgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtWzEuMDJdIGFjdGl2ZTpzY2FsZS1bMC45OF1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5K+IFNpbXBhbiBLb3Jla3NpIExlbmdrYXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC00IHNwYWNlLXktMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEphd2FiYW4gUmVzcG9uZGVuOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Byb3VuZGVkLXhsIGJvcmRlciBwLTMgZm9udC1tZWRpdW0gJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlZmZJc0NvcnJlY3QgPT09IHRydWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzQwIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMCB0ZXh0LWVtZXJhbGQtOTAwIGRhcms6dGV4dC1lbWVyYWxkLTIwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBlZmZJc0NvcnJlY3QgPT09IGZhbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNDAgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTgwMCB0ZXh0LXJlZC05MDAgZGFyazp0ZXh0LXJlZC0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Fuc3dlci5hbnN3ZXJUZXh0IHx8IGFuc3dlci5hbnN3ZXJWYWx1ZSB8fCBhbnN3ZXIub3B0aW9uVGV4dCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17YW5zd2VyLmFuc3dlclRleHQgfHwgYW5zd2VyLmFuc3dlclZhbHVlIHx8IGFuc3dlci5vcHRpb25UZXh0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgaXRhbGljXCI+VGlkYWsgYWRhIGphd2FiYW48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7a2V5QW5zd2VyICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgS3VuY2kgLyBKYXdhYmFuIEJlbmFyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDAgcC0zIHRleHQtZW1lcmFsZC05MDAgZGFyazp0ZXh0LWVtZXJhbGQtMjAwIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXtrZXlBbnN3ZXJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KCFzZWxlY3RlZFJlc3BvbmRlbnQuYW5zd2VycyB8fCBzZWxlY3RlZFJlc3BvbmRlbnQuYW5zd2Vycy5sZW5ndGggPT09IDApICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMiB0ZXh0LXNtIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJpbmNpYW4gamF3YWJhbiB0aWRhayB0ZXJzZWRpYS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogTmF2aWdhdGlvbiBGb290ZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktMyBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2dvUHJldmlvdXN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50SW5kZXggPD0gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgc2l6ZT17MTV9IC8+IFNlYmVsdW1ueWFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50SW5kZXggKyAxfSBkYXJpIHtyZXNwb25kZW50c0xpc3QubGVuZ3RofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Z29OZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y3VycmVudEluZGV4ID09PSByZXNwb25kZW50c0xpc3QubGVuZ3RoIC0gMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZWxhbmp1dG55YSA8Q2hldnJvblJpZ2h0IHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7Lyog4pSA4pSAIEEtODogSE9MSVNUSUMgQUkgU0NPUklORyBQUkVWSUVXIE1PREFMIOKUgOKUgCAqL31cbiAgICAgICAgICAgIHthaUhvbGlzdGljUHJldmlld09wZW4gJiYgYWlIb2xpc3RpY1Jlc3VsdCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzYwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzYwIGJhY2tkcm9wLWJsdXIteHNcIiBvbkNsaWNrPXsoKSA9PiBzZXRBaUhvbGlzdGljUHJldmlld09wZW4oZmFsc2UpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHctZnVsbCBtYXgtdy1sZyBtYXgtaC1bODV2aF0gcm91bmRlZC0zeGwgc2hhZG93LTJ4bCBmbGV4IGZsZXgtY29sIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgei0xMCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzaHJpbmstMCBiZy1wdXJwbGUtNTAvNTAgZGFyazpiZy1wdXJwbGUtOTUwLzIwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5TYXJhbiBTa29yIEFJIOKAlCBSZXZpZXcgSG9saXN0aWM8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPnthaUhvbGlzdGljUmVzdWx0LmVzc2F5U3VnZ2VzdGlvbnMubGVuZ3RofSBzb2FsIGVzc2F5IGRpYW5hbGlzaXM8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldEFpSG9saXN0aWNQcmV2aWV3T3BlbihmYWxzZSl9IGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogUEcgU3VtbWFyeSArIFRvdGFsIEVzdGltYXRlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgeyhhaUhvbGlzdGljUmVzdWx0LnBnU3VtbWFyeSB8fCBhaUhvbGlzdGljUmVzdWx0LnRvdGFsRXN0aW1hdGUgIT09IG51bGwpICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtd3JhcCBnYXAtNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthaUhvbGlzdGljUmVzdWx0LnBnU3VtbWFyeSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+UEc6PC9zcGFuPiB7YWlIb2xpc3RpY1Jlc3VsdC5wZ1N1bW1hcnl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthaUhvbGlzdGljUmVzdWx0LnRvdGFsRXN0aW1hdGUgIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1wdXJwbGUtNzAwIGRhcms6dGV4dC1wdXJwbGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRXN0aW1hc2kgU2tvciBUb3RhbDoge2FpSG9saXN0aWNSZXN1bHQudG90YWxFc3RpbWF0ZX0lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRXNzYXkgU3VnZ2VzdGlvbnMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC01IHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthaUhvbGlzdGljUmVzdWx0LmVzc2F5U3VnZ2VzdGlvbnMubWFwKCh7IGFuc3dlciwgc3VnZ2VzdGlvbiB9LCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAvNjAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZmxleC0xIGxpbmUtY2xhbXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGFuc3dlci5xdWVzdGlvbiB8fCAnJykucmVwbGFjZSgvPFtePl0qPi9nLCAnJykuc3Vic3RyaW5nKDAsIDEwMCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHNocmluay0wIHRleHQteHMgZm9udC1leHRyYWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsICR7c3VnZ2VzdGlvbi5pc0NvcnJlY3QgPyAnYmctZW1lcmFsZC0xMDAgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCcgOiAnYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAgZGFyazpiZy1yZWQtOTUwLzYwIGRhcms6dGV4dC1yZWQtMzAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N1Z2dlc3Rpb24uc2NvcmV9JVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBpdGFsaWNcIj5cIntzdWdnZXN0aW9uLnJlYXNvbn1cIjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEphd2FiYW46IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj57KChhbnN3ZXIuYW5zd2VyVGV4dCB8fCBhbnN3ZXIuYW5zd2VyVmFsdWUgfHwgJyhrb3NvbmcpJykpLnN1YnN0cmluZygwLCA4MCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGb290ZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hyaW5rLTAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRBaUhvbGlzdGljUHJldmlld09wZW4oZmFsc2UpfSBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYXRhbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUFwcGx5QWxsQWlTY29yZXN9IGNsYXNzTmFtZT1cInB4LTUgcHktMi41IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgZGFyazpiZy1zbGF0ZS03MDAgZGFyazpob3ZlcjpiZy1zbGF0ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHNoYWRvdy14cyBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUZXJhcGthbiBTZW11YSBTa29yIEFJICh7YWlIb2xpc3RpY1Jlc3VsdC5lc3NheVN1Z2dlc3Rpb25zLmxlbmd0aH0gZXNzYXkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7Lyog4pSA4pSAIEJVTEsgU0NPUkUgQURKVVNUTUVOVCBNT0RBTCDilIDilIAgKi99XG4gICAgICAgICAgICB7YnVsa01vZGFsT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRCdWxrTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHctZnVsbCBtYXgtdy14bCBtYXgtaC1bOTB2aF0gcm91bmRlZC0zeGwgc2hhZG93LTJ4bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0xNTAgZm9udC1zYW5zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hyaW5rLTAgYmctc2xhdGUtNTAvNTAgZGFyazpiZy1zbGF0ZS04MDAvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2xpZGVycyBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZW55ZXN1YWlhbiBTa29yIE1hc3NhbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZXN1YWlrYW4gbmlsYWkgcmVzcG9uZGVuIGRlbmdhbiBmaWx0ZXIgZGFuIGF0dXJhbiBmbGVrc2liZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QnVsa01vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEJvZHkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBvdmVyZmxvdy15LWF1dG8gc3BhY2UteS01IGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAxLiBUYXJnZXQgRmlsdGVyICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJsb2NrIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDEuIFRhcmdldCBSZXNwb25kZW4geWFuZyBEaXNlc3VhaWthbjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QnVsa0ZpbHRlcignYWxsJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa0ZpbHRlciA9PT0gJ2FsbCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCBib3JkZXItWyMwMDg5N0JdIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBzaGFkb3ctMnhzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZW11YSBSZXNwb25kZW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJ1bGtGaWx0ZXIoJ2JlbG93Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa0ZpbHRlciA9PT0gJ2JlbG93J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIGJvcmRlci1bIzAwODk3Ql0gdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwIHNoYWRvdy0yeHMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5pbGFpIGRpIEJhd2FoIEJhdGFzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRCdWxrRmlsdGVyKCdyYW5nZScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIHRleHQteHMgZm9udC1ib2xkIHRleHQtY2VudGVyIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtGaWx0ZXIgPT09ICdyYW5nZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCBib3JkZXItWyMwMDg5N0JdIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBzaGFkb3ctMnhzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZW50YW5nIE5pbGFpIFRlcnRlbnR1XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2J1bGtGaWx0ZXIgPT09ICdiZWxvdycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5IYW55YSBzZXN1YWlrYW4gcmVzcG9uZGVuIGRlbmdhbiBuaWxhaSBkaSBiYXdhaDo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9XCIxMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlclRocmVzaG9sZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZpbHRlclRocmVzaG9sZChwYXJzZUZsb2F0KGUudGFyZ2V0LnZhbHVlKSB8fCAwKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTYgcHgtMiBweS0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNjAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtY2VudGVyIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMFwiPiU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YnVsa0ZpbHRlciA9PT0gJ3JhbmdlJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgcC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPkhhbnlhIHNlc3VhaWthbiByZXNwb25kZW4gZGVuZ2FuIG5pbGFpIGFudGFyYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9XCIxMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlclJhbmdlTWlufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0RmlsdGVyUmFuZ2VNaW4ocGFyc2VGbG9hdChlLnRhcmdldC52YWx1ZSkgfHwgMCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE0IHB4LTIgcHktMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTYwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LWNlbnRlciBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPnMvZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4PVwiMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJSYW5nZU1heH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZpbHRlclJhbmdlTWF4KHBhcnNlRmxvYXQoZS50YXJnZXQudmFsdWUpIHx8IDApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xNCBweC0yIHB5LTEgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS02MDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC1jZW50ZXIgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwXCI+JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDIuIEFkanVzdG1lbnQgTWV0aG9kICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJsb2NrIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDIuIE1ldG9kZSBQZW55ZXN1YWlhbiBOaWxhaTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIHAtMyByb3VuZGVkLTJ4bCBib3JkZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVHlwZSA9PT0gJ21pbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLVsjMDA4OTdCXSBiZy10ZWFsLTUwLzQwIGRhcms6YmctdGVhbC05NTAvNDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1zbGF0ZS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJidWxrVHlwZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPVwibWluXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17YnVsa1R5cGUgPT09ICdtaW4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4geyBzZXRCdWxrVHlwZSgnbWluJyk7IHNldEJ1bGtWYWx1ZSg3NSk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LVsjMDA4OTdCXSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5CYXRhcyBTa29yIE1pbmltdW0gKFRocmVzaG9sZCk8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5OaWxhaSBkaSBiYXdhaCBiYXRhcyBkaW5haWtrYW4ga2UgYmF0YXMuIE5pbGFpIHlhbmcgc3VkYWggZGkgYXRhcyBiYXRhcyB0ZXRhcCBhbWFuIGRhbiB0aWRhayBha2FuIHR1cnVuLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIHAtMyByb3VuZGVkLTJ4bCBib3JkZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVHlwZSA9PT0gJ2JvbnVzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItWyMwMDg5N0JdIGJnLXRlYWwtNTAvNDAgZGFyazpiZy10ZWFsLTk1MC80MCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImJ1bGtUeXBlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9XCJib251c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2J1bGtUeXBlID09PSAnYm9udXMnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4geyBzZXRCdWxrVHlwZSgnYm9udXMnKTsgc2V0QnVsa1ZhbHVlKDEwKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMC41IHRleHQtWyMwMDg5N0JdIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlRhbWJhaCBOaWxhaSBCb251cyAoKyBQb2luKTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlRhbWJhaGthbiBwb2luIHRldGFwIGtlIHNldGlhcCByZXNwb25kZW4geWFuZyBtZW1lbnVoaSBrcml0ZXJpYSAobWFrc2ltYWwgMTAwKS48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1zdGFydCBnYXAtMyBwLTMgcm91bmRlZC0yeGwgYm9yZGVyIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1R5cGUgPT09ICdzY2FsZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLVsjMDA4OTdCXSBiZy10ZWFsLTUwLzQwIGRhcms6YmctdGVhbC05NTAvNDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1zbGF0ZS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJidWxrVHlwZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPVwic2NhbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtidWxrVHlwZSA9PT0gJ3NjYWxlJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHsgc2V0QnVsa1R5cGUoJ3NjYWxlJyk7IHNldEJ1bGtWYWx1ZSgxMTApOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0wLjUgdGV4dC1bIzAwODk3Ql0gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+S2FsaWthbiBLdXJ2YSBTa2FsYSBQZXJzZW50YXNlICh4ICUpPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+S2FsaWthbiBuaWxhaSBzYWF0IGluaSBkZW5nYW4gcGVyc2VudGFzZSB0ZXJ0ZW50dSAobWlzYWw6IDExMCUgPSBuaWxhaSB4IDEuMSkuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcC0zIHJvdW5kZWQtMnhsIGJvcmRlciBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtUeXBlID09PSAnc2V0X2ZpeGVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItWyMwMDg5N0JdIGJnLXRlYWwtNTAvNDAgZGFyazpiZy10ZWFsLTk1MC80MCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImJ1bGtUeXBlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9XCJzZXRfZml4ZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtidWxrVHlwZSA9PT0gJ3NldF9maXhlZCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7IHNldEJ1bGtUeXBlKCdzZXRfZml4ZWQnKTsgc2V0QnVsa1ZhbHVlKDgwKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMC41IHRleHQtWyMwMDg5N0JdIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlRldGFwa2FuIE5pbGFpIFJhdGEgKD0gTmlsYWkgVGV0YXApPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+VWJhaCBzZWx1cnVoIG5pbGFpIHJlc3BvbmRlbiB5YW5nIG1lbWVudWhpIGtyaXRlcmlhIGxhbmdzdW5nIG1lbmphZGkgbmlsYWkgaW5pLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDMuIFBhcmFtZXRlciBWYWx1ZSBJbnB1dCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBibG9jayBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtidWxrVHlwZSA9PT0gJ21pbicgPyAnQmF0YXMgTmlsYWkgTWluaW11bSBUYXJnZXQ6JyA6IGJ1bGtUeXBlID09PSAnYm9udXMnID8gJ0p1bWxhaCBQb2luIEJvbnVzIFRhbWJhaGFuICgrKTonIDogYnVsa1R5cGUgPT09ICdzY2FsZScgPyAnRmFrdG9yIFNrYWxhIFBlcnNlbnRhc2UgKCUpOicgOiAnTmlsYWkgVGV0YXAgeWFuZyBEaXRlcmFwa2FuOid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9e2J1bGtUeXBlID09PSAnc2NhbGUnID8gJzUnIDogJzEnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heD17YnVsa1R5cGUgPT09ICdzY2FsZScgPyAnMjAwJyA6ICcxMDAnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtidWxrVmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0QnVsa1ZhbHVlKHBhcnNlRmxvYXQoZS50YXJnZXQudmFsdWUpIHx8IDApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdGV4dC1zbSBmb250LWJvbGQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YnVsa1R5cGUgPT09ICdzY2FsZScgPyAnJScgOiAncG9pbid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDQuIExpdmUgUHJldmlldyBTZWN0aW9uICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExpdmUgUHJldmlldyBQZXJ1YmFoYW4gTmlsYWk6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ByZXZpZXdBZGp1c3RtZW50cy5maWx0ZXIocCA9PiBwLm1lZXRzRmlsdGVyICYmIHAuZGlmZiAhPT0gMCkubGVuZ3RofSBkYXJpIHtwcmV2aWV3QWRqdXN0bWVudHMubGVuZ3RofSByZXNwb25kZW4gdGVycGVuZ2FydWhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIG1heC1oLTQ0IG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzIHRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIHN0aWNreSB0b3AtMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMiBweC0zXCI+UmVzcG9uZGVuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yIHB4LTMgdGV4dC1jZW50ZXJcIj5Ta29yIFNhYXQgSW5pPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yIHB4LTMgdGV4dC1jZW50ZXJcIj5Ta29yIEJhcnU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIgcHgtMyB0ZXh0LXJpZ2h0XCI+UGVydWJhaGFuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJldmlld0FkanVzdG1lbnRzLm1hcCgoaXRlbSwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLnJlc3BvbnNlSWQgfHwgaWR4fSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC81MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5yZXNwb25kZW50TmFtZSB8fCAnQW5vbmltJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTMgdGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY3VycmVudFNjb3JlfSVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTMgdGV4dC1jZW50ZXIgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnByb2plY3RlZFNjb3JlfSVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTMgdGV4dC1yaWdodCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGlmZiA+IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBmb250LWV4dHJhYm9sZFwiPit7aXRlbS5kaWZmfSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBpdGVtLmRpZmYgPCAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGRhcms6dGV4dC1yZWQtNDAwIGZvbnQtZXh0cmFib2xkXCI+e2l0ZW0uZGlmZn0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1ub3JtYWxcIj5UZXRhcDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzaHJpbmstMCBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC81MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlc2V0QWxsU2NvcmVzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtcmVkLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiS2VtYmFsaWthbiBzZW11YSBuaWxhaSBrZSBwZXJoaXR1bmdhbiBhc2xpIHNpc3RlbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IHNpemU9ezEzfSAvPiBSZXNldCBTZW11YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJ1bGtNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmF0YWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQXBwbHlCdWxrU2NvcmV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LXhzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVyYXBrYW4gUGVydWJhaGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogUHJvY3RvciBBY3Rpb24gQ29uZmlybWF0aW9uIE1vZGFsICovfVxuICAgICAgICAgICAgPENvbmZpcm1Nb2RhbFxuICAgICAgICAgICAgICAgIGlzT3Blbj17cHJvY3Rvck1vZGFsLmlzT3Blbn1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiAhcHJvY3Rvck1vZGFsLmxvYWRpbmcgJiYgc2V0UHJvY3Rvck1vZGFsKHByZXYgPT4gKHsgLi4ucHJldiwgaXNPcGVuOiBmYWxzZSB9KSl9XG4gICAgICAgICAgICAgICAgb25Db25maXJtPXtoYW5kbGVDb25maXJtUHJvY3RvckFjdGlvbn1cbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e3Byb2N0b3JNb2RhbC5sb2FkaW5nfVxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9e3Byb2N0b3JNb2RhbC50eXBlID09PSAnZm9yY2Vfc3VibWl0JyA/ICd3YXJuaW5nJyA6ICdkYW5nZXInfVxuICAgICAgICAgICAgICAgIHRpdGxlPXtwcm9jdG9yTW9kYWwudHlwZSA9PT0gJ2ZvcmNlX3N1Ym1pdCcgPyAnU2VsZXNhaWthbiBQYWtzYSBTZXNpIFVqaWFuPycgOiAnUmVzZXQgSmF3YWJhbiBQZXNlcnRhPyd9XG4gICAgICAgICAgICAgICAgbWVzc2FnZT17XG4gICAgICAgICAgICAgICAgICAgIHByb2N0b3JNb2RhbC50eXBlID09PSAnZm9yY2Vfc3VibWl0J1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBgQXBha2FoIEFuZGEgeWFraW4gaW5naW4gbWVueWVsZXNhaWthbiBwYWtzYSBzZXNpIHVqaWFuIHVudHVrIHBlc2VydGEgXCIke3Byb2N0b3JNb2RhbC5yZXNwb25kZW50TmFtZX1cIj8gRHJhZnQgamF3YWJhbiB5YW5nIHRlcnNpbmtyb25pc2FzaSBha2FuIGRpc2ltcGFuIGRhbiBzdGF0dXMgc2VzaSBha2FuIGRpdWJhaCBtZW5qYWRpIHN1Ym1pdHRlZC5gXG4gICAgICAgICAgICAgICAgICAgICAgICA6IGBBcGFrYWggQW5kYSB5YWtpbiBpbmdpbiBtZS1yZXNldCBqYXdhYmFuIHlhbmcgc3VkYWggZGlzdWJtaXQgb2xlaCBcIiR7cHJvY3Rvck1vZGFsLnJlc3BvbmRlbnROYW1lfVwiPyBEYXRhIGxhbWEgZGlwZXJ0YWhhbmthbiBkYW4gcGVzZXJ0YSBkaWJlcmkgMSBqYXRhaCBpc2kgdWxhbmcuIEhhbnlhIHNlc2kgeWFuZyBzdWRhaCBkaXN1Ym1pdCB5YW5nIGJpc2EgZGktcmVzZXQuYFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25maXJtVGV4dD17cHJvY3Rvck1vZGFsLnR5cGUgPT09ICdmb3JjZV9zdWJtaXQnID8gJ1lhLCBTZWxlc2Fpa2FuIFBha3NhJyA6ICdZYSwgUmVzZXQgSmF3YWJhbid9XG4gICAgICAgICAgICAgICAgY2FuY2VsVGV4dD1cIkJhdGFsXCJcbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiBMaWdodGJveCBNb2RhbCAqL31cbiAgICAgICAgICAgIDxJbWFnZUxpZ2h0Ym94TW9kYWxcbiAgICAgICAgICAgICAgICBpc09wZW49eyEhbGlnaHRib3hJbWFnZX1cbiAgICAgICAgICAgICAgICBzcmM9e2xpZ2h0Ym94SW1hZ2U/LnNyY31cbiAgICAgICAgICAgICAgICBhbHQ9e2xpZ2h0Ym94SW1hZ2U/LmFsdH1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRMaWdodGJveEltYWdlKG51bGwpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==