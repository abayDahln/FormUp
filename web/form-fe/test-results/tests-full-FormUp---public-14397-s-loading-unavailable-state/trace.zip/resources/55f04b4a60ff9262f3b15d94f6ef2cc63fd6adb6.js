//#region node_modules/@studio-freight/lenis/dist/lenis.mjs
function t(t, e, i) {
	return Math.max(t, Math.min(e, i));
}
var Animate = class {
	advance(e) {
		if (!this.isRunning) return;
		let i = !1;
		if (this.lerp) this.value = (s = this.value, o = this.to, n = 60 * this.lerp, r = e, function(t, e, i) {
			return (1 - i) * t + i * e;
		}(s, o, 1 - Math.exp(-n * r))), Math.round(this.value) === this.to && (this.value = this.to, i = !0);
		else {
			this.currentTime += e;
			const s = t(0, this.currentTime / this.duration, 1);
			i = s >= 1;
			const o = i ? 1 : this.easing(s);
			this.value = this.from + (this.to - this.from) * o;
		}
		var s, o, n, r;
		this.onUpdate?.(this.value, i), i && this.stop();
	}
	stop() {
		this.isRunning = !1;
	}
	fromTo(t, e, { lerp: i = .1, duration: s = 1, easing: o = ((t) => t), onStart: n, onUpdate: r }) {
		this.from = this.value = t, this.to = e, this.lerp = i, this.duration = s, this.easing = o, this.currentTime = 0, this.isRunning = !0, n?.(), this.onUpdate = r;
	}
};
var Dimensions = class {
	constructor({ wrapper: t, content: e, autoResize: i = !0, debounce: s = 250 } = {}) {
		this.wrapper = t, this.content = e, i && (this.debouncedResize = function(t, e) {
			let i;
			return function() {
				let s = arguments, o = this;
				clearTimeout(i), i = setTimeout((function() {
					t.apply(o, s);
				}), e);
			};
		}(this.resize, s), this.wrapper === window ? window.addEventListener("resize", this.debouncedResize, !1) : (this.wrapperResizeObserver = new ResizeObserver(this.debouncedResize), this.wrapperResizeObserver.observe(this.wrapper)), this.contentResizeObserver = new ResizeObserver(this.debouncedResize), this.contentResizeObserver.observe(this.content)), this.resize();
	}
	destroy() {
		this.wrapperResizeObserver?.disconnect(), this.contentResizeObserver?.disconnect(), window.removeEventListener("resize", this.debouncedResize, !1);
	}
	resize = () => {
		this.onWrapperResize(), this.onContentResize();
	};
	onWrapperResize = () => {
		this.wrapper === window ? (this.width = window.innerWidth, this.height = window.innerHeight) : (this.width = this.wrapper.clientWidth, this.height = this.wrapper.clientHeight);
	};
	onContentResize = () => {
		this.wrapper === window ? (this.scrollHeight = this.content.scrollHeight, this.scrollWidth = this.content.scrollWidth) : (this.scrollHeight = this.wrapper.scrollHeight, this.scrollWidth = this.wrapper.scrollWidth);
	};
	get limit() {
		return {
			x: this.scrollWidth - this.width,
			y: this.scrollHeight - this.height
		};
	}
};
var Emitter = class {
	constructor() {
		this.events = {};
	}
	emit(t, ...e) {
		let i = this.events[t] || [];
		for (let t = 0, s = i.length; t < s; t++) i[t](...e);
	}
	on(t, e) {
		return this.events[t]?.push(e) || (this.events[t] = [e]), () => {
			this.events[t] = this.events[t]?.filter(((t) => e !== t));
		};
	}
	off(t, e) {
		this.events[t] = this.events[t]?.filter(((t) => e !== t));
	}
	destroy() {
		this.events = {};
	}
};
var e = 100 / 6;
var VirtualScroll = class {
	constructor(t, { wheelMultiplier: e = 1, touchMultiplier: i = 1 }) {
		this.element = t, this.wheelMultiplier = e, this.touchMultiplier = i, this.touchStart = {
			x: null,
			y: null
		}, this.emitter = new Emitter(), window.addEventListener("resize", this.onWindowResize, !1), this.onWindowResize(), this.element.addEventListener("wheel", this.onWheel, { passive: !1 }), this.element.addEventListener("touchstart", this.onTouchStart, { passive: !1 }), this.element.addEventListener("touchmove", this.onTouchMove, { passive: !1 }), this.element.addEventListener("touchend", this.onTouchEnd, { passive: !1 });
	}
	on(t, e) {
		return this.emitter.on(t, e);
	}
	destroy() {
		this.emitter.destroy(), window.removeEventListener("resize", this.onWindowResize, !1), this.element.removeEventListener("wheel", this.onWheel, { passive: !1 }), this.element.removeEventListener("touchstart", this.onTouchStart, { passive: !1 }), this.element.removeEventListener("touchmove", this.onTouchMove, { passive: !1 }), this.element.removeEventListener("touchend", this.onTouchEnd, { passive: !1 });
	}
	onTouchStart = (t) => {
		const { clientX: e, clientY: i } = t.targetTouches ? t.targetTouches[0] : t;
		this.touchStart.x = e, this.touchStart.y = i, this.lastDelta = {
			x: 0,
			y: 0
		}, this.emitter.emit("scroll", {
			deltaX: 0,
			deltaY: 0,
			event: t
		});
	};
	onTouchMove = (t) => {
		const { clientX: e, clientY: i } = t.targetTouches ? t.targetTouches[0] : t, s = -(e - this.touchStart.x) * this.touchMultiplier, o = -(i - this.touchStart.y) * this.touchMultiplier;
		this.touchStart.x = e, this.touchStart.y = i, this.lastDelta = {
			x: s,
			y: o
		}, this.emitter.emit("scroll", {
			deltaX: s,
			deltaY: o,
			event: t
		});
	};
	onTouchEnd = (t) => {
		this.emitter.emit("scroll", {
			deltaX: this.lastDelta.x,
			deltaY: this.lastDelta.y,
			event: t
		});
	};
	onWheel = (t) => {
		let { deltaX: i, deltaY: s, deltaMode: o } = t;
		i *= 1 === o ? e : 2 === o ? this.windowWidth : 1, s *= 1 === o ? e : 2 === o ? this.windowHeight : 1, i *= this.wheelMultiplier, s *= this.wheelMultiplier, this.emitter.emit("scroll", {
			deltaX: i,
			deltaY: s,
			event: t
		});
	};
	onWindowResize = () => {
		this.windowWidth = window.innerWidth, this.windowHeight = window.innerHeight;
	};
};
var Lenis = class {
	constructor({ wrapper: t = window, content: e = document.documentElement, wheelEventsTarget: i = t, eventsTarget: s = i, smoothWheel: o = !0, syncTouch: n = !1, syncTouchLerp: r = .075, touchInertiaMultiplier: l = 35, duration: h, easing: a = ((t) => Math.min(1, 1.001 - Math.pow(2, -10 * t))), lerp: c = !h && .1, infinite: d = !1, orientation: p = "vertical", gestureOrientation: u = "vertical", touchMultiplier: m = 1, wheelMultiplier: v = 1, autoResize: g = !0, __experimental__naiveDimensions: S = !1 } = {}) {
		this.__isSmooth = !1, this.__isScrolling = !1, this.__isStopped = !1, this.__isLocked = !1, this.onVirtualScroll = ({ deltaX: t, deltaY: e, event: i }) => {
			if (i.ctrlKey) return;
			const s = i.type.includes("touch"), o = i.type.includes("wheel");
			if (this.options.syncTouch && s && "touchstart" === i.type && !this.isStopped && !this.isLocked) return void this.reset();
			const n = 0 === t && 0 === e, r = "vertical" === this.options.gestureOrientation && 0 === e || "horizontal" === this.options.gestureOrientation && 0 === t;
			if (n || r) return;
			let l = i.composedPath();
			if (l = l.slice(0, l.indexOf(this.rootElement)), l.find(((t) => {
				var e, i, n, r, l;
				return (null === (e = t.hasAttribute) || void 0 === e ? void 0 : e.call(t, "data-lenis-prevent")) || s && (null === (i = t.hasAttribute) || void 0 === i ? void 0 : i.call(t, "data-lenis-prevent-touch")) || o && (null === (n = t.hasAttribute) || void 0 === n ? void 0 : n.call(t, "data-lenis-prevent-wheel")) || (null === (r = t.classList) || void 0 === r ? void 0 : r.contains("lenis")) && !(null === (l = t.classList) || void 0 === l ? void 0 : l.contains("lenis-stopped"));
			}))) return;
			if (this.isStopped || this.isLocked) return void i.preventDefault();
			if (this.isSmooth = this.options.syncTouch && s || this.options.smoothWheel && o, !this.isSmooth) return this.isScrolling = !1, void this.animate.stop();
			i.preventDefault();
			let h = e;
			"both" === this.options.gestureOrientation ? h = Math.abs(e) > Math.abs(t) ? e : t : "horizontal" === this.options.gestureOrientation && (h = t);
			const a = s && this.options.syncTouch, c = s && "touchend" === i.type && Math.abs(h) > 5;
			c && (h = this.velocity * this.options.touchInertiaMultiplier), this.scrollTo(this.targetScroll + h, Object.assign({ programmatic: !1 }, a ? { lerp: c ? this.options.syncTouchLerp : 1 } : {
				lerp: this.options.lerp,
				duration: this.options.duration,
				easing: this.options.easing
			}));
		}, this.onNativeScroll = () => {
			if (!this.__preventNextScrollEvent && !this.isScrolling) {
				const t = this.animatedScroll;
				this.animatedScroll = this.targetScroll = this.actualScroll, this.velocity = 0, this.direction = Math.sign(this.animatedScroll - t), this.emit();
			}
		}, window.lenisVersion = "1.0.42", t !== document.documentElement && t !== document.body || (t = window), this.options = {
			wrapper: t,
			content: e,
			wheelEventsTarget: i,
			eventsTarget: s,
			smoothWheel: o,
			syncTouch: n,
			syncTouchLerp: r,
			touchInertiaMultiplier: l,
			duration: h,
			easing: a,
			lerp: c,
			infinite: d,
			gestureOrientation: u,
			orientation: p,
			touchMultiplier: m,
			wheelMultiplier: v,
			autoResize: g,
			__experimental__naiveDimensions: S
		}, this.animate = new Animate(), this.emitter = new Emitter(), this.dimensions = new Dimensions({
			wrapper: t,
			content: e,
			autoResize: g
		}), this.toggleClassName("lenis", !0), this.velocity = 0, this.isLocked = !1, this.isStopped = !1, this.isSmooth = n || o, this.isScrolling = !1, this.targetScroll = this.animatedScroll = this.actualScroll, this.options.wrapper.addEventListener("scroll", this.onNativeScroll, !1), this.virtualScroll = new VirtualScroll(s, {
			touchMultiplier: m,
			wheelMultiplier: v
		}), this.virtualScroll.on("scroll", this.onVirtualScroll);
	}
	destroy() {
		this.emitter.destroy(), this.options.wrapper.removeEventListener("scroll", this.onNativeScroll, !1), this.virtualScroll.destroy(), this.dimensions.destroy(), this.toggleClassName("lenis", !1), this.toggleClassName("lenis-smooth", !1), this.toggleClassName("lenis-scrolling", !1), this.toggleClassName("lenis-stopped", !1), this.toggleClassName("lenis-locked", !1);
	}
	on(t, e) {
		return this.emitter.on(t, e);
	}
	off(t, e) {
		return this.emitter.off(t, e);
	}
	setScroll(t) {
		this.isHorizontal ? this.rootElement.scrollLeft = t : this.rootElement.scrollTop = t;
	}
	resize() {
		this.dimensions.resize();
	}
	emit() {
		this.emitter.emit("scroll", this);
	}
	reset() {
		this.isLocked = !1, this.isScrolling = !1, this.animatedScroll = this.targetScroll = this.actualScroll, this.velocity = 0, this.animate.stop();
	}
	start() {
		this.isStopped && (this.isStopped = !1, this.reset());
	}
	stop() {
		this.isStopped || (this.isStopped = !0, this.animate.stop(), this.reset());
	}
	raf(t) {
		const e = t - (this.time || t);
		this.time = t, this.animate.advance(.001 * e);
	}
	scrollTo(e, { offset: i = 0, immediate: s = !1, lock: o = !1, duration: n = this.options.duration, easing: r = this.options.easing, lerp: l = !n && this.options.lerp, onComplete: h, force: a = !1, programmatic: c = !0 } = {}) {
		if (!this.isStopped && !this.isLocked || a) {
			if ([
				"top",
				"left",
				"start"
			].includes(e)) e = 0;
			else if ([
				"bottom",
				"right",
				"end"
			].includes(e)) e = this.limit;
			else {
				let t;
				if ("string" == typeof e ? t = document.querySelector(e) : null != e && e.nodeType && (t = e), t) {
					if (this.options.wrapper !== window) {
						const t = this.options.wrapper.getBoundingClientRect();
						i -= this.isHorizontal ? t.left : t.top;
					}
					const s = t.getBoundingClientRect();
					e = (this.isHorizontal ? s.left : s.top) + this.animatedScroll;
				}
			}
			if ("number" == typeof e) {
				if (e += i, e = Math.round(e), this.options.infinite ? c && (this.targetScroll = this.animatedScroll = this.scroll) : e = t(0, e, this.limit), s) return this.animatedScroll = this.targetScroll = e, this.setScroll(this.scroll), this.reset(), void (null == h || h(this));
				if (!c) {
					if (e === this.targetScroll) return;
					this.targetScroll = e;
				}
				this.animate.fromTo(this.animatedScroll, e, {
					duration: n,
					easing: r,
					lerp: l,
					onStart: () => {
						o && (this.isLocked = !0), this.isScrolling = !0;
					},
					onUpdate: (t, e) => {
						this.isScrolling = !0, this.velocity = t - this.animatedScroll, this.direction = Math.sign(this.velocity), this.animatedScroll = t, this.setScroll(this.scroll), c && (this.targetScroll = t), e || this.emit(), e && (this.reset(), this.emit(), h?.(this), this.__preventNextScrollEvent = !0, requestAnimationFrame((() => {
							delete this.__preventNextScrollEvent;
						})));
					}
				});
			}
		}
	}
	get rootElement() {
		return this.options.wrapper === window ? document.documentElement : this.options.wrapper;
	}
	get limit() {
		return this.options.__experimental__naiveDimensions ? this.isHorizontal ? this.rootElement.scrollWidth - this.rootElement.clientWidth : this.rootElement.scrollHeight - this.rootElement.clientHeight : this.dimensions.limit[this.isHorizontal ? "x" : "y"];
	}
	get isHorizontal() {
		return "horizontal" === this.options.orientation;
	}
	get actualScroll() {
		return this.isHorizontal ? this.rootElement.scrollLeft : this.rootElement.scrollTop;
	}
	get scroll() {
		return this.options.infinite ? (t = this.animatedScroll, e = this.limit, (t % e + e) % e) : this.animatedScroll;
		var t, e;
	}
	get progress() {
		return 0 === this.limit ? 1 : this.scroll / this.limit;
	}
	get isSmooth() {
		return this.__isSmooth;
	}
	set isSmooth(t) {
		this.__isSmooth !== t && (this.__isSmooth = t, this.toggleClassName("lenis-smooth", t));
	}
	get isScrolling() {
		return this.__isScrolling;
	}
	set isScrolling(t) {
		this.__isScrolling !== t && (this.__isScrolling = t, this.toggleClassName("lenis-scrolling", t));
	}
	get isStopped() {
		return this.__isStopped;
	}
	set isStopped(t) {
		this.__isStopped !== t && (this.__isStopped = t, this.toggleClassName("lenis-stopped", t));
	}
	get isLocked() {
		return this.__isLocked;
	}
	set isLocked(t) {
		this.__isLocked !== t && (this.__isLocked = t, this.toggleClassName("lenis-locked", t));
	}
	get className() {
		let t = "lenis";
		return this.isStopped && (t += " lenis-stopped"), this.isLocked && (t += " lenis-locked"), this.isScrolling && (t += " lenis-scrolling"), this.isSmooth && (t += " lenis-smooth"), t;
	}
	toggleClassName(t, e) {
		this.rootElement.classList.toggle(t, e), this.emitter.emit("className change", this);
	}
};
//#endregion
export { Lenis as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHN0dWRpby1mcmVpZ2h0X2xlbmlzLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL0BzdHVkaW8tZnJlaWdodC9sZW5pcy9kaXN0L2xlbmlzLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiB0KHQsZSxpKXtyZXR1cm4gTWF0aC5tYXgodCxNYXRoLm1pbihlLGkpKX1jbGFzcyBBbmltYXRle2FkdmFuY2UoZSl7aWYoIXRoaXMuaXNSdW5uaW5nKXJldHVybjtsZXQgaT0hMTtpZih0aGlzLmxlcnApdGhpcy52YWx1ZT0ocz10aGlzLnZhbHVlLG89dGhpcy50byxuPTYwKnRoaXMubGVycCxyPWUsZnVuY3Rpb24odCxlLGkpe3JldHVybigxLWkpKnQraSplfShzLG8sMS1NYXRoLmV4cCgtbipyKSkpLE1hdGgucm91bmQodGhpcy52YWx1ZSk9PT10aGlzLnRvJiYodGhpcy52YWx1ZT10aGlzLnRvLGk9ITApO2Vsc2V7dGhpcy5jdXJyZW50VGltZSs9ZTtjb25zdCBzPXQoMCx0aGlzLmN1cnJlbnRUaW1lL3RoaXMuZHVyYXRpb24sMSk7aT1zPj0xO2NvbnN0IG89aT8xOnRoaXMuZWFzaW5nKHMpO3RoaXMudmFsdWU9dGhpcy5mcm9tKyh0aGlzLnRvLXRoaXMuZnJvbSkqb312YXIgcyxvLG4scjt0aGlzLm9uVXBkYXRlPy4odGhpcy52YWx1ZSxpKSxpJiZ0aGlzLnN0b3AoKX1zdG9wKCl7dGhpcy5pc1J1bm5pbmc9ITF9ZnJvbVRvKHQsZSx7bGVycDppPS4xLGR1cmF0aW9uOnM9MSxlYXNpbmc6bz0odD0+dCksb25TdGFydDpuLG9uVXBkYXRlOnJ9KXt0aGlzLmZyb209dGhpcy52YWx1ZT10LHRoaXMudG89ZSx0aGlzLmxlcnA9aSx0aGlzLmR1cmF0aW9uPXMsdGhpcy5lYXNpbmc9byx0aGlzLmN1cnJlbnRUaW1lPTAsdGhpcy5pc1J1bm5pbmc9ITAsbj8uKCksdGhpcy5vblVwZGF0ZT1yfX1jbGFzcyBEaW1lbnNpb25ze2NvbnN0cnVjdG9yKHt3cmFwcGVyOnQsY29udGVudDplLGF1dG9SZXNpemU6aT0hMCxkZWJvdW5jZTpzPTI1MH09e30pe3RoaXMud3JhcHBlcj10LHRoaXMuY29udGVudD1lLGkmJih0aGlzLmRlYm91bmNlZFJlc2l6ZT1mdW5jdGlvbih0LGUpe2xldCBpO3JldHVybiBmdW5jdGlvbigpe2xldCBzPWFyZ3VtZW50cyxvPXRoaXM7Y2xlYXJUaW1lb3V0KGkpLGk9c2V0VGltZW91dCgoZnVuY3Rpb24oKXt0LmFwcGx5KG8scyl9KSxlKX19KHRoaXMucmVzaXplLHMpLHRoaXMud3JhcHBlcj09PXdpbmRvdz93aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLHRoaXMuZGVib3VuY2VkUmVzaXplLCExKToodGhpcy53cmFwcGVyUmVzaXplT2JzZXJ2ZXI9bmV3IFJlc2l6ZU9ic2VydmVyKHRoaXMuZGVib3VuY2VkUmVzaXplKSx0aGlzLndyYXBwZXJSZXNpemVPYnNlcnZlci5vYnNlcnZlKHRoaXMud3JhcHBlcikpLHRoaXMuY29udGVudFJlc2l6ZU9ic2VydmVyPW5ldyBSZXNpemVPYnNlcnZlcih0aGlzLmRlYm91bmNlZFJlc2l6ZSksdGhpcy5jb250ZW50UmVzaXplT2JzZXJ2ZXIub2JzZXJ2ZSh0aGlzLmNvbnRlbnQpKSx0aGlzLnJlc2l6ZSgpfWRlc3Ryb3koKXt0aGlzLndyYXBwZXJSZXNpemVPYnNlcnZlcj8uZGlzY29ubmVjdCgpLHRoaXMuY29udGVudFJlc2l6ZU9ic2VydmVyPy5kaXNjb25uZWN0KCksd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIix0aGlzLmRlYm91bmNlZFJlc2l6ZSwhMSl9cmVzaXplPSgpPT57dGhpcy5vbldyYXBwZXJSZXNpemUoKSx0aGlzLm9uQ29udGVudFJlc2l6ZSgpfTtvbldyYXBwZXJSZXNpemU9KCk9Pnt0aGlzLndyYXBwZXI9PT13aW5kb3c/KHRoaXMud2lkdGg9d2luZG93LmlubmVyV2lkdGgsdGhpcy5oZWlnaHQ9d2luZG93LmlubmVySGVpZ2h0KToodGhpcy53aWR0aD10aGlzLndyYXBwZXIuY2xpZW50V2lkdGgsdGhpcy5oZWlnaHQ9dGhpcy53cmFwcGVyLmNsaWVudEhlaWdodCl9O29uQ29udGVudFJlc2l6ZT0oKT0+e3RoaXMud3JhcHBlcj09PXdpbmRvdz8odGhpcy5zY3JvbGxIZWlnaHQ9dGhpcy5jb250ZW50LnNjcm9sbEhlaWdodCx0aGlzLnNjcm9sbFdpZHRoPXRoaXMuY29udGVudC5zY3JvbGxXaWR0aCk6KHRoaXMuc2Nyb2xsSGVpZ2h0PXRoaXMud3JhcHBlci5zY3JvbGxIZWlnaHQsdGhpcy5zY3JvbGxXaWR0aD10aGlzLndyYXBwZXIuc2Nyb2xsV2lkdGgpfTtnZXQgbGltaXQoKXtyZXR1cm57eDp0aGlzLnNjcm9sbFdpZHRoLXRoaXMud2lkdGgseTp0aGlzLnNjcm9sbEhlaWdodC10aGlzLmhlaWdodH19fWNsYXNzIEVtaXR0ZXJ7Y29uc3RydWN0b3IoKXt0aGlzLmV2ZW50cz17fX1lbWl0KHQsLi4uZSl7bGV0IGk9dGhpcy5ldmVudHNbdF18fFtdO2ZvcihsZXQgdD0wLHM9aS5sZW5ndGg7dDxzO3QrKylpW3RdKC4uLmUpfW9uKHQsZSl7cmV0dXJuIHRoaXMuZXZlbnRzW3RdPy5wdXNoKGUpfHwodGhpcy5ldmVudHNbdF09W2VdKSwoKT0+e3RoaXMuZXZlbnRzW3RdPXRoaXMuZXZlbnRzW3RdPy5maWx0ZXIoKHQ9PmUhPT10KSl9fW9mZih0LGUpe3RoaXMuZXZlbnRzW3RdPXRoaXMuZXZlbnRzW3RdPy5maWx0ZXIoKHQ9PmUhPT10KSl9ZGVzdHJveSgpe3RoaXMuZXZlbnRzPXt9fX1jb25zdCBlPTEwMC82O2NsYXNzIFZpcnR1YWxTY3JvbGx7Y29uc3RydWN0b3IodCx7d2hlZWxNdWx0aXBsaWVyOmU9MSx0b3VjaE11bHRpcGxpZXI6aT0xfSl7dGhpcy5lbGVtZW50PXQsdGhpcy53aGVlbE11bHRpcGxpZXI9ZSx0aGlzLnRvdWNoTXVsdGlwbGllcj1pLHRoaXMudG91Y2hTdGFydD17eDpudWxsLHk6bnVsbH0sdGhpcy5lbWl0dGVyPW5ldyBFbWl0dGVyLHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsdGhpcy5vbldpbmRvd1Jlc2l6ZSwhMSksdGhpcy5vbldpbmRvd1Jlc2l6ZSgpLHRoaXMuZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwid2hlZWxcIix0aGlzLm9uV2hlZWwse3Bhc3NpdmU6ITF9KSx0aGlzLmVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInRvdWNoc3RhcnRcIix0aGlzLm9uVG91Y2hTdGFydCx7cGFzc2l2ZTohMX0pLHRoaXMuZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwidG91Y2htb3ZlXCIsdGhpcy5vblRvdWNoTW92ZSx7cGFzc2l2ZTohMX0pLHRoaXMuZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwidG91Y2hlbmRcIix0aGlzLm9uVG91Y2hFbmQse3Bhc3NpdmU6ITF9KX1vbih0LGUpe3JldHVybiB0aGlzLmVtaXR0ZXIub24odCxlKX1kZXN0cm95KCl7dGhpcy5lbWl0dGVyLmRlc3Ryb3koKSx3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLHRoaXMub25XaW5kb3dSZXNpemUsITEpLHRoaXMuZWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwid2hlZWxcIix0aGlzLm9uV2hlZWwse3Bhc3NpdmU6ITF9KSx0aGlzLmVsZW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInRvdWNoc3RhcnRcIix0aGlzLm9uVG91Y2hTdGFydCx7cGFzc2l2ZTohMX0pLHRoaXMuZWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwidG91Y2htb3ZlXCIsdGhpcy5vblRvdWNoTW92ZSx7cGFzc2l2ZTohMX0pLHRoaXMuZWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwidG91Y2hlbmRcIix0aGlzLm9uVG91Y2hFbmQse3Bhc3NpdmU6ITF9KX1vblRvdWNoU3RhcnQ9dD0+e2NvbnN0e2NsaWVudFg6ZSxjbGllbnRZOml9PXQudGFyZ2V0VG91Y2hlcz90LnRhcmdldFRvdWNoZXNbMF06dDt0aGlzLnRvdWNoU3RhcnQueD1lLHRoaXMudG91Y2hTdGFydC55PWksdGhpcy5sYXN0RGVsdGE9e3g6MCx5OjB9LHRoaXMuZW1pdHRlci5lbWl0KFwic2Nyb2xsXCIse2RlbHRhWDowLGRlbHRhWTowLGV2ZW50OnR9KX07b25Ub3VjaE1vdmU9dD0+e2NvbnN0e2NsaWVudFg6ZSxjbGllbnRZOml9PXQudGFyZ2V0VG91Y2hlcz90LnRhcmdldFRvdWNoZXNbMF06dCxzPS0oZS10aGlzLnRvdWNoU3RhcnQueCkqdGhpcy50b3VjaE11bHRpcGxpZXIsbz0tKGktdGhpcy50b3VjaFN0YXJ0LnkpKnRoaXMudG91Y2hNdWx0aXBsaWVyO3RoaXMudG91Y2hTdGFydC54PWUsdGhpcy50b3VjaFN0YXJ0Lnk9aSx0aGlzLmxhc3REZWx0YT17eDpzLHk6b30sdGhpcy5lbWl0dGVyLmVtaXQoXCJzY3JvbGxcIix7ZGVsdGFYOnMsZGVsdGFZOm8sZXZlbnQ6dH0pfTtvblRvdWNoRW5kPXQ9Pnt0aGlzLmVtaXR0ZXIuZW1pdChcInNjcm9sbFwiLHtkZWx0YVg6dGhpcy5sYXN0RGVsdGEueCxkZWx0YVk6dGhpcy5sYXN0RGVsdGEueSxldmVudDp0fSl9O29uV2hlZWw9dD0+e2xldHtkZWx0YVg6aSxkZWx0YVk6cyxkZWx0YU1vZGU6b309dDtpKj0xPT09bz9lOjI9PT1vP3RoaXMud2luZG93V2lkdGg6MSxzKj0xPT09bz9lOjI9PT1vP3RoaXMud2luZG93SGVpZ2h0OjEsaSo9dGhpcy53aGVlbE11bHRpcGxpZXIscyo9dGhpcy53aGVlbE11bHRpcGxpZXIsdGhpcy5lbWl0dGVyLmVtaXQoXCJzY3JvbGxcIix7ZGVsdGFYOmksZGVsdGFZOnMsZXZlbnQ6dH0pfTtvbldpbmRvd1Jlc2l6ZT0oKT0+e3RoaXMud2luZG93V2lkdGg9d2luZG93LmlubmVyV2lkdGgsdGhpcy53aW5kb3dIZWlnaHQ9d2luZG93LmlubmVySGVpZ2h0fX1jbGFzcyBMZW5pc3tjb25zdHJ1Y3Rvcih7d3JhcHBlcjp0PXdpbmRvdyxjb250ZW50OmU9ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LHdoZWVsRXZlbnRzVGFyZ2V0Omk9dCxldmVudHNUYXJnZXQ6cz1pLHNtb290aFdoZWVsOm89ITAsc3luY1RvdWNoOm49ITEsc3luY1RvdWNoTGVycDpyPS4wNzUsdG91Y2hJbmVydGlhTXVsdGlwbGllcjpsPTM1LGR1cmF0aW9uOmgsZWFzaW5nOmE9KHQ9Pk1hdGgubWluKDEsMS4wMDEtTWF0aC5wb3coMiwtMTAqdCkpKSxsZXJwOmM9IWgmJi4xLGluZmluaXRlOmQ9ITEsb3JpZW50YXRpb246cD1cInZlcnRpY2FsXCIsZ2VzdHVyZU9yaWVudGF0aW9uOnU9XCJ2ZXJ0aWNhbFwiLHRvdWNoTXVsdGlwbGllcjptPTEsd2hlZWxNdWx0aXBsaWVyOnY9MSxhdXRvUmVzaXplOmc9ITAsX19leHBlcmltZW50YWxfX25haXZlRGltZW5zaW9uczpTPSExfT17fSl7dGhpcy5fX2lzU21vb3RoPSExLHRoaXMuX19pc1Njcm9sbGluZz0hMSx0aGlzLl9faXNTdG9wcGVkPSExLHRoaXMuX19pc0xvY2tlZD0hMSx0aGlzLm9uVmlydHVhbFNjcm9sbD0oe2RlbHRhWDp0LGRlbHRhWTplLGV2ZW50Oml9KT0+e2lmKGkuY3RybEtleSlyZXR1cm47Y29uc3Qgcz1pLnR5cGUuaW5jbHVkZXMoXCJ0b3VjaFwiKSxvPWkudHlwZS5pbmNsdWRlcyhcIndoZWVsXCIpO2lmKHRoaXMub3B0aW9ucy5zeW5jVG91Y2gmJnMmJlwidG91Y2hzdGFydFwiPT09aS50eXBlJiYhdGhpcy5pc1N0b3BwZWQmJiF0aGlzLmlzTG9ja2VkKXJldHVybiB2b2lkIHRoaXMucmVzZXQoKTtjb25zdCBuPTA9PT10JiYwPT09ZSxyPVwidmVydGljYWxcIj09PXRoaXMub3B0aW9ucy5nZXN0dXJlT3JpZW50YXRpb24mJjA9PT1lfHxcImhvcml6b250YWxcIj09PXRoaXMub3B0aW9ucy5nZXN0dXJlT3JpZW50YXRpb24mJjA9PT10O2lmKG58fHIpcmV0dXJuO2xldCBsPWkuY29tcG9zZWRQYXRoKCk7aWYobD1sLnNsaWNlKDAsbC5pbmRleE9mKHRoaXMucm9vdEVsZW1lbnQpKSxsLmZpbmQoKHQ9Pnt2YXIgZSxpLG4scixsO3JldHVybihudWxsPT09KGU9dC5oYXNBdHRyaWJ1dGUpfHx2b2lkIDA9PT1lP3ZvaWQgMDplLmNhbGwodCxcImRhdGEtbGVuaXMtcHJldmVudFwiKSl8fHMmJihudWxsPT09KGk9dC5oYXNBdHRyaWJ1dGUpfHx2b2lkIDA9PT1pP3ZvaWQgMDppLmNhbGwodCxcImRhdGEtbGVuaXMtcHJldmVudC10b3VjaFwiKSl8fG8mJihudWxsPT09KG49dC5oYXNBdHRyaWJ1dGUpfHx2b2lkIDA9PT1uP3ZvaWQgMDpuLmNhbGwodCxcImRhdGEtbGVuaXMtcHJldmVudC13aGVlbFwiKSl8fChudWxsPT09KHI9dC5jbGFzc0xpc3QpfHx2b2lkIDA9PT1yP3ZvaWQgMDpyLmNvbnRhaW5zKFwibGVuaXNcIikpJiYhKG51bGw9PT0obD10LmNsYXNzTGlzdCl8fHZvaWQgMD09PWw/dm9pZCAwOmwuY29udGFpbnMoXCJsZW5pcy1zdG9wcGVkXCIpKX0pKSlyZXR1cm47aWYodGhpcy5pc1N0b3BwZWR8fHRoaXMuaXNMb2NrZWQpcmV0dXJuIHZvaWQgaS5wcmV2ZW50RGVmYXVsdCgpO2lmKHRoaXMuaXNTbW9vdGg9dGhpcy5vcHRpb25zLnN5bmNUb3VjaCYmc3x8dGhpcy5vcHRpb25zLnNtb290aFdoZWVsJiZvLCF0aGlzLmlzU21vb3RoKXJldHVybiB0aGlzLmlzU2Nyb2xsaW5nPSExLHZvaWQgdGhpcy5hbmltYXRlLnN0b3AoKTtpLnByZXZlbnREZWZhdWx0KCk7bGV0IGg9ZTtcImJvdGhcIj09PXRoaXMub3B0aW9ucy5nZXN0dXJlT3JpZW50YXRpb24/aD1NYXRoLmFicyhlKT5NYXRoLmFicyh0KT9lOnQ6XCJob3Jpem9udGFsXCI9PT10aGlzLm9wdGlvbnMuZ2VzdHVyZU9yaWVudGF0aW9uJiYoaD10KTtjb25zdCBhPXMmJnRoaXMub3B0aW9ucy5zeW5jVG91Y2gsYz1zJiZcInRvdWNoZW5kXCI9PT1pLnR5cGUmJk1hdGguYWJzKGgpPjU7YyYmKGg9dGhpcy52ZWxvY2l0eSp0aGlzLm9wdGlvbnMudG91Y2hJbmVydGlhTXVsdGlwbGllciksdGhpcy5zY3JvbGxUbyh0aGlzLnRhcmdldFNjcm9sbCtoLE9iamVjdC5hc3NpZ24oe3Byb2dyYW1tYXRpYzohMX0sYT97bGVycDpjP3RoaXMub3B0aW9ucy5zeW5jVG91Y2hMZXJwOjF9OntsZXJwOnRoaXMub3B0aW9ucy5sZXJwLGR1cmF0aW9uOnRoaXMub3B0aW9ucy5kdXJhdGlvbixlYXNpbmc6dGhpcy5vcHRpb25zLmVhc2luZ30pKX0sdGhpcy5vbk5hdGl2ZVNjcm9sbD0oKT0+e2lmKCF0aGlzLl9fcHJldmVudE5leHRTY3JvbGxFdmVudCYmIXRoaXMuaXNTY3JvbGxpbmcpe2NvbnN0IHQ9dGhpcy5hbmltYXRlZFNjcm9sbDt0aGlzLmFuaW1hdGVkU2Nyb2xsPXRoaXMudGFyZ2V0U2Nyb2xsPXRoaXMuYWN0dWFsU2Nyb2xsLHRoaXMudmVsb2NpdHk9MCx0aGlzLmRpcmVjdGlvbj1NYXRoLnNpZ24odGhpcy5hbmltYXRlZFNjcm9sbC10KSx0aGlzLmVtaXQoKX19LHdpbmRvdy5sZW5pc1ZlcnNpb249XCIxLjAuNDJcIix0IT09ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50JiZ0IT09ZG9jdW1lbnQuYm9keXx8KHQ9d2luZG93KSx0aGlzLm9wdGlvbnM9e3dyYXBwZXI6dCxjb250ZW50OmUsd2hlZWxFdmVudHNUYXJnZXQ6aSxldmVudHNUYXJnZXQ6cyxzbW9vdGhXaGVlbDpvLHN5bmNUb3VjaDpuLHN5bmNUb3VjaExlcnA6cix0b3VjaEluZXJ0aWFNdWx0aXBsaWVyOmwsZHVyYXRpb246aCxlYXNpbmc6YSxsZXJwOmMsaW5maW5pdGU6ZCxnZXN0dXJlT3JpZW50YXRpb246dSxvcmllbnRhdGlvbjpwLHRvdWNoTXVsdGlwbGllcjptLHdoZWVsTXVsdGlwbGllcjp2LGF1dG9SZXNpemU6ZyxfX2V4cGVyaW1lbnRhbF9fbmFpdmVEaW1lbnNpb25zOlN9LHRoaXMuYW5pbWF0ZT1uZXcgQW5pbWF0ZSx0aGlzLmVtaXR0ZXI9bmV3IEVtaXR0ZXIsdGhpcy5kaW1lbnNpb25zPW5ldyBEaW1lbnNpb25zKHt3cmFwcGVyOnQsY29udGVudDplLGF1dG9SZXNpemU6Z30pLHRoaXMudG9nZ2xlQ2xhc3NOYW1lKFwibGVuaXNcIiwhMCksdGhpcy52ZWxvY2l0eT0wLHRoaXMuaXNMb2NrZWQ9ITEsdGhpcy5pc1N0b3BwZWQ9ITEsdGhpcy5pc1Ntb290aD1ufHxvLHRoaXMuaXNTY3JvbGxpbmc9ITEsdGhpcy50YXJnZXRTY3JvbGw9dGhpcy5hbmltYXRlZFNjcm9sbD10aGlzLmFjdHVhbFNjcm9sbCx0aGlzLm9wdGlvbnMud3JhcHBlci5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsdGhpcy5vbk5hdGl2ZVNjcm9sbCwhMSksdGhpcy52aXJ0dWFsU2Nyb2xsPW5ldyBWaXJ0dWFsU2Nyb2xsKHMse3RvdWNoTXVsdGlwbGllcjptLHdoZWVsTXVsdGlwbGllcjp2fSksdGhpcy52aXJ0dWFsU2Nyb2xsLm9uKFwic2Nyb2xsXCIsdGhpcy5vblZpcnR1YWxTY3JvbGwpfWRlc3Ryb3koKXt0aGlzLmVtaXR0ZXIuZGVzdHJveSgpLHRoaXMub3B0aW9ucy53cmFwcGVyLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIix0aGlzLm9uTmF0aXZlU2Nyb2xsLCExKSx0aGlzLnZpcnR1YWxTY3JvbGwuZGVzdHJveSgpLHRoaXMuZGltZW5zaW9ucy5kZXN0cm95KCksdGhpcy50b2dnbGVDbGFzc05hbWUoXCJsZW5pc1wiLCExKSx0aGlzLnRvZ2dsZUNsYXNzTmFtZShcImxlbmlzLXNtb290aFwiLCExKSx0aGlzLnRvZ2dsZUNsYXNzTmFtZShcImxlbmlzLXNjcm9sbGluZ1wiLCExKSx0aGlzLnRvZ2dsZUNsYXNzTmFtZShcImxlbmlzLXN0b3BwZWRcIiwhMSksdGhpcy50b2dnbGVDbGFzc05hbWUoXCJsZW5pcy1sb2NrZWRcIiwhMSl9b24odCxlKXtyZXR1cm4gdGhpcy5lbWl0dGVyLm9uKHQsZSl9b2ZmKHQsZSl7cmV0dXJuIHRoaXMuZW1pdHRlci5vZmYodCxlKX1zZXRTY3JvbGwodCl7dGhpcy5pc0hvcml6b250YWw/dGhpcy5yb290RWxlbWVudC5zY3JvbGxMZWZ0PXQ6dGhpcy5yb290RWxlbWVudC5zY3JvbGxUb3A9dH1yZXNpemUoKXt0aGlzLmRpbWVuc2lvbnMucmVzaXplKCl9ZW1pdCgpe3RoaXMuZW1pdHRlci5lbWl0KFwic2Nyb2xsXCIsdGhpcyl9cmVzZXQoKXt0aGlzLmlzTG9ja2VkPSExLHRoaXMuaXNTY3JvbGxpbmc9ITEsdGhpcy5hbmltYXRlZFNjcm9sbD10aGlzLnRhcmdldFNjcm9sbD10aGlzLmFjdHVhbFNjcm9sbCx0aGlzLnZlbG9jaXR5PTAsdGhpcy5hbmltYXRlLnN0b3AoKX1zdGFydCgpe3RoaXMuaXNTdG9wcGVkJiYodGhpcy5pc1N0b3BwZWQ9ITEsdGhpcy5yZXNldCgpKX1zdG9wKCl7dGhpcy5pc1N0b3BwZWR8fCh0aGlzLmlzU3RvcHBlZD0hMCx0aGlzLmFuaW1hdGUuc3RvcCgpLHRoaXMucmVzZXQoKSl9cmFmKHQpe2NvbnN0IGU9dC0odGhpcy50aW1lfHx0KTt0aGlzLnRpbWU9dCx0aGlzLmFuaW1hdGUuYWR2YW5jZSguMDAxKmUpfXNjcm9sbFRvKGUse29mZnNldDppPTAsaW1tZWRpYXRlOnM9ITEsbG9jazpvPSExLGR1cmF0aW9uOm49dGhpcy5vcHRpb25zLmR1cmF0aW9uLGVhc2luZzpyPXRoaXMub3B0aW9ucy5lYXNpbmcsbGVycDpsPSFuJiZ0aGlzLm9wdGlvbnMubGVycCxvbkNvbXBsZXRlOmgsZm9yY2U6YT0hMSxwcm9ncmFtbWF0aWM6Yz0hMH09e30pe2lmKCF0aGlzLmlzU3RvcHBlZCYmIXRoaXMuaXNMb2NrZWR8fGEpe2lmKFtcInRvcFwiLFwibGVmdFwiLFwic3RhcnRcIl0uaW5jbHVkZXMoZSkpZT0wO2Vsc2UgaWYoW1wiYm90dG9tXCIsXCJyaWdodFwiLFwiZW5kXCJdLmluY2x1ZGVzKGUpKWU9dGhpcy5saW1pdDtlbHNle2xldCB0O2lmKFwic3RyaW5nXCI9PXR5cGVvZiBlP3Q9ZG9jdW1lbnQucXVlcnlTZWxlY3RvcihlKToobnVsbD09ZT92b2lkIDA6ZS5ub2RlVHlwZSkmJih0PWUpLHQpe2lmKHRoaXMub3B0aW9ucy53cmFwcGVyIT09d2luZG93KXtjb25zdCB0PXRoaXMub3B0aW9ucy53cmFwcGVyLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO2ktPXRoaXMuaXNIb3Jpem9udGFsP3QubGVmdDp0LnRvcH1jb25zdCBzPXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7ZT0odGhpcy5pc0hvcml6b250YWw/cy5sZWZ0OnMudG9wKSt0aGlzLmFuaW1hdGVkU2Nyb2xsfX1pZihcIm51bWJlclwiPT10eXBlb2YgZSl7aWYoZSs9aSxlPU1hdGgucm91bmQoZSksdGhpcy5vcHRpb25zLmluZmluaXRlP2MmJih0aGlzLnRhcmdldFNjcm9sbD10aGlzLmFuaW1hdGVkU2Nyb2xsPXRoaXMuc2Nyb2xsKTplPXQoMCxlLHRoaXMubGltaXQpLHMpcmV0dXJuIHRoaXMuYW5pbWF0ZWRTY3JvbGw9dGhpcy50YXJnZXRTY3JvbGw9ZSx0aGlzLnNldFNjcm9sbCh0aGlzLnNjcm9sbCksdGhpcy5yZXNldCgpLHZvaWQobnVsbD09aHx8aCh0aGlzKSk7aWYoIWMpe2lmKGU9PT10aGlzLnRhcmdldFNjcm9sbClyZXR1cm47dGhpcy50YXJnZXRTY3JvbGw9ZX10aGlzLmFuaW1hdGUuZnJvbVRvKHRoaXMuYW5pbWF0ZWRTY3JvbGwsZSx7ZHVyYXRpb246bixlYXNpbmc6cixsZXJwOmwsb25TdGFydDooKT0+e28mJih0aGlzLmlzTG9ja2VkPSEwKSx0aGlzLmlzU2Nyb2xsaW5nPSEwfSxvblVwZGF0ZToodCxlKT0+e3RoaXMuaXNTY3JvbGxpbmc9ITAsdGhpcy52ZWxvY2l0eT10LXRoaXMuYW5pbWF0ZWRTY3JvbGwsdGhpcy5kaXJlY3Rpb249TWF0aC5zaWduKHRoaXMudmVsb2NpdHkpLHRoaXMuYW5pbWF0ZWRTY3JvbGw9dCx0aGlzLnNldFNjcm9sbCh0aGlzLnNjcm9sbCksYyYmKHRoaXMudGFyZ2V0U2Nyb2xsPXQpLGV8fHRoaXMuZW1pdCgpLGUmJih0aGlzLnJlc2V0KCksdGhpcy5lbWl0KCksbnVsbD09aHx8aCh0aGlzKSx0aGlzLl9fcHJldmVudE5leHRTY3JvbGxFdmVudD0hMCxyZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCgpPT57ZGVsZXRlIHRoaXMuX19wcmV2ZW50TmV4dFNjcm9sbEV2ZW50fSkpKX19KX19fWdldCByb290RWxlbWVudCgpe3JldHVybiB0aGlzLm9wdGlvbnMud3JhcHBlcj09PXdpbmRvdz9kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ6dGhpcy5vcHRpb25zLndyYXBwZXJ9Z2V0IGxpbWl0KCl7cmV0dXJuIHRoaXMub3B0aW9ucy5fX2V4cGVyaW1lbnRhbF9fbmFpdmVEaW1lbnNpb25zP3RoaXMuaXNIb3Jpem9udGFsP3RoaXMucm9vdEVsZW1lbnQuc2Nyb2xsV2lkdGgtdGhpcy5yb290RWxlbWVudC5jbGllbnRXaWR0aDp0aGlzLnJvb3RFbGVtZW50LnNjcm9sbEhlaWdodC10aGlzLnJvb3RFbGVtZW50LmNsaWVudEhlaWdodDp0aGlzLmRpbWVuc2lvbnMubGltaXRbdGhpcy5pc0hvcml6b250YWw/XCJ4XCI6XCJ5XCJdfWdldCBpc0hvcml6b250YWwoKXtyZXR1cm5cImhvcml6b250YWxcIj09PXRoaXMub3B0aW9ucy5vcmllbnRhdGlvbn1nZXQgYWN0dWFsU2Nyb2xsKCl7cmV0dXJuIHRoaXMuaXNIb3Jpem9udGFsP3RoaXMucm9vdEVsZW1lbnQuc2Nyb2xsTGVmdDp0aGlzLnJvb3RFbGVtZW50LnNjcm9sbFRvcH1nZXQgc2Nyb2xsKCl7cmV0dXJuIHRoaXMub3B0aW9ucy5pbmZpbml0ZT8odD10aGlzLmFuaW1hdGVkU2Nyb2xsLGU9dGhpcy5saW1pdCwodCVlK2UpJWUpOnRoaXMuYW5pbWF0ZWRTY3JvbGw7dmFyIHQsZX1nZXQgcHJvZ3Jlc3MoKXtyZXR1cm4gMD09PXRoaXMubGltaXQ/MTp0aGlzLnNjcm9sbC90aGlzLmxpbWl0fWdldCBpc1Ntb290aCgpe3JldHVybiB0aGlzLl9faXNTbW9vdGh9c2V0IGlzU21vb3RoKHQpe3RoaXMuX19pc1Ntb290aCE9PXQmJih0aGlzLl9faXNTbW9vdGg9dCx0aGlzLnRvZ2dsZUNsYXNzTmFtZShcImxlbmlzLXNtb290aFwiLHQpKX1nZXQgaXNTY3JvbGxpbmcoKXtyZXR1cm4gdGhpcy5fX2lzU2Nyb2xsaW5nfXNldCBpc1Njcm9sbGluZyh0KXt0aGlzLl9faXNTY3JvbGxpbmchPT10JiYodGhpcy5fX2lzU2Nyb2xsaW5nPXQsdGhpcy50b2dnbGVDbGFzc05hbWUoXCJsZW5pcy1zY3JvbGxpbmdcIix0KSl9Z2V0IGlzU3RvcHBlZCgpe3JldHVybiB0aGlzLl9faXNTdG9wcGVkfXNldCBpc1N0b3BwZWQodCl7dGhpcy5fX2lzU3RvcHBlZCE9PXQmJih0aGlzLl9faXNTdG9wcGVkPXQsdGhpcy50b2dnbGVDbGFzc05hbWUoXCJsZW5pcy1zdG9wcGVkXCIsdCkpfWdldCBpc0xvY2tlZCgpe3JldHVybiB0aGlzLl9faXNMb2NrZWR9c2V0IGlzTG9ja2VkKHQpe3RoaXMuX19pc0xvY2tlZCE9PXQmJih0aGlzLl9faXNMb2NrZWQ9dCx0aGlzLnRvZ2dsZUNsYXNzTmFtZShcImxlbmlzLWxvY2tlZFwiLHQpKX1nZXQgY2xhc3NOYW1lKCl7bGV0IHQ9XCJsZW5pc1wiO3JldHVybiB0aGlzLmlzU3RvcHBlZCYmKHQrPVwiIGxlbmlzLXN0b3BwZWRcIiksdGhpcy5pc0xvY2tlZCYmKHQrPVwiIGxlbmlzLWxvY2tlZFwiKSx0aGlzLmlzU2Nyb2xsaW5nJiYodCs9XCIgbGVuaXMtc2Nyb2xsaW5nXCIpLHRoaXMuaXNTbW9vdGgmJih0Kz1cIiBsZW5pcy1zbW9vdGhcIiksdH10b2dnbGVDbGFzc05hbWUodCxlKXt0aGlzLnJvb3RFbGVtZW50LmNsYXNzTGlzdC50b2dnbGUodCxlKSx0aGlzLmVtaXR0ZXIuZW1pdChcImNsYXNzTmFtZSBjaGFuZ2VcIix0aGlzKX19ZXhwb3J0e0xlbmlzIGFzIGRlZmF1bHR9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bGVuaXMubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiO0FBQUEsU0FBUyxFQUFFLEdBQUUsR0FBRSxHQUFFO0NBQUMsT0FBTyxLQUFLLElBQUksR0FBRSxLQUFLLElBQUksR0FBRSxDQUFDLENBQUM7QUFBQztBQUFDLElBQU0sVUFBTixNQUFhO0NBQUMsUUFBUSxHQUFFO0VBQUMsSUFBRyxDQUFDLEtBQUssV0FBVTtFQUFPLElBQUksSUFBRSxDQUFDO0VBQUUsSUFBRyxLQUFLLE1BQUssS0FBSyxTQUFPLElBQUUsS0FBSyxPQUFNLElBQUUsS0FBSyxJQUFHLElBQUUsS0FBRyxLQUFLLE1BQUssSUFBRSxHQUFFLFNBQVMsR0FBRSxHQUFFLEdBQUU7R0FBQyxRQUFPLElBQUUsS0FBRyxJQUFFLElBQUU7RUFBQyxFQUFFLEdBQUUsR0FBRSxJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUcsS0FBSyxNQUFNLEtBQUssS0FBSyxNQUFJLEtBQUssT0FBSyxLQUFLLFFBQU0sS0FBSyxJQUFHLElBQUUsQ0FBQztPQUFPO0dBQUMsS0FBSyxlQUFhO0dBQUUsTUFBTSxJQUFFLEVBQUUsR0FBRSxLQUFLLGNBQVksS0FBSyxVQUFTLENBQUM7R0FBRSxJQUFFLEtBQUc7R0FBRSxNQUFNLElBQUUsSUFBRSxJQUFFLEtBQUssT0FBTyxDQUFDO0dBQUUsS0FBSyxRQUFNLEtBQUssUUFBTSxLQUFLLEtBQUcsS0FBSyxRQUFNO0VBQUM7RUFBQyxJQUFJLEdBQUUsR0FBRSxHQUFFO0VBQUUsS0FBSyxXQUFXLEtBQUssT0FBTSxDQUFDLEdBQUUsS0FBRyxLQUFLLEtBQUs7Q0FBQztDQUFDLE9BQU07RUFBQyxLQUFLLFlBQVUsQ0FBQztDQUFDO0NBQUMsT0FBTyxHQUFFLEdBQUUsRUFBQyxNQUFLLElBQUUsSUFBRyxVQUFTLElBQUUsR0FBRSxRQUFPLE1BQUcsTUFBRyxJQUFHLFNBQVEsR0FBRSxVQUFTLEtBQUc7RUFBQyxLQUFLLE9BQUssS0FBSyxRQUFNLEdBQUUsS0FBSyxLQUFHLEdBQUUsS0FBSyxPQUFLLEdBQUUsS0FBSyxXQUFTLEdBQUUsS0FBSyxTQUFPLEdBQUUsS0FBSyxjQUFZLEdBQUUsS0FBSyxZQUFVLENBQUMsR0FBRSxJQUFJLEdBQUUsS0FBSyxXQUFTO0NBQUM7QUFBQztBQUFDLElBQU0sYUFBTixNQUFnQjtDQUFDLFlBQVksRUFBQyxTQUFRLEdBQUUsU0FBUSxHQUFFLFlBQVcsSUFBRSxDQUFDLEdBQUUsVUFBUyxJQUFFLFFBQUssQ0FBQyxHQUFFO0VBQUMsS0FBSyxVQUFRLEdBQUUsS0FBSyxVQUFRLEdBQUUsTUFBSSxLQUFLLGtCQUFnQixTQUFTLEdBQUUsR0FBRTtHQUFDLElBQUk7R0FBRSxPQUFPLFdBQVU7SUFBQyxJQUFJLElBQUUsV0FBVSxJQUFFO0lBQUssYUFBYSxDQUFDLEdBQUUsSUFBRSxZQUFZLFdBQVU7S0FBQyxFQUFFLE1BQU0sR0FBRSxDQUFDO0lBQUMsSUFBRyxDQUFDO0dBQUM7RUFBQyxFQUFFLEtBQUssUUFBTyxDQUFDLEdBQUUsS0FBSyxZQUFVLFNBQU8sT0FBTyxpQkFBaUIsVUFBUyxLQUFLLGlCQUFnQixDQUFDLENBQUMsS0FBRyxLQUFLLHdCQUFzQixJQUFJLGVBQWUsS0FBSyxlQUFlLEdBQUUsS0FBSyxzQkFBc0IsUUFBUSxLQUFLLE9BQU8sSUFBRyxLQUFLLHdCQUFzQixJQUFJLGVBQWUsS0FBSyxlQUFlLEdBQUUsS0FBSyxzQkFBc0IsUUFBUSxLQUFLLE9BQU8sSUFBRyxLQUFLLE9BQU87Q0FBQztDQUFDLFVBQVM7RUFBQyxLQUFLLHVCQUF1QixXQUFXLEdBQUUsS0FBSyx1QkFBdUIsV0FBVyxHQUFFLE9BQU8sb0JBQW9CLFVBQVMsS0FBSyxpQkFBZ0IsQ0FBQyxDQUFDO0NBQUM7Q0FBQyxlQUFXO0VBQUMsS0FBSyxnQkFBZ0IsR0FBRSxLQUFLLGdCQUFnQjtDQUFDO0NBQUUsd0JBQW9CO0VBQUMsS0FBSyxZQUFVLFVBQVEsS0FBSyxRQUFNLE9BQU8sWUFBVyxLQUFLLFNBQU8sT0FBTyxnQkFBYyxLQUFLLFFBQU0sS0FBSyxRQUFRLGFBQVksS0FBSyxTQUFPLEtBQUssUUFBUTtDQUFhO0NBQUUsd0JBQW9CO0VBQUMsS0FBSyxZQUFVLFVBQVEsS0FBSyxlQUFhLEtBQUssUUFBUSxjQUFhLEtBQUssY0FBWSxLQUFLLFFBQVEsZ0JBQWMsS0FBSyxlQUFhLEtBQUssUUFBUSxjQUFhLEtBQUssY0FBWSxLQUFLLFFBQVE7Q0FBWTtDQUFFLElBQUksUUFBTztFQUFDLE9BQU07R0FBQyxHQUFFLEtBQUssY0FBWSxLQUFLO0dBQU0sR0FBRSxLQUFLLGVBQWEsS0FBSztFQUFNO0NBQUM7QUFBQztBQUFDLElBQU0sVUFBTixNQUFhO0NBQUMsY0FBYTtFQUFDLEtBQUssU0FBTyxDQUFDO0NBQUM7Q0FBQyxLQUFLLEdBQUUsR0FBRyxHQUFFO0VBQUMsSUFBSSxJQUFFLEtBQUssT0FBTyxNQUFJLENBQUM7RUFBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLElBQUUsR0FBRSxLQUFJLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQztDQUFDO0NBQUMsR0FBRyxHQUFFLEdBQUU7RUFBQyxPQUFPLEtBQUssT0FBTyxFQUFFLEVBQUUsS0FBSyxDQUFDLE1BQUksS0FBSyxPQUFPLEtBQUcsQ0FBQyxDQUFDLFVBQU87R0FBQyxLQUFLLE9BQU8sS0FBRyxLQUFLLE9BQU8sRUFBRSxFQUFFLFNBQVEsTUFBRyxNQUFJLEVBQUU7RUFBQztDQUFDO0NBQUMsSUFBSSxHQUFFLEdBQUU7RUFBQyxLQUFLLE9BQU8sS0FBRyxLQUFLLE9BQU8sRUFBRSxFQUFFLFNBQVEsTUFBRyxNQUFJLEVBQUU7Q0FBQztDQUFDLFVBQVM7RUFBQyxLQUFLLFNBQU8sQ0FBQztDQUFDO0FBQUM7QUFBQyxJQUFNLElBQUUsTUFBSTtBQUFFLElBQU0sZ0JBQU4sTUFBbUI7Q0FBQyxZQUFZLEdBQUUsRUFBQyxpQkFBZ0IsSUFBRSxHQUFFLGlCQUFnQixJQUFFLEtBQUc7RUFBQyxLQUFLLFVBQVEsR0FBRSxLQUFLLGtCQUFnQixHQUFFLEtBQUssa0JBQWdCLEdBQUUsS0FBSyxhQUFXO0dBQUMsR0FBRTtHQUFLLEdBQUU7RUFBSSxHQUFFLEtBQUssVUFBUSxJQUFJLFFBQU0sR0FBRSxPQUFPLGlCQUFpQixVQUFTLEtBQUssZ0JBQWUsQ0FBQyxDQUFDLEdBQUUsS0FBSyxlQUFlLEdBQUUsS0FBSyxRQUFRLGlCQUFpQixTQUFRLEtBQUssU0FBUSxFQUFDLFNBQVEsQ0FBQyxFQUFDLENBQUMsR0FBRSxLQUFLLFFBQVEsaUJBQWlCLGNBQWEsS0FBSyxjQUFhLEVBQUMsU0FBUSxDQUFDLEVBQUMsQ0FBQyxHQUFFLEtBQUssUUFBUSxpQkFBaUIsYUFBWSxLQUFLLGFBQVksRUFBQyxTQUFRLENBQUMsRUFBQyxDQUFDLEdBQUUsS0FBSyxRQUFRLGlCQUFpQixZQUFXLEtBQUssWUFBVyxFQUFDLFNBQVEsQ0FBQyxFQUFDLENBQUM7Q0FBQztDQUFDLEdBQUcsR0FBRSxHQUFFO0VBQUMsT0FBTyxLQUFLLFFBQVEsR0FBRyxHQUFFLENBQUM7Q0FBQztDQUFDLFVBQVM7RUFBQyxLQUFLLFFBQVEsUUFBUSxHQUFFLE9BQU8sb0JBQW9CLFVBQVMsS0FBSyxnQkFBZSxDQUFDLENBQUMsR0FBRSxLQUFLLFFBQVEsb0JBQW9CLFNBQVEsS0FBSyxTQUFRLEVBQUMsU0FBUSxDQUFDLEVBQUMsQ0FBQyxHQUFFLEtBQUssUUFBUSxvQkFBb0IsY0FBYSxLQUFLLGNBQWEsRUFBQyxTQUFRLENBQUMsRUFBQyxDQUFDLEdBQUUsS0FBSyxRQUFRLG9CQUFvQixhQUFZLEtBQUssYUFBWSxFQUFDLFNBQVEsQ0FBQyxFQUFDLENBQUMsR0FBRSxLQUFLLFFBQVEsb0JBQW9CLFlBQVcsS0FBSyxZQUFXLEVBQUMsU0FBUSxDQUFDLEVBQUMsQ0FBQztDQUFDO0NBQUMsZ0JBQWEsTUFBRztFQUFDLE1BQUssRUFBQyxTQUFRLEdBQUUsU0FBUSxNQUFHLEVBQUUsZ0JBQWMsRUFBRSxjQUFjLEtBQUc7RUFBRSxLQUFLLFdBQVcsSUFBRSxHQUFFLEtBQUssV0FBVyxJQUFFLEdBQUUsS0FBSyxZQUFVO0dBQUMsR0FBRTtHQUFFLEdBQUU7RUFBQyxHQUFFLEtBQUssUUFBUSxLQUFLLFVBQVM7R0FBQyxRQUFPO0dBQUUsUUFBTztHQUFFLE9BQU07RUFBQyxDQUFDO0NBQUM7Q0FBRSxlQUFZLE1BQUc7RUFBQyxNQUFLLEVBQUMsU0FBUSxHQUFFLFNBQVEsTUFBRyxFQUFFLGdCQUFjLEVBQUUsY0FBYyxLQUFHLEdBQUUsSUFBRSxFQUFFLElBQUUsS0FBSyxXQUFXLEtBQUcsS0FBSyxpQkFBZ0IsSUFBRSxFQUFFLElBQUUsS0FBSyxXQUFXLEtBQUcsS0FBSztFQUFnQixLQUFLLFdBQVcsSUFBRSxHQUFFLEtBQUssV0FBVyxJQUFFLEdBQUUsS0FBSyxZQUFVO0dBQUMsR0FBRTtHQUFFLEdBQUU7RUFBQyxHQUFFLEtBQUssUUFBUSxLQUFLLFVBQVM7R0FBQyxRQUFPO0dBQUUsUUFBTztHQUFFLE9BQU07RUFBQyxDQUFDO0NBQUM7Q0FBRSxjQUFXLE1BQUc7RUFBQyxLQUFLLFFBQVEsS0FBSyxVQUFTO0dBQUMsUUFBTyxLQUFLLFVBQVU7R0FBRSxRQUFPLEtBQUssVUFBVTtHQUFFLE9BQU07RUFBQyxDQUFDO0NBQUM7Q0FBRSxXQUFRLE1BQUc7RUFBQyxJQUFHLEVBQUMsUUFBTyxHQUFFLFFBQU8sR0FBRSxXQUFVLE1BQUc7RUFBRSxLQUFHLE1BQUksSUFBRSxJQUFFLE1BQUksSUFBRSxLQUFLLGNBQVksR0FBRSxLQUFHLE1BQUksSUFBRSxJQUFFLE1BQUksSUFBRSxLQUFLLGVBQWEsR0FBRSxLQUFHLEtBQUssaUJBQWdCLEtBQUcsS0FBSyxpQkFBZ0IsS0FBSyxRQUFRLEtBQUssVUFBUztHQUFDLFFBQU87R0FBRSxRQUFPO0dBQUUsT0FBTTtFQUFDLENBQUM7Q0FBQztDQUFFLHVCQUFtQjtFQUFDLEtBQUssY0FBWSxPQUFPLFlBQVcsS0FBSyxlQUFhLE9BQU87Q0FBVztBQUFDO0FBQUMsSUFBTSxRQUFOLE1BQVc7Q0FBQyxZQUFZLEVBQUMsU0FBUSxJQUFFLFFBQU8sU0FBUSxJQUFFLFNBQVMsaUJBQWdCLG1CQUFrQixJQUFFLEdBQUUsY0FBYSxJQUFFLEdBQUUsYUFBWSxJQUFFLENBQUMsR0FBRSxXQUFVLElBQUUsQ0FBQyxHQUFFLGVBQWMsSUFBRSxNQUFLLHdCQUF1QixJQUFFLElBQUcsVUFBUyxHQUFFLFFBQU8sTUFBRyxNQUFHLEtBQUssSUFBSSxHQUFFLFFBQU0sS0FBSyxJQUFJLEdBQUUsTUFBSSxDQUFDLENBQUMsSUFBRyxNQUFLLElBQUUsQ0FBQyxLQUFHLElBQUcsVUFBUyxJQUFFLENBQUMsR0FBRSxhQUFZLElBQUUsWUFBVyxvQkFBbUIsSUFBRSxZQUFXLGlCQUFnQixJQUFFLEdBQUUsaUJBQWdCLElBQUUsR0FBRSxZQUFXLElBQUUsQ0FBQyxHQUFFLGlDQUFnQyxJQUFFLENBQUMsTUFBRyxDQUFDLEdBQUU7RUFBQyxLQUFLLGFBQVcsQ0FBQyxHQUFFLEtBQUssZ0JBQWMsQ0FBQyxHQUFFLEtBQUssY0FBWSxDQUFDLEdBQUUsS0FBSyxhQUFXLENBQUMsR0FBRSxLQUFLLG1CQUFpQixFQUFDLFFBQU8sR0FBRSxRQUFPLEdBQUUsT0FBTSxRQUFLO0dBQUMsSUFBRyxFQUFFLFNBQVE7R0FBTyxNQUFNLElBQUUsRUFBRSxLQUFLLFNBQVMsT0FBTyxHQUFFLElBQUUsRUFBRSxLQUFLLFNBQVMsT0FBTztHQUFFLElBQUcsS0FBSyxRQUFRLGFBQVcsS0FBRyxpQkFBZSxFQUFFLFFBQU0sQ0FBQyxLQUFLLGFBQVcsQ0FBQyxLQUFLLFVBQVMsT0FBTyxLQUFLLEtBQUssTUFBTTtHQUFFLE1BQU0sSUFBRSxNQUFJLEtBQUcsTUFBSSxHQUFFLElBQUUsZUFBYSxLQUFLLFFBQVEsc0JBQW9CLE1BQUksS0FBRyxpQkFBZSxLQUFLLFFBQVEsc0JBQW9CLE1BQUk7R0FBRSxJQUFHLEtBQUcsR0FBRTtHQUFPLElBQUksSUFBRSxFQUFFLGFBQWE7R0FBRSxJQUFHLElBQUUsRUFBRSxNQUFNLEdBQUUsRUFBRSxRQUFRLEtBQUssV0FBVyxDQUFDLEdBQUUsRUFBRSxPQUFNLE1BQUc7SUFBQyxJQUFJLEdBQUUsR0FBRSxHQUFFLEdBQUU7SUFBRSxRQUFPLFVBQVEsSUFBRSxFQUFFLGlCQUFlLEtBQUssTUFBSSxJQUFFLEtBQUssSUFBRSxFQUFFLEtBQUssR0FBRSxvQkFBb0IsTUFBSSxNQUFJLFVBQVEsSUFBRSxFQUFFLGlCQUFlLEtBQUssTUFBSSxJQUFFLEtBQUssSUFBRSxFQUFFLEtBQUssR0FBRSwwQkFBMEIsTUFBSSxNQUFJLFVBQVEsSUFBRSxFQUFFLGlCQUFlLEtBQUssTUFBSSxJQUFFLEtBQUssSUFBRSxFQUFFLEtBQUssR0FBRSwwQkFBMEIsT0FBSyxVQUFRLElBQUUsRUFBRSxjQUFZLEtBQUssTUFBSSxJQUFFLEtBQUssSUFBRSxFQUFFLFNBQVMsT0FBTyxNQUFJLEVBQUUsVUFBUSxJQUFFLEVBQUUsY0FBWSxLQUFLLE1BQUksSUFBRSxLQUFLLElBQUUsRUFBRSxTQUFTLGVBQWU7R0FBRSxFQUFFLEdBQUU7R0FBTyxJQUFHLEtBQUssYUFBVyxLQUFLLFVBQVMsT0FBTyxLQUFLLEVBQUUsZUFBZTtHQUFFLElBQUcsS0FBSyxXQUFTLEtBQUssUUFBUSxhQUFXLEtBQUcsS0FBSyxRQUFRLGVBQWEsR0FBRSxDQUFDLEtBQUssVUFBUyxPQUFPLEtBQUssY0FBWSxDQUFDLEdBQUUsS0FBSyxLQUFLLFFBQVEsS0FBSztHQUFFLEVBQUUsZUFBZTtHQUFFLElBQUksSUFBRTtHQUFFLFdBQVMsS0FBSyxRQUFRLHFCQUFtQixJQUFFLEtBQUssSUFBSSxDQUFDLElBQUUsS0FBSyxJQUFJLENBQUMsSUFBRSxJQUFFLElBQUUsaUJBQWUsS0FBSyxRQUFRLHVCQUFxQixJQUFFO0dBQUcsTUFBTSxJQUFFLEtBQUcsS0FBSyxRQUFRLFdBQVUsSUFBRSxLQUFHLGVBQWEsRUFBRSxRQUFNLEtBQUssSUFBSSxDQUFDLElBQUU7R0FBRSxNQUFJLElBQUUsS0FBSyxXQUFTLEtBQUssUUFBUSx5QkFBd0IsS0FBSyxTQUFTLEtBQUssZUFBYSxHQUFFLE9BQU8sT0FBTyxFQUFDLGNBQWEsQ0FBQyxFQUFDLEdBQUUsSUFBRSxFQUFDLE1BQUssSUFBRSxLQUFLLFFBQVEsZ0JBQWMsRUFBQyxJQUFFO0lBQUMsTUFBSyxLQUFLLFFBQVE7SUFBSyxVQUFTLEtBQUssUUFBUTtJQUFTLFFBQU8sS0FBSyxRQUFRO0dBQU0sQ0FBQyxDQUFDO0VBQUMsR0FBRSxLQUFLLHVCQUFtQjtHQUFDLElBQUcsQ0FBQyxLQUFLLDRCQUEwQixDQUFDLEtBQUssYUFBWTtJQUFDLE1BQU0sSUFBRSxLQUFLO0lBQWUsS0FBSyxpQkFBZSxLQUFLLGVBQWEsS0FBSyxjQUFhLEtBQUssV0FBUyxHQUFFLEtBQUssWUFBVSxLQUFLLEtBQUssS0FBSyxpQkFBZSxDQUFDLEdBQUUsS0FBSyxLQUFLO0dBQUM7RUFBQyxHQUFFLE9BQU8sZUFBYSxVQUFTLE1BQUksU0FBUyxtQkFBaUIsTUFBSSxTQUFTLFNBQU8sSUFBRSxTQUFRLEtBQUssVUFBUTtHQUFDLFNBQVE7R0FBRSxTQUFRO0dBQUUsbUJBQWtCO0dBQUUsY0FBYTtHQUFFLGFBQVk7R0FBRSxXQUFVO0dBQUUsZUFBYztHQUFFLHdCQUF1QjtHQUFFLFVBQVM7R0FBRSxRQUFPO0dBQUUsTUFBSztHQUFFLFVBQVM7R0FBRSxvQkFBbUI7R0FBRSxhQUFZO0dBQUUsaUJBQWdCO0dBQUUsaUJBQWdCO0dBQUUsWUFBVztHQUFFLGlDQUFnQztFQUFDLEdBQUUsS0FBSyxVQUFRLElBQUksUUFBTSxHQUFFLEtBQUssVUFBUSxJQUFJLFFBQU0sR0FBRSxLQUFLLGFBQVcsSUFBSSxXQUFXO0dBQUMsU0FBUTtHQUFFLFNBQVE7R0FBRSxZQUFXO0VBQUMsQ0FBQyxHQUFFLEtBQUssZ0JBQWdCLFNBQVEsQ0FBQyxDQUFDLEdBQUUsS0FBSyxXQUFTLEdBQUUsS0FBSyxXQUFTLENBQUMsR0FBRSxLQUFLLFlBQVUsQ0FBQyxHQUFFLEtBQUssV0FBUyxLQUFHLEdBQUUsS0FBSyxjQUFZLENBQUMsR0FBRSxLQUFLLGVBQWEsS0FBSyxpQkFBZSxLQUFLLGNBQWEsS0FBSyxRQUFRLFFBQVEsaUJBQWlCLFVBQVMsS0FBSyxnQkFBZSxDQUFDLENBQUMsR0FBRSxLQUFLLGdCQUFjLElBQUksY0FBYyxHQUFFO0dBQUMsaUJBQWdCO0dBQUUsaUJBQWdCO0VBQUMsQ0FBQyxHQUFFLEtBQUssY0FBYyxHQUFHLFVBQVMsS0FBSyxlQUFlO0NBQUM7Q0FBQyxVQUFTO0VBQUMsS0FBSyxRQUFRLFFBQVEsR0FBRSxLQUFLLFFBQVEsUUFBUSxvQkFBb0IsVUFBUyxLQUFLLGdCQUFlLENBQUMsQ0FBQyxHQUFFLEtBQUssY0FBYyxRQUFRLEdBQUUsS0FBSyxXQUFXLFFBQVEsR0FBRSxLQUFLLGdCQUFnQixTQUFRLENBQUMsQ0FBQyxHQUFFLEtBQUssZ0JBQWdCLGdCQUFlLENBQUMsQ0FBQyxHQUFFLEtBQUssZ0JBQWdCLG1CQUFrQixDQUFDLENBQUMsR0FBRSxLQUFLLGdCQUFnQixpQkFBZ0IsQ0FBQyxDQUFDLEdBQUUsS0FBSyxnQkFBZ0IsZ0JBQWUsQ0FBQyxDQUFDO0NBQUM7Q0FBQyxHQUFHLEdBQUUsR0FBRTtFQUFDLE9BQU8sS0FBSyxRQUFRLEdBQUcsR0FBRSxDQUFDO0NBQUM7Q0FBQyxJQUFJLEdBQUUsR0FBRTtFQUFDLE9BQU8sS0FBSyxRQUFRLElBQUksR0FBRSxDQUFDO0NBQUM7Q0FBQyxVQUFVLEdBQUU7RUFBQyxLQUFLLGVBQWEsS0FBSyxZQUFZLGFBQVcsSUFBRSxLQUFLLFlBQVksWUFBVTtDQUFDO0NBQUMsU0FBUTtFQUFDLEtBQUssV0FBVyxPQUFPO0NBQUM7Q0FBQyxPQUFNO0VBQUMsS0FBSyxRQUFRLEtBQUssVUFBUyxJQUFJO0NBQUM7Q0FBQyxRQUFPO0VBQUMsS0FBSyxXQUFTLENBQUMsR0FBRSxLQUFLLGNBQVksQ0FBQyxHQUFFLEtBQUssaUJBQWUsS0FBSyxlQUFhLEtBQUssY0FBYSxLQUFLLFdBQVMsR0FBRSxLQUFLLFFBQVEsS0FBSztDQUFDO0NBQUMsUUFBTztFQUFDLEtBQUssY0FBWSxLQUFLLFlBQVUsQ0FBQyxHQUFFLEtBQUssTUFBTTtDQUFFO0NBQUMsT0FBTTtFQUFDLEtBQUssY0FBWSxLQUFLLFlBQVUsQ0FBQyxHQUFFLEtBQUssUUFBUSxLQUFLLEdBQUUsS0FBSyxNQUFNO0NBQUU7Q0FBQyxJQUFJLEdBQUU7RUFBQyxNQUFNLElBQUUsS0FBRyxLQUFLLFFBQU07RUFBRyxLQUFLLE9BQUssR0FBRSxLQUFLLFFBQVEsUUFBUSxPQUFLLENBQUM7Q0FBQztDQUFDLFNBQVMsR0FBRSxFQUFDLFFBQU8sSUFBRSxHQUFFLFdBQVUsSUFBRSxDQUFDLEdBQUUsTUFBSyxJQUFFLENBQUMsR0FBRSxVQUFTLElBQUUsS0FBSyxRQUFRLFVBQVMsUUFBTyxJQUFFLEtBQUssUUFBUSxRQUFPLE1BQUssSUFBRSxDQUFDLEtBQUcsS0FBSyxRQUFRLE1BQUssWUFBVyxHQUFFLE9BQU0sSUFBRSxDQUFDLEdBQUUsY0FBYSxJQUFFLENBQUMsTUFBRyxDQUFDLEdBQUU7RUFBQyxJQUFHLENBQUMsS0FBSyxhQUFXLENBQUMsS0FBSyxZQUFVLEdBQUU7R0FBQyxJQUFHO0lBQUM7SUFBTTtJQUFPO0dBQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFFLElBQUU7UUFBTyxJQUFHO0lBQUM7SUFBUztJQUFRO0dBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFFLElBQUUsS0FBSztRQUFVO0lBQUMsSUFBSTtJQUFFLElBQUcsWUFBVSxPQUFPLElBQUUsSUFBRSxTQUFTLGNBQWMsQ0FBQyxJQUFHLFFBQU0sS0FBUyxFQUFFLGFBQVksSUFBRSxJQUFHLEdBQUU7S0FBQyxJQUFHLEtBQUssUUFBUSxZQUFVLFFBQU87TUFBQyxNQUFNLElBQUUsS0FBSyxRQUFRLFFBQVEsc0JBQXNCO01BQUUsS0FBRyxLQUFLLGVBQWEsRUFBRSxPQUFLLEVBQUU7S0FBRztLQUFDLE1BQU0sSUFBRSxFQUFFLHNCQUFzQjtLQUFFLEtBQUcsS0FBSyxlQUFhLEVBQUUsT0FBSyxFQUFFLE9BQUssS0FBSztJQUFjO0dBQUM7R0FBQyxJQUFHLFlBQVUsT0FBTyxHQUFFO0lBQUMsSUFBRyxLQUFHLEdBQUUsSUFBRSxLQUFLLE1BQU0sQ0FBQyxHQUFFLEtBQUssUUFBUSxXQUFTLE1BQUksS0FBSyxlQUFhLEtBQUssaUJBQWUsS0FBSyxVQUFRLElBQUUsRUFBRSxHQUFFLEdBQUUsS0FBSyxLQUFLLEdBQUUsR0FBRSxPQUFPLEtBQUssaUJBQWUsS0FBSyxlQUFhLEdBQUUsS0FBSyxVQUFVLEtBQUssTUFBTSxHQUFFLEtBQUssTUFBTSxHQUFFLE1BQUssUUFBTSxLQUFHLEVBQUUsSUFBSTtJQUFHLElBQUcsQ0FBQyxHQUFFO0tBQUMsSUFBRyxNQUFJLEtBQUssY0FBYTtLQUFPLEtBQUssZUFBYTtJQUFDO0lBQUMsS0FBSyxRQUFRLE9BQU8sS0FBSyxnQkFBZSxHQUFFO0tBQUMsVUFBUztLQUFFLFFBQU87S0FBRSxNQUFLO0tBQUUsZUFBWTtNQUFDLE1BQUksS0FBSyxXQUFTLENBQUMsSUFBRyxLQUFLLGNBQVksQ0FBQztLQUFDO0tBQUUsV0FBVSxHQUFFLE1BQUk7TUFBQyxLQUFLLGNBQVksQ0FBQyxHQUFFLEtBQUssV0FBUyxJQUFFLEtBQUssZ0JBQWUsS0FBSyxZQUFVLEtBQUssS0FBSyxLQUFLLFFBQVEsR0FBRSxLQUFLLGlCQUFlLEdBQUUsS0FBSyxVQUFVLEtBQUssTUFBTSxHQUFFLE1BQUksS0FBSyxlQUFhLElBQUcsS0FBRyxLQUFLLEtBQUssR0FBRSxNQUFJLEtBQUssTUFBTSxHQUFFLEtBQUssS0FBSyxHQUFRLElBQUssSUFBSSxHQUFFLEtBQUssMkJBQXlCLENBQUMsR0FBRSw2QkFBMkI7T0FBQyxPQUFPLEtBQUs7TUFBd0IsRUFBRTtLQUFFO0lBQUMsQ0FBQztHQUFDO0VBQUM7Q0FBQztDQUFDLElBQUksY0FBYTtFQUFDLE9BQU8sS0FBSyxRQUFRLFlBQVUsU0FBTyxTQUFTLGtCQUFnQixLQUFLLFFBQVE7Q0FBTztDQUFDLElBQUksUUFBTztFQUFDLE9BQU8sS0FBSyxRQUFRLGtDQUFnQyxLQUFLLGVBQWEsS0FBSyxZQUFZLGNBQVksS0FBSyxZQUFZLGNBQVksS0FBSyxZQUFZLGVBQWEsS0FBSyxZQUFZLGVBQWEsS0FBSyxXQUFXLE1BQU0sS0FBSyxlQUFhLE1BQUk7Q0FBSTtDQUFDLElBQUksZUFBYztFQUFDLE9BQU0saUJBQWUsS0FBSyxRQUFRO0NBQVc7Q0FBQyxJQUFJLGVBQWM7RUFBQyxPQUFPLEtBQUssZUFBYSxLQUFLLFlBQVksYUFBVyxLQUFLLFlBQVk7Q0FBUztDQUFDLElBQUksU0FBUTtFQUFDLE9BQU8sS0FBSyxRQUFRLFlBQVUsSUFBRSxLQUFLLGdCQUFlLElBQUUsS0FBSyxRQUFPLElBQUUsSUFBRSxLQUFHLEtBQUcsS0FBSztNQUFtQixHQUFFO0NBQUM7Q0FBQyxJQUFJLFdBQVU7RUFBQyxPQUFPLE1BQUksS0FBSyxRQUFNLElBQUUsS0FBSyxTQUFPLEtBQUs7Q0FBSztDQUFDLElBQUksV0FBVTtFQUFDLE9BQU8sS0FBSztDQUFVO0NBQUMsSUFBSSxTQUFTLEdBQUU7RUFBQyxLQUFLLGVBQWEsTUFBSSxLQUFLLGFBQVcsR0FBRSxLQUFLLGdCQUFnQixnQkFBZSxDQUFDO0NBQUU7Q0FBQyxJQUFJLGNBQWE7RUFBQyxPQUFPLEtBQUs7Q0FBYTtDQUFDLElBQUksWUFBWSxHQUFFO0VBQUMsS0FBSyxrQkFBZ0IsTUFBSSxLQUFLLGdCQUFjLEdBQUUsS0FBSyxnQkFBZ0IsbUJBQWtCLENBQUM7Q0FBRTtDQUFDLElBQUksWUFBVztFQUFDLE9BQU8sS0FBSztDQUFXO0NBQUMsSUFBSSxVQUFVLEdBQUU7RUFBQyxLQUFLLGdCQUFjLE1BQUksS0FBSyxjQUFZLEdBQUUsS0FBSyxnQkFBZ0IsaUJBQWdCLENBQUM7Q0FBRTtDQUFDLElBQUksV0FBVTtFQUFDLE9BQU8sS0FBSztDQUFVO0NBQUMsSUFBSSxTQUFTLEdBQUU7RUFBQyxLQUFLLGVBQWEsTUFBSSxLQUFLLGFBQVcsR0FBRSxLQUFLLGdCQUFnQixnQkFBZSxDQUFDO0NBQUU7Q0FBQyxJQUFJLFlBQVc7RUFBQyxJQUFJLElBQUU7RUFBUSxPQUFPLEtBQUssY0FBWSxLQUFHLG1CQUFrQixLQUFLLGFBQVcsS0FBRyxrQkFBaUIsS0FBSyxnQkFBYyxLQUFHLHFCQUFvQixLQUFLLGFBQVcsS0FBRyxrQkFBaUI7Q0FBQztDQUFDLGdCQUFnQixHQUFFLEdBQUU7RUFBQyxLQUFLLFlBQVksVUFBVSxPQUFPLEdBQUUsQ0FBQyxHQUFFLEtBQUssUUFBUSxLQUFLLG9CQUFtQixJQUFJO0NBQUM7QUFBQyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=