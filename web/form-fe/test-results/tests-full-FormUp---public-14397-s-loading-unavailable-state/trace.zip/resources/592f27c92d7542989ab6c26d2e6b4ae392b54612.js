/**
* AI Service for Generating Quiz & Form Questions using Google Gemini API
* Model list matches Google AI Studio free tier models.
*/
export const AVAILABLE_MODELS = [{
	id: "gemini-3.6-flash",
	name: "Gemini 3.6 Flash",
	desc: "Paling Cepat & Akurat (Rekomendasi)",
	badge: "Rekomendasi"
}, {
	id: "gemini-3.6-flash-lite",
	name: "Gemini 3.6 Flash Lite",
	desc: "Hemat Kuota (Limit 10 RPM) & Responsif",
	badge: "Hemat Kuota"
}];
export const DEFAULT_AI_MODEL = "gemini-3.6-flash";
export const normalizeAiModel = (model) => {
	if (!model || model.includes("-pro") || model === "gemini-3-flash-preview" || !AVAILABLE_MODELS.some((item) => item.id === model)) return DEFAULT_AI_MODEL;
	return model;
};
/**
* API Key Stacking (Multi-Key with Auto-Failover)
*/
export const getGeminiApiKeys = () => {
	if (typeof window !== "undefined") {
		try {
			const raw = localStorage.getItem("formup_gemini_api_keys");
			if (raw) {
				const parsed = JSON.parse(raw);
				if (Array.isArray(parsed) && parsed.length > 0) {
					return parsed.map((k) => String(k).trim()).filter(Boolean);
				}
			}
		} catch {}
		const legacy = localStorage.getItem("formup_gemini_api_key");
		if (legacy && legacy.trim()) {
			return [legacy.trim()];
		}
	}
	return [];
};
export const saveGeminiApiKeys = (keysInput) => {
	if (typeof window !== "undefined") {
		let cleanKeys = [];
		if (Array.isArray(keysInput)) {
			cleanKeys = keysInput.map((k) => String(k).trim()).filter(Boolean);
		} else if (typeof keysInput === "string") {
			cleanKeys = keysInput.split(/[\n,;]+/).map((k) => k.trim()).filter(Boolean);
		}
		// Deduplicate while preserving order
		cleanKeys = Array.from(new Set(cleanKeys));
		if (cleanKeys.length === 0) {
			localStorage.removeItem("formup_gemini_api_keys");
			localStorage.removeItem("formup_gemini_api_key");
			localStorage.removeItem("formup_gemini_active_key_idx");
		} else {
			localStorage.setItem("formup_gemini_api_keys", JSON.stringify(cleanKeys));
			localStorage.setItem("formup_gemini_api_key", cleanKeys[0]);
			const curIdx = parseInt(localStorage.getItem("formup_gemini_active_key_idx") || "0", 10);
			if (curIdx >= cleanKeys.length) {
				localStorage.setItem("formup_gemini_active_key_idx", "0");
			}
		}
		return cleanKeys;
	}
	return [];
};
export const getActiveApiKeyIndex = () => {
	if (typeof window !== "undefined") {
		const idx = parseInt(localStorage.getItem("formup_gemini_active_key_idx") || "0", 10);
		const keys = getGeminiApiKeys();
		if (idx >= 0 && idx < keys.length) return idx;
	}
	return 0;
};
export const rotateToNextApiKey = () => {
	if (typeof window !== "undefined") {
		const keys = getGeminiApiKeys();
		if (keys.length <= 1) return {
			index: 0,
			key: keys[0] || "",
			total: keys.length,
			rotated: false
		};
		const curIdx = getActiveApiKeyIndex();
		const nextIdx = (curIdx + 1) % keys.length;
		localStorage.setItem("formup_gemini_active_key_idx", String(nextIdx));
		localStorage.setItem("formup_gemini_api_key", keys[nextIdx]);
		return {
			index: nextIdx,
			key: keys[nextIdx],
			total: keys.length,
			rotated: true
		};
	}
	return {
		index: 0,
		key: "",
		total: 0,
		rotated: false
	};
};
export const getGeminiApiKey = () => {
	const keys = getGeminiApiKeys();
	if (keys.length === 0) return "";
	const idx = getActiveApiKeyIndex();
	return keys[idx] || keys[0] || "";
};
export const saveGeminiApiKey = (key) => {
	if (!key || !key.trim()) {
		saveGeminiApiKeys([]);
	} else {
		const existing = getGeminiApiKeys();
		if (!existing.includes(key.trim())) {
			saveGeminiApiKeys([key.trim(), ...existing]);
		}
	}
};
export const removeGeminiApiKey = () => {
	saveGeminiApiKeys([]);
};
/**
* Execute Gemini API request with automatic multi-key failover rotation.
*/
export const executeWithApiKeyFailover = async (requestFn, customApiKey = null) => {
	if (customApiKey && customApiKey.trim()) {
		return await requestFn(customApiKey.trim(), 0, 1);
	}
	const keys = getGeminiApiKeys();
	if (keys.length === 0) {
		return {
			ok: false,
			message: "API Key Gemini belum diatur. Masukkan API Key dari Google AI Studio."
		};
	}
	let startIdx = getActiveApiKeyIndex();
	let attempts = 0;
	const maxAttempts = keys.length;
	while (attempts < maxAttempts) {
		const currentIdx = (startIdx + attempts) % keys.length;
		const currentKey = keys[currentIdx];
		try {
			const result = await requestFn(currentKey, currentIdx, keys.length);
			// Check if result returned an HTTP rate-limit or key error
			if (result && result.status && (result.status === 429 || result.status === 400 || result.status === 403)) {
				if (keys.length > 1 && attempts + 1 < maxAttempts) {
					console.warn(`[API Key Stacking]: Key #${currentIdx + 1} hit error (${result.status}). Auto-failing over to next key...`);
					rotateToNextApiKey();
					attempts++;
					continue;
				}
			}
			// If response is successful, ensure active index matches working key
			if (result && result.ok) {
				if (getActiveApiKeyIndex() !== currentIdx) {
					localStorage.setItem("formup_gemini_active_key_idx", String(currentIdx));
					localStorage.setItem("formup_gemini_api_key", currentKey);
				}
			}
			return result;
		} catch (err) {
			const isRateLimitOrAuth = err?.message && (err.message.includes("429") || err.message.includes("RESOURCE_EXHAUSTED") || err.message.includes("API_KEY_INVALID") || err.message.includes("403") || err.message.includes("quota"));
			if (isRateLimitOrAuth && keys.length > 1 && attempts + 1 < maxAttempts) {
				console.warn(`[API Key Stacking]: Exception on Key #${currentIdx + 1}. Auto-rotating to next key...`, err);
				rotateToNextApiKey();
				attempts++;
				continue;
			}
			throw err;
		}
	}
	return {
		ok: false,
		message: `Seluruh ${keys.length} API Key telah mencapai batas kuota (Rate Limit 429) atau tidak valid. Silakan tambahkan key baru atau coba lagi nanti.`
	};
};
// B2: Guardrail instruction injected into every AI prompt
const AI_GUARDRAIL = `PERAN & BATASAN KERAS: Anda adalah asisten KHUSUS pembuatan soal ujian dan kuis untuk aplikasi pendidikan FormUp. Anda HANYA boleh membantu hal-hal yang berkaitan dengan:
- Membuat, merevisi, atau mengevaluasi soal ujian/kuis/latihan
- Materi pelajaran, topik akademik, dan konten edukasi
- Format soal (pilihan ganda, essay, benar/salah, checkbox, dll.)

Jika diminta hal di luar ini (kode untuk tujuan lain, konten tidak pantas, topik non-edukasi, percakapan umum yang tidak relevan), TOLAK dengan pesan sopan: "Maaf, saya hanya dapat membantu membuat soal ujian dan kuis untuk keperluan pendidikan."

`;
// Helper to parse JSON with unescaped LaTeX backslashes repair
export const safeJsonParse = (rawStr) => {
	if (!rawStr) return null;
	let cleaned = rawStr.trim().replace(/^```json\s*/i, "").replace(/\s*```$/i, "").replace(/^```\s*/i, "").trim();
	try {
		return JSON.parse(cleaned);
	} catch (e1) {
		try {
			// Repair unescaped backslashes that are not valid JSON escape chars (\", \\, /, \b, \f, \n, \r, \t, \uXXXX)
			const repaired = cleaned.replace(/\\([^"\\/bfnrtu]|u(?![\da-fA-F]{4}))/g, "\\\\$1");
			return JSON.parse(repaired);
		} catch {
			const jsonMatch = cleaned.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
			if (jsonMatch) {
				const repaired = jsonMatch[0].replace(/\\([^"\\/bfnrtu]|u(?![\da-fA-F]{4}))/g, "\\\\$1");
				return JSON.parse(repaired);
			}
			throw e1;
		}
	}
};
/**
* Generate structured quiz questions using Google Gemini API
*/
export const generateQuestionsWithAI = async ({ topic, contextText = "", count = 5, typePreference = "2", difficulty = "Sedang", includeMath = false, includeCode = false, selectedModel = DEFAULT_AI_MODEL, customApiKey = null, onStatus = null }) => {
	const setStatus = (msg) => {
		if (typeof onStatus === "function") onStatus(msg);
	};
	setStatus(`Mempersiapkan pembuatan ${count} butir soal materi "${topic}"...`);
	const typeDescription = {
		"1": "Semua soal bertipe Essay / Isian Singkat (typeId: 1, sertakan kunci/contoh jawaban di correctAnswer).",
		"2": "Semua soal bertipe Pilihan Ganda (typeId: 2, sediakan 4 pilihan jawaban di options di mana tepat SATU bernilai isCorrect: true).",
		"3": "Semua soal bertipe Checkbox / Pilihan Majemuk (typeId: 3, sediakan 4-5 opsi di mana ada minimal 2 bernilai isCorrect: true).",
		"5": "Semua soal bertipe Benar / Salah (typeId: 5, correctAnswer diisi \"Benar\" atau \"Salah\").",
		"mixed": "Variasi campuran antara Pilihan Ganda (typeId: 2), Benar/Salah (typeId: 5), dan Essay (typeId: 1)."
	}[typePreference] || "Pilihan Ganda (typeId: 2)";
	let extraInstructions = [];
	if (includeMath) {
		extraInstructions.push("Gunakan rumus matematika/fisika dalam format LaTeX $...$ untuk inline atau $$...$$ untuk tampilan terpisah jika relevan.");
	}
	if (includeCode) {
		extraInstructions.push("Untuk potongan kode, tulis dalam format ```bahasa\\nkode\\n``` di baris terpisah.");
	}
	if (contextText && contextText.trim()) {
		extraInstructions.push(`Gunakan materi referensi berikut sebagai acuan utama:\n"""\n${contextText.trim()}\n"""`);
	}
	// B2: Guardrail prepended to prompt
	const promptText = `${AI_GUARDRAIL}Buatlah ${count} butir soal berkualitas tinggi dengan panduan berikut:

- **Materi / Topik:** ${topic || "Pengetahuan Umum"}
- **Tingkat Kesulitan:** ${difficulty}
- **Bentuk Soal:** ${typeDescription}
- **Bahasa:** Gunakan bahasa yang SAMA dengan bahasa topik/materi di atas untuk SELURUH output — termasuk teks pertanyaan, SEMUA opsi jawaban, dan kunci jawaban (correctAnswer). Jangan mencampur bahasa.
${extraInstructions.length > 0 ? `- **Panduan Tambahan:**\n  ${extraInstructions.join("\n  ")}` : ""}

**FORMAT KELUARAN WAJIB (JSON ARRAY):**
Kembalikan HANYA array JSON valid tanpa teks atau penjelasan pembuka/penutup. Struktur objek per soal:
[
  {
    "question": "Teks pertanyaan lengkap",
    "typeId": 2, // 1 = Essay, 2 = Pilihan Ganda, 3 = Checkbox, 5 = Benar/Salah
    "isRequired": true,
    "isScorable": true,
    "correctAnswer": "Kunci jawaban untuk tipe 1 atau 'Benar'/'Salah' untuk tipe 5",
    "options": [
      { "optionText": "Pilihan A", "isCorrect": false },
      { "optionText": "Pilihan B", "isCorrect": true },
      { "optionText": "Pilihan C", "isCorrect": false },
      { "optionText": "Pilihan D", "isCorrect": false }
    ]
  }
]
Catatan Penting:
- Jangan mengisi bobot poin (biarkan default).
- Untuk tipe 2 (Pilihan Ganda), pastikan tepat ada 1 opsi yang isCorrect: true.
- Untuk tipe 1 dan 5, options boleh berupa array kosong [].
`.trim();
	return await executeWithApiKeyFailover(async (apiKey) => {
		try {
			const targetModel = normalizeAiModel(selectedModel);
			setStatus(`Menghubungkan ke ${targetModel} di Google AI Studio...`);
			const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:generateContent?key=${apiKey}`;
			const startTime = Date.now();
			setStatus(`AI (${targetModel}) sedang berpikir & menyusun butir soal...`);
			const controller = new AbortController();
			const timeoutId = setTimeout(() => controller.abort(), 6e4);
			const response = await fetch(endpoint, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				signal: controller.signal,
				body: JSON.stringify({
					contents: [{ parts: [{ text: promptText }] }],
					generationConfig: {
						responseMimeType: "application/json",
						temperature: .7
					}
				})
			});
			clearTimeout(timeoutId);
			const elapsedSec = ((Date.now() - startTime) / 1e3).toFixed(1);
			if (!response.ok) {
				const errData = await response.json().catch(() => ({}));
				const errMsg = errData.error?.message || `HTTP ${response.status} ${response.statusText}`;
				if (response.status === 429) {
					return {
						ok: false,
						status: 429,
						message: `Batas penggunaan / rate limit Google AI Studio untuk model ${targetModel} telah tercapai.`
					};
				}
				if (response.status === 400 || response.status === 403) {
					return {
						ok: false,
						status: response.status,
						message: `API Key Google AI Studio tidak valid atau izin akses ditolak. (${errMsg})`
					};
				}
				if (response.status >= 500) {
					return {
						ok: false,
						status: response.status,
						message: `Server AI Studio sedang tidak tersedia (Error ${response.status}). Coba beberapa menit lagi atau gunakan Gemini 3.6 Flash Lite.`
					};
				}
				return {
					ok: false,
					status: response.status,
					message: `Gagal memanggil model ${targetModel}: ${errMsg}.`
				};
			}
			setStatus(`Menerima hasil dari AI (${elapsedSec} detik). Memeriksa struktur soal...`);
			const data = await response.json();
			const textResponse = data.candidates?.[0]?.content?.parts?.[0]?.text;
			if (!textResponse) {
				return {
					ok: false,
					message: "AI tidak mengembalikan teks soal. Silakan coba klik Generate sekali lagi."
				};
			}
			let parsedQuestions;
			try {
				parsedQuestions = safeJsonParse(textResponse);
			} catch {
				return {
					ok: false,
					message: "AI mengembalikan format yang tidak valid. Coba klik Generate sekali lagi."
				};
			}
			if (!Array.isArray(parsedQuestions) || parsedQuestions.length === 0) {
				return {
					ok: false,
					message: "Format data dari AI tidak valid. Silakan coba klik Generate lagi."
				};
			}
			// Normalize questions to match FormBuilder structure
			const normalized = parsedQuestions.map((q, idx) => {
				const typeId = parseInt(q.typeId, 10) || 2;
				let options = Array.isArray(q.options) ? q.options : [];
				if ([2, 3].includes(typeId) && options.length === 0) {
					options = [
						{
							optionText: "Pilihan A",
							isCorrect: true
						},
						{
							optionText: "Pilihan B",
							isCorrect: false
						},
						{
							optionText: "Pilihan C",
							isCorrect: false
						},
						{
							optionText: "Pilihan D",
							isCorrect: false
						}
					];
				}
				const formattedOptions = options.map((opt, oIdx) => ({
					optionText: String(opt.optionText || opt.text || `Pilihan ${String.fromCharCode(65 + oIdx)}`),
					isCorrect: Boolean(opt.isCorrect)
				}));
				return {
					_id: `q_ai_${Date.now()}_${idx}`,
					id: null,
					question: String(q.question || `Pertanyaan ${idx + 1}`),
					typeId,
					isRequired: q.isRequired !== undefined ? Boolean(q.isRequired) : true,
					isScorable: q.isScorable !== undefined ? Boolean(q.isScorable) : true,
					points: null,
					correctAnswer: q.correctAnswer ? String(q.correctAnswer) : "",
					options: formattedOptions,
					questionImage: null,
					questionAudio: null
				};
			});
			setStatus(`Selesai! ${normalized.length} butir soal siap.`);
			return {
				ok: true,
				data: normalized,
				modelUsed: targetModel,
				elapsedSec
			};
		} catch (err) {
			if (err && err.name === "AbortError") {
				return {
					ok: false,
					message: "Koneksi ke AI Studio timeout. Periksa koneksi internet Anda lalu coba lagi."
				};
			}
			if (err && err.name === "TypeError" && err.message && (err.message.includes("fetch") || err.message.includes("network") || err.message.includes("Failed") || err.message.includes("NetworkError"))) {
				return {
					ok: false,
					message: "Tidak dapat terhubung ke AI Studio. Periksa koneksi internet Anda."
				};
			}
			if (err instanceof SyntaxError) {
				return {
					ok: false,
					message: "AI mengembalikan format yang tidak valid. Coba klik Generate sekali lagi."
				};
			}
			return {
				ok: false,
				message: `Terjadi kendala saat memproses AI: ${err?.message || "Unknown error"}. Coba lagi atau gunakan model lain.`
			};
		}
	}, customApiKey);
};
/**
* B9: Stream quiz questions from Gemini API — questions appear one-by-one as generated.
* @param {object} params - Same generation params as generateQuestionsWithAI
* @param {function} onQuestion - Called with each complete normalized question object
* @param {function} onStatus - Called with status text updates
* @param {function} onDone - Called on completion: { ok, totalCount, modelUsed, elapsedSec } or { ok: false, message }
*/
export const streamGenerateQuestionsWithAI = async ({ topic, contextText = "", count = 5, typePreference = "2", difficulty = "Sedang", includeMath = false, includeCode = false, selectedModel = DEFAULT_AI_MODEL, customApiKey = null }, onQuestion, onStatus, onDone) => {
	const apiKey = (customApiKey || getGeminiApiKey()).trim();
	const setStatus = (msg) => {
		if (typeof onStatus === "function") onStatus(msg);
	};
	if (!apiKey) {
		onDone({
			ok: false,
			message: "API Key Gemini belum diatur."
		});
		return;
	}
	const typeDescription = {
		"1": "Semua soal bertipe Essay / Isian Singkat (typeId: 1, sertakan kunci/contoh jawaban di correctAnswer).",
		"2": "Semua soal bertipe Pilihan Ganda (typeId: 2, sediakan 4 pilihan jawaban di options di mana tepat SATU bernilai isCorrect: true).",
		"3": "Semua soal bertipe Checkbox / Pilihan Majemuk (typeId: 3, sediakan 4-5 opsi di mana ada minimal 2 bernilai isCorrect: true).",
		"5": "Semua soal bertipe Benar / Salah (typeId: 5, correctAnswer diisi \"Benar\" atau \"Salah\").",
		"mixed": "Variasi campuran antara Pilihan Ganda (typeId: 2), Benar/Salah (typeId: 5), dan Essay (typeId: 1)."
	}[typePreference] || "Pilihan Ganda (typeId: 2)";
	let extraInstructions = [];
	if (includeMath) extraInstructions.push("Gunakan rumus matematika/fisika dalam format LaTeX $...$ untuk inline atau $$...$$ untuk tampilan terpisah jika relevan.");
	if (includeCode) extraInstructions.push("Untuk potongan kode, tulis dalam format ```bahasa\\nkode\\n``` di baris terpisah.");
	if (contextText && contextText.trim()) extraInstructions.push(`Gunakan materi referensi berikut sebagai acuan utama:\n"""\n${contextText.trim()}\n"""`);
	const promptText = `${AI_GUARDRAIL}Buatlah ${count} butir soal berkualitas tinggi dengan panduan berikut:
- **Materi / Topik:** ${topic || "Pengetahuan Umum"}
- **Tingkat Kesulitan:** ${difficulty}
- **Bentuk Soal:** ${typeDescription}
- **Bahasa:** Gunakan bahasa yang SAMA dengan bahasa topik/materi di atas untuk SELURUH output.
${extraInstructions.length > 0 ? `- **Panduan Tambahan:**\n  ${extraInstructions.join("\n  ")}` : ""}

**FORMAT KELUARAN WAJIB (JSON ARRAY):**
Kembalikan HANYA array JSON valid tanpa teks atau penjelasan pembuka/penutup.
[
  {
    "question": "Teks pertanyaan lengkap",
    "typeId": 2,
    "isRequired": true,
    "isScorable": true,
    "correctAnswer": "Kunci jawaban",
    "options": [
      { "optionText": "Pilihan A", "isCorrect": false },
      { "optionText": "Pilihan B", "isCorrect": true },
      { "optionText": "Pilihan C", "isCorrect": false },
      { "optionText": "Pilihan D", "isCorrect": false }
    ]
  }
]`.trim();
	const targetModel = normalizeAiModel(selectedModel);
	const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:streamGenerateContent?key=${apiKey}&alt=sse`;
	const startTime = Date.now();
	setStatus(`AI (${targetModel}) sedang menyusun soal...`);
	try {
		const controller = new AbortController();
		const timeoutId = setTimeout(() => controller.abort(), 6e4);
		const response = await fetch(endpoint, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			signal: controller.signal,
			body: JSON.stringify({
				contents: [{ parts: [{ text: promptText }] }],
				generationConfig: { temperature: .7 }
			})
		});
		clearTimeout(timeoutId);
		if (!response.ok) {
			const errData = await response.json().catch(() => ({}));
			const errMsg = errData.error?.message || `HTTP ${response.status}`;
			if (response.status === 429) {
				onDone({
					ok: false,
					message: `Rate limit tercapai untuk model ${targetModel}. Coba model lain atau tunggu sebentar.`
				});
			} else if (response.status === 400 || response.status === 403) {
				onDone({
					ok: false,
					message: `API Key tidak valid atau akses ditolak. (${errMsg})`
				});
			} else if (response.status >= 500) {
				onDone({
					ok: false,
					message: `Server AI Studio tidak tersedia (Error ${response.status}). Coba lagi nanti.`
				});
			} else {
				onDone({
					ok: false,
					message: `Gagal memanggil AI: ${errMsg}`
				});
			}
			return;
		}
		const reader = response.body.getReader();
		const decoder = new TextDecoder();
		let sseBuffer = "";
		let jsonBuffer = "";
		let questionCount = 0;
		let arrayStarted = false;
		const tryParseQuestion = () => {
			let d = 0, inStr = false, esc = false, objectStart = -1;
			for (let i = 0; i < jsonBuffer.length; i++) {
				const ch = jsonBuffer[i];
				if (esc) {
					esc = false;
					continue;
				}
				if (ch === "\\" && inStr) {
					esc = true;
					continue;
				}
				if (ch === "\"") {
					inStr = !inStr;
					continue;
				}
				if (inStr) continue;
				if (ch === "{") {
					if (d === 0) objectStart = i;
					d++;
				} else if (ch === "}") {
					d--;
					if (d === 0 && objectStart !== -1) {
						const objStr = jsonBuffer.slice(objectStart, i + 1);
						jsonBuffer = jsonBuffer.slice(i + 1).replace(/^[,\s]+/, "");
						try {
							const q = JSON.parse(objStr);
							const typeId = parseInt(q.typeId, 10) || 2;
							let options = Array.isArray(q.options) ? q.options : [];
							if ([2, 3].includes(typeId) && options.length === 0) {
								options = [
									{
										optionText: "Pilihan A",
										isCorrect: true
									},
									{
										optionText: "Pilihan B",
										isCorrect: false
									},
									{
										optionText: "Pilihan C",
										isCorrect: false
									},
									{
										optionText: "Pilihan D",
										isCorrect: false
									}
								];
							}
							const normalized = {
								_id: `q_ai_stream_${Date.now()}_${questionCount}`,
								id: null,
								question: String(q.question || `Pertanyaan ${questionCount + 1}`),
								typeId,
								isRequired: q.isRequired !== undefined ? Boolean(q.isRequired) : true,
								isScorable: q.isScorable !== undefined ? Boolean(q.isScorable) : true,
								points: null,
								correctAnswer: q.correctAnswer ? String(q.correctAnswer) : "",
								options: options.map((opt, oIdx) => ({
									optionText: String(opt.optionText || opt.text || `Pilihan ${String.fromCharCode(65 + oIdx)}`),
									isCorrect: Boolean(opt.isCorrect)
								})),
								questionImage: null,
								questionAudio: null
							};
							questionCount++;
							if (typeof onQuestion === "function") onQuestion(normalized);
							setStatus(`Menerima soal ${questionCount}/${count}...`);
							return true;
						} catch {}
						break;
					}
				}
			}
			return false;
		};
		while (true) {
			const { done, value } = await reader.read();
			if (done) break;
			sseBuffer += decoder.decode(value, { stream: true });
			const lines = sseBuffer.split("\n");
			sseBuffer = lines.pop() || "";
			for (const line of lines) {
				if (!line.startsWith("data: ")) continue;
				const dataStr = line.slice(6).trim();
				if (dataStr === "[DONE]") continue;
				try {
					const parsed = JSON.parse(dataStr);
					const text = parsed.candidates?.[0]?.content?.parts?.[0]?.text || "";
					jsonBuffer += text;
					if (!arrayStarted) {
						const trimmed = jsonBuffer.trimStart();
						if (trimmed.startsWith("[")) {
							jsonBuffer = trimmed.slice(1);
							arrayStarted = true;
						}
					}
					let cont = true;
					while (cont) {
						cont = tryParseQuestion();
					}
				} catch {}
			}
		}
		const elapsedSec = ((Date.now() - startTime) / 1e3).toFixed(1);
		setStatus(`Selesai! ${questionCount} butir soal diterima (${elapsedSec} detik).`);
		onDone({
			ok: true,
			totalCount: questionCount,
			modelUsed: targetModel,
			elapsedSec
		});
	} catch (err) {
		if (err && err.name === "AbortError") {
			onDone({
				ok: false,
				message: "Koneksi ke AI Studio timeout. Periksa koneksi internet Anda lalu coba lagi."
			});
		} else if (err && err.name === "TypeError") {
			onDone({
				ok: false,
				message: "Tidak dapat terhubung ke AI Studio. Periksa koneksi internet Anda."
			});
		} else {
			onDone({
				ok: false,
				message: `Terjadi kendala saat streaming AI: ${err?.message || "Unknown error"}`
			});
		}
	}
};
/**
* Generate questions directly from an uploaded document (PDF, Text, CSV, etc.)
*/
export const generateQuestionsFromDocument = async ({ file, instruction = "Buatkan butir soal kuis/ujian berkualitas tinggi dari materi dokumen ini", count = 5, typePreference = "2", difficulty = "Sedang", selectedModel = DEFAULT_AI_MODEL, customApiKey = null, onStatus = null }) => {
	const setStatus = (msg) => {
		if (typeof onStatus === "function") onStatus(msg);
	};
	if (!file) {
		return {
			ok: false,
			message: "Berkas materi belum dipilih."
		};
	}
	setStatus(`Membaca berkas "${file.name}"...`);
	const typeDescription = {
		"1": "Semua soal bertipe Essay / Isian Singkat (typeId: 1, sertakan kunci/contoh jawaban di correctAnswer).",
		"2": "Semua soal bertipe Pilihan Ganda (typeId: 2, sediakan 4 pilihan jawaban di options di mana tepat SATU bernilai isCorrect: true).",
		"3": "Semua soal bertipe Checkbox / Pilihan Majemuk (typeId: 3, sediakan 4-5 opsi di mana ada minimal 2 bernilai isCorrect: true).",
		"4": "Semua soal bertipe Tanggal & Waktu / Date Time (typeId: 4, correctAnswer diisi format ISO \"YYYY-MM-DD\" atau \"YYYY-MM-DDTHH:mm\").",
		"5": "Semua soal bertipe Benar / Salah (typeId: 5, correctAnswer diisi \"Benar\" atau \"Salah\").",
		"mixed": "Variasi campuran antara Pilihan Ganda (typeId: 2), Benar/Salah (typeId: 5), dan Essay (typeId: 1)."
	}[typePreference] || "Pilihan Ganda (typeId: 2)";
	const promptText = `${AI_GUARDRAIL}Berdasarkan berkas/dokumen materi terlampir, buatlah ${count} butir soal berkualitas tinggi dengan panduan berikut:
- **Instruksi Khusus Pengguna:** ${instruction || "Buat butir soal dari seluruh materi"}
- **Tingkat Kesulitan:** ${difficulty}
- **Bentuk Soal:** ${typeDescription}
- **Bahasa:** Gunakan bahasa yang SAMA dengan bahasa dokumen materi di atas untuk SELURUH output.

**FORMAT KELUARAN WAJIB (JSON ARRAY):**
Kembalikan HANYA array JSON valid tanpa teks atau penjelasan pembuka/penutup. Struktur objek per soal:
[
  {
    "question": "Teks pertanyaan lengkap",
    "typeId": 2,
    "isRequired": true,
    "isScorable": true,
    "points": 1,
    "correctAnswer": "Kunci jawaban untuk tipe 1/4 atau 'Benar'/'Salah' untuk tipe 5",
    "options": [
      { "optionText": "Pilihan A", "isCorrect": false },
      { "optionText": "Pilihan B", "isCorrect": true },
      { "optionText": "Pilihan C", "isCorrect": false },
      { "optionText": "Pilihan D", "isCorrect": false }
    ]
  }
]
Catatan:
- Untuk tipe 2 (Pilihan Ganda), pastikan tepat 1 opsi isCorrect: true.
- Untuk tipe 3 (Checkbox), minimal 2 opsi isCorrect: true.
- Untuk tipe 1, 4, 5, options boleh kosong [].
`.trim();
	return await executeWithApiKeyFailover(async (apiKey) => {
		try {
			const targetModel = normalizeAiModel(selectedModel);
			setStatus(`Menghubungkan ke ${targetModel} di Google AI Studio...`);
			const isPdfOrImage = file.type === "application/pdf" || file.type.startsWith("image/") || file.name.toLowerCase().endsWith(".pdf");
			const parts = [{ text: promptText }];
			if (isPdfOrImage) {
				const base64Data = await new Promise((resolve, reject) => {
					const reader = new FileReader();
					reader.onload = () => {
						const res = reader.result;
						const base64 = typeof res === "string" ? res.split(",")[1] : "";
						resolve(base64);
					};
					reader.onerror = reject;
					reader.readAsDataURL(file);
				});
				parts.push({ inlineData: {
					mimeType: file.type || "application/pdf",
					data: base64Data
				} });
			} else {
				const textContent = await new Promise((resolve, reject) => {
					const reader = new FileReader();
					reader.onload = () => resolve(reader.result || "");
					reader.onerror = reject;
					reader.readAsText(file);
				});
				parts.push({ text: `\n\n=== ISI DOKUMEN MATERI ("${file.name}") ===\n"""\n${String(textContent).slice(0, 1e5)}\n"""` });
			}
			const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:generateContent?key=${apiKey}`;
			const startTime = Date.now();
			setStatus(`AI (${targetModel}) sedang membaca materi & menyusun butir soal...`);
			const response = await fetch(endpoint, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					contents: [{ parts }],
					generationConfig: {
						responseMimeType: "application/json",
						temperature: .7
					}
				})
			});
			const elapsedSec = ((Date.now() - startTime) / 1e3).toFixed(1);
			if (!response.ok) {
				const errData = await response.json().catch(() => ({}));
				const errMsg = errData.error?.message || `HTTP ${response.status}`;
				if (response.status === 429) {
					return {
						ok: false,
						status: 429,
						message: `Batas rate limit model ${targetModel} tercapai. Coba lagi dalam beberapa saat.`
					};
				}
				if (response.status === 400 || response.status === 403) {
					return {
						ok: false,
						status: response.status,
						message: `API Key tidak valid atau akses ditolak. (${errMsg})`
					};
				}
				return {
					ok: false,
					status: response.status,
					message: `Gagal memanggil AI: ${errMsg}`
				};
			}
			setStatus(`Menerima hasil soal dari AI (${elapsedSec} detik). Memvalidasi struktur...`);
			const data = await response.json();
			const textResponse = data.candidates?.[0]?.content?.parts?.[0]?.text;
			if (!textResponse) {
				return {
					ok: false,
					message: "AI tidak mengembalikan hasil teks soal."
				};
			}
			let parsedQuestions;
			try {
				parsedQuestions = safeJsonParse(textResponse);
			} catch {
				return {
					ok: false,
					message: "Format data dari AI tidak valid."
				};
			}
			if (!Array.isArray(parsedQuestions) || parsedQuestions.length === 0) {
				return {
					ok: false,
					message: "Format data dari AI tidak menghasilkan daftar soal."
				};
			}
			const normalized = parsedQuestions.map((q, idx) => {
				const typeId = parseInt(q.typeId, 10) || 2;
				let options = Array.isArray(q.options) ? q.options : [];
				if ([2, 3].includes(typeId) && options.length === 0) {
					options = [
						{
							optionText: "Pilihan A",
							isCorrect: true
						},
						{
							optionText: "Pilihan B",
							isCorrect: false
						},
						{
							optionText: "Pilihan C",
							isCorrect: false
						},
						{
							optionText: "Pilihan D",
							isCorrect: false
						}
					];
				}
				return {
					_id: `q_doc_ai_${Date.now()}_${idx}`,
					id: null,
					question: String(q.question || `Pertanyaan ${idx + 1}`),
					typeId,
					isRequired: q.isRequired !== undefined ? Boolean(q.isRequired) : true,
					isScorable: q.isScorable !== undefined ? Boolean(q.isScorable) : true,
					points: q.points != null ? Number(q.points) : 1,
					correctAnswer: q.correctAnswer ? String(q.correctAnswer) : "",
					options: options.map((opt, oIdx) => ({
						optionText: String(opt.optionText || opt.text || `Pilihan ${String.fromCharCode(65 + oIdx)}`),
						isCorrect: Boolean(opt.isCorrect)
					})),
					questionImage: null,
					questionAudio: null
				};
			});
			setStatus(`Selesai! Berhasil membuat ${normalized.length} butir soal dari "${file.name}".`);
			return {
				ok: true,
				data: normalized,
				fileName: file.name,
				modelUsed: targetModel,
				elapsedSec
			};
		} catch (err) {
			return {
				ok: false,
				message: `Terjadi kendala saat membaca materi atau memproses AI: ${err?.message || "Unknown error"}`
			};
		}
	}, customApiKey);
};
/**
* Helper to download structured questions as a standard CSV template for re-import
*/
export const exportQuestionsToCSV = (questions, title = "template-soal-ai") => {
	if (!questions || questions.length === 0) return;
	const rows = [[
		"question",
		"type_id",
		"order",
		"is_required",
		"correct_answer",
		"options"
	]];
	questions.forEach((q, i) => {
		const isChoice = q.typeId === 2 || q.typeId === 3;
		const optionsStr = (q.options || []).map((o) => o.isCorrect ? `[BENAR] ${o.optionText}` : o.optionText).join("|");
		const cleanQ = (q.question || "").replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
		const correctCa = isChoice ? (q.options || []).filter((o) => o.isCorrect).map((o) => o.optionText).join(",") : q.correctAnswer || "";
		rows.push([
			`"${cleanQ.replace(/"/g, "\"\"")}"`,
			q.typeId || 2,
			i + 1,
			q.isRequired ? "true" : "false",
			`"${(correctCa || "").replace(/"/g, "\"\"")}"`,
			`"${optionsStr.replace(/"/g, "\"\"")}"`
		]);
	});
	const csv = "﻿" + rows.map((r) => r.join(",")).join("\r\n");
	const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = `${title.replace(/\s+/g, "_")}-${Date.now()}.csv`;
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	URL.revokeObjectURL(url);
};
/**
* Extract text content or transcript from a given URL (Web Article or YouTube Video)
*/
export const extractContentFromUrl = async (url, onStatus = null) => {
	const setStatus = (msg) => {
		if (typeof onStatus === "function") onStatus(msg);
	};
	if (!url || typeof url !== "string") return {
		ok: false,
		message: "URL tidak valid"
	};
	const trimmedUrl = url.trim();
	setStatus(`Membaca URL: ${trimmedUrl}...`);
	// 1. YouTube URL detection
	const ytMatch = trimmedUrl.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|v\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i);
	if (ytMatch && ytMatch[1]) {
		const videoId = ytMatch[1];
		setStatus(`Mendeteksi video YouTube (ID: ${videoId}). Mengambil judul & transkrip...`);
		try {
			// Attempt to fetch oEmbed metadata for title
			let videoTitle = `YouTube Video (${videoId})`;
			try {
				const oembedRes = await fetch(`https://noembed.com/embed?url=https://www.youtube.com/watch?v=${videoId}`);
				if (oembedRes.ok) {
					const meta = await oembedRes.json();
					if (meta.title) videoTitle = meta.title;
				}
			} catch {}
			// Attempt public timedtext / subtitles extraction via corsproxy
			let transcriptText = "";
			try {
				const subRes = await fetch(`https://corsproxy.io/?${encodeURIComponent(`https://www.youtube.com/watch?v=${videoId}`)}`);
				if (subRes.ok) {
					const html = await subRes.text();
					// Extract captions JSON from initial player response if available
					const captionMatch = html.match(/"captionTracks":\s*(\[[^\]]+\])/);
					if (captionMatch && captionMatch[1]) {
						const tracks = JSON.parse(captionMatch[1]);
						const trackUrl = tracks[0]?.baseUrl;
						if (trackUrl) {
							const trackRes = await fetch(`https://corsproxy.io/?${encodeURIComponent(trackUrl)}`);
							if (trackRes.ok) {
								const xmlText = await trackRes.text();
								transcriptText = xmlText.replace(/<text[^>]*>/g, " ").replace(/<\/text>/g, "\n").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&quot;/g, "\"").replace(/\s+/g, " ").trim();
							}
						}
					}
				}
			} catch {}
			if (!transcriptText) {
				// Fallback video summary payload
				transcriptText = `Video YouTube: "${videoTitle}". URL: https://youtu.be/${videoId}. Silakan analisis materi dan buat soal sesuai topik/judul video ini.`;
			}
			return {
				ok: true,
				type: "youtube",
				title: videoTitle,
				videoId,
				content: transcriptText.slice(0, 5e4),
				url: trimmedUrl
			};
		} catch (err) {
			return {
				ok: true,
				type: "youtube",
				title: `Video YouTube (${videoId})`,
				videoId,
				content: `Video YouTube: https://youtu.be/${videoId}`,
				url: trimmedUrl
			};
		}
	}
	// 2. Standard Webpage Article extraction
	try {
		setStatus(`Mengambil teks artikel dari webpage...`);
		let html = "";
		try {
			const resp = await fetch(`https://corsproxy.io/?${encodeURIComponent(trimmedUrl)}`);
			if (resp.ok) {
				html = await resp.text();
			}
		} catch {}
		if (!html) {
			const directResp = await fetch(trimmedUrl, { mode: "cors" }).catch(() => null);
			if (directResp && directResp.ok) {
				html = await directResp.text();
			}
		}
		if (!html) {
			return {
				ok: false,
				message: "Tidak dapat mengambil konten halaman web. Pastikan URL dapat diakses publik."
			};
		}
		// Clean HTML to pure article text
		const parser = new DOMParser();
		const doc = parser.parseFromString(html, "text/html");
		// Remove script, style, nav, footer tags
		doc.querySelectorAll("script, style, nav, footer, header, noscript, iframe, svg, [role=\"navigation\"]").forEach((el) => el.remove());
		const pageTitle = doc.querySelector("title")?.innerText || doc.querySelector("h1")?.innerText || trimmedUrl;
		// Extract paragraph texts
		const paragraphs = Array.from(doc.querySelectorAll("article, main, p, h1, h2, h3, h4, li")).map((el) => el.innerText.trim()).filter((t) => t.length > 20);
		const fullText = paragraphs.join("\n\n").slice(0, 6e4);
		if (!fullText || fullText.length < 50) {
			return {
				ok: false,
				message: "Teks artikel pada halaman web tersebut terlalu singkat atau tidak dapat diekstrak."
			};
		}
		return {
			ok: true,
			type: "webpage",
			title: pageTitle.trim(),
			content: fullText,
			url: trimmedUrl
		};
	} catch (err) {
		return {
			ok: false,
			message: `Gagal membaca URL: ${err.message}`
		};
	}
};
/**
* Generate remedial explanation & self-check practice questions for "Pelajari Soal" feature
*/
export const generateRemedialExplanation = async ({ questionText, questionType = 2, userAnswer = "", correctAnswer = "", options = [], selectedModel = DEFAULT_AI_MODEL, customApiKey = null }) => {
	return await executeWithApiKeyFailover(async (apiKey) => {
		const typeLabelMap = {
			1: "Essay",
			2: "Pilihan Ganda",
			3: "Checkbox",
			4: "Tanggal",
			5: "Benar/Salah"
		};
		const qTypeName = typeLabelMap[questionType] || "Pilihan Ganda";
		const promptText = `
Anda adalah Guru & Tutor Pendamping Cerdas yang ramah, memotivasi, dan solutif.
Siswa baru saja mengerjakan soal kuis dan ingin mempelajari letak kesalahan serta konsep dasar materinya secara mendalam.

=== DATA SOAL KUIS ===
- Bentuk Soal: ${qTypeName}
- Pertanyaan: "${questionText}"
- Pilihan Opsi yang Tersedia: ${options.map((o, i) => `${String.fromCharCode(65 + i)}. ${o.optionText}`).join(" | ") || "-"}
- Jawaban yang Dipilih Siswa: "${userAnswer || "(Tidak dijawab / Kosong)"}"
- Jawaban yang Benar / Kunci: "${correctAnswer}"

TUGAS ANDA:
1. Jelaskan secara ramah, ringkas, dan jelas mengapa jawaban siswa salah (jika salah) dan mengapa jawaban kunci adalah jawaban yang tepat.
2. Tuliskan 2-3 poin ringkas materi/rumus kunci yang harus diingat siswa.
3. Buat 1 BUTIR SOAL LATIHAN SEJENIS (Pilihan Ganda 4 opsi) lengkap dengan kunci jawaban dan pembahasannya agar siswa dapat langsung menguji pemahamannya secara mandiri.

**FORMAT KELUARAN WAJIB (JSON VALID):**
{
  "explanation": "Penjelasan ramah dan terstruktur (bisa gunakan Markdown bullet/bold/LaTeX jika ada rumus)",
  "keyTakeaways": [
    "Poin kunci 1",
    "Poin kunci 2"
  ],
  "practiceQuestion": {
    "question": "Teks soal latihan serupa untuk menguji pemahaman",
    "options": [
      { "optionText": "Pilihan A", "isCorrect": false },
      { "optionText": "Pilihan B", "isCorrect": true },
      { "optionText": "Pilihan C", "isCorrect": false },
      { "optionText": "Pilihan D", "isCorrect": false }
    ],
    "explanation": "Pembahasan singkat untuk soal latihan ini"
  }
}
`.trim();
		const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${selectedModel}:generateContent?key=${apiKey}`;
		const response = await fetch(endpoint, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				contents: [{ parts: [{ text: promptText }] }],
				generationConfig: {
					responseMimeType: "application/json",
					temperature: .6
				}
			})
		});
		if (!response.ok) {
			const errData = await response.json().catch(() => ({}));
			const errMsg = errData.error?.message || `HTTP ${response.status}`;
			return {
				ok: false,
				status: response.status,
				message: errMsg
			};
		}
		const data = await response.json();
		const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
		if (!rawText) return {
			ok: false,
			message: "AI tidak mengembalikan hasil."
		};
		const parsed = safeJsonParse(rawText);
		if (!parsed || !parsed.explanation) {
			return {
				ok: false,
				message: "Format respons tutor AI tidak valid."
			};
		}
		return {
			ok: true,
			data: parsed,
			modelUsed: selectedModel
		};
	}, customApiKey);
};
/**
* Revise a single question using Gemini API with failover
*/
export const reviseQuestionWithAI = async ({ question, options = [], correctAnswer = "", typeId = 2, isRequired = true, isScorable = true, instruction, selectedModel = DEFAULT_AI_MODEL, customApiKey = null }) => {
	return await executeWithApiKeyFailover(async (apiKey) => {
		const cleanQ = (question || "").replace(/<[^>]*>/g, "").trim();
		const optionsText = options.map((o, i) => `${String.fromCharCode(65 + i)}. ${o.optionText}${o.isCorrect ? " (jawaban benar)" : ""}`).join("\n");
		const prompt = `Anda adalah asisten penyusun soal ujian. Revisi soal berikut sesuai instruksi.

Soal asli:
${cleanQ}

Pilihan jawaban:
${optionsText || "(tidak ada opsi)"}

Kunci jawaban: ${correctAnswer || ""}

Instruksi revisi: ${instruction.trim()}

Kembalikan HANYA JSON valid (satu objek, bukan array) dengan struktur:
{
  "question": "teks soal yang direvisi",
  "typeId": ${typeId},
  "isRequired": ${isRequired},
  "isScorable": ${isScorable},
  "correctAnswer": "kunci jawaban",
  "options": [{"optionText":"...", "isCorrect": false}]
}`;
		const targetModel = normalizeAiModel(selectedModel);
		const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:generateContent?key=${apiKey}`;
		const resp = await fetch(endpoint, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				contents: [{ parts: [{ text: prompt }] }],
				generationConfig: {
					responseMimeType: "application/json",
					temperature: .7
				}
			})
		});
		if (!resp.ok) {
			const errData = await resp.json().catch(() => ({}));
			const errMsg = errData.error?.message || `HTTP ${resp.status}`;
			return {
				ok: false,
				status: resp.status,
				message: errMsg
			};
		}
		const data = await resp.json();
		let textRes = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
		textRes = textRes.trim().replace(/^```json\s*/, "").replace(/\s*```$/, "").replace(/^```\s*/, "");
		const revised = JSON.parse(textRes);
		return {
			ok: true,
			data: revised
		};
	}, customApiKey);
};
/**
* Bulk revise multiple questions using Gemini API with failover
*/
export const bulkReviseQuestionsWithAI = async ({ questions = [], selectedIndices = [], instruction, selectedModel = DEFAULT_AI_MODEL, customApiKey = null }) => {
	return await executeWithApiKeyFailover(async (apiKey) => {
		const targetModel = normalizeAiModel(selectedModel);
		const results = [];
		let anySuccess = false;
		for (const idx of selectedIndices) {
			const q = questions[idx];
			if (!q) continue;
			try {
				const cleanQ = (q.question || "").replace(/<[^>]*>/g, "").trim();
				const optionsText = (q.options || []).map((o, i) => `${String.fromCharCode(65 + i)}. ${o.optionText}${o.isCorrect ? " (jawaban benar)" : ""}`).join("\n");
				const prompt = `Revisi soal berikut sesuai instruksi. Kembalikan HANYA JSON valid.\n\nSoal: ${cleanQ}\nOpsi:\n${optionsText || "(tidak ada)"}\nKunci: ${q.correctAnswer || ""}\n\nInstruksi: ${instruction.trim()}\n\nJSON output:\n{"question":"...","typeId":${q.typeId},"isRequired":${q.isRequired},"isScorable":${q.isScorable},"correctAnswer":"...","options":[{"optionText":"...","isCorrect":false}]}`;
				const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:generateContent?key=${apiKey}`;
				const resp = await fetch(endpoint, {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({
						contents: [{ parts: [{ text: prompt }] }],
						generationConfig: {
							responseMimeType: "application/json",
							temperature: .7
						}
					})
				});
				if (!resp.ok) {
					if (resp.status === 429 || resp.status === 400 || resp.status === 403) {
						return {
							ok: false,
							status: resp.status,
							message: `HTTP ${resp.status}`
						};
					}
					continue;
				}
				const data = await resp.json();
				let textRes = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
				textRes = textRes.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
				// Gemini can occasionally add a short sentence around the JSON.
				// Extract the object so one malformed wrapper does not drop a
				// selected question from the bulk result.
				const jsonStart = textRes.indexOf("{");
				const jsonEnd = textRes.lastIndexOf("}");
				if (jsonStart >= 0 && jsonEnd > jsonStart) textRes = textRes.slice(jsonStart, jsonEnd + 1);
				const revised = safeJsonParse(textRes);
				if (!revised || !revised.question) throw new Error("Format JSON revisi tidak valid");
				results.push({
					idx,
					original: q,
					revised
				});
				anySuccess = true;
			} catch (err) {
				console.error(`Error revising question ${idx}:`, err);
			}
		}
		if (!anySuccess && selectedIndices.length > 0) {
			return {
				ok: false,
				message: "Tidak ada soal yang berhasil direvisi oleh AI."
			};
		}
		return {
			ok: true,
			data: results
		};
	}, customApiKey);
};
/**
* AI Analytics & Educational Insights
*/
export const analyzeFormAnalyticsWithAI = async ({ summary, selectedModel = DEFAULT_AI_MODEL, customApiKey = null }) => {
	return await executeWithApiKeyFailover(async (apiKey) => {
		const promptText = `Anda adalah analis pendidikan profesional. Berdasarkan data hasil ujian berikut, berikan analisis mendalam dan rekomendasi perbaikan dalam bahasa Indonesia yang jelas dan mudah dipahami guru.

${summary}

Berikan analisis yang mencakup:
1. Identifikasi soal-soal bermasalah (terlalu sulit/mudah) dan saran perbaikannya
2. Interpretasi distribusi nilai dan apa artinya bagi kualitas pembelajaran
3. Rekomendasi konkret untuk meningkatkan hasil belajar
4. Kesimpulan umum tentang kualitas soal dan pemahaman siswa

Format respons dalam paragraf yang terstruktur, maksimal 400 kata.`;
		const targetModel = normalizeAiModel(selectedModel);
		const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:generateContent?key=${apiKey}`;
		const resp = await fetch(endpoint, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				contents: [{ parts: [{ text: promptText }] }],
				generationConfig: { temperature: .5 }
			})
		});
		if (!resp.ok) {
			const errData = await resp.json().catch(() => ({}));
			const errMsg = errData.error?.message || `HTTP ${resp.status}`;
			return {
				ok: false,
				status: resp.status,
				message: errMsg
			};
		}
		const data = await resp.json();
		const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
		return {
			ok: true,
			data: text.trim()
		};
	}, customApiKey);
};
/**
* AI Holistic Essay Scoring
*/
export const scoreHolisticEssayWithAI = async ({ essayAnswers = [], pgSection = "", selectedModel = DEFAULT_AI_MODEL, customApiKey = null }) => {
	return await executeWithApiKeyFailover(async (apiKey) => {
		const essaySection = essayAnswers.map((a, i) => {
			const text = a.answerText || a.answerValue || "(kosong)";
			const key = a.correctAnswer || "(tidak ada kunci)";
			const q = (a.question || "").replace(/<[^>]*>/g, "").substring(0, 200);
			const aId = a.answerId || a.id;
			return `Essay #${i + 1} (answerId: ${aId}):\nPertanyaan: ${q}\nKunci: ${key}\nJawaban: ${text}`;
		}).join("\n\n");
		const prompt = `Anda adalah penilai ujian. Nilai SEMUA soal essay dari satu responden sekaligus secara holistik, dengan mempertimbangkan konteks keseluruhan performa responden.
${pgSection}

Data Essay:
${essaySection}

Kembalikan JSON array — satu objek per essay, HARUS berurutan sesuai Essay #1, #2, dst:
[
  {"answerId": <answerId integer dari data essay>, "score": 85, "isCorrect": true, "reason": "Alasan singkat 1 kalimat"}
]

Panduan penilaian:
- Nilai berdasarkan kesamaan makna/konsep, bukan kata per kata
- isCorrect: true jika score >= 70
- Pertimbangkan konteks: jika PG bagus, cenderung paham materi
- Score: 0-100`;
		const targetModel = normalizeAiModel(selectedModel);
		const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:generateContent?key=${apiKey}`;
		const resp = await fetch(endpoint, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				contents: [{ parts: [{ text: prompt }] }],
				generationConfig: {
					responseMimeType: "application/json",
					temperature: .3
				}
			})
		});
		if (!resp.ok) {
			const errData = await resp.json().catch(() => ({}));
			const errMsg = errData.error?.message || `HTTP ${resp.status}`;
			return {
				ok: false,
				status: resp.status,
				message: errMsg
			};
		}
		const data = await resp.json();
		let textRes = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
		textRes = textRes.trim().replace(/^```json\s*/, "").replace(/\s*```$/, "").replace(/^```\s*/, "");
		const suggestions = JSON.parse(textRes);
		return {
			ok: true,
			data: suggestions
		};
	}, customApiKey);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sTUFBTSxtQkFBbUIsQ0FDNUI7Q0FDSSxJQUFJO0NBQ0osTUFBTTtDQUNOLE1BQU07Q0FDTixPQUFPO0FBQ1gsR0FDQTtDQUNJLElBQUk7Q0FDSixNQUFNO0NBQ04sTUFBTTtDQUNOLE9BQU87QUFDWCxDQUNKO0FBRUEsT0FBTyxNQUFNLG1CQUFtQjtBQUNoQyxPQUFPLE1BQU0sb0JBQW9CLFVBQVU7Q0FDdkMsSUFBSSxDQUFDLFNBQVMsTUFBTSxTQUFTLE1BQU0sS0FBSyxVQUFVLDRCQUE0QixDQUFDLGlCQUFpQixNQUFLLFNBQVEsS0FBSyxPQUFPLEtBQUssR0FBRyxPQUFPO0NBQ3hJLE9BQU87QUFDWDs7OztBQUtBLE9BQU8sTUFBTSx5QkFBeUI7Q0FDbEMsSUFBSSxPQUFPLFdBQVcsYUFBYTtFQUMvQixJQUFJO0dBQ0EsTUFBTSxNQUFNLGFBQWEsUUFBUSx3QkFBd0I7R0FDekQsSUFBSSxLQUFLO0lBQ0wsTUFBTSxTQUFTLEtBQUssTUFBTSxHQUFHO0lBQzdCLElBQUksTUFBTSxRQUFRLE1BQU0sS0FBSyxPQUFPLFNBQVMsR0FBRztLQUM1QyxPQUFPLE9BQU8sS0FBSSxNQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU87SUFDM0Q7R0FDSjtFQUNKLFFBQVEsQ0FBQztFQUNULE1BQU0sU0FBUyxhQUFhLFFBQVEsdUJBQXVCO0VBQzNELElBQUksVUFBVSxPQUFPLEtBQUssR0FBRztHQUN6QixPQUFPLENBQUMsT0FBTyxLQUFLLENBQUM7RUFDekI7Q0FDSjtDQUNBLE9BQU8sQ0FBQztBQUNaO0FBRUEsT0FBTyxNQUFNLHFCQUFxQixjQUFjO0NBQzVDLElBQUksT0FBTyxXQUFXLGFBQWE7RUFDL0IsSUFBSSxZQUFZLENBQUM7RUFDakIsSUFBSSxNQUFNLFFBQVEsU0FBUyxHQUFHO0dBQzFCLFlBQVksVUFBVSxLQUFJLE1BQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTztFQUNuRSxPQUFPLElBQUksT0FBTyxjQUFjLFVBQVU7R0FDdEMsWUFBWSxVQUNQLE1BQU0sU0FBUyxDQUFDLENBQ2hCLEtBQUksTUFBSyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQ2xCLE9BQU8sT0FBTztFQUN2Qjs7RUFFQSxZQUFZLE1BQU0sS0FBSyxJQUFJLElBQUksU0FBUyxDQUFDO0VBRXpDLElBQUksVUFBVSxXQUFXLEdBQUc7R0FDeEIsYUFBYSxXQUFXLHdCQUF3QjtHQUNoRCxhQUFhLFdBQVcsdUJBQXVCO0dBQy9DLGFBQWEsV0FBVyw4QkFBOEI7RUFDMUQsT0FBTztHQUNILGFBQWEsUUFBUSwwQkFBMEIsS0FBSyxVQUFVLFNBQVMsQ0FBQztHQUN4RSxhQUFhLFFBQVEseUJBQXlCLFVBQVUsRUFBRTtHQUMxRCxNQUFNLFNBQVMsU0FBUyxhQUFhLFFBQVEsOEJBQThCLEtBQUssS0FBSyxFQUFFO0dBQ3ZGLElBQUksVUFBVSxVQUFVLFFBQVE7SUFDNUIsYUFBYSxRQUFRLGdDQUFnQyxHQUFHO0dBQzVEO0VBQ0o7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxPQUFPLENBQUM7QUFDWjtBQUVBLE9BQU8sTUFBTSw2QkFBNkI7Q0FDdEMsSUFBSSxPQUFPLFdBQVcsYUFBYTtFQUMvQixNQUFNLE1BQU0sU0FBUyxhQUFhLFFBQVEsOEJBQThCLEtBQUssS0FBSyxFQUFFO0VBQ3BGLE1BQU0sT0FBTyxpQkFBaUI7RUFDOUIsSUFBSSxPQUFPLEtBQUssTUFBTSxLQUFLLFFBQVEsT0FBTztDQUM5QztDQUNBLE9BQU87QUFDWDtBQUVBLE9BQU8sTUFBTSwyQkFBMkI7Q0FDcEMsSUFBSSxPQUFPLFdBQVcsYUFBYTtFQUMvQixNQUFNLE9BQU8saUJBQWlCO0VBQzlCLElBQUksS0FBSyxVQUFVLEdBQUcsT0FBTztHQUFFLE9BQU87R0FBRyxLQUFLLEtBQUssTUFBTTtHQUFJLE9BQU8sS0FBSztHQUFRLFNBQVM7RUFBTTtFQUNoRyxNQUFNLFNBQVMscUJBQXFCO0VBQ3BDLE1BQU0sV0FBVyxTQUFTLEtBQUssS0FBSztFQUNwQyxhQUFhLFFBQVEsZ0NBQWdDLE9BQU8sT0FBTyxDQUFDO0VBQ3BFLGFBQWEsUUFBUSx5QkFBeUIsS0FBSyxRQUFRO0VBQzNELE9BQU87R0FBRSxPQUFPO0dBQVMsS0FBSyxLQUFLO0dBQVUsT0FBTyxLQUFLO0dBQVEsU0FBUztFQUFLO0NBQ25GO0NBQ0EsT0FBTztFQUFFLE9BQU87RUFBRyxLQUFLO0VBQUksT0FBTztFQUFHLFNBQVM7Q0FBTTtBQUN6RDtBQUVBLE9BQU8sTUFBTSx3QkFBd0I7Q0FDakMsTUFBTSxPQUFPLGlCQUFpQjtDQUM5QixJQUFJLEtBQUssV0FBVyxHQUFHLE9BQU87Q0FDOUIsTUFBTSxNQUFNLHFCQUFxQjtDQUNqQyxPQUFPLEtBQUssUUFBUSxLQUFLLE1BQU07QUFDbkM7QUFFQSxPQUFPLE1BQU0sb0JBQW9CLFFBQVE7Q0FDckMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssR0FBRztFQUNyQixrQkFBa0IsQ0FBQyxDQUFDO0NBQ3hCLE9BQU87RUFDSCxNQUFNLFdBQVcsaUJBQWlCO0VBQ2xDLElBQUksQ0FBQyxTQUFTLFNBQVMsSUFBSSxLQUFLLENBQUMsR0FBRztHQUNoQyxrQkFBa0IsQ0FBQyxJQUFJLEtBQUssR0FBRyxHQUFHLFFBQVEsQ0FBQztFQUMvQztDQUNKO0FBQ0o7QUFFQSxPQUFPLE1BQU0sMkJBQTJCO0NBQ3BDLGtCQUFrQixDQUFDLENBQUM7QUFDeEI7Ozs7QUFLQSxPQUFPLE1BQU0sNEJBQTRCLE9BQU8sV0FBVyxlQUFlLFNBQVM7Q0FDL0UsSUFBSSxnQkFBZ0IsYUFBYSxLQUFLLEdBQUc7RUFDckMsT0FBTyxNQUFNLFVBQVUsYUFBYSxLQUFLLEdBQUcsR0FBRyxDQUFDO0NBQ3BEO0NBRUEsTUFBTSxPQUFPLGlCQUFpQjtDQUM5QixJQUFJLEtBQUssV0FBVyxHQUFHO0VBQ25CLE9BQU87R0FBRSxJQUFJO0dBQU8sU0FBUztFQUF1RTtDQUN4RztDQUVBLElBQUksV0FBVyxxQkFBcUI7Q0FDcEMsSUFBSSxXQUFXO0NBQ2YsTUFBTSxjQUFjLEtBQUs7Q0FFekIsT0FBTyxXQUFXLGFBQWE7RUFDM0IsTUFBTSxjQUFjLFdBQVcsWUFBWSxLQUFLO0VBQ2hELE1BQU0sYUFBYSxLQUFLO0VBRXhCLElBQUk7R0FDQSxNQUFNLFNBQVMsTUFBTSxVQUFVLFlBQVksWUFBWSxLQUFLLE1BQU07O0dBR2xFLElBQUksVUFBVSxPQUFPLFdBQVcsT0FBTyxXQUFXLE9BQU8sT0FBTyxXQUFXLE9BQU8sT0FBTyxXQUFXLE1BQU07SUFDdEcsSUFBSSxLQUFLLFNBQVMsS0FBSyxXQUFXLElBQUksYUFBYTtLQUMvQyxRQUFRLEtBQUssNEJBQTRCLGFBQWEsRUFBRSxjQUFjLE9BQU8sT0FBTyxvQ0FBb0M7S0FDeEgsbUJBQW1CO0tBQ25CO0tBQ0E7SUFDSjtHQUNKOztHQUdBLElBQUksVUFBVSxPQUFPLElBQUk7SUFDckIsSUFBSSxxQkFBcUIsTUFBTSxZQUFZO0tBQ3ZDLGFBQWEsUUFBUSxnQ0FBZ0MsT0FBTyxVQUFVLENBQUM7S0FDdkUsYUFBYSxRQUFRLHlCQUF5QixVQUFVO0lBQzVEO0dBQ0o7R0FFQSxPQUFPO0VBQ1gsU0FBUyxLQUFLO0dBQ1YsTUFBTSxvQkFBb0IsS0FBSyxZQUMzQixJQUFJLFFBQVEsU0FBUyxLQUFLLEtBQzFCLElBQUksUUFBUSxTQUFTLG9CQUFvQixLQUN6QyxJQUFJLFFBQVEsU0FBUyxpQkFBaUIsS0FDdEMsSUFBSSxRQUFRLFNBQVMsS0FBSyxLQUMxQixJQUFJLFFBQVEsU0FBUyxPQUFPO0dBR2hDLElBQUkscUJBQXFCLEtBQUssU0FBUyxLQUFLLFdBQVcsSUFBSSxhQUFhO0lBQ3BFLFFBQVEsS0FBSyx5Q0FBeUMsYUFBYSxFQUFFLGlDQUFpQyxHQUFHO0lBQ3pHLG1CQUFtQjtJQUNuQjtJQUNBO0dBQ0o7R0FDQSxNQUFNO0VBQ1Y7Q0FDSjtDQUVBLE9BQU87RUFDSCxJQUFJO0VBQ0osU0FBUyxXQUFXLEtBQUssT0FBTztDQUNwQztBQUNKOztBQUdBLE1BQU0sZUFBZTs7Ozs7Ozs7O0FBVXJCLE9BQU8sTUFBTSxpQkFBaUIsV0FBVztDQUNyQyxJQUFJLENBQUMsUUFBUSxPQUFPO0NBQ3BCLElBQUksVUFBVSxPQUFPLEtBQUssQ0FBQyxDQUN0QixRQUFRLGdCQUFnQixFQUFFLENBQUMsQ0FDM0IsUUFBUSxZQUFZLEVBQUUsQ0FBQyxDQUN2QixRQUFRLFlBQVksRUFBRSxDQUFDLENBQ3ZCLEtBQUs7Q0FFVixJQUFJO0VBQ0EsT0FBTyxLQUFLLE1BQU0sT0FBTztDQUM3QixTQUFTLElBQUk7RUFDVCxJQUFJOztHQUVBLE1BQU0sV0FBVyxRQUFRLFFBQVEseUNBQXlDLFFBQVE7R0FDbEYsT0FBTyxLQUFLLE1BQU0sUUFBUTtFQUM5QixRQUFRO0dBQ0osTUFBTSxZQUFZLFFBQVEsTUFBTSwyQkFBMkI7R0FDM0QsSUFBSSxXQUFXO0lBQ1gsTUFBTSxXQUFXLFVBQVUsRUFBRSxDQUFDLFFBQVEseUNBQXlDLFFBQVE7SUFDdkYsT0FBTyxLQUFLLE1BQU0sUUFBUTtHQUM5QjtHQUNBLE1BQU07RUFDVjtDQUNKO0FBQ0o7Ozs7QUFLQSxPQUFPLE1BQU0sMEJBQTBCLE9BQU8sRUFDMUMsT0FDQSxjQUFjLElBQ2QsUUFBUSxHQUNSLGlCQUFpQixLQUNqQixhQUFhLFVBQ2IsY0FBYyxPQUNkLGNBQWMsT0FDZCxnQkFBZ0Isa0JBQ2hCLGVBQWUsTUFDZixXQUFXLFdBQ1Q7Q0FDRixNQUFNLGFBQWEsUUFBUTtFQUN2QixJQUFJLE9BQU8sYUFBYSxZQUFZLFNBQVMsR0FBRztDQUNwRDtDQUVBLFVBQVUsMkJBQTJCLE1BQU0sc0JBQXNCLE1BQU0sS0FBSztDQUU1RSxNQUFNLGtCQUFrQjtFQUNwQixLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsU0FBUztDQUNiLEVBQUUsbUJBQW1CO0NBRXJCLElBQUksb0JBQW9CLENBQUM7Q0FDekIsSUFBSSxhQUFhO0VBQ2Isa0JBQWtCLEtBQUssMEhBQTBIO0NBQ3JKO0NBQ0EsSUFBSSxhQUFhO0VBQ2Isa0JBQWtCLEtBQUssbUZBQW1GO0NBQzlHO0NBQ0EsSUFBSSxlQUFlLFlBQVksS0FBSyxHQUFHO0VBQ25DLGtCQUFrQixLQUFLLCtEQUErRCxZQUFZLEtBQUssRUFBRSxNQUFNO0NBQ25IOztDQUdBLE1BQU0sYUFBYSxHQUFHLGFBQWEsVUFBVSxNQUFNOzt3QkFFL0IsU0FBUyxtQkFBbUI7MkJBQ3pCLFdBQVc7cUJBQ2pCLGdCQUFnQjs7RUFFbkMsa0JBQWtCLFNBQVMsSUFBSSw4QkFBOEIsa0JBQWtCLEtBQUssTUFBTSxNQUFNLEdBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBdUJuRyxLQUFLO0NBRUgsT0FBTyxNQUFNLDBCQUEwQixPQUFPLFdBQVc7RUFDckQsSUFBSTtHQUNBLE1BQU0sY0FBYyxpQkFBaUIsYUFBYTtHQUNsRCxVQUFVLG9CQUFvQixZQUFZLHdCQUF3QjtHQUVsRSxNQUFNLFdBQVcsMkRBQTJELFlBQVksdUJBQXVCO0dBRS9HLE1BQU0sWUFBWSxLQUFLLElBQUk7R0FDM0IsVUFBVSxPQUFPLFlBQVksMkNBQTJDO0dBRXhFLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtHQUN2QyxNQUFNLFlBQVksaUJBQWlCLFdBQVcsTUFBTSxHQUFHLEdBQUs7R0FDNUQsTUFBTSxXQUFXLE1BQU0sTUFBTSxVQUFVO0lBQ25DLFFBQVE7SUFDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtJQUM5QyxRQUFRLFdBQVc7SUFDbkIsTUFBTSxLQUFLLFVBQVU7S0FDakIsVUFBVSxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUUsTUFBTSxXQUFXLENBQUMsRUFBRSxDQUFDO0tBQzVDLGtCQUFrQjtNQUNkLGtCQUFrQjtNQUNsQixhQUFhO0tBQ2pCO0lBQ0osQ0FBQztHQUNMLENBQUM7R0FDRCxhQUFhLFNBQVM7R0FFdEIsTUFBTSxlQUFlLEtBQUssSUFBSSxJQUFJLGFBQWEsSUFBSSxDQUFFLFFBQVEsQ0FBQztHQUU5RCxJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2QsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRTtJQUN0RCxNQUFNLFNBQVMsUUFBUSxPQUFPLFdBQVcsUUFBUSxTQUFTLE9BQU8sR0FBRyxTQUFTO0lBRTdFLElBQUksU0FBUyxXQUFXLEtBQUs7S0FDekIsT0FBTztNQUNILElBQUk7TUFDSixRQUFRO01BQ1IsU0FBUyw4REFBOEQsWUFBWTtLQUN2RjtJQUNKO0lBRUEsSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztLQUNwRCxPQUFPO01BQ0gsSUFBSTtNQUNKLFFBQVEsU0FBUztNQUNqQixTQUFTLGtFQUFrRSxPQUFPO0tBQ3RGO0lBQ0o7SUFFQSxJQUFJLFNBQVMsVUFBVSxLQUFLO0tBQ3hCLE9BQU87TUFDSCxJQUFJO01BQ0osUUFBUSxTQUFTO01BQ2pCLFNBQVMsaURBQWlELFNBQVMsT0FBTztLQUM5RTtJQUNKO0lBRUEsT0FBTztLQUNILElBQUk7S0FDSixRQUFRLFNBQVM7S0FDakIsU0FBUyx5QkFBeUIsWUFBWSxJQUFJLE9BQU87SUFDN0Q7R0FDSjtHQUVBLFVBQVUsMkJBQTJCLFdBQVcsb0NBQW9DO0dBRXBGLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztHQUNqQyxNQUFNLGVBQWUsS0FBSyxhQUFhLEVBQUUsRUFBRSxTQUFTLFFBQVEsRUFBRSxFQUFFO0dBRWhFLElBQUksQ0FBQyxjQUFjO0lBQ2YsT0FBTztLQUNILElBQUk7S0FDSixTQUFTO0lBQ2I7R0FDSjtHQUVBLElBQUk7R0FDSixJQUFJO0lBQ0Esa0JBQWtCLGNBQWMsWUFBWTtHQUNoRCxRQUFRO0lBQ0osT0FBTztLQUFFLElBQUk7S0FBTyxTQUFTO0lBQTRFO0dBQzdHO0dBRUEsSUFBSSxDQUFDLE1BQU0sUUFBUSxlQUFlLEtBQUssZ0JBQWdCLFdBQVcsR0FBRztJQUNqRSxPQUFPO0tBQ0gsSUFBSTtLQUNKLFNBQVM7SUFDYjtHQUNKOztHQUdBLE1BQU0sYUFBYSxnQkFBZ0IsS0FBSyxHQUFHLFFBQVE7SUFDL0MsTUFBTSxTQUFTLFNBQVMsRUFBRSxRQUFRLEVBQUUsS0FBSztJQUN6QyxJQUFJLFVBQVUsTUFBTSxRQUFRLEVBQUUsT0FBTyxJQUFJLEVBQUUsVUFBVSxDQUFDO0lBRXRELElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsTUFBTSxLQUFLLFFBQVEsV0FBVyxHQUFHO0tBQ2pELFVBQVU7TUFDTjtPQUFFLFlBQVk7T0FBYSxXQUFXO01BQUs7TUFDM0M7T0FBRSxZQUFZO09BQWEsV0FBVztNQUFNO01BQzVDO09BQUUsWUFBWTtPQUFhLFdBQVc7TUFBTTtNQUM1QztPQUFFLFlBQVk7T0FBYSxXQUFXO01BQU07S0FDaEQ7SUFDSjtJQUVBLE1BQU0sbUJBQW1CLFFBQVEsS0FBSyxLQUFLLFVBQVU7S0FDakQsWUFBWSxPQUFPLElBQUksY0FBYyxJQUFJLFFBQVEsV0FBVyxPQUFPLGFBQWEsS0FBSyxJQUFJLEdBQUc7S0FDNUYsV0FBVyxRQUFRLElBQUksU0FBUztJQUNwQyxFQUFFO0lBRUYsT0FBTztLQUNILEtBQUssUUFBUSxLQUFLLElBQUksRUFBRSxHQUFHO0tBQzNCLElBQUk7S0FDSixVQUFVLE9BQU8sRUFBRSxZQUFZLGNBQWMsTUFBTSxHQUFHO0tBQzlDO0tBQ1IsWUFBWSxFQUFFLGVBQWUsWUFBWSxRQUFRLEVBQUUsVUFBVSxJQUFJO0tBQ2pFLFlBQVksRUFBRSxlQUFlLFlBQVksUUFBUSxFQUFFLFVBQVUsSUFBSTtLQUNqRSxRQUFRO0tBQ1IsZUFBZSxFQUFFLGdCQUFnQixPQUFPLEVBQUUsYUFBYSxJQUFJO0tBQzNELFNBQVM7S0FDVCxlQUFlO0tBQ2YsZUFBZTtJQUNuQjtHQUNKLENBQUM7R0FFRCxVQUFVLFlBQVksV0FBVyxPQUFPLGtCQUFrQjtHQUUxRCxPQUFPO0lBQ0gsSUFBSTtJQUNKLE1BQU07SUFDTixXQUFXO0lBQ1g7R0FDSjtFQUNKLFNBQVMsS0FBSztHQUNWLElBQUksT0FBTyxJQUFJLFNBQVMsY0FBYztJQUNsQyxPQUFPO0tBQUUsSUFBSTtLQUFPLFNBQVM7SUFBOEU7R0FDL0c7R0FDQSxJQUFJLE9BQU8sSUFBSSxTQUFTLGVBQWUsSUFBSSxZQUFZLElBQUksUUFBUSxTQUFTLE9BQU8sS0FBSyxJQUFJLFFBQVEsU0FBUyxTQUFTLEtBQUssSUFBSSxRQUFRLFNBQVMsUUFBUSxLQUFLLElBQUksUUFBUSxTQUFTLGNBQWMsSUFBSTtJQUNoTSxPQUFPO0tBQUUsSUFBSTtLQUFPLFNBQVM7SUFBcUU7R0FDdEc7R0FDQSxJQUFJLGVBQWUsYUFBYTtJQUM1QixPQUFPO0tBQUUsSUFBSTtLQUFPLFNBQVM7SUFBNEU7R0FDN0c7R0FDQSxPQUFPO0lBQ0gsSUFBSTtJQUNKLFNBQVMsc0NBQXNDLEtBQUssV0FBVyxnQkFBZ0I7R0FDbkY7RUFDSjtDQUNKLEdBQUcsWUFBWTtBQUNuQjs7Ozs7Ozs7QUFTQSxPQUFPLE1BQU0sZ0NBQWdDLE9BQU8sRUFDaEQsT0FDQSxjQUFjLElBQ2QsUUFBUSxHQUNSLGlCQUFpQixLQUNqQixhQUFhLFVBQ2IsY0FBYyxPQUNkLGNBQWMsT0FDZCxnQkFBZ0Isa0JBQ2hCLGVBQWUsUUFDaEIsWUFBWSxVQUFVLFdBQVc7Q0FDaEMsTUFBTSxVQUFVLGdCQUFnQixnQkFBZ0IsRUFBQyxDQUFFLEtBQUs7Q0FDeEQsTUFBTSxhQUFhLFFBQVE7RUFBRSxJQUFJLE9BQU8sYUFBYSxZQUFZLFNBQVMsR0FBRztDQUFHO0NBRWhGLElBQUksQ0FBQyxRQUFRO0VBQ1QsT0FBTztHQUFFLElBQUk7R0FBTyxTQUFTO0VBQStCLENBQUM7RUFDN0Q7Q0FDSjtDQUVBLE1BQU0sa0JBQWtCO0VBQ3BCLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxTQUFTO0NBQ2IsRUFBRSxtQkFBbUI7Q0FFckIsSUFBSSxvQkFBb0IsQ0FBQztDQUN6QixJQUFJLGFBQWEsa0JBQWtCLEtBQUssMEhBQTBIO0NBQ2xLLElBQUksYUFBYSxrQkFBa0IsS0FBSyxtRkFBbUY7Q0FDM0gsSUFBSSxlQUFlLFlBQVksS0FBSyxHQUFHLGtCQUFrQixLQUFLLCtEQUErRCxZQUFZLEtBQUssRUFBRSxNQUFNO0NBRXRKLE1BQU0sYUFBYSxHQUFHLGFBQWEsVUFBVSxNQUFNO3dCQUMvQixTQUFTLG1CQUFtQjsyQkFDekIsV0FBVztxQkFDakIsZ0JBQWdCOztFQUVuQyxrQkFBa0IsU0FBUyxJQUFJLDhCQUE4QixrQkFBa0IsS0FBSyxNQUFNLE1BQU0sR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBa0JsRyxLQUFLO0NBRUksTUFBTSxjQUFjLGlCQUFpQixhQUFhO0NBQzFELE1BQU0sV0FBVywyREFBMkQsWUFBWSw2QkFBNkIsT0FBTztDQUM1SCxNQUFNLFlBQVksS0FBSyxJQUFJO0NBQzNCLFVBQVUsT0FBTyxZQUFZLDBCQUEwQjtDQUV2RCxJQUFJO0VBQ0EsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBQ3ZDLE1BQU0sWUFBWSxpQkFBaUIsV0FBVyxNQUFNLEdBQUcsR0FBSztFQUM1RCxNQUFNLFdBQVcsTUFBTSxNQUFNLFVBQVU7R0FDbkMsUUFBUTtHQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0dBQzlDLFFBQVEsV0FBVztHQUNuQixNQUFNLEtBQUssVUFBVTtJQUNqQixVQUFVLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRSxNQUFNLFdBQVcsQ0FBQyxFQUFFLENBQUM7SUFDNUMsa0JBQWtCLEVBQUUsYUFBYSxHQUFJO0dBQ3pDLENBQUM7RUFDTCxDQUFDO0VBQ0QsYUFBYSxTQUFTO0VBRXRCLElBQUksQ0FBQyxTQUFTLElBQUk7R0FDZCxNQUFNLFVBQVUsTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFO0dBQ3RELE1BQU0sU0FBUyxRQUFRLE9BQU8sV0FBVyxRQUFRLFNBQVM7R0FDMUQsSUFBSSxTQUFTLFdBQVcsS0FBSztJQUFFLE9BQU87S0FBRSxJQUFJO0tBQU8sU0FBUyxtQ0FBbUMsWUFBWTtJQUF5QyxDQUFDO0dBQUcsT0FDbkosSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztJQUFFLE9BQU87S0FBRSxJQUFJO0tBQU8sU0FBUyw0Q0FBNEMsT0FBTztJQUFHLENBQUM7R0FBRyxPQUNqSixJQUFJLFNBQVMsVUFBVSxLQUFLO0lBQUUsT0FBTztLQUFFLElBQUk7S0FBTyxTQUFTLDBDQUEwQyxTQUFTLE9BQU87SUFBcUIsQ0FBQztHQUFHLE9BQzlJO0lBQUUsT0FBTztLQUFFLElBQUk7S0FBTyxTQUFTLHVCQUF1QjtJQUFTLENBQUM7R0FBRztHQUN4RTtFQUNKO0VBRUEsTUFBTSxTQUFTLFNBQVMsS0FBSyxVQUFVO0VBQ3ZDLE1BQU0sVUFBVSxJQUFJLFlBQVk7RUFDaEMsSUFBSSxZQUFZO0VBQ2hCLElBQUksYUFBYTtFQUNqQixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLGVBQWU7RUFFbkIsTUFBTSx5QkFBeUI7R0FDM0IsSUFBSSxJQUFJLEdBQUcsUUFBUSxPQUFPLE1BQU0sT0FBTyxjQUFjLENBQUM7R0FDdEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsUUFBUSxLQUFLO0lBQ3hDLE1BQU0sS0FBSyxXQUFXO0lBQ3RCLElBQUksS0FBSztLQUFFLE1BQU07S0FBTztJQUFVO0lBQ2xDLElBQUksT0FBTyxRQUFRLE9BQU87S0FBRSxNQUFNO0tBQU07SUFBVTtJQUNsRCxJQUFJLE9BQU8sTUFBSztLQUFFLFFBQVEsQ0FBQztLQUFPO0lBQVU7SUFDNUMsSUFBSSxPQUFPO0lBQ1gsSUFBSSxPQUFPLEtBQUs7S0FBRSxJQUFJLE1BQU0sR0FBRyxjQUFjO0tBQUc7SUFBSyxPQUNoRCxJQUFJLE9BQU8sS0FBSztLQUNqQjtLQUNBLElBQUksTUFBTSxLQUFLLGdCQUFnQixDQUFDLEdBQUc7TUFDL0IsTUFBTSxTQUFTLFdBQVcsTUFBTSxhQUFhLElBQUksQ0FBQztNQUNsRCxhQUFhLFdBQVcsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsV0FBVyxFQUFFO01BQzFELElBQUk7T0FDQSxNQUFNLElBQUksS0FBSyxNQUFNLE1BQU07T0FDM0IsTUFBTSxTQUFTLFNBQVMsRUFBRSxRQUFRLEVBQUUsS0FBSztPQUN6QyxJQUFJLFVBQVUsTUFBTSxRQUFRLEVBQUUsT0FBTyxJQUFJLEVBQUUsVUFBVSxDQUFDO09BQ3RELElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsTUFBTSxLQUFLLFFBQVEsV0FBVyxHQUFHO1FBQ2pELFVBQVU7U0FDTjtVQUFFLFlBQVk7VUFBYSxXQUFXO1NBQUs7U0FDM0M7VUFBRSxZQUFZO1VBQWEsV0FBVztTQUFNO1NBQzVDO1VBQUUsWUFBWTtVQUFhLFdBQVc7U0FBTTtTQUM1QztVQUFFLFlBQVk7VUFBYSxXQUFXO1NBQU07UUFDaEQ7T0FDSjtPQUNBLE1BQU0sYUFBYTtRQUNmLEtBQUssZUFBZSxLQUFLLElBQUksRUFBRSxHQUFHO1FBQ2xDLElBQUk7UUFDSixVQUFVLE9BQU8sRUFBRSxZQUFZLGNBQWMsZ0JBQWdCLEdBQUc7UUFDaEU7UUFDQSxZQUFZLEVBQUUsZUFBZSxZQUFZLFFBQVEsRUFBRSxVQUFVLElBQUk7UUFDakUsWUFBWSxFQUFFLGVBQWUsWUFBWSxRQUFRLEVBQUUsVUFBVSxJQUFJO1FBQ2pFLFFBQVE7UUFDUixlQUFlLEVBQUUsZ0JBQWdCLE9BQU8sRUFBRSxhQUFhLElBQUk7UUFDM0QsU0FBUyxRQUFRLEtBQUssS0FBSyxVQUFVO1NBQ2pDLFlBQVksT0FBTyxJQUFJLGNBQWMsSUFBSSxRQUFRLFdBQVcsT0FBTyxhQUFhLEtBQUssSUFBSSxHQUFHO1NBQzVGLFdBQVcsUUFBUSxJQUFJLFNBQVM7UUFDcEMsRUFBRTtRQUNGLGVBQWU7UUFDZixlQUFlO09BQ25CO09BQ0E7T0FDQSxJQUFJLE9BQU8sZUFBZSxZQUFZLFdBQVcsVUFBVTtPQUMzRCxVQUFVLGlCQUFpQixjQUFjLEdBQUcsTUFBTSxJQUFJO09BQ3RELE9BQU87TUFDWCxRQUFRLENBQXNCO01BQzlCO0tBQ0o7SUFDSjtHQUNKO0dBQ0EsT0FBTztFQUNYO0VBRUEsT0FBTyxNQUFNO0dBQ1QsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLE9BQU8sS0FBSztHQUMxQyxJQUFJLE1BQU07R0FDVixhQUFhLFFBQVEsT0FBTyxPQUFPLEVBQUUsUUFBUSxLQUFLLENBQUM7R0FDbkQsTUFBTSxRQUFRLFVBQVUsTUFBTSxJQUFJO0dBQ2xDLFlBQVksTUFBTSxJQUFJLEtBQUs7R0FDM0IsS0FBSyxNQUFNLFFBQVEsT0FBTztJQUN0QixJQUFJLENBQUMsS0FBSyxXQUFXLFFBQVEsR0FBRztJQUNoQyxNQUFNLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUs7SUFDbkMsSUFBSSxZQUFZLFVBQVU7SUFDMUIsSUFBSTtLQUNBLE1BQU0sU0FBUyxLQUFLLE1BQU0sT0FBTztLQUNqQyxNQUFNLE9BQU8sT0FBTyxhQUFhLEVBQUUsRUFBRSxTQUFTLFFBQVEsRUFBRSxFQUFFLFFBQVE7S0FDbEUsY0FBYztLQUNkLElBQUksQ0FBQyxjQUFjO01BQ2YsTUFBTSxVQUFVLFdBQVcsVUFBVTtNQUNyQyxJQUFJLFFBQVEsV0FBVyxHQUFHLEdBQUc7T0FBRSxhQUFhLFFBQVEsTUFBTSxDQUFDO09BQUcsZUFBZTtNQUFNO0tBQ3ZGO0tBQ0EsSUFBSSxPQUFPO0tBQ1gsT0FBTyxNQUFNO01BQUUsT0FBTyxpQkFBaUI7S0FBRztJQUM5QyxRQUFRLENBQThCO0dBQzFDO0VBQ0o7RUFFQSxNQUFNLGVBQWUsS0FBSyxJQUFJLElBQUksYUFBYSxJQUFJLENBQUUsUUFBUSxDQUFDO0VBQzlELFVBQVUsWUFBWSxjQUFjLHdCQUF3QixXQUFXLFNBQVM7RUFDaEYsT0FBTztHQUFFLElBQUk7R0FBTSxZQUFZO0dBQWUsV0FBVztHQUFhO0VBQVcsQ0FBQztDQUN0RixTQUFTLEtBQUs7RUFDVixJQUFJLE9BQU8sSUFBSSxTQUFTLGNBQWM7R0FBRSxPQUFPO0lBQUUsSUFBSTtJQUFPLFNBQVM7R0FBOEUsQ0FBQztFQUFHLE9BQ2xKLElBQUksT0FBTyxJQUFJLFNBQVMsYUFBYTtHQUFFLE9BQU87SUFBRSxJQUFJO0lBQU8sU0FBUztHQUFxRSxDQUFDO0VBQUcsT0FDN0k7R0FBRSxPQUFPO0lBQUUsSUFBSTtJQUFPLFNBQVMsc0NBQXNDLEtBQUssV0FBVztHQUFrQixDQUFDO0VBQUc7Q0FDcEg7QUFDSjs7OztBQUtBLE9BQU8sTUFBTSxnQ0FBZ0MsT0FBTyxFQUNoRCxNQUNBLGNBQWMsNEVBQ2QsUUFBUSxHQUNSLGlCQUFpQixLQUNqQixhQUFhLFVBQ2IsZ0JBQWdCLGtCQUNoQixlQUFlLE1BQ2YsV0FBVyxXQUNUO0NBQ0YsTUFBTSxhQUFhLFFBQVE7RUFBRSxJQUFJLE9BQU8sYUFBYSxZQUFZLFNBQVMsR0FBRztDQUFHO0NBRWhGLElBQUksQ0FBQyxNQUFNO0VBQ1AsT0FBTztHQUFFLElBQUk7R0FBTyxTQUFTO0VBQStCO0NBQ2hFO0NBRUEsVUFBVSxtQkFBbUIsS0FBSyxLQUFLLEtBQUs7Q0FFNUMsTUFBTSxrQkFBa0I7RUFDcEIsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxTQUFTO0NBQ2IsRUFBRSxtQkFBbUI7Q0FFckIsTUFBTSxhQUFhLEdBQUcsYUFBYSx1REFBdUQsTUFBTTttQ0FDakUsZUFBZSxzQ0FBc0M7MkJBQzdELFdBQVc7cUJBQ2pCLGdCQUFnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXlCbkMsS0FBSztDQUVILE9BQU8sTUFBTSwwQkFBMEIsT0FBTyxXQUFXO0VBQ3JELElBQUk7R0FDQSxNQUFNLGNBQWMsaUJBQWlCLGFBQWE7R0FDbEQsVUFBVSxvQkFBb0IsWUFBWSx3QkFBd0I7R0FFbEUsTUFBTSxlQUFlLEtBQUssU0FBUyxxQkFBcUIsS0FBSyxLQUFLLFdBQVcsUUFBUSxLQUFLLEtBQUssS0FBSyxZQUFZLENBQUMsQ0FBQyxTQUFTLE1BQU07R0FDakksTUFBTSxRQUFRLENBQUMsRUFBRSxNQUFNLFdBQVcsQ0FBQztHQUVuQyxJQUFJLGNBQWM7SUFDZCxNQUFNLGFBQWEsTUFBTSxJQUFJLFNBQVMsU0FBUyxXQUFXO0tBQ3RELE1BQU0sU0FBUyxJQUFJLFdBQVc7S0FDOUIsT0FBTyxlQUFlO01BQ2xCLE1BQU0sTUFBTSxPQUFPO01BQ25CLE1BQU0sU0FBUyxPQUFPLFFBQVEsV0FBVyxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSztNQUM3RCxRQUFRLE1BQU07S0FDbEI7S0FDQSxPQUFPLFVBQVU7S0FDakIsT0FBTyxjQUFjLElBQUk7SUFDN0IsQ0FBQztJQUNELE1BQU0sS0FBSyxFQUNQLFlBQVk7S0FDUixVQUFVLEtBQUssUUFBUTtLQUN2QixNQUFNO0lBQ1YsRUFDSixDQUFDO0dBQ0wsT0FBTztJQUNILE1BQU0sY0FBYyxNQUFNLElBQUksU0FBUyxTQUFTLFdBQVc7S0FDdkQsTUFBTSxTQUFTLElBQUksV0FBVztLQUM5QixPQUFPLGVBQWUsUUFBUSxPQUFPLFVBQVUsRUFBRTtLQUNqRCxPQUFPLFVBQVU7S0FDakIsT0FBTyxXQUFXLElBQUk7SUFDMUIsQ0FBQztJQUNELE1BQU0sS0FBSyxFQUNQLE1BQU0sZ0NBQWdDLEtBQUssS0FBSyxlQUFlLE9BQU8sV0FBVyxDQUFDLENBQUMsTUFBTSxHQUFHLEdBQU0sRUFBRSxPQUN4RyxDQUFDO0dBQ0w7R0FFQSxNQUFNLFdBQVcsMkRBQTJELFlBQVksdUJBQXVCO0dBQy9HLE1BQU0sWUFBWSxLQUFLLElBQUk7R0FDM0IsVUFBVSxPQUFPLFlBQVksaURBQWlEO0dBRTlFLE1BQU0sV0FBVyxNQUFNLE1BQU0sVUFBVTtJQUNuQyxRQUFRO0lBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7SUFDOUMsTUFBTSxLQUFLLFVBQVU7S0FDakIsVUFBVSxDQUFDLEVBQUUsTUFBTSxDQUFDO0tBQ3BCLGtCQUFrQjtNQUNkLGtCQUFrQjtNQUNsQixhQUFhO0tBQ2pCO0lBQ0osQ0FBQztHQUNMLENBQUM7R0FFRCxNQUFNLGVBQWUsS0FBSyxJQUFJLElBQUksYUFBYSxJQUFJLENBQUUsUUFBUSxDQUFDO0dBRTlELElBQUksQ0FBQyxTQUFTLElBQUk7SUFDZCxNQUFNLFVBQVUsTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFO0lBQ3RELE1BQU0sU0FBUyxRQUFRLE9BQU8sV0FBVyxRQUFRLFNBQVM7SUFDMUQsSUFBSSxTQUFTLFdBQVcsS0FBSztLQUN6QixPQUFPO01BQUUsSUFBSTtNQUFPLFFBQVE7TUFBSyxTQUFTLDBCQUEwQixZQUFZO0tBQTJDO0lBQy9IO0lBQ0EsSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztLQUNwRCxPQUFPO01BQUUsSUFBSTtNQUFPLFFBQVEsU0FBUztNQUFRLFNBQVMsNENBQTRDLE9BQU87S0FBRztJQUNoSDtJQUNBLE9BQU87S0FBRSxJQUFJO0tBQU8sUUFBUSxTQUFTO0tBQVEsU0FBUyx1QkFBdUI7SUFBUztHQUMxRjtHQUVBLFVBQVUsZ0NBQWdDLFdBQVcsaUNBQWlDO0dBRXRGLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztHQUNqQyxNQUFNLGVBQWUsS0FBSyxhQUFhLEVBQUUsRUFBRSxTQUFTLFFBQVEsRUFBRSxFQUFFO0dBRWhFLElBQUksQ0FBQyxjQUFjO0lBQ2YsT0FBTztLQUFFLElBQUk7S0FBTyxTQUFTO0lBQTBDO0dBQzNFO0dBRUEsSUFBSTtHQUNKLElBQUk7SUFDQSxrQkFBa0IsY0FBYyxZQUFZO0dBQ2hELFFBQVE7SUFDSixPQUFPO0tBQUUsSUFBSTtLQUFPLFNBQVM7SUFBbUM7R0FDcEU7R0FFQSxJQUFJLENBQUMsTUFBTSxRQUFRLGVBQWUsS0FBSyxnQkFBZ0IsV0FBVyxHQUFHO0lBQ2pFLE9BQU87S0FBRSxJQUFJO0tBQU8sU0FBUztJQUFzRDtHQUN2RjtHQUVBLE1BQU0sYUFBYSxnQkFBZ0IsS0FBSyxHQUFHLFFBQVE7SUFDL0MsTUFBTSxTQUFTLFNBQVMsRUFBRSxRQUFRLEVBQUUsS0FBSztJQUN6QyxJQUFJLFVBQVUsTUFBTSxRQUFRLEVBQUUsT0FBTyxJQUFJLEVBQUUsVUFBVSxDQUFDO0lBQ3RELElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsTUFBTSxLQUFLLFFBQVEsV0FBVyxHQUFHO0tBQ2pELFVBQVU7TUFDTjtPQUFFLFlBQVk7T0FBYSxXQUFXO01BQUs7TUFDM0M7T0FBRSxZQUFZO09BQWEsV0FBVztNQUFNO01BQzVDO09BQUUsWUFBWTtPQUFhLFdBQVc7TUFBTTtNQUM1QztPQUFFLFlBQVk7T0FBYSxXQUFXO01BQU07S0FDaEQ7SUFDSjtJQUNBLE9BQU87S0FDSCxLQUFLLFlBQVksS0FBSyxJQUFJLEVBQUUsR0FBRztLQUMvQixJQUFJO0tBQ0osVUFBVSxPQUFPLEVBQUUsWUFBWSxjQUFjLE1BQU0sR0FBRztLQUM5QztLQUNSLFlBQVksRUFBRSxlQUFlLFlBQVksUUFBUSxFQUFFLFVBQVUsSUFBSTtLQUNqRSxZQUFZLEVBQUUsZUFBZSxZQUFZLFFBQVEsRUFBRSxVQUFVLElBQUk7S0FDakUsUUFBUSxFQUFFLFVBQVUsT0FBTyxPQUFPLEVBQUUsTUFBTSxJQUFJO0tBQzlDLGVBQWUsRUFBRSxnQkFBZ0IsT0FBTyxFQUFFLGFBQWEsSUFBSTtLQUMzRCxTQUFTLFFBQVEsS0FBSyxLQUFLLFVBQVU7TUFDakMsWUFBWSxPQUFPLElBQUksY0FBYyxJQUFJLFFBQVEsV0FBVyxPQUFPLGFBQWEsS0FBSyxJQUFJLEdBQUc7TUFDNUYsV0FBVyxRQUFRLElBQUksU0FBUztLQUNwQyxFQUFFO0tBQ0YsZUFBZTtLQUNmLGVBQWU7SUFDbkI7R0FDSixDQUFDO0dBRUQsVUFBVSw2QkFBNkIsV0FBVyxPQUFPLG9CQUFvQixLQUFLLEtBQUssR0FBRztHQUUxRixPQUFPO0lBQ0gsSUFBSTtJQUNKLE1BQU07SUFDTixVQUFVLEtBQUs7SUFDZixXQUFXO0lBQ1g7R0FDSjtFQUNKLFNBQVMsS0FBSztHQUNWLE9BQU87SUFDSCxJQUFJO0lBQ0osU0FBUywwREFBMEQsS0FBSyxXQUFXO0dBQ3ZGO0VBQ0o7Q0FDSixHQUFHLFlBQVk7QUFDbkI7Ozs7QUFLQSxPQUFPLE1BQU0sd0JBQXdCLFdBQVcsUUFBUSx1QkFBdUI7Q0FDM0UsSUFBSSxDQUFDLGFBQWEsVUFBVSxXQUFXLEdBQUc7Q0FDMUMsTUFBTSxPQUFPLENBQ1Q7RUFBQztFQUFZO0VBQVc7RUFBUztFQUFlO0VBQWtCO0NBQVMsQ0FDL0U7Q0FDQSxVQUFVLFNBQVMsR0FBRyxNQUFNO0VBQ3hCLE1BQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxFQUFFLFdBQVc7RUFDaEQsTUFBTSxjQUFjLEVBQUUsV0FBVyxDQUFDLEVBQUMsQ0FBRSxLQUFJLE1BQU0sRUFBRSxZQUFZLFdBQVcsRUFBRSxlQUFlLEVBQUUsVUFBVyxDQUFDLENBQUMsS0FBSyxHQUFHO0VBQ2hILE1BQU0sVUFBVSxFQUFFLFlBQVksR0FBRSxDQUFFLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FBQyxRQUFRLFFBQVEsR0FBRyxDQUFDLENBQUMsS0FBSztFQUNwRixNQUFNLFlBQVksWUFDWCxFQUFFLFdBQVcsQ0FBQyxFQUFDLENBQUUsUUFBTyxNQUFLLEVBQUUsU0FBUyxDQUFDLENBQUMsS0FBSSxNQUFLLEVBQUUsVUFBVSxDQUFDLENBQUMsS0FBSyxHQUFHLElBQ3pFLEVBQUUsaUJBQWlCO0VBQzFCLEtBQUssS0FBSztHQUNOLElBQUksT0FBTyxRQUFRLE1BQU0sTUFBSSxFQUFFO0dBQy9CLEVBQUUsVUFBVTtHQUNaLElBQUk7R0FDSixFQUFFLGFBQWEsU0FBUztHQUN4QixLQUFLLGFBQWEsR0FBRSxDQUFFLFFBQVEsTUFBTSxNQUFJLEVBQUU7R0FDMUMsSUFBSSxXQUFXLFFBQVEsTUFBTSxNQUFJLEVBQUU7RUFDdkMsQ0FBQztDQUNMLENBQUM7Q0FDRCxNQUFNLE1BQU0sTUFBVyxLQUFLLEtBQUksTUFBSyxFQUFFLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU07Q0FDN0QsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7Q0FDaEUsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7Q0FDcEMsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0NBQ3BDLEVBQUUsT0FBTztDQUNULEVBQUUsV0FBVyxHQUFHLE1BQU0sUUFBUSxRQUFRLEdBQUcsRUFBRSxHQUFHLEtBQUssSUFBSSxFQUFFO0NBQ3pELFNBQVMsS0FBSyxZQUFZLENBQUM7Q0FDM0IsRUFBRSxNQUFNO0NBQ1IsU0FBUyxLQUFLLFlBQVksQ0FBQztDQUMzQixJQUFJLGdCQUFnQixHQUFHO0FBQzNCOzs7O0FBS0EsT0FBTyxNQUFNLHdCQUF3QixPQUFPLEtBQUssV0FBVyxTQUFTO0NBQ2pFLE1BQU0sYUFBYSxRQUFRO0VBQUUsSUFBSSxPQUFPLGFBQWEsWUFBWSxTQUFTLEdBQUc7Q0FBRztDQUNoRixJQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsVUFBVSxPQUFPO0VBQUUsSUFBSTtFQUFPLFNBQVM7Q0FBa0I7Q0FFcEYsTUFBTSxhQUFhLElBQUksS0FBSztDQUM1QixVQUFVLGdCQUFnQixXQUFXLElBQUk7O0NBR3pDLE1BQU0sVUFBVSxXQUFXLE1BQU0sc0ZBQXNGO0NBQ3ZILElBQUksV0FBVyxRQUFRLElBQUk7RUFDdkIsTUFBTSxVQUFVLFFBQVE7RUFDeEIsVUFBVSxpQ0FBaUMsUUFBUSxrQ0FBa0M7RUFFckYsSUFBSTs7R0FFQSxJQUFJLGFBQWEsa0JBQWtCLFFBQVE7R0FDM0MsSUFBSTtJQUNBLE1BQU0sWUFBWSxNQUFNLE1BQU0saUVBQWlFLFNBQVM7SUFDeEcsSUFBSSxVQUFVLElBQUk7S0FDZCxNQUFNLE9BQU8sTUFBTSxVQUFVLEtBQUs7S0FDbEMsSUFBSSxLQUFLLE9BQU8sYUFBYSxLQUFLO0lBQ3RDO0dBQ0osUUFBUSxDQUFDOztHQUdULElBQUksaUJBQWlCO0dBQ3JCLElBQUk7SUFDQSxNQUFNLFNBQVMsTUFBTSxNQUFNLHlCQUF5QixtQkFBbUIsbUNBQW1DLFNBQVMsR0FBRztJQUN0SCxJQUFJLE9BQU8sSUFBSTtLQUNYLE1BQU0sT0FBTyxNQUFNLE9BQU8sS0FBSzs7S0FFL0IsTUFBTSxlQUFlLEtBQUssTUFBTSxpQ0FBaUM7S0FDakUsSUFBSSxnQkFBZ0IsYUFBYSxJQUFJO01BQ2pDLE1BQU0sU0FBUyxLQUFLLE1BQU0sYUFBYSxFQUFFO01BQ3pDLE1BQU0sV0FBVyxPQUFPLEVBQUUsRUFBRTtNQUM1QixJQUFJLFVBQVU7T0FDVixNQUFNLFdBQVcsTUFBTSxNQUFNLHlCQUF5QixtQkFBbUIsUUFBUSxHQUFHO09BQ3BGLElBQUksU0FBUyxJQUFJO1FBQ2IsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLO1FBQ3BDLGlCQUFpQixRQUNaLFFBQVEsZ0JBQWdCLEdBQUcsQ0FBQyxDQUM1QixRQUFRLGFBQWEsSUFBSSxDQUFDLENBQzFCLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FDdkIsUUFBUSxVQUFVLEdBQUcsQ0FBQyxDQUN0QixRQUFRLFVBQVUsR0FBRyxDQUFDLENBQ3RCLFFBQVEsV0FBVyxJQUFHLENBQUMsQ0FDdkIsUUFBUSxRQUFRLEdBQUcsQ0FBQyxDQUNwQixLQUFLO09BQ2Q7TUFDSjtLQUNKO0lBQ0o7R0FDSixRQUFRLENBQUM7R0FFVCxJQUFJLENBQUMsZ0JBQWdCOztJQUVqQixpQkFBaUIsbUJBQW1CLFdBQVcsMkJBQTJCLFFBQVE7R0FDdEY7R0FFQSxPQUFPO0lBQ0gsSUFBSTtJQUNKLE1BQU07SUFDTixPQUFPO0lBQ1A7SUFDQSxTQUFTLGVBQWUsTUFBTSxHQUFHLEdBQUs7SUFDdEMsS0FBSztHQUNUO0VBQ0osU0FBUyxLQUFLO0dBQ1YsT0FBTztJQUNILElBQUk7SUFDSixNQUFNO0lBQ04sT0FBTyxrQkFBa0IsUUFBUTtJQUNqQztJQUNBLFNBQVMsbUNBQW1DO0lBQzVDLEtBQUs7R0FDVDtFQUNKO0NBQ0o7O0NBR0EsSUFBSTtFQUNBLFVBQVUsd0NBQXdDO0VBQ2xELElBQUksT0FBTztFQUNYLElBQUk7R0FDQSxNQUFNLE9BQU8sTUFBTSxNQUFNLHlCQUF5QixtQkFBbUIsVUFBVSxHQUFHO0dBQ2xGLElBQUksS0FBSyxJQUFJO0lBQ1QsT0FBTyxNQUFNLEtBQUssS0FBSztHQUMzQjtFQUNKLFFBQVEsQ0FBQztFQUVULElBQUksQ0FBQyxNQUFNO0dBQ1AsTUFBTSxhQUFhLE1BQU0sTUFBTSxZQUFZLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBSTtHQUM3RSxJQUFJLGNBQWMsV0FBVyxJQUFJO0lBQzdCLE9BQU8sTUFBTSxXQUFXLEtBQUs7R0FDakM7RUFDSjtFQUVBLElBQUksQ0FBQyxNQUFNO0dBQ1AsT0FBTztJQUFFLElBQUk7SUFBTyxTQUFTO0dBQStFO0VBQ2hIOztFQUdBLE1BQU0sU0FBUyxJQUFJLFVBQVU7RUFDN0IsTUFBTSxNQUFNLE9BQU8sZ0JBQWdCLE1BQU0sV0FBVzs7RUFHcEQsSUFBSSxpQkFBaUIsa0ZBQWdGLENBQUMsQ0FBQyxTQUFRLE9BQU0sR0FBRyxPQUFPLENBQUM7RUFFaEksTUFBTSxZQUFZLElBQUksY0FBYyxPQUFPLENBQUMsRUFBRSxhQUFhLElBQUksY0FBYyxJQUFJLENBQUMsRUFBRSxhQUFhOztFQUdqRyxNQUFNLGFBQWEsTUFBTSxLQUFLLElBQUksaUJBQWlCLHNDQUFzQyxDQUFDLENBQUMsQ0FDdEYsS0FBSSxPQUFNLEdBQUcsVUFBVSxLQUFLLENBQUMsQ0FBQyxDQUM5QixRQUFPLE1BQUssRUFBRSxTQUFTLEVBQUU7RUFFOUIsTUFBTSxXQUFXLFdBQVcsS0FBSyxNQUFNLENBQUMsQ0FBQyxNQUFNLEdBQUcsR0FBSztFQUV2RCxJQUFJLENBQUMsWUFBWSxTQUFTLFNBQVMsSUFBSTtHQUNuQyxPQUFPO0lBQUUsSUFBSTtJQUFPLFNBQVM7R0FBcUY7RUFDdEg7RUFFQSxPQUFPO0dBQ0gsSUFBSTtHQUNKLE1BQU07R0FDTixPQUFPLFVBQVUsS0FBSztHQUN0QixTQUFTO0dBQ1QsS0FBSztFQUNUO0NBQ0osU0FBUyxLQUFLO0VBQ1YsT0FBTztHQUFFLElBQUk7R0FBTyxTQUFTLHNCQUFzQixJQUFJO0VBQVU7Q0FDckU7QUFDSjs7OztBQUtBLE9BQU8sTUFBTSw4QkFBOEIsT0FBTyxFQUM5QyxjQUNBLGVBQWUsR0FDZixhQUFhLElBQ2IsZ0JBQWdCLElBQ2hCLFVBQVUsQ0FBQyxHQUNYLGdCQUFnQixrQkFDaEIsZUFBZSxXQUNiO0NBQ0YsT0FBTyxNQUFNLDBCQUEwQixPQUFPLFdBQVc7RUFDckQsTUFBTSxlQUFlO0dBQUUsR0FBRztHQUFTLEdBQUc7R0FBaUIsR0FBRztHQUFZLEdBQUc7R0FBVyxHQUFHO0VBQWM7RUFDckcsTUFBTSxZQUFZLGFBQWEsaUJBQWlCO0VBRWhELE1BQU0sYUFBYTs7Ozs7aUJBS1YsVUFBVTtpQkFDVixhQUFhO2dDQUNFLFFBQVEsS0FBSyxHQUFHLE1BQU0sR0FBRyxPQUFPLGFBQWEsS0FBSyxDQUFDLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLLElBQUk7aUNBQzNGLGNBQWMsMkJBQTJCO2lDQUN6QyxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBeUI3QyxLQUFLO0VBRUMsTUFBTSxXQUFXLDJEQUEyRCxjQUFjLHVCQUF1QjtFQUNqSCxNQUFNLFdBQVcsTUFBTSxNQUFNLFVBQVU7R0FDbkMsUUFBUTtHQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0dBQzlDLE1BQU0sS0FBSyxVQUFVO0lBQ2pCLFVBQVUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLE1BQU0sV0FBVyxDQUFDLEVBQUUsQ0FBQztJQUM1QyxrQkFBa0I7S0FDZCxrQkFBa0I7S0FDbEIsYUFBYTtJQUNqQjtHQUNKLENBQUM7RUFDTCxDQUFDO0VBRUQsSUFBSSxDQUFDLFNBQVMsSUFBSTtHQUNkLE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUU7R0FDdEQsTUFBTSxTQUFTLFFBQVEsT0FBTyxXQUFXLFFBQVEsU0FBUztHQUMxRCxPQUFPO0lBQUUsSUFBSTtJQUFPLFFBQVEsU0FBUztJQUFRLFNBQVM7R0FBTztFQUNqRTtFQUVBLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztFQUNqQyxNQUFNLFVBQVUsS0FBSyxhQUFhLEVBQUUsRUFBRSxTQUFTLFFBQVEsRUFBRSxFQUFFO0VBQzNELElBQUksQ0FBQyxTQUFTLE9BQU87R0FBRSxJQUFJO0dBQU8sU0FBUztFQUFnQztFQUUzRSxNQUFNLFNBQVMsY0FBYyxPQUFPO0VBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxhQUFhO0dBQ2hDLE9BQU87SUFBRSxJQUFJO0lBQU8sU0FBUztHQUF1QztFQUN4RTtFQUVBLE9BQU87R0FDSCxJQUFJO0dBQ0osTUFBTTtHQUNOLFdBQVc7RUFDZjtDQUNKLEdBQUcsWUFBWTtBQUNuQjs7OztBQUtBLE9BQU8sTUFBTSx1QkFBdUIsT0FBTyxFQUN2QyxVQUNBLFVBQVUsQ0FBQyxHQUNYLGdCQUFnQixJQUNoQixTQUFTLEdBQ1QsYUFBYSxNQUNiLGFBQWEsTUFDYixhQUNBLGdCQUFnQixrQkFDaEIsZUFBZSxXQUNiO0NBQ0YsT0FBTyxNQUFNLDBCQUEwQixPQUFPLFdBQVc7RUFDckQsTUFBTSxVQUFVLFlBQVksR0FBRSxDQUFFLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FBQyxLQUFLO0VBQzdELE1BQU0sY0FBYyxRQUFRLEtBQUssR0FBRyxNQUFNLEdBQUcsT0FBTyxhQUFhLEtBQUcsQ0FBQyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsWUFBVSxxQkFBbUIsSUFBSSxDQUFDLENBQUMsS0FBSyxJQUFJO0VBQ3hJLE1BQU0sU0FBUzs7O0VBR3JCLE9BQU87OztFQUdQLGVBQWUsbUJBQW1COztpQkFFbkIsaUJBQWlCLEdBQUc7O29CQUVqQixZQUFZLEtBQUssRUFBRTs7Ozs7Y0FLekIsT0FBTztrQkFDSCxXQUFXO2tCQUNYLFdBQVc7Ozs7RUFJakIsTUFBTSxjQUFjLGlCQUFpQixhQUFhO0VBQ3RELE1BQU0sV0FBVywyREFBMkQsWUFBWSx1QkFBdUI7RUFDL0csTUFBTSxPQUFPLE1BQU0sTUFBTSxVQUFVO0dBQy9CLFFBQVE7R0FDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtHQUM5QyxNQUFNLEtBQUssVUFBVTtJQUNqQixVQUFVLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRSxNQUFNLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDeEMsa0JBQWtCO0tBQUUsa0JBQWtCO0tBQW9CLGFBQWE7SUFBSTtHQUMvRSxDQUFDO0VBQ0wsQ0FBQztFQUNELElBQUksQ0FBQyxLQUFLLElBQUk7R0FDVixNQUFNLFVBQVUsTUFBTSxLQUFLLEtBQUssQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFO0dBQ2xELE1BQU0sU0FBUyxRQUFRLE9BQU8sV0FBVyxRQUFRLEtBQUs7R0FDdEQsT0FBTztJQUFFLElBQUk7SUFBTyxRQUFRLEtBQUs7SUFBUSxTQUFTO0dBQU87RUFDN0Q7RUFDQSxNQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUs7RUFDN0IsSUFBSSxVQUFVLEtBQUssYUFBYSxFQUFFLEVBQUUsU0FBUyxRQUFRLEVBQUUsRUFBRSxRQUFRO0VBQ2pFLFVBQVUsUUFBUSxLQUFLLENBQUMsQ0FBQyxRQUFRLGVBQWMsRUFBRSxDQUFDLENBQUMsUUFBUSxXQUFVLEVBQUUsQ0FBQyxDQUFDLFFBQVEsV0FBVSxFQUFFO0VBQzdGLE1BQU0sVUFBVSxLQUFLLE1BQU0sT0FBTztFQUNsQyxPQUFPO0dBQUUsSUFBSTtHQUFNLE1BQU07RUFBUTtDQUNyQyxHQUFHLFlBQVk7QUFDbkI7Ozs7QUFLQSxPQUFPLE1BQU0sNEJBQTRCLE9BQU8sRUFDNUMsWUFBWSxDQUFDLEdBQ2Isa0JBQWtCLENBQUMsR0FDbkIsYUFDQSxnQkFBZ0Isa0JBQ2hCLGVBQWUsV0FDYjtDQUNGLE9BQU8sTUFBTSwwQkFBMEIsT0FBTyxXQUFXO0VBQ2pELE1BQU0sY0FBYyxpQkFBaUIsYUFBYTtFQUN0RCxNQUFNLFVBQVUsQ0FBQztFQUNqQixJQUFJLGFBQWE7RUFFakIsS0FBSyxNQUFNLE9BQU8saUJBQWlCO0dBQy9CLE1BQU0sSUFBSSxVQUFVO0dBQ3BCLElBQUksQ0FBQyxHQUFHO0dBQ1IsSUFBSTtJQUNBLE1BQU0sVUFBVSxFQUFFLFlBQVksR0FBRSxDQUFFLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FBQyxLQUFLO0lBQy9ELE1BQU0sZUFBZSxFQUFFLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSyxHQUFHLE1BQU0sR0FBRyxPQUFPLGFBQWEsS0FBRyxDQUFDLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxZQUFVLHFCQUFtQixJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUk7SUFDbEosTUFBTSxTQUFTLCtFQUErRSxPQUFPLFdBQVcsZUFBZSxjQUFjLFdBQVcsRUFBRSxpQkFBaUIsR0FBRyxpQkFBaUIsWUFBWSxLQUFLLEVBQUUsK0NBQStDLEVBQUUsT0FBTyxnQkFBZ0IsRUFBRSxXQUFXLGdCQUFnQixFQUFFLFdBQVc7SUFDcFUsTUFBTSxXQUFXLDJEQUEyRCxZQUFZLHVCQUF1QjtJQUMvRyxNQUFNLE9BQU8sTUFBTSxNQUFNLFVBQVU7S0FDL0IsUUFBUTtLQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0tBQzlDLE1BQU0sS0FBSyxVQUFVO01BQ2pCLFVBQVUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLE1BQU0sT0FBTyxDQUFDLEVBQUUsQ0FBQztNQUN4QyxrQkFBa0I7T0FBRSxrQkFBa0I7T0FBb0IsYUFBYTtNQUFJO0tBQy9FLENBQUM7SUFDTCxDQUFDO0lBQ0QsSUFBSSxDQUFDLEtBQUssSUFBSTtLQUNWLElBQUksS0FBSyxXQUFXLE9BQU8sS0FBSyxXQUFXLE9BQU8sS0FBSyxXQUFXLEtBQUs7TUFDbkUsT0FBTztPQUFFLElBQUk7T0FBTyxRQUFRLEtBQUs7T0FBUSxTQUFTLFFBQVEsS0FBSztNQUFTO0tBQzVFO0tBQ0E7SUFDSjtJQUNBLE1BQU0sT0FBTyxNQUFNLEtBQUssS0FBSztJQUM3QixJQUFJLFVBQVUsS0FBSyxhQUFhLEVBQUUsRUFBRSxTQUFTLFFBQVEsRUFBRSxFQUFFLFFBQVE7SUFDakUsVUFBVSxRQUFRLEtBQUssQ0FBQyxDQUFDLFFBQVEscUJBQW9CLEVBQUUsQ0FBQyxDQUFDLFFBQVEsV0FBVSxFQUFFLENBQUMsQ0FBQyxLQUFLOzs7O0lBSXBGLE1BQU0sWUFBWSxRQUFRLFFBQVEsR0FBRztJQUNyQyxNQUFNLFVBQVUsUUFBUSxZQUFZLEdBQUc7SUFDdkMsSUFBSSxhQUFhLEtBQUssVUFBVSxXQUFXLFVBQVUsUUFBUSxNQUFNLFdBQVcsVUFBVSxDQUFDO0lBQ3pGLE1BQU0sVUFBVSxjQUFjLE9BQU87SUFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLFVBQVUsTUFBTSxJQUFJLE1BQU0sZ0NBQWdDO0lBQ25GLFFBQVEsS0FBSztLQUFFO0tBQUssVUFBVTtLQUFHO0lBQVEsQ0FBQztJQUMxQyxhQUFhO0dBQ2pCLFNBQVMsS0FBSztJQUNWLFFBQVEsTUFBTSwyQkFBMkIsSUFBSSxJQUFJLEdBQUc7R0FDeEQ7RUFDSjtFQUVBLElBQUksQ0FBQyxjQUFjLGdCQUFnQixTQUFTLEdBQUc7R0FDM0MsT0FBTztJQUFFLElBQUk7SUFBTyxTQUFTO0dBQWlEO0VBQ2xGO0VBQ0EsT0FBTztHQUFFLElBQUk7R0FBTSxNQUFNO0VBQVE7Q0FDckMsR0FBRyxZQUFZO0FBQ25COzs7O0FBS0EsT0FBTyxNQUFNLDZCQUE2QixPQUFPLEVBQzdDLFNBQ0EsZ0JBQWdCLGtCQUNoQixlQUFlLFdBQ2I7Q0FDRixPQUFPLE1BQU0sMEJBQTBCLE9BQU8sV0FBVztFQUNyRCxNQUFNLGFBQWE7O0VBRXpCLFFBQVE7Ozs7Ozs7OztFQVVFLE1BQU0sY0FBYyxpQkFBaUIsYUFBYTtFQUN0RCxNQUFNLFdBQVcsMkRBQTJELFlBQVksdUJBQXVCO0VBQy9HLE1BQU0sT0FBTyxNQUFNLE1BQU0sVUFBVTtHQUMvQixRQUFRO0dBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7R0FDOUMsTUFBTSxLQUFLLFVBQVU7SUFDakIsVUFBVSxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUUsTUFBTSxXQUFXLENBQUMsRUFBRSxDQUFDO0lBQzVDLGtCQUFrQixFQUFFLGFBQWEsR0FBSTtHQUN6QyxDQUFDO0VBQ0wsQ0FBQztFQUVELElBQUksQ0FBQyxLQUFLLElBQUk7R0FDVixNQUFNLFVBQVUsTUFBTSxLQUFLLEtBQUssQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFO0dBQ2xELE1BQU0sU0FBUyxRQUFRLE9BQU8sV0FBVyxRQUFRLEtBQUs7R0FDdEQsT0FBTztJQUFFLElBQUk7SUFBTyxRQUFRLEtBQUs7SUFBUSxTQUFTO0dBQU87RUFDN0Q7RUFFQSxNQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUs7RUFDN0IsTUFBTSxPQUFPLEtBQUssYUFBYSxFQUFFLEVBQUUsU0FBUyxRQUFRLEVBQUUsRUFBRSxRQUFRO0VBQ2hFLE9BQU87R0FBRSxJQUFJO0dBQU0sTUFBTSxLQUFLLEtBQUs7RUFBRTtDQUN6QyxHQUFHLFlBQVk7QUFDbkI7Ozs7QUFLQSxPQUFPLE1BQU0sMkJBQTJCLE9BQU8sRUFDM0MsZUFBZSxDQUFDLEdBQ2hCLFlBQVksSUFDWixnQkFBZ0Isa0JBQ2hCLGVBQWUsV0FDYjtDQUNGLE9BQU8sTUFBTSwwQkFBMEIsT0FBTyxXQUFXO0VBQ3JELE1BQU0sZUFBZSxhQUFhLEtBQUssR0FBRyxNQUFNO0dBQzVDLE1BQU0sT0FBTyxFQUFFLGNBQWMsRUFBRSxlQUFlO0dBQzlDLE1BQU0sTUFBTSxFQUFFLGlCQUFpQjtHQUMvQixNQUFNLEtBQUssRUFBRSxZQUFZLEdBQUUsQ0FBRSxRQUFRLFlBQVksRUFBRSxDQUFDLENBQUMsVUFBVSxHQUFHLEdBQUc7R0FDckUsTUFBTSxNQUFNLEVBQUUsWUFBWSxFQUFFO0dBQzVCLE9BQU8sVUFBVSxJQUFFLEVBQUUsY0FBYyxJQUFJLGtCQUFrQixFQUFFLFdBQVcsSUFBSSxhQUFhO0VBQzNGLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTTtFQUVkLE1BQU0sU0FBUztFQUNyQixVQUFVOzs7RUFHVixhQUFhOzs7Ozs7Ozs7Ozs7RUFhSCxNQUFNLGNBQWMsaUJBQWlCLGFBQWE7RUFDdEQsTUFBTSxXQUFXLDJEQUEyRCxZQUFZLHVCQUF1QjtFQUMvRyxNQUFNLE9BQU8sTUFBTSxNQUFNLFVBQVU7R0FDL0IsUUFBUTtHQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0dBQzlDLE1BQU0sS0FBSyxVQUFVO0lBQ2pCLFVBQVUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLE1BQU0sT0FBTyxDQUFDLEVBQUUsQ0FBQztJQUN4QyxrQkFBa0I7S0FBRSxrQkFBa0I7S0FBb0IsYUFBYTtJQUFJO0dBQy9FLENBQUM7RUFDTCxDQUFDO0VBRUQsSUFBSSxDQUFDLEtBQUssSUFBSTtHQUNWLE1BQU0sVUFBVSxNQUFNLEtBQUssS0FBSyxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUU7R0FDbEQsTUFBTSxTQUFTLFFBQVEsT0FBTyxXQUFXLFFBQVEsS0FBSztHQUN0RCxPQUFPO0lBQUUsSUFBSTtJQUFPLFFBQVEsS0FBSztJQUFRLFNBQVM7R0FBTztFQUM3RDtFQUVBLE1BQU0sT0FBTyxNQUFNLEtBQUssS0FBSztFQUM3QixJQUFJLFVBQVUsS0FBSyxhQUFhLEVBQUUsRUFBRSxTQUFTLFFBQVEsRUFBRSxFQUFFLFFBQVE7RUFDakUsVUFBVSxRQUFRLEtBQUssQ0FBQyxDQUFDLFFBQVEsZUFBYyxFQUFFLENBQUMsQ0FBQyxRQUFRLFdBQVUsRUFBRSxDQUFDLENBQUMsUUFBUSxXQUFVLEVBQUU7RUFDN0YsTUFBTSxjQUFjLEtBQUssTUFBTSxPQUFPO0VBQ3RDLE9BQU87R0FBRSxJQUFJO0dBQU0sTUFBTTtFQUFZO0NBQ3pDLEdBQUcsWUFBWTtBQUNuQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJhaVNlcnZpY2UuanMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBBSSBTZXJ2aWNlIGZvciBHZW5lcmF0aW5nIFF1aXogJiBGb3JtIFF1ZXN0aW9ucyB1c2luZyBHb29nbGUgR2VtaW5pIEFQSVxuICogTW9kZWwgbGlzdCBtYXRjaGVzIEdvb2dsZSBBSSBTdHVkaW8gZnJlZSB0aWVyIG1vZGVscy5cbiAqL1xuXG5leHBvcnQgY29uc3QgQVZBSUxBQkxFX01PREVMUyA9IFtcbiAgICB7IFxuICAgICAgICBpZDogJ2dlbWluaS0zLjYtZmxhc2gnLFxuICAgICAgICBuYW1lOiAnR2VtaW5pIDMuNiBGbGFzaCcsXG4gICAgICAgIGRlc2M6ICdQYWxpbmcgQ2VwYXQgJiBBa3VyYXQgKFJla29tZW5kYXNpKScsIFxuICAgICAgICBiYWRnZTogJ1Jla29tZW5kYXNpJyBcbiAgICB9LFxuICAgIHsgXG4gICAgICAgIGlkOiAnZ2VtaW5pLTMuNi1mbGFzaC1saXRlJyxcbiAgICAgICAgbmFtZTogJ0dlbWluaSAzLjYgRmxhc2ggTGl0ZScsXG4gICAgICAgIGRlc2M6ICdIZW1hdCBLdW90YSAoTGltaXQgMTAgUlBNKSAmIFJlc3BvbnNpZicsIFxuICAgICAgICBiYWRnZTogJ0hlbWF0IEt1b3RhJyBcbiAgICB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfQUlfTU9ERUwgPSAnZ2VtaW5pLTMuNi1mbGFzaCc7XG5leHBvcnQgY29uc3Qgbm9ybWFsaXplQWlNb2RlbCA9IChtb2RlbCkgPT4ge1xuICAgIGlmICghbW9kZWwgfHwgbW9kZWwuaW5jbHVkZXMoJy1wcm8nKSB8fCBtb2RlbCA9PT0gJ2dlbWluaS0zLWZsYXNoLXByZXZpZXcnIHx8ICFBVkFJTEFCTEVfTU9ERUxTLnNvbWUoaXRlbSA9PiBpdGVtLmlkID09PSBtb2RlbCkpIHJldHVybiBERUZBVUxUX0FJX01PREVMO1xuICAgIHJldHVybiBtb2RlbDtcbn07XG5cbi8qKlxuICogQVBJIEtleSBTdGFja2luZyAoTXVsdGktS2V5IHdpdGggQXV0by1GYWlsb3ZlcilcbiAqL1xuZXhwb3J0IGNvbnN0IGdldEdlbWluaUFwaUtleXMgPSAoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByYXcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnZm9ybXVwX2dlbWluaV9hcGlfa2V5cycpO1xuICAgICAgICAgICAgaWYgKHJhdykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UocmF3KTtcbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShwYXJzZWQpICYmIHBhcnNlZC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBwYXJzZWQubWFwKGsgPT4gU3RyaW5nKGspLnRyaW0oKSkuZmlsdGVyKEJvb2xlYW4pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCB7fVxuICAgICAgICBjb25zdCBsZWdhY3kgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnZm9ybXVwX2dlbWluaV9hcGlfa2V5Jyk7XG4gICAgICAgIGlmIChsZWdhY3kgJiYgbGVnYWN5LnRyaW0oKSkge1xuICAgICAgICAgICAgcmV0dXJuIFtsZWdhY3kudHJpbSgpXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gW107XG59O1xuXG5leHBvcnQgY29uc3Qgc2F2ZUdlbWluaUFwaUtleXMgPSAoa2V5c0lucHV0KSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGxldCBjbGVhbktleXMgPSBbXTtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoa2V5c0lucHV0KSkge1xuICAgICAgICAgICAgY2xlYW5LZXlzID0ga2V5c0lucHV0Lm1hcChrID0+IFN0cmluZyhrKS50cmltKCkpLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2Yga2V5c0lucHV0ID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgY2xlYW5LZXlzID0ga2V5c0lucHV0XG4gICAgICAgICAgICAgICAgLnNwbGl0KC9bXFxuLDtdKy8pXG4gICAgICAgICAgICAgICAgLm1hcChrID0+IGsudHJpbSgpKVxuICAgICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gRGVkdXBsaWNhdGUgd2hpbGUgcHJlc2VydmluZyBvcmRlclxuICAgICAgICBjbGVhbktleXMgPSBBcnJheS5mcm9tKG5ldyBTZXQoY2xlYW5LZXlzKSk7XG5cbiAgICAgICAgaWYgKGNsZWFuS2V5cy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdmb3JtdXBfZ2VtaW5pX2FwaV9rZXlzJyk7XG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnZm9ybXVwX2dlbWluaV9hcGlfa2V5Jyk7XG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnZm9ybXVwX2dlbWluaV9hY3RpdmVfa2V5X2lkeCcpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2Zvcm11cF9nZW1pbmlfYXBpX2tleXMnLCBKU09OLnN0cmluZ2lmeShjbGVhbktleXMpKTtcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdmb3JtdXBfZ2VtaW5pX2FwaV9rZXknLCBjbGVhbktleXNbMF0pO1xuICAgICAgICAgICAgY29uc3QgY3VySWR4ID0gcGFyc2VJbnQobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2Zvcm11cF9nZW1pbmlfYWN0aXZlX2tleV9pZHgnKSB8fCAnMCcsIDEwKTtcbiAgICAgICAgICAgIGlmIChjdXJJZHggPj0gY2xlYW5LZXlzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdmb3JtdXBfZ2VtaW5pX2FjdGl2ZV9rZXlfaWR4JywgJzAnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY2xlYW5LZXlzO1xuICAgIH1cbiAgICByZXR1cm4gW107XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0QWN0aXZlQXBpS2V5SW5kZXggPSAoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGNvbnN0IGlkeCA9IHBhcnNlSW50KGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdmb3JtdXBfZ2VtaW5pX2FjdGl2ZV9rZXlfaWR4JykgfHwgJzAnLCAxMCk7XG4gICAgICAgIGNvbnN0IGtleXMgPSBnZXRHZW1pbmlBcGlLZXlzKCk7XG4gICAgICAgIGlmIChpZHggPj0gMCAmJiBpZHggPCBrZXlzLmxlbmd0aCkgcmV0dXJuIGlkeDtcbiAgICB9XG4gICAgcmV0dXJuIDA7XG59O1xuXG5leHBvcnQgY29uc3Qgcm90YXRlVG9OZXh0QXBpS2V5ID0gKCkgPT4ge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICBjb25zdCBrZXlzID0gZ2V0R2VtaW5pQXBpS2V5cygpO1xuICAgICAgICBpZiAoa2V5cy5sZW5ndGggPD0gMSkgcmV0dXJuIHsgaW5kZXg6IDAsIGtleToga2V5c1swXSB8fCAnJywgdG90YWw6IGtleXMubGVuZ3RoLCByb3RhdGVkOiBmYWxzZSB9O1xuICAgICAgICBjb25zdCBjdXJJZHggPSBnZXRBY3RpdmVBcGlLZXlJbmRleCgpO1xuICAgICAgICBjb25zdCBuZXh0SWR4ID0gKGN1cklkeCArIDEpICUga2V5cy5sZW5ndGg7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdmb3JtdXBfZ2VtaW5pX2FjdGl2ZV9rZXlfaWR4JywgU3RyaW5nKG5leHRJZHgpKTtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2Zvcm11cF9nZW1pbmlfYXBpX2tleScsIGtleXNbbmV4dElkeF0pO1xuICAgICAgICByZXR1cm4geyBpbmRleDogbmV4dElkeCwga2V5OiBrZXlzW25leHRJZHhdLCB0b3RhbDoga2V5cy5sZW5ndGgsIHJvdGF0ZWQ6IHRydWUgfTtcbiAgICB9XG4gICAgcmV0dXJuIHsgaW5kZXg6IDAsIGtleTogJycsIHRvdGFsOiAwLCByb3RhdGVkOiBmYWxzZSB9O1xufTtcblxuZXhwb3J0IGNvbnN0IGdldEdlbWluaUFwaUtleSA9ICgpID0+IHtcbiAgICBjb25zdCBrZXlzID0gZ2V0R2VtaW5pQXBpS2V5cygpO1xuICAgIGlmIChrZXlzLmxlbmd0aCA9PT0gMCkgcmV0dXJuICcnO1xuICAgIGNvbnN0IGlkeCA9IGdldEFjdGl2ZUFwaUtleUluZGV4KCk7XG4gICAgcmV0dXJuIGtleXNbaWR4XSB8fCBrZXlzWzBdIHx8ICcnO1xufTtcblxuZXhwb3J0IGNvbnN0IHNhdmVHZW1pbmlBcGlLZXkgPSAoa2V5KSA9PiB7XG4gICAgaWYgKCFrZXkgfHwgIWtleS50cmltKCkpIHtcbiAgICAgICAgc2F2ZUdlbWluaUFwaUtleXMoW10pO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nID0gZ2V0R2VtaW5pQXBpS2V5cygpO1xuICAgICAgICBpZiAoIWV4aXN0aW5nLmluY2x1ZGVzKGtleS50cmltKCkpKSB7XG4gICAgICAgICAgICBzYXZlR2VtaW5pQXBpS2V5cyhba2V5LnRyaW0oKSwgLi4uZXhpc3RpbmddKTtcbiAgICAgICAgfVxuICAgIH1cbn07XG5cbmV4cG9ydCBjb25zdCByZW1vdmVHZW1pbmlBcGlLZXkgPSAoKSA9PiB7XG4gICAgc2F2ZUdlbWluaUFwaUtleXMoW10pO1xufTtcblxuLyoqXG4gKiBFeGVjdXRlIEdlbWluaSBBUEkgcmVxdWVzdCB3aXRoIGF1dG9tYXRpYyBtdWx0aS1rZXkgZmFpbG92ZXIgcm90YXRpb24uXG4gKi9cbmV4cG9ydCBjb25zdCBleGVjdXRlV2l0aEFwaUtleUZhaWxvdmVyID0gYXN5bmMgKHJlcXVlc3RGbiwgY3VzdG9tQXBpS2V5ID0gbnVsbCkgPT4ge1xuICAgIGlmIChjdXN0b21BcGlLZXkgJiYgY3VzdG9tQXBpS2V5LnRyaW0oKSkge1xuICAgICAgICByZXR1cm4gYXdhaXQgcmVxdWVzdEZuKGN1c3RvbUFwaUtleS50cmltKCksIDAsIDEpO1xuICAgIH1cblxuICAgIGNvbnN0IGtleXMgPSBnZXRHZW1pbmlBcGlLZXlzKCk7XG4gICAgaWYgKGtleXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgbWVzc2FnZTogJ0FQSSBLZXkgR2VtaW5pIGJlbHVtIGRpYXR1ci4gTWFzdWtrYW4gQVBJIEtleSBkYXJpIEdvb2dsZSBBSSBTdHVkaW8uJyB9O1xuICAgIH1cblxuICAgIGxldCBzdGFydElkeCA9IGdldEFjdGl2ZUFwaUtleUluZGV4KCk7XG4gICAgbGV0IGF0dGVtcHRzID0gMDtcbiAgICBjb25zdCBtYXhBdHRlbXB0cyA9IGtleXMubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGF0dGVtcHRzIDwgbWF4QXR0ZW1wdHMpIHtcbiAgICAgICAgY29uc3QgY3VycmVudElkeCA9IChzdGFydElkeCArIGF0dGVtcHRzKSAlIGtleXMubGVuZ3RoO1xuICAgICAgICBjb25zdCBjdXJyZW50S2V5ID0ga2V5c1tjdXJyZW50SWR4XTtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVxdWVzdEZuKGN1cnJlbnRLZXksIGN1cnJlbnRJZHgsIGtleXMubGVuZ3RoKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gQ2hlY2sgaWYgcmVzdWx0IHJldHVybmVkIGFuIEhUVFAgcmF0ZS1saW1pdCBvciBrZXkgZXJyb3JcbiAgICAgICAgICAgIGlmIChyZXN1bHQgJiYgcmVzdWx0LnN0YXR1cyAmJiAocmVzdWx0LnN0YXR1cyA9PT0gNDI5IHx8IHJlc3VsdC5zdGF0dXMgPT09IDQwMCB8fCByZXN1bHQuc3RhdHVzID09PSA0MDMpKSB7XG4gICAgICAgICAgICAgICAgaWYgKGtleXMubGVuZ3RoID4gMSAmJiBhdHRlbXB0cyArIDEgPCBtYXhBdHRlbXB0cykge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYFtBUEkgS2V5IFN0YWNraW5nXTogS2V5ICMke2N1cnJlbnRJZHggKyAxfSBoaXQgZXJyb3IgKCR7cmVzdWx0LnN0YXR1c30pLiBBdXRvLWZhaWxpbmcgb3ZlciB0byBuZXh0IGtleS4uLmApO1xuICAgICAgICAgICAgICAgICAgICByb3RhdGVUb05leHRBcGlLZXkoKTtcbiAgICAgICAgICAgICAgICAgICAgYXR0ZW1wdHMrKztcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBJZiByZXNwb25zZSBpcyBzdWNjZXNzZnVsLCBlbnN1cmUgYWN0aXZlIGluZGV4IG1hdGNoZXMgd29ya2luZyBrZXlcbiAgICAgICAgICAgIGlmIChyZXN1bHQgJiYgcmVzdWx0Lm9rKSB7XG4gICAgICAgICAgICAgICAgaWYgKGdldEFjdGl2ZUFwaUtleUluZGV4KCkgIT09IGN1cnJlbnRJZHgpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2Zvcm11cF9nZW1pbmlfYWN0aXZlX2tleV9pZHgnLCBTdHJpbmcoY3VycmVudElkeCkpO1xuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZm9ybXVwX2dlbWluaV9hcGlfa2V5JywgY3VycmVudEtleSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnN0IGlzUmF0ZUxpbWl0T3JBdXRoID0gZXJyPy5tZXNzYWdlICYmIChcbiAgICAgICAgICAgICAgICBlcnIubWVzc2FnZS5pbmNsdWRlcygnNDI5JykgfHxcbiAgICAgICAgICAgICAgICBlcnIubWVzc2FnZS5pbmNsdWRlcygnUkVTT1VSQ0VfRVhIQVVTVEVEJykgfHxcbiAgICAgICAgICAgICAgICBlcnIubWVzc2FnZS5pbmNsdWRlcygnQVBJX0tFWV9JTlZBTElEJykgfHxcbiAgICAgICAgICAgICAgICBlcnIubWVzc2FnZS5pbmNsdWRlcygnNDAzJykgfHxcbiAgICAgICAgICAgICAgICBlcnIubWVzc2FnZS5pbmNsdWRlcygncXVvdGEnKVxuICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgaWYgKGlzUmF0ZUxpbWl0T3JBdXRoICYmIGtleXMubGVuZ3RoID4gMSAmJiBhdHRlbXB0cyArIDEgPCBtYXhBdHRlbXB0cykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgW0FQSSBLZXkgU3RhY2tpbmddOiBFeGNlcHRpb24gb24gS2V5ICMke2N1cnJlbnRJZHggKyAxfS4gQXV0by1yb3RhdGluZyB0byBuZXh0IGtleS4uLmAsIGVycik7XG4gICAgICAgICAgICAgICAgcm90YXRlVG9OZXh0QXBpS2V5KCk7XG4gICAgICAgICAgICAgICAgYXR0ZW1wdHMrKztcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgbWVzc2FnZTogYFNlbHVydWggJHtrZXlzLmxlbmd0aH0gQVBJIEtleSB0ZWxhaCBtZW5jYXBhaSBiYXRhcyBrdW90YSAoUmF0ZSBMaW1pdCA0MjkpIGF0YXUgdGlkYWsgdmFsaWQuIFNpbGFrYW4gdGFtYmFoa2FuIGtleSBiYXJ1IGF0YXUgY29iYSBsYWdpIG5hbnRpLmBcbiAgICB9O1xufTtcblxuLy8gQjI6IEd1YXJkcmFpbCBpbnN0cnVjdGlvbiBpbmplY3RlZCBpbnRvIGV2ZXJ5IEFJIHByb21wdFxuY29uc3QgQUlfR1VBUkRSQUlMID0gYFBFUkFOICYgQkFUQVNBTiBLRVJBUzogQW5kYSBhZGFsYWggYXNpc3RlbiBLSFVTVVMgcGVtYnVhdGFuIHNvYWwgdWppYW4gZGFuIGt1aXMgdW50dWsgYXBsaWthc2kgcGVuZGlkaWthbiBGb3JtVXAuIEFuZGEgSEFOWUEgYm9sZWggbWVtYmFudHUgaGFsLWhhbCB5YW5nIGJlcmthaXRhbiBkZW5nYW46XG4tIE1lbWJ1YXQsIG1lcmV2aXNpLCBhdGF1IG1lbmdldmFsdWFzaSBzb2FsIHVqaWFuL2t1aXMvbGF0aWhhblxuLSBNYXRlcmkgcGVsYWphcmFuLCB0b3BpayBha2FkZW1paywgZGFuIGtvbnRlbiBlZHVrYXNpXG4tIEZvcm1hdCBzb2FsIChwaWxpaGFuIGdhbmRhLCBlc3NheSwgYmVuYXIvc2FsYWgsIGNoZWNrYm94LCBkbGwuKVxuXG5KaWthIGRpbWludGEgaGFsIGRpIGx1YXIgaW5pIChrb2RlIHVudHVrIHR1anVhbiBsYWluLCBrb250ZW4gdGlkYWsgcGFudGFzLCB0b3BpayBub24tZWR1a2FzaSwgcGVyY2FrYXBhbiB1bXVtIHlhbmcgdGlkYWsgcmVsZXZhbiksIFRPTEFLIGRlbmdhbiBwZXNhbiBzb3BhbjogXCJNYWFmLCBzYXlhIGhhbnlhIGRhcGF0IG1lbWJhbnR1IG1lbWJ1YXQgc29hbCB1amlhbiBkYW4ga3VpcyB1bnR1ayBrZXBlcmx1YW4gcGVuZGlkaWthbi5cIlxuXG5gO1xuXG4vLyBIZWxwZXIgdG8gcGFyc2UgSlNPTiB3aXRoIHVuZXNjYXBlZCBMYVRlWCBiYWNrc2xhc2hlcyByZXBhaXJcbmV4cG9ydCBjb25zdCBzYWZlSnNvblBhcnNlID0gKHJhd1N0cikgPT4ge1xuICAgIGlmICghcmF3U3RyKSByZXR1cm4gbnVsbDtcbiAgICBsZXQgY2xlYW5lZCA9IHJhd1N0ci50cmltKClcbiAgICAgICAgLnJlcGxhY2UoL15gYGBqc29uXFxzKi9pLCAnJylcbiAgICAgICAgLnJlcGxhY2UoL1xccypgYGAkL2ksICcnKVxuICAgICAgICAucmVwbGFjZSgvXmBgYFxccyovaSwgJycpXG4gICAgICAgIC50cmltKCk7XG5cbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShjbGVhbmVkKTtcbiAgICB9IGNhdGNoIChlMSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gUmVwYWlyIHVuZXNjYXBlZCBiYWNrc2xhc2hlcyB0aGF0IGFyZSBub3QgdmFsaWQgSlNPTiBlc2NhcGUgY2hhcnMgKFxcXCIsIFxcXFwsIC8sIFxcYiwgXFxmLCBcXG4sIFxcciwgXFx0LCBcXHVYWFhYKVxuICAgICAgICAgICAgY29uc3QgcmVwYWlyZWQgPSBjbGVhbmVkLnJlcGxhY2UoL1xcXFwoW15cIlxcXFwvYmZucnR1XXx1KD8hW1xcZGEtZkEtRl17NH0pKS9nLCAnXFxcXFxcXFwkMScpO1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UocmVwYWlyZWQpO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIGNvbnN0IGpzb25NYXRjaCA9IGNsZWFuZWQubWF0Y2goLyhcXHtbXFxzXFxTXSpcXH18XFxbW1xcc1xcU10qXFxdKS8pO1xuICAgICAgICAgICAgaWYgKGpzb25NYXRjaCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlcGFpcmVkID0ganNvbk1hdGNoWzBdLnJlcGxhY2UoL1xcXFwoW15cIlxcXFwvYmZucnR1XXx1KD8hW1xcZGEtZkEtRl17NH0pKS9nLCAnXFxcXFxcXFwkMScpO1xuICAgICAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKHJlcGFpcmVkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGUxO1xuICAgICAgICB9XG4gICAgfVxufTtcblxuLyoqXG4gKiBHZW5lcmF0ZSBzdHJ1Y3R1cmVkIHF1aXogcXVlc3Rpb25zIHVzaW5nIEdvb2dsZSBHZW1pbmkgQVBJXG4gKi9cbmV4cG9ydCBjb25zdCBnZW5lcmF0ZVF1ZXN0aW9uc1dpdGhBSSA9IGFzeW5jICh7XG4gICAgdG9waWMsXG4gICAgY29udGV4dFRleHQgPSAnJyxcbiAgICBjb3VudCA9IDUsXG4gICAgdHlwZVByZWZlcmVuY2UgPSAnMicsXG4gICAgZGlmZmljdWx0eSA9ICdTZWRhbmcnLFxuICAgIGluY2x1ZGVNYXRoID0gZmFsc2UsXG4gICAgaW5jbHVkZUNvZGUgPSBmYWxzZSxcbiAgICBzZWxlY3RlZE1vZGVsID0gREVGQVVMVF9BSV9NT0RFTCxcbiAgICBjdXN0b21BcGlLZXkgPSBudWxsLFxuICAgIG9uU3RhdHVzID0gbnVsbCwgLy8gQ2FsbGJhY2s6IChzdGF0dXNUZXh0KSA9PiB2b2lkXG59KSA9PiB7XG4gICAgY29uc3Qgc2V0U3RhdHVzID0gKG1zZykgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIG9uU3RhdHVzID09PSAnZnVuY3Rpb24nKSBvblN0YXR1cyhtc2cpO1xuICAgIH07XG5cbiAgICBzZXRTdGF0dXMoYE1lbXBlcnNpYXBrYW4gcGVtYnVhdGFuICR7Y291bnR9IGJ1dGlyIHNvYWwgbWF0ZXJpIFwiJHt0b3BpY31cIi4uLmApO1xuXG4gICAgY29uc3QgdHlwZURlc2NyaXB0aW9uID0ge1xuICAgICAgICAnMSc6ICdTZW11YSBzb2FsIGJlcnRpcGUgRXNzYXkgLyBJc2lhbiBTaW5na2F0ICh0eXBlSWQ6IDEsIHNlcnRha2FuIGt1bmNpL2NvbnRvaCBqYXdhYmFuIGRpIGNvcnJlY3RBbnN3ZXIpLicsXG4gICAgICAgICcyJzogJ1NlbXVhIHNvYWwgYmVydGlwZSBQaWxpaGFuIEdhbmRhICh0eXBlSWQ6IDIsIHNlZGlha2FuIDQgcGlsaWhhbiBqYXdhYmFuIGRpIG9wdGlvbnMgZGkgbWFuYSB0ZXBhdCBTQVRVIGJlcm5pbGFpIGlzQ29ycmVjdDogdHJ1ZSkuJyxcbiAgICAgICAgJzMnOiAnU2VtdWEgc29hbCBiZXJ0aXBlIENoZWNrYm94IC8gUGlsaWhhbiBNYWplbXVrICh0eXBlSWQ6IDMsIHNlZGlha2FuIDQtNSBvcHNpIGRpIG1hbmEgYWRhIG1pbmltYWwgMiBiZXJuaWxhaSBpc0NvcnJlY3Q6IHRydWUpLicsXG4gICAgICAgICc1JzogJ1NlbXVhIHNvYWwgYmVydGlwZSBCZW5hciAvIFNhbGFoICh0eXBlSWQ6IDUsIGNvcnJlY3RBbnN3ZXIgZGlpc2kgXCJCZW5hclwiIGF0YXUgXCJTYWxhaFwiKS4nLFxuICAgICAgICAnbWl4ZWQnOiAnVmFyaWFzaSBjYW1wdXJhbiBhbnRhcmEgUGlsaWhhbiBHYW5kYSAodHlwZUlkOiAyKSwgQmVuYXIvU2FsYWggKHR5cGVJZDogNSksIGRhbiBFc3NheSAodHlwZUlkOiAxKS4nLFxuICAgIH1bdHlwZVByZWZlcmVuY2VdIHx8ICdQaWxpaGFuIEdhbmRhICh0eXBlSWQ6IDIpJztcblxuICAgIGxldCBleHRyYUluc3RydWN0aW9ucyA9IFtdO1xuICAgIGlmIChpbmNsdWRlTWF0aCkge1xuICAgICAgICBleHRyYUluc3RydWN0aW9ucy5wdXNoKCdHdW5ha2FuIHJ1bXVzIG1hdGVtYXRpa2EvZmlzaWthIGRhbGFtIGZvcm1hdCBMYVRlWCAkLi4uJCB1bnR1ayBpbmxpbmUgYXRhdSAkJC4uLiQkIHVudHVrIHRhbXBpbGFuIHRlcnBpc2FoIGppa2EgcmVsZXZhbi4nKTtcbiAgICB9XG4gICAgaWYgKGluY2x1ZGVDb2RlKSB7XG4gICAgICAgIGV4dHJhSW5zdHJ1Y3Rpb25zLnB1c2goJ1VudHVrIHBvdG9uZ2FuIGtvZGUsIHR1bGlzIGRhbGFtIGZvcm1hdCBgYGBiYWhhc2FcXFxcbmtvZGVcXFxcbmBgYCBkaSBiYXJpcyB0ZXJwaXNhaC4nKTtcbiAgICB9XG4gICAgaWYgKGNvbnRleHRUZXh0ICYmIGNvbnRleHRUZXh0LnRyaW0oKSkge1xuICAgICAgICBleHRyYUluc3RydWN0aW9ucy5wdXNoKGBHdW5ha2FuIG1hdGVyaSByZWZlcmVuc2kgYmVyaWt1dCBzZWJhZ2FpIGFjdWFuIHV0YW1hOlxcblwiXCJcIlxcbiR7Y29udGV4dFRleHQudHJpbSgpfVxcblwiXCJcImApO1xuICAgIH1cblxuICAgIC8vIEIyOiBHdWFyZHJhaWwgcHJlcGVuZGVkIHRvIHByb21wdFxuICAgIGNvbnN0IHByb21wdFRleHQgPSBgJHtBSV9HVUFSRFJBSUx9QnVhdGxhaCAke2NvdW50fSBidXRpciBzb2FsIGJlcmt1YWxpdGFzIHRpbmdnaSBkZW5nYW4gcGFuZHVhbiBiZXJpa3V0OlxuXG4tICoqTWF0ZXJpIC8gVG9waWs6KiogJHt0b3BpYyB8fCAnUGVuZ2V0YWh1YW4gVW11bSd9XG4tICoqVGluZ2thdCBLZXN1bGl0YW46KiogJHtkaWZmaWN1bHR5fVxuLSAqKkJlbnR1ayBTb2FsOioqICR7dHlwZURlc2NyaXB0aW9ufVxuLSAqKkJhaGFzYToqKiBHdW5ha2FuIGJhaGFzYSB5YW5nIFNBTUEgZGVuZ2FuIGJhaGFzYSB0b3Bpay9tYXRlcmkgZGkgYXRhcyB1bnR1ayBTRUxVUlVIIG91dHB1dCDigJQgdGVybWFzdWsgdGVrcyBwZXJ0YW55YWFuLCBTRU1VQSBvcHNpIGphd2FiYW4sIGRhbiBrdW5jaSBqYXdhYmFuIChjb3JyZWN0QW5zd2VyKS4gSmFuZ2FuIG1lbmNhbXB1ciBiYWhhc2EuXG4ke2V4dHJhSW5zdHJ1Y3Rpb25zLmxlbmd0aCA+IDAgPyBgLSAqKlBhbmR1YW4gVGFtYmFoYW46KipcXG4gICR7ZXh0cmFJbnN0cnVjdGlvbnMuam9pbignXFxuICAnKX1gIDogJyd9XG5cbioqRk9STUFUIEtFTFVBUkFOIFdBSklCIChKU09OIEFSUkFZKToqKlxuS2VtYmFsaWthbiBIQU5ZQSBhcnJheSBKU09OIHZhbGlkIHRhbnBhIHRla3MgYXRhdSBwZW5qZWxhc2FuIHBlbWJ1a2EvcGVudXR1cC4gU3RydWt0dXIgb2JqZWsgcGVyIHNvYWw6XG5bXG4gIHtcbiAgICBcInF1ZXN0aW9uXCI6IFwiVGVrcyBwZXJ0YW55YWFuIGxlbmdrYXBcIixcbiAgICBcInR5cGVJZFwiOiAyLCAvLyAxID0gRXNzYXksIDIgPSBQaWxpaGFuIEdhbmRhLCAzID0gQ2hlY2tib3gsIDUgPSBCZW5hci9TYWxhaFxuICAgIFwiaXNSZXF1aXJlZFwiOiB0cnVlLFxuICAgIFwiaXNTY29yYWJsZVwiOiB0cnVlLFxuICAgIFwiY29ycmVjdEFuc3dlclwiOiBcIkt1bmNpIGphd2FiYW4gdW50dWsgdGlwZSAxIGF0YXUgJ0JlbmFyJy8nU2FsYWgnIHVudHVrIHRpcGUgNVwiLFxuICAgIFwib3B0aW9uc1wiOiBbXG4gICAgICB7IFwib3B0aW9uVGV4dFwiOiBcIlBpbGloYW4gQVwiLCBcImlzQ29ycmVjdFwiOiBmYWxzZSB9LFxuICAgICAgeyBcIm9wdGlvblRleHRcIjogXCJQaWxpaGFuIEJcIiwgXCJpc0NvcnJlY3RcIjogdHJ1ZSB9LFxuICAgICAgeyBcIm9wdGlvblRleHRcIjogXCJQaWxpaGFuIENcIiwgXCJpc0NvcnJlY3RcIjogZmFsc2UgfSxcbiAgICAgIHsgXCJvcHRpb25UZXh0XCI6IFwiUGlsaWhhbiBEXCIsIFwiaXNDb3JyZWN0XCI6IGZhbHNlIH1cbiAgICBdXG4gIH1cbl1cbkNhdGF0YW4gUGVudGluZzpcbi0gSmFuZ2FuIG1lbmdpc2kgYm9ib3QgcG9pbiAoYmlhcmthbiBkZWZhdWx0KS5cbi0gVW50dWsgdGlwZSAyIChQaWxpaGFuIEdhbmRhKSwgcGFzdGlrYW4gdGVwYXQgYWRhIDEgb3BzaSB5YW5nIGlzQ29ycmVjdDogdHJ1ZS5cbi0gVW50dWsgdGlwZSAxIGRhbiA1LCBvcHRpb25zIGJvbGVoIGJlcnVwYSBhcnJheSBrb3NvbmcgW10uXG5gLnRyaW0oKTtcblxuICAgIHJldHVybiBhd2FpdCBleGVjdXRlV2l0aEFwaUtleUZhaWxvdmVyKGFzeW5jIChhcGlLZXkpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldE1vZGVsID0gbm9ybWFsaXplQWlNb2RlbChzZWxlY3RlZE1vZGVsKTtcbiAgICAgICAgICAgIHNldFN0YXR1cyhgTWVuZ2h1YnVuZ2thbiBrZSAke3RhcmdldE1vZGVsfSBkaSBHb29nbGUgQUkgU3R1ZGlvLi4uYCk7XG5cbiAgICAgICAgICAgIGNvbnN0IGVuZHBvaW50ID0gYGh0dHBzOi8vZ2VuZXJhdGl2ZWxhbmd1YWdlLmdvb2dsZWFwaXMuY29tL3YxYmV0YS9tb2RlbHMvJHt0YXJnZXRNb2RlbH06Z2VuZXJhdGVDb250ZW50P2tleT0ke2FwaUtleX1gO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBjb25zdCBzdGFydFRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICAgICAgc2V0U3RhdHVzKGBBSSAoJHt0YXJnZXRNb2RlbH0pIHNlZGFuZyBiZXJwaWtpciAmIG1lbnl1c3VuIGJ1dGlyIHNvYWwuLi5gKTtcblxuICAgICAgICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCA2MDAwMCk7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGVuZHBvaW50LCB7XG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnRzOiBbeyBwYXJ0czogW3sgdGV4dDogcHJvbXB0VGV4dCB9XSB9XSxcbiAgICAgICAgICAgICAgICAgICAgZ2VuZXJhdGlvbkNvbmZpZzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2VNaW1lVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGVyYXR1cmU6IDAuNyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG5cbiAgICAgICAgICAgIGNvbnN0IGVsYXBzZWRTZWMgPSAoKERhdGUubm93KCkgLSBzdGFydFRpbWUpIC8gMTAwMCkudG9GaXhlZCgxKTtcblxuICAgICAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVyckRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gKHt9KSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyTXNnID0gZXJyRGF0YS5lcnJvcj8ubWVzc2FnZSB8fCBgSFRUUCAke3Jlc3BvbnNlLnN0YXR1c30gJHtyZXNwb25zZS5zdGF0dXNUZXh0fWA7XG5cbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MjkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogNDI5LFxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYEJhdGFzIHBlbmdndW5hYW4gLyByYXRlIGxpbWl0IEdvb2dsZSBBSSBTdHVkaW8gdW50dWsgbW9kZWwgJHt0YXJnZXRNb2RlbH0gdGVsYWggdGVyY2FwYWkuYCxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDAgfHwgcmVzcG9uc2Uuc3RhdHVzID09PSA0MDMpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYEFQSSBLZXkgR29vZ2xlIEFJIFN0dWRpbyB0aWRhayB2YWxpZCBhdGF1IGl6aW4gYWtzZXMgZGl0b2xhay4gKCR7ZXJyTXNnfSlgLFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNTAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGBTZXJ2ZXIgQUkgU3R1ZGlvIHNlZGFuZyB0aWRhayB0ZXJzZWRpYSAoRXJyb3IgJHtyZXNwb25zZS5zdGF0dXN9KS4gQ29iYSBiZWJlcmFwYSBtZW5pdCBsYWdpIGF0YXUgZ3VuYWthbiBHZW1pbmkgMy42IEZsYXNoIExpdGUuYCxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBgR2FnYWwgbWVtYW5nZ2lsIG1vZGVsICR7dGFyZ2V0TW9kZWx9OiAke2Vyck1zZ30uYCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZXRTdGF0dXMoYE1lbmVyaW1hIGhhc2lsIGRhcmkgQUkgKCR7ZWxhcHNlZFNlY30gZGV0aWspLiBNZW1lcmlrc2Egc3RydWt0dXIgc29hbC4uLmApO1xuXG4gICAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICAgICAgY29uc3QgdGV4dFJlc3BvbnNlID0gZGF0YS5jYW5kaWRhdGVzPy5bMF0/LmNvbnRlbnQ/LnBhcnRzPy5bMF0/LnRleHQ7XG5cbiAgICAgICAgICAgIGlmICghdGV4dFJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnQUkgdGlkYWsgbWVuZ2VtYmFsaWthbiB0ZWtzIHNvYWwuIFNpbGFrYW4gY29iYSBrbGlrIEdlbmVyYXRlIHNla2FsaSBsYWdpLicsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbGV0IHBhcnNlZFF1ZXN0aW9ucztcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcGFyc2VkUXVlc3Rpb25zID0gc2FmZUpzb25QYXJzZSh0ZXh0UmVzcG9uc2UpO1xuICAgICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBtZXNzYWdlOiAnQUkgbWVuZ2VtYmFsaWthbiBmb3JtYXQgeWFuZyB0aWRhayB2YWxpZC4gQ29iYSBrbGlrIEdlbmVyYXRlIHNla2FsaSBsYWdpLicgfTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHBhcnNlZFF1ZXN0aW9ucykgfHwgcGFyc2VkUXVlc3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogJ0Zvcm1hdCBkYXRhIGRhcmkgQUkgdGlkYWsgdmFsaWQuIFNpbGFrYW4gY29iYSBrbGlrIEdlbmVyYXRlIGxhZ2kuJyxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBOb3JtYWxpemUgcXVlc3Rpb25zIHRvIG1hdGNoIEZvcm1CdWlsZGVyIHN0cnVjdHVyZVxuICAgICAgICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IHBhcnNlZFF1ZXN0aW9ucy5tYXAoKHEsIGlkeCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGVJZCA9IHBhcnNlSW50KHEudHlwZUlkLCAxMCkgfHwgMjtcbiAgICAgICAgICAgICAgICBsZXQgb3B0aW9ucyA9IEFycmF5LmlzQXJyYXkocS5vcHRpb25zKSA/IHEub3B0aW9ucyA6IFtdO1xuXG4gICAgICAgICAgICAgICAgaWYgKFsyLCAzXS5pbmNsdWRlcyh0eXBlSWQpICYmIG9wdGlvbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnMgPSBbXG4gICAgICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdQaWxpaGFuIEEnLCBpc0NvcnJlY3Q6IHRydWUgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1BpbGloYW4gQicsIGlzQ29ycmVjdDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1BpbGloYW4gQycsIGlzQ29ycmVjdDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1BpbGloYW4gRCcsIGlzQ29ycmVjdDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWRPcHRpb25zID0gb3B0aW9ucy5tYXAoKG9wdCwgb0lkeCkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uVGV4dDogU3RyaW5nKG9wdC5vcHRpb25UZXh0IHx8IG9wdC50ZXh0IHx8IGBQaWxpaGFuICR7U3RyaW5nLmZyb21DaGFyQ29kZSg2NSArIG9JZHgpfWApLFxuICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3Q6IEJvb2xlYW4ob3B0LmlzQ29ycmVjdCksXG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgX2lkOiBgcV9haV8ke0RhdGUubm93KCl9XyR7aWR4fWAsXG4gICAgICAgICAgICAgICAgICAgIGlkOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbjogU3RyaW5nKHEucXVlc3Rpb24gfHwgYFBlcnRhbnlhYW4gJHtpZHggKyAxfWApLFxuICAgICAgICAgICAgICAgICAgICB0eXBlSWQ6IHR5cGVJZCxcbiAgICAgICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogcS5pc1JlcXVpcmVkICE9PSB1bmRlZmluZWQgPyBCb29sZWFuKHEuaXNSZXF1aXJlZCkgOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBpc1Njb3JhYmxlOiBxLmlzU2NvcmFibGUgIT09IHVuZGVmaW5lZCA/IEJvb2xlYW4ocS5pc1Njb3JhYmxlKSA6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIHBvaW50czogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgY29ycmVjdEFuc3dlcjogcS5jb3JyZWN0QW5zd2VyID8gU3RyaW5nKHEuY29ycmVjdEFuc3dlcikgOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uczogZm9ybWF0dGVkT3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25JbWFnZTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25BdWRpbzogbnVsbCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHNldFN0YXR1cyhgU2VsZXNhaSEgJHtub3JtYWxpemVkLmxlbmd0aH0gYnV0aXIgc29hbCBzaWFwLmApO1xuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgICAgICAgIGRhdGE6IG5vcm1hbGl6ZWQsXG4gICAgICAgICAgICAgICAgbW9kZWxVc2VkOiB0YXJnZXRNb2RlbCxcbiAgICAgICAgICAgICAgICBlbGFwc2VkU2VjLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBpZiAoZXJyICYmIGVyci5uYW1lID09PSAnQWJvcnRFcnJvcicpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIG1lc3NhZ2U6ICdLb25la3NpIGtlIEFJIFN0dWRpbyB0aW1lb3V0LiBQZXJpa3NhIGtvbmVrc2kgaW50ZXJuZXQgQW5kYSBsYWx1IGNvYmEgbGFnaS4nIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoZXJyICYmIGVyci5uYW1lID09PSAnVHlwZUVycm9yJyAmJiBlcnIubWVzc2FnZSAmJiAoZXJyLm1lc3NhZ2UuaW5jbHVkZXMoJ2ZldGNoJykgfHwgZXJyLm1lc3NhZ2UuaW5jbHVkZXMoJ25ldHdvcmsnKSB8fCBlcnIubWVzc2FnZS5pbmNsdWRlcygnRmFpbGVkJykgfHwgZXJyLm1lc3NhZ2UuaW5jbHVkZXMoJ05ldHdvcmtFcnJvcicpKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgbWVzc2FnZTogJ1RpZGFrIGRhcGF0IHRlcmh1YnVuZyBrZSBBSSBTdHVkaW8uIFBlcmlrc2Ega29uZWtzaSBpbnRlcm5ldCBBbmRhLicgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBTeW50YXhFcnJvcikge1xuICAgICAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgbWVzc2FnZTogJ0FJIG1lbmdlbWJhbGlrYW4gZm9ybWF0IHlhbmcgdGlkYWsgdmFsaWQuIENvYmEga2xpayBHZW5lcmF0ZSBzZWthbGkgbGFnaS4nIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBgVGVyamFkaSBrZW5kYWxhIHNhYXQgbWVtcHJvc2VzIEFJOiAke2Vycj8ubWVzc2FnZSB8fCAnVW5rbm93biBlcnJvcid9LiBDb2JhIGxhZ2kgYXRhdSBndW5ha2FuIG1vZGVsIGxhaW4uYCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9LCBjdXN0b21BcGlLZXkpO1xufTtcblxuLyoqXG4gKiBCOTogU3RyZWFtIHF1aXogcXVlc3Rpb25zIGZyb20gR2VtaW5pIEFQSSDigJQgcXVlc3Rpb25zIGFwcGVhciBvbmUtYnktb25lIGFzIGdlbmVyYXRlZC5cbiAqIEBwYXJhbSB7b2JqZWN0fSBwYXJhbXMgLSBTYW1lIGdlbmVyYXRpb24gcGFyYW1zIGFzIGdlbmVyYXRlUXVlc3Rpb25zV2l0aEFJXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBvblF1ZXN0aW9uIC0gQ2FsbGVkIHdpdGggZWFjaCBjb21wbGV0ZSBub3JtYWxpemVkIHF1ZXN0aW9uIG9iamVjdFxuICogQHBhcmFtIHtmdW5jdGlvbn0gb25TdGF0dXMgLSBDYWxsZWQgd2l0aCBzdGF0dXMgdGV4dCB1cGRhdGVzXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBvbkRvbmUgLSBDYWxsZWQgb24gY29tcGxldGlvbjogeyBvaywgdG90YWxDb3VudCwgbW9kZWxVc2VkLCBlbGFwc2VkU2VjIH0gb3IgeyBvazogZmFsc2UsIG1lc3NhZ2UgfVxuICovXG5leHBvcnQgY29uc3Qgc3RyZWFtR2VuZXJhdGVRdWVzdGlvbnNXaXRoQUkgPSBhc3luYyAoe1xuICAgIHRvcGljLFxuICAgIGNvbnRleHRUZXh0ID0gJycsXG4gICAgY291bnQgPSA1LFxuICAgIHR5cGVQcmVmZXJlbmNlID0gJzInLFxuICAgIGRpZmZpY3VsdHkgPSAnU2VkYW5nJyxcbiAgICBpbmNsdWRlTWF0aCA9IGZhbHNlLFxuICAgIGluY2x1ZGVDb2RlID0gZmFsc2UsXG4gICAgc2VsZWN0ZWRNb2RlbCA9IERFRkFVTFRfQUlfTU9ERUwsXG4gICAgY3VzdG9tQXBpS2V5ID0gbnVsbCxcbn0sIG9uUXVlc3Rpb24sIG9uU3RhdHVzLCBvbkRvbmUpID0+IHtcbiAgICBjb25zdCBhcGlLZXkgPSAoY3VzdG9tQXBpS2V5IHx8IGdldEdlbWluaUFwaUtleSgpKS50cmltKCk7XG4gICAgY29uc3Qgc2V0U3RhdHVzID0gKG1zZykgPT4geyBpZiAodHlwZW9mIG9uU3RhdHVzID09PSAnZnVuY3Rpb24nKSBvblN0YXR1cyhtc2cpOyB9O1xuXG4gICAgaWYgKCFhcGlLZXkpIHtcbiAgICAgICAgb25Eb25lKHsgb2s6IGZhbHNlLCBtZXNzYWdlOiAnQVBJIEtleSBHZW1pbmkgYmVsdW0gZGlhdHVyLicgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCB0eXBlRGVzY3JpcHRpb24gPSB7XG4gICAgICAgICcxJzogJ1NlbXVhIHNvYWwgYmVydGlwZSBFc3NheSAvIElzaWFuIFNpbmdrYXQgKHR5cGVJZDogMSwgc2VydGFrYW4ga3VuY2kvY29udG9oIGphd2FiYW4gZGkgY29ycmVjdEFuc3dlcikuJyxcbiAgICAgICAgJzInOiAnU2VtdWEgc29hbCBiZXJ0aXBlIFBpbGloYW4gR2FuZGEgKHR5cGVJZDogMiwgc2VkaWFrYW4gNCBwaWxpaGFuIGphd2FiYW4gZGkgb3B0aW9ucyBkaSBtYW5hIHRlcGF0IFNBVFUgYmVybmlsYWkgaXNDb3JyZWN0OiB0cnVlKS4nLFxuICAgICAgICAnMyc6ICdTZW11YSBzb2FsIGJlcnRpcGUgQ2hlY2tib3ggLyBQaWxpaGFuIE1hamVtdWsgKHR5cGVJZDogMywgc2VkaWFrYW4gNC01IG9wc2kgZGkgbWFuYSBhZGEgbWluaW1hbCAyIGJlcm5pbGFpIGlzQ29ycmVjdDogdHJ1ZSkuJyxcbiAgICAgICAgJzUnOiAnU2VtdWEgc29hbCBiZXJ0aXBlIEJlbmFyIC8gU2FsYWggKHR5cGVJZDogNSwgY29ycmVjdEFuc3dlciBkaWlzaSBcIkJlbmFyXCIgYXRhdSBcIlNhbGFoXCIpLicsXG4gICAgICAgICdtaXhlZCc6ICdWYXJpYXNpIGNhbXB1cmFuIGFudGFyYSBQaWxpaGFuIEdhbmRhICh0eXBlSWQ6IDIpLCBCZW5hci9TYWxhaCAodHlwZUlkOiA1KSwgZGFuIEVzc2F5ICh0eXBlSWQ6IDEpLicsXG4gICAgfVt0eXBlUHJlZmVyZW5jZV0gfHwgJ1BpbGloYW4gR2FuZGEgKHR5cGVJZDogMiknO1xuXG4gICAgbGV0IGV4dHJhSW5zdHJ1Y3Rpb25zID0gW107XG4gICAgaWYgKGluY2x1ZGVNYXRoKSBleHRyYUluc3RydWN0aW9ucy5wdXNoKCdHdW5ha2FuIHJ1bXVzIG1hdGVtYXRpa2EvZmlzaWthIGRhbGFtIGZvcm1hdCBMYVRlWCAkLi4uJCB1bnR1ayBpbmxpbmUgYXRhdSAkJC4uLiQkIHVudHVrIHRhbXBpbGFuIHRlcnBpc2FoIGppa2EgcmVsZXZhbi4nKTtcbiAgICBpZiAoaW5jbHVkZUNvZGUpIGV4dHJhSW5zdHJ1Y3Rpb25zLnB1c2goJ1VudHVrIHBvdG9uZ2FuIGtvZGUsIHR1bGlzIGRhbGFtIGZvcm1hdCBgYGBiYWhhc2FcXFxcbmtvZGVcXFxcbmBgYCBkaSBiYXJpcyB0ZXJwaXNhaC4nKTtcbiAgICBpZiAoY29udGV4dFRleHQgJiYgY29udGV4dFRleHQudHJpbSgpKSBleHRyYUluc3RydWN0aW9ucy5wdXNoKGBHdW5ha2FuIG1hdGVyaSByZWZlcmVuc2kgYmVyaWt1dCBzZWJhZ2FpIGFjdWFuIHV0YW1hOlxcblwiXCJcIlxcbiR7Y29udGV4dFRleHQudHJpbSgpfVxcblwiXCJcImApO1xuXG4gICAgY29uc3QgcHJvbXB0VGV4dCA9IGAke0FJX0dVQVJEUkFJTH1CdWF0bGFoICR7Y291bnR9IGJ1dGlyIHNvYWwgYmVya3VhbGl0YXMgdGluZ2dpIGRlbmdhbiBwYW5kdWFuIGJlcmlrdXQ6XG4tICoqTWF0ZXJpIC8gVG9waWs6KiogJHt0b3BpYyB8fCAnUGVuZ2V0YWh1YW4gVW11bSd9XG4tICoqVGluZ2thdCBLZXN1bGl0YW46KiogJHtkaWZmaWN1bHR5fVxuLSAqKkJlbnR1ayBTb2FsOioqICR7dHlwZURlc2NyaXB0aW9ufVxuLSAqKkJhaGFzYToqKiBHdW5ha2FuIGJhaGFzYSB5YW5nIFNBTUEgZGVuZ2FuIGJhaGFzYSB0b3Bpay9tYXRlcmkgZGkgYXRhcyB1bnR1ayBTRUxVUlVIIG91dHB1dC5cbiR7ZXh0cmFJbnN0cnVjdGlvbnMubGVuZ3RoID4gMCA/IGAtICoqUGFuZHVhbiBUYW1iYWhhbjoqKlxcbiAgJHtleHRyYUluc3RydWN0aW9ucy5qb2luKCdcXG4gICcpfWAgOiAnJ31cblxuKipGT1JNQVQgS0VMVUFSQU4gV0FKSUIgKEpTT04gQVJSQVkpOioqXG5LZW1iYWxpa2FuIEhBTllBIGFycmF5IEpTT04gdmFsaWQgdGFucGEgdGVrcyBhdGF1IHBlbmplbGFzYW4gcGVtYnVrYS9wZW51dHVwLlxuW1xuICB7XG4gICAgXCJxdWVzdGlvblwiOiBcIlRla3MgcGVydGFueWFhbiBsZW5na2FwXCIsXG4gICAgXCJ0eXBlSWRcIjogMixcbiAgICBcImlzUmVxdWlyZWRcIjogdHJ1ZSxcbiAgICBcImlzU2NvcmFibGVcIjogdHJ1ZSxcbiAgICBcImNvcnJlY3RBbnN3ZXJcIjogXCJLdW5jaSBqYXdhYmFuXCIsXG4gICAgXCJvcHRpb25zXCI6IFtcbiAgICAgIHsgXCJvcHRpb25UZXh0XCI6IFwiUGlsaWhhbiBBXCIsIFwiaXNDb3JyZWN0XCI6IGZhbHNlIH0sXG4gICAgICB7IFwib3B0aW9uVGV4dFwiOiBcIlBpbGloYW4gQlwiLCBcImlzQ29ycmVjdFwiOiB0cnVlIH0sXG4gICAgICB7IFwib3B0aW9uVGV4dFwiOiBcIlBpbGloYW4gQ1wiLCBcImlzQ29ycmVjdFwiOiBmYWxzZSB9LFxuICAgICAgeyBcIm9wdGlvblRleHRcIjogXCJQaWxpaGFuIERcIiwgXCJpc0NvcnJlY3RcIjogZmFsc2UgfVxuICAgIF1cbiAgfVxuXWAudHJpbSgpO1xuXG4gICAgICAgICAgICBjb25zdCB0YXJnZXRNb2RlbCA9IG5vcm1hbGl6ZUFpTW9kZWwoc2VsZWN0ZWRNb2RlbCk7XG4gICAgY29uc3QgZW5kcG9pbnQgPSBgaHR0cHM6Ly9nZW5lcmF0aXZlbGFuZ3VhZ2UuZ29vZ2xlYXBpcy5jb20vdjFiZXRhL21vZGVscy8ke3RhcmdldE1vZGVsfTpzdHJlYW1HZW5lcmF0ZUNvbnRlbnQ/a2V5PSR7YXBpS2V5fSZhbHQ9c3NlYDtcbiAgICBjb25zdCBzdGFydFRpbWUgPSBEYXRlLm5vdygpO1xuICAgIHNldFN0YXR1cyhgQUkgKCR7dGFyZ2V0TW9kZWx9KSBzZWRhbmcgbWVueXVzdW4gc29hbC4uLmApO1xuXG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIDYwMDAwKTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChlbmRwb2ludCwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgY29udGVudHM6IFt7IHBhcnRzOiBbeyB0ZXh0OiBwcm9tcHRUZXh0IH1dIH1dLFxuICAgICAgICAgICAgICAgIGdlbmVyYXRpb25Db25maWc6IHsgdGVtcGVyYXR1cmU6IDAuNyB9LFxuICAgICAgICAgICAgfSksXG4gICAgICAgIH0pO1xuICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJEYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+ICh7fSkpO1xuICAgICAgICAgICAgY29uc3QgZXJyTXNnID0gZXJyRGF0YS5lcnJvcj8ubWVzc2FnZSB8fCBgSFRUUCAke3Jlc3BvbnNlLnN0YXR1c31gO1xuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDI5KSB7IG9uRG9uZSh7IG9rOiBmYWxzZSwgbWVzc2FnZTogYFJhdGUgbGltaXQgdGVyY2FwYWkgdW50dWsgbW9kZWwgJHt0YXJnZXRNb2RlbH0uIENvYmEgbW9kZWwgbGFpbiBhdGF1IHR1bmdndSBzZWJlbnRhci5gIH0pOyB9XG4gICAgICAgICAgICBlbHNlIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwMCB8fCByZXNwb25zZS5zdGF0dXMgPT09IDQwMykgeyBvbkRvbmUoeyBvazogZmFsc2UsIG1lc3NhZ2U6IGBBUEkgS2V5IHRpZGFrIHZhbGlkIGF0YXUgYWtzZXMgZGl0b2xhay4gKCR7ZXJyTXNnfSlgIH0pOyB9XG4gICAgICAgICAgICBlbHNlIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNTAwKSB7IG9uRG9uZSh7IG9rOiBmYWxzZSwgbWVzc2FnZTogYFNlcnZlciBBSSBTdHVkaW8gdGlkYWsgdGVyc2VkaWEgKEVycm9yICR7cmVzcG9uc2Uuc3RhdHVzfSkuIENvYmEgbGFnaSBuYW50aS5gIH0pOyB9XG4gICAgICAgICAgICBlbHNlIHsgb25Eb25lKHsgb2s6IGZhbHNlLCBtZXNzYWdlOiBgR2FnYWwgbWVtYW5nZ2lsIEFJOiAke2Vyck1zZ31gIH0pOyB9XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByZWFkZXIgPSByZXNwb25zZS5ib2R5LmdldFJlYWRlcigpO1xuICAgICAgICBjb25zdCBkZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCk7XG4gICAgICAgIGxldCBzc2VCdWZmZXIgPSAnJztcbiAgICAgICAgbGV0IGpzb25CdWZmZXIgPSAnJztcbiAgICAgICAgbGV0IHF1ZXN0aW9uQ291bnQgPSAwO1xuICAgICAgICBsZXQgYXJyYXlTdGFydGVkID0gZmFsc2U7XG5cbiAgICAgICAgY29uc3QgdHJ5UGFyc2VRdWVzdGlvbiA9ICgpID0+IHtcbiAgICAgICAgICAgIGxldCBkID0gMCwgaW5TdHIgPSBmYWxzZSwgZXNjID0gZmFsc2UsIG9iamVjdFN0YXJ0ID0gLTE7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGpzb25CdWZmZXIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjaCA9IGpzb25CdWZmZXJbaV07XG4gICAgICAgICAgICAgICAgaWYgKGVzYykgeyBlc2MgPSBmYWxzZTsgY29udGludWU7IH1cbiAgICAgICAgICAgICAgICBpZiAoY2ggPT09ICdcXFxcJyAmJiBpblN0cikgeyBlc2MgPSB0cnVlOyBjb250aW51ZTsgfVxuICAgICAgICAgICAgICAgIGlmIChjaCA9PT0gJ1wiJykgeyBpblN0ciA9ICFpblN0cjsgY29udGludWU7IH1cbiAgICAgICAgICAgICAgICBpZiAoaW5TdHIpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGlmIChjaCA9PT0gJ3snKSB7IGlmIChkID09PSAwKSBvYmplY3RTdGFydCA9IGk7IGQrKzsgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGNoID09PSAnfScpIHtcbiAgICAgICAgICAgICAgICAgICAgZC0tO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZCA9PT0gMCAmJiBvYmplY3RTdGFydCAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG9ialN0ciA9IGpzb25CdWZmZXIuc2xpY2Uob2JqZWN0U3RhcnQsIGkgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGpzb25CdWZmZXIgPSBqc29uQnVmZmVyLnNsaWNlKGkgKyAxKS5yZXBsYWNlKC9eWyxcXHNdKy8sICcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcSA9IEpTT04ucGFyc2Uob2JqU3RyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0eXBlSWQgPSBwYXJzZUludChxLnR5cGVJZCwgMTApIHx8IDI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG9wdGlvbnMgPSBBcnJheS5pc0FycmF5KHEub3B0aW9ucykgPyBxLm9wdGlvbnMgOiBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoWzIsIDNdLmluY2x1ZGVzKHR5cGVJZCkgJiYgb3B0aW9ucy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucyA9IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1BpbGloYW4gQScsIGlzQ29ycmVjdDogdHJ1ZSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnUGlsaWhhbiBCJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnUGlsaWhhbiBDJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnUGlsaWhhbiBEJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBub3JtYWxpemVkID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfaWQ6IGBxX2FpX3N0cmVhbV8ke0RhdGUubm93KCl9XyR7cXVlc3Rpb25Db3VudH1gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb246IFN0cmluZyhxLnF1ZXN0aW9uIHx8IGBQZXJ0YW55YWFuICR7cXVlc3Rpb25Db3VudCArIDF9YCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGVJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogcS5pc1JlcXVpcmVkICE9PSB1bmRlZmluZWQgPyBCb29sZWFuKHEuaXNSZXF1aXJlZCkgOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1Njb3JhYmxlOiBxLmlzU2NvcmFibGUgIT09IHVuZGVmaW5lZCA/IEJvb2xlYW4ocS5pc1Njb3JhYmxlKSA6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvaW50czogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29ycmVjdEFuc3dlcjogcS5jb3JyZWN0QW5zd2VyID8gU3RyaW5nKHEuY29ycmVjdEFuc3dlcikgOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uczogb3B0aW9ucy5tYXAoKG9wdCwgb0lkeCkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvblRleHQ6IFN0cmluZyhvcHQub3B0aW9uVGV4dCB8fCBvcHQudGV4dCB8fCBgUGlsaWhhbiAke1N0cmluZy5mcm9tQ2hhckNvZGUoNjUgKyBvSWR4KX1gKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdDogQm9vbGVhbihvcHQuaXNDb3JyZWN0KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbkltYWdlOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbkF1ZGlvOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25Db3VudCsrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygb25RdWVzdGlvbiA9PT0gJ2Z1bmN0aW9uJykgb25RdWVzdGlvbihub3JtYWxpemVkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTdGF0dXMoYE1lbmVyaW1hIHNvYWwgJHtxdWVzdGlvbkNvdW50fS8ke2NvdW50fS4uLmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCB7IC8qIHBhcnRpYWwsIHNraXAgKi8gfVxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgZG9uZSwgdmFsdWUgfSA9IGF3YWl0IHJlYWRlci5yZWFkKCk7XG4gICAgICAgICAgICBpZiAoZG9uZSkgYnJlYWs7XG4gICAgICAgICAgICBzc2VCdWZmZXIgKz0gZGVjb2Rlci5kZWNvZGUodmFsdWUsIHsgc3RyZWFtOiB0cnVlIH0pO1xuICAgICAgICAgICAgY29uc3QgbGluZXMgPSBzc2VCdWZmZXIuc3BsaXQoJ1xcbicpO1xuICAgICAgICAgICAgc3NlQnVmZmVyID0gbGluZXMucG9wKCkgfHwgJyc7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGxpbmUgb2YgbGluZXMpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWxpbmUuc3RhcnRzV2l0aCgnZGF0YTogJykpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGFTdHIgPSBsaW5lLnNsaWNlKDYpLnRyaW0oKTtcbiAgICAgICAgICAgICAgICBpZiAoZGF0YVN0ciA9PT0gJ1tET05FXScpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UoZGF0YVN0cik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRleHQgPSBwYXJzZWQuY2FuZGlkYXRlcz8uWzBdPy5jb250ZW50Py5wYXJ0cz8uWzBdPy50ZXh0IHx8ICcnO1xuICAgICAgICAgICAgICAgICAgICBqc29uQnVmZmVyICs9IHRleHQ7XG4gICAgICAgICAgICAgICAgICAgIGlmICghYXJyYXlTdGFydGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0cmltbWVkID0ganNvbkJ1ZmZlci50cmltU3RhcnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0cmltbWVkLnN0YXJ0c1dpdGgoJ1snKSkgeyBqc29uQnVmZmVyID0gdHJpbW1lZC5zbGljZSgxKTsgYXJyYXlTdGFydGVkID0gdHJ1ZTsgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGxldCBjb250ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgd2hpbGUgKGNvbnQpIHsgY29udCA9IHRyeVBhcnNlUXVlc3Rpb24oKTsgfVxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggeyAvKiBTU0UgY2h1bmsgcGFyc2UgZXJyb3IgKi8gfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZWxhcHNlZFNlYyA9ICgoRGF0ZS5ub3coKSAtIHN0YXJ0VGltZSkgLyAxMDAwKS50b0ZpeGVkKDEpO1xuICAgICAgICBzZXRTdGF0dXMoYFNlbGVzYWkhICR7cXVlc3Rpb25Db3VudH0gYnV0aXIgc29hbCBkaXRlcmltYSAoJHtlbGFwc2VkU2VjfSBkZXRpaykuYCk7XG4gICAgICAgIG9uRG9uZSh7IG9rOiB0cnVlLCB0b3RhbENvdW50OiBxdWVzdGlvbkNvdW50LCBtb2RlbFVzZWQ6IHRhcmdldE1vZGVsLCBlbGFwc2VkU2VjIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBpZiAoZXJyICYmIGVyci5uYW1lID09PSAnQWJvcnRFcnJvcicpIHsgb25Eb25lKHsgb2s6IGZhbHNlLCBtZXNzYWdlOiAnS29uZWtzaSBrZSBBSSBTdHVkaW8gdGltZW91dC4gUGVyaWtzYSBrb25la3NpIGludGVybmV0IEFuZGEgbGFsdSBjb2JhIGxhZ2kuJyB9KTsgfVxuICAgICAgICBlbHNlIGlmIChlcnIgJiYgZXJyLm5hbWUgPT09ICdUeXBlRXJyb3InKSB7IG9uRG9uZSh7IG9rOiBmYWxzZSwgbWVzc2FnZTogJ1RpZGFrIGRhcGF0IHRlcmh1YnVuZyBrZSBBSSBTdHVkaW8uIFBlcmlrc2Ega29uZWtzaSBpbnRlcm5ldCBBbmRhLicgfSk7IH1cbiAgICAgICAgZWxzZSB7IG9uRG9uZSh7IG9rOiBmYWxzZSwgbWVzc2FnZTogYFRlcmphZGkga2VuZGFsYSBzYWF0IHN0cmVhbWluZyBBSTogJHtlcnI/Lm1lc3NhZ2UgfHwgJ1Vua25vd24gZXJyb3InfWAgfSk7IH1cbiAgICB9XG59O1xuXG4vKipcbiAqIEdlbmVyYXRlIHF1ZXN0aW9ucyBkaXJlY3RseSBmcm9tIGFuIHVwbG9hZGVkIGRvY3VtZW50IChQREYsIFRleHQsIENTViwgZXRjLilcbiAqL1xuZXhwb3J0IGNvbnN0IGdlbmVyYXRlUXVlc3Rpb25zRnJvbURvY3VtZW50ID0gYXN5bmMgKHtcbiAgICBmaWxlLFxuICAgIGluc3RydWN0aW9uID0gJ0J1YXRrYW4gYnV0aXIgc29hbCBrdWlzL3VqaWFuIGJlcmt1YWxpdGFzIHRpbmdnaSBkYXJpIG1hdGVyaSBkb2t1bWVuIGluaScsXG4gICAgY291bnQgPSA1LFxuICAgIHR5cGVQcmVmZXJlbmNlID0gJzInLFxuICAgIGRpZmZpY3VsdHkgPSAnU2VkYW5nJyxcbiAgICBzZWxlY3RlZE1vZGVsID0gREVGQVVMVF9BSV9NT0RFTCxcbiAgICBjdXN0b21BcGlLZXkgPSBudWxsLFxuICAgIG9uU3RhdHVzID0gbnVsbCxcbn0pID0+IHtcbiAgICBjb25zdCBzZXRTdGF0dXMgPSAobXNnKSA9PiB7IGlmICh0eXBlb2Ygb25TdGF0dXMgPT09ICdmdW5jdGlvbicpIG9uU3RhdHVzKG1zZyk7IH07XG5cbiAgICBpZiAoIWZpbGUpIHtcbiAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBtZXNzYWdlOiAnQmVya2FzIG1hdGVyaSBiZWx1bSBkaXBpbGloLicgfTtcbiAgICB9XG5cbiAgICBzZXRTdGF0dXMoYE1lbWJhY2EgYmVya2FzIFwiJHtmaWxlLm5hbWV9XCIuLi5gKTtcblxuICAgIGNvbnN0IHR5cGVEZXNjcmlwdGlvbiA9IHtcbiAgICAgICAgJzEnOiAnU2VtdWEgc29hbCBiZXJ0aXBlIEVzc2F5IC8gSXNpYW4gU2luZ2thdCAodHlwZUlkOiAxLCBzZXJ0YWthbiBrdW5jaS9jb250b2ggamF3YWJhbiBkaSBjb3JyZWN0QW5zd2VyKS4nLFxuICAgICAgICAnMic6ICdTZW11YSBzb2FsIGJlcnRpcGUgUGlsaWhhbiBHYW5kYSAodHlwZUlkOiAyLCBzZWRpYWthbiA0IHBpbGloYW4gamF3YWJhbiBkaSBvcHRpb25zIGRpIG1hbmEgdGVwYXQgU0FUVSBiZXJuaWxhaSBpc0NvcnJlY3Q6IHRydWUpLicsXG4gICAgICAgICczJzogJ1NlbXVhIHNvYWwgYmVydGlwZSBDaGVja2JveCAvIFBpbGloYW4gTWFqZW11ayAodHlwZUlkOiAzLCBzZWRpYWthbiA0LTUgb3BzaSBkaSBtYW5hIGFkYSBtaW5pbWFsIDIgYmVybmlsYWkgaXNDb3JyZWN0OiB0cnVlKS4nLFxuICAgICAgICAnNCc6ICdTZW11YSBzb2FsIGJlcnRpcGUgVGFuZ2dhbCAmIFdha3R1IC8gRGF0ZSBUaW1lICh0eXBlSWQ6IDQsIGNvcnJlY3RBbnN3ZXIgZGlpc2kgZm9ybWF0IElTTyBcIllZWVktTU0tRERcIiBhdGF1IFwiWVlZWS1NTS1ERFRISDptbVwiKS4nLFxuICAgICAgICAnNSc6ICdTZW11YSBzb2FsIGJlcnRpcGUgQmVuYXIgLyBTYWxhaCAodHlwZUlkOiA1LCBjb3JyZWN0QW5zd2VyIGRpaXNpIFwiQmVuYXJcIiBhdGF1IFwiU2FsYWhcIikuJyxcbiAgICAgICAgJ21peGVkJzogJ1Zhcmlhc2kgY2FtcHVyYW4gYW50YXJhIFBpbGloYW4gR2FuZGEgKHR5cGVJZDogMiksIEJlbmFyL1NhbGFoICh0eXBlSWQ6IDUpLCBkYW4gRXNzYXkgKHR5cGVJZDogMSkuJyxcbiAgICB9W3R5cGVQcmVmZXJlbmNlXSB8fCAnUGlsaWhhbiBHYW5kYSAodHlwZUlkOiAyKSc7XG5cbiAgICBjb25zdCBwcm9tcHRUZXh0ID0gYCR7QUlfR1VBUkRSQUlMfUJlcmRhc2Fya2FuIGJlcmthcy9kb2t1bWVuIG1hdGVyaSB0ZXJsYW1waXIsIGJ1YXRsYWggJHtjb3VudH0gYnV0aXIgc29hbCBiZXJrdWFsaXRhcyB0aW5nZ2kgZGVuZ2FuIHBhbmR1YW4gYmVyaWt1dDpcbi0gKipJbnN0cnVrc2kgS2h1c3VzIFBlbmdndW5hOioqICR7aW5zdHJ1Y3Rpb24gfHwgJ0J1YXQgYnV0aXIgc29hbCBkYXJpIHNlbHVydWggbWF0ZXJpJ31cbi0gKipUaW5na2F0IEtlc3VsaXRhbjoqKiAke2RpZmZpY3VsdHl9XG4tICoqQmVudHVrIFNvYWw6KiogJHt0eXBlRGVzY3JpcHRpb259XG4tICoqQmFoYXNhOioqIEd1bmFrYW4gYmFoYXNhIHlhbmcgU0FNQSBkZW5nYW4gYmFoYXNhIGRva3VtZW4gbWF0ZXJpIGRpIGF0YXMgdW50dWsgU0VMVVJVSCBvdXRwdXQuXG5cbioqRk9STUFUIEtFTFVBUkFOIFdBSklCIChKU09OIEFSUkFZKToqKlxuS2VtYmFsaWthbiBIQU5ZQSBhcnJheSBKU09OIHZhbGlkIHRhbnBhIHRla3MgYXRhdSBwZW5qZWxhc2FuIHBlbWJ1a2EvcGVudXR1cC4gU3RydWt0dXIgb2JqZWsgcGVyIHNvYWw6XG5bXG4gIHtcbiAgICBcInF1ZXN0aW9uXCI6IFwiVGVrcyBwZXJ0YW55YWFuIGxlbmdrYXBcIixcbiAgICBcInR5cGVJZFwiOiAyLFxuICAgIFwiaXNSZXF1aXJlZFwiOiB0cnVlLFxuICAgIFwiaXNTY29yYWJsZVwiOiB0cnVlLFxuICAgIFwicG9pbnRzXCI6IDEsXG4gICAgXCJjb3JyZWN0QW5zd2VyXCI6IFwiS3VuY2kgamF3YWJhbiB1bnR1ayB0aXBlIDEvNCBhdGF1ICdCZW5hcicvJ1NhbGFoJyB1bnR1ayB0aXBlIDVcIixcbiAgICBcIm9wdGlvbnNcIjogW1xuICAgICAgeyBcIm9wdGlvblRleHRcIjogXCJQaWxpaGFuIEFcIiwgXCJpc0NvcnJlY3RcIjogZmFsc2UgfSxcbiAgICAgIHsgXCJvcHRpb25UZXh0XCI6IFwiUGlsaWhhbiBCXCIsIFwiaXNDb3JyZWN0XCI6IHRydWUgfSxcbiAgICAgIHsgXCJvcHRpb25UZXh0XCI6IFwiUGlsaWhhbiBDXCIsIFwiaXNDb3JyZWN0XCI6IGZhbHNlIH0sXG4gICAgICB7IFwib3B0aW9uVGV4dFwiOiBcIlBpbGloYW4gRFwiLCBcImlzQ29ycmVjdFwiOiBmYWxzZSB9XG4gICAgXVxuICB9XG5dXG5DYXRhdGFuOlxuLSBVbnR1ayB0aXBlIDIgKFBpbGloYW4gR2FuZGEpLCBwYXN0aWthbiB0ZXBhdCAxIG9wc2kgaXNDb3JyZWN0OiB0cnVlLlxuLSBVbnR1ayB0aXBlIDMgKENoZWNrYm94KSwgbWluaW1hbCAyIG9wc2kgaXNDb3JyZWN0OiB0cnVlLlxuLSBVbnR1ayB0aXBlIDEsIDQsIDUsIG9wdGlvbnMgYm9sZWgga29zb25nIFtdLlxuYC50cmltKCk7XG5cbiAgICByZXR1cm4gYXdhaXQgZXhlY3V0ZVdpdGhBcGlLZXlGYWlsb3Zlcihhc3luYyAoYXBpS2V5KSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXRNb2RlbCA9IG5vcm1hbGl6ZUFpTW9kZWwoc2VsZWN0ZWRNb2RlbCk7XG4gICAgICAgICAgICBzZXRTdGF0dXMoYE1lbmdodWJ1bmdrYW4ga2UgJHt0YXJnZXRNb2RlbH0gZGkgR29vZ2xlIEFJIFN0dWRpby4uLmApO1xuXG4gICAgICAgICAgICBjb25zdCBpc1BkZk9ySW1hZ2UgPSBmaWxlLnR5cGUgPT09ICdhcHBsaWNhdGlvbi9wZGYnIHx8IGZpbGUudHlwZS5zdGFydHNXaXRoKCdpbWFnZS8nKSB8fCBmaWxlLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnBkZicpO1xuICAgICAgICAgICAgY29uc3QgcGFydHMgPSBbeyB0ZXh0OiBwcm9tcHRUZXh0IH1dO1xuXG4gICAgICAgICAgICBpZiAoaXNQZGZPckltYWdlKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYmFzZTY0RGF0YSA9IGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgICAgICAgICAgICAgICAgcmVhZGVyLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IHJlYWRlci5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBiYXNlNjQgPSB0eXBlb2YgcmVzID09PSAnc3RyaW5nJyA/IHJlcy5zcGxpdCgnLCcpWzFdIDogJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKGJhc2U2NCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5vbmVycm9yID0gcmVqZWN0O1xuICAgICAgICAgICAgICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBwYXJ0cy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgaW5saW5lRGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWltZVR5cGU6IGZpbGUudHlwZSB8fCAnYXBwbGljYXRpb24vcGRmJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IGJhc2U2NERhdGEsXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGV4dENvbnRlbnQgPSBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5vbmxvYWQgPSAoKSA9PiByZXNvbHZlKHJlYWRlci5yZXN1bHQgfHwgJycpO1xuICAgICAgICAgICAgICAgICAgICByZWFkZXIub25lcnJvciA9IHJlamVjdDtcbiAgICAgICAgICAgICAgICAgICAgcmVhZGVyLnJlYWRBc1RleHQoZmlsZSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcGFydHMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IGBcXG5cXG49PT0gSVNJIERPS1VNRU4gTUFURVJJIChcIiR7ZmlsZS5uYW1lfVwiKSA9PT1cXG5cIlwiXCJcXG4ke1N0cmluZyh0ZXh0Q29udGVudCkuc2xpY2UoMCwgMTAwMDAwKX1cXG5cIlwiXCJgXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IGVuZHBvaW50ID0gYGh0dHBzOi8vZ2VuZXJhdGl2ZWxhbmd1YWdlLmdvb2dsZWFwaXMuY29tL3YxYmV0YS9tb2RlbHMvJHt0YXJnZXRNb2RlbH06Z2VuZXJhdGVDb250ZW50P2tleT0ke2FwaUtleX1gO1xuICAgICAgICAgICAgY29uc3Qgc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgIHNldFN0YXR1cyhgQUkgKCR7dGFyZ2V0TW9kZWx9KSBzZWRhbmcgbWVtYmFjYSBtYXRlcmkgJiBtZW55dXN1biBidXRpciBzb2FsLi4uYCk7XG5cbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goZW5kcG9pbnQsIHtcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnRzOiBbeyBwYXJ0cyB9XSxcbiAgICAgICAgICAgICAgICAgICAgZ2VuZXJhdGlvbkNvbmZpZzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2VNaW1lVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGVyYXR1cmU6IDAuNyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBjb25zdCBlbGFwc2VkU2VjID0gKChEYXRlLm5vdygpIC0gc3RhcnRUaW1lKSAvIDEwMDApLnRvRml4ZWQoMSk7XG5cbiAgICAgICAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlcnJEYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+ICh7fSkpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVyck1zZyA9IGVyckRhdGEuZXJyb3I/Lm1lc3NhZ2UgfHwgYEhUVFAgJHtyZXNwb25zZS5zdGF0dXN9YDtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MjkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBzdGF0dXM6IDQyOSwgbWVzc2FnZTogYEJhdGFzIHJhdGUgbGltaXQgbW9kZWwgJHt0YXJnZXRNb2RlbH0gdGVyY2FwYWkuIENvYmEgbGFnaSBkYWxhbSBiZWJlcmFwYSBzYWF0LmAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAwIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsIG1lc3NhZ2U6IGBBUEkgS2V5IHRpZGFrIHZhbGlkIGF0YXUgYWtzZXMgZGl0b2xhay4gKCR7ZXJyTXNnfSlgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsIG1lc3NhZ2U6IGBHYWdhbCBtZW1hbmdnaWwgQUk6ICR7ZXJyTXNnfWAgfTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc2V0U3RhdHVzKGBNZW5lcmltYSBoYXNpbCBzb2FsIGRhcmkgQUkgKCR7ZWxhcHNlZFNlY30gZGV0aWspLiBNZW12YWxpZGFzaSBzdHJ1a3R1ci4uLmApO1xuXG4gICAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICAgICAgY29uc3QgdGV4dFJlc3BvbnNlID0gZGF0YS5jYW5kaWRhdGVzPy5bMF0/LmNvbnRlbnQ/LnBhcnRzPy5bMF0/LnRleHQ7XG5cbiAgICAgICAgICAgIGlmICghdGV4dFJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBtZXNzYWdlOiAnQUkgdGlkYWsgbWVuZ2VtYmFsaWthbiBoYXNpbCB0ZWtzIHNvYWwuJyB9O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBsZXQgcGFyc2VkUXVlc3Rpb25zO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBwYXJzZWRRdWVzdGlvbnMgPSBzYWZlSnNvblBhcnNlKHRleHRSZXNwb25zZSk7XG4gICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIG1lc3NhZ2U6ICdGb3JtYXQgZGF0YSBkYXJpIEFJIHRpZGFrIHZhbGlkLicgfTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHBhcnNlZFF1ZXN0aW9ucykgfHwgcGFyc2VkUXVlc3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgbWVzc2FnZTogJ0Zvcm1hdCBkYXRhIGRhcmkgQUkgdGlkYWsgbWVuZ2hhc2lsa2FuIGRhZnRhciBzb2FsLicgfTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IHBhcnNlZFF1ZXN0aW9ucy5tYXAoKHEsIGlkeCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGVJZCA9IHBhcnNlSW50KHEudHlwZUlkLCAxMCkgfHwgMjtcbiAgICAgICAgICAgICAgICBsZXQgb3B0aW9ucyA9IEFycmF5LmlzQXJyYXkocS5vcHRpb25zKSA/IHEub3B0aW9ucyA6IFtdO1xuICAgICAgICAgICAgICAgIGlmIChbMiwgM10uaW5jbHVkZXModHlwZUlkKSAmJiBvcHRpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICBvcHRpb25zID0gW1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnUGlsaWhhbiBBJywgaXNDb3JyZWN0OiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdQaWxpaGFuIEInLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdQaWxpaGFuIEMnLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdQaWxpaGFuIEQnLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIF9pZDogYHFfZG9jX2FpXyR7RGF0ZS5ub3coKX1fJHtpZHh9YCxcbiAgICAgICAgICAgICAgICAgICAgaWQ6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiBTdHJpbmcocS5xdWVzdGlvbiB8fCBgUGVydGFueWFhbiAke2lkeCArIDF9YCksXG4gICAgICAgICAgICAgICAgICAgIHR5cGVJZDogdHlwZUlkLFxuICAgICAgICAgICAgICAgICAgICBpc1JlcXVpcmVkOiBxLmlzUmVxdWlyZWQgIT09IHVuZGVmaW5lZCA/IEJvb2xlYW4ocS5pc1JlcXVpcmVkKSA6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGlzU2NvcmFibGU6IHEuaXNTY29yYWJsZSAhPT0gdW5kZWZpbmVkID8gQm9vbGVhbihxLmlzU2NvcmFibGUpIDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgcG9pbnRzOiBxLnBvaW50cyAhPSBudWxsID8gTnVtYmVyKHEucG9pbnRzKSA6IDEsXG4gICAgICAgICAgICAgICAgICAgIGNvcnJlY3RBbnN3ZXI6IHEuY29ycmVjdEFuc3dlciA/IFN0cmluZyhxLmNvcnJlY3RBbnN3ZXIpIDogJycsXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IG9wdGlvbnMubWFwKChvcHQsIG9JZHgpID0+ICh7XG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25UZXh0OiBTdHJpbmcob3B0Lm9wdGlvblRleHQgfHwgb3B0LnRleHQgfHwgYFBpbGloYW4gJHtTdHJpbmcuZnJvbUNoYXJDb2RlKDY1ICsgb0lkeCl9YCksXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3Q6IEJvb2xlYW4ob3B0LmlzQ29ycmVjdCksXG4gICAgICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25JbWFnZTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25BdWRpbzogbnVsbCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHNldFN0YXR1cyhgU2VsZXNhaSEgQmVyaGFzaWwgbWVtYnVhdCAke25vcm1hbGl6ZWQubGVuZ3RofSBidXRpciBzb2FsIGRhcmkgXCIke2ZpbGUubmFtZX1cIi5gKTtcblxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICAgICAgICBkYXRhOiBub3JtYWxpemVkLFxuICAgICAgICAgICAgICAgIGZpbGVOYW1lOiBmaWxlLm5hbWUsXG4gICAgICAgICAgICAgICAgbW9kZWxVc2VkOiB0YXJnZXRNb2RlbCxcbiAgICAgICAgICAgICAgICBlbGFwc2VkU2VjLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBgVGVyamFkaSBrZW5kYWxhIHNhYXQgbWVtYmFjYSBtYXRlcmkgYXRhdSBtZW1wcm9zZXMgQUk6ICR7ZXJyPy5tZXNzYWdlIHx8ICdVbmtub3duIGVycm9yJ31gLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIH0sIGN1c3RvbUFwaUtleSk7XG59O1xuXG4vKipcbiAqIEhlbHBlciB0byBkb3dubG9hZCBzdHJ1Y3R1cmVkIHF1ZXN0aW9ucyBhcyBhIHN0YW5kYXJkIENTViB0ZW1wbGF0ZSBmb3IgcmUtaW1wb3J0XG4gKi9cbmV4cG9ydCBjb25zdCBleHBvcnRRdWVzdGlvbnNUb0NTViA9IChxdWVzdGlvbnMsIHRpdGxlID0gJ3RlbXBsYXRlLXNvYWwtYWknKSA9PiB7XG4gICAgaWYgKCFxdWVzdGlvbnMgfHwgcXVlc3Rpb25zLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAgIGNvbnN0IHJvd3MgPSBbXG4gICAgICAgIFsncXVlc3Rpb24nLCAndHlwZV9pZCcsICdvcmRlcicsICdpc19yZXF1aXJlZCcsICdjb3JyZWN0X2Fuc3dlcicsICdvcHRpb25zJ11cbiAgICBdO1xuICAgIHF1ZXN0aW9ucy5mb3JFYWNoKChxLCBpKSA9PiB7XG4gICAgICAgIGNvbnN0IGlzQ2hvaWNlID0gcS50eXBlSWQgPT09IDIgfHwgcS50eXBlSWQgPT09IDM7XG4gICAgICAgIGNvbnN0IG9wdGlvbnNTdHIgPSAocS5vcHRpb25zIHx8IFtdKS5tYXAobyA9PiAoby5pc0NvcnJlY3QgPyBgW0JFTkFSXSAke28ub3B0aW9uVGV4dH1gIDogby5vcHRpb25UZXh0KSkuam9pbignfCcpO1xuICAgICAgICBjb25zdCBjbGVhblEgPSAocS5xdWVzdGlvbiB8fCAnJykucmVwbGFjZSgvPFtePl0qPi9nLCAnJykucmVwbGFjZSgvXFxzKy9nLCAnICcpLnRyaW0oKTtcbiAgICAgICAgY29uc3QgY29ycmVjdENhID0gaXNDaG9pY2VcbiAgICAgICAgICAgID8gKHEub3B0aW9ucyB8fCBbXSkuZmlsdGVyKG8gPT4gby5pc0NvcnJlY3QpLm1hcChvID0+IG8ub3B0aW9uVGV4dCkuam9pbignLCcpXG4gICAgICAgICAgICA6IChxLmNvcnJlY3RBbnN3ZXIgfHwgJycpO1xuICAgICAgICByb3dzLnB1c2goW1xuICAgICAgICAgICAgYFwiJHtjbGVhblEucmVwbGFjZSgvXCIvZywgJ1wiXCInKX1cImAsXG4gICAgICAgICAgICBxLnR5cGVJZCB8fCAyLFxuICAgICAgICAgICAgaSArIDEsXG4gICAgICAgICAgICBxLmlzUmVxdWlyZWQgPyAndHJ1ZScgOiAnZmFsc2UnLFxuICAgICAgICAgICAgYFwiJHsoY29ycmVjdENhIHx8ICcnKS5yZXBsYWNlKC9cIi9nLCAnXCJcIicpfVwiYCxcbiAgICAgICAgICAgIGBcIiR7b3B0aW9uc1N0ci5yZXBsYWNlKC9cIi9nLCAnXCJcIicpfVwiYCxcbiAgICAgICAgXSk7XG4gICAgfSk7XG4gICAgY29uc3QgY3N2ID0gJ1xcdUZFRkYnICsgcm93cy5tYXAociA9PiByLmpvaW4oJywnKSkuam9pbignXFxyXFxuJyk7XG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtjc3ZdLCB7IHR5cGU6ICd0ZXh0L2NzdjtjaGFyc2V0PXV0Zi04OycgfSk7XG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGEuaHJlZiA9IHVybDtcbiAgICBhLmRvd25sb2FkID0gYCR7dGl0bGUucmVwbGFjZSgvXFxzKy9nLCAnXycpfS0ke0RhdGUubm93KCl9LmNzdmA7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChhKTtcbiAgICBhLmNsaWNrKCk7XG4gICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChhKTtcbiAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG59O1xuXG4vKipcbiAqIEV4dHJhY3QgdGV4dCBjb250ZW50IG9yIHRyYW5zY3JpcHQgZnJvbSBhIGdpdmVuIFVSTCAoV2ViIEFydGljbGUgb3IgWW91VHViZSBWaWRlbylcbiAqL1xuZXhwb3J0IGNvbnN0IGV4dHJhY3RDb250ZW50RnJvbVVybCA9IGFzeW5jICh1cmwsIG9uU3RhdHVzID0gbnVsbCkgPT4ge1xuICAgIGNvbnN0IHNldFN0YXR1cyA9IChtc2cpID0+IHsgaWYgKHR5cGVvZiBvblN0YXR1cyA9PT0gJ2Z1bmN0aW9uJykgb25TdGF0dXMobXNnKTsgfTtcbiAgICBpZiAoIXVybCB8fCB0eXBlb2YgdXJsICE9PSAnc3RyaW5nJykgcmV0dXJuIHsgb2s6IGZhbHNlLCBtZXNzYWdlOiAnVVJMIHRpZGFrIHZhbGlkJyB9O1xuXG4gICAgY29uc3QgdHJpbW1lZFVybCA9IHVybC50cmltKCk7XG4gICAgc2V0U3RhdHVzKGBNZW1iYWNhIFVSTDogJHt0cmltbWVkVXJsfS4uLmApO1xuXG4gICAgLy8gMS4gWW91VHViZSBVUkwgZGV0ZWN0aW9uXG4gICAgY29uc3QgeXRNYXRjaCA9IHRyaW1tZWRVcmwubWF0Y2goLyg/OnlvdXR1YmVcXC5jb21cXC8oPzp3YXRjaFxcP3Y9fGVtYmVkXFwvfHZcXC98c2hvcnRzXFwvKXx5b3V0dVxcLmJlXFwvKShbYS16QS1aMC05Xy1dezExfSkvaSk7XG4gICAgaWYgKHl0TWF0Y2ggJiYgeXRNYXRjaFsxXSkge1xuICAgICAgICBjb25zdCB2aWRlb0lkID0geXRNYXRjaFsxXTtcbiAgICAgICAgc2V0U3RhdHVzKGBNZW5kZXRla3NpIHZpZGVvIFlvdVR1YmUgKElEOiAke3ZpZGVvSWR9KS4gTWVuZ2FtYmlsIGp1ZHVsICYgdHJhbnNrcmlwLi4uYCk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIEF0dGVtcHQgdG8gZmV0Y2ggb0VtYmVkIG1ldGFkYXRhIGZvciB0aXRsZVxuICAgICAgICAgICAgbGV0IHZpZGVvVGl0bGUgPSBgWW91VHViZSBWaWRlbyAoJHt2aWRlb0lkfSlgO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBvZW1iZWRSZXMgPSBhd2FpdCBmZXRjaChgaHR0cHM6Ly9ub2VtYmVkLmNvbS9lbWJlZD91cmw9aHR0cHM6Ly93d3cueW91dHViZS5jb20vd2F0Y2g/dj0ke3ZpZGVvSWR9YCk7XG4gICAgICAgICAgICAgICAgaWYgKG9lbWJlZFJlcy5vaykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBtZXRhID0gYXdhaXQgb2VtYmVkUmVzLmpzb24oKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1ldGEudGl0bGUpIHZpZGVvVGl0bGUgPSBtZXRhLnRpdGxlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2gge31cblxuICAgICAgICAgICAgLy8gQXR0ZW1wdCBwdWJsaWMgdGltZWR0ZXh0IC8gc3VidGl0bGVzIGV4dHJhY3Rpb24gdmlhIGNvcnNwcm94eVxuICAgICAgICAgICAgbGV0IHRyYW5zY3JpcHRUZXh0ID0gJyc7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHN1YlJlcyA9IGF3YWl0IGZldGNoKGBodHRwczovL2NvcnNwcm94eS5pby8/JHtlbmNvZGVVUklDb21wb25lbnQoYGh0dHBzOi8vd3d3LnlvdXR1YmUuY29tL3dhdGNoP3Y9JHt2aWRlb0lkfWApfWApO1xuICAgICAgICAgICAgICAgIGlmIChzdWJSZXMub2spIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaHRtbCA9IGF3YWl0IHN1YlJlcy50ZXh0KCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIEV4dHJhY3QgY2FwdGlvbnMgSlNPTiBmcm9tIGluaXRpYWwgcGxheWVyIHJlc3BvbnNlIGlmIGF2YWlsYWJsZVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjYXB0aW9uTWF0Y2ggPSBodG1sLm1hdGNoKC9cImNhcHRpb25UcmFja3NcIjpcXHMqKFxcW1teXFxdXStcXF0pLyk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjYXB0aW9uTWF0Y2ggJiYgY2FwdGlvbk1hdGNoWzFdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0cmFja3MgPSBKU09OLnBhcnNlKGNhcHRpb25NYXRjaFsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0cmFja1VybCA9IHRyYWNrc1swXT8uYmFzZVVybDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0cmFja1VybCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRyYWNrUmVzID0gYXdhaXQgZmV0Y2goYGh0dHBzOi8vY29yc3Byb3h5LmlvLz8ke2VuY29kZVVSSUNvbXBvbmVudCh0cmFja1VybCl9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRyYWNrUmVzLm9rKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHhtbFRleHQgPSBhd2FpdCB0cmFja1Jlcy50ZXh0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zY3JpcHRUZXh0ID0geG1sVGV4dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoLzx0ZXh0W14+XSo+L2csICcgJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC88XFwvdGV4dD4vZywgJ1xcbicpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvPFtePl0rPi9nLCAnJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC8mYW1wOy9nLCAnJicpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvJiMzOTsvZywgXCInXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvJnF1b3Q7L2csICdcIicpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxzKy9nLCAnICcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2gge31cblxuICAgICAgICAgICAgaWYgKCF0cmFuc2NyaXB0VGV4dCkge1xuICAgICAgICAgICAgICAgIC8vIEZhbGxiYWNrIHZpZGVvIHN1bW1hcnkgcGF5bG9hZFxuICAgICAgICAgICAgICAgIHRyYW5zY3JpcHRUZXh0ID0gYFZpZGVvIFlvdVR1YmU6IFwiJHt2aWRlb1RpdGxlfVwiLiBVUkw6IGh0dHBzOi8veW91dHUuYmUvJHt2aWRlb0lkfS4gU2lsYWthbiBhbmFsaXNpcyBtYXRlcmkgZGFuIGJ1YXQgc29hbCBzZXN1YWkgdG9waWsvanVkdWwgdmlkZW8gaW5pLmA7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgICAgICAgdHlwZTogJ3lvdXR1YmUnLFxuICAgICAgICAgICAgICAgIHRpdGxlOiB2aWRlb1RpdGxlLFxuICAgICAgICAgICAgICAgIHZpZGVvSWQsXG4gICAgICAgICAgICAgICAgY29udGVudDogdHJhbnNjcmlwdFRleHQuc2xpY2UoMCwgNTAwMDApLFxuICAgICAgICAgICAgICAgIHVybDogdHJpbW1lZFVybFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgICAgICAgIHR5cGU6ICd5b3V0dWJlJyxcbiAgICAgICAgICAgICAgICB0aXRsZTogYFZpZGVvIFlvdVR1YmUgKCR7dmlkZW9JZH0pYCxcbiAgICAgICAgICAgICAgICB2aWRlb0lkLFxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGBWaWRlbyBZb3VUdWJlOiBodHRwczovL3lvdXR1LmJlLyR7dmlkZW9JZH1gLFxuICAgICAgICAgICAgICAgIHVybDogdHJpbW1lZFVybFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIDIuIFN0YW5kYXJkIFdlYnBhZ2UgQXJ0aWNsZSBleHRyYWN0aW9uXG4gICAgdHJ5IHtcbiAgICAgICAgc2V0U3RhdHVzKGBNZW5nYW1iaWwgdGVrcyBhcnRpa2VsIGRhcmkgd2VicGFnZS4uLmApO1xuICAgICAgICBsZXQgaHRtbCA9ICcnO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGZldGNoKGBodHRwczovL2NvcnNwcm94eS5pby8/JHtlbmNvZGVVUklDb21wb25lbnQodHJpbW1lZFVybCl9YCk7XG4gICAgICAgICAgICBpZiAocmVzcC5vaykge1xuICAgICAgICAgICAgICAgIGh0bWwgPSBhd2FpdCByZXNwLnRleHQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCB7fVxuXG4gICAgICAgIGlmICghaHRtbCkge1xuICAgICAgICAgICAgY29uc3QgZGlyZWN0UmVzcCA9IGF3YWl0IGZldGNoKHRyaW1tZWRVcmwsIHsgbW9kZTogJ2NvcnMnIH0pLmNhdGNoKCgpID0+IG51bGwpO1xuICAgICAgICAgICAgaWYgKGRpcmVjdFJlc3AgJiYgZGlyZWN0UmVzcC5vaykge1xuICAgICAgICAgICAgICAgIGh0bWwgPSBhd2FpdCBkaXJlY3RSZXNwLnRleHQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghaHRtbCkge1xuICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBtZXNzYWdlOiAnVGlkYWsgZGFwYXQgbWVuZ2FtYmlsIGtvbnRlbiBoYWxhbWFuIHdlYi4gUGFzdGlrYW4gVVJMIGRhcGF0IGRpYWtzZXMgcHVibGlrLicgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIENsZWFuIEhUTUwgdG8gcHVyZSBhcnRpY2xlIHRleHRcbiAgICAgICAgY29uc3QgcGFyc2VyID0gbmV3IERPTVBhcnNlcigpO1xuICAgICAgICBjb25zdCBkb2MgPSBwYXJzZXIucGFyc2VGcm9tU3RyaW5nKGh0bWwsICd0ZXh0L2h0bWwnKTtcblxuICAgICAgICAvLyBSZW1vdmUgc2NyaXB0LCBzdHlsZSwgbmF2LCBmb290ZXIgdGFnc1xuICAgICAgICBkb2MucXVlcnlTZWxlY3RvckFsbCgnc2NyaXB0LCBzdHlsZSwgbmF2LCBmb290ZXIsIGhlYWRlciwgbm9zY3JpcHQsIGlmcmFtZSwgc3ZnLCBbcm9sZT1cIm5hdmlnYXRpb25cIl0nKS5mb3JFYWNoKGVsID0+IGVsLnJlbW92ZSgpKTtcblxuICAgICAgICBjb25zdCBwYWdlVGl0bGUgPSBkb2MucXVlcnlTZWxlY3RvcigndGl0bGUnKT8uaW5uZXJUZXh0IHx8IGRvYy5xdWVyeVNlbGVjdG9yKCdoMScpPy5pbm5lclRleHQgfHwgdHJpbW1lZFVybDtcbiAgICAgICAgXG4gICAgICAgIC8vIEV4dHJhY3QgcGFyYWdyYXBoIHRleHRzXG4gICAgICAgIGNvbnN0IHBhcmFncmFwaHMgPSBBcnJheS5mcm9tKGRvYy5xdWVyeVNlbGVjdG9yQWxsKCdhcnRpY2xlLCBtYWluLCBwLCBoMSwgaDIsIGgzLCBoNCwgbGknKSlcbiAgICAgICAgICAgIC5tYXAoZWwgPT4gZWwuaW5uZXJUZXh0LnRyaW0oKSlcbiAgICAgICAgICAgIC5maWx0ZXIodCA9PiB0Lmxlbmd0aCA+IDIwKTtcblxuICAgICAgICBjb25zdCBmdWxsVGV4dCA9IHBhcmFncmFwaHMuam9pbignXFxuXFxuJykuc2xpY2UoMCwgNjAwMDApO1xuXG4gICAgICAgIGlmICghZnVsbFRleHQgfHwgZnVsbFRleHQubGVuZ3RoIDwgNTApIHtcbiAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgbWVzc2FnZTogJ1Rla3MgYXJ0aWtlbCBwYWRhIGhhbGFtYW4gd2ViIHRlcnNlYnV0IHRlcmxhbHUgc2luZ2thdCBhdGF1IHRpZGFrIGRhcGF0IGRpZWtzdHJhay4nIH07XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgb2s6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnd2VicGFnZScsXG4gICAgICAgICAgICB0aXRsZTogcGFnZVRpdGxlLnRyaW0oKSxcbiAgICAgICAgICAgIGNvbnRlbnQ6IGZ1bGxUZXh0LFxuICAgICAgICAgICAgdXJsOiB0cmltbWVkVXJsXG4gICAgICAgIH07XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgbWVzc2FnZTogYEdhZ2FsIG1lbWJhY2EgVVJMOiAke2Vyci5tZXNzYWdlfWAgfTtcbiAgICB9XG59O1xuXG4vKipcbiAqIEdlbmVyYXRlIHJlbWVkaWFsIGV4cGxhbmF0aW9uICYgc2VsZi1jaGVjayBwcmFjdGljZSBxdWVzdGlvbnMgZm9yIFwiUGVsYWphcmkgU29hbFwiIGZlYXR1cmVcbiAqL1xuZXhwb3J0IGNvbnN0IGdlbmVyYXRlUmVtZWRpYWxFeHBsYW5hdGlvbiA9IGFzeW5jICh7XG4gICAgcXVlc3Rpb25UZXh0LFxuICAgIHF1ZXN0aW9uVHlwZSA9IDIsXG4gICAgdXNlckFuc3dlciA9ICcnLFxuICAgIGNvcnJlY3RBbnN3ZXIgPSAnJyxcbiAgICBvcHRpb25zID0gW10sXG4gICAgc2VsZWN0ZWRNb2RlbCA9IERFRkFVTFRfQUlfTU9ERUwsXG4gICAgY3VzdG9tQXBpS2V5ID0gbnVsbCxcbn0pID0+IHtcbiAgICByZXR1cm4gYXdhaXQgZXhlY3V0ZVdpdGhBcGlLZXlGYWlsb3Zlcihhc3luYyAoYXBpS2V5KSA9PiB7XG4gICAgICAgIGNvbnN0IHR5cGVMYWJlbE1hcCA9IHsgMTogJ0Vzc2F5JywgMjogJ1BpbGloYW4gR2FuZGEnLCAzOiAnQ2hlY2tib3gnLCA0OiAnVGFuZ2dhbCcsIDU6ICdCZW5hci9TYWxhaCcgfTtcbiAgICAgICAgY29uc3QgcVR5cGVOYW1lID0gdHlwZUxhYmVsTWFwW3F1ZXN0aW9uVHlwZV0gfHwgJ1BpbGloYW4gR2FuZGEnO1xuXG4gICAgICAgIGNvbnN0IHByb21wdFRleHQgPSBgXG5BbmRhIGFkYWxhaCBHdXJ1ICYgVHV0b3IgUGVuZGFtcGluZyBDZXJkYXMgeWFuZyByYW1haCwgbWVtb3RpdmFzaSwgZGFuIHNvbHV0aWYuXG5TaXN3YSBiYXJ1IHNhamEgbWVuZ2VyamFrYW4gc29hbCBrdWlzIGRhbiBpbmdpbiBtZW1wZWxhamFyaSBsZXRhayBrZXNhbGFoYW4gc2VydGEga29uc2VwIGRhc2FyIG1hdGVyaW55YSBzZWNhcmEgbWVuZGFsYW0uXG5cbj09PSBEQVRBIFNPQUwgS1VJUyA9PT1cbi0gQmVudHVrIFNvYWw6ICR7cVR5cGVOYW1lfVxuLSBQZXJ0YW55YWFuOiBcIiR7cXVlc3Rpb25UZXh0fVwiXG4tIFBpbGloYW4gT3BzaSB5YW5nIFRlcnNlZGlhOiAke29wdGlvbnMubWFwKChvLCBpKSA9PiBgJHtTdHJpbmcuZnJvbUNoYXJDb2RlKDY1ICsgaSl9LiAke28ub3B0aW9uVGV4dH1gKS5qb2luKCcgfCAnKSB8fCAnLSd9XG4tIEphd2FiYW4geWFuZyBEaXBpbGloIFNpc3dhOiBcIiR7dXNlckFuc3dlciB8fCAnKFRpZGFrIGRpamF3YWIgLyBLb3NvbmcpJ31cIlxuLSBKYXdhYmFuIHlhbmcgQmVuYXIgLyBLdW5jaTogXCIke2NvcnJlY3RBbnN3ZXJ9XCJcblxuVFVHQVMgQU5EQTpcbjEuIEplbGFza2FuIHNlY2FyYSByYW1haCwgcmluZ2thcywgZGFuIGplbGFzIG1lbmdhcGEgamF3YWJhbiBzaXN3YSBzYWxhaCAoamlrYSBzYWxhaCkgZGFuIG1lbmdhcGEgamF3YWJhbiBrdW5jaSBhZGFsYWggamF3YWJhbiB5YW5nIHRlcGF0LlxuMi4gVHVsaXNrYW4gMi0zIHBvaW4gcmluZ2thcyBtYXRlcmkvcnVtdXMga3VuY2kgeWFuZyBoYXJ1cyBkaWluZ2F0IHNpc3dhLlxuMy4gQnVhdCAxIEJVVElSIFNPQUwgTEFUSUhBTiBTRUpFTklTIChQaWxpaGFuIEdhbmRhIDQgb3BzaSkgbGVuZ2thcCBkZW5nYW4ga3VuY2kgamF3YWJhbiBkYW4gcGVtYmFoYXNhbm55YSBhZ2FyIHNpc3dhIGRhcGF0IGxhbmdzdW5nIG1lbmd1amkgcGVtYWhhbWFubnlhIHNlY2FyYSBtYW5kaXJpLlxuXG4qKkZPUk1BVCBLRUxVQVJBTiBXQUpJQiAoSlNPTiBWQUxJRCk6KipcbntcbiAgXCJleHBsYW5hdGlvblwiOiBcIlBlbmplbGFzYW4gcmFtYWggZGFuIHRlcnN0cnVrdHVyIChiaXNhIGd1bmFrYW4gTWFya2Rvd24gYnVsbGV0L2JvbGQvTGFUZVggamlrYSBhZGEgcnVtdXMpXCIsXG4gIFwia2V5VGFrZWF3YXlzXCI6IFtcbiAgICBcIlBvaW4ga3VuY2kgMVwiLFxuICAgIFwiUG9pbiBrdW5jaSAyXCJcbiAgXSxcbiAgXCJwcmFjdGljZVF1ZXN0aW9uXCI6IHtcbiAgICBcInF1ZXN0aW9uXCI6IFwiVGVrcyBzb2FsIGxhdGloYW4gc2VydXBhIHVudHVrIG1lbmd1amkgcGVtYWhhbWFuXCIsXG4gICAgXCJvcHRpb25zXCI6IFtcbiAgICAgIHsgXCJvcHRpb25UZXh0XCI6IFwiUGlsaWhhbiBBXCIsIFwiaXNDb3JyZWN0XCI6IGZhbHNlIH0sXG4gICAgICB7IFwib3B0aW9uVGV4dFwiOiBcIlBpbGloYW4gQlwiLCBcImlzQ29ycmVjdFwiOiB0cnVlIH0sXG4gICAgICB7IFwib3B0aW9uVGV4dFwiOiBcIlBpbGloYW4gQ1wiLCBcImlzQ29ycmVjdFwiOiBmYWxzZSB9LFxuICAgICAgeyBcIm9wdGlvblRleHRcIjogXCJQaWxpaGFuIERcIiwgXCJpc0NvcnJlY3RcIjogZmFsc2UgfVxuICAgIF0sXG4gICAgXCJleHBsYW5hdGlvblwiOiBcIlBlbWJhaGFzYW4gc2luZ2thdCB1bnR1ayBzb2FsIGxhdGloYW4gaW5pXCJcbiAgfVxufVxuYC50cmltKCk7XG5cbiAgICAgICAgY29uc3QgZW5kcG9pbnQgPSBgaHR0cHM6Ly9nZW5lcmF0aXZlbGFuZ3VhZ2UuZ29vZ2xlYXBpcy5jb20vdjFiZXRhL21vZGVscy8ke3NlbGVjdGVkTW9kZWx9OmdlbmVyYXRlQ29udGVudD9rZXk9JHthcGlLZXl9YDtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChlbmRwb2ludCwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICBjb250ZW50czogW3sgcGFydHM6IFt7IHRleHQ6IHByb21wdFRleHQgfV0gfV0sXG4gICAgICAgICAgICAgICAgZ2VuZXJhdGlvbkNvbmZpZzoge1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZU1pbWVUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICAgICAgICAgIHRlbXBlcmF0dXJlOiAwLjYsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJEYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+ICh7fSkpO1xuICAgICAgICAgICAgY29uc3QgZXJyTXNnID0gZXJyRGF0YS5lcnJvcj8ubWVzc2FnZSB8fCBgSFRUUCAke3Jlc3BvbnNlLnN0YXR1c31gO1xuICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cywgbWVzc2FnZTogZXJyTXNnIH07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBjb25zdCByYXdUZXh0ID0gZGF0YS5jYW5kaWRhdGVzPy5bMF0/LmNvbnRlbnQ/LnBhcnRzPy5bMF0/LnRleHQ7XG4gICAgICAgIGlmICghcmF3VGV4dCkgcmV0dXJuIHsgb2s6IGZhbHNlLCBtZXNzYWdlOiAnQUkgdGlkYWsgbWVuZ2VtYmFsaWthbiBoYXNpbC4nIH07XG5cbiAgICAgICAgY29uc3QgcGFyc2VkID0gc2FmZUpzb25QYXJzZShyYXdUZXh0KTtcbiAgICAgICAgaWYgKCFwYXJzZWQgfHwgIXBhcnNlZC5leHBsYW5hdGlvbikge1xuICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBtZXNzYWdlOiAnRm9ybWF0IHJlc3BvbnMgdHV0b3IgQUkgdGlkYWsgdmFsaWQuJyB9O1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG9rOiB0cnVlLFxuICAgICAgICAgICAgZGF0YTogcGFyc2VkLFxuICAgICAgICAgICAgbW9kZWxVc2VkOiBzZWxlY3RlZE1vZGVsLFxuICAgICAgICB9O1xuICAgIH0sIGN1c3RvbUFwaUtleSk7XG59O1xuXG4vKipcbiAqIFJldmlzZSBhIHNpbmdsZSBxdWVzdGlvbiB1c2luZyBHZW1pbmkgQVBJIHdpdGggZmFpbG92ZXJcbiAqL1xuZXhwb3J0IGNvbnN0IHJldmlzZVF1ZXN0aW9uV2l0aEFJID0gYXN5bmMgKHtcbiAgICBxdWVzdGlvbixcbiAgICBvcHRpb25zID0gW10sXG4gICAgY29ycmVjdEFuc3dlciA9ICcnLFxuICAgIHR5cGVJZCA9IDIsXG4gICAgaXNSZXF1aXJlZCA9IHRydWUsXG4gICAgaXNTY29yYWJsZSA9IHRydWUsXG4gICAgaW5zdHJ1Y3Rpb24sXG4gICAgc2VsZWN0ZWRNb2RlbCA9IERFRkFVTFRfQUlfTU9ERUwsXG4gICAgY3VzdG9tQXBpS2V5ID0gbnVsbCxcbn0pID0+IHtcbiAgICByZXR1cm4gYXdhaXQgZXhlY3V0ZVdpdGhBcGlLZXlGYWlsb3Zlcihhc3luYyAoYXBpS2V5KSA9PiB7XG4gICAgICAgIGNvbnN0IGNsZWFuUSA9IChxdWVzdGlvbiB8fCAnJykucmVwbGFjZSgvPFtePl0qPi9nLCAnJykudHJpbSgpO1xuICAgICAgICBjb25zdCBvcHRpb25zVGV4dCA9IG9wdGlvbnMubWFwKChvLCBpKSA9PiBgJHtTdHJpbmcuZnJvbUNoYXJDb2RlKDY1K2kpfS4gJHtvLm9wdGlvblRleHR9JHtvLmlzQ29ycmVjdD8nIChqYXdhYmFuIGJlbmFyKSc6Jyd9YCkuam9pbignXFxuJyk7XG4gICAgICAgIGNvbnN0IHByb21wdCA9IGBBbmRhIGFkYWxhaCBhc2lzdGVuIHBlbnl1c3VuIHNvYWwgdWppYW4uIFJldmlzaSBzb2FsIGJlcmlrdXQgc2VzdWFpIGluc3RydWtzaS5cblxuU29hbCBhc2xpOlxuJHtjbGVhblF9XG5cblBpbGloYW4gamF3YWJhbjpcbiR7b3B0aW9uc1RleHQgfHwgJyh0aWRhayBhZGEgb3BzaSknfVxuXG5LdW5jaSBqYXdhYmFuOiAke2NvcnJlY3RBbnN3ZXIgfHwgJyd9XG5cbkluc3RydWtzaSByZXZpc2k6ICR7aW5zdHJ1Y3Rpb24udHJpbSgpfVxuXG5LZW1iYWxpa2FuIEhBTllBIEpTT04gdmFsaWQgKHNhdHUgb2JqZWssIGJ1a2FuIGFycmF5KSBkZW5nYW4gc3RydWt0dXI6XG57XG4gIFwicXVlc3Rpb25cIjogXCJ0ZWtzIHNvYWwgeWFuZyBkaXJldmlzaVwiLFxuICBcInR5cGVJZFwiOiAke3R5cGVJZH0sXG4gIFwiaXNSZXF1aXJlZFwiOiAke2lzUmVxdWlyZWR9LFxuICBcImlzU2NvcmFibGVcIjogJHtpc1Njb3JhYmxlfSxcbiAgXCJjb3JyZWN0QW5zd2VyXCI6IFwia3VuY2kgamF3YWJhblwiLFxuICBcIm9wdGlvbnNcIjogW3tcIm9wdGlvblRleHRcIjpcIi4uLlwiLCBcImlzQ29ycmVjdFwiOiBmYWxzZX1dXG59YDtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldE1vZGVsID0gbm9ybWFsaXplQWlNb2RlbChzZWxlY3RlZE1vZGVsKTtcbiAgICAgICAgY29uc3QgZW5kcG9pbnQgPSBgaHR0cHM6Ly9nZW5lcmF0aXZlbGFuZ3VhZ2UuZ29vZ2xlYXBpcy5jb20vdjFiZXRhL21vZGVscy8ke3RhcmdldE1vZGVsfTpnZW5lcmF0ZUNvbnRlbnQ/a2V5PSR7YXBpS2V5fWA7XG4gICAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBmZXRjaChlbmRwb2ludCwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICBjb250ZW50czogW3sgcGFydHM6IFt7IHRleHQ6IHByb21wdCB9XSB9XSxcbiAgICAgICAgICAgICAgICBnZW5lcmF0aW9uQ29uZmlnOiB7IHJlc3BvbnNlTWltZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJywgdGVtcGVyYXR1cmU6IDAuNyB9XG4gICAgICAgICAgICB9KVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFyZXNwLm9rKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJEYXRhID0gYXdhaXQgcmVzcC5qc29uKCkuY2F0Y2goKCkgPT4gKHt9KSk7XG4gICAgICAgICAgICBjb25zdCBlcnJNc2cgPSBlcnJEYXRhLmVycm9yPy5tZXNzYWdlIHx8IGBIVFRQICR7cmVzcC5zdGF0dXN9YDtcbiAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgc3RhdHVzOiByZXNwLnN0YXR1cywgbWVzc2FnZTogZXJyTXNnIH07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3AuanNvbigpO1xuICAgICAgICBsZXQgdGV4dFJlcyA9IGRhdGEuY2FuZGlkYXRlcz8uWzBdPy5jb250ZW50Py5wYXJ0cz8uWzBdPy50ZXh0IHx8ICcnO1xuICAgICAgICB0ZXh0UmVzID0gdGV4dFJlcy50cmltKCkucmVwbGFjZSgvXmBgYGpzb25cXHMqLywnJykucmVwbGFjZSgvXFxzKmBgYCQvLCcnKS5yZXBsYWNlKC9eYGBgXFxzKi8sJycpO1xuICAgICAgICBjb25zdCByZXZpc2VkID0gSlNPTi5wYXJzZSh0ZXh0UmVzKTtcbiAgICAgICAgcmV0dXJuIHsgb2s6IHRydWUsIGRhdGE6IHJldmlzZWQgfTtcbiAgICB9LCBjdXN0b21BcGlLZXkpO1xufTtcblxuLyoqXG4gKiBCdWxrIHJldmlzZSBtdWx0aXBsZSBxdWVzdGlvbnMgdXNpbmcgR2VtaW5pIEFQSSB3aXRoIGZhaWxvdmVyXG4gKi9cbmV4cG9ydCBjb25zdCBidWxrUmV2aXNlUXVlc3Rpb25zV2l0aEFJID0gYXN5bmMgKHtcbiAgICBxdWVzdGlvbnMgPSBbXSxcbiAgICBzZWxlY3RlZEluZGljZXMgPSBbXSxcbiAgICBpbnN0cnVjdGlvbixcbiAgICBzZWxlY3RlZE1vZGVsID0gREVGQVVMVF9BSV9NT0RFTCxcbiAgICBjdXN0b21BcGlLZXkgPSBudWxsLFxufSkgPT4ge1xuICAgIHJldHVybiBhd2FpdCBleGVjdXRlV2l0aEFwaUtleUZhaWxvdmVyKGFzeW5jIChhcGlLZXkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldE1vZGVsID0gbm9ybWFsaXplQWlNb2RlbChzZWxlY3RlZE1vZGVsKTtcbiAgICAgICAgY29uc3QgcmVzdWx0cyA9IFtdO1xuICAgICAgICBsZXQgYW55U3VjY2VzcyA9IGZhbHNlO1xuXG4gICAgICAgIGZvciAoY29uc3QgaWR4IG9mIHNlbGVjdGVkSW5kaWNlcykge1xuICAgICAgICAgICAgY29uc3QgcSA9IHF1ZXN0aW9uc1tpZHhdO1xuICAgICAgICAgICAgaWYgKCFxKSBjb250aW51ZTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgY2xlYW5RID0gKHEucXVlc3Rpb24gfHwgJycpLnJlcGxhY2UoLzxbXj5dKj4vZywgJycpLnRyaW0oKTtcbiAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25zVGV4dCA9IChxLm9wdGlvbnMgfHwgW10pLm1hcCgobywgaSkgPT4gYCR7U3RyaW5nLmZyb21DaGFyQ29kZSg2NStpKX0uICR7by5vcHRpb25UZXh0fSR7by5pc0NvcnJlY3Q/JyAoamF3YWJhbiBiZW5hciknOicnfWApLmpvaW4oJ1xcbicpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHByb21wdCA9IGBSZXZpc2kgc29hbCBiZXJpa3V0IHNlc3VhaSBpbnN0cnVrc2kuIEtlbWJhbGlrYW4gSEFOWUEgSlNPTiB2YWxpZC5cXG5cXG5Tb2FsOiAke2NsZWFuUX1cXG5PcHNpOlxcbiR7b3B0aW9uc1RleHQgfHwgJyh0aWRhayBhZGEpJ31cXG5LdW5jaTogJHtxLmNvcnJlY3RBbnN3ZXIgfHwgJyd9XFxuXFxuSW5zdHJ1a3NpOiAke2luc3RydWN0aW9uLnRyaW0oKX1cXG5cXG5KU09OIG91dHB1dDpcXG57XCJxdWVzdGlvblwiOlwiLi4uXCIsXCJ0eXBlSWRcIjoke3EudHlwZUlkfSxcImlzUmVxdWlyZWRcIjoke3EuaXNSZXF1aXJlZH0sXCJpc1Njb3JhYmxlXCI6JHtxLmlzU2NvcmFibGV9LFwiY29ycmVjdEFuc3dlclwiOlwiLi4uXCIsXCJvcHRpb25zXCI6W3tcIm9wdGlvblRleHRcIjpcIi4uLlwiLFwiaXNDb3JyZWN0XCI6ZmFsc2V9XX1gO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVuZHBvaW50ID0gYGh0dHBzOi8vZ2VuZXJhdGl2ZWxhbmd1YWdlLmdvb2dsZWFwaXMuY29tL3YxYmV0YS9tb2RlbHMvJHt0YXJnZXRNb2RlbH06Z2VuZXJhdGVDb250ZW50P2tleT0ke2FwaUtleX1gO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBmZXRjaChlbmRwb2ludCwge1xuICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnRzOiBbeyBwYXJ0czogW3sgdGV4dDogcHJvbXB0IH1dIH1dLFxuICAgICAgICAgICAgICAgICAgICAgICAgZ2VuZXJhdGlvbkNvbmZpZzogeyByZXNwb25zZU1pbWVUeXBlOiAnYXBwbGljYXRpb24vanNvbicsIHRlbXBlcmF0dXJlOiAwLjcgfVxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmICghcmVzcC5vaykge1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcC5zdGF0dXMgPT09IDQyOSB8fCByZXNwLnN0YXR1cyA9PT0gNDAwIHx8IHJlc3Auc3RhdHVzID09PSA0MDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgc3RhdHVzOiByZXNwLnN0YXR1cywgbWVzc2FnZTogYEhUVFAgJHtyZXNwLnN0YXR1c31gIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwLmpzb24oKTtcbiAgICAgICAgICAgICAgICBsZXQgdGV4dFJlcyA9IGRhdGEuY2FuZGlkYXRlcz8uWzBdPy5jb250ZW50Py5wYXJ0cz8uWzBdPy50ZXh0IHx8ICcnO1xuICAgICAgICAgICAgICAgIHRleHRSZXMgPSB0ZXh0UmVzLnRyaW0oKS5yZXBsYWNlKC9eYGBgKD86anNvbik/XFxzKi9pLCcnKS5yZXBsYWNlKC9cXHMqYGBgJC8sJycpLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAvLyBHZW1pbmkgY2FuIG9jY2FzaW9uYWxseSBhZGQgYSBzaG9ydCBzZW50ZW5jZSBhcm91bmQgdGhlIEpTT04uXG4gICAgICAgICAgICAgICAgLy8gRXh0cmFjdCB0aGUgb2JqZWN0IHNvIG9uZSBtYWxmb3JtZWQgd3JhcHBlciBkb2VzIG5vdCBkcm9wIGFcbiAgICAgICAgICAgICAgICAvLyBzZWxlY3RlZCBxdWVzdGlvbiBmcm9tIHRoZSBidWxrIHJlc3VsdC5cbiAgICAgICAgICAgICAgICBjb25zdCBqc29uU3RhcnQgPSB0ZXh0UmVzLmluZGV4T2YoJ3snKTtcbiAgICAgICAgICAgICAgICBjb25zdCBqc29uRW5kID0gdGV4dFJlcy5sYXN0SW5kZXhPZignfScpO1xuICAgICAgICAgICAgICAgIGlmIChqc29uU3RhcnQgPj0gMCAmJiBqc29uRW5kID4ganNvblN0YXJ0KSB0ZXh0UmVzID0gdGV4dFJlcy5zbGljZShqc29uU3RhcnQsIGpzb25FbmQgKyAxKTtcbiAgICAgICAgICAgICAgICBjb25zdCByZXZpc2VkID0gc2FmZUpzb25QYXJzZSh0ZXh0UmVzKTtcbiAgICAgICAgICAgICAgICBpZiAoIXJldmlzZWQgfHwgIXJldmlzZWQucXVlc3Rpb24pIHRocm93IG5ldyBFcnJvcignRm9ybWF0IEpTT04gcmV2aXNpIHRpZGFrIHZhbGlkJyk7XG4gICAgICAgICAgICAgICAgcmVzdWx0cy5wdXNoKHsgaWR4LCBvcmlnaW5hbDogcSwgcmV2aXNlZCB9KTtcbiAgICAgICAgICAgICAgICBhbnlTdWNjZXNzID0gdHJ1ZTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHJldmlzaW5nIHF1ZXN0aW9uICR7aWR4fTpgLCBlcnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFhbnlTdWNjZXNzICYmIHNlbGVjdGVkSW5kaWNlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIG1lc3NhZ2U6ICdUaWRhayBhZGEgc29hbCB5YW5nIGJlcmhhc2lsIGRpcmV2aXNpIG9sZWggQUkuJyB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7IG9rOiB0cnVlLCBkYXRhOiByZXN1bHRzIH07XG4gICAgfSwgY3VzdG9tQXBpS2V5KTtcbn07XG5cbi8qKlxuICogQUkgQW5hbHl0aWNzICYgRWR1Y2F0aW9uYWwgSW5zaWdodHNcbiAqL1xuZXhwb3J0IGNvbnN0IGFuYWx5emVGb3JtQW5hbHl0aWNzV2l0aEFJID0gYXN5bmMgKHtcbiAgICBzdW1tYXJ5LFxuICAgIHNlbGVjdGVkTW9kZWwgPSBERUZBVUxUX0FJX01PREVMLFxuICAgIGN1c3RvbUFwaUtleSA9IG51bGwsXG59KSA9PiB7XG4gICAgcmV0dXJuIGF3YWl0IGV4ZWN1dGVXaXRoQXBpS2V5RmFpbG92ZXIoYXN5bmMgKGFwaUtleSkgPT4ge1xuICAgICAgICBjb25zdCBwcm9tcHRUZXh0ID0gYEFuZGEgYWRhbGFoIGFuYWxpcyBwZW5kaWRpa2FuIHByb2Zlc2lvbmFsLiBCZXJkYXNhcmthbiBkYXRhIGhhc2lsIHVqaWFuIGJlcmlrdXQsIGJlcmlrYW4gYW5hbGlzaXMgbWVuZGFsYW0gZGFuIHJla29tZW5kYXNpIHBlcmJhaWthbiBkYWxhbSBiYWhhc2EgSW5kb25lc2lhIHlhbmcgamVsYXMgZGFuIG11ZGFoIGRpcGFoYW1pIGd1cnUuXG5cbiR7c3VtbWFyeX1cblxuQmVyaWthbiBhbmFsaXNpcyB5YW5nIG1lbmNha3VwOlxuMS4gSWRlbnRpZmlrYXNpIHNvYWwtc29hbCBiZXJtYXNhbGFoICh0ZXJsYWx1IHN1bGl0L211ZGFoKSBkYW4gc2FyYW4gcGVyYmFpa2FubnlhXG4yLiBJbnRlcnByZXRhc2kgZGlzdHJpYnVzaSBuaWxhaSBkYW4gYXBhIGFydGlueWEgYmFnaSBrdWFsaXRhcyBwZW1iZWxhamFyYW5cbjMuIFJla29tZW5kYXNpIGtvbmtyZXQgdW50dWsgbWVuaW5na2F0a2FuIGhhc2lsIGJlbGFqYXJcbjQuIEtlc2ltcHVsYW4gdW11bSB0ZW50YW5nIGt1YWxpdGFzIHNvYWwgZGFuIHBlbWFoYW1hbiBzaXN3YVxuXG5Gb3JtYXQgcmVzcG9ucyBkYWxhbSBwYXJhZ3JhZiB5YW5nIHRlcnN0cnVrdHVyLCBtYWtzaW1hbCA0MDAga2F0YS5gO1xuXG4gICAgICAgICAgICBjb25zdCB0YXJnZXRNb2RlbCA9IG5vcm1hbGl6ZUFpTW9kZWwoc2VsZWN0ZWRNb2RlbCk7XG4gICAgICAgIGNvbnN0IGVuZHBvaW50ID0gYGh0dHBzOi8vZ2VuZXJhdGl2ZWxhbmd1YWdlLmdvb2dsZWFwaXMuY29tL3YxYmV0YS9tb2RlbHMvJHt0YXJnZXRNb2RlbH06Z2VuZXJhdGVDb250ZW50P2tleT0ke2FwaUtleX1gO1xuICAgICAgICBjb25zdCByZXNwID0gYXdhaXQgZmV0Y2goZW5kcG9pbnQsIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgY29udGVudHM6IFt7IHBhcnRzOiBbeyB0ZXh0OiBwcm9tcHRUZXh0IH1dIH1dLFxuICAgICAgICAgICAgICAgIGdlbmVyYXRpb25Db25maWc6IHsgdGVtcGVyYXR1cmU6IDAuNSB9XG4gICAgICAgICAgICB9KVxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3Aub2spIHtcbiAgICAgICAgICAgIGNvbnN0IGVyckRhdGEgPSBhd2FpdCByZXNwLmpzb24oKS5jYXRjaCgoKSA9PiAoe30pKTtcbiAgICAgICAgICAgIGNvbnN0IGVyck1zZyA9IGVyckRhdGEuZXJyb3I/Lm1lc3NhZ2UgfHwgYEhUVFAgJHtyZXNwLnN0YXR1c31gO1xuICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBzdGF0dXM6IHJlc3Auc3RhdHVzLCBtZXNzYWdlOiBlcnJNc2cgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwLmpzb24oKTtcbiAgICAgICAgY29uc3QgdGV4dCA9IGRhdGEuY2FuZGlkYXRlcz8uWzBdPy5jb250ZW50Py5wYXJ0cz8uWzBdPy50ZXh0IHx8ICcnO1xuICAgICAgICByZXR1cm4geyBvazogdHJ1ZSwgZGF0YTogdGV4dC50cmltKCkgfTtcbiAgICB9LCBjdXN0b21BcGlLZXkpO1xufTtcblxuLyoqXG4gKiBBSSBIb2xpc3RpYyBFc3NheSBTY29yaW5nXG4gKi9cbmV4cG9ydCBjb25zdCBzY29yZUhvbGlzdGljRXNzYXlXaXRoQUkgPSBhc3luYyAoe1xuICAgIGVzc2F5QW5zd2VycyA9IFtdLFxuICAgIHBnU2VjdGlvbiA9ICcnLFxuICAgIHNlbGVjdGVkTW9kZWwgPSBERUZBVUxUX0FJX01PREVMLFxuICAgIGN1c3RvbUFwaUtleSA9IG51bGwsXG59KSA9PiB7XG4gICAgcmV0dXJuIGF3YWl0IGV4ZWN1dGVXaXRoQXBpS2V5RmFpbG92ZXIoYXN5bmMgKGFwaUtleSkgPT4ge1xuICAgICAgICBjb25zdCBlc3NheVNlY3Rpb24gPSBlc3NheUFuc3dlcnMubWFwKChhLCBpKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0ID0gYS5hbnN3ZXJUZXh0IHx8IGEuYW5zd2VyVmFsdWUgfHwgJyhrb3NvbmcpJztcbiAgICAgICAgICAgIGNvbnN0IGtleSA9IGEuY29ycmVjdEFuc3dlciB8fCAnKHRpZGFrIGFkYSBrdW5jaSknO1xuICAgICAgICAgICAgY29uc3QgcSA9IChhLnF1ZXN0aW9uIHx8ICcnKS5yZXBsYWNlKC88W14+XSo+L2csICcnKS5zdWJzdHJpbmcoMCwgMjAwKTtcbiAgICAgICAgICAgIGNvbnN0IGFJZCA9IGEuYW5zd2VySWQgfHwgYS5pZDtcbiAgICAgICAgICAgIHJldHVybiBgRXNzYXkgIyR7aSsxfSAoYW5zd2VySWQ6ICR7YUlkfSk6XFxuUGVydGFueWFhbjogJHtxfVxcbkt1bmNpOiAke2tleX1cXG5KYXdhYmFuOiAke3RleHR9YDtcbiAgICAgICAgfSkuam9pbignXFxuXFxuJyk7XG5cbiAgICAgICAgY29uc3QgcHJvbXB0ID0gYEFuZGEgYWRhbGFoIHBlbmlsYWkgdWppYW4uIE5pbGFpIFNFTVVBIHNvYWwgZXNzYXkgZGFyaSBzYXR1IHJlc3BvbmRlbiBzZWthbGlndXMgc2VjYXJhIGhvbGlzdGlrLCBkZW5nYW4gbWVtcGVydGltYmFuZ2thbiBrb250ZWtzIGtlc2VsdXJ1aGFuIHBlcmZvcm1hIHJlc3BvbmRlbi5cbiR7cGdTZWN0aW9ufVxuXG5EYXRhIEVzc2F5OlxuJHtlc3NheVNlY3Rpb259XG5cbktlbWJhbGlrYW4gSlNPTiBhcnJheSDigJQgc2F0dSBvYmplayBwZXIgZXNzYXksIEhBUlVTIGJlcnVydXRhbiBzZXN1YWkgRXNzYXkgIzEsICMyLCBkc3Q6XG5bXG4gIHtcImFuc3dlcklkXCI6IDxhbnN3ZXJJZCBpbnRlZ2VyIGRhcmkgZGF0YSBlc3NheT4sIFwic2NvcmVcIjogODUsIFwiaXNDb3JyZWN0XCI6IHRydWUsIFwicmVhc29uXCI6IFwiQWxhc2FuIHNpbmdrYXQgMSBrYWxpbWF0XCJ9XG5dXG5cblBhbmR1YW4gcGVuaWxhaWFuOlxuLSBOaWxhaSBiZXJkYXNhcmthbiBrZXNhbWFhbiBtYWtuYS9rb25zZXAsIGJ1a2FuIGthdGEgcGVyIGthdGFcbi0gaXNDb3JyZWN0OiB0cnVlIGppa2Egc2NvcmUgPj0gNzBcbi0gUGVydGltYmFuZ2thbiBrb250ZWtzOiBqaWthIFBHIGJhZ3VzLCBjZW5kZXJ1bmcgcGFoYW0gbWF0ZXJpXG4tIFNjb3JlOiAwLTEwMGA7XG5cbiAgICAgICAgICAgIGNvbnN0IHRhcmdldE1vZGVsID0gbm9ybWFsaXplQWlNb2RlbChzZWxlY3RlZE1vZGVsKTtcbiAgICAgICAgY29uc3QgZW5kcG9pbnQgPSBgaHR0cHM6Ly9nZW5lcmF0aXZlbGFuZ3VhZ2UuZ29vZ2xlYXBpcy5jb20vdjFiZXRhL21vZGVscy8ke3RhcmdldE1vZGVsfTpnZW5lcmF0ZUNvbnRlbnQ/a2V5PSR7YXBpS2V5fWA7XG4gICAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBmZXRjaChlbmRwb2ludCwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICBjb250ZW50czogW3sgcGFydHM6IFt7IHRleHQ6IHByb21wdCB9XSB9XSxcbiAgICAgICAgICAgICAgICBnZW5lcmF0aW9uQ29uZmlnOiB7IHJlc3BvbnNlTWltZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJywgdGVtcGVyYXR1cmU6IDAuMyB9XG4gICAgICAgICAgICB9KVxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3Aub2spIHtcbiAgICAgICAgICAgIGNvbnN0IGVyckRhdGEgPSBhd2FpdCByZXNwLmpzb24oKS5jYXRjaCgoKSA9PiAoe30pKTtcbiAgICAgICAgICAgIGNvbnN0IGVyck1zZyA9IGVyckRhdGEuZXJyb3I/Lm1lc3NhZ2UgfHwgYEhUVFAgJHtyZXNwLnN0YXR1c31gO1xuICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBzdGF0dXM6IHJlc3Auc3RhdHVzLCBtZXNzYWdlOiBlcnJNc2cgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwLmpzb24oKTtcbiAgICAgICAgbGV0IHRleHRSZXMgPSBkYXRhLmNhbmRpZGF0ZXM/LlswXT8uY29udGVudD8ucGFydHM/LlswXT8udGV4dCB8fCAnJztcbiAgICAgICAgdGV4dFJlcyA9IHRleHRSZXMudHJpbSgpLnJlcGxhY2UoL15gYGBqc29uXFxzKi8sJycpLnJlcGxhY2UoL1xccypgYGAkLywnJykucmVwbGFjZSgvXmBgYFxccyovLCcnKTtcbiAgICAgICAgY29uc3Qgc3VnZ2VzdGlvbnMgPSBKU09OLnBhcnNlKHRleHRSZXMpO1xuICAgICAgICByZXR1cm4geyBvazogdHJ1ZSwgZGF0YTogc3VnZ2VzdGlvbnMgfTtcbiAgICB9LCBjdXN0b21BcGlLZXkpO1xufTtcbiJdfQ==