import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/VisualFormulaEditor.jsx");const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Beaker, Calculator } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/VisualFormulaEditor.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const templates = {
	matematika: [
		["Fraksi", "\\frac{a}{b}"],
		["Akar", "\\sqrt{x}"],
		["Akar-n", "\\sqrt[n]{x}"],
		["Integral berbatas", "\\int_{a}^{b} f(x)\\,dx"],
		["Limit", "\\lim_{x\\to a} f(x)"],
		["Sigma", "\\sum_{i=1}^{n} i"],
		["Phi besar", "\\prod_{i=1}^{n} i"],
		["Matriks 2×2", "\\begin{pmatrix}a&b\\\\c&d\\end{pmatrix}"],
		["α β θ π", "\\alpha+\\beta+\\theta+\\pi"],
		["± ∞", "\\pm\\infty"]
	],
	kimia: [
		["Subskrip H₂O", "H_{2}O"],
		["Ion sulfat", "SO_{4}^{2-}"],
		["Superskrip", "Na^{+}"],
		["Reaksi →", "A \\rightarrow B"],
		["Kesetimbangan ⇌", "A \\rightleftharpoons B"],
		["Ikatan tunggal", "A-B"],
		["Ikatan rangkap", "A=B"]
	]
};
export default function VisualFormulaEditor({ value, onChange, append = true }) {
	_s();
	const [category, setCategory] = useState("matematika");
	const preview = useMemo(() => value?.trim() || "\\frac{a}{b}", [value]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setCategory("matematika"),
					className: `px-3 py-1.5 rounded-lg text-xs font-bold ${category === "matematika" ? "bg-teal-600 text-white" : "bg-slate-100 dark:bg-slate-800"}`,
					children: [/* @__PURE__ */ _jsxDEV(Calculator, {
						size: 13,
						className: "inline mr-1"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 227
					}, this), "Matematika"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setCategory("kimia"),
					className: `px-3 py-1.5 rounded-lg text-xs font-bold ${category === "kimia" ? "bg-teal-600 text-white" : "bg-slate-100 dark:bg-slate-800"}`,
					children: [/* @__PURE__ */ _jsxDEV(Beaker, {
						size: 13,
						className: "inline mr-1"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 217
					}, this), "Kimia"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap gap-1.5",
				children: templates[category].map(([label, latex]) => /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => onChange(append && value?.trim() ? `${value}${latex}` : latex),
					className: "px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-teal-950 text-[11px] font-bold",
					children: ["+ ", label]
				}, label, true, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 62
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-[11px] text-slate-400",
				children: "Klik template lalu ubah placeholder di syntax jika diperlukan."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("textarea", {
				value,
				onChange: (e) => onChange(e.target.value),
				rows: 3,
				spellCheck: false,
				className: "w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-3 text-xs font-mono",
				"aria-label": "Syntax LaTeX hasil editor visual"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "min-h-16 rounded-xl border border-teal-100 dark:border-teal-900 bg-teal-50/40 dark:bg-teal-950/30 p-4 flex items-center justify-center",
				children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: `$$${preview}$$` }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 165
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 9
	}, this);
}
_s(VisualFormulaEditor, "AdS7QZLj6CjVQCQ0UOzEevwnIHw=");
_c = VisualFormulaEditor;
var _c;
$RefreshReg$(_c, "VisualFormulaEditor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/VisualFormulaEditor.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/VisualFormulaEditor.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/VisualFormulaEditor.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/VisualFormulaEditor.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxTQUFTLGdCQUFnQjtBQUNsQyxTQUFTLFFBQVEsa0JBQWtCO0FBQ25DLE9BQU8seUJBQXlCOzs7O0FBRWhDLE1BQU0sWUFBWTtDQUNkLFlBQVk7RUFDUixDQUFDLFVBQVUsY0FBYztFQUFHLENBQUMsUUFBUSxXQUFXO0VBQUcsQ0FBQyxVQUFVLGNBQWM7RUFDNUUsQ0FBQyxxQkFBcUIseUJBQXlCO0VBQUcsQ0FBQyxTQUFTLHNCQUFzQjtFQUNsRixDQUFDLFNBQVMsbUJBQW1CO0VBQUcsQ0FBQyxhQUFhLG9CQUFvQjtFQUNsRSxDQUFDLGVBQWUsMENBQTBDO0VBQzFELENBQUMsV0FBVyw2QkFBNkI7RUFBRyxDQUFDLE9BQU8sYUFBYTtDQUNyRTtDQUNBLE9BQU87RUFDSCxDQUFDLGdCQUFnQixRQUFRO0VBQUcsQ0FBQyxjQUFjLGFBQWE7RUFDeEQsQ0FBQyxjQUFjLFFBQVE7RUFBRyxDQUFDLFlBQVksa0JBQWtCO0VBQ3pELENBQUMsbUJBQW1CLHlCQUF5QjtFQUFHLENBQUMsa0JBQWtCLEtBQUs7RUFDeEUsQ0FBQyxrQkFBa0IsS0FBSztDQUM1QjtBQUNKO0FBRUEsZUFBZSxTQUFTLG9CQUFvQixFQUFFLE9BQU8sVUFBVSxTQUFTLFFBQVE7O0NBQzVFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxZQUFZO0NBQ3JELE1BQU0sVUFBVSxjQUFjLE9BQU8sS0FBSyxLQUFLLGdCQUFnQixDQUFDLEtBQUssQ0FBQztDQUN0RSxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxlQUFlLFlBQVksWUFBWTtLQUFHLFdBQVcsNENBQTRDLGFBQWEsZUFBZSwyQkFBMkI7ZUFBOUssQ0FBa04sd0JBQUMsWUFBRDtNQUFZLE1BQU07TUFBSSxXQUFVO0tBQWU7Ozs7ZUFBQyxZQUFrQjs7Ozs7Y0FDcFIsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxlQUFlLFlBQVksT0FBTztLQUFHLFdBQVcsNENBQTRDLGFBQWEsVUFBVSwyQkFBMkI7ZUFBcEssQ0FBd00sd0JBQUMsUUFBRDtNQUFRLE1BQU07TUFBSSxXQUFVO0tBQWU7Ozs7ZUFBQyxPQUFhOzs7OztZQUNoUTs7Ozs7O0dBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDVixVQUFVLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxXQUFXLHdCQUFDLFVBQUQ7S0FBb0IsTUFBSztLQUFTLGVBQWUsU0FBUyxVQUFVLE9BQU8sS0FBSyxJQUFJLEdBQUcsUUFBUSxVQUFVLEtBQUs7S0FBRyxXQUFVO2VBQTNILENBQStPLE1BQUcsS0FBYztPQUFuUDs7OztXQUFtUCxDQUFDO0dBQzdTOzs7OztHQUNMLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQTZCO0dBQWlFOzs7OztHQUMzRyx3QkFBQyxZQUFEO0lBQWlCO0lBQU8sV0FBVSxNQUFLLFNBQVMsRUFBRSxPQUFPLEtBQUs7SUFBRyxNQUFNO0lBQUcsWUFBWTtJQUFPLFdBQVU7SUFBbUgsY0FBVztHQUFvQzs7Ozs7R0FDelEsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBeUksd0JBQUMscUJBQUQsRUFBcUIsU0FBUyxLQUFLLFFBQVEsSUFBTTs7Ozs7R0FBTTs7Ozs7RUFDOU07Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlZpc3VhbEZvcm11bGFFZGl0b3IuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQmVha2VyLCBDYWxjdWxhdG9yIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBSaWNoQ29udGVudFJlbmRlcmVyIGZyb20gJy4uLy4uL3V0aWxzL1JpY2hDb250ZW50UmVuZGVyZXInO1xuXG5jb25zdCB0ZW1wbGF0ZXMgPSB7XG4gICAgbWF0ZW1hdGlrYTogW1xuICAgICAgICBbJ0ZyYWtzaScsICdcXFxcZnJhY3thfXtifSddLCBbJ0FrYXInLCAnXFxcXHNxcnR7eH0nXSwgWydBa2FyLW4nLCAnXFxcXHNxcnRbbl17eH0nXSxcbiAgICAgICAgWydJbnRlZ3JhbCBiZXJiYXRhcycsICdcXFxcaW50X3thfV57Yn0gZih4KVxcXFwsZHgnXSwgWydMaW1pdCcsICdcXFxcbGltX3t4XFxcXHRvIGF9IGYoeCknXSxcbiAgICAgICAgWydTaWdtYScsICdcXFxcc3VtX3tpPTF9XntufSBpJ10sIFsnUGhpIGJlc2FyJywgJ1xcXFxwcm9kX3tpPTF9XntufSBpJ10sXG4gICAgICAgIFsnTWF0cmlrcyAyw5cyJywgJ1xcXFxiZWdpbntwbWF0cml4fWEmYlxcXFxcXFxcYyZkXFxcXGVuZHtwbWF0cml4fSddLFxuICAgICAgICBbJ86xIM6yIM64IM+AJywgJ1xcXFxhbHBoYStcXFxcYmV0YStcXFxcdGhldGErXFxcXHBpJ10sIFsnwrEg4oieJywgJ1xcXFxwbVxcXFxpbmZ0eSddLFxuICAgIF0sXG4gICAga2ltaWE6IFtcbiAgICAgICAgWydTdWJza3JpcCBI4oKCTycsICdIX3syfU8nXSwgWydJb24gc3VsZmF0JywgJ1NPX3s0fV57Mi19J10sXG4gICAgICAgIFsnU3VwZXJza3JpcCcsICdOYV57K30nXSwgWydSZWFrc2kg4oaSJywgJ0EgXFxcXHJpZ2h0YXJyb3cgQiddLFxuICAgICAgICBbJ0tlc2V0aW1iYW5nYW4g4oeMJywgJ0EgXFxcXHJpZ2h0bGVmdGhhcnBvb25zIEInXSwgWydJa2F0YW4gdHVuZ2dhbCcsICdBLUInXSxcbiAgICAgICAgWydJa2F0YW4gcmFuZ2thcCcsICdBPUInXSxcbiAgICBdLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVmlzdWFsRm9ybXVsYUVkaXRvcih7IHZhbHVlLCBvbkNoYW5nZSwgYXBwZW5kID0gdHJ1ZSB9KSB7XG4gICAgY29uc3QgW2NhdGVnb3J5LCBzZXRDYXRlZ29yeV0gPSB1c2VTdGF0ZSgnbWF0ZW1hdGlrYScpO1xuICAgIGNvbnN0IHByZXZpZXcgPSB1c2VNZW1vKCgpID0+IHZhbHVlPy50cmltKCkgfHwgJ1xcXFxmcmFje2F9e2J9JywgW3ZhbHVlXSk7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldENhdGVnb3J5KCdtYXRlbWF0aWthJyl9IGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgJHtjYXRlZ29yeSA9PT0gJ21hdGVtYXRpa2EnID8gJ2JnLXRlYWwtNjAwIHRleHQtd2hpdGUnIDogJ2JnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCd9YH0+PENhbGN1bGF0b3Igc2l6ZT17MTN9IGNsYXNzTmFtZT1cImlubGluZSBtci0xXCIgLz5NYXRlbWF0aWthPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0Q2F0ZWdvcnkoJ2tpbWlhJyl9IGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgJHtjYXRlZ29yeSA9PT0gJ2tpbWlhJyA/ICdiZy10ZWFsLTYwMCB0ZXh0LXdoaXRlJyA6ICdiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAnfWB9PjxCZWFrZXIgc2l6ZT17MTN9IGNsYXNzTmFtZT1cImlubGluZSBtci0xXCIgLz5LaW1pYTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICB7dGVtcGxhdGVzW2NhdGVnb3J5XS5tYXAoKFtsYWJlbCwgbGF0ZXhdKSA9PiA8YnV0dG9uIGtleT17bGFiZWx9IHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZShhcHBlbmQgJiYgdmFsdWU/LnRyaW0oKSA/IGAke3ZhbHVlfSR7bGF0ZXh9YCA6IGxhdGV4KX0gY2xhc3NOYW1lPVwicHgtMiBweS0xIHJvdW5kZWQtbGcgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXRlYWwtNTAgZGFyazpob3ZlcjpiZy10ZWFsLTk1MCB0ZXh0LVsxMXB4XSBmb250LWJvbGRcIj4rIHtsYWJlbH08L2J1dHRvbj4pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPktsaWsgdGVtcGxhdGUgbGFsdSB1YmFoIHBsYWNlaG9sZGVyIGRpIHN5bnRheCBqaWthIGRpcGVybHVrYW4uPC9wPlxuICAgICAgICAgICAgPHRleHRhcmVhIHZhbHVlPXt2YWx1ZX0gb25DaGFuZ2U9e2UgPT4gb25DaGFuZ2UoZS50YXJnZXQudmFsdWUpfSByb3dzPXszfSBzcGVsbENoZWNrPXtmYWxzZX0gY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHAtMyB0ZXh0LXhzIGZvbnQtbW9ub1wiIGFyaWEtbGFiZWw9XCJTeW50YXggTGFUZVggaGFzaWwgZWRpdG9yIHZpc3VhbFwiIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLTE2IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci10ZWFsLTEwMCBkYXJrOmJvcmRlci10ZWFsLTkwMCBiZy10ZWFsLTUwLzQwIGRhcms6YmctdGVhbC05NTAvMzAgcC00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+PFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17YCQkJHtwcmV2aWV3fSQkYH0gLz48L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==