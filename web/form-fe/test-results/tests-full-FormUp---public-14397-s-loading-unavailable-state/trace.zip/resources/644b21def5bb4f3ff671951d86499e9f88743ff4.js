import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/Login.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Link, useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { login, saveSession, isAuthenticated } from "/src/services/apiService.js";
import { FileText, ArrowRight, Lock, Mail, Loader2, Eye, EyeOff } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/Login.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const Login = () => {
	_s();
	const [showPassword, setShowPassword] = useState(false);
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [rememberMe, setRememberMe] = useState(true);
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(false);
	const navigate = useNavigate();
	const [searchParams] = useSearchParams();
	useEffect(() => {
		if (isAuthenticated()) {
			navigate("/dashboard", { replace: true });
		}
		const reason = searchParams.get("reason");
		if (reason === "session_expired") {
			setError("Sesi Anda telah berakhir. Silakan login kembali.");
		}
	}, [navigate, searchParams]);
	const handleLogin = async (e) => {
		e.preventDefault();
		setError("");
		setLoading(true);
		try {
			const result = await login(email.trim(), password);
			if (result.ok && result.data?.token) {
				saveSession(result.data, rememberMe);
				navigate("/dashboard");
			} else {
				setError(result.message || "Email atau password salah.");
			}
		} catch (err) {
			console.error("Error Login:", err);
			setError("Terjadi kesalahan koneksi ke server.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "h-screen max-h-screen w-full bg-[#004D4E] flex items-center justify-center p-4 sm:p-6 lg:p-12 relative overflow-hidden select-none touch-none",
		children: [
			"            ",
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute inset-0 pointer-events-none",
				style: { background: "linear-gradient(200deg, #2ED8C3 0%, #0FA89E 35%, #018081 75%, #004D4E 100%)" }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 172
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute pointer-events-none rounded-full",
				style: {
					width: "clamp(350px, 45vw, 750px)",
					height: "clamp(350px, 45vw, 750px)",
					top: "-10%",
					left: "-10%",
					background: "linear-gradient(-143deg, #2ED8C3 0%, rgba(10, 95, 110, 0.7) 100%)",
					opacity: .6,
					zIndex: 1
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute pointer-events-none rounded-full",
				style: {
					width: "clamp(350px, 45vw, 750px)",
					height: "clamp(350px, 45vw, 750px)",
					bottom: "-10%",
					right: "-10%",
					background: "linear-gradient(135deg, #2ED8C3 0%, rgba(10, 29, 93, 0.7) 100%)",
					opacity: .8,
					zIndex: 1
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative z-10 w-full max-w-6xl flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12 my-auto",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "w-full lg:w-1/2 text-white space-y-4 text-center lg:text-left",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-tight text-white",
						children: "Buat Tanpa Limit!"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-base sm:text-lg text-white/95 font-medium leading-relaxed max-w-lg mx-auto lg:mx-0",
						children: "Buat formulir, kuis interaktif, survei, dan evaluasi dengan pengalaman yang cepat, fleksibel, dan responsif."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "w-full lg:w-1/2 max-w-md",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "w-full bg-black/40 backdrop-blur-[20px] border border-white/10 rounded-[28px] p-6 sm:p-10 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-2xl sm:text-3xl font-bold text-white tracking-tight",
								children: "Selamat Datang!"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs sm:text-sm font-medium text-white/70 mt-1",
								children: "Masuk ke akun Anda untuk mengakses formulir dan respons"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 25
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 21
							}, this),
							error && /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3.5 bg-red-500/20 border border-red-500/30 rounded-xl",
								children: /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-bold text-red-300 text-center",
									children: error
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 113,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("form", {
								onSubmit: handleLogin,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-white/90 mb-1.5",
										children: "Email"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 120,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "relative",
										children: [/* @__PURE__ */ _jsxDEV(Mail, {
											size: 16,
											className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 124,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "email",
											placeholder: "nama@email.com",
											value: email,
											onChange: (e) => setEmail(e.target.value),
											required: true,
											className: "w-full pl-10 pr-4 py-3 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 126,
											columnNumber: 33
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 29
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 118,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-white/90 mb-1.5",
										children: "Password"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 138,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "relative",
										children: [
											/* @__PURE__ */ _jsxDEV(Lock, {
												size: 16,
												className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 142,
												columnNumber: 33
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: showPassword ? "text" : "password",
												placeholder: "••••••••",
												value: password,
												onChange: (e) => setPassword(e.target.value),
												required: true,
												className: "w-full pl-10 pr-10 py-3 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 143,
												columnNumber: 33
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setShowPassword(!showPassword),
												className: "absolute right-3.5 top-1/2 -translate-y-1/2 text-white/50 hover:text-white transition-colors cursor-pointer p-0.5 focus:outline-none",
												tabIndex: "-1",
												children: showPassword ? /* @__PURE__ */ _jsxDEV(EyeOff, { size: 16 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 159,
													columnNumber: 41
												}, this) : /* @__PURE__ */ _jsxDEV(Eye, { size: 16 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 161,
													columnNumber: 41
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 152,
												columnNumber: 33
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 141,
										columnNumber: 29
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 137,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pt-1",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "flex items-center gap-2 cursor-pointer select-none",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: rememberMe,
												onChange: (e) => setRememberMe(e.target.checked),
												className: "w-4 h-4 rounded text-[#0FA89E] focus:ring-[#0FA89E] accent-[#0FA89E] bg-black/40 border-white/20 cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 33
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-medium text-white/80",
												children: "Ingat Saya"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 175,
												columnNumber: 33
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 168,
											columnNumber: 29
										}, this), /* @__PURE__ */ _jsxDEV(Link, {
											to: "/forgot-password",
											className: "text-xs font-medium text-white/80 hover:text-[#2ED8C3] transition-colors",
											children: "Lupa password?"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 177,
											columnNumber: 29
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										disabled: loading,
										className: "w-full mt-4 py-3.5 px-6 bg-[#0FA89E] hover:bg-[#0d968d] active:scale-[0.98] text-white font-bold rounded-full shadow-[0_6px_20px_rgba(15,168,158,0.4)] transition-all duration-200 text-xs sm:text-sm tracking-wide disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center gap-2",
										children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
											size: 16,
											className: "animate-spin"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 192,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Memproses..." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 37
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 191,
											columnNumber: 33
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("span", { children: "Masuk ke Akun" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 197,
											columnNumber: 37
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 196,
											columnNumber: 33
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 25
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-center pt-3 border-t border-white/10",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-medium text-white/70",
									children: "Belum punya akun? "
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV(Link, {
									to: "/register",
									className: "text-xs font-bold text-[#2ED8C3] hover:underline transition-all",
									children: "Daftar Sekarang"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 205,
									columnNumber: 25
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 203,
								columnNumber: 21
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 1
	}, this);
};
_s(Login, "XUBx42riyZKokhm8F1+aETjCMu4=", false, function() {
	return [useNavigate, useSearchParams];
});
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/Login.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/Login.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/Login.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/Login.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLE1BQU0sYUFBYSx1QkFBdUI7QUFDbkQsU0FBUyxPQUFPLGFBQWEsdUJBQXVCO0FBQ3BELFNBQVMsVUFBVSxZQUFZLE1BQU0sTUFBTSxTQUFTLEtBQUssY0FBYzs7OztBQUV2RSxNQUFNLGNBQWM7O0NBQ2hCLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsSUFBSTtDQUNqRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsZ0JBQWdCLGdCQUFnQjtDQUV2QyxnQkFBZ0I7RUFDWixJQUFJLGdCQUFnQixHQUFHO0dBQ25CLFNBQVMsY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDO0VBQzVDO0VBQ0EsTUFBTSxTQUFTLGFBQWEsSUFBSSxRQUFRO0VBQ3hDLElBQUksV0FBVyxtQkFBbUI7R0FDOUIsU0FBUyxrREFBa0Q7RUFDL0Q7Q0FDSixHQUFHLENBQUMsVUFBVSxZQUFZLENBQUM7Q0FFM0IsTUFBTSxjQUFjLE9BQU8sTUFBTTtFQUM3QixFQUFFLGVBQWU7RUFDakIsU0FBUyxFQUFFO0VBQ1gsV0FBVyxJQUFJO0VBRWYsSUFBSTtHQUNBLE1BQU0sU0FBUyxNQUFNLE1BQU0sTUFBTSxLQUFLLEdBQUcsUUFBUTtHQUVqRCxJQUFJLE9BQU8sTUFBTSxPQUFPLE1BQU0sT0FBTztJQUNqQyxZQUFZLE9BQU8sTUFBTSxVQUFVO0lBQ25DLFNBQVMsWUFBWTtHQUN6QixPQUFPO0lBQ0gsU0FBUyxPQUFPLFdBQVcsNEJBQTRCO0dBQzNEO0VBQ0osU0FBUyxLQUFLO0dBQ1YsUUFBUSxNQUFNLGdCQUFnQixHQUFHO0dBQ2pDLFNBQVMsc0NBQXNDO0VBQ25ELFVBQVU7R0FDTixXQUFXLEtBQUs7RUFDcEI7Q0FDSjtDQUVBLE9BQ0osd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUErSjtHQUFZLHdCQUFDLE9BQUQ7SUFDM0osV0FBVTtJQUNWLE9BQU8sRUFDSCxZQUFZLDhFQUNoQjtHQUNIOzs7OztHQUdELHdCQUFDLE9BQUQ7SUFDSSxXQUFVO0lBQ1YsT0FBTztLQUNILE9BQU87S0FDUCxRQUFRO0tBQ1IsS0FBSztLQUNMLE1BQU07S0FDTixZQUFZO0tBQ1osU0FBUztLQUNULFFBQVE7SUFDWjtHQUNIOzs7OztHQUdELHdCQUFDLE9BQUQ7SUFDSSxXQUFVO0lBQ1YsT0FBTztLQUNILE9BQU87S0FDUCxRQUFRO0tBQ1IsUUFBUTtLQUNSLE9BQU87S0FDUCxZQUFZO0tBQ1osU0FBUztLQUNULFFBQVE7SUFDWjtHQUNIOzs7OztHQUdELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FHSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXFGO0tBRS9GOzs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTBGO0tBRXBHOzs7O2FBQ0Y7Ozs7O2NBR1Qsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFFWCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNJLHdCQUFDLE9BQUQsYUFFSSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBMkQ7T0FFckU7Ozs7aUJBQ0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQW9EO09BRTlEOzs7O2VBQ0Y7Ozs7O09BRUosU0FDRyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBOEM7UUFBUzs7Ozs7T0FDbkU7Ozs7O09BR1Qsd0JBQUMsUUFBRDtRQUFNLFVBQVU7UUFBYSxXQUFVO2tCQUF2QztTQUNJLHdCQUFDLE9BQUQsYUFFSSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBbUQ7U0FFN0Q7Ozs7bUJBQ1Asd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxNQUFEO1dBQU0sTUFBTTtXQUFJLFdBQVU7VUFBZ0Y7Ozs7b0JBRTFHLHdCQUFDLFNBQUQ7V0FDSSxNQUFLO1dBQ0wsYUFBWTtXQUNaLE9BQU87V0FDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztXQUN4QztXQUNBLFdBQVU7VUFDYjs7OztrQkFDQTs7Ozs7aUJBQ0o7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFtRDtTQUU3RDs7OzttQkFDUCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNJLHdCQUFDLE1BQUQ7WUFBTSxNQUFNO1lBQUksV0FBVTtXQUFnRjs7Ozs7V0FDMUcsd0JBQUMsU0FBRDtZQUNJLE1BQU0sZUFBZSxTQUFTO1lBQzlCLGFBQVk7WUFDWixPQUFPO1lBQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7WUFDM0M7WUFDQSxXQUFVO1dBQ2I7Ozs7O1dBRUQsd0JBQUMsVUFBRDtZQUNJLE1BQUs7WUFDTCxlQUFlLGdCQUFnQixDQUFDLFlBQVk7WUFDNUMsV0FBVTtZQUNWLFVBQVM7c0JBRVIsZUFDRyx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7O3VCQUVuQix3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OztXQUVoQjs7Ozs7VUFDUDs7Ozs7aUJBQ0o7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBakIsQ0FDSSx3QkFBQyxTQUFEO1lBQ0ksTUFBSztZQUNMLFNBQVM7WUFDVCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sT0FBTztZQUMvQyxXQUFVO1dBQ2I7Ozs7cUJBQ0Qsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQW9DO1dBQWdCOzs7O21CQUNqRTs7Ozs7b0JBQ1Asd0JBQUMsTUFBRDtXQUNJLElBQUc7V0FDSCxXQUFVO3FCQUNiO1VBRUs7Ozs7a0JBQ0w7Ozs7OztTQUVMLHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsVUFBVTtVQUNWLFdBQVU7b0JBRVQsVUFDRyxnREFDSSx3QkFBQyxTQUFEO1dBQVMsTUFBTTtXQUFJLFdBQVU7VUFBZ0I7Ozs7b0JBQzdDLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7OztrQkFDMUI7Ozs7cUJBRUYsK0NBQ0ksd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OzttQkFDM0I7Ozs7O1NBRUY7Ozs7O1FBQ047Ozs7OztPQUVOLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW9DO1FBQXdCOzs7O2tCQUM1RSx3QkFBQyxNQUFEO1NBQ0ksSUFBRztTQUNILFdBQVU7bUJBQ2I7UUFFSzs7OztnQkFDTDs7Ozs7O01BRUo7Ozs7OztJQUNKOzs7O1lBQ0E7Ozs7OztFQUNKOzs7Ozs7QUFFYjs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxvZ2luLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgbG9naW4sIHNhdmVTZXNzaW9uLCBpc0F1dGhlbnRpY2F0ZWQgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IEZpbGVUZXh0LCBBcnJvd1JpZ2h0LCBMb2NrLCBNYWlsLCBMb2FkZXIyLCBFeWUsIEV5ZU9mZiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmNvbnN0IExvZ2luID0gKCkgPT4ge1xuICAgIGNvbnN0IFtzaG93UGFzc3dvcmQsIHNldFNob3dQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW3JlbWVtYmVyTWUsIHNldFJlbWVtYmVyTWVdID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBbc2VhcmNoUGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGlzQXV0aGVudGljYXRlZCgpKSB7XG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL2Rhc2hib2FyZCcsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZWFzb24gPSBzZWFyY2hQYXJhbXMuZ2V0KCdyZWFzb24nKTtcbiAgICAgICAgaWYgKHJlYXNvbiA9PT0gJ3Nlc3Npb25fZXhwaXJlZCcpIHtcbiAgICAgICAgICAgIHNldEVycm9yKCdTZXNpIEFuZGEgdGVsYWggYmVyYWtoaXIuIFNpbGFrYW4gbG9naW4ga2VtYmFsaS4nKTtcbiAgICAgICAgfVxuICAgIH0sIFtuYXZpZ2F0ZSwgc2VhcmNoUGFyYW1zXSk7XG5cbiAgICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgc2V0RXJyb3IoJycpO1xuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBsb2dpbihlbWFpbC50cmltKCksIHBhc3N3b3JkKTtcblxuICAgICAgICAgICAgaWYgKHJlc3VsdC5vayAmJiByZXN1bHQuZGF0YT8udG9rZW4pIHtcbiAgICAgICAgICAgICAgICBzYXZlU2Vzc2lvbihyZXN1bHQuZGF0YSwgcmVtZW1iZXJNZSk7XG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoJy9kYXNoYm9hcmQnKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc2V0RXJyb3IocmVzdWx0Lm1lc3NhZ2UgfHwgJ0VtYWlsIGF0YXUgcGFzc3dvcmQgc2FsYWguJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgTG9naW46JywgZXJyKTtcbiAgICAgICAgICAgIHNldEVycm9yKCdUZXJqYWRpIGtlc2FsYWhhbiBrb25la3NpIGtlIHNlcnZlci4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIHJldHVybiAoXG48ZGl2IGNsYXNzTmFtZT1cImgtc2NyZWVuIG1heC1oLXNjcmVlbiB3LWZ1bGwgYmctWyMwMDRENEVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBzbTpwLTYgbGc6cC0xMiByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gc2VsZWN0LW5vbmUgdG91Y2gtbm9uZVwiPiAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBwb2ludGVyLWV2ZW50cy1ub25lXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDIwMGRlZywgIzJFRDhDMyAwJSwgIzBGQTg5RSAzNSUsICMwMTgwODEgNzUlLCAjMDA0RDRFIDEwMCUpJ1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICB7LyogQnVsYXRhbiBHcmFkaWVuIEtpcmkgQXRhcyAqL31cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBwb2ludGVyLWV2ZW50cy1ub25lIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6ICdjbGFtcCgzNTBweCwgNDV2dywgNzUwcHgpJyxcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAnY2xhbXAoMzUwcHgsIDQ1dncsIDc1MHB4KScsXG4gICAgICAgICAgICAgICAgICAgIHRvcDogJy0xMCUnLFxuICAgICAgICAgICAgICAgICAgICBsZWZ0OiAnLTEwJScsXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQoLTE0M2RlZywgIzJFRDhDMyAwJSwgcmdiYSgxMCwgOTUsIDExMCwgMC43KSAxMDAlKScsXG4gICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuNixcbiAgICAgICAgICAgICAgICAgICAgekluZGV4OiAxXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiBCdWxhdGFuIEdyYWRpZW4gS2FuYW4gQmF3YWggKi99XG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcG9pbnRlci1ldmVudHMtbm9uZSByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAnY2xhbXAoMzUwcHgsIDQ1dncsIDc1MHB4KScsXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogJ2NsYW1wKDM1MHB4LCA0NXZ3LCA3NTBweCknLFxuICAgICAgICAgICAgICAgICAgICBib3R0b206ICctMTAlJyxcbiAgICAgICAgICAgICAgICAgICAgcmlnaHQ6ICctMTAlJyxcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCgxMzVkZWcsICMyRUQ4QzMgMCUsIHJnYmEoMTAsIDI5LCA5MywgMC43KSAxMDAlKScsXG4gICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuOCxcbiAgICAgICAgICAgICAgICAgICAgekluZGV4OiAxXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiBDb250YWluZXIgVXRhbWEgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgdy1mdWxsIG1heC13LTZ4bCBmbGV4IGZsZXgtY29sIGxnOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTggbGc6Z2FwLTEyIG15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB7LyogTGVmdCBzaWRlIGJyYW5kaW5nICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGxnOnctMS8yIHRleHQtd2hpdGUgc3BhY2UteS00IHRleHQtY2VudGVyIGxnOnRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC00eGwgc206dGV4dC01eGwgbGc6dGV4dC02eGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IGxlYWRpbmctdGlnaHQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQnVhdCBUYW5wYSBMaW1pdCFcbiAgICAgICAgICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIHNtOnRleHQtbGcgdGV4dC13aGl0ZS85NSBmb250LW1lZGl1bSBsZWFkaW5nLXJlbGF4ZWQgbWF4LXctbGcgbXgtYXV0byBsZzpteC0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBCdWF0IGZvcm11bGlyLCBrdWlzIGludGVyYWt0aWYsIHN1cnZlaSwgZGFuIGV2YWx1YXNpIGRlbmdhbiBwZW5nYWxhbWFuIHlhbmcgY2VwYXQsIGZsZWtzaWJlbCwgZGFuIHJlc3BvbnNpZi5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFJpZ2h0IHNpZGUgZm9ybSBjYXJkICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbGc6dy0xLzIgbWF4LXctbWRcIj5cbiAgICAgICAgICAgICAgICB7LyogTWVuZ3ViYWggYmFja2dyb3VuZCBkYXJpIGJnLXdoaXRlLzIwIG1lbmphZGkgYmctYmxhY2svNDAgYWdhciBsZWJpaCBnZWxhcCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy1ibGFjay80MCBiYWNrZHJvcC1ibHVyLVsyMHB4XSBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHJvdW5kZWQtWzI4cHhdIHAtNiBzbTpwLTEwIHNoYWRvdy1bMF84cHhfMzJweF8wX3JnYmEoMCwwLDAsMC4zNyldIHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1lbmd1YmFoIHdhcm5hIHRla3MganVkdWwgJiBkZXNrcmlwc2kga2UgbnVhbnNhIHB1dGloICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIHNtOnRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VsYW1hdCBEYXRhbmchXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUvNzAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1hc3VrIGtlIGFrdW4gQW5kYSB1bnR1ayBtZW5nYWtzZXMgZm9ybXVsaXIgZGFuIHJlc3BvbnNcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctcmVkLTUwMC8yMCBib3JkZXIgYm9yZGVyLXJlZC01MDAvMzAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtcmVkLTMwMCB0ZXh0LWNlbnRlclwiPntlcnJvcn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTWVuZ3ViYWggd2FybmEgbGFiZWwgbWVuamFkaSBwdXRpaCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUvOTAgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVtYWlsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNYWlsIHNpemU9ezE2fSBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC13aGl0ZS81MCBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIElucHV0IG1lbmdndW5ha2FuIGJhY2tncm91bmQgZ2VsYXAgdHJhbnNwYXJhbiAoYmctYmxhY2svMzApIGRlbmdhbiB0ZWtzIHB1dGloICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIm5hbWFAZW1haWwuY29tXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC0xMCBwci00IHB5LTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIGJnLWJsYWNrLzMwIHRleHQtd2hpdGUgcGxhY2Vob2xkZXI6dGV4dC13aGl0ZS80MCBmb250LW1lZGl1bSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6YmctYmxhY2svNTAgZm9jdXM6Ym9yZGVyLVsjMkVEOEMzXSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzJFRDhDM10gdGV4dC14cyBzbTp0ZXh0LXNtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1pbm5lclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUvOTAgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2NrIHNpemU9ezE2fSBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC13aGl0ZS81MCBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPXtzaG93UGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC0xMCBwci0xMCBweS0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCBiZy1ibGFjay8zMCB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyOnRleHQtd2hpdGUvNDAgZm9udC1tZWRpdW0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJnLWJsYWNrLzUwIGZvY3VzOmJvcmRlci1bIzJFRDhDM10gZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctWyMyRUQ4QzNdIHRleHQteHMgc206dGV4dC1zbSB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctaW5uZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGFzc3dvcmQoIXNob3dQYXNzd29yZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtd2hpdGUvNTAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBwLTAuNSBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFiSW5kZXg9XCItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93UGFzc3dvcmQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV5ZU9mZiBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV5ZSBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgc2VsZWN0LW5vbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cmVtZW1iZXJNZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVtZW1iZXJNZShlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgcm91bmRlZCB0ZXh0LVsjMEZBODlFXSBmb2N1czpyaW5nLVsjMEZBODlFXSBhY2NlbnQtWyMwRkE4OUVdIGJnLWJsYWNrLzQwIGJvcmRlci13aGl0ZS8yMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC13aGl0ZS84MFwiPkluZ2F0IFNheWE8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9mb3Jnb3QtcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUvODAgaG92ZXI6dGV4dC1bIzJFRDhDM10gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTHVwYSBwYXNzd29yZD9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtdC00IHB5LTMuNSBweC02IGJnLVsjMEZBODlFXSBob3ZlcjpiZy1bIzBkOTY4ZF0gYWN0aXZlOnNjYWxlLVswLjk4XSB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLWZ1bGwgc2hhZG93LVswXzZweF8yMHB4X3JnYmEoMTUsMTY4LDE1OCwwLjQpXSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgdGV4dC14cyBzbTp0ZXh0LXNtIHRyYWNraW5nLXdpZGUgZGlzYWJsZWQ6b3BhY2l0eS02MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NZW1wcm9zZXMuLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NYXN1ayBrZSBBa3VuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXdoaXRlLzEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUvNzBcIj5CZWx1bSBwdW55YSBha3VuPyA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3JlZ2lzdGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjMkVEOEMzXSBob3Zlcjp1bmRlcmxpbmUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERhZnRhciBTZWthcmFuZ1xuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IExvZ2luOyJdfQ==