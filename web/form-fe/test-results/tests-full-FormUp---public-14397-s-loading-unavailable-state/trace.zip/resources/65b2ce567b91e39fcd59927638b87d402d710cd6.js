import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Topbar.jsx");const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import { Search, Sun, Moon, Menu, X, FileText, LayoutDashboard, Folder, MessageSquare, LayoutTemplate, History, LogOut, Shield, HelpCircle } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate, useLocation, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { getLocalUser, assetUrl, clearSession } from "/src/services/apiService.js";
import useDebounce from "/src/hooks/useDebounce.js";
import UserGuideModal from "/src/components/ui/UserGuideModal.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/layout/Topbar.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function Topbar({ searchQuery = "", onSearchChange = null, placeholder = "Cari formulir, respons..." }) {
	_s();
	const navigate = useNavigate();
	const location = useLocation();
	const [user] = useState(() => getLocalUser());
	const [internalSearch, setInternalSearch] = useState(searchQuery || "");
	const debouncedSearch = useDebounce(internalSearch, 300);
	const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
	const [guideModalOpen, setGuideModalOpen] = useState(false);
	const [isDark, setIsDark] = useState(() => {
		return localStorage.getItem("theme") === "dark";
	});
	useEffect(() => {
		if (isDark) {
			document.documentElement.classList.add("dark");
			document.documentElement.setAttribute("data-theme", "dark");
			localStorage.setItem("theme", "dark");
		} else {
			document.documentElement.classList.remove("dark");
			document.documentElement.setAttribute("data-theme", "light");
			localStorage.setItem("theme", "light");
		}
	}, [isDark]);
	// Mencegah background page ter-scroll saat menu drawer mobile terbuka
	useEffect(() => {
		if (mobileMenuOpen) {
			document.body.style.overflow = "hidden";
		} else {
			document.body.style.overflow = "unset";
		}
		return () => {
			document.body.style.overflow = "unset";
		};
	}, [mobileMenuOpen]);
	useEffect(() => {
		if (onSearchChange) {
			onSearchChange(debouncedSearch);
		}
	}, [debouncedSearch, onSearchChange]);
	const handleInputChange = (e) => {
		setInternalSearch(e.target.value);
	};
	const handleLogout = () => {
		clearSession();
		navigate("/login", { replace: true });
	};
	const menuItems = [
		{
			path: "/dashboard",
			icon: LayoutDashboard,
			label: "Dashboard"
		},
		{
			path: "/my-forms",
			icon: Folder,
			label: "Formulir Saya"
		},
		{
			path: "/responses",
			icon: MessageSquare,
			label: "Respons"
		},
		{
			path: "/templates",
			icon: LayoutTemplate,
			label: "Templat"
		},
		{
			path: "/history",
			icon: History,
			label: "Riwayat"
		}
	];
	const userRole = (user?.role || "").toUpperCase();
	if (userRole === "ADMIN" || userRole === "SUPER_ADMIN") {
		menuItems.push({
			path: "/admin",
			icon: Shield,
			label: "Kontrol Admin"
		});
	}
	const currentValue = internalSearch;
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("header", {
			className: "bg-white dark:bg-slate-900 p-3 sm:p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between gap-2 sm:gap-4 transition-colors",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 sm:gap-3 flex-1 min-w-0",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setMobileMenuOpen(true),
					className: "md:hidden p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer shrink-0",
					title: "Buka Menu",
					children: /* @__PURE__ */ _jsxDEV(Menu, { size: 20 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 25
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative flex-1 min-w-0",
					"data-tour": "topbar-search",
					children: [/* @__PURE__ */ _jsxDEV(Search, {
						size: 18,
						className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 pointer-events-none"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: currentValue,
						onChange: handleInputChange,
						placeholder,
						className: "w-full pl-10 pr-4 py-2 sm:py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-[#00897B] dark:focus:ring-teal-400 transition-all text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 font-medium"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 sm:gap-4 shrink-0",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "hidden md:flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setIsDark(false),
						className: `p-1.5 rounded-lg transition-all cursor-pointer ${!isDark ? "bg-white text-amber-500 shadow-xs" : "text-slate-400 hover:text-slate-600"}`,
						title: "Mode Terang",
						children: /* @__PURE__ */ _jsxDEV(Sun, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 29
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setIsDark(true),
						className: `p-1.5 rounded-lg transition-all cursor-pointer ${isDark ? "bg-slate-900 text-teal-400 shadow-xs" : "text-slate-400 hover:text-slate-600"}`,
						title: "Mode Gelap",
						children: /* @__PURE__ */ _jsxDEV(Moon, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 29
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 126,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => navigate("/profile"),
					className: "flex items-center gap-3 pl-2 sm:pl-3 md:border-l border-slate-200 dark:border-slate-700 hover:opacity-85 transition-opacity cursor-pointer text-left shrink-0",
					title: "Pengaturan Akun",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-right hidden sm:block",
						children: /* @__PURE__ */ _jsxDEV("h4", {
							className: "text-xs font-bold text-slate-800 dark:text-slate-100",
							children: user?.fullname || "Pengguna"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 29
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("img", {
						src: assetUrl(user?.profileImage, `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.fullname || "U")}&background=00897B&color=fff&size=64`),
						alt: "Profil",
						className: "w-9 h-9 rounded-full object-cover border-2 border-teal-500/30 dark:border-teal-500/50 shadow-xs"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 97,
			columnNumber: 13
		}, this),
		mobileMenuOpen && /* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 z-50 md:hidden flex w-screen h-screen",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity",
				onClick: () => setMobileMenuOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 179,
				columnNumber: 21
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "relative w-72 max-w-[85vw] h-full min-h-screen bg-[#005B52] dark:bg-slate-900 text-white flex flex-col justify-between p-6 shadow-2xl z-10 overflow-y-auto animate-in slide-in-from-left duration-200",
				children: [
					"                        ",
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV(Link, {
									to: "/dashboard",
									onClick: () => setMobileMenuOpen(false),
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-2 bg-white/15 dark:bg-white/10 rounded-xl",
										children: /* @__PURE__ */ _jsxDEV(FileText, {
											size: 20,
											className: "text-white"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 190,
											columnNumber: 41
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 189,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-lg font-extrabold tracking-tight text-white",
										children: "FormUp"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 192,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 188,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setMobileMenuOpen(false),
									className: "p-1.5 text-white/80 hover:text-white rounded-lg cursor-pointer",
									children: /* @__PURE__ */ _jsxDEV(X, { size: 20 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 199,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 194,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-full flex items-center bg-black/20 dark:bg-slate-800/80 p-1.5 rounded-xl border border-white/10 dark:border-slate-700/60",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setIsDark(false),
									className: `flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${!isDark ? "bg-white text-amber-500 shadow-md" : "text-teal-100/70 hover:text-white dark:text-slate-400 dark:hover:text-slate-200"}`,
									title: "Mode Terang",
									children: /* @__PURE__ */ _jsxDEV(Sun, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 215,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 205,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setIsDark(true),
									className: `flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${isDark ? "bg-slate-900 text-teal-400 shadow-md" : "text-teal-100/70 hover:text-white dark:text-slate-400 dark:hover:text-slate-200"}`,
									title: "Mode Gelap",
									children: /* @__PURE__ */ _jsxDEV(Moon, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 228,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV("nav", {
								className: "space-y-1.5",
								children: [menuItems.map((item) => {
									const Icon = item.icon;
									const isActive = location.pathname.startsWith(item.path);
									return /* @__PURE__ */ _jsxDEV(Link, {
										to: item.path,
										onClick: () => setMobileMenuOpen(false),
										className: `flex items-center gap-3 px-4 py-3 font-bold text-sm rounded-xl transition-all ${isActive ? "bg-white/20 dark:bg-teal-600/30 text-white shadow-xs border border-white/20 dark:border-teal-500/40" : "text-teal-100/80 dark:text-slate-300 hover:bg-white/10 dark:hover:bg-slate-800/80 hover:text-white"}`,
										children: [/* @__PURE__ */ _jsxDEV(Icon, {
											size: 18,
											className: isActive ? "text-teal-200 dark:text-teal-300" : "text-teal-200/70 dark:text-slate-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 249,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.label }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 250,
											columnNumber: 45
										}, this)]
									}, item.path, true, {
										fileName: _jsxFileName,
										lineNumber: 239,
										columnNumber: 41
									}, this);
								}), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setMobileMenuOpen(false);
										setGuideModalOpen(true);
									},
									className: "w-full flex items-center gap-3 px-4 py-3 font-bold text-sm rounded-xl text-teal-100/80 dark:text-slate-300 hover:bg-white/10 dark:hover:bg-slate-800/80 hover:text-white transition-all cursor-pointer text-left",
									children: [/* @__PURE__ */ _jsxDEV(HelpCircle, {
										size: 18,
										className: "text-teal-200/70 dark:text-slate-400"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 264,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Panduan Pengguna" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 265,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 256,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 233,
								columnNumber: 29
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 264
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-4 mt-6 border-t border-white/10 dark:border-slate-800 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV(Link, {
							to: "/profile",
							onClick: () => setMobileMenuOpen(false),
							className: "flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-white/10 transition-colors",
							children: [/* @__PURE__ */ _jsxDEV("img", {
								src: assetUrl(user?.profileImage, `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.fullname || "U")}&background=00897B&color=fff&size=64`),
								alt: "Profil",
								className: "w-8 h-8 rounded-full object-cover border border-teal-300/40"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 277,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-left overflow-hidden",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-bold text-white truncate",
									children: user?.fullname || "Pengguna"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-teal-200/80 truncate",
									children: ["@", user?.username || "user"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 287,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 285,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleLogout,
							className: "w-full flex items-center gap-3 px-4 py-3 font-bold text-sm text-teal-100 hover:text-white hover:bg-white/10 dark:text-red-400 dark:hover:bg-red-950/30 dark:hover:text-red-300 rounded-xl transition-all cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(LogOut, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 295,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Keluar" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 296,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 291,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 271,
						columnNumber: 25
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 185,
				columnNumber: 25
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 177,
			columnNumber: 17
		}, this),
		/* @__PURE__ */ _jsxDEV(UserGuideModal, {
			isOpen: guideModalOpen,
			onClose: () => setGuideModalOpen(false),
			onStartTour: () => {
				setGuideModalOpen(false);
				if (window.__startFormUpTour) {
					window.__startFormUpTour();
				}
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 304,
			columnNumber: 13
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 96,
		columnNumber: 9
	}, this);
}
_s(Topbar, "D7i9g8R7UR0uBkwfroPVlJdU4fg=", false, function() {
	return [
		useNavigate,
		useLocation,
		useDebounce
	];
});
_c = Topbar;
var _c;
$RefreshReg$(_c, "Topbar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Topbar.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/layout/Topbar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/layout/Topbar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/layout/Topbar.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDSSxRQUNBLEtBQ0EsTUFDQSxNQUNBLEdBQ0EsVUFDQSxpQkFDQSxRQUNBLGVBQ0EsZ0JBQ0EsU0FDQSxRQUNBLFFBQ0Esa0JBQ0c7QUFDUCxTQUFTLFVBQVUsaUJBQWlCO0FBQ3BDLFNBQVMsYUFBYSxhQUFhLFlBQVk7QUFDL0MsU0FBUyxjQUFjLFVBQVUsb0JBQW9CO0FBQ3JELE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sb0JBQW9COzs7O0FBRTNCLGVBQWUsU0FBUyxPQUFPLEVBQzNCLGNBQWMsSUFDZCxpQkFBaUIsTUFDakIsY0FBYywrQkFDZjs7Q0FDQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsUUFBUSxlQUFlLGFBQWEsQ0FBQztDQUM1QyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLGVBQWUsRUFBRTtDQUN0RSxNQUFNLGtCQUFrQixZQUFZLGdCQUFnQixHQUFHO0NBQ3ZELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsS0FBSztDQUMxRCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEtBQUs7Q0FFMUQsTUFBTSxDQUFDLFFBQVEsYUFBYSxlQUFlO0VBQ3ZDLE9BQU8sYUFBYSxRQUFRLE9BQU8sTUFBTTtDQUM3QyxDQUFDO0NBRUQsZ0JBQWdCO0VBQ1osSUFBSSxRQUFRO0dBQ1IsU0FBUyxnQkFBZ0IsVUFBVSxJQUFJLE1BQU07R0FDN0MsU0FBUyxnQkFBZ0IsYUFBYSxjQUFjLE1BQU07R0FDMUQsYUFBYSxRQUFRLFNBQVMsTUFBTTtFQUN4QyxPQUFPO0dBQ0gsU0FBUyxnQkFBZ0IsVUFBVSxPQUFPLE1BQU07R0FDaEQsU0FBUyxnQkFBZ0IsYUFBYSxjQUFjLE9BQU87R0FDM0QsYUFBYSxRQUFRLFNBQVMsT0FBTztFQUN6QztDQUNKLEdBQUcsQ0FBQyxNQUFNLENBQUM7O0NBR1gsZ0JBQWdCO0VBQ1osSUFBSSxnQkFBZ0I7R0FDaEIsU0FBUyxLQUFLLE1BQU0sV0FBVztFQUNuQyxPQUFPO0dBQ0gsU0FBUyxLQUFLLE1BQU0sV0FBVztFQUNuQztFQUVBLGFBQWE7R0FDVCxTQUFTLEtBQUssTUFBTSxXQUFXO0VBQ25DO0NBQ0osR0FBRyxDQUFDLGNBQWMsQ0FBQztDQUVuQixnQkFBZ0I7RUFDWixJQUFJLGdCQUFnQjtHQUNoQixlQUFlLGVBQWU7RUFDbEM7Q0FDSixHQUFHLENBQUMsaUJBQWlCLGNBQWMsQ0FBQztDQUVwQyxNQUFNLHFCQUFxQixNQUFNO0VBQzdCLGtCQUFrQixFQUFFLE9BQU8sS0FBSztDQUNwQztDQUVBLE1BQU0scUJBQXFCO0VBQ3ZCLGFBQWE7RUFDYixTQUFTLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQztDQUN4QztDQUVBLE1BQU0sWUFBWTtFQUNkO0dBQUUsTUFBTTtHQUFjLE1BQU07R0FBaUIsT0FBTztFQUFZO0VBQ2hFO0dBQUUsTUFBTTtHQUFhLE1BQU07R0FBUSxPQUFPO0VBQWdCO0VBQzFEO0dBQUUsTUFBTTtHQUFjLE1BQU07R0FBZSxPQUFPO0VBQVU7RUFDNUQ7R0FBRSxNQUFNO0dBQWMsTUFBTTtHQUFnQixPQUFPO0VBQVU7RUFDN0Q7R0FBRSxNQUFNO0dBQVksTUFBTTtHQUFTLE9BQU87RUFBVTtDQUN4RDtDQUVBLE1BQU0sWUFBWSxNQUFNLFFBQVEsR0FBRSxDQUFFLFlBQVk7Q0FDaEQsSUFBSSxhQUFhLFdBQVcsYUFBYSxlQUFlO0VBQ3BELFVBQVUsS0FBSztHQUFFLE1BQU07R0FBVSxNQUFNO0dBQVEsT0FBTztFQUFnQixDQUFDO0NBQzNFO0NBRUEsTUFBTSxlQUFlO0NBRXJCLE9BQ0k7RUFDSSx3QkFBQyxVQUFEO0dBQVEsV0FBVTthQUFsQixDQUVJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFSSx3QkFBQyxVQUFEO0tBQ0ksTUFBSztLQUNMLGVBQWUsa0JBQWtCLElBQUk7S0FDckMsV0FBVTtLQUNWLE9BQU07ZUFFTix3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztJQUNiOzs7O2NBR1Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBMEIsYUFBVTtlQUFuRCxDQUNJLHdCQUFDLFFBQUQ7TUFBUSxNQUFNO01BQUksV0FBVTtLQUFxRzs7OztlQUNqSSx3QkFBQyxTQUFEO01BQ0ksTUFBSztNQUNMLE9BQU87TUFDUCxVQUFVO01BQ0c7TUFDYixXQUFVO0tBQ2I7Ozs7YUFDQTs7Ozs7WUFDSjs7Ozs7YUFHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNJLHdCQUFDLFVBQUQ7TUFDSSxNQUFLO01BQ0wsZUFBZSxVQUFVLEtBQUs7TUFDOUIsV0FBVyxrREFDUCxDQUFDLFNBQ0ssc0NBQ0E7TUFFVixPQUFNO2dCQUVOLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7O0tBQ1o7Ozs7ZUFDUix3QkFBQyxVQUFEO01BQ0ksTUFBSztNQUNMLGVBQWUsVUFBVSxJQUFJO01BQzdCLFdBQVcsa0RBQ1AsU0FDTSx5Q0FDQTtNQUVWLE9BQU07Z0JBRU4sd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7S0FDYjs7OzthQUNQOzs7OztjQUlMLHdCQUFDLFVBQUQ7S0FDSSxlQUFlLFNBQVMsVUFBVTtLQUNsQyxXQUFVO0tBQ1YsT0FBTTtlQUhWLENBS0ksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1gsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXdELE1BQU0sWUFBWTtNQUFlOzs7OztLQUN0Rzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFDSSxLQUFLLFNBQ0QsTUFBTSxjQUNOLG9DQUFvQyxtQkFBbUIsTUFBTSxZQUFZLEdBQUcsRUFBRSxxQ0FDbEY7TUFDQSxLQUFJO01BQ0osV0FBVTtLQUNiOzs7O2FBQ0c7Ozs7O1lBQ1A7Ozs7O1dBQ0Q7Ozs7OztFQUdQLGtCQUNHLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FFSSx3QkFBQyxPQUFEO0lBQ0ksV0FBVTtJQUNWLGVBQWUsa0JBQWtCLEtBQUs7R0FDekM7Ozs7YUFHRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQXVOO0tBQXdCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRTNPLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsTUFBRDtTQUFNLElBQUc7U0FBYSxlQUFlLGtCQUFrQixLQUFLO1NBQUcsV0FBVTttQkFBekUsQ0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWCx3QkFBQyxVQUFEO1dBQVUsTUFBTTtXQUFJLFdBQVU7VUFBYzs7Ozs7U0FDM0M7Ozs7bUJBQ0wsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW1EO1NBQVk7Ozs7aUJBQzdFOzs7OztrQkFDTix3QkFBQyxVQUFEO1NBQ0ksTUFBSztTQUNMLGVBQWUsa0JBQWtCLEtBQUs7U0FDdEMsV0FBVTttQkFFVix3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztRQUNWOzs7O2dCQUNQOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLFVBQUQ7U0FDSSxNQUFLO1NBQ0wsZUFBZSxVQUFVLEtBQUs7U0FDOUIsV0FBVyxpSEFDUCxDQUFDLFNBQ0ssc0NBQ0E7U0FFVixPQUFNO21CQUVOLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7O1FBQ1o7Ozs7a0JBRVIsd0JBQUMsVUFBRDtTQUNJLE1BQUs7U0FDTCxlQUFlLFVBQVUsSUFBSTtTQUM3QixXQUFXLGlIQUNQLFNBQ00seUNBQ0E7U0FFVixPQUFNO21CQUVOLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O1FBQ2I7Ozs7Z0JBQ1A7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ssVUFBVSxLQUFLLFNBQVM7U0FDckIsTUFBTSxPQUFPLEtBQUs7U0FDbEIsTUFBTSxXQUFXLFNBQVMsU0FBUyxXQUFXLEtBQUssSUFBSTtTQUV2RCxPQUNJLHdCQUFDLE1BQUQ7VUFFSSxJQUFJLEtBQUs7VUFDVCxlQUFlLGtCQUFrQixLQUFLO1VBQ3RDLFdBQVcsaUZBQ1AsV0FDTSx3R0FDQTtvQkFQZCxDQVVJLHdCQUFDLE1BQUQ7V0FBTSxNQUFNO1dBQUksV0FBVyxXQUFXLHFDQUFxQztVQUF5Qzs7OztvQkFDcEgsd0JBQUMsUUFBRCxZQUFPLEtBQUssTUFBWTs7OztrQkFDdEI7WUFYRyxLQUFLOzs7O2dCQVdSO1FBRWQsQ0FBQyxHQUdELHdCQUFDLFVBQUQ7U0FDSSxNQUFLO1NBQ0wsZUFBZTtVQUNYLGtCQUFrQixLQUFLO1VBQ3ZCLGtCQUFrQixJQUFJO1NBQzFCO1NBQ0EsV0FBVTttQkFOZCxDQVFJLHdCQUFDLFlBQUQ7VUFBWSxNQUFNO1VBQUksV0FBVTtTQUF3Qzs7OzttQkFDeEUsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztpQkFDeEI7Ozs7O2dCQUNQOzs7Ozs7TUFDSjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxNQUFEO09BQ0ksSUFBRztPQUNILGVBQWUsa0JBQWtCLEtBQUs7T0FDdEMsV0FBVTtpQkFIZCxDQUtJLHdCQUFDLE9BQUQ7UUFDSSxLQUFLLFNBQ0QsTUFBTSxjQUNOLG9DQUFvQyxtQkFBbUIsTUFBTSxZQUFZLEdBQUcsRUFBRSxxQ0FDbEY7UUFDQSxLQUFJO1FBQ0osV0FBVTtPQUNiOzs7O2lCQUNELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlDLE1BQU0sWUFBWTtRQUFjOzs7O2tCQUN0Rix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYixDQUFxRCxLQUFFLE1BQU0sWUFBWSxNQUFVOzs7OztnQkFDbEY7Ozs7O2VBQ0g7Ozs7O2dCQUVOLHdCQUFDLFVBQUQ7T0FDSSxTQUFTO09BQ1QsV0FBVTtpQkFGZCxDQUlJLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7aUJBQ25CLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7O2VBQ2Q7Ozs7O2NBQ1A7Ozs7OztJQUNKOzs7OztXQUNKOzs7Ozs7RUFJVCx3QkFBQyxnQkFBRDtHQUNJLFFBQVE7R0FDUixlQUFlLGtCQUFrQixLQUFLO0dBQ3RDLG1CQUFtQjtJQUNmLGtCQUFrQixLQUFLO0lBQ3ZCLElBQUksT0FBTyxtQkFBbUI7S0FDMUIsT0FBTyxrQkFBa0I7SUFDN0I7R0FDSjtFQUNIOzs7OztDQUNIOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRvcGJhci5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgICBTZWFyY2gsXG4gICAgU3VuLFxuICAgIE1vb24sXG4gICAgTWVudSxcbiAgICBYLFxuICAgIEZpbGVUZXh0LFxuICAgIExheW91dERhc2hib2FyZCxcbiAgICBGb2xkZXIsXG4gICAgTWVzc2FnZVNxdWFyZSxcbiAgICBMYXlvdXRUZW1wbGF0ZSxcbiAgICBIaXN0b3J5LFxuICAgIExvZ091dCxcbiAgICBTaGllbGQsXG4gICAgSGVscENpcmNsZVxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VMb2NhdGlvbiwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgZ2V0TG9jYWxVc2VyLCBhc3NldFVybCwgY2xlYXJTZXNzaW9uIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgdXNlRGVib3VuY2UgZnJvbSAnLi4vLi4vaG9va3MvdXNlRGVib3VuY2UnO1xuaW1wb3J0IFVzZXJHdWlkZU1vZGFsIGZyb20gJy4uL3VpL1VzZXJHdWlkZU1vZGFsJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVG9wYmFyKHsgXG4gICAgc2VhcmNoUXVlcnkgPSAnJywgXG4gICAgb25TZWFyY2hDaGFuZ2UgPSBudWxsLCBcbiAgICBwbGFjZWhvbGRlciA9ICdDYXJpIGZvcm11bGlyLCByZXNwb25zLi4uJyBcbn0pIHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuICAgIGNvbnN0IFt1c2VyXSA9IHVzZVN0YXRlKCgpID0+IGdldExvY2FsVXNlcigpKTtcbiAgICBjb25zdCBbaW50ZXJuYWxTZWFyY2gsIHNldEludGVybmFsU2VhcmNoXSA9IHVzZVN0YXRlKHNlYXJjaFF1ZXJ5IHx8ICcnKTtcbiAgICBjb25zdCBkZWJvdW5jZWRTZWFyY2ggPSB1c2VEZWJvdW5jZShpbnRlcm5hbFNlYXJjaCwgMzAwKTtcbiAgICBjb25zdCBbbW9iaWxlTWVudU9wZW4sIHNldE1vYmlsZU1lbnVPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZ3VpZGVNb2RhbE9wZW4sIHNldEd1aWRlTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IFtpc0RhcmssIHNldElzRGFya10gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgICAgIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndGhlbWUnKSA9PT0gJ2RhcmsnO1xuICAgIH0pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGlzRGFyaykge1xuICAgICAgICAgICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2RhcmsnKTtcbiAgICAgICAgICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zZXRBdHRyaWJ1dGUoJ2RhdGEtdGhlbWUnLCAnZGFyaycpO1xuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RoZW1lJywgJ2RhcmsnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdkYXJrJyk7XG4gICAgICAgICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2V0QXR0cmlidXRlKCdkYXRhLXRoZW1lJywgJ2xpZ2h0Jyk7XG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndGhlbWUnLCAnbGlnaHQnKTtcbiAgICAgICAgfVxuICAgIH0sIFtpc0RhcmtdKTtcblxuICAgIC8vIE1lbmNlZ2FoIGJhY2tncm91bmQgcGFnZSB0ZXItc2Nyb2xsIHNhYXQgbWVudSBkcmF3ZXIgbW9iaWxlIHRlcmJ1a2FcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAobW9iaWxlTWVudU9wZW4pIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSAnaGlkZGVuJztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSAndW5zZXQnO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSAndW5zZXQnO1xuICAgICAgICB9O1xuICAgIH0sIFttb2JpbGVNZW51T3Blbl0pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKG9uU2VhcmNoQ2hhbmdlKSB7XG4gICAgICAgICAgICBvblNlYXJjaENoYW5nZShkZWJvdW5jZWRTZWFyY2gpO1xuICAgICAgICB9XG4gICAgfSwgW2RlYm91bmNlZFNlYXJjaCwgb25TZWFyY2hDaGFuZ2VdKTtcblxuICAgIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcbiAgICAgICAgc2V0SW50ZXJuYWxTZWFyY2goZS50YXJnZXQudmFsdWUpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgICAgIGNsZWFyU2Vzc2lvbigpO1xuICAgICAgICBuYXZpZ2F0ZSgnL2xvZ2luJywgeyByZXBsYWNlOiB0cnVlIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBtZW51SXRlbXMgPSBbXG4gICAgICAgIHsgcGF0aDogJy9kYXNoYm9hcmQnLCBpY29uOiBMYXlvdXREYXNoYm9hcmQsIGxhYmVsOiAnRGFzaGJvYXJkJyB9LFxuICAgICAgICB7IHBhdGg6ICcvbXktZm9ybXMnLCBpY29uOiBGb2xkZXIsIGxhYmVsOiAnRm9ybXVsaXIgU2F5YScgfSxcbiAgICAgICAgeyBwYXRoOiAnL3Jlc3BvbnNlcycsIGljb246IE1lc3NhZ2VTcXVhcmUsIGxhYmVsOiAnUmVzcG9ucycgfSxcbiAgICAgICAgeyBwYXRoOiAnL3RlbXBsYXRlcycsIGljb246IExheW91dFRlbXBsYXRlLCBsYWJlbDogJ1RlbXBsYXQnIH0sXG4gICAgICAgIHsgcGF0aDogJy9oaXN0b3J5JywgaWNvbjogSGlzdG9yeSwgbGFiZWw6ICdSaXdheWF0JyB9LFxuICAgIF07XG5cbiAgICBjb25zdCB1c2VyUm9sZSA9ICh1c2VyPy5yb2xlIHx8ICcnKS50b1VwcGVyQ2FzZSgpO1xuICAgIGlmICh1c2VyUm9sZSA9PT0gJ0FETUlOJyB8fCB1c2VyUm9sZSA9PT0gJ1NVUEVSX0FETUlOJykge1xuICAgICAgICBtZW51SXRlbXMucHVzaCh7IHBhdGg6ICcvYWRtaW4nLCBpY29uOiBTaGllbGQsIGxhYmVsOiAnS29udHJvbCBBZG1pbicgfSk7XG4gICAgfVxuXG4gICAgY29uc3QgY3VycmVudFZhbHVlID0gaW50ZXJuYWxTZWFyY2g7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8PlxuICAgICAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTMgc206cC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIHNtOmdhcC00IHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgey8qIEhBTUJVUkdFUiArIFNFQVJDSCBDT05UQUlORVIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzbTpnYXAtMyBmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICB7LyogTU9CSUxFIEhBTUJVUkdFUiBCVVRUT04gKi99XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9iaWxlTWVudU9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtZDpoaWRkZW4gcC0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIHNocmluay0wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQnVrYSBNZW51XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnUgc2l6ZT17MjB9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTRUFSQ0ggSU5QVVQgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xIG1pbi13LTBcIiBkYXRhLXRvdXI9XCJ0b3BiYXItc2VhcmNoXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VhcmNoIHNpemU9ezE4fSBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17cGxhY2Vob2xkZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTEwIHByLTQgcHktMiBzbTpweS0yLjUgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvODAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC1zbSBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdIGRhcms6Zm9jdXM6cmluZy10ZWFsLTQwMCB0cmFuc2l0aW9uLWFsbCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIHBsYWNlaG9sZGVyOnRleHQtc2xhdGUtNDAwIGRhcms6cGxhY2Vob2xkZXI6dGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogUklHSFQgQ09OVFJPTFMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzbTpnYXAtNCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICB7LyogVE9HR0xFIERBUksgTU9ERSAoREVTS1RPUCBPTkxZKSAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHAtMSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzRGFyayhmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhaXNEYXJrIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgdGV4dC1hbWJlci01MDAgc2hhZG93LXhzJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTW9kZSBUZXJhbmdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTdW4gc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0RhcmsodHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0RhcmsgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1zbGF0ZS05MDAgdGV4dC10ZWFsLTQwMCBzaGFkb3cteHMnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJNb2RlIEdlbGFwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TW9vbiBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBVU0VSIFBST0ZJTEUgKi99XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvcHJvZmlsZScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcGwtMiBzbTpwbC0zIG1kOmJvcmRlci1sIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGhvdmVyOm9wYWNpdHktODUgdHJhbnNpdGlvbi1vcGFjaXR5IGN1cnNvci1wb2ludGVyIHRleHQtbGVmdCBzaHJpbmstMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlBlbmdhdHVyYW4gQWt1blwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodCBoaWRkZW4gc206YmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPnt1c2VyPy5mdWxsbmFtZSB8fCAnUGVuZ2d1bmEnfTwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Fzc2V0VXJsKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyPy5wcm9maWxlSW1hZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBodHRwczovL3VpLWF2YXRhcnMuY29tL2FwaS8/bmFtZT0ke2VuY29kZVVSSUNvbXBvbmVudCh1c2VyPy5mdWxsbmFtZSB8fCAnVScpfSZiYWNrZ3JvdW5kPTAwODk3QiZjb2xvcj1mZmYmc2l6ZT02NGBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIlByb2ZpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWZ1bGwgb2JqZWN0LWNvdmVyIGJvcmRlci0yIGJvcmRlci10ZWFsLTUwMC8zMCBkYXJrOmJvcmRlci10ZWFsLTUwMC81MCBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2hlYWRlcj5cblxuICAgICAgICAgICAgey8qIE1PQklMRSBEUkFXRVIgLyBTSURFQkFSICovfVxuICAgICAgICAgICAge21vYmlsZU1lbnVPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBtZDpoaWRkZW4gZmxleCB3LXNjcmVlbiBoLXNjcmVlblwiPlxuICAgICAgICAgICAgICAgICAgICB7LyogQmFja2Ryb3AgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNjAgYmFja2Ryb3AtYmx1ci14cyB0cmFuc2l0aW9uLW9wYWNpdHlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9iaWxlTWVudU9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBEcmF3ZXIgQ29udGVudCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy03MiBtYXgtdy1bODV2d10gaC1mdWxsIG1pbi1oLXNjcmVlbiBiZy1bIzAwNUI1Ml0gZGFyazpiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBwLTYgc2hhZG93LTJ4bCB6LTEwIG92ZXJmbG93LXktYXV0byBhbmltYXRlLWluIHNsaWRlLWluLWZyb20tbGVmdCBkdXJhdGlvbi0yMDBcIj4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89XCIvZGFzaGJvYXJkXCIgb25DbGljaz17KCkgPT4gc2V0TW9iaWxlTWVudU9wZW4oZmFsc2UpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctd2hpdGUvMTUgZGFyazpiZy13aGl0ZS8xMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LXdoaXRlXCI+Rm9ybVVwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9iaWxlTWVudU9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC13aGl0ZS84MCBob3Zlcjp0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVE9HR0xFIERBUksgTU9ERSAoTU9CSUxFIERSQVdFUiBPTkxZKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBiZy1ibGFjay8yMCBkYXJrOmJnLXNsYXRlLTgwMC84MCBwLTEuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItd2hpdGUvMTAgZGFyazpib3JkZXItc2xhdGUtNzAwLzYwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNEYXJrKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweS0yIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhaXNEYXJrIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSB0ZXh0LWFtYmVyLTUwMCBzaGFkb3ctbWQnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXRlYWwtMTAwLzcwIGhvdmVyOnRleHQtd2hpdGUgZGFyazp0ZXh0LXNsYXRlLTQwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIk1vZGUgVGVyYW5nXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFN1biBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzRGFyayh0cnVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweS0yIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0RhcmsgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTkwMCB0ZXh0LXRlYWwtNDAwIHNoYWRvdy1tZCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtdGVhbC0xMDAvNzAgaG92ZXI6dGV4dC13aGl0ZSBkYXJrOnRleHQtc2xhdGUtNDAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTW9kZSBHZWxhcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNb29uIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBOYXYgTGlua3MgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bWVudUl0ZW1zLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IGl0ZW0uaWNvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gbG9jYXRpb24ucGF0aG5hbWUuc3RhcnRzV2l0aChpdGVtLnBhdGgpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ucGF0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2l0ZW0ucGF0aH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNCBweS0zIGZvbnQtYm9sZCB0ZXh0LXNtIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlLzIwIGRhcms6YmctdGVhbC02MDAvMzAgdGV4dC13aGl0ZSBzaGFkb3cteHMgYm9yZGVyIGJvcmRlci13aGl0ZS8yMCBkYXJrOmJvcmRlci10ZWFsLTUwMC80MCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC10ZWFsLTEwMC84MCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXdoaXRlLzEwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzgwIGhvdmVyOnRleHQtd2hpdGUnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIHNpemU9ezE4fSBjbGFzc05hbWU9e2lzQWN0aXZlID8gJ3RleHQtdGVhbC0yMDAgZGFyazp0ZXh0LXRlYWwtMzAwJyA6ICd0ZXh0LXRlYWwtMjAwLzcwIGRhcms6dGV4dC1zbGF0ZS00MDAnfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1vYmlsZSBHdWlkZSBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRHdWlkZU1vZGFsT3Blbih0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNCBweS0zIGZvbnQtYm9sZCB0ZXh0LXNtIHJvdW5kZWQteGwgdGV4dC10ZWFsLTEwMC84MCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXdoaXRlLzEwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzgwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgdGV4dC1sZWZ0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEhlbHBDaXJjbGUgc2l6ZT17MTh9IGNsYXNzTmFtZT1cInRleHQtdGVhbC0yMDAvNzAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QYW5kdWFuIFBlbmdndW5hPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L25hdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRm9vdGVyICYgTG9nb3V0ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IG10LTYgYm9yZGVyLXQgYm9yZGVyLXdoaXRlLzEwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9wcm9maWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9iaWxlTWVudU9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC0zIHB5LTIgcm91bmRlZC14bCBob3ZlcjpiZy13aGl0ZS8xMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Fzc2V0VXJsKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXI/LnByb2ZpbGVJbWFnZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgaHR0cHM6Ly91aS1hdmF0YXJzLmNvbS9hcGkvP25hbWU9JHtlbmNvZGVVUklDb21wb25lbnQodXNlcj8uZnVsbG5hbWUgfHwgJ1UnKX0mYmFja2dyb3VuZD0wMDg5N0ImY29sb3I9ZmZmJnNpemU9NjRgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiUHJvZmlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIG9iamVjdC1jb3ZlciBib3JkZXIgYm9yZGVyLXRlYWwtMzAwLzQwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRydW5jYXRlXCI+e3VzZXI/LmZ1bGxuYW1lIHx8ICdQZW5nZ3VuYSd9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC10ZWFsLTIwMC84MCB0cnVuY2F0ZVwiPkB7dXNlcj8udXNlcm5hbWUgfHwgJ3VzZXInfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC00IHB5LTMgZm9udC1ib2xkIHRleHQtc20gdGV4dC10ZWFsLTEwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXdoaXRlLzEwIGRhcms6dGV4dC1yZWQtNDAwIGRhcms6aG92ZXI6YmctcmVkLTk1MC8zMCBkYXJrOmhvdmVyOnRleHQtcmVkLTMwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2dPdXQgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPktlbHVhcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBQb3B1cCBSaW5na2FzYW4gUGFuZHVhbiBQZW5nZ3VuYSAqL31cbiAgICAgICAgICAgIDxVc2VyR3VpZGVNb2RhbFxuICAgICAgICAgICAgICAgIGlzT3Blbj17Z3VpZGVNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0R3VpZGVNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgIG9uU3RhcnRUb3VyPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEd1aWRlTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHdpbmRvdy5fX3N0YXJ0Rm9ybVVwVG91cikge1xuICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93Ll9fc3RhcnRGb3JtVXBUb3VyKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgPC8+XG4gICAgKTtcbn0iXX0=