//#region node_modules/gsap/gsap-core.js
function _assertThisInitialized(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _inheritsLoose(subClass, superClass) {
	subClass.prototype = Object.create(superClass.prototype);
	subClass.prototype.constructor = subClass;
	subClass.__proto__ = superClass;
}
/*!
* GSAP 3.15.0
* https://gsap.com
*
* @license Copyright 2008-2026, GreenSock. All rights reserved.
* Subject to the terms at https://gsap.com/standard-license
* @author: Jack Doyle, jack@greensock.com
*/
var _config = {
	autoSleep: 120,
	force3D: "auto",
	nullTargetWarn: 1,
	units: { lineHeight: "" }
};
var _defaults = {
	duration: .5,
	overwrite: false,
	delay: 0
};
var _suppressOverwrites;
var _reverting$1;
var _context;
var _bigNum$1 = 1e8;
var _tinyNum = 1 / _bigNum$1;
var _2PI = Math.PI * 2;
var _HALF_PI = _2PI / 4;
var _gsID = 0;
var _sqrt = Math.sqrt;
var _cos = Math.cos;
var _sin = Math.sin;
var _isString = function _isString(value) {
	return typeof value === "string";
};
var _isFunction = function _isFunction(value) {
	return typeof value === "function";
};
var _isNumber = function _isNumber(value) {
	return typeof value === "number";
};
var _isUndefined = function _isUndefined(value) {
	return typeof value === "undefined";
};
var _isObject = function _isObject(value) {
	return typeof value === "object";
};
var _isNotFalse = function _isNotFalse(value) {
	return value !== false;
};
var _windowExists$1 = function _windowExists() {
	return typeof window !== "undefined";
};
var _isFuncOrString = function _isFuncOrString(value) {
	return _isFunction(value) || _isString(value);
};
var _isTypedArray = typeof ArrayBuffer === "function" && ArrayBuffer.isView || function() {};
var _isArray = Array.isArray;
var _randomExp = /random\([^)]+\)/g;
var _commaDelimExp = /,\s*/g;
var _strictNumExp = /(?:-?\.?\d|\.)+/gi;
var _numExp = /[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g;
var _numWithUnitExp = /[-+=.]*\d+[.e-]*\d*[a-z%]*/g;
var _complexStringNumExp = /[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi;
var _relExp = /[+-]=-?[.\d]+/;
var _delimitedValueExp = /[^,'"\[\]\s]+/gi;
var _unitExp = /^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i;
var _globalTimeline;
var _win$1;
var _coreInitted;
var _doc$1;
var _globals = {};
var _installScope = {};
var _coreReady;
var _install = function _install(scope) {
	return (_installScope = _merge(scope, _globals)) && gsap;
};
var _missingPlugin = function _missingPlugin(property, value) {
	return console.warn("Invalid property", property, "set to", value, "Missing plugin? gsap.registerPlugin()");
};
var _warn = function _warn(message, suppress) {
	return !suppress && console.warn(message);
};
var _addGlobal = function _addGlobal(name, obj) {
	return name && (_globals[name] = obj) && _installScope && (_installScope[name] = obj) || _globals;
};
var _emptyFunc = function _emptyFunc() {
	return 0;
};
var _startAtRevertConfig = {
	suppressEvents: true,
	isStart: true,
	kill: false
};
var _revertConfigNoKill = {
	suppressEvents: true,
	kill: false
};
var _revertConfig = { suppressEvents: true };
var _reservedProps = {};
var _lazyTweens = [];
var _lazyLookup = {};
var _lastRenderedFrame;
var _plugins = {};
var _effects = {};
var _nextGCFrame = 30;
var _harnessPlugins = [];
var _callbackNames = "";
var _harness = function _harness(targets) {
	var target = targets[0], harnessPlugin, i;
	_isObject(target) || _isFunction(target) || (targets = [targets]);
	if (!(harnessPlugin = (target._gsap || {}).harness)) {
		i = _harnessPlugins.length;
		while (i-- && !_harnessPlugins[i].targetTest(target));
		harnessPlugin = _harnessPlugins[i];
	}
	i = targets.length;
	while (i--) targets[i] && (targets[i]._gsap || (targets[i]._gsap = new GSCache(targets[i], harnessPlugin))) || targets.splice(i, 1);
	return targets;
};
var _getCache = function _getCache(target) {
	return target._gsap || _harness(toArray(target))[0]._gsap;
};
var _getProperty = function _getProperty(target, property, v) {
	return (v = target[property]) && _isFunction(v) ? target[property]() : _isUndefined(v) && target.getAttribute && target.getAttribute(property) || v;
};
var _forEachName = function _forEachName(names, func) {
	return (names = names.split(",")).forEach(func) || names;
};
var _round = function _round(value) {
	return Math.round(value * 1e5) / 1e5 || 0;
};
var _roundPrecise = function _roundPrecise(value) {
	return Math.round(value * 1e7) / 1e7 || 0;
};
var _parseRelative = function _parseRelative(start, value) {
	var operator = value.charAt(0), end = parseFloat(value.substr(2));
	start = parseFloat(start);
	return operator === "+" ? start + end : operator === "-" ? start - end : operator === "*" ? start * end : start / end;
};
var _arrayContainsAny = function _arrayContainsAny(toSearch, toFind) {
	var l = toFind.length, i = 0;
	for (; toSearch.indexOf(toFind[i]) < 0 && ++i < l;);
	return i < l;
};
var _lazyRender = function _lazyRender() {
	var l = _lazyTweens.length, a = _lazyTweens.slice(0), i, tween;
	_lazyLookup = {};
	_lazyTweens.length = 0;
	for (i = 0; i < l; i++) {
		tween = a[i];
		tween && tween._lazy && (tween.render(tween._lazy[0], tween._lazy[1], true)._lazy = 0);
	}
};
var _isRevertWorthy = function _isRevertWorthy(animation) {
	return !!(animation._initted || animation._startAt || animation.add);
};
var _lazySafeRender = function _lazySafeRender(animation, time, suppressEvents, force) {
	_lazyTweens.length && !_reverting$1 && _lazyRender();
	animation.render(time, suppressEvents, force || !!(_reverting$1 && time < 0 && _isRevertWorthy(animation)));
	_lazyTweens.length && !_reverting$1 && _lazyRender();
};
var _numericIfPossible = function _numericIfPossible(value) {
	var n = parseFloat(value);
	return (n || n === 0) && (value + "").match(_delimitedValueExp).length < 2 ? n : _isString(value) ? value.trim() : value;
};
var _passThrough = function _passThrough(p) {
	return p;
};
var _setDefaults = function _setDefaults(obj, defaults) {
	for (var p in defaults) p in obj || (obj[p] = defaults[p]);
	return obj;
};
var _setKeyframeDefaults = function _setKeyframeDefaults(excludeDuration) {
	return function(obj, defaults) {
		for (var p in defaults) p in obj || p === "duration" && excludeDuration || p === "ease" || (obj[p] = defaults[p]);
	};
};
var _merge = function _merge(base, toMerge) {
	for (var p in toMerge) base[p] = toMerge[p];
	return base;
};
var _mergeDeep = function _mergeDeep(base, toMerge) {
	for (var p in toMerge) p !== "__proto__" && p !== "constructor" && p !== "prototype" && (base[p] = _isObject(toMerge[p]) ? _mergeDeep(base[p] || (base[p] = {}), toMerge[p]) : toMerge[p]);
	return base;
};
var _copyExcluding = function _copyExcluding(obj, excluding) {
	var copy = {}, p;
	for (p in obj) p in excluding || (copy[p] = obj[p]);
	return copy;
};
var _inheritDefaults = function _inheritDefaults(vars) {
	var parent = vars.parent || _globalTimeline, func = vars.keyframes ? _setKeyframeDefaults(_isArray(vars.keyframes)) : _setDefaults;
	if (_isNotFalse(vars.inherit)) while (parent) {
		func(vars, parent.vars.defaults);
		parent = parent.parent || parent._dp;
	}
	return vars;
};
var _arraysMatch = function _arraysMatch(a1, a2) {
	var i = a1.length, match = i === a2.length;
	while (match && i-- && a1[i] === a2[i]);
	return i < 0;
};
var _addLinkedListItem = function _addLinkedListItem(parent, child, firstProp, lastProp, sortBy) {
	if (firstProp === void 0) firstProp = "_first";
	if (lastProp === void 0) lastProp = "_last";
	var prev = parent[lastProp], t;
	if (sortBy) {
		t = child[sortBy];
		while (prev && prev[sortBy] > t) prev = prev._prev;
	}
	if (prev) {
		child._next = prev._next;
		prev._next = child;
	} else {
		child._next = parent[firstProp];
		parent[firstProp] = child;
	}
	if (child._next) child._next._prev = child;
	else parent[lastProp] = child;
	child._prev = prev;
	child.parent = child._dp = parent;
	return child;
};
var _removeLinkedListItem = function _removeLinkedListItem(parent, child, firstProp, lastProp) {
	if (firstProp === void 0) firstProp = "_first";
	if (lastProp === void 0) lastProp = "_last";
	var prev = child._prev, next = child._next;
	if (prev) prev._next = next;
	else if (parent[firstProp] === child) parent[firstProp] = next;
	if (next) next._prev = prev;
	else if (parent[lastProp] === child) parent[lastProp] = prev;
	child._next = child._prev = child.parent = null;
};
var _removeFromParent = function _removeFromParent(child, onlyIfParentHasAutoRemove) {
	child.parent && (!onlyIfParentHasAutoRemove || child.parent.autoRemoveChildren) && child.parent.remove && child.parent.remove(child);
	child._act = 0;
};
var _uncache = function _uncache(animation, child) {
	if (animation && (!child || child._end > animation._dur || child._start < 0)) {
		var a = animation;
		while (a) {
			a._dirty = 1;
			a = a.parent;
		}
	}
	return animation;
};
var _recacheAncestors = function _recacheAncestors(animation) {
	var parent = animation.parent;
	while (parent && parent.parent) {
		parent._dirty = 1;
		parent.totalDuration();
		parent = parent.parent;
	}
	return animation;
};
var _rewindStartAt = function _rewindStartAt(tween, totalTime, suppressEvents, force) {
	return tween._startAt && (_reverting$1 ? tween._startAt.revert(_revertConfigNoKill) : tween.vars.immediateRender && !tween.vars.autoRevert || tween._startAt.render(totalTime, true, force));
};
var _hasNoPausedAncestors = function _hasNoPausedAncestors(animation) {
	return !animation || animation._ts && _hasNoPausedAncestors(animation.parent);
};
var _elapsedCycleDuration = function _elapsedCycleDuration(animation) {
	return animation._repeat ? _animationCycle(animation._tTime, animation = animation.duration() + animation._rDelay) * animation : 0;
};
var _animationCycle = function _animationCycle(tTime, cycleDuration) {
	var whole = Math.floor(tTime = _roundPrecise(tTime / cycleDuration));
	return tTime && whole === tTime ? whole - 1 : whole;
};
var _parentToChildTotalTime = function _parentToChildTotalTime(parentTime, child) {
	return (parentTime - child._start) * child._ts + (child._ts >= 0 ? 0 : child._dirty ? child.totalDuration() : child._tDur);
};
var _setEnd = function _setEnd(animation) {
	return animation._end = _roundPrecise(animation._start + (animation._tDur / Math.abs(animation._ts || animation._rts || _tinyNum) || 0));
};
var _alignPlayhead = function _alignPlayhead(animation, totalTime) {
	var parent = animation._dp;
	if (parent && parent.smoothChildTiming && animation._ts) {
		animation._start = _roundPrecise(parent._time - (animation._ts > 0 ? totalTime / animation._ts : ((animation._dirty ? animation.totalDuration() : animation._tDur) - totalTime) / -animation._ts));
		_setEnd(animation);
		parent._dirty || _uncache(parent, animation);
	}
	return animation;
};
var _postAddChecks = function _postAddChecks(timeline, child) {
	var t;
	if (child._time || !child._dur && child._initted || child._start < timeline._time && (child._dur || !child.add)) {
		t = _parentToChildTotalTime(timeline.rawTime(), child);
		if (!child._dur || _clamp(0, child.totalDuration(), t) - child._tTime > _tinyNum) child.render(t, true);
	}
	if (_uncache(timeline, child)._dp && timeline._initted && timeline._time >= timeline._dur && timeline._ts) {
		if (timeline._dur < timeline.duration()) {
			t = timeline;
			while (t._dp) {
				t.rawTime() >= 0 && t.totalTime(t._tTime);
				t = t._dp;
			}
		}
		timeline._zTime = -_tinyNum;
	}
};
var _addToTimeline = function _addToTimeline(timeline, child, position, skipChecks) {
	child.parent && _removeFromParent(child);
	child._start = _roundPrecise((_isNumber(position) ? position : position || timeline !== _globalTimeline ? _parsePosition(timeline, position, child) : timeline._time) + child._delay);
	child._end = _roundPrecise(child._start + (child.totalDuration() / Math.abs(child.timeScale()) || 0));
	_addLinkedListItem(timeline, child, "_first", "_last", timeline._sort ? "_start" : 0);
	_isFromOrFromStart(child) || (timeline._recent = child);
	skipChecks || _postAddChecks(timeline, child);
	timeline._ts < 0 && _alignPlayhead(timeline, timeline._tTime);
	return timeline;
};
var _scrollTrigger = function _scrollTrigger(animation, trigger) {
	return (_globals.ScrollTrigger || _missingPlugin("scrollTrigger", trigger)) && _globals.ScrollTrigger.create(trigger, animation);
};
var _attemptInitTween = function _attemptInitTween(tween, time, force, suppressEvents, tTime) {
	_initTween(tween, time, tTime);
	if (!tween._initted) return 1;
	if (!force && tween._pt && !_reverting$1 && (tween._dur && tween.vars.lazy !== false || !tween._dur && tween.vars.lazy) && _lastRenderedFrame !== _ticker.frame) {
		_lazyTweens.push(tween);
		tween._lazy = [tTime, suppressEvents];
		return 1;
	}
};
var _parentPlayheadIsBeforeStart = function _parentPlayheadIsBeforeStart(_ref) {
	var parent = _ref.parent;
	return parent && parent._ts && parent._initted && !parent._lock && (parent.rawTime() < 0 || _parentPlayheadIsBeforeStart(parent));
};
var _isFromOrFromStart = function _isFromOrFromStart(_ref2) {
	var data = _ref2.data;
	return data === "isFromStart" || data === "isStart";
};
var _renderZeroDurationTween = function _renderZeroDurationTween(tween, totalTime, suppressEvents, force) {
	var prevRatio = tween.ratio, ratio = totalTime < 0 || !totalTime && (!tween._start && _parentPlayheadIsBeforeStart(tween) && !(!tween._initted && _isFromOrFromStart(tween)) || (tween._ts < 0 || tween._dp._ts < 0) && !_isFromOrFromStart(tween)) ? 0 : 1, repeatDelay = tween._rDelay, tTime = 0, pt, iteration, prevIteration;
	if (repeatDelay && tween._repeat) {
		tTime = _clamp(0, tween._tDur, totalTime);
		iteration = _animationCycle(tTime, repeatDelay);
		tween._yoyo && iteration & 1 && (ratio = 1 - ratio);
		if (iteration !== _animationCycle(tween._tTime, repeatDelay)) {
			prevRatio = 1 - ratio;
			tween.vars.repeatRefresh && tween._initted && tween.invalidate();
		}
	}
	if (ratio !== prevRatio || _reverting$1 || force || tween._zTime === _tinyNum || !totalTime && tween._zTime) {
		if (!tween._initted && _attemptInitTween(tween, totalTime, force, suppressEvents, tTime)) return;
		prevIteration = tween._zTime;
		tween._zTime = totalTime || (suppressEvents ? _tinyNum : 0);
		suppressEvents || (suppressEvents = totalTime && !prevIteration);
		tween.ratio = ratio;
		tween._from && (ratio = 1 - ratio);
		tween._time = 0;
		tween._tTime = tTime;
		pt = tween._pt;
		while (pt) {
			pt.r(ratio, pt.d);
			pt = pt._next;
		}
		totalTime < 0 && _rewindStartAt(tween, totalTime, suppressEvents, true);
		tween._onUpdate && !suppressEvents && _callback(tween, "onUpdate");
		tTime && tween._repeat && !suppressEvents && tween.parent && _callback(tween, "onRepeat");
		if ((totalTime >= tween._tDur || totalTime < 0) && tween.ratio === ratio) {
			ratio && _removeFromParent(tween, 1);
			if (!suppressEvents && !_reverting$1) {
				_callback(tween, ratio ? "onComplete" : "onReverseComplete", true);
				tween._prom && tween._prom();
			}
		}
	} else if (!tween._zTime) tween._zTime = totalTime;
};
var _findNextPauseTween = function _findNextPauseTween(animation, prevTime, time) {
	var child;
	if (time > prevTime) {
		child = animation._first;
		while (child && child._start <= time) {
			if (child.data === "isPause" && child._start > prevTime) return child;
			child = child._next;
		}
	} else {
		child = animation._last;
		while (child && child._start >= time) {
			if (child.data === "isPause" && child._start < prevTime) return child;
			child = child._prev;
		}
	}
};
var _setDuration = function _setDuration(animation, duration, skipUncache, leavePlayhead) {
	var repeat = animation._repeat, dur = _roundPrecise(duration) || 0, totalProgress = animation._tTime / animation._tDur;
	totalProgress && !leavePlayhead && (animation._time *= dur / animation._dur);
	animation._dur = dur;
	animation._tDur = !repeat ? dur : repeat < 0 ? 1e10 : _roundPrecise(dur * (repeat + 1) + animation._rDelay * repeat);
	totalProgress > 0 && !leavePlayhead && _alignPlayhead(animation, animation._tTime = animation._tDur * totalProgress);
	animation.parent && _setEnd(animation);
	skipUncache || _uncache(animation.parent, animation);
	return animation;
};
var _onUpdateTotalDuration = function _onUpdateTotalDuration(animation) {
	return animation instanceof Timeline ? _uncache(animation) : _setDuration(animation, animation._dur);
};
var _zeroPosition = {
	_start: 0,
	endTime: _emptyFunc,
	totalDuration: _emptyFunc
};
var _parsePosition = function _parsePosition(animation, position, percentAnimation) {
	var labels = animation.labels, recent = animation._recent || _zeroPosition, clippedDuration = animation.duration() >= _bigNum$1 ? recent.endTime(false) : animation._dur, i, offset, isPercent;
	if (_isString(position) && (isNaN(position) || position in labels)) {
		offset = position.charAt(0);
		isPercent = position.substr(-1) === "%";
		i = position.indexOf("=");
		if (offset === "<" || offset === ">") {
			i >= 0 && (position = position.replace(/=/, ""));
			return (offset === "<" ? recent._start : recent.endTime(recent._repeat >= 0)) + (parseFloat(position.substr(1)) || 0) * (isPercent ? (i < 0 ? recent : percentAnimation).totalDuration() / 100 : 1);
		}
		if (i < 0) {
			position in labels || (labels[position] = clippedDuration);
			return labels[position];
		}
		offset = parseFloat(position.charAt(i - 1) + position.substr(i + 1));
		if (isPercent && percentAnimation) offset = offset / 100 * (_isArray(percentAnimation) ? percentAnimation[0] : percentAnimation).totalDuration();
		return i > 1 ? _parsePosition(animation, position.substr(0, i - 1), percentAnimation) + offset : clippedDuration + offset;
	}
	return position == null ? clippedDuration : +position;
};
var _createTweenType = function _createTweenType(type, params, timeline) {
	var isLegacy = _isNumber(params[1]), varsIndex = (isLegacy ? 2 : 1) + (type < 2 ? 0 : 1), vars = params[varsIndex], irVars, parent;
	isLegacy && (vars.duration = params[1]);
	vars.parent = timeline;
	if (type) {
		irVars = vars;
		parent = timeline;
		while (parent && !("immediateRender" in irVars)) {
			irVars = parent.vars.defaults || {};
			parent = _isNotFalse(parent.vars.inherit) && parent.parent;
		}
		vars.immediateRender = _isNotFalse(irVars.immediateRender);
		type < 2 ? vars.runBackwards = 1 : vars.startAt = params[varsIndex - 1];
	}
	return new Tween(params[0], vars, params[varsIndex + 1]);
};
var _conditionalReturn = function _conditionalReturn(value, func) {
	return value || value === 0 ? func(value) : func;
};
var _clamp = function _clamp(min, max, value) {
	return value < min ? min : value > max ? max : value;
};
var getUnit = function getUnit(value, v) {
	return !_isString(value) || !(v = _unitExp.exec(value)) ? "" : v[1];
};
var clamp = function clamp(min, max, value) {
	return _conditionalReturn(value, function(v) {
		return _clamp(min, max, v);
	});
};
var _slice = [].slice;
var _isArrayLike = function _isArrayLike(value, nonEmpty) {
	return value && _isObject(value) && "length" in value && (!nonEmpty && !value.length || value.length - 1 in value && _isObject(value[0])) && !value.nodeType && value !== _win$1;
};
var _flatten = function _flatten(ar, leaveStrings, accumulator) {
	if (accumulator === void 0) accumulator = [];
	return ar.forEach(function(value) {
		var _accumulator;
		return _isString(value) && !leaveStrings || _isArrayLike(value, 1) ? (_accumulator = accumulator).push.apply(_accumulator, toArray(value)) : accumulator.push(value);
	}) || accumulator;
};
var toArray = function toArray(value, scope, leaveStrings) {
	return _context && !scope && _context.selector ? _context.selector(value) : _isString(value) && !leaveStrings && (_coreInitted || !_wake()) ? _slice.call((scope || _doc$1).querySelectorAll(value), 0) : _isArray(value) ? _flatten(value, leaveStrings) : _isArrayLike(value) ? _slice.call(value, 0) : value ? [value] : [];
};
var selector = function selector(value) {
	value = toArray(value)[0] || _warn("Invalid scope") || {};
	return function(v) {
		var el = value.current || value.nativeElement || value;
		return toArray(v, el.querySelectorAll ? el : el === value ? _warn("Invalid scope") || _doc$1.createElement("div") : value);
	};
};
var shuffle = function shuffle(a) {
	return a.sort(function() {
		return .5 - Math.random();
	});
};
var distribute = function distribute(v) {
	if (_isFunction(v)) return v;
	var vars = _isObject(v) ? v : { each: v }, ease = _parseEase(vars.ease), from = vars.from || 0, base = parseFloat(vars.base) || 0, cache = {}, isDecimal = from > 0 && from < 1, ratios = isNaN(from) || isDecimal, axis = vars.axis, ratioX = from, ratioY = from;
	if (_isString(from)) ratioX = ratioY = {
		center: .5,
		edges: .5,
		end: 1
	}[from] || 0;
	else if (!isDecimal && ratios) {
		ratioX = from[0];
		ratioY = from[1];
	}
	return function(i, target, a) {
		var l = (a || vars).length, distances = cache[l], originX, originY, x, y, d, j, max, min, wrapAt;
		if (!distances) {
			wrapAt = vars.grid === "auto" ? 0 : (vars.grid || [1, _bigNum$1])[1];
			if (!wrapAt) {
				max = -_bigNum$1;
				while (max < (max = a[wrapAt++].getBoundingClientRect().left) && wrapAt < l);
				wrapAt < l && wrapAt--;
			}
			distances = cache[l] = [];
			originX = ratios ? Math.min(wrapAt, l) * ratioX - .5 : from % wrapAt;
			originY = wrapAt === _bigNum$1 ? 0 : ratios ? l * ratioY / wrapAt - .5 : from / wrapAt | 0;
			max = 0;
			min = _bigNum$1;
			for (j = 0; j < l; j++) {
				x = j % wrapAt - originX;
				y = originY - (j / wrapAt | 0);
				distances[j] = d = !axis ? _sqrt(x * x + y * y) : Math.abs(axis === "y" ? y : x);
				d > max && (max = d);
				d < min && (min = d);
			}
			from === "random" && shuffle(distances);
			distances.max = max - min;
			distances.min = min;
			distances.v = l = (parseFloat(vars.amount) || parseFloat(vars.each) * (wrapAt > l ? l - 1 : !axis ? Math.max(wrapAt, l / wrapAt) : axis === "y" ? l / wrapAt : wrapAt) || 0) * (from === "edges" ? -1 : 1);
			distances.b = l < 0 ? base - l : base;
			distances.u = getUnit(vars.amount || vars.each) || 0;
			ease = ease && l < 0 ? _invertEase(ease) : ease;
		}
		l = (distances[i] - distances.min) / distances.max || 0;
		return _roundPrecise(distances.b + (ease ? ease(l) : l) * distances.v) + distances.u;
	};
};
var _roundModifier = function _roundModifier(v) {
	var p = Math.pow(10, ((v + "").split(".")[1] || "").length);
	return function(raw) {
		var n = _roundPrecise(Math.round(parseFloat(raw) / v) * v * p);
		return (n - n % 1) / p + (_isNumber(raw) ? 0 : getUnit(raw));
	};
};
var snap = function snap(snapTo, value) {
	var isArray = _isArray(snapTo), radius, is2D;
	if (!isArray && _isObject(snapTo)) {
		radius = isArray = snapTo.radius || _bigNum$1;
		if (snapTo.values) {
			snapTo = toArray(snapTo.values);
			if (is2D = !_isNumber(snapTo[0])) radius *= radius;
		} else snapTo = _roundModifier(snapTo.increment);
	}
	return _conditionalReturn(value, !isArray ? _roundModifier(snapTo) : _isFunction(snapTo) ? function(raw) {
		is2D = snapTo(raw);
		return Math.abs(is2D - raw) <= radius ? is2D : raw;
	} : function(raw) {
		var x = parseFloat(is2D ? raw.x : raw), y = parseFloat(is2D ? raw.y : 0), min = _bigNum$1, closest = 0, i = snapTo.length, dx, dy;
		while (i--) {
			if (is2D) {
				dx = snapTo[i].x - x;
				dy = snapTo[i].y - y;
				dx = dx * dx + dy * dy;
			} else dx = Math.abs(snapTo[i] - x);
			if (dx < min) {
				min = dx;
				closest = i;
			}
		}
		closest = !radius || min <= radius ? snapTo[closest] : raw;
		return is2D || closest === raw || _isNumber(raw) ? closest : closest + getUnit(raw);
	});
};
var random = function random(min, max, roundingIncrement, returnFunction) {
	return _conditionalReturn(_isArray(min) ? !max : roundingIncrement === true ? !!(roundingIncrement = 0) : !returnFunction, function() {
		return _isArray(min) ? min[~~(Math.random() * min.length)] : (roundingIncrement = roundingIncrement || 1e-5) && (returnFunction = roundingIncrement < 1 ? Math.pow(10, (roundingIncrement + "").length - 2) : 1) && Math.floor(Math.round((min - roundingIncrement / 2 + Math.random() * (max - min + roundingIncrement * .99)) / roundingIncrement) * roundingIncrement * returnFunction) / returnFunction;
	});
};
var pipe = function pipe() {
	for (var _len = arguments.length, functions = new Array(_len), _key = 0; _key < _len; _key++) functions[_key] = arguments[_key];
	return function(value) {
		return functions.reduce(function(v, f) {
			return f(v);
		}, value);
	};
};
var unitize = function unitize(func, unit) {
	return function(value) {
		return func(parseFloat(value)) + (unit || getUnit(value));
	};
};
var normalize = function normalize(min, max, value) {
	return mapRange(min, max, 0, 1, value);
};
var _wrapArray = function _wrapArray(a, wrapper, value) {
	return _conditionalReturn(value, function(index) {
		return a[~~wrapper(index)];
	});
};
var wrap = function wrap(min, max, value) {
	var range = max - min;
	return _isArray(min) ? _wrapArray(min, wrap(0, min.length), max) : _conditionalReturn(value, function(value) {
		return (range + (value - min) % range) % range + min;
	});
};
var wrapYoyo = function wrapYoyo(min, max, value) {
	var range = max - min, total = range * 2;
	return _isArray(min) ? _wrapArray(min, wrapYoyo(0, min.length - 1), max) : _conditionalReturn(value, function(value) {
		value = (total + (value - min) % total) % total || 0;
		return min + (value > range ? total - value : value);
	});
};
var _replaceRandom = function _replaceRandom(s) {
	return s.replace(_randomExp, function(match) {
		var arIndex = match.indexOf("[") + 1, values = match.substring(arIndex || 7, arIndex ? match.indexOf("]") : match.length - 1).split(_commaDelimExp);
		return random(arIndex ? values : +values[0], arIndex ? 0 : +values[1], +values[2] || 1e-5);
	});
};
var mapRange = function mapRange(inMin, inMax, outMin, outMax, value) {
	var inRange = inMax - inMin, outRange = outMax - outMin;
	return _conditionalReturn(value, function(value) {
		return outMin + ((value - inMin) / inRange * outRange || 0);
	});
};
var interpolate = function interpolate(start, end, progress, mutate) {
	var func = isNaN(start + end) ? 0 : function(p) {
		return (1 - p) * start + p * end;
	};
	if (!func) {
		var isString = _isString(start), master = {}, p, i, interpolators, l, il;
		progress === true && (mutate = 1) && (progress = null);
		if (isString) {
			start = { p: start };
			end = { p: end };
		} else if (_isArray(start) && !_isArray(end)) {
			interpolators = [];
			l = start.length;
			il = l - 2;
			for (i = 1; i < l; i++) interpolators.push(interpolate(start[i - 1], start[i]));
			l--;
			func = function func(p) {
				p *= l;
				var i = Math.min(il, ~~p);
				return interpolators[i](p - i);
			};
			progress = end;
		} else if (!mutate) start = _merge(_isArray(start) ? [] : {}, start);
		if (!interpolators) {
			for (p in end) _addPropTween.call(master, start, p, "get", end[p]);
			func = function func(p) {
				return _renderPropTweens(p, master) || (isString ? start.p : start);
			};
		}
	}
	return _conditionalReturn(progress, func);
};
var _getLabelInDirection = function _getLabelInDirection(timeline, fromTime, backward) {
	var labels = timeline.labels, min = _bigNum$1, p, distance, label;
	for (p in labels) {
		distance = labels[p] - fromTime;
		if (distance < 0 === !!backward && distance && min > (distance = Math.abs(distance))) {
			label = p;
			min = distance;
		}
	}
	return label;
};
var _callback = function _callback(animation, type, executeLazyFirst) {
	var v = animation.vars, callback = v[type], prevContext = _context, context = animation._ctx, params, scope, result;
	if (!callback) return;
	params = v[type + "Params"];
	scope = v.callbackScope || animation;
	executeLazyFirst && _lazyTweens.length && _lazyRender();
	context && (_context = context);
	result = params ? callback.apply(scope, params) : callback.call(scope);
	_context = prevContext;
	return result;
};
var _interrupt = function _interrupt(animation) {
	_removeFromParent(animation);
	animation.scrollTrigger && animation.scrollTrigger.kill(!!_reverting$1);
	animation.progress() < 1 && _callback(animation, "onInterrupt");
	return animation;
};
var _quickTween;
var _registerPluginQueue = [];
var _createPlugin = function _createPlugin(config) {
	if (!config) return;
	config = !config.name && config["default"] || config;
	if (_windowExists$1() || config.headless) {
		var name = config.name, isFunc = _isFunction(config), Plugin = name && !isFunc && config.init ? function() {
			this._props = [];
		} : config, instanceDefaults = {
			init: _emptyFunc,
			render: _renderPropTweens,
			add: _addPropTween,
			kill: _killPropTweensOf,
			modifier: _addPluginModifier,
			rawVars: 0
		}, statics = {
			targetTest: 0,
			get: 0,
			getSetter: _getSetter,
			aliases: {},
			register: 0
		};
		_wake();
		if (config !== Plugin) {
			if (_plugins[name]) return;
			_setDefaults(Plugin, _setDefaults(_copyExcluding(config, instanceDefaults), statics));
			_merge(Plugin.prototype, _merge(instanceDefaults, _copyExcluding(config, statics)));
			_plugins[Plugin.prop = name] = Plugin;
			if (config.targetTest) {
				_harnessPlugins.push(Plugin);
				_reservedProps[name] = 1;
			}
			name = (name === "css" ? "CSS" : name.charAt(0).toUpperCase() + name.substr(1)) + "Plugin";
		}
		_addGlobal(name, Plugin);
		config.register && config.register(gsap, Plugin, PropTween);
	} else _registerPluginQueue.push(config);
};
var _255 = 255;
var _colorLookup = {
	aqua: [
		0,
		_255,
		_255
	],
	lime: [
		0,
		_255,
		0
	],
	silver: [
		192,
		192,
		192
	],
	black: [
		0,
		0,
		0
	],
	maroon: [
		128,
		0,
		0
	],
	teal: [
		0,
		128,
		128
	],
	blue: [
		0,
		0,
		_255
	],
	navy: [
		0,
		0,
		128
	],
	white: [
		_255,
		_255,
		_255
	],
	olive: [
		128,
		128,
		0
	],
	yellow: [
		_255,
		_255,
		0
	],
	orange: [
		_255,
		165,
		0
	],
	gray: [
		128,
		128,
		128
	],
	purple: [
		128,
		0,
		128
	],
	green: [
		0,
		128,
		0
	],
	red: [
		_255,
		0,
		0
	],
	pink: [
		_255,
		192,
		203
	],
	cyan: [
		0,
		_255,
		_255
	],
	transparent: [
		_255,
		_255,
		_255,
		0
	]
};
var _hue = function _hue(h, m1, m2) {
	h += h < 0 ? 1 : h > 1 ? -1 : 0;
	return (h * 6 < 1 ? m1 + (m2 - m1) * h * 6 : h < .5 ? m2 : h * 3 < 2 ? m1 + (m2 - m1) * (2 / 3 - h) * 6 : m1) * _255 + .5 | 0;
};
var splitColor = function splitColor(v, toHSL, forceAlpha) {
	var a = !v ? _colorLookup.black : _isNumber(v) ? [
		v >> 16,
		v >> 8 & _255,
		v & _255
	] : 0, r, g, b, h, s, l, max, min, d, wasHSL;
	if (!a) {
		if (v.substr(-1) === ",") v = v.substr(0, v.length - 1);
		if (_colorLookup[v]) a = _colorLookup[v];
		else if (v.charAt(0) === "#") {
			if (v.length < 6) {
				r = v.charAt(1);
				g = v.charAt(2);
				b = v.charAt(3);
				v = "#" + r + r + g + g + b + b + (v.length === 5 ? v.charAt(4) + v.charAt(4) : "");
			}
			if (v.length === 9) {
				a = parseInt(v.substr(1, 6), 16);
				return [
					a >> 16,
					a >> 8 & _255,
					a & _255,
					parseInt(v.substr(7), 16) / 255
				];
			}
			v = parseInt(v.substr(1), 16);
			a = [
				v >> 16,
				v >> 8 & _255,
				v & _255
			];
		} else if (v.substr(0, 3) === "hsl") {
			a = wasHSL = v.match(_strictNumExp);
			if (!toHSL) {
				h = +a[0] % 360 / 360;
				s = +a[1] / 100;
				l = +a[2] / 100;
				g = l <= .5 ? l * (s + 1) : l + s - l * s;
				r = l * 2 - g;
				a.length > 3 && (a[3] *= 1);
				a[0] = _hue(h + 1 / 3, r, g);
				a[1] = _hue(h, r, g);
				a[2] = _hue(h - 1 / 3, r, g);
			} else if (~v.indexOf("=")) {
				a = v.match(_numExp);
				forceAlpha && a.length < 4 && (a[3] = 1);
				return a;
			}
		} else a = v.match(_strictNumExp) || _colorLookup.transparent;
		a = a.map(Number);
	}
	if (toHSL && !wasHSL) {
		r = a[0] / _255;
		g = a[1] / _255;
		b = a[2] / _255;
		max = Math.max(r, g, b);
		min = Math.min(r, g, b);
		l = (max + min) / 2;
		if (max === min) h = s = 0;
		else {
			d = max - min;
			s = l > .5 ? d / (2 - max - min) : d / (max + min);
			h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
			h *= 60;
		}
		a[0] = ~~(h + .5);
		a[1] = ~~(s * 100 + .5);
		a[2] = ~~(l * 100 + .5);
	}
	forceAlpha && a.length < 4 && (a[3] = 1);
	return a;
};
var _colorOrderData = function _colorOrderData(v) {
	var values = [], c = [], i = -1;
	v.split(_colorExp).forEach(function(v) {
		var a = v.match(_numWithUnitExp) || [];
		values.push.apply(values, a);
		c.push(i += a.length + 1);
	});
	values.c = c;
	return values;
};
var _formatColors = function _formatColors(s, toHSL, orderMatchData) {
	var result = "", colors = (s + result).match(_colorExp), type = toHSL ? "hsla(" : "rgba(", i = 0, c, shell, d, l;
	if (!colors) return s;
	colors = colors.map(function(color) {
		return (color = splitColor(color, toHSL, 1)) && type + (toHSL ? color[0] + "," + color[1] + "%," + color[2] + "%," + color[3] : color.join(",")) + ")";
	});
	if (orderMatchData) {
		d = _colorOrderData(s);
		c = orderMatchData.c;
		if (c.join(result) !== d.c.join(result)) {
			shell = s.replace(_colorExp, "1").split(_numWithUnitExp);
			l = shell.length - 1;
			for (; i < l; i++) result += shell[i] + (~c.indexOf(i) ? colors.shift() || type + "0,0,0,0)" : (d.length ? d : colors.length ? colors : orderMatchData).shift());
		}
	}
	if (!shell) {
		shell = s.split(_colorExp);
		l = shell.length - 1;
		for (; i < l; i++) result += shell[i] + colors[i];
	}
	return result + shell[l];
};
var _colorExp = function() {
	var s = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b", p;
	for (p in _colorLookup) s += "|" + p + "\\b";
	return new RegExp(s + ")", "gi");
}();
var _hslExp = /hsl[a]?\(/;
var _colorStringFilter = function _colorStringFilter(a) {
	var combined = a.join(" "), toHSL;
	_colorExp.lastIndex = 0;
	if (_colorExp.test(combined)) {
		toHSL = _hslExp.test(combined);
		a[1] = _formatColors(a[1], toHSL);
		a[0] = _formatColors(a[0], toHSL, _colorOrderData(a[1]));
		return true;
	}
};
var _tickerActive;
var _ticker = function() {
	var _getTime = Date.now, _lagThreshold = 500, _adjustedLag = 33, _startTime = _getTime(), _lastUpdate = _startTime, _gap = 1e3 / 240, _nextTime = _gap, _listeners = [], _id, _req, _raf, _self, _delta, _i, _tick = function _tick(v) {
		var elapsed = _getTime() - _lastUpdate, manual = v === true, overlap, dispatch, time, frame;
		(elapsed > _lagThreshold || elapsed < 0) && (_startTime += elapsed - _adjustedLag);
		_lastUpdate += elapsed;
		time = _lastUpdate - _startTime;
		overlap = time - _nextTime;
		if (overlap > 0 || manual) {
			frame = ++_self.frame;
			_delta = time - _self.time * 1e3;
			_self.time = time = time / 1e3;
			_nextTime += overlap + (overlap >= _gap ? 4 : _gap - overlap);
			dispatch = 1;
		}
		manual || (_id = _req(_tick));
		if (dispatch) for (_i = 0; _i < _listeners.length; _i++) _listeners[_i](time, _delta, frame, v);
	};
	_self = {
		time: 0,
		frame: 0,
		tick: function tick() {
			_tick(true);
		},
		deltaRatio: function deltaRatio(fps) {
			return _delta / (1e3 / (fps || 60));
		},
		wake: function wake() {
			if (_coreReady) {
				if (!_coreInitted && _windowExists$1()) {
					_win$1 = _coreInitted = window;
					_doc$1 = _win$1.document || {};
					_globals.gsap = gsap;
					(_win$1.gsapVersions || (_win$1.gsapVersions = [])).push(gsap.version);
					_install(_installScope || _win$1.GreenSockGlobals || !_win$1.gsap && _win$1 || {});
					_registerPluginQueue.forEach(_createPlugin);
				}
				_raf = typeof requestAnimationFrame !== "undefined" && requestAnimationFrame;
				_id && _self.sleep();
				_req = _raf || function(f) {
					return setTimeout(f, _nextTime - _self.time * 1e3 + 1 | 0);
				};
				_tickerActive = 1;
				_tick(2);
			}
		},
		sleep: function sleep() {
			(_raf ? cancelAnimationFrame : clearTimeout)(_id);
			_tickerActive = 0;
			_req = _emptyFunc;
		},
		lagSmoothing: function lagSmoothing(threshold, adjustedLag) {
			_lagThreshold = threshold || Infinity;
			_adjustedLag = Math.min(adjustedLag || 33, _lagThreshold);
		},
		fps: function fps(_fps) {
			_gap = 1e3 / (_fps || 240);
			_nextTime = _self.time * 1e3 + _gap;
		},
		add: function add(callback, once, prioritize) {
			var func = once ? function(t, d, f, v) {
				callback(t, d, f, v);
				_self.remove(func);
			} : callback;
			_self.remove(callback);
			_listeners[prioritize ? "unshift" : "push"](func);
			_wake();
			return func;
		},
		remove: function remove(callback, i) {
			~(i = _listeners.indexOf(callback)) && _listeners.splice(i, 1) && _i >= i && _i--;
		},
		_listeners
	};
	return _self;
}();
var _wake = function _wake() {
	return !_tickerActive && _ticker.wake();
};
var _easeMap = {};
var _customEaseExp = /^[\d.\-M][\d.\-,\s]/;
var _quotesExp = /["']/g;
var _parseObjectInString = function _parseObjectInString(value) {
	var obj = {}, split = value.substr(1, value.length - 3).split(":"), key = split[0], i = 1, l = split.length, index, val, parsedVal;
	for (; i < l; i++) {
		val = split[i];
		index = i !== l - 1 ? val.lastIndexOf(",") : val.length;
		parsedVal = val.substr(0, index);
		obj[key] = isNaN(parsedVal) ? parsedVal.replace(_quotesExp, "").trim() : +parsedVal;
		key = val.substr(index + 1).trim();
	}
	return obj;
};
var _valueInParentheses = function _valueInParentheses(value) {
	var open = value.indexOf("(") + 1, close = value.indexOf(")"), nested = value.indexOf("(", open);
	return value.substring(open, ~nested && nested < close ? value.indexOf(")", close + 1) : close);
};
var _configEaseFromString = function _configEaseFromString(name) {
	var split = (name + "").split("("), ease = _easeMap[split[0]];
	return ease && split.length > 1 && ease.config ? ease.config.apply(null, ~name.indexOf("{") ? [_parseObjectInString(split[1])] : _valueInParentheses(name).split(",").map(_numericIfPossible)) : _easeMap._CE && _customEaseExp.test(name) ? _easeMap._CE("", name) : ease;
};
var _invertEase = function _invertEase(ease) {
	return function(p) {
		return 1 - ease(1 - p);
	};
};
var _parseEase = function _parseEase(ease, defaultEase) {
	return !ease ? defaultEase : (_isFunction(ease) ? ease : _easeMap[ease] || _configEaseFromString(ease)) || defaultEase;
};
var _insertEase = function _insertEase(names, easeIn, easeOut, easeInOut) {
	if (easeOut === void 0) easeOut = function easeOut(p) {
		return 1 - easeIn(1 - p);
	};
	if (easeInOut === void 0) easeInOut = function easeInOut(p) {
		return p < .5 ? easeIn(p * 2) / 2 : 1 - easeIn((1 - p) * 2) / 2;
	};
	var ease = {
		easeIn,
		easeOut,
		easeInOut
	}, lowercaseName;
	_forEachName(names, function(name) {
		_easeMap[name] = _globals[name] = ease;
		_easeMap[lowercaseName = name.toLowerCase()] = easeOut;
		for (var p in ease) _easeMap[lowercaseName + (p === "easeIn" ? ".in" : p === "easeOut" ? ".out" : ".inOut")] = _easeMap[name + "." + p] = ease[p];
	});
	return ease;
};
var _easeInOutFromOut = function _easeInOutFromOut(easeOut) {
	return function(p) {
		return p < .5 ? (1 - easeOut(1 - p * 2)) / 2 : .5 + easeOut((p - .5) * 2) / 2;
	};
};
var _configElastic = function _configElastic(type, amplitude, period) {
	var p1 = amplitude >= 1 ? amplitude : 1, p2 = (period || (type ? .3 : .45)) / (amplitude < 1 ? amplitude : 1), p3 = p2 / _2PI * (Math.asin(1 / p1) || 0), easeOut = function easeOut(p) {
		return p === 1 ? 1 : p1 * Math.pow(2, -10 * p) * _sin((p - p3) * p2) + 1;
	}, ease = type === "out" ? easeOut : type === "in" ? function(p) {
		return 1 - easeOut(1 - p);
	} : _easeInOutFromOut(easeOut);
	p2 = _2PI / p2;
	ease.config = function(amplitude, period) {
		return _configElastic(type, amplitude, period);
	};
	return ease;
};
var _configBack = function _configBack(type, overshoot) {
	if (overshoot === void 0) overshoot = 1.70158;
	var easeOut = function easeOut(p) {
		return p ? --p * p * ((overshoot + 1) * p + overshoot) + 1 : 0;
	}, ease = type === "out" ? easeOut : type === "in" ? function(p) {
		return 1 - easeOut(1 - p);
	} : _easeInOutFromOut(easeOut);
	ease.config = function(overshoot) {
		return _configBack(type, overshoot);
	};
	return ease;
};
_forEachName("Linear,Quad,Cubic,Quart,Quint,Strong", function(name, i) {
	var power = i < 5 ? i + 1 : i;
	_insertEase(name + ",Power" + (power - 1), i ? function(p) {
		return Math.pow(p, power);
	} : function(p) {
		return p;
	}, function(p) {
		return 1 - Math.pow(1 - p, power);
	}, function(p) {
		return p < .5 ? Math.pow(p * 2, power) / 2 : 1 - Math.pow((1 - p) * 2, power) / 2;
	});
});
_easeMap.Linear.easeNone = _easeMap.none = _easeMap.Linear.easeIn;
_insertEase("Elastic", _configElastic("in"), _configElastic("out"), _configElastic());
(function(n, c) {
	var n1 = 1 / c, n2 = 2 * n1, n3 = 2.5 * n1, easeOut = function easeOut(p) {
		return p < n1 ? n * p * p : p < n2 ? n * Math.pow(p - 1.5 / c, 2) + .75 : p < n3 ? n * (p -= 2.25 / c) * p + .9375 : n * Math.pow(p - 2.625 / c, 2) + .984375;
	};
	_insertEase("Bounce", function(p) {
		return 1 - easeOut(1 - p);
	}, easeOut);
})(7.5625, 2.75);
_insertEase("Expo", function(p) {
	return Math.pow(2, 10 * (p - 1)) * p + p * p * p * p * p * p * (1 - p);
});
_insertEase("Circ", function(p) {
	return -(_sqrt(1 - p * p) - 1);
});
_insertEase("Sine", function(p) {
	return p === 1 ? 1 : -_cos(p * _HALF_PI) + 1;
});
_insertEase("Back", _configBack("in"), _configBack("out"), _configBack());
_easeMap.SteppedEase = _easeMap.steps = _globals.SteppedEase = { config: function config(steps, immediateStart) {
	if (steps === void 0) steps = 1;
	var p1 = 1 / steps, p2 = steps + (immediateStart ? 0 : 1), p3 = immediateStart ? 1 : 0, max = 1 - _tinyNum;
	return function(p) {
		return ((p2 * _clamp(0, max, p) | 0) + p3) * p1;
	};
} };
_defaults.ease = _easeMap["quad.out"];
_forEachName("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt", function(name) {
	return _callbackNames += name + "," + name + "Params,";
});
var GSCache = function GSCache(target, harness) {
	this.id = _gsID++;
	target._gsap = this;
	this.target = target;
	this.harness = harness;
	this.get = harness ? harness.get : _getProperty;
	this.set = harness ? harness.getSetter : _getSetter;
};
var Animation = /*#__PURE__*/ function() {
	function Animation(vars) {
		this.vars = vars;
		this._delay = +vars.delay || 0;
		if (this._repeat = vars.repeat === Infinity ? -2 : vars.repeat || 0) {
			this._rDelay = vars.repeatDelay || 0;
			this._yoyo = !!vars.yoyo || !!vars.yoyoEase;
		}
		this._ts = 1;
		_setDuration(this, +vars.duration, 1, 1);
		this.data = vars.data;
		if (_context) {
			this._ctx = _context;
			_context.data.push(this);
		}
		_tickerActive || _ticker.wake();
	}
	var _proto = Animation.prototype;
	_proto.delay = function delay(value) {
		if (value || value === 0) {
			this.parent && this.parent.smoothChildTiming && this.startTime(this._start + value - this._delay);
			this._delay = value;
			return this;
		}
		return this._delay;
	};
	_proto.duration = function duration(value) {
		return arguments.length ? this.totalDuration(this._repeat > 0 ? value + (value + this._rDelay) * this._repeat : value) : this.totalDuration() && this._dur;
	};
	_proto.totalDuration = function totalDuration(value) {
		if (!arguments.length) return this._tDur;
		this._dirty = 0;
		return _setDuration(this, this._repeat < 0 ? value : (value - this._repeat * this._rDelay) / (this._repeat + 1));
	};
	_proto.totalTime = function totalTime(_totalTime, suppressEvents) {
		_wake();
		if (!arguments.length) return this._tTime;
		var parent = this._dp;
		if (parent && parent.smoothChildTiming && this._ts) {
			_alignPlayhead(this, _totalTime);
			!parent._dp || parent.parent || _postAddChecks(parent, this);
			while (parent && parent.parent) {
				if (parent.parent._time !== parent._start + (parent._ts >= 0 ? parent._tTime / parent._ts : (parent.totalDuration() - parent._tTime) / -parent._ts)) parent.totalTime(parent._tTime, true);
				parent = parent.parent;
			}
			if (!this.parent && this._dp.autoRemoveChildren && (this._ts > 0 && _totalTime < this._tDur || this._ts < 0 && _totalTime > 0 || !this._tDur && !_totalTime)) _addToTimeline(this._dp, this, this._start - this._delay);
		}
		if (this._tTime !== _totalTime || !this._dur && !suppressEvents || this._initted && Math.abs(this._zTime) === _tinyNum || !this._initted && this._dur && _totalTime || !_totalTime && !this._initted && (this.add || this._ptLookup)) {
			this._ts || (this._pTime = _totalTime);
			_lazySafeRender(this, _totalTime, suppressEvents);
		}
		return this;
	};
	_proto.time = function time(value, suppressEvents) {
		return arguments.length ? this.totalTime(Math.min(this.totalDuration(), value + _elapsedCycleDuration(this)) % (this._dur + this._rDelay) || (value ? this._dur : 0), suppressEvents) : this._time;
	};
	_proto.totalProgress = function totalProgress(value, suppressEvents) {
		return arguments.length ? this.totalTime(this.totalDuration() * value, suppressEvents) : this.totalDuration() ? Math.min(1, this._tTime / this._tDur) : this.rawTime() >= 0 && this._initted ? 1 : 0;
	};
	_proto.progress = function progress(value, suppressEvents) {
		return arguments.length ? this.totalTime(this.duration() * (this._yoyo && !(this.iteration() & 1) ? 1 - value : value) + _elapsedCycleDuration(this), suppressEvents) : this.duration() ? Math.min(1, this._time / this._dur) : this.rawTime() > 0 ? 1 : 0;
	};
	_proto.iteration = function iteration(value, suppressEvents) {
		var cycleDuration = this.duration() + this._rDelay;
		return arguments.length ? this.totalTime(this._time + (value - 1) * cycleDuration, suppressEvents) : this._repeat ? _animationCycle(this._tTime, cycleDuration) + 1 : 1;
	};
	_proto.timeScale = function timeScale(value, suppressEvents) {
		if (!arguments.length) return this._rts === -_tinyNum ? 0 : this._rts;
		if (this._rts === value) return this;
		var tTime = this.parent && this._ts ? _parentToChildTotalTime(this.parent._time, this) : this._tTime;
		this._rts = +value || 0;
		this._ts = this._ps || value === -_tinyNum ? 0 : this._rts;
		this.totalTime(_clamp(-Math.abs(this._delay), this.totalDuration(), tTime), suppressEvents !== false);
		_setEnd(this);
		return _recacheAncestors(this);
	};
	_proto.paused = function paused(value) {
		if (!arguments.length) return this._ps;
		if (this._ps !== value) {
			this._ps = value;
			if (value) {
				this._pTime = this._tTime || Math.max(-this._delay, this.rawTime());
				this._ts = this._act = 0;
			} else {
				_wake();
				this._ts = this._rts;
				this.totalTime(this.parent && !this.parent.smoothChildTiming ? this.rawTime() : this._tTime || this._pTime, this.progress() === 1 && Math.abs(this._zTime) !== _tinyNum && (this._tTime -= _tinyNum));
			}
		}
		return this;
	};
	_proto.startTime = function startTime(value) {
		if (arguments.length) {
			this._start = _roundPrecise(value);
			var parent = this.parent || this._dp;
			parent && (parent._sort || !this.parent) && _addToTimeline(parent, this, this._start - this._delay);
			return this;
		}
		return this._start;
	};
	_proto.endTime = function endTime(includeRepeats) {
		return this._start + (_isNotFalse(includeRepeats) ? this.totalDuration() : this.duration()) / Math.abs(this._ts || 1);
	};
	_proto.rawTime = function rawTime(wrapRepeats) {
		var parent = this.parent || this._dp;
		return !parent ? this._tTime : wrapRepeats && (!this._ts || this._repeat && this._time && this.totalProgress() < 1) ? this._tTime % (this._dur + this._rDelay) : !this._ts ? this._tTime : _parentToChildTotalTime(parent.rawTime(wrapRepeats), this);
	};
	_proto.revert = function revert(config) {
		if (config === void 0) config = _revertConfig;
		var prevIsReverting = _reverting$1;
		_reverting$1 = config;
		if (_isRevertWorthy(this)) {
			this.timeline && this.timeline.revert(config);
			this.totalTime(-.01, config.suppressEvents);
		}
		this.data !== "nested" && config.kill !== false && this.kill();
		_reverting$1 = prevIsReverting;
		return this;
	};
	_proto.globalTime = function globalTime(rawTime) {
		var animation = this, time = arguments.length ? rawTime : animation.rawTime();
		while (animation) {
			time = animation._start + time / (Math.abs(animation._ts) || 1);
			animation = animation._dp;
		}
		return !this.parent && this._sat ? this._sat.globalTime(rawTime) : time;
	};
	_proto.repeat = function repeat(value) {
		if (arguments.length) {
			this._repeat = value === Infinity ? -2 : value;
			return _onUpdateTotalDuration(this);
		}
		return this._repeat === -2 ? Infinity : this._repeat;
	};
	_proto.repeatDelay = function repeatDelay(value) {
		if (arguments.length) {
			var time = this._time;
			this._rDelay = value;
			_onUpdateTotalDuration(this);
			return time ? this.time(time) : this;
		}
		return this._rDelay;
	};
	_proto.yoyo = function yoyo(value) {
		if (arguments.length) {
			this._yoyo = value;
			return this;
		}
		return this._yoyo;
	};
	_proto.seek = function seek(position, suppressEvents) {
		return this.totalTime(_parsePosition(this, position), _isNotFalse(suppressEvents));
	};
	_proto.restart = function restart(includeDelay, suppressEvents) {
		this.play().totalTime(includeDelay ? -this._delay : 0, _isNotFalse(suppressEvents));
		this._dur || (this._zTime = -_tinyNum);
		return this;
	};
	_proto.play = function play(from, suppressEvents) {
		from != null && this.seek(from, suppressEvents);
		return this.reversed(false).paused(false);
	};
	_proto.reverse = function reverse(from, suppressEvents) {
		from != null && this.seek(from || this.totalDuration(), suppressEvents);
		return this.reversed(true).paused(false);
	};
	_proto.pause = function pause(atTime, suppressEvents) {
		atTime != null && this.seek(atTime, suppressEvents);
		return this.paused(true);
	};
	_proto.resume = function resume() {
		return this.paused(false);
	};
	_proto.reversed = function reversed(value) {
		if (arguments.length) {
			!!value !== this.reversed() && this.timeScale(-this._rts || (value ? -_tinyNum : 0));
			return this;
		}
		return this._rts < 0;
	};
	_proto.invalidate = function invalidate() {
		this._initted = this._act = 0;
		this._zTime = -_tinyNum;
		return this;
	};
	_proto.isActive = function isActive() {
		var parent = this.parent || this._dp, start = this._start, rawTime;
		return !!(!parent || this._ts && this._initted && parent.isActive() && (rawTime = parent.rawTime(true)) >= start && rawTime < this.endTime(true) - _tinyNum);
	};
	_proto.eventCallback = function eventCallback(type, callback, params) {
		var vars = this.vars;
		if (arguments.length > 1) {
			if (!callback) delete vars[type];
			else {
				vars[type] = callback;
				params && (vars[type + "Params"] = params);
				type === "onUpdate" && (this._onUpdate = callback);
			}
			return this;
		}
		return vars[type];
	};
	_proto.then = function then(onFulfilled) {
		var self = this, prevProm = self._prom;
		return new Promise(function(resolve) {
			var f = _isFunction(onFulfilled) ? onFulfilled : _passThrough, _resolve = function _resolve() {
				var _then = self.then;
				self.then = null;
				prevProm && prevProm();
				_isFunction(f) && (f = f(self)) && (f.then || f === self) && (self.then = _then);
				resolve(f);
				self.then = _then;
			};
			if (self._initted && self.totalProgress() === 1 && self._ts >= 0 || !self._tTime && self._ts < 0) _resolve();
			else self._prom = _resolve;
		});
	};
	_proto.kill = function kill() {
		_interrupt(this);
	};
	return Animation;
}();
_setDefaults(Animation.prototype, {
	_time: 0,
	_start: 0,
	_end: 0,
	_tTime: 0,
	_tDur: 0,
	_dirty: 0,
	_repeat: 0,
	_yoyo: false,
	parent: null,
	_initted: false,
	_rDelay: 0,
	_ts: 1,
	_dp: 0,
	ratio: 0,
	_zTime: -_tinyNum,
	_prom: 0,
	_ps: false,
	_rts: 1
});
var Timeline = /*#__PURE__*/ function(_Animation) {
	_inheritsLoose(Timeline, _Animation);
	function Timeline(vars, position) {
		var _this;
		if (vars === void 0) vars = {};
		_this = _Animation.call(this, vars) || this;
		_this.labels = {};
		_this.smoothChildTiming = !!vars.smoothChildTiming;
		_this.autoRemoveChildren = !!vars.autoRemoveChildren;
		_this._sort = _isNotFalse(vars.sortChildren);
		_globalTimeline && _addToTimeline(vars.parent || _globalTimeline, _assertThisInitialized(_this), position);
		vars.reversed && _this.reverse();
		vars.paused && _this.paused(true);
		vars.scrollTrigger && _scrollTrigger(_assertThisInitialized(_this), vars.scrollTrigger);
		return _this;
	}
	var _proto2 = Timeline.prototype;
	_proto2.to = function to(targets, vars, position) {
		_createTweenType(0, arguments, this);
		return this;
	};
	_proto2.from = function from(targets, vars, position) {
		_createTweenType(1, arguments, this);
		return this;
	};
	_proto2.fromTo = function fromTo(targets, fromVars, toVars, position) {
		_createTweenType(2, arguments, this);
		return this;
	};
	_proto2.set = function set(targets, vars, position) {
		vars.duration = 0;
		vars.parent = this;
		_inheritDefaults(vars).repeatDelay || (vars.repeat = 0);
		vars.immediateRender = !!vars.immediateRender;
		new Tween(targets, vars, _parsePosition(this, position), 1);
		return this;
	};
	_proto2.call = function call(callback, params, position) {
		return _addToTimeline(this, Tween.delayedCall(0, callback, params), position);
	};
	_proto2.staggerTo = function staggerTo(targets, duration, vars, stagger, position, onCompleteAll, onCompleteAllParams) {
		vars.duration = duration;
		vars.stagger = vars.stagger || stagger;
		vars.onComplete = onCompleteAll;
		vars.onCompleteParams = onCompleteAllParams;
		vars.parent = this;
		new Tween(targets, vars, _parsePosition(this, position));
		return this;
	};
	_proto2.staggerFrom = function staggerFrom(targets, duration, vars, stagger, position, onCompleteAll, onCompleteAllParams) {
		vars.runBackwards = 1;
		_inheritDefaults(vars).immediateRender = _isNotFalse(vars.immediateRender);
		return this.staggerTo(targets, duration, vars, stagger, position, onCompleteAll, onCompleteAllParams);
	};
	_proto2.staggerFromTo = function staggerFromTo(targets, duration, fromVars, toVars, stagger, position, onCompleteAll, onCompleteAllParams) {
		toVars.startAt = fromVars;
		_inheritDefaults(toVars).immediateRender = _isNotFalse(toVars.immediateRender);
		return this.staggerTo(targets, duration, toVars, stagger, position, onCompleteAll, onCompleteAllParams);
	};
	_proto2.render = function render(totalTime, suppressEvents, force) {
		var prevTime = this._time, tDur = this._dirty ? this.totalDuration() : this._tDur, dur = this._dur, tTime = totalTime <= 0 ? 0 : _roundPrecise(totalTime), crossingStart = this._zTime < 0 !== totalTime < 0 && (this._initted || !dur), time, child, next, iteration, cycleDuration, prevPaused, pauseTween, timeScale, prevStart, prevIteration, yoyo, isYoyo;
		this !== _globalTimeline && tTime > tDur && totalTime >= 0 && (tTime = tDur);
		if (tTime !== this._tTime || force || crossingStart) {
			if (prevTime !== this._time && dur) {
				tTime += this._time - prevTime;
				totalTime += this._time - prevTime;
			}
			time = tTime;
			prevStart = this._start;
			timeScale = this._ts;
			prevPaused = !timeScale;
			if (crossingStart) {
				dur || (prevTime = this._zTime);
				(totalTime || !suppressEvents) && (this._zTime = totalTime);
			}
			if (this._repeat) {
				yoyo = this._yoyo;
				cycleDuration = dur + this._rDelay;
				if (this._repeat < -1 && totalTime < 0) return this.totalTime(cycleDuration * 100 + totalTime, suppressEvents, force);
				time = _roundPrecise(tTime % cycleDuration);
				if (tTime === tDur) {
					iteration = this._repeat;
					time = dur;
				} else {
					prevIteration = _roundPrecise(tTime / cycleDuration);
					iteration = ~~prevIteration;
					if (iteration && iteration === prevIteration) {
						time = dur;
						iteration--;
					}
					time > dur && (time = dur);
				}
				prevIteration = _animationCycle(this._tTime, cycleDuration);
				!prevTime && this._tTime && prevIteration !== iteration && this._tTime - prevIteration * cycleDuration - this._dur <= 0 && (prevIteration = iteration);
				if (yoyo && iteration & 1) {
					time = dur - time;
					isYoyo = 1;
				}
				if (iteration !== prevIteration && !this._lock) {
					var rewinding = yoyo && prevIteration & 1, doesWrap = rewinding === (yoyo && iteration & 1);
					iteration < prevIteration && (rewinding = !rewinding);
					prevTime = rewinding ? 0 : tTime % dur ? dur : tTime;
					this._lock = 1;
					this.render(prevTime || (isYoyo ? 0 : _roundPrecise(iteration * cycleDuration)), suppressEvents, !dur)._lock = 0;
					this._tTime = tTime;
					!suppressEvents && this.parent && _callback(this, "onRepeat");
					if (this.vars.repeatRefresh && !isYoyo) {
						this.invalidate()._lock = 1;
						prevIteration = iteration;
					}
					if (prevTime && prevTime !== this._time || prevPaused !== !this._ts || this.vars.onRepeat && !this.parent && !this._act) return this;
					dur = this._dur;
					tDur = this._tDur;
					if (doesWrap) {
						this._lock = 2;
						prevTime = rewinding ? dur : -1e-4;
						this.render(prevTime, true);
						this.vars.repeatRefresh && !isYoyo && this.invalidate();
					}
					this._lock = 0;
					if (!this._ts && !prevPaused) return this;
				}
			}
			if (this._hasPause && !this._forcing && this._lock < 2) {
				pauseTween = _findNextPauseTween(this, _roundPrecise(prevTime), _roundPrecise(time));
				if (pauseTween) tTime -= time - (time = pauseTween._start);
			}
			this._tTime = tTime;
			this._time = time;
			this._act = !!timeScale;
			if (!this._initted) {
				this._onUpdate = this.vars.onUpdate;
				this._initted = 1;
				this._zTime = totalTime;
				prevTime = 0;
			}
			if (!prevTime && tTime && dur && !suppressEvents && !prevIteration) {
				_callback(this, "onStart");
				if (this._tTime !== tTime) return this;
			}
			if (time >= prevTime && totalTime >= 0) {
				child = this._first;
				while (child) {
					next = child._next;
					if ((child._act || time >= child._start) && child._ts && pauseTween !== child) {
						if (child.parent !== this) return this.render(totalTime, suppressEvents, force);
						child.render(child._ts > 0 ? (time - child._start) * child._ts : (child._dirty ? child.totalDuration() : child._tDur) + (time - child._start) * child._ts, suppressEvents, force);
						if (time !== this._time || !this._ts && !prevPaused) {
							pauseTween = 0;
							next && (tTime += this._zTime = -_tinyNum);
							break;
						}
					}
					child = next;
				}
			} else {
				child = this._last;
				var adjustedTime = totalTime < 0 ? totalTime : time;
				while (child) {
					next = child._prev;
					if ((child._act || adjustedTime <= child._end) && child._ts && pauseTween !== child) {
						if (child.parent !== this) return this.render(totalTime, suppressEvents, force);
						child.render(child._ts > 0 ? (adjustedTime - child._start) * child._ts : (child._dirty ? child.totalDuration() : child._tDur) + (adjustedTime - child._start) * child._ts, suppressEvents, force || _reverting$1 && _isRevertWorthy(child));
						if (time !== this._time || !this._ts && !prevPaused) {
							pauseTween = 0;
							next && (tTime += this._zTime = adjustedTime ? -_tinyNum : _tinyNum);
							break;
						}
					}
					child = next;
				}
			}
			if (pauseTween && !suppressEvents) {
				this.pause();
				pauseTween.render(time >= prevTime ? 0 : -_tinyNum)._zTime = time >= prevTime ? 1 : -1;
				if (this._ts) {
					this._start = prevStart;
					_setEnd(this);
					return this.render(totalTime, suppressEvents, force);
				}
			}
			this._onUpdate && !suppressEvents && _callback(this, "onUpdate", true);
			if (tTime === tDur && this._tTime >= this.totalDuration() || !tTime && prevTime) {
				if (prevStart === this._start || Math.abs(timeScale) !== Math.abs(this._ts)) {
					if (!this._lock) {
						(totalTime || !dur) && (tTime === tDur && this._ts > 0 || !tTime && this._ts < 0) && _removeFromParent(this, 1);
						if (!suppressEvents && !(totalTime < 0 && !prevTime) && (tTime || prevTime || !tDur)) {
							_callback(this, tTime === tDur && totalTime >= 0 ? "onComplete" : "onReverseComplete", true);
							this._prom && !(tTime < tDur && this.timeScale() > 0) && this._prom();
						}
					}
				}
			}
		}
		return this;
	};
	_proto2.add = function add(child, position) {
		var _this2 = this;
		_isNumber(position) || (position = _parsePosition(this, position, child));
		if (!(child instanceof Animation)) {
			if (_isArray(child)) {
				child.forEach(function(obj) {
					return _this2.add(obj, position);
				});
				return this;
			}
			if (_isString(child)) return this.addLabel(child, position);
			if (_isFunction(child)) child = Tween.delayedCall(0, child);
			else return this;
		}
		return this !== child ? _addToTimeline(this, child, position) : this;
	};
	_proto2.getChildren = function getChildren(nested, tweens, timelines, ignoreBeforeTime) {
		if (nested === void 0) nested = true;
		if (tweens === void 0) tweens = true;
		if (timelines === void 0) timelines = true;
		if (ignoreBeforeTime === void 0) ignoreBeforeTime = -_bigNum$1;
		var a = [], child = this._first;
		while (child) {
			if (child._start >= ignoreBeforeTime) if (child instanceof Tween) tweens && a.push(child);
			else {
				timelines && a.push(child);
				nested && a.push.apply(a, child.getChildren(true, tweens, timelines));
			}
			child = child._next;
		}
		return a;
	};
	_proto2.getById = function getById(id) {
		var animations = this.getChildren(1, 1, 1), i = animations.length;
		while (i--) if (animations[i].vars.id === id) return animations[i];
	};
	_proto2.remove = function remove(child) {
		if (_isString(child)) return this.removeLabel(child);
		if (_isFunction(child)) return this.killTweensOf(child);
		child.parent === this && _removeLinkedListItem(this, child);
		if (child === this._recent) this._recent = this._last;
		return _uncache(this);
	};
	_proto2.totalTime = function totalTime(_totalTime2, suppressEvents) {
		if (!arguments.length) return this._tTime;
		this._forcing = 1;
		if (!this._dp && this._ts) this._start = _roundPrecise(_ticker.time - (this._ts > 0 ? _totalTime2 / this._ts : (this.totalDuration() - _totalTime2) / -this._ts));
		_Animation.prototype.totalTime.call(this, _totalTime2, suppressEvents);
		this._forcing = 0;
		return this;
	};
	_proto2.addLabel = function addLabel(label, position) {
		this.labels[label] = _parsePosition(this, position);
		return this;
	};
	_proto2.removeLabel = function removeLabel(label) {
		delete this.labels[label];
		return this;
	};
	_proto2.addPause = function addPause(position, callback, params) {
		var t = Tween.delayedCall(0, callback || _emptyFunc, params);
		t.data = "isPause";
		this._hasPause = 1;
		return _addToTimeline(this, t, _parsePosition(this, position));
	};
	_proto2.removePause = function removePause(position) {
		var child = this._first;
		position = _parsePosition(this, position);
		while (child) {
			if (child._start === position && child.data === "isPause") _removeFromParent(child);
			child = child._next;
		}
	};
	_proto2.killTweensOf = function killTweensOf(targets, props, onlyActive) {
		var tweens = this.getTweensOf(targets, onlyActive), i = tweens.length;
		while (i--) _overwritingTween !== tweens[i] && tweens[i].kill(targets, props);
		return this;
	};
	_proto2.getTweensOf = function getTweensOf(targets, onlyActive) {
		var a = [], parsedTargets = toArray(targets), child = this._first, isGlobalTime = _isNumber(onlyActive), children;
		while (child) {
			if (child instanceof Tween) {
				if (_arrayContainsAny(child._targets, parsedTargets) && (isGlobalTime ? (!_overwritingTween || child._initted && child._ts) && child.globalTime(0) <= onlyActive && child.globalTime(child.totalDuration()) > onlyActive : !onlyActive || child.isActive())) a.push(child);
			} else if ((children = child.getTweensOf(parsedTargets, onlyActive)).length) a.push.apply(a, children);
			child = child._next;
		}
		return a;
	};
	_proto2.tweenTo = function tweenTo(position, vars) {
		vars = vars || {};
		var tl = this, endTime = _parsePosition(tl, position), _vars = vars, startAt = _vars.startAt, _onStart = _vars.onStart, onStartParams = _vars.onStartParams, immediateRender = _vars.immediateRender, initted, tween = Tween.to(tl, _setDefaults({
			ease: vars.ease || "none",
			lazy: false,
			immediateRender: false,
			time: endTime,
			overwrite: "auto",
			duration: vars.duration || Math.abs((endTime - (startAt && "time" in startAt ? startAt.time : tl._time)) / tl.timeScale()) || _tinyNum,
			onStart: function onStart() {
				tl.pause();
				if (!initted) {
					var duration = vars.duration || Math.abs((endTime - (startAt && "time" in startAt ? startAt.time : tl._time)) / tl.timeScale());
					tween._dur !== duration && _setDuration(tween, duration, 0, 1).render(tween._time, true, true);
					initted = 1;
				}
				_onStart && _onStart.apply(tween, onStartParams || []);
			}
		}, vars));
		return immediateRender ? tween.render(0) : tween;
	};
	_proto2.tweenFromTo = function tweenFromTo(fromPosition, toPosition, vars) {
		return this.tweenTo(toPosition, _setDefaults({ startAt: { time: _parsePosition(this, fromPosition) } }, vars));
	};
	_proto2.recent = function recent() {
		return this._recent;
	};
	_proto2.nextLabel = function nextLabel(afterTime) {
		if (afterTime === void 0) afterTime = this._time;
		return _getLabelInDirection(this, _parsePosition(this, afterTime));
	};
	_proto2.previousLabel = function previousLabel(beforeTime) {
		if (beforeTime === void 0) beforeTime = this._time;
		return _getLabelInDirection(this, _parsePosition(this, beforeTime), 1);
	};
	_proto2.currentLabel = function currentLabel(value) {
		return arguments.length ? this.seek(value, true) : this.previousLabel(this._time + _tinyNum);
	};
	_proto2.shiftChildren = function shiftChildren(amount, adjustLabels, ignoreBeforeTime) {
		if (ignoreBeforeTime === void 0) ignoreBeforeTime = 0;
		var child = this._first, labels = this.labels, p;
		amount = _roundPrecise(amount);
		while (child) {
			if (child._start >= ignoreBeforeTime) {
				child._start += amount;
				child._end += amount;
			}
			child = child._next;
		}
		if (adjustLabels) {
			for (p in labels) if (labels[p] >= ignoreBeforeTime) labels[p] += amount;
		}
		return _uncache(this);
	};
	_proto2.invalidate = function invalidate(soft) {
		var child = this._first;
		this._lock = 0;
		while (child) {
			child.invalidate(soft);
			child = child._next;
		}
		return _Animation.prototype.invalidate.call(this, soft);
	};
	_proto2.clear = function clear(includeLabels) {
		if (includeLabels === void 0) includeLabels = true;
		var child = this._first, next;
		while (child) {
			next = child._next;
			this.remove(child);
			child = next;
		}
		this._dp && (this._time = this._tTime = this._pTime = 0);
		includeLabels && (this.labels = {});
		return _uncache(this);
	};
	_proto2.totalDuration = function totalDuration(value) {
		var max = 0, self = this, child = self._last, prevStart = _bigNum$1, prev, start, parent;
		if (arguments.length) return self.timeScale((self._repeat < 0 ? self.duration() : self.totalDuration()) / (self.reversed() ? -value : value));
		if (self._dirty) {
			parent = self.parent;
			while (child) {
				prev = child._prev;
				child._dirty && child.totalDuration();
				start = child._start;
				if (start > prevStart && self._sort && child._ts && !self._lock) {
					self._lock = 1;
					_addToTimeline(self, child, start - child._delay, 1)._lock = 0;
				} else prevStart = start;
				if (start < 0 && child._ts) {
					max -= start;
					if (!parent && !self._dp || parent && parent.smoothChildTiming) {
						self._start += _roundPrecise(start / self._ts);
						self._time -= start;
						self._tTime -= start;
					}
					self.shiftChildren(-start, false, -Infinity);
					prevStart = 0;
				}
				child._end > max && child._ts && (max = child._end);
				child = prev;
			}
			_setDuration(self, self === _globalTimeline && self._time > max ? self._time : max, 1, 1);
			self._dirty = 0;
		}
		return self._tDur;
	};
	Timeline.updateRoot = function updateRoot(time) {
		if (_globalTimeline._ts) {
			_lazySafeRender(_globalTimeline, _parentToChildTotalTime(time, _globalTimeline));
			_lastRenderedFrame = _ticker.frame;
		}
		if (_ticker.frame >= _nextGCFrame) {
			_nextGCFrame += _config.autoSleep || 120;
			var child = _globalTimeline._first;
			if (!child || !child._ts) {
				if (_config.autoSleep && _ticker._listeners.length < 2) {
					while (child && !child._ts) child = child._next;
					child || _ticker.sleep();
				}
			}
		}
	};
	return Timeline;
}(Animation);
_setDefaults(Timeline.prototype, {
	_lock: 0,
	_hasPause: 0,
	_forcing: 0
});
var _addComplexStringPropTween = function _addComplexStringPropTween(target, prop, start, end, setter, stringFilter, funcParam) {
	var pt = new PropTween(this._pt, target, prop, 0, 1, _renderComplexString, null, setter), index = 0, matchIndex = 0, result, startNums, color, endNum, chunk, startNum, hasRandom, a;
	pt.b = start;
	pt.e = end;
	start += "";
	end += "";
	if (hasRandom = ~end.indexOf("random(")) end = _replaceRandom(end);
	if (stringFilter) {
		a = [start, end];
		stringFilter(a, target, prop);
		start = a[0];
		end = a[1];
	}
	startNums = start.match(_complexStringNumExp) || [];
	while (result = _complexStringNumExp.exec(end)) {
		endNum = result[0];
		chunk = end.substring(index, result.index);
		if (color) color = (color + 1) % 5;
		else if (chunk.substr(-5) === "rgba(") color = 1;
		if (endNum !== startNums[matchIndex++]) {
			startNum = parseFloat(startNums[matchIndex - 1]) || 0;
			pt._pt = {
				_next: pt._pt,
				p: chunk || matchIndex === 1 ? chunk : ",",
				s: startNum,
				c: endNum.charAt(1) === "=" ? _parseRelative(startNum, endNum) - startNum : parseFloat(endNum) - startNum,
				m: color && color < 4 ? Math.round : 0
			};
			index = _complexStringNumExp.lastIndex;
		}
	}
	pt.c = index < end.length ? end.substring(index, end.length) : "";
	pt.fp = funcParam;
	if (_relExp.test(end) || hasRandom) pt.e = 0;
	this._pt = pt;
	return pt;
};
var _addPropTween = function _addPropTween(target, prop, start, end, index, targets, modifier, stringFilter, funcParam, optional) {
	_isFunction(end) && (end = end(index || 0, target, targets));
	var currentValue = target[prop], parsedStart = start !== "get" ? start : !_isFunction(currentValue) ? currentValue : funcParam ? target[prop.indexOf("set") || !_isFunction(target["get" + prop.substr(3)]) ? prop : "get" + prop.substr(3)](funcParam) : target[prop](), setter = !_isFunction(currentValue) ? _setterPlain : funcParam ? _setterFuncWithParam : _setterFunc, pt;
	if (_isString(end)) {
		if (~end.indexOf("random(")) end = _replaceRandom(end);
		if (end.charAt(1) === "=") {
			pt = _parseRelative(parsedStart, end) + (getUnit(parsedStart) || 0);
			if (pt || pt === 0) end = pt;
		}
	}
	if (!optional || parsedStart !== end || _forceAllPropTweens) {
		if (!isNaN(parsedStart * end) && end !== "") {
			pt = new PropTween(this._pt, target, prop, +parsedStart || 0, end - (parsedStart || 0), typeof currentValue === "boolean" ? _renderBoolean : _renderPlain, 0, setter);
			funcParam && (pt.fp = funcParam);
			modifier && pt.modifier(modifier, this, target);
			return this._pt = pt;
		}
		!currentValue && !(prop in target) && _missingPlugin(prop, end);
		return _addComplexStringPropTween.call(this, target, prop, parsedStart, end, setter, stringFilter || _config.stringFilter, funcParam);
	}
};
var _processVars = function _processVars(vars, index, target, targets, tween) {
	_isFunction(vars) && (vars = _parseFuncOrString(vars, tween, index, target, targets));
	if (!_isObject(vars) || vars.style && vars.nodeType || _isArray(vars) || _isTypedArray(vars)) return _isString(vars) ? _parseFuncOrString(vars, tween, index, target, targets) : vars;
	var copy = {}, p;
	for (p in vars) copy[p] = _parseFuncOrString(vars[p], tween, index, target, targets);
	return copy;
};
var _checkPlugin = function _checkPlugin(property, vars, tween, index, target, targets) {
	var plugin, pt, ptLookup, i;
	if (_plugins[property] && (plugin = new _plugins[property]()).init(target, plugin.rawVars ? vars[property] : _processVars(vars[property], index, target, targets, tween), tween, index, targets) !== false) {
		tween._pt = pt = new PropTween(tween._pt, target, property, 0, 1, plugin.render, plugin, 0, plugin.priority);
		if (tween !== _quickTween) {
			ptLookup = tween._ptLookup[tween._targets.indexOf(target)];
			i = plugin._props.length;
			while (i--) ptLookup[plugin._props[i]] = pt;
		}
	}
	return plugin;
};
var _overwritingTween;
var _forceAllPropTweens;
var _initTween = function _initTween(tween, time, tTime) {
	var vars = tween.vars, ease = vars.ease, startAt = vars.startAt, immediateRender = vars.immediateRender, lazy = vars.lazy, onUpdate = vars.onUpdate, runBackwards = vars.runBackwards, yoyoEase = vars.yoyoEase, keyframes = vars.keyframes, autoRevert = vars.autoRevert, dur = tween._dur, prevStartAt = tween._startAt, targets = tween._targets, parent = tween.parent, fullTargets = parent && parent.data === "nested" ? parent.vars.targets : targets, autoOverwrite = tween._overwrite === "auto" && !_suppressOverwrites, tl = tween.timeline, reverseEase = vars.easeReverse || yoyoEase, cleanVars, i, p, pt, target, hasPriority, gsData, harness, plugin, ptLookup, index, harnessVars, overwritten;
	tl && (!keyframes || !ease) && (ease = "none");
	tween._ease = _parseEase(ease, _defaults.ease);
	tween._rEase = reverseEase && (_parseEase(reverseEase) || tween._ease);
	tween._from = !tl && !!vars.runBackwards;
	if (tween._from) tween.ratio = 1;
	if (!tl || keyframes && !vars.stagger) {
		harness = targets[0] ? _getCache(targets[0]).harness : 0;
		harnessVars = harness && vars[harness.prop];
		cleanVars = _copyExcluding(vars, _reservedProps);
		if (prevStartAt) {
			prevStartAt._zTime < 0 && prevStartAt.progress(1);
			time < 0 && runBackwards && immediateRender && !autoRevert ? prevStartAt.render(-1, true) : prevStartAt.revert(runBackwards && dur ? _revertConfigNoKill : _startAtRevertConfig);
			prevStartAt._lazy = 0;
		}
		if (startAt) {
			_removeFromParent(tween._startAt = Tween.set(targets, _setDefaults({
				data: "isStart",
				overwrite: false,
				parent,
				immediateRender: true,
				lazy: !prevStartAt && _isNotFalse(lazy),
				startAt: null,
				delay: 0,
				onUpdate: onUpdate && function() {
					return _callback(tween, "onUpdate");
				},
				stagger: 0
			}, startAt)));
			tween._startAt._dp = 0;
			tween._startAt._sat = tween;
			time < 0 && (_reverting$1 || !immediateRender && !autoRevert) && tween._startAt.revert(_revertConfigNoKill);
			if (immediateRender) {
				if (dur && time <= 0 && tTime <= 0) {
					time && (tween._zTime = time);
					return;
				}
			}
		} else if (runBackwards && dur) {
			if (!prevStartAt) {
				time && (immediateRender = false);
				p = _setDefaults({
					overwrite: false,
					data: "isFromStart",
					lazy: immediateRender && !prevStartAt && _isNotFalse(lazy),
					immediateRender,
					stagger: 0,
					parent
				}, cleanVars);
				harnessVars && (p[harness.prop] = harnessVars);
				_removeFromParent(tween._startAt = Tween.set(targets, p));
				tween._startAt._dp = 0;
				tween._startAt._sat = tween;
				time < 0 && (_reverting$1 ? tween._startAt.revert(_revertConfigNoKill) : tween._startAt.render(-1, true));
				tween._zTime = time;
				if (!immediateRender) _initTween(tween._startAt, _tinyNum, _tinyNum);
				else if (!time) return;
			}
		}
		tween._pt = tween._ptCache = 0;
		lazy = dur && _isNotFalse(lazy) || lazy && !dur;
		for (i = 0; i < targets.length; i++) {
			target = targets[i];
			gsData = target._gsap || _harness(targets)[i]._gsap;
			tween._ptLookup[i] = ptLookup = {};
			_lazyLookup[gsData.id] && _lazyTweens.length && _lazyRender();
			index = fullTargets === targets ? i : fullTargets.indexOf(target);
			if (harness && (plugin = new harness()).init(target, harnessVars || cleanVars, tween, index, fullTargets) !== false) {
				tween._pt = pt = new PropTween(tween._pt, target, plugin.name, 0, 1, plugin.render, plugin, 0, plugin.priority);
				plugin._props.forEach(function(name) {
					ptLookup[name] = pt;
				});
				plugin.priority && (hasPriority = 1);
			}
			if (!harness || harnessVars) for (p in cleanVars) if (_plugins[p] && (plugin = _checkPlugin(p, cleanVars, tween, index, target, fullTargets))) plugin.priority && (hasPriority = 1);
			else ptLookup[p] = pt = _addPropTween.call(tween, target, p, "get", cleanVars[p], index, fullTargets, 0, vars.stringFilter);
			tween._op && tween._op[i] && tween.kill(target, tween._op[i]);
			if (autoOverwrite && tween._pt) {
				_overwritingTween = tween;
				_globalTimeline.killTweensOf(target, ptLookup, tween.globalTime(time));
				overwritten = !tween.parent;
				_overwritingTween = 0;
			}
			tween._pt && lazy && (_lazyLookup[gsData.id] = 1);
		}
		hasPriority && _sortPropTweensByPriority(tween);
		tween._onInit && tween._onInit(tween);
	}
	tween._onUpdate = onUpdate;
	tween._initted = (!tween._op || tween._pt) && !overwritten;
	keyframes && time <= 0 && tl.render(_bigNum$1, true, true);
};
var _updatePropTweens = function _updatePropTweens(tween, property, value, start, startIsRelative, ratio, time, skipRecursion) {
	var ptCache = (tween._pt && tween._ptCache || (tween._ptCache = {}))[property], pt, rootPT, lookup, i;
	if (!ptCache) {
		ptCache = tween._ptCache[property] = [];
		lookup = tween._ptLookup;
		i = tween._targets.length;
		while (i--) {
			pt = lookup[i][property];
			if (pt && pt.d && pt.d._pt) {
				pt = pt.d._pt;
				while (pt && pt.p !== property && pt.fp !== property) pt = pt._next;
			}
			if (!pt) {
				_forceAllPropTweens = 1;
				tween.vars[property] = "+=0";
				_initTween(tween, time);
				_forceAllPropTweens = 0;
				return skipRecursion ? _warn(property + " not eligible for reset. Try splitting into individual properties") : 1;
			}
			ptCache.push(pt);
		}
	}
	i = ptCache.length;
	while (i--) {
		rootPT = ptCache[i];
		pt = rootPT._pt || rootPT;
		pt.s = (start || start === 0) && !startIsRelative ? start : pt.s + (start || 0) + ratio * pt.c;
		pt.c = value - pt.s;
		rootPT.e && (rootPT.e = _round(value) + getUnit(rootPT.e));
		rootPT.b && (rootPT.b = pt.s + getUnit(rootPT.b));
	}
};
var _addAliasesToVars = function _addAliasesToVars(targets, vars) {
	var harness = targets[0] ? _getCache(targets[0]).harness : 0, propertyAliases = harness && harness.aliases, copy, p, i, aliases;
	if (!propertyAliases) return vars;
	copy = _merge({}, vars);
	for (p in propertyAliases) if (p in copy) {
		aliases = propertyAliases[p].split(",");
		i = aliases.length;
		while (i--) copy[aliases[i]] = copy[p];
	}
	return copy;
};
var _parseKeyframe = function _parseKeyframe(prop, obj, allProps, easeEach) {
	var ease = obj.ease || easeEach || "power1.inOut", p, a;
	if (_isArray(obj)) {
		a = allProps[prop] || (allProps[prop] = []);
		obj.forEach(function(value, i) {
			return a.push({
				t: i / (obj.length - 1) * 100,
				v: value,
				e: ease
			});
		});
	} else for (p in obj) {
		a = allProps[p] || (allProps[p] = []);
		p === "ease" || a.push({
			t: parseFloat(prop),
			v: obj[p],
			e: ease
		});
	}
};
var _parseFuncOrString = function _parseFuncOrString(value, tween, i, target, targets) {
	return _isFunction(value) ? value.call(tween, i, target, targets) : _isString(value) && ~value.indexOf("random(") ? _replaceRandom(value) : value;
};
var _staggerTweenProps = _callbackNames + "repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,easeReverse,autoRevert";
var _staggerPropsToSkip = {};
_forEachName(_staggerTweenProps + ",id,stagger,delay,duration,paused,scrollTrigger", function(name) {
	return _staggerPropsToSkip[name] = 1;
});
var Tween = /*#__PURE__*/ function(_Animation2) {
	_inheritsLoose(Tween, _Animation2);
	function Tween(targets, vars, position, skipInherit) {
		var _this3;
		if (typeof vars === "number") {
			position.duration = vars;
			vars = position;
			position = null;
		}
		_this3 = _Animation2.call(this, skipInherit ? vars : _inheritDefaults(vars)) || this;
		var _this3$vars = _this3.vars, duration = _this3$vars.duration, delay = _this3$vars.delay, immediateRender = _this3$vars.immediateRender, stagger = _this3$vars.stagger, overwrite = _this3$vars.overwrite, keyframes = _this3$vars.keyframes, defaults = _this3$vars.defaults, scrollTrigger = _this3$vars.scrollTrigger, parent = vars.parent || _globalTimeline, parsedTargets = (_isArray(targets) || _isTypedArray(targets) ? _isNumber(targets[0]) : "length" in vars) ? [targets] : toArray(targets), tl, i, copy, l, p, curTarget, staggerFunc, staggerVarsToMerge;
		_this3._targets = parsedTargets.length ? _harness(parsedTargets) : _warn("GSAP target " + targets + " not found. https://gsap.com", !_config.nullTargetWarn) || [];
		_this3._ptLookup = [];
		_this3._overwrite = overwrite;
		if (keyframes || stagger || _isFuncOrString(duration) || _isFuncOrString(delay)) {
			vars = _this3.vars;
			var easeReverse = vars.easeReverse || vars.yoyoEase;
			tl = _this3.timeline = new Timeline({
				data: "nested",
				defaults: defaults || {},
				targets: parent && parent.data === "nested" ? parent.vars.targets : parsedTargets
			});
			tl.kill();
			tl.parent = tl._dp = _assertThisInitialized(_this3);
			tl._start = 0;
			if (stagger || _isFuncOrString(duration) || _isFuncOrString(delay)) {
				l = parsedTargets.length;
				staggerFunc = stagger && distribute(stagger);
				if (_isObject(stagger)) {
					for (p in stagger) if (~_staggerTweenProps.indexOf(p)) {
						staggerVarsToMerge || (staggerVarsToMerge = {});
						staggerVarsToMerge[p] = stagger[p];
					}
				}
				for (i = 0; i < l; i++) {
					copy = _copyExcluding(vars, _staggerPropsToSkip);
					copy.stagger = 0;
					easeReverse && (copy.easeReverse = easeReverse);
					staggerVarsToMerge && _merge(copy, staggerVarsToMerge);
					curTarget = parsedTargets[i];
					copy.duration = +_parseFuncOrString(duration, _assertThisInitialized(_this3), i, curTarget, parsedTargets);
					copy.delay = (+_parseFuncOrString(delay, _assertThisInitialized(_this3), i, curTarget, parsedTargets) || 0) - _this3._delay;
					if (!stagger && l === 1 && copy.delay) {
						_this3._delay = delay = copy.delay;
						_this3._start += delay;
						copy.delay = 0;
					}
					tl.to(curTarget, copy, staggerFunc ? staggerFunc(i, curTarget, parsedTargets) : 0);
					tl._ease = _easeMap.none;
				}
				tl.duration() ? duration = delay = 0 : _this3.timeline = 0;
			} else if (keyframes) {
				_inheritDefaults(_setDefaults(tl.vars.defaults, { ease: "none" }));
				tl._ease = _parseEase(keyframes.ease || vars.ease || "none");
				var time = 0, a, kf, v;
				if (_isArray(keyframes)) {
					keyframes.forEach(function(frame) {
						return tl.to(parsedTargets, frame, ">");
					});
					tl.duration();
				} else {
					copy = {};
					for (p in keyframes) p === "ease" || p === "easeEach" || _parseKeyframe(p, keyframes[p], copy, keyframes.easeEach);
					for (p in copy) {
						a = copy[p].sort(function(a, b) {
							return a.t - b.t;
						});
						time = 0;
						for (i = 0; i < a.length; i++) {
							kf = a[i];
							v = {
								ease: kf.e,
								duration: (kf.t - (i ? a[i - 1].t : 0)) / 100 * duration
							};
							v[p] = kf.v;
							tl.to(parsedTargets, v, time);
							time += v.duration;
						}
					}
					tl.duration() < duration && tl.to({}, { duration: duration - tl.duration() });
				}
			}
			duration || _this3.duration(duration = tl.duration());
		} else _this3.timeline = 0;
		if (overwrite === true && !_suppressOverwrites) {
			_overwritingTween = _assertThisInitialized(_this3);
			_globalTimeline.killTweensOf(parsedTargets);
			_overwritingTween = 0;
		}
		_addToTimeline(parent, _assertThisInitialized(_this3), position);
		vars.reversed && _this3.reverse();
		vars.paused && _this3.paused(true);
		if (immediateRender || !duration && !keyframes && _this3._start === _roundPrecise(parent._time) && _isNotFalse(immediateRender) && _hasNoPausedAncestors(_assertThisInitialized(_this3)) && parent.data !== "nested") {
			_this3._tTime = -_tinyNum;
			_this3.render(Math.max(0, -delay) || 0);
		}
		scrollTrigger && _scrollTrigger(_assertThisInitialized(_this3), scrollTrigger);
		return _this3;
	}
	var _proto3 = Tween.prototype;
	_proto3.render = function render(totalTime, suppressEvents, force) {
		var prevTime = this._time, tDur = this._tDur, dur = this._dur, isNegative = totalTime < 0, tTime = totalTime > tDur - _tinyNum && !isNegative ? tDur : totalTime < _tinyNum ? 0 : totalTime, time, pt, iteration, cycleDuration, prevIteration, isYoyo, ratio, timeline;
		if (!dur) _renderZeroDurationTween(this, totalTime, suppressEvents, force);
		else if (tTime !== this._tTime || !totalTime || force || !this._initted && this._tTime || this._startAt && this._zTime < 0 !== isNegative || this._lazy) {
			time = tTime;
			timeline = this.timeline;
			if (this._repeat) {
				cycleDuration = dur + this._rDelay;
				if (this._repeat < -1 && isNegative) return this.totalTime(cycleDuration * 100 + totalTime, suppressEvents, force);
				time = _roundPrecise(tTime % cycleDuration);
				if (tTime === tDur) {
					iteration = this._repeat;
					time = dur;
				} else {
					prevIteration = _roundPrecise(tTime / cycleDuration);
					iteration = ~~prevIteration;
					if (iteration && iteration === prevIteration) {
						time = dur;
						iteration--;
					} else if (time > dur) time = dur;
				}
				isYoyo = this._yoyo && iteration & 1;
				if (isYoyo) time = dur - time;
				prevIteration = _animationCycle(this._tTime, cycleDuration);
				if (time === prevTime && !force && this._initted && iteration === prevIteration) {
					this._tTime = tTime;
					return this;
				}
				if (iteration !== prevIteration) {
					if (this.vars.repeatRefresh && !isYoyo && !this._lock && time !== cycleDuration && this._initted) {
						this._lock = force = 1;
						this.render(_roundPrecise(cycleDuration * iteration), true).invalidate()._lock = 0;
					}
				}
			}
			if (!this._initted) {
				if (_attemptInitTween(this, isNegative ? totalTime : time, force, suppressEvents, tTime)) {
					this._tTime = 0;
					return this;
				}
				if (prevTime !== this._time && !(force && this.vars.repeatRefresh && iteration !== prevIteration)) return this;
				if (dur !== this._dur) return this.render(totalTime, suppressEvents, force);
			}
			if (this._rEase) {
				var inv = time < prevTime;
				if (inv !== this._inv) {
					var segDur = inv ? prevTime : dur - prevTime;
					this._inv = inv;
					if (this._from) this.ratio = 1 - this.ratio;
					this._invRatio = this.ratio;
					this._invTime = prevTime;
					this._invRecip = segDur ? (inv ? -1 : 1) / segDur : 0;
					this._invScale = inv ? -this.ratio : 1 - this.ratio;
					this._invEase = inv ? this._rEase : this._ease;
				}
				this.ratio = ratio = this._invRatio + this._invScale * this._invEase((time - this._invTime) * this._invRecip);
			} else this.ratio = ratio = this._ease(time / dur);
			if (this._from) this.ratio = ratio = 1 - ratio;
			this._tTime = tTime;
			this._time = time;
			if (!this._act && this._ts) {
				this._act = 1;
				this._lazy = 0;
			}
			if (!prevTime && tTime && !suppressEvents && !prevIteration) {
				_callback(this, "onStart");
				if (this._tTime !== tTime) return this;
			}
			pt = this._pt;
			while (pt) {
				pt.r(ratio, pt.d);
				pt = pt._next;
			}
			timeline && timeline.render(totalTime < 0 ? totalTime : timeline._dur * timeline._ease(time / this._dur), suppressEvents, force) || this._startAt && (this._zTime = totalTime);
			if (this._onUpdate && !suppressEvents) {
				isNegative && _rewindStartAt(this, totalTime, suppressEvents, force);
				_callback(this, "onUpdate");
			}
			this._repeat && iteration !== prevIteration && this.vars.onRepeat && !suppressEvents && this.parent && _callback(this, "onRepeat");
			if ((tTime === this._tDur || !tTime) && this._tTime === tTime) {
				isNegative && !this._onUpdate && _rewindStartAt(this, totalTime, true, true);
				(totalTime || !dur) && (tTime === this._tDur && this._ts > 0 || !tTime && this._ts < 0) && _removeFromParent(this, 1);
				if (!suppressEvents && !(isNegative && !prevTime) && (tTime || prevTime || isYoyo)) {
					_callback(this, tTime === tDur ? "onComplete" : "onReverseComplete", true);
					this._prom && !(tTime < tDur && this.timeScale() > 0) && this._prom();
				}
			}
		}
		return this;
	};
	_proto3.targets = function targets() {
		return this._targets;
	};
	_proto3.invalidate = function invalidate(soft) {
		(!soft || !this.vars.runBackwards) && (this._startAt = 0);
		this._pt = this._op = this._onUpdate = this._lazy = this.ratio = 0;
		this._ptLookup = [];
		this.timeline && this.timeline.invalidate(soft);
		return _Animation2.prototype.invalidate.call(this, soft);
	};
	_proto3.resetTo = function resetTo(property, value, start, startIsRelative, skipRecursion) {
		_tickerActive || _ticker.wake();
		this._ts || this.play();
		var time = Math.min(this._dur, (this._dp._time - this._start) * this._ts), ratio;
		this._initted || _initTween(this, time);
		ratio = this._ease(time / this._dur);
		if (_updatePropTweens(this, property, value, start, startIsRelative, ratio, time, skipRecursion)) return this.resetTo(property, value, start, startIsRelative, 1);
		_alignPlayhead(this, 0);
		this.parent || _addLinkedListItem(this._dp, this, "_first", "_last", this._dp._sort ? "_start" : 0);
		return this.render(0);
	};
	_proto3.kill = function kill(targets, vars) {
		if (vars === void 0) vars = "all";
		if (!targets && (!vars || vars === "all")) {
			this._lazy = this._pt = 0;
			this.parent ? _interrupt(this) : this.scrollTrigger && this.scrollTrigger.kill(!!_reverting$1);
			return this;
		}
		if (this.timeline) {
			var tDur = this.timeline.totalDuration();
			this.timeline.killTweensOf(targets, vars, _overwritingTween && _overwritingTween.vars.overwrite !== true)._first || _interrupt(this);
			this.parent && tDur !== this.timeline.totalDuration() && _setDuration(this, this._dur * this.timeline._tDur / tDur, 0, 1);
			return this;
		}
		var parsedTargets = this._targets, killingTargets = targets ? toArray(targets) : parsedTargets, propTweenLookup = this._ptLookup, firstPT = this._pt, overwrittenProps, curLookup, curOverwriteProps, props, p, pt, i;
		if ((!vars || vars === "all") && _arraysMatch(parsedTargets, killingTargets)) {
			vars === "all" && (this._pt = 0);
			return _interrupt(this);
		}
		overwrittenProps = this._op = this._op || [];
		if (vars !== "all") {
			if (_isString(vars)) {
				p = {};
				_forEachName(vars, function(name) {
					return p[name] = 1;
				});
				vars = p;
			}
			vars = _addAliasesToVars(parsedTargets, vars);
		}
		i = parsedTargets.length;
		while (i--) if (~killingTargets.indexOf(parsedTargets[i])) {
			curLookup = propTweenLookup[i];
			if (vars === "all") {
				overwrittenProps[i] = vars;
				props = curLookup;
				curOverwriteProps = {};
			} else {
				curOverwriteProps = overwrittenProps[i] = overwrittenProps[i] || {};
				props = vars;
			}
			for (p in props) {
				pt = curLookup && curLookup[p];
				if (pt) {
					if (!("kill" in pt.d) || pt.d.kill(p) === true) _removeLinkedListItem(this, pt, "_pt");
					delete curLookup[p];
				}
				if (curOverwriteProps !== "all") curOverwriteProps[p] = 1;
			}
		}
		this._initted && !this._pt && firstPT && _interrupt(this);
		return this;
	};
	Tween.to = function to(targets, vars) {
		return new Tween(targets, vars, arguments[2]);
	};
	Tween.from = function from(targets, vars) {
		return _createTweenType(1, arguments);
	};
	Tween.delayedCall = function delayedCall(delay, callback, params, scope) {
		return new Tween(callback, 0, {
			immediateRender: false,
			lazy: false,
			overwrite: false,
			delay,
			onComplete: callback,
			onReverseComplete: callback,
			onCompleteParams: params,
			onReverseCompleteParams: params,
			callbackScope: scope
		});
	};
	Tween.fromTo = function fromTo(targets, fromVars, toVars) {
		return _createTweenType(2, arguments);
	};
	Tween.set = function set(targets, vars) {
		vars.duration = 0;
		vars.repeatDelay || (vars.repeat = 0);
		return new Tween(targets, vars);
	};
	Tween.killTweensOf = function killTweensOf(targets, props, onlyActive) {
		return _globalTimeline.killTweensOf(targets, props, onlyActive);
	};
	return Tween;
}(Animation);
_setDefaults(Tween.prototype, {
	_targets: [],
	_lazy: 0,
	_startAt: 0,
	_op: 0,
	_onInit: 0
});
_forEachName("staggerTo,staggerFrom,staggerFromTo", function(name) {
	Tween[name] = function() {
		var tl = new Timeline(), params = _slice.call(arguments, 0);
		params.splice(name === "staggerFromTo" ? 5 : 4, 0, 0);
		return tl[name].apply(tl, params);
	};
});
var _setterPlain = function _setterPlain(target, property, value) {
	return target[property] = value;
};
var _setterFunc = function _setterFunc(target, property, value) {
	return target[property](value);
};
var _setterFuncWithParam = function _setterFuncWithParam(target, property, value, data) {
	return target[property](data.fp, value);
};
var _setterAttribute = function _setterAttribute(target, property, value) {
	return target.setAttribute(property, value);
};
var _getSetter = function _getSetter(target, property) {
	return _isFunction(target[property]) ? _setterFunc : _isUndefined(target[property]) && target.setAttribute ? _setterAttribute : _setterPlain;
};
var _renderPlain = function _renderPlain(ratio, data) {
	return data.set(data.t, data.p, Math.round((data.s + data.c * ratio) * 1e6) / 1e6, data);
};
var _renderBoolean = function _renderBoolean(ratio, data) {
	return data.set(data.t, data.p, !!(data.s + data.c * ratio), data);
};
var _renderComplexString = function _renderComplexString(ratio, data) {
	var pt = data._pt, s = "";
	if (!ratio && data.b) s = data.b;
	else if (ratio === 1 && data.e) s = data.e;
	else {
		while (pt) {
			s = pt.p + (pt.m ? pt.m(pt.s + pt.c * ratio) : Math.round((pt.s + pt.c * ratio) * 1e4) / 1e4) + s;
			pt = pt._next;
		}
		s += data.c;
	}
	data.set(data.t, data.p, s, data);
};
var _renderPropTweens = function _renderPropTweens(ratio, data) {
	var pt = data._pt;
	while (pt) {
		pt.r(ratio, pt.d);
		pt = pt._next;
	}
};
var _addPluginModifier = function _addPluginModifier(modifier, tween, target, property) {
	var pt = this._pt, next;
	while (pt) {
		next = pt._next;
		pt.p === property && pt.modifier(modifier, tween, target);
		pt = next;
	}
};
var _killPropTweensOf = function _killPropTweensOf(property) {
	var pt = this._pt, hasNonDependentRemaining, next;
	while (pt) {
		next = pt._next;
		if (pt.p === property && !pt.op || pt.op === property) _removeLinkedListItem(this, pt, "_pt");
		else if (!pt.dep) hasNonDependentRemaining = 1;
		pt = next;
	}
	return !hasNonDependentRemaining;
};
var _setterWithModifier = function _setterWithModifier(target, property, value, data) {
	data.mSet(target, property, data.m.call(data.tween, value, data.mt), data);
};
var _sortPropTweensByPriority = function _sortPropTweensByPriority(parent) {
	var pt = parent._pt, next, pt2, first, last;
	while (pt) {
		next = pt._next;
		pt2 = first;
		while (pt2 && pt2.pr > pt.pr) pt2 = pt2._next;
		if (pt._prev = pt2 ? pt2._prev : last) pt._prev._next = pt;
		else first = pt;
		if (pt._next = pt2) pt2._prev = pt;
		else last = pt;
		pt = next;
	}
	parent._pt = first;
};
var PropTween = /*#__PURE__*/ function() {
	function PropTween(next, target, prop, start, change, renderer, data, setter, priority) {
		this.t = target;
		this.s = start;
		this.c = change;
		this.p = prop;
		this.r = renderer || _renderPlain;
		this.d = data || this;
		this.set = setter || _setterPlain;
		this.pr = priority || 0;
		this._next = next;
		if (next) next._prev = this;
	}
	var _proto4 = PropTween.prototype;
	_proto4.modifier = function modifier(func, tween, target) {
		this.mSet = this.mSet || this.set;
		this.set = _setterWithModifier;
		this.m = func;
		this.mt = target;
		this.tween = tween;
	};
	return PropTween;
}();
_forEachName(_callbackNames + "parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger,easeReverse", function(name) {
	return _reservedProps[name] = 1;
});
_globals.TweenMax = _globals.TweenLite = Tween;
_globals.TimelineLite = _globals.TimelineMax = Timeline;
_globalTimeline = new Timeline({
	sortChildren: false,
	defaults: _defaults,
	autoRemoveChildren: true,
	id: "root",
	smoothChildTiming: true
});
_config.stringFilter = _colorStringFilter;
var _media = [];
var _listeners = {};
var _emptyArray = [];
var _lastMediaTime = 0;
var _contextID = 0;
var _dispatch = function _dispatch(type) {
	return (_listeners[type] || _emptyArray).map(function(f) {
		return f();
	});
};
var _onMediaChange = function _onMediaChange() {
	var time = Date.now(), matches = [];
	if (time - _lastMediaTime > 2) {
		_dispatch("matchMediaInit");
		_media.forEach(function(c) {
			var queries = c.queries, conditions = c.conditions, match, p, anyMatch, toggled;
			for (p in queries) {
				match = _win$1.matchMedia(queries[p]).matches;
				match && (anyMatch = 1);
				if (match !== conditions[p]) {
					conditions[p] = match;
					toggled = 1;
				}
			}
			if (toggled) {
				c.revert();
				anyMatch && matches.push(c);
			}
		});
		_dispatch("matchMediaRevert");
		matches.forEach(function(c) {
			return c.onMatch(c, function(func) {
				return c.add(null, func);
			});
		});
		_lastMediaTime = time;
		_dispatch("matchMedia");
	}
};
var Context = /*#__PURE__*/ function() {
	function Context(func, scope) {
		this.selector = scope && selector(scope);
		this.data = [];
		this._r = [];
		this.isReverted = false;
		this.id = _contextID++;
		func && this.add(func);
	}
	var _proto5 = Context.prototype;
	_proto5.add = function add(name, func, scope) {
		if (_isFunction(name)) {
			scope = func;
			func = name;
			name = _isFunction;
		}
		var self = this, f = function f() {
			var prev = _context, prevSelector = self.selector, result;
			prev && prev !== self && prev.data.push(self);
			scope && (self.selector = selector(scope));
			_context = self;
			result = func.apply(self, arguments);
			_isFunction(result) && self._r.push(result);
			_context = prev;
			self.selector = prevSelector;
			self.isReverted = false;
			return result;
		};
		self.last = f;
		return name === _isFunction ? f(self, function(func) {
			return self.add(null, func);
		}) : name ? self[name] = f : f;
	};
	_proto5.ignore = function ignore(func) {
		var prev = _context;
		_context = null;
		func(this);
		_context = prev;
	};
	_proto5.getTweens = function getTweens() {
		var a = [];
		this.data.forEach(function(e) {
			return e instanceof Context ? a.push.apply(a, e.getTweens()) : e instanceof Tween && !(e.parent && e.parent.data === "nested") && a.push(e);
		});
		return a;
	};
	_proto5.clear = function clear() {
		this._r.length = this.data.length = 0;
	};
	_proto5.kill = function kill(revert, matchMedia) {
		var _this4 = this;
		if (revert) (function() {
			var tweens = _this4.getTweens(), i = _this4.data.length, t;
			while (i--) {
				t = _this4.data[i];
				if (t.data === "isFlip") {
					t.revert();
					t.getChildren(true, true, false).forEach(function(tween) {
						return tweens.splice(tweens.indexOf(tween), 1);
					});
				}
			}
			tweens.map(function(t) {
				return {
					g: t._dur || t._delay || t._sat && !t._sat.vars.immediateRender ? t.globalTime(0) : -Infinity,
					t
				};
			}).sort(function(a, b) {
				return b.g - a.g || -Infinity;
			}).forEach(function(o) {
				return o.t.revert(revert);
			});
			i = _this4.data.length;
			while (i--) {
				t = _this4.data[i];
				if (t instanceof Timeline) {
					if (t.data !== "nested") {
						t.scrollTrigger && t.scrollTrigger.revert();
						t.kill();
					}
				} else !(t instanceof Tween) && t.revert && t.revert(revert);
			}
			_this4._r.forEach(function(f) {
				return f(revert, _this4);
			});
			_this4.isReverted = true;
		})();
		else this.data.forEach(function(e) {
			return e.kill && e.kill();
		});
		this.clear();
		if (matchMedia) {
			var i = _media.length;
			while (i--) _media[i].id === this.id && _media.splice(i, 1);
		}
	};
	_proto5.revert = function revert(config) {
		this.kill(config || {});
	};
	return Context;
}();
var MatchMedia = /*#__PURE__*/ function() {
	function MatchMedia(scope) {
		this.contexts = [];
		this.scope = scope;
		_context && _context.data.push(this);
	}
	var _proto6 = MatchMedia.prototype;
	_proto6.add = function add(conditions, func, scope) {
		_isObject(conditions) || (conditions = { matches: conditions });
		var context = new Context(0, scope || this.scope), cond = context.conditions = {}, mq, p, active;
		_context && !context.selector && (context.selector = _context.selector);
		this.contexts.push(context);
		func = context.add("onMatch", func);
		context.queries = conditions;
		for (p in conditions) if (p === "all") active = 1;
		else {
			mq = _win$1.matchMedia(conditions[p]);
			if (mq) {
				_media.indexOf(context) < 0 && _media.push(context);
				(cond[p] = mq.matches) && (active = 1);
				mq.addListener ? mq.addListener(_onMediaChange) : mq.addEventListener("change", _onMediaChange);
			}
		}
		active && func(context, function(f) {
			return context.add(null, f);
		});
		return this;
	};
	_proto6.revert = function revert(config) {
		this.kill(config || {});
	};
	_proto6.kill = function kill(revert) {
		this.contexts.forEach(function(c) {
			return c.kill(revert, true);
		});
	};
	return MatchMedia;
}();
var _gsap = {
	registerPlugin: function registerPlugin() {
		for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) args[_key2] = arguments[_key2];
		args.forEach(function(config) {
			return _createPlugin(config);
		});
	},
	timeline: function timeline(vars) {
		return new Timeline(vars);
	},
	getTweensOf: function getTweensOf(targets, onlyActive) {
		return _globalTimeline.getTweensOf(targets, onlyActive);
	},
	getProperty: function getProperty(target, property, unit, uncache) {
		_isString(target) && (target = toArray(target)[0]);
		var getter = _getCache(target || {}).get, format = unit ? _passThrough : _numericIfPossible;
		unit === "native" && (unit = "");
		return !target ? target : !property ? function(property, unit, uncache) {
			return format((_plugins[property] && _plugins[property].get || getter)(target, property, unit, uncache));
		} : format((_plugins[property] && _plugins[property].get || getter)(target, property, unit, uncache));
	},
	quickSetter: function quickSetter(target, property, unit) {
		target = toArray(target);
		if (target.length > 1) {
			var setters = target.map(function(t) {
				return gsap.quickSetter(t, property, unit);
			}), l = setters.length;
			return function(value) {
				var i = l;
				while (i--) setters[i](value);
			};
		}
		target = target[0] || {};
		var Plugin = _plugins[property], cache = _getCache(target), p = cache.harness && (cache.harness.aliases || {})[property] || property, setter = Plugin ? function(value) {
			var p = new Plugin();
			_quickTween._pt = 0;
			p.init(target, unit ? value + unit : value, _quickTween, 0, [target]);
			p.render(1, p);
			_quickTween._pt && _renderPropTweens(1, _quickTween);
		} : cache.set(target, p);
		return Plugin ? setter : function(value) {
			return setter(target, p, unit ? value + unit : value, cache, 1);
		};
	},
	quickTo: function quickTo(target, property, vars) {
		var _setDefaults2;
		var tween = gsap.to(target, _setDefaults((_setDefaults2 = {}, _setDefaults2[property] = "+=0.1", _setDefaults2.paused = true, _setDefaults2.stagger = 0, _setDefaults2), vars || {})), func = function func(value, start, startIsRelative) {
			return tween.resetTo(property, value, start, startIsRelative);
		};
		func.tween = tween;
		return func;
	},
	isTweening: function isTweening(targets) {
		return _globalTimeline.getTweensOf(targets, true).length > 0;
	},
	defaults: function defaults(value) {
		value && value.ease && (value.ease = _parseEase(value.ease, _defaults.ease));
		return _mergeDeep(_defaults, value || {});
	},
	config: function config(value) {
		return _mergeDeep(_config, value || {});
	},
	registerEffect: function registerEffect(_ref3) {
		var name = _ref3.name, effect = _ref3.effect, plugins = _ref3.plugins, defaults = _ref3.defaults, extendTimeline = _ref3.extendTimeline;
		(plugins || "").split(",").forEach(function(pluginName) {
			return pluginName && !_plugins[pluginName] && !_globals[pluginName] && _warn(name + " effect requires " + pluginName + " plugin.");
		});
		_effects[name] = function(targets, vars, tl) {
			return effect(toArray(targets), _setDefaults(vars || {}, defaults), tl);
		};
		if (extendTimeline) Timeline.prototype[name] = function(targets, vars, position) {
			return this.add(_effects[name](targets, _isObject(vars) ? vars : (position = vars) && {}, this), position);
		};
	},
	registerEase: function registerEase(name, ease) {
		_easeMap[name] = _parseEase(ease);
	},
	parseEase: function parseEase(ease, defaultEase) {
		return arguments.length ? _parseEase(ease, defaultEase) : _easeMap;
	},
	getById: function getById(id) {
		return _globalTimeline.getById(id);
	},
	exportRoot: function exportRoot(vars, includeDelayedCalls) {
		if (vars === void 0) vars = {};
		var tl = new Timeline(vars), child, next;
		tl.smoothChildTiming = _isNotFalse(vars.smoothChildTiming);
		_globalTimeline.remove(tl);
		tl._dp = 0;
		tl._time = tl._tTime = _globalTimeline._time;
		child = _globalTimeline._first;
		while (child) {
			next = child._next;
			if (includeDelayedCalls || !(!child._dur && child instanceof Tween && child.vars.onComplete === child._targets[0])) _addToTimeline(tl, child, child._start - child._delay);
			child = next;
		}
		_addToTimeline(_globalTimeline, tl, 0);
		return tl;
	},
	context: function context(func, scope) {
		return func ? new Context(func, scope) : _context;
	},
	matchMedia: function matchMedia(scope) {
		return new MatchMedia(scope);
	},
	matchMediaRefresh: function matchMediaRefresh() {
		return _media.forEach(function(c) {
			var cond = c.conditions, found, p;
			for (p in cond) if (cond[p]) {
				cond[p] = false;
				found = 1;
			}
			found && c.revert();
		}) || _onMediaChange();
	},
	addEventListener: function addEventListener(type, callback) {
		var a = _listeners[type] || (_listeners[type] = []);
		~a.indexOf(callback) || a.push(callback);
	},
	removeEventListener: function removeEventListener(type, callback) {
		var a = _listeners[type], i = a && a.indexOf(callback);
		i >= 0 && a.splice(i, 1);
	},
	utils: {
		wrap,
		wrapYoyo,
		distribute,
		random,
		snap,
		normalize,
		getUnit,
		clamp,
		splitColor,
		toArray,
		selector,
		mapRange,
		pipe,
		unitize,
		interpolate,
		shuffle
	},
	install: _install,
	effects: _effects,
	ticker: _ticker,
	updateRoot: Timeline.updateRoot,
	plugins: _plugins,
	globalTimeline: _globalTimeline,
	core: {
		PropTween,
		globals: _addGlobal,
		Tween,
		Timeline,
		Animation,
		getCache: _getCache,
		_removeLinkedListItem,
		reverting: function reverting() {
			return _reverting$1;
		},
		context: function context(toAdd) {
			if (toAdd && _context) {
				_context.data.push(toAdd);
				toAdd._ctx = _context;
			}
			return _context;
		},
		suppressOverwrites: function suppressOverwrites(value) {
			return _suppressOverwrites = value;
		}
	}
};
_forEachName("to,from,fromTo,delayedCall,set,killTweensOf", function(name) {
	return _gsap[name] = Tween[name];
});
_ticker.add(Timeline.updateRoot);
_quickTween = _gsap.to({}, { duration: 0 });
var _getPluginPropTween = function _getPluginPropTween(plugin, prop) {
	var pt = plugin._pt;
	while (pt && pt.p !== prop && pt.op !== prop && pt.fp !== prop) pt = pt._next;
	return pt;
};
var _addModifiers = function _addModifiers(tween, modifiers) {
	var targets = tween._targets, p, i, pt;
	for (p in modifiers) {
		i = targets.length;
		while (i--) {
			pt = tween._ptLookup[i][p];
			if (pt && (pt = pt.d)) {
				if (pt._pt) pt = _getPluginPropTween(pt, p);
				pt && pt.modifier && pt.modifier(modifiers[p], tween, targets[i], p);
			}
		}
	}
};
var _buildModifierPlugin = function _buildModifierPlugin(name, modifier) {
	return {
		name,
		headless: 1,
		rawVars: 1,
		init: function init(target, vars, tween) {
			tween._onInit = function(tween) {
				var temp, p;
				if (_isString(vars)) {
					temp = {};
					_forEachName(vars, function(name) {
						return temp[name] = 1;
					});
					vars = temp;
				}
				if (modifier) {
					temp = {};
					for (p in vars) temp[p] = modifier(vars[p]);
					vars = temp;
				}
				_addModifiers(tween, vars);
			};
		}
	};
};
var gsap = _gsap.registerPlugin({
	name: "attr",
	init: function init(target, vars, tween, index, targets) {
		var p, pt, v;
		this.tween = tween;
		for (p in vars) {
			v = target.getAttribute(p) || "";
			pt = this.add(target, "setAttribute", (v || 0) + "", vars[p], index, targets, 0, 0, p);
			pt.op = p;
			pt.b = v;
			this._props.push(p);
		}
	},
	render: function render(ratio, data) {
		var pt = data._pt;
		while (pt) {
			_reverting$1 ? pt.set(pt.t, pt.p, pt.b, pt) : pt.r(ratio, pt.d);
			pt = pt._next;
		}
	}
}, {
	name: "endArray",
	headless: 1,
	init: function init(target, value) {
		var i = value.length;
		while (i--) this.add(target, i, target[i] || 0, value[i], 0, 0, 0, 0, 0, 1);
	}
}, _buildModifierPlugin("roundProps", _roundModifier), _buildModifierPlugin("modifiers"), _buildModifierPlugin("snap", snap)) || _gsap;
Tween.version = Timeline.version = gsap.version = "3.15.0";
_coreReady = 1;
_windowExists$1() && _wake();
var Power0 = _easeMap.Power0;
var Power1 = _easeMap.Power1;
var Power2 = _easeMap.Power2;
var Power3 = _easeMap.Power3;
var Power4 = _easeMap.Power4;
var Linear = _easeMap.Linear;
var Quad = _easeMap.Quad;
var Cubic = _easeMap.Cubic;
var Quart = _easeMap.Quart;
var Quint = _easeMap.Quint;
var Strong = _easeMap.Strong;
var Elastic = _easeMap.Elastic;
var Back = _easeMap.Back;
var SteppedEase = _easeMap.SteppedEase;
var Bounce = _easeMap.Bounce;
var Sine = _easeMap.Sine;
var Expo = _easeMap.Expo;
var Circ = _easeMap.Circ;
//#endregion
//#region node_modules/gsap/CSSPlugin.js
/*!
* CSSPlugin 3.15.0
* https://gsap.com
*
* Copyright 2008-2026, GreenSock. All rights reserved.
* Subject to the terms at https://gsap.com/standard-license
* @author: Jack Doyle, jack@greensock.com
*/
var _win;
var _doc;
var _docElement;
var _pluginInitted;
var _tempDiv;
var _recentSetterPlugin;
var _reverting;
var _windowExists = function _windowExists() {
	return typeof window !== "undefined";
};
var _transformProps = {};
var _RAD2DEG = 180 / Math.PI;
var _DEG2RAD = Math.PI / 180;
var _atan2 = Math.atan2;
var _bigNum = 1e8;
var _capsExp = /([A-Z])/g;
var _horizontalExp = /(left|right|width|margin|padding|x)/i;
var _complexExp = /[\s,\(]\S/;
var _propertyAliases = {
	autoAlpha: "opacity,visibility",
	scale: "scaleX,scaleY",
	alpha: "opacity"
};
var _renderCSSProp = function _renderCSSProp(ratio, data) {
	return data.set(data.t, data.p, Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u, data);
};
var _renderPropWithEnd = function _renderPropWithEnd(ratio, data) {
	return data.set(data.t, data.p, ratio === 1 ? data.e : Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u, data);
};
var _renderCSSPropWithBeginning = function _renderCSSPropWithBeginning(ratio, data) {
	return data.set(data.t, data.p, ratio ? Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u : data.b, data);
};
var _renderCSSPropWithBeginningAndEnd = function _renderCSSPropWithBeginningAndEnd(ratio, data) {
	return data.set(data.t, data.p, ratio === 1 ? data.e : ratio ? Math.round((data.s + data.c * ratio) * 1e4) / 1e4 + data.u : data.b, data);
};
var _renderRoundedCSSProp = function _renderRoundedCSSProp(ratio, data) {
	var value = data.s + data.c * ratio;
	data.set(data.t, data.p, ~~(value + (value < 0 ? -.5 : .5)) + data.u, data);
};
var _renderNonTweeningValue = function _renderNonTweeningValue(ratio, data) {
	return data.set(data.t, data.p, ratio ? data.e : data.b, data);
};
var _renderNonTweeningValueOnlyAtEnd = function _renderNonTweeningValueOnlyAtEnd(ratio, data) {
	return data.set(data.t, data.p, ratio !== 1 ? data.b : data.e, data);
};
var _setterCSSStyle = function _setterCSSStyle(target, property, value) {
	return target.style[property] = value;
};
var _setterCSSProp = function _setterCSSProp(target, property, value) {
	return target.style.setProperty(property, value);
};
var _setterTransform = function _setterTransform(target, property, value) {
	return target._gsap[property] = value;
};
var _setterScale = function _setterScale(target, property, value) {
	return target._gsap.scaleX = target._gsap.scaleY = value;
};
var _setterScaleWithRender = function _setterScaleWithRender(target, property, value, data, ratio) {
	var cache = target._gsap;
	cache.scaleX = cache.scaleY = value;
	cache.renderTransform(ratio, cache);
};
var _setterTransformWithRender = function _setterTransformWithRender(target, property, value, data, ratio) {
	var cache = target._gsap;
	cache[property] = value;
	cache.renderTransform(ratio, cache);
};
var _transformProp = "transform";
var _transformOriginProp = _transformProp + "Origin";
var _saveStyle = function _saveStyle(property, isNotCSS) {
	var _this = this;
	var target = this.target, style = target.style, cache = target._gsap;
	if (property in _transformProps && style) {
		this.tfm = this.tfm || {};
		if (property !== "transform") {
			property = _propertyAliases[property] || property;
			~property.indexOf(",") ? property.split(",").forEach(function(a) {
				return _this.tfm[a] = _get(target, a);
			}) : this.tfm[property] = cache.x ? cache[property] : _get(target, property);
			property === _transformOriginProp && (this.tfm.zOrigin = cache.zOrigin);
		} else return _propertyAliases.transform.split(",").forEach(function(p) {
			return _saveStyle.call(_this, p, isNotCSS);
		});
		if (this.props.indexOf(_transformProp) >= 0) return;
		if (cache.svg) {
			this.svgo = target.getAttribute("data-svg-origin");
			this.props.push(_transformOriginProp, isNotCSS, "");
		}
		property = _transformProp;
	}
	(style || isNotCSS) && this.props.push(property, isNotCSS, style[property]);
};
var _removeIndependentTransforms = function _removeIndependentTransforms(style) {
	if (style.translate) {
		style.removeProperty("translate");
		style.removeProperty("scale");
		style.removeProperty("rotate");
	}
};
var _revertStyle = function _revertStyle() {
	var props = this.props, target = this.target, style = target.style, cache = target._gsap, i, p;
	for (i = 0; i < props.length; i += 3) if (!props[i + 1]) props[i + 2] ? style[props[i]] = props[i + 2] : style.removeProperty(props[i].substr(0, 2) === "--" ? props[i] : props[i].replace(_capsExp, "-$1").toLowerCase());
	else if (props[i + 1] === 2) target[props[i]](props[i + 2]);
	else target[props[i]] = props[i + 2];
	if (this.tfm) {
		for (p in this.tfm) cache[p] = this.tfm[p];
		if (cache.svg) {
			cache.renderTransform();
			target.setAttribute("data-svg-origin", this.svgo || "");
		}
		i = _reverting();
		if ((!i || !i.isStart) && !style[_transformProp]) {
			_removeIndependentTransforms(style);
			if (cache.zOrigin && style[_transformOriginProp]) {
				style[_transformOriginProp] += " " + cache.zOrigin + "px";
				cache.zOrigin = 0;
				cache.renderTransform();
			}
			cache.uncache = 1;
		}
	}
};
var _getStyleSaver = function _getStyleSaver(target, properties) {
	var saver = {
		target,
		props: [],
		revert: _revertStyle,
		save: _saveStyle
	};
	target._gsap || gsap.core.getCache(target);
	properties && target.style && target.nodeType && properties.split(",").forEach(function(p) {
		return saver.save(p);
	});
	return saver;
};
var _supports3D;
var _createElement = function _createElement(type, ns) {
	var e = _doc.createElementNS ? _doc.createElementNS((ns || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), type) : _doc.createElement(type);
	return e && e.style ? e : _doc.createElement(type);
};
var _getComputedProperty = function _getComputedProperty(target, property, skipPrefixFallback) {
	var cs = getComputedStyle(target);
	return cs[property] || cs.getPropertyValue(property.replace(_capsExp, "-$1").toLowerCase()) || cs.getPropertyValue(property) || !skipPrefixFallback && _getComputedProperty(target, _checkPropPrefix(property) || property, 1) || "";
};
var _prefixes = "O,Moz,ms,Ms,Webkit".split(",");
var _checkPropPrefix = function _checkPropPrefix(property, element, preferPrefix) {
	var s = (element || _tempDiv).style, i = 5;
	if (property in s && !preferPrefix) return property;
	property = property.charAt(0).toUpperCase() + property.substr(1);
	while (i-- && !(_prefixes[i] + property in s));
	return i < 0 ? null : (i === 3 ? "ms" : i >= 0 ? _prefixes[i] : "") + property;
};
var _initCore = function _initCore() {
	if (_windowExists() && window.document) {
		_win = window;
		_doc = _win.document;
		_docElement = _doc.documentElement;
		_tempDiv = _createElement("div") || { style: {} };
		_createElement("div");
		_transformProp = _checkPropPrefix(_transformProp);
		_transformOriginProp = _transformProp + "Origin";
		_tempDiv.style.cssText = "border-width:0;line-height:0;position:absolute;padding:0";
		_supports3D = !!_checkPropPrefix("perspective");
		_reverting = gsap.core.reverting;
		_pluginInitted = 1;
	}
};
var _getReparentedCloneBBox = function _getReparentedCloneBBox(target) {
	var owner = target.ownerSVGElement, svg = _createElement("svg", owner && owner.getAttribute("xmlns") || "http://www.w3.org/2000/svg"), clone = target.cloneNode(true), bbox;
	clone.style.display = "block";
	svg.appendChild(clone);
	_docElement.appendChild(svg);
	try {
		bbox = clone.getBBox();
	} catch (e) {}
	svg.removeChild(clone);
	_docElement.removeChild(svg);
	return bbox;
};
var _getAttributeFallbacks = function _getAttributeFallbacks(target, attributesArray) {
	var i = attributesArray.length;
	while (i--) if (target.hasAttribute(attributesArray[i])) return target.getAttribute(attributesArray[i]);
};
var _getBBox = function _getBBox(target) {
	var bounds, cloned;
	try {
		bounds = target.getBBox();
	} catch (error) {
		bounds = _getReparentedCloneBBox(target);
		cloned = 1;
	}
	bounds && (bounds.width || bounds.height) || cloned || (bounds = _getReparentedCloneBBox(target));
	return bounds && !bounds.width && !bounds.x && !bounds.y ? {
		x: +_getAttributeFallbacks(target, [
			"x",
			"cx",
			"x1"
		]) || 0,
		y: +_getAttributeFallbacks(target, [
			"y",
			"cy",
			"y1"
		]) || 0,
		width: 0,
		height: 0
	} : bounds;
};
var _isSVG = function _isSVG(e) {
	return !!(e.getCTM && (!e.parentNode || e.ownerSVGElement) && _getBBox(e));
};
var _removeProperty = function _removeProperty(target, property) {
	if (property) {
		var style = target.style, first2Chars;
		if (property in _transformProps && property !== _transformOriginProp) property = _transformProp;
		if (style.removeProperty) {
			first2Chars = property.substr(0, 2);
			if (first2Chars === "ms" || property.substr(0, 6) === "webkit") property = "-" + property;
			style.removeProperty(first2Chars === "--" ? property : property.replace(_capsExp, "-$1").toLowerCase());
		} else style.removeAttribute(property);
	}
};
var _addNonTweeningPT = function _addNonTweeningPT(plugin, target, property, beginning, end, onlySetAtEnd) {
	var pt = new PropTween(plugin._pt, target, property, 0, 1, onlySetAtEnd ? _renderNonTweeningValueOnlyAtEnd : _renderNonTweeningValue);
	plugin._pt = pt;
	pt.b = beginning;
	pt.e = end;
	plugin._props.push(property);
	return pt;
};
var _nonConvertibleUnits = {
	deg: 1,
	rad: 1,
	turn: 1
};
var _nonStandardLayouts = {
	grid: 1,
	flex: 1
};
var _convertToUnit = function _convertToUnit(target, property, value, unit) {
	var curValue = parseFloat(value) || 0, curUnit = (value + "").trim().substr((curValue + "").length) || "px", style = _tempDiv.style, horizontal = _horizontalExp.test(property), isRootSVG = target.tagName.toLowerCase() === "svg", measureProperty = (isRootSVG ? "client" : "offset") + (horizontal ? "Width" : "Height"), amount = 100, toPixels = unit === "px", toPercent = unit === "%", px, parent, cache, isSVG;
	if (unit === curUnit || !curValue || _nonConvertibleUnits[unit] || _nonConvertibleUnits[curUnit]) return curValue;
	curUnit !== "px" && !toPixels && (curValue = _convertToUnit(target, property, value, "px"));
	isSVG = target.getCTM && _isSVG(target);
	if ((toPercent || curUnit === "%") && (_transformProps[property] || ~property.indexOf("adius"))) {
		px = isSVG ? target.getBBox()[horizontal ? "width" : "height"] : target[measureProperty];
		return _round(toPercent ? curValue / px * amount : curValue / 100 * px);
	}
	style[horizontal ? "width" : "height"] = amount + (toPixels ? curUnit : unit);
	parent = unit !== "rem" && ~property.indexOf("adius") || unit === "em" && target.appendChild && !isRootSVG ? target : target.parentNode;
	if (isSVG) parent = (target.ownerSVGElement || {}).parentNode;
	if (!parent || parent === _doc || !parent.appendChild) parent = _doc.body;
	cache = parent._gsap;
	if (cache && toPercent && cache.width && horizontal && cache.time === _ticker.time && !cache.uncache) return _round(curValue / cache.width * amount);
	else {
		if (toPercent && (property === "height" || property === "width")) {
			var v = target.style[property];
			target.style[property] = amount + unit;
			px = target[measureProperty];
			v ? target.style[property] = v : _removeProperty(target, property);
		} else {
			(toPercent || curUnit === "%") && !_nonStandardLayouts[_getComputedProperty(parent, "display")] && (style.position = _getComputedProperty(target, "position"));
			parent === target && (style.position = "static");
			parent.appendChild(_tempDiv);
			px = _tempDiv[measureProperty];
			parent.removeChild(_tempDiv);
			style.position = "absolute";
		}
		if (horizontal && toPercent) {
			cache = _getCache(parent);
			cache.time = _ticker.time;
			cache.width = parent[measureProperty];
		}
	}
	return _round(toPixels ? px * curValue / amount : px && curValue ? amount / px * curValue : 0);
};
var _get = function _get(target, property, unit, uncache) {
	var value;
	_pluginInitted || _initCore();
	if (property in _propertyAliases && property !== "transform") {
		property = _propertyAliases[property];
		if (~property.indexOf(",")) property = property.split(",")[0];
	}
	if (_transformProps[property] && property !== "transform") {
		value = _parseTransform(target, uncache);
		value = property !== "transformOrigin" ? value[property] : value.svg ? value.origin : _firstTwoOnly(_getComputedProperty(target, _transformOriginProp)) + " " + value.zOrigin + "px";
	} else {
		value = target.style[property];
		if (!value || value === "auto" || uncache || ~(value + "").indexOf("calc(")) value = _specialProps[property] && _specialProps[property](target, property, unit) || _getComputedProperty(target, property) || _getProperty(target, property) || (property === "opacity" ? 1 : 0);
	}
	return unit && !~(value + "").trim().indexOf(" ") ? _convertToUnit(target, property, value, unit) + unit : value;
};
var _tweenComplexCSSString = function _tweenComplexCSSString(target, prop, start, end) {
	if (!start || start === "none") {
		var p = _checkPropPrefix(prop, target, 1), s = p && _getComputedProperty(target, p, 1);
		if (s && s !== start) {
			prop = p;
			start = s;
		} else if (prop === "borderColor") start = _getComputedProperty(target, "borderTopColor");
	}
	var pt = new PropTween(this._pt, target.style, prop, 0, 1, _renderComplexString), index = 0, matchIndex = 0, a, result, startValues, startNum, color, startValue, endValue, endNum, chunk, endUnit, startUnit, endValues;
	pt.b = start;
	pt.e = end;
	start += "";
	end += "";
	if (end.substring(0, 6) === "var(--") end = _getComputedProperty(target, end.substring(4, end.indexOf(")")));
	if (end === "auto") {
		startValue = target.style[prop];
		target.style[prop] = end;
		end = _getComputedProperty(target, prop) || end;
		startValue ? target.style[prop] = startValue : _removeProperty(target, prop);
	}
	a = [start, end];
	_colorStringFilter(a);
	start = a[0];
	end = a[1];
	startValues = start.match(_numWithUnitExp) || [];
	endValues = end.match(_numWithUnitExp) || [];
	if (endValues.length) {
		while (result = _numWithUnitExp.exec(end)) {
			endValue = result[0];
			chunk = end.substring(index, result.index);
			if (color) color = (color + 1) % 5;
			else if (chunk.substr(-5) === "rgba(" || chunk.substr(-5) === "hsla(") color = 1;
			if (endValue !== (startValue = startValues[matchIndex++] || "")) {
				startNum = parseFloat(startValue) || 0;
				startUnit = startValue.substr((startNum + "").length);
				endValue.charAt(1) === "=" && (endValue = _parseRelative(startNum, endValue) + startUnit);
				endNum = parseFloat(endValue);
				endUnit = endValue.substr((endNum + "").length);
				index = _numWithUnitExp.lastIndex - endUnit.length;
				if (!endUnit) {
					endUnit = endUnit || _config.units[prop] || startUnit;
					if (index === end.length) {
						end += endUnit;
						pt.e += endUnit;
					}
				}
				if (startUnit !== endUnit) startNum = _convertToUnit(target, prop, startValue, endUnit) || 0;
				pt._pt = {
					_next: pt._pt,
					p: chunk || matchIndex === 1 ? chunk : ",",
					s: startNum,
					c: endNum - startNum,
					m: color && color < 4 || prop === "zIndex" ? Math.round : 0
				};
			}
		}
		pt.c = index < end.length ? end.substring(index, end.length) : "";
	} else pt.r = prop === "display" && end === "none" ? _renderNonTweeningValueOnlyAtEnd : _renderNonTweeningValue;
	_relExp.test(end) && (pt.e = 0);
	this._pt = pt;
	return pt;
};
var _keywordToPercent = {
	top: "0%",
	bottom: "100%",
	left: "0%",
	right: "100%",
	center: "50%"
};
var _convertKeywordsToPercentages = function _convertKeywordsToPercentages(value) {
	var split = value.split(" "), x = split[0], y = split[1] || "50%";
	if (x === "top" || x === "bottom" || y === "left" || y === "right") {
		value = x;
		x = y;
		y = value;
	}
	split[0] = _keywordToPercent[x] || x;
	split[1] = _keywordToPercent[y] || y;
	return split.join(" ");
};
var _renderClearProps = function _renderClearProps(ratio, data) {
	if (data.tween && data.tween._time === data.tween._dur) {
		var target = data.t, style = target.style, props = data.u, cache = target._gsap, prop, clearTransforms, i;
		if (props === "all" || props === true) {
			style.cssText = "";
			clearTransforms = 1;
		} else {
			props = props.split(",");
			i = props.length;
			while (--i > -1) {
				prop = props[i];
				if (_transformProps[prop]) {
					clearTransforms = 1;
					prop = prop === "transformOrigin" ? _transformOriginProp : _transformProp;
				}
				_removeProperty(target, prop);
			}
		}
		if (clearTransforms) {
			_removeProperty(target, _transformProp);
			if (cache) {
				cache.svg && target.removeAttribute("transform");
				style.scale = style.rotate = style.translate = "none";
				_parseTransform(target, 1);
				cache.uncache = 1;
				_removeIndependentTransforms(style);
			}
		}
	}
};
var _specialProps = { clearProps: function clearProps(plugin, target, property, endValue, tween) {
	if (tween.data !== "isFromStart") {
		var pt = plugin._pt = new PropTween(plugin._pt, target, property, 0, 0, _renderClearProps);
		pt.u = endValue;
		pt.pr = -10;
		pt.tween = tween;
		plugin._props.push(property);
		return 1;
	}
} };
var _identity2DMatrix = [
	1,
	0,
	0,
	1,
	0,
	0
];
var _rotationalProperties = {};
var _isNullTransform = function _isNullTransform(value) {
	return value === "matrix(1, 0, 0, 1, 0, 0)" || value === "none" || !value;
};
var _getComputedTransformMatrixAsArray = function _getComputedTransformMatrixAsArray(target) {
	var matrixString = _getComputedProperty(target, _transformProp);
	return _isNullTransform(matrixString) ? _identity2DMatrix : matrixString.substr(7).match(_numExp).map(_round);
};
var _getMatrix = function _getMatrix(target, force2D) {
	var cache = target._gsap || _getCache(target), style = target.style, matrix = _getComputedTransformMatrixAsArray(target), parent, nextSibling, temp, addedToDOM;
	if (cache.svg && target.getAttribute("transform")) {
		temp = target.transform.baseVal.consolidate().matrix;
		matrix = [
			temp.a,
			temp.b,
			temp.c,
			temp.d,
			temp.e,
			temp.f
		];
		return matrix.join(",") === "1,0,0,1,0,0" ? _identity2DMatrix : matrix;
	} else if (matrix === _identity2DMatrix && !target.offsetParent && target !== _docElement && !cache.svg) {
		temp = style.display;
		style.display = "block";
		parent = target.parentNode;
		if (!parent || !target.offsetParent && !target.getBoundingClientRect().width) {
			addedToDOM = 1;
			nextSibling = target.nextElementSibling;
			_docElement.appendChild(target);
		}
		matrix = _getComputedTransformMatrixAsArray(target);
		temp ? style.display = temp : _removeProperty(target, "display");
		if (addedToDOM) nextSibling ? parent.insertBefore(target, nextSibling) : parent ? parent.appendChild(target) : _docElement.removeChild(target);
	}
	return force2D && matrix.length > 6 ? [
		matrix[0],
		matrix[1],
		matrix[4],
		matrix[5],
		matrix[12],
		matrix[13]
	] : matrix;
};
var _applySVGOrigin = function _applySVGOrigin(target, origin, originIsAbsolute, smooth, matrixArray, pluginToAddPropTweensTo) {
	var cache = target._gsap, matrix = matrixArray || _getMatrix(target, true), xOriginOld = cache.xOrigin || 0, yOriginOld = cache.yOrigin || 0, xOffsetOld = cache.xOffset || 0, yOffsetOld = cache.yOffset || 0, a = matrix[0], b = matrix[1], c = matrix[2], d = matrix[3], tx = matrix[4], ty = matrix[5], originSplit = origin.split(" "), xOrigin = parseFloat(originSplit[0]) || 0, yOrigin = parseFloat(originSplit[1]) || 0, bounds, determinant, x, y;
	if (!originIsAbsolute) {
		bounds = _getBBox(target);
		xOrigin = bounds.x + (~originSplit[0].indexOf("%") ? xOrigin / 100 * bounds.width : xOrigin);
		yOrigin = bounds.y + (~(originSplit[1] || originSplit[0]).indexOf("%") ? yOrigin / 100 * bounds.height : yOrigin);
	} else if (matrix !== _identity2DMatrix && (determinant = a * d - b * c)) {
		x = xOrigin * (d / determinant) + yOrigin * (-c / determinant) + (c * ty - d * tx) / determinant;
		y = xOrigin * (-b / determinant) + yOrigin * (a / determinant) - (a * ty - b * tx) / determinant;
		xOrigin = x;
		yOrigin = y;
	}
	if (smooth || smooth !== false && cache.smooth) {
		tx = xOrigin - xOriginOld;
		ty = yOrigin - yOriginOld;
		cache.xOffset = xOffsetOld + (tx * a + ty * c) - tx;
		cache.yOffset = yOffsetOld + (tx * b + ty * d) - ty;
	} else cache.xOffset = cache.yOffset = 0;
	cache.xOrigin = xOrigin;
	cache.yOrigin = yOrigin;
	cache.smooth = !!smooth;
	cache.origin = origin;
	cache.originIsAbsolute = !!originIsAbsolute;
	target.style[_transformOriginProp] = "0px 0px";
	if (pluginToAddPropTweensTo) {
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "xOrigin", xOriginOld, xOrigin);
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "yOrigin", yOriginOld, yOrigin);
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "xOffset", xOffsetOld, cache.xOffset);
		_addNonTweeningPT(pluginToAddPropTweensTo, cache, "yOffset", yOffsetOld, cache.yOffset);
	}
	target.setAttribute("data-svg-origin", xOrigin + " " + yOrigin);
};
var _parseTransform = function _parseTransform(target, uncache) {
	var cache = target._gsap || new GSCache(target);
	if ("x" in cache && !uncache && !cache.uncache) return cache;
	var style = target.style, invertedScaleX = cache.scaleX < 0, px = "px", deg = "deg", cs = getComputedStyle(target), origin = _getComputedProperty(target, _transformOriginProp) || "0", x = y = z = rotation = rotationX = rotationY = skewX = skewY = perspective = 0, y, z, scaleX = scaleY = 1, scaleY, rotation, rotationX, rotationY, skewX, skewY, perspective, xOrigin, yOrigin, matrix, angle, cos, sin, a, b, c, d, a12, a22, t1, t2, t3, a13, a23, a33, a42, a43, a32;
	cache.svg = !!(target.getCTM && _isSVG(target));
	if (cs.translate) {
		if (cs.translate !== "none" || cs.scale !== "none" || cs.rotate !== "none") style[_transformProp] = (cs.translate !== "none" ? "translate3d(" + (cs.translate + " 0 0").split(" ").slice(0, 3).join(", ") + ") " : "") + (cs.rotate !== "none" ? "rotate(" + cs.rotate + ") " : "") + (cs.scale !== "none" ? "scale(" + cs.scale.split(" ").join(",") + ") " : "") + (cs[_transformProp] !== "none" ? cs[_transformProp] : "");
		style.scale = style.rotate = style.translate = "none";
	}
	matrix = _getMatrix(target, cache.svg);
	if (cache.svg) {
		if (cache.uncache) {
			t2 = target.getBBox();
			origin = cache.xOrigin - t2.x + "px " + (cache.yOrigin - t2.y) + "px";
			t1 = "";
		} else t1 = !uncache && target.getAttribute("data-svg-origin");
		_applySVGOrigin(target, t1 || origin, !!t1 || cache.originIsAbsolute, cache.smooth !== false, matrix);
	}
	xOrigin = cache.xOrigin || 0;
	yOrigin = cache.yOrigin || 0;
	if (matrix !== _identity2DMatrix) {
		a = matrix[0];
		b = matrix[1];
		c = matrix[2];
		d = matrix[3];
		x = a12 = matrix[4];
		y = a22 = matrix[5];
		if (matrix.length === 6) {
			scaleX = Math.sqrt(a * a + b * b);
			scaleY = Math.sqrt(d * d + c * c);
			rotation = a || b ? _atan2(b, a) * _RAD2DEG : 0;
			skewX = c || d ? _atan2(c, d) * _RAD2DEG + rotation : 0;
			skewX && (scaleY *= Math.abs(Math.cos(skewX * _DEG2RAD)));
			if (cache.svg) {
				x -= xOrigin - (xOrigin * a + yOrigin * c);
				y -= yOrigin - (xOrigin * b + yOrigin * d);
			}
		} else {
			a32 = matrix[6];
			a42 = matrix[7];
			a13 = matrix[8];
			a23 = matrix[9];
			a33 = matrix[10];
			a43 = matrix[11];
			x = matrix[12];
			y = matrix[13];
			z = matrix[14];
			angle = _atan2(a32, a33);
			rotationX = angle * _RAD2DEG;
			if (angle) {
				cos = Math.cos(-angle);
				sin = Math.sin(-angle);
				t1 = a12 * cos + a13 * sin;
				t2 = a22 * cos + a23 * sin;
				t3 = a32 * cos + a33 * sin;
				a13 = a12 * -sin + a13 * cos;
				a23 = a22 * -sin + a23 * cos;
				a33 = a32 * -sin + a33 * cos;
				a43 = a42 * -sin + a43 * cos;
				a12 = t1;
				a22 = t2;
				a32 = t3;
			}
			angle = _atan2(-c, a33);
			rotationY = angle * _RAD2DEG;
			if (angle) {
				cos = Math.cos(-angle);
				sin = Math.sin(-angle);
				t1 = a * cos - a13 * sin;
				t2 = b * cos - a23 * sin;
				t3 = c * cos - a33 * sin;
				a43 = d * sin + a43 * cos;
				a = t1;
				b = t2;
				c = t3;
			}
			angle = _atan2(b, a);
			rotation = angle * _RAD2DEG;
			if (angle) {
				cos = Math.cos(angle);
				sin = Math.sin(angle);
				t1 = a * cos + b * sin;
				t2 = a12 * cos + a22 * sin;
				b = b * cos - a * sin;
				a22 = a22 * cos - a12 * sin;
				a = t1;
				a12 = t2;
			}
			if (rotationX && Math.abs(rotationX) + Math.abs(rotation) > 359.9) {
				rotationX = rotation = 0;
				rotationY = 180 - rotationY;
			}
			scaleX = _round(Math.sqrt(a * a + b * b + c * c));
			scaleY = _round(Math.sqrt(a22 * a22 + a32 * a32));
			angle = _atan2(a12, a22);
			skewX = Math.abs(angle) > 2e-4 ? angle * _RAD2DEG : 0;
			perspective = a43 ? 1 / (a43 < 0 ? -a43 : a43) : 0;
		}
		if (cache.svg) {
			t1 = target.getAttribute("transform");
			cache.forceCSS = target.setAttribute("transform", "") || !_isNullTransform(_getComputedProperty(target, _transformProp));
			t1 && target.setAttribute("transform", t1);
		}
	}
	if (Math.abs(skewX) > 90 && Math.abs(skewX) < 270) if (invertedScaleX) {
		scaleX *= -1;
		skewX += rotation <= 0 ? 180 : -180;
		rotation += rotation <= 0 ? 180 : -180;
	} else {
		scaleY *= -1;
		skewX += skewX <= 0 ? 180 : -180;
	}
	uncache = uncache || cache.uncache;
	cache.x = x - ((cache.xPercent = x && (!uncache && cache.xPercent || (Math.round(target.offsetWidth / 2) === Math.round(-x) ? -50 : 0))) ? target.offsetWidth * cache.xPercent / 100 : 0) + px;
	cache.y = y - ((cache.yPercent = y && (!uncache && cache.yPercent || (Math.round(target.offsetHeight / 2) === Math.round(-y) ? -50 : 0))) ? target.offsetHeight * cache.yPercent / 100 : 0) + px;
	cache.z = z + px;
	cache.scaleX = _round(scaleX);
	cache.scaleY = _round(scaleY);
	cache.rotation = _round(rotation) + deg;
	cache.rotationX = _round(rotationX) + deg;
	cache.rotationY = _round(rotationY) + deg;
	cache.skewX = skewX + deg;
	cache.skewY = skewY + deg;
	cache.transformPerspective = perspective + px;
	if (cache.zOrigin = parseFloat(origin.split(" ")[2]) || !uncache && cache.zOrigin || 0) style[_transformOriginProp] = _firstTwoOnly(origin);
	cache.xOffset = cache.yOffset = 0;
	cache.force3D = _config.force3D;
	cache.renderTransform = cache.svg ? _renderSVGTransforms : _supports3D ? _renderCSSTransforms : _renderNon3DTransforms;
	cache.uncache = 0;
	return cache;
};
var _firstTwoOnly = function _firstTwoOnly(value) {
	return (value = value.split(" "))[0] + " " + value[1];
};
var _addPxTranslate = function _addPxTranslate(target, start, value) {
	var unit = getUnit(start);
	return _round(parseFloat(start) + parseFloat(_convertToUnit(target, "x", value + "px", unit))) + unit;
};
var _renderNon3DTransforms = function _renderNon3DTransforms(ratio, cache) {
	cache.z = "0px";
	cache.rotationY = cache.rotationX = "0deg";
	cache.force3D = 0;
	_renderCSSTransforms(ratio, cache);
};
var _zeroDeg = "0deg";
var _zeroPx = "0px";
var _endParenthesis = ") ";
var _renderCSSTransforms = function _renderCSSTransforms(ratio, cache) {
	var _ref = cache || this, xPercent = _ref.xPercent, yPercent = _ref.yPercent, x = _ref.x, y = _ref.y, z = _ref.z, rotation = _ref.rotation, rotationY = _ref.rotationY, rotationX = _ref.rotationX, skewX = _ref.skewX, skewY = _ref.skewY, scaleX = _ref.scaleX, scaleY = _ref.scaleY, transformPerspective = _ref.transformPerspective, force3D = _ref.force3D, target = _ref.target, zOrigin = _ref.zOrigin, transforms = "", use3D = force3D === "auto" && ratio && ratio !== 1 || force3D === true;
	if (zOrigin && (rotationX !== _zeroDeg || rotationY !== _zeroDeg)) {
		var angle = parseFloat(rotationY) * _DEG2RAD, a13 = Math.sin(angle), a33 = Math.cos(angle), cos;
		angle = parseFloat(rotationX) * _DEG2RAD;
		cos = Math.cos(angle);
		x = _addPxTranslate(target, x, a13 * cos * -zOrigin);
		y = _addPxTranslate(target, y, -Math.sin(angle) * -zOrigin);
		z = _addPxTranslate(target, z, a33 * cos * -zOrigin + zOrigin);
	}
	if (transformPerspective !== _zeroPx) transforms += "perspective(" + transformPerspective + _endParenthesis;
	if (xPercent || yPercent) transforms += "translate(" + xPercent + "%, " + yPercent + "%) ";
	if (use3D || x !== _zeroPx || y !== _zeroPx || z !== _zeroPx) transforms += z !== _zeroPx || use3D ? "translate3d(" + x + ", " + y + ", " + z + ") " : "translate(" + x + ", " + y + _endParenthesis;
	if (rotation !== _zeroDeg) transforms += "rotate(" + rotation + _endParenthesis;
	if (rotationY !== _zeroDeg) transforms += "rotateY(" + rotationY + _endParenthesis;
	if (rotationX !== _zeroDeg) transforms += "rotateX(" + rotationX + _endParenthesis;
	if (skewX !== _zeroDeg || skewY !== _zeroDeg) transforms += "skew(" + skewX + ", " + skewY + _endParenthesis;
	if (scaleX !== 1 || scaleY !== 1) transforms += "scale(" + scaleX + ", " + scaleY + _endParenthesis;
	target.style[_transformProp] = transforms || "translate(0, 0)";
};
var _renderSVGTransforms = function _renderSVGTransforms(ratio, cache) {
	var _ref2 = cache || this, xPercent = _ref2.xPercent, yPercent = _ref2.yPercent, x = _ref2.x, y = _ref2.y, rotation = _ref2.rotation, skewX = _ref2.skewX, skewY = _ref2.skewY, scaleX = _ref2.scaleX, scaleY = _ref2.scaleY, target = _ref2.target, xOrigin = _ref2.xOrigin, yOrigin = _ref2.yOrigin, xOffset = _ref2.xOffset, yOffset = _ref2.yOffset, forceCSS = _ref2.forceCSS, tx = parseFloat(x), ty = parseFloat(y), a11, a21, a12, a22, temp;
	rotation = parseFloat(rotation);
	skewX = parseFloat(skewX);
	skewY = parseFloat(skewY);
	if (skewY) {
		skewY = parseFloat(skewY);
		skewX += skewY;
		rotation += skewY;
	}
	if (rotation || skewX) {
		rotation *= _DEG2RAD;
		skewX *= _DEG2RAD;
		a11 = Math.cos(rotation) * scaleX;
		a21 = Math.sin(rotation) * scaleX;
		a12 = Math.sin(rotation - skewX) * -scaleY;
		a22 = Math.cos(rotation - skewX) * scaleY;
		if (skewX) {
			skewY *= _DEG2RAD;
			temp = Math.tan(skewX - skewY);
			temp = Math.sqrt(1 + temp * temp);
			a12 *= temp;
			a22 *= temp;
			if (skewY) {
				temp = Math.tan(skewY);
				temp = Math.sqrt(1 + temp * temp);
				a11 *= temp;
				a21 *= temp;
			}
		}
		a11 = _round(a11);
		a21 = _round(a21);
		a12 = _round(a12);
		a22 = _round(a22);
	} else {
		a11 = scaleX;
		a22 = scaleY;
		a21 = a12 = 0;
	}
	if (tx && !~(x + "").indexOf("px") || ty && !~(y + "").indexOf("px")) {
		tx = _convertToUnit(target, "x", x, "px");
		ty = _convertToUnit(target, "y", y, "px");
	}
	if (xOrigin || yOrigin || xOffset || yOffset) {
		tx = _round(tx + xOrigin - (xOrigin * a11 + yOrigin * a12) + xOffset);
		ty = _round(ty + yOrigin - (xOrigin * a21 + yOrigin * a22) + yOffset);
	}
	if (xPercent || yPercent) {
		temp = target.getBBox();
		tx = _round(tx + xPercent / 100 * temp.width);
		ty = _round(ty + yPercent / 100 * temp.height);
	}
	temp = "matrix(" + a11 + "," + a21 + "," + a12 + "," + a22 + "," + tx + "," + ty + ")";
	target.setAttribute("transform", temp);
	forceCSS && (target.style[_transformProp] = temp);
};
var _addRotationalPropTween = function _addRotationalPropTween(plugin, target, property, startNum, endValue) {
	var cap = 360, isString = _isString(endValue), change = parseFloat(endValue) * (isString && ~endValue.indexOf("rad") ? _RAD2DEG : 1) - startNum, finalValue = startNum + change + "deg", direction, pt;
	if (isString) {
		direction = endValue.split("_")[1];
		if (direction === "short") {
			change %= cap;
			if (change !== change % (cap / 2)) change += change < 0 ? cap : -cap;
		}
		if (direction === "cw" && change < 0) change = (change + cap * _bigNum) % cap - ~~(change / cap) * cap;
		else if (direction === "ccw" && change > 0) change = (change - cap * _bigNum) % cap - ~~(change / cap) * cap;
	}
	plugin._pt = pt = new PropTween(plugin._pt, target, property, startNum, change, _renderPropWithEnd);
	pt.e = finalValue;
	pt.u = "deg";
	plugin._props.push(property);
	return pt;
};
var _assign = function _assign(target, source) {
	for (var p in source) target[p] = source[p];
	return target;
};
var _addRawTransformPTs = function _addRawTransformPTs(plugin, transforms, target) {
	var startCache = _assign({}, target._gsap), exclude = "perspective,force3D,transformOrigin,svgOrigin", style = target.style, endCache, p, startValue, endValue, startNum, endNum, startUnit, endUnit;
	if (startCache.svg) {
		startValue = target.getAttribute("transform");
		target.setAttribute("transform", "");
		style[_transformProp] = transforms;
		endCache = _parseTransform(target, 1);
		_removeProperty(target, _transformProp);
		target.setAttribute("transform", startValue);
	} else {
		startValue = getComputedStyle(target)[_transformProp];
		style[_transformProp] = transforms;
		endCache = _parseTransform(target, 1);
		style[_transformProp] = startValue;
	}
	for (p in _transformProps) {
		startValue = startCache[p];
		endValue = endCache[p];
		if (startValue !== endValue && exclude.indexOf(p) < 0) {
			startUnit = getUnit(startValue);
			endUnit = getUnit(endValue);
			startNum = startUnit !== endUnit ? _convertToUnit(target, p, startValue, endUnit) : parseFloat(startValue);
			endNum = parseFloat(endValue);
			plugin._pt = new PropTween(plugin._pt, endCache, p, startNum, endNum - startNum, _renderCSSProp);
			plugin._pt.u = endUnit || 0;
			plugin._props.push(p);
		}
	}
	_assign(endCache, startCache);
};
_forEachName("padding,margin,Width,Radius", function(name, index) {
	var t = "Top", r = "Right", b = "Bottom", l = "Left", props = (index < 3 ? [
		t,
		r,
		b,
		l
	] : [
		t + l,
		t + r,
		b + r,
		b + l
	]).map(function(side) {
		return index < 2 ? name + side : "border" + side + name;
	});
	_specialProps[index > 1 ? "border" + name : name] = function(plugin, target, property, endValue, tween) {
		var a, vars;
		if (arguments.length < 4) {
			a = props.map(function(prop) {
				return _get(plugin, prop, property);
			});
			vars = a.join(" ");
			return vars.split(a[0]).length === 5 ? a[0] : vars;
		}
		a = (endValue + "").split(" ");
		vars = {};
		props.forEach(function(prop, i) {
			return vars[prop] = a[i] = a[i] || a[(i - 1) / 2 | 0];
		});
		plugin.init(target, vars, tween);
	};
});
var CSSPlugin = {
	name: "css",
	register: _initCore,
	targetTest: function targetTest(target) {
		return target.style && target.nodeType;
	},
	init: function init(target, vars, tween, index, targets) {
		var props = this._props, style = target.style, startAt = tween.vars.startAt, startValue, endValue, endNum, startNum, type, specialProp, p, startUnit, endUnit, relative, isTransformRelated, transformPropTween, cache, smooth, hasPriority, inlineProps, finalTransformValue;
		_pluginInitted || _initCore();
		this.styles = this.styles || _getStyleSaver(target);
		inlineProps = this.styles.props;
		this.tween = tween;
		for (p in vars) {
			if (p === "autoRound") continue;
			endValue = vars[p];
			if (_plugins[p] && _checkPlugin(p, vars, tween, index, target, targets)) continue;
			type = typeof endValue;
			specialProp = _specialProps[p];
			if (type === "function") {
				endValue = endValue.call(tween, index, target, targets);
				type = typeof endValue;
			}
			if (type === "string" && ~endValue.indexOf("random(")) endValue = _replaceRandom(endValue);
			if (specialProp) specialProp(this, target, p, endValue, tween) && (hasPriority = 1);
			else if (p.substr(0, 2) === "--") {
				startValue = (getComputedStyle(target).getPropertyValue(p) + "").trim();
				endValue += "";
				_colorExp.lastIndex = 0;
				if (!_colorExp.test(startValue)) {
					startUnit = getUnit(startValue);
					endUnit = getUnit(endValue);
					endUnit ? startUnit !== endUnit && (startValue = _convertToUnit(target, p, startValue, endUnit) + endUnit) : startUnit && (endValue += startUnit);
				}
				this.add(style, "setProperty", startValue, endValue, index, targets, 0, 0, p);
				props.push(p);
				inlineProps.push(p, 0, style[p]);
			} else if (type !== "undefined") {
				if (startAt && p in startAt) {
					startValue = typeof startAt[p] === "function" ? startAt[p].call(tween, index, target, targets) : startAt[p];
					_isString(startValue) && ~startValue.indexOf("random(") && (startValue = _replaceRandom(startValue));
					getUnit(startValue + "") || startValue === "auto" || (startValue += _config.units[p] || getUnit(_get(target, p)) || "");
					(startValue + "").charAt(1) === "=" && (startValue = _get(target, p));
				} else startValue = _get(target, p);
				startNum = parseFloat(startValue);
				relative = type === "string" && endValue.charAt(1) === "=" && endValue.substr(0, 2);
				relative && (endValue = endValue.substr(2));
				endNum = parseFloat(endValue);
				if (p in _propertyAliases) {
					if (p === "autoAlpha") {
						if (startNum === 1 && _get(target, "visibility") === "hidden" && endNum) startNum = 0;
						inlineProps.push("visibility", 0, style.visibility);
						_addNonTweeningPT(this, style, "visibility", startNum ? "inherit" : "hidden", endNum ? "inherit" : "hidden", !endNum);
					}
					if (p !== "scale" && p !== "transform") {
						p = _propertyAliases[p];
						~p.indexOf(",") && (p = p.split(",")[0]);
					}
				}
				isTransformRelated = p in _transformProps;
				if (isTransformRelated) {
					this.styles.save(p);
					finalTransformValue = endValue;
					if (type === "string" && endValue.substring(0, 6) === "var(--") {
						endValue = _getComputedProperty(target, endValue.substring(4, endValue.indexOf(")")));
						if (endValue.substring(0, 5) === "calc(") {
							var origPerspective = target.style.perspective;
							target.style.perspective = endValue;
							endValue = _getComputedProperty(target, "perspective");
							origPerspective ? target.style.perspective = origPerspective : _removeProperty(target, "perspective");
						}
						endNum = parseFloat(endValue);
					}
					if (!transformPropTween) {
						cache = target._gsap;
						cache.renderTransform && !vars.parseTransform || _parseTransform(target, vars.parseTransform);
						smooth = vars.smoothOrigin !== false && cache.smooth;
						transformPropTween = this._pt = new PropTween(this._pt, style, _transformProp, 0, 1, cache.renderTransform, cache, 0, -1);
						transformPropTween.dep = 1;
					}
					if (p === "scale") {
						this._pt = new PropTween(this._pt, cache, "scaleY", cache.scaleY, (relative ? _parseRelative(cache.scaleY, relative + endNum) : endNum) - cache.scaleY || 0, _renderCSSProp);
						this._pt.u = 0;
						props.push("scaleY", p);
						p += "X";
					} else if (p === "transformOrigin") {
						inlineProps.push(_transformOriginProp, 0, style[_transformOriginProp]);
						endValue = _convertKeywordsToPercentages(endValue);
						if (cache.svg) _applySVGOrigin(target, endValue, 0, smooth, 0, this);
						else {
							endUnit = parseFloat(endValue.split(" ")[2]) || 0;
							endUnit !== cache.zOrigin && _addNonTweeningPT(this, cache, "zOrigin", cache.zOrigin, endUnit);
							_addNonTweeningPT(this, style, p, _firstTwoOnly(startValue), _firstTwoOnly(endValue));
						}
						continue;
					} else if (p === "svgOrigin") {
						_applySVGOrigin(target, endValue, 1, smooth, 0, this);
						continue;
					} else if (p in _rotationalProperties) {
						_addRotationalPropTween(this, cache, p, startNum, relative ? _parseRelative(startNum, relative + endValue) : endValue);
						continue;
					} else if (p === "smoothOrigin") {
						_addNonTweeningPT(this, cache, "smooth", cache.smooth, endValue);
						continue;
					} else if (p === "force3D") {
						cache[p] = endValue;
						continue;
					} else if (p === "transform") {
						_addRawTransformPTs(this, endValue, target);
						continue;
					}
				} else if (!(p in style)) p = _checkPropPrefix(p) || p;
				if (isTransformRelated || (endNum || endNum === 0) && (startNum || startNum === 0) && !_complexExp.test(endValue) && p in style) {
					startUnit = (startValue + "").substr((startNum + "").length);
					endNum || (endNum = 0);
					endUnit = getUnit(endValue) || (p in _config.units ? _config.units[p] : startUnit);
					startUnit !== endUnit && (startNum = _convertToUnit(target, p, startValue, endUnit));
					this._pt = new PropTween(this._pt, isTransformRelated ? cache : style, p, startNum, (relative ? _parseRelative(startNum, relative + endNum) : endNum) - startNum, !isTransformRelated && (endUnit === "px" || p === "zIndex") && vars.autoRound !== false ? _renderRoundedCSSProp : _renderCSSProp);
					this._pt.u = endUnit || 0;
					if (isTransformRelated && finalTransformValue !== endValue) {
						this._pt.b = startValue;
						this._pt.e = finalTransformValue;
						this._pt.r = _renderCSSPropWithBeginningAndEnd;
					} else if (startUnit !== endUnit && endUnit !== "%") {
						this._pt.b = startValue;
						this._pt.r = _renderCSSPropWithBeginning;
					}
				} else if (!(p in style)) {
					if (p in target) this.add(target, p, startValue || target[p], relative ? relative + endValue : endValue, index, targets);
					else if (p !== "parseTransform") {
						_missingPlugin(p, endValue);
						continue;
					}
				} else _tweenComplexCSSString.call(this, target, p, startValue, relative ? relative + endValue : endValue);
				isTransformRelated || (p in style ? inlineProps.push(p, 0, style[p]) : typeof target[p] === "function" ? inlineProps.push(p, 2, target[p]()) : inlineProps.push(p, 1, startValue || target[p]));
				props.push(p);
			}
		}
		hasPriority && _sortPropTweensByPriority(this);
	},
	render: function render(ratio, data) {
		if (data.tween._time || !_reverting()) {
			var pt = data._pt;
			while (pt) {
				pt.r(ratio, pt.d);
				pt = pt._next;
			}
		} else data.styles.revert();
	},
	get: _get,
	aliases: _propertyAliases,
	getSetter: function getSetter(target, property, plugin) {
		var p = _propertyAliases[property];
		p && p.indexOf(",") < 0 && (property = p);
		return property in _transformProps && property !== _transformOriginProp && (target._gsap.x || _get(target, "x")) ? plugin && _recentSetterPlugin === plugin ? property === "scale" ? _setterScale : _setterTransform : (_recentSetterPlugin = plugin || {}) && (property === "scale" ? _setterScaleWithRender : _setterTransformWithRender) : target.style && !_isUndefined(target.style[property]) ? _setterCSSStyle : ~property.indexOf("-") ? _setterCSSProp : _getSetter(target, property);
	},
	core: {
		_removeProperty,
		_getMatrix
	}
};
gsap.utils.checkPrefix = _checkPropPrefix;
gsap.core.getStyleSaver = _getStyleSaver;
(function(positionAndScale, rotation, others, aliases) {
	var all = _forEachName(positionAndScale + "," + rotation + "," + others, function(name) {
		_transformProps[name] = 1;
	});
	_forEachName(rotation, function(name) {
		_config.units[name] = "deg";
		_rotationalProperties[name] = 1;
	});
	_propertyAliases[all[13]] = positionAndScale + "," + rotation;
	_forEachName(aliases, function(name) {
		var split = name.split(":");
		_propertyAliases[split[1]] = all[split[0]];
	});
})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent", "rotation,rotationX,rotationY,skewX,skewY", "transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective", "0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");
_forEachName("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective", function(name) {
	_config.units[name] = "px";
});
gsap.registerPlugin(CSSPlugin);
//#endregion
//#region node_modules/gsap/index.js
var gsapWithCSS = gsap.registerPlugin(CSSPlugin) || gsap;
var TweenMaxWithCSS = gsapWithCSS.core.Tween;
//#endregion
export { Back, Bounce, CSSPlugin, Circ, Cubic, Elastic, Expo, Linear, Power0, Power1, Power2, Power3, Power4, Quad, Quart, Quint, Sine, SteppedEase, Strong, Timeline as TimelineLite, Timeline as TimelineMax, Tween as TweenLite, TweenMaxWithCSS as TweenMax, gsapWithCSS as default, gsapWithCSS as gsap };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3NhcC5qcyIsIm5hbWVzIjpbIl9yZXZlcnRpbmciLCJfYmlnTnVtIiwiX3dpbmRvd0V4aXN0cyIsIl93aW4iLCJfZG9jIl0sInNvdXJjZXMiOlsiLi4vLi4vZ3NhcC9nc2FwLWNvcmUuanMiLCIuLi8uLi9nc2FwL0NTU1BsdWdpbi5qcyIsIi4uLy4uL2dzYXAvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiZnVuY3Rpb24gX2Fzc2VydFRoaXNJbml0aWFsaXplZChzZWxmKSB7IGlmIChzZWxmID09PSB2b2lkIDApIHsgdGhyb3cgbmV3IFJlZmVyZW5jZUVycm9yKFwidGhpcyBoYXNuJ3QgYmVlbiBpbml0aWFsaXNlZCAtIHN1cGVyKCkgaGFzbid0IGJlZW4gY2FsbGVkXCIpOyB9IHJldHVybiBzZWxmOyB9XG5cbmZ1bmN0aW9uIF9pbmhlcml0c0xvb3NlKHN1YkNsYXNzLCBzdXBlckNsYXNzKSB7IHN1YkNsYXNzLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoc3VwZXJDbGFzcy5wcm90b3R5cGUpOyBzdWJDbGFzcy5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBzdWJDbGFzczsgc3ViQ2xhc3MuX19wcm90b19fID0gc3VwZXJDbGFzczsgfVxuXG4vKiFcbiAqIEdTQVAgMy4xNS4wXG4gKiBodHRwczovL2dzYXAuY29tXG4gKlxuICogQGxpY2Vuc2UgQ29weXJpZ2h0IDIwMDgtMjAyNiwgR3JlZW5Tb2NrLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICogU3ViamVjdCB0byB0aGUgdGVybXMgYXQgaHR0cHM6Ly9nc2FwLmNvbS9zdGFuZGFyZC1saWNlbnNlXG4gKiBAYXV0aG9yOiBKYWNrIERveWxlLCBqYWNrQGdyZWVuc29jay5jb21cbiovXG5cbi8qIGVzbGludC1kaXNhYmxlICovXG52YXIgX2NvbmZpZyA9IHtcbiAgYXV0b1NsZWVwOiAxMjAsXG4gIGZvcmNlM0Q6IFwiYXV0b1wiLFxuICBudWxsVGFyZ2V0V2FybjogMSxcbiAgdW5pdHM6IHtcbiAgICBsaW5lSGVpZ2h0OiBcIlwiXG4gIH1cbn0sXG4gICAgX2RlZmF1bHRzID0ge1xuICBkdXJhdGlvbjogLjUsXG4gIG92ZXJ3cml0ZTogZmFsc2UsXG4gIGRlbGF5OiAwXG59LFxuICAgIF9zdXBwcmVzc092ZXJ3cml0ZXMsXG4gICAgX3JldmVydGluZyxcbiAgICBfY29udGV4dCxcbiAgICBfYmlnTnVtID0gMWU4LFxuICAgIF90aW55TnVtID0gMSAvIF9iaWdOdW0sXG4gICAgXzJQSSA9IE1hdGguUEkgKiAyLFxuICAgIF9IQUxGX1BJID0gXzJQSSAvIDQsXG4gICAgX2dzSUQgPSAwLFxuICAgIF9zcXJ0ID0gTWF0aC5zcXJ0LFxuICAgIF9jb3MgPSBNYXRoLmNvcyxcbiAgICBfc2luID0gTWF0aC5zaW4sXG4gICAgX2lzU3RyaW5nID0gZnVuY3Rpb24gX2lzU3RyaW5nKHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCI7XG59LFxuICAgIF9pc0Z1bmN0aW9uID0gZnVuY3Rpb24gX2lzRnVuY3Rpb24odmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiO1xufSxcbiAgICBfaXNOdW1iZXIgPSBmdW5jdGlvbiBfaXNOdW1iZXIodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIjtcbn0sXG4gICAgX2lzVW5kZWZpbmVkID0gZnVuY3Rpb24gX2lzVW5kZWZpbmVkKHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwidW5kZWZpbmVkXCI7XG59LFxuICAgIF9pc09iamVjdCA9IGZ1bmN0aW9uIF9pc09iamVjdCh2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiO1xufSxcbiAgICBfaXNOb3RGYWxzZSA9IGZ1bmN0aW9uIF9pc05vdEZhbHNlKHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZSAhPT0gZmFsc2U7XG59LFxuICAgIF93aW5kb3dFeGlzdHMgPSBmdW5jdGlvbiBfd2luZG93RXhpc3RzKCkge1xuICByZXR1cm4gdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIjtcbn0sXG4gICAgX2lzRnVuY09yU3RyaW5nID0gZnVuY3Rpb24gX2lzRnVuY09yU3RyaW5nKHZhbHVlKSB7XG4gIHJldHVybiBfaXNGdW5jdGlvbih2YWx1ZSkgfHwgX2lzU3RyaW5nKHZhbHVlKTtcbn0sXG4gICAgX2lzVHlwZWRBcnJheSA9IHR5cGVvZiBBcnJheUJ1ZmZlciA9PT0gXCJmdW5jdGlvblwiICYmIEFycmF5QnVmZmVyLmlzVmlldyB8fCBmdW5jdGlvbiAoKSB7fSxcbiAgICAvLyBub3RlOiBJRTEwIGhhcyBBcnJheUJ1ZmZlciwgYnV0IE5PVCBBcnJheUJ1ZmZlci5pc1ZpZXcoKS5cbl9pc0FycmF5ID0gQXJyYXkuaXNBcnJheSxcbiAgICBfcmFuZG9tRXhwID0gL3JhbmRvbVxcKFteKV0rXFwpL2csXG4gICAgX2NvbW1hRGVsaW1FeHAgPSAvLFxccyovZyxcbiAgICBfc3RyaWN0TnVtRXhwID0gLyg/Oi0/XFwuP1xcZHxcXC4pKy9naSxcbiAgICAvL29ubHkgbnVtYmVycyAoaW5jbHVkaW5nIG5lZ2F0aXZlcyBhbmQgZGVjaW1hbHMpIGJ1dCBOT1QgcmVsYXRpdmUgdmFsdWVzLlxuX251bUV4cCA9IC9bLSs9Ll0qXFxkK1suZVxcLStdKlxcZCpbZVxcLStdKlxcZCovZyxcbiAgICAvL2ZpbmRzIGFueSBudW1iZXJzLCBpbmNsdWRpbmcgb25lcyB0aGF0IHN0YXJ0IHdpdGggKz0gb3IgLT0sIG5lZ2F0aXZlIG51bWJlcnMsIGFuZCBvbmVzIGluIHNjaWVudGlmaWMgbm90YXRpb24gbGlrZSAxZS04LlxuX251bVdpdGhVbml0RXhwID0gL1stKz0uXSpcXGQrWy5lLV0qXFxkKlthLXolXSovZyxcbiAgICBfY29tcGxleFN0cmluZ051bUV4cCA9IC9bLSs9Ll0qXFxkK1xcLj9cXGQqKD86ZS18ZVxcKyk/XFxkKi9naSxcbiAgICAvL2R1cGxpY2F0ZSBzbyB0aGF0IHdoaWxlIHdlJ3JlIGxvb3BpbmcgdGhyb3VnaCBtYXRjaGVzIGZyb20gZXhlYygpLCBpdCBkb2Vzbid0IGNvbnRhbWluYXRlIHRoZSBsYXN0SW5kZXggb2YgX251bUV4cCB3aGljaCB3ZSB1c2UgdG8gc2VhcmNoIGZvciBjb2xvcnMgdG9vLlxuX3JlbEV4cCA9IC9bKy1dPS0/Wy5cXGRdKy8sXG4gICAgX2RlbGltaXRlZFZhbHVlRXhwID0gL1teLCdcIlxcW1xcXVxcc10rL2dpLFxuICAgIC8vIHByZXZpb3VzbHkgL1sjXFwtKy5dKlxcYlthLXpcXGRcXC09KyUuXSsvZ2kgYnV0IGRpZG4ndCBjYXRjaCBzcGVjaWFsIGNoYXJhY3RlcnMuXG5fdW5pdEV4cCA9IC9eWytcXC09ZVxcc1xcZF0qXFxkK1suXFxkXSooW2Etel0qfCUpXFxzKiQvaSxcbiAgICBfZ2xvYmFsVGltZWxpbmUsXG4gICAgX3dpbixcbiAgICBfY29yZUluaXR0ZWQsXG4gICAgX2RvYyxcbiAgICBfZ2xvYmFscyA9IHt9LFxuICAgIF9pbnN0YWxsU2NvcGUgPSB7fSxcbiAgICBfY29yZVJlYWR5LFxuICAgIF9pbnN0YWxsID0gZnVuY3Rpb24gX2luc3RhbGwoc2NvcGUpIHtcbiAgcmV0dXJuIChfaW5zdGFsbFNjb3BlID0gX21lcmdlKHNjb3BlLCBfZ2xvYmFscykpICYmIGdzYXA7XG59LFxuICAgIF9taXNzaW5nUGx1Z2luID0gZnVuY3Rpb24gX21pc3NpbmdQbHVnaW4ocHJvcGVydHksIHZhbHVlKSB7XG4gIHJldHVybiBjb25zb2xlLndhcm4oXCJJbnZhbGlkIHByb3BlcnR5XCIsIHByb3BlcnR5LCBcInNldCB0b1wiLCB2YWx1ZSwgXCJNaXNzaW5nIHBsdWdpbj8gZ3NhcC5yZWdpc3RlclBsdWdpbigpXCIpO1xufSxcbiAgICBfd2FybiA9IGZ1bmN0aW9uIF93YXJuKG1lc3NhZ2UsIHN1cHByZXNzKSB7XG4gIHJldHVybiAhc3VwcHJlc3MgJiYgY29uc29sZS53YXJuKG1lc3NhZ2UpO1xufSxcbiAgICBfYWRkR2xvYmFsID0gZnVuY3Rpb24gX2FkZEdsb2JhbChuYW1lLCBvYmopIHtcbiAgcmV0dXJuIG5hbWUgJiYgKF9nbG9iYWxzW25hbWVdID0gb2JqKSAmJiBfaW5zdGFsbFNjb3BlICYmIChfaW5zdGFsbFNjb3BlW25hbWVdID0gb2JqKSB8fCBfZ2xvYmFscztcbn0sXG4gICAgX2VtcHR5RnVuYyA9IGZ1bmN0aW9uIF9lbXB0eUZ1bmMoKSB7XG4gIHJldHVybiAwO1xufSxcbiAgICBfc3RhcnRBdFJldmVydENvbmZpZyA9IHtcbiAgc3VwcHJlc3NFdmVudHM6IHRydWUsXG4gIGlzU3RhcnQ6IHRydWUsXG4gIGtpbGw6IGZhbHNlXG59LFxuICAgIF9yZXZlcnRDb25maWdOb0tpbGwgPSB7XG4gIHN1cHByZXNzRXZlbnRzOiB0cnVlLFxuICBraWxsOiBmYWxzZVxufSxcbiAgICBfcmV2ZXJ0Q29uZmlnID0ge1xuICBzdXBwcmVzc0V2ZW50czogdHJ1ZVxufSxcbiAgICBfcmVzZXJ2ZWRQcm9wcyA9IHt9LFxuICAgIF9sYXp5VHdlZW5zID0gW10sXG4gICAgX2xhenlMb29rdXAgPSB7fSxcbiAgICBfbGFzdFJlbmRlcmVkRnJhbWUsXG4gICAgX3BsdWdpbnMgPSB7fSxcbiAgICBfZWZmZWN0cyA9IHt9LFxuICAgIF9uZXh0R0NGcmFtZSA9IDMwLFxuICAgIF9oYXJuZXNzUGx1Z2lucyA9IFtdLFxuICAgIF9jYWxsYmFja05hbWVzID0gXCJcIixcbiAgICBfaGFybmVzcyA9IGZ1bmN0aW9uIF9oYXJuZXNzKHRhcmdldHMpIHtcbiAgdmFyIHRhcmdldCA9IHRhcmdldHNbMF0sXG4gICAgICBoYXJuZXNzUGx1Z2luLFxuICAgICAgaTtcbiAgX2lzT2JqZWN0KHRhcmdldCkgfHwgX2lzRnVuY3Rpb24odGFyZ2V0KSB8fCAodGFyZ2V0cyA9IFt0YXJnZXRzXSk7XG5cbiAgaWYgKCEoaGFybmVzc1BsdWdpbiA9ICh0YXJnZXQuX2dzYXAgfHwge30pLmhhcm5lc3MpKSB7XG4gICAgLy8gZmluZCB0aGUgZmlyc3QgdGFyZ2V0IHdpdGggYSBoYXJuZXNzLiBXZSBhc3N1bWUgdGFyZ2V0cyBwYXNzZWQgaW50byBhbiBhbmltYXRpb24gd2lsbCBiZSBvZiBzaW1pbGFyIHR5cGUsIG1lYW5pbmcgdGhlIHNhbWUga2luZCBvZiBoYXJuZXNzIGNhbiBiZSB1c2VkIGZvciB0aGVtIGFsbCAocGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9uKVxuICAgIGkgPSBfaGFybmVzc1BsdWdpbnMubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGktLSAmJiAhX2hhcm5lc3NQbHVnaW5zW2ldLnRhcmdldFRlc3QodGFyZ2V0KSkge31cblxuICAgIGhhcm5lc3NQbHVnaW4gPSBfaGFybmVzc1BsdWdpbnNbaV07XG4gIH1cblxuICBpID0gdGFyZ2V0cy5sZW5ndGg7XG5cbiAgd2hpbGUgKGktLSkge1xuICAgIHRhcmdldHNbaV0gJiYgKHRhcmdldHNbaV0uX2dzYXAgfHwgKHRhcmdldHNbaV0uX2dzYXAgPSBuZXcgR1NDYWNoZSh0YXJnZXRzW2ldLCBoYXJuZXNzUGx1Z2luKSkpIHx8IHRhcmdldHMuc3BsaWNlKGksIDEpO1xuICB9XG5cbiAgcmV0dXJuIHRhcmdldHM7XG59LFxuICAgIF9nZXRDYWNoZSA9IGZ1bmN0aW9uIF9nZXRDYWNoZSh0YXJnZXQpIHtcbiAgcmV0dXJuIHRhcmdldC5fZ3NhcCB8fCBfaGFybmVzcyh0b0FycmF5KHRhcmdldCkpWzBdLl9nc2FwO1xufSxcbiAgICBfZ2V0UHJvcGVydHkgPSBmdW5jdGlvbiBfZ2V0UHJvcGVydHkodGFyZ2V0LCBwcm9wZXJ0eSwgdikge1xuICByZXR1cm4gKHYgPSB0YXJnZXRbcHJvcGVydHldKSAmJiBfaXNGdW5jdGlvbih2KSA/IHRhcmdldFtwcm9wZXJ0eV0oKSA6IF9pc1VuZGVmaW5lZCh2KSAmJiB0YXJnZXQuZ2V0QXR0cmlidXRlICYmIHRhcmdldC5nZXRBdHRyaWJ1dGUocHJvcGVydHkpIHx8IHY7XG59LFxuICAgIF9mb3JFYWNoTmFtZSA9IGZ1bmN0aW9uIF9mb3JFYWNoTmFtZShuYW1lcywgZnVuYykge1xuICByZXR1cm4gKG5hbWVzID0gbmFtZXMuc3BsaXQoXCIsXCIpKS5mb3JFYWNoKGZ1bmMpIHx8IG5hbWVzO1xufSxcbiAgICAvL3NwbGl0IGEgY29tbWEtZGVsaW1pdGVkIGxpc3Qgb2YgbmFtZXMgaW50byBhbiBhcnJheSwgdGhlbiBydW4gYSBmb3JFYWNoKCkgZnVuY3Rpb24gYW5kIHJldHVybiB0aGUgc3BsaXQgYXJyYXkgKHRoaXMgaXMganVzdCBhIHdheSB0byBjb25zb2xpZGF0ZS9zaG9ydGVuIHNvbWUgY29kZSkuXG5fcm91bmQgPSBmdW5jdGlvbiBfcm91bmQodmFsdWUpIHtcbiAgcmV0dXJuIE1hdGgucm91bmQodmFsdWUgKiAxMDAwMDApIC8gMTAwMDAwIHx8IDA7XG59LFxuICAgIF9yb3VuZFByZWNpc2UgPSBmdW5jdGlvbiBfcm91bmRQcmVjaXNlKHZhbHVlKSB7XG4gIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlICogMTAwMDAwMDApIC8gMTAwMDAwMDAgfHwgMDtcbn0sXG4gICAgLy8gaW5jcmVhc2VkIHByZWNpc2lvbiBtb3N0bHkgZm9yIHRpbWluZyB2YWx1ZXMuXG5fcGFyc2VSZWxhdGl2ZSA9IGZ1bmN0aW9uIF9wYXJzZVJlbGF0aXZlKHN0YXJ0LCB2YWx1ZSkge1xuICB2YXIgb3BlcmF0b3IgPSB2YWx1ZS5jaGFyQXQoMCksXG4gICAgICBlbmQgPSBwYXJzZUZsb2F0KHZhbHVlLnN1YnN0cigyKSk7XG4gIHN0YXJ0ID0gcGFyc2VGbG9hdChzdGFydCk7XG4gIHJldHVybiBvcGVyYXRvciA9PT0gXCIrXCIgPyBzdGFydCArIGVuZCA6IG9wZXJhdG9yID09PSBcIi1cIiA/IHN0YXJ0IC0gZW5kIDogb3BlcmF0b3IgPT09IFwiKlwiID8gc3RhcnQgKiBlbmQgOiBzdGFydCAvIGVuZDtcbn0sXG4gICAgX2FycmF5Q29udGFpbnNBbnkgPSBmdW5jdGlvbiBfYXJyYXlDb250YWluc0FueSh0b1NlYXJjaCwgdG9GaW5kKSB7XG4gIC8vc2VhcmNoZXMgb25lIGFycmF5IHRvIGZpbmQgbWF0Y2hlcyBmb3IgYW55IG9mIHRoZSBpdGVtcyBpbiB0aGUgdG9GaW5kIGFycmF5LiBBcyBzb29uIGFzIG9uZSBpcyBmb3VuZCwgaXQgcmV0dXJucyB0cnVlLiBJdCBkb2VzIE5PVCByZXR1cm4gYWxsIHRoZSBtYXRjaGVzOyBpdCdzIHNpbXBseSBhIGJvb2xlYW4gc2VhcmNoLlxuICB2YXIgbCA9IHRvRmluZC5sZW5ndGgsXG4gICAgICBpID0gMDtcblxuICBmb3IgKDsgdG9TZWFyY2guaW5kZXhPZih0b0ZpbmRbaV0pIDwgMCAmJiArK2kgPCBsOykge31cblxuICByZXR1cm4gaSA8IGw7XG59LFxuICAgIF9sYXp5UmVuZGVyID0gZnVuY3Rpb24gX2xhenlSZW5kZXIoKSB7XG4gIHZhciBsID0gX2xhenlUd2VlbnMubGVuZ3RoLFxuICAgICAgYSA9IF9sYXp5VHdlZW5zLnNsaWNlKDApLFxuICAgICAgaSxcbiAgICAgIHR3ZWVuO1xuXG4gIF9sYXp5TG9va3VwID0ge307XG4gIF9sYXp5VHdlZW5zLmxlbmd0aCA9IDA7XG5cbiAgZm9yIChpID0gMDsgaSA8IGw7IGkrKykge1xuICAgIHR3ZWVuID0gYVtpXTtcbiAgICB0d2VlbiAmJiB0d2Vlbi5fbGF6eSAmJiAodHdlZW4ucmVuZGVyKHR3ZWVuLl9sYXp5WzBdLCB0d2Vlbi5fbGF6eVsxXSwgdHJ1ZSkuX2xhenkgPSAwKTtcbiAgfVxufSxcbiAgICBfaXNSZXZlcnRXb3J0aHkgPSBmdW5jdGlvbiBfaXNSZXZlcnRXb3J0aHkoYW5pbWF0aW9uKSB7XG4gIHJldHVybiAhIShhbmltYXRpb24uX2luaXR0ZWQgfHwgYW5pbWF0aW9uLl9zdGFydEF0IHx8IGFuaW1hdGlvbi5hZGQpO1xufSxcbiAgICBfbGF6eVNhZmVSZW5kZXIgPSBmdW5jdGlvbiBfbGF6eVNhZmVSZW5kZXIoYW5pbWF0aW9uLCB0aW1lLCBzdXBwcmVzc0V2ZW50cywgZm9yY2UpIHtcbiAgX2xhenlUd2VlbnMubGVuZ3RoICYmICFfcmV2ZXJ0aW5nICYmIF9sYXp5UmVuZGVyKCk7XG4gIGFuaW1hdGlvbi5yZW5kZXIodGltZSwgc3VwcHJlc3NFdmVudHMsIGZvcmNlIHx8ICEhKF9yZXZlcnRpbmcgJiYgdGltZSA8IDAgJiYgX2lzUmV2ZXJ0V29ydGh5KGFuaW1hdGlvbikpKTtcbiAgX2xhenlUd2VlbnMubGVuZ3RoICYmICFfcmV2ZXJ0aW5nICYmIF9sYXp5UmVuZGVyKCk7IC8vaW4gY2FzZSByZW5kZXJpbmcgY2F1c2VkIGFueSB0d2VlbnMgdG8gbGF6eS1pbml0LCB3ZSBzaG91bGQgcmVuZGVyIHRoZW0gYmVjYXVzZSB0eXBpY2FsbHkgd2hlbiBzb21lb25lIGNhbGxzIHNlZWsoKSBvciB0aW1lKCkgb3IgcHJvZ3Jlc3MoKSwgdGhleSBleHBlY3QgYW4gaW1tZWRpYXRlIHJlbmRlci5cbn0sXG4gICAgX251bWVyaWNJZlBvc3NpYmxlID0gZnVuY3Rpb24gX251bWVyaWNJZlBvc3NpYmxlKHZhbHVlKSB7XG4gIHZhciBuID0gcGFyc2VGbG9hdCh2YWx1ZSk7XG4gIHJldHVybiAobiB8fCBuID09PSAwKSAmJiAodmFsdWUgKyBcIlwiKS5tYXRjaChfZGVsaW1pdGVkVmFsdWVFeHApLmxlbmd0aCA8IDIgPyBuIDogX2lzU3RyaW5nKHZhbHVlKSA/IHZhbHVlLnRyaW0oKSA6IHZhbHVlO1xufSxcbiAgICBfcGFzc1Rocm91Z2ggPSBmdW5jdGlvbiBfcGFzc1Rocm91Z2gocCkge1xuICByZXR1cm4gcDtcbn0sXG4gICAgX3NldERlZmF1bHRzID0gZnVuY3Rpb24gX3NldERlZmF1bHRzKG9iaiwgZGVmYXVsdHMpIHtcbiAgZm9yICh2YXIgcCBpbiBkZWZhdWx0cykge1xuICAgIHAgaW4gb2JqIHx8IChvYmpbcF0gPSBkZWZhdWx0c1twXSk7XG4gIH1cblxuICByZXR1cm4gb2JqO1xufSxcbiAgICBfc2V0S2V5ZnJhbWVEZWZhdWx0cyA9IGZ1bmN0aW9uIF9zZXRLZXlmcmFtZURlZmF1bHRzKGV4Y2x1ZGVEdXJhdGlvbikge1xuICByZXR1cm4gZnVuY3Rpb24gKG9iaiwgZGVmYXVsdHMpIHtcbiAgICBmb3IgKHZhciBwIGluIGRlZmF1bHRzKSB7XG4gICAgICBwIGluIG9iaiB8fCBwID09PSBcImR1cmF0aW9uXCIgJiYgZXhjbHVkZUR1cmF0aW9uIHx8IHAgPT09IFwiZWFzZVwiIHx8IChvYmpbcF0gPSBkZWZhdWx0c1twXSk7XG4gICAgfVxuICB9O1xufSxcbiAgICBfbWVyZ2UgPSBmdW5jdGlvbiBfbWVyZ2UoYmFzZSwgdG9NZXJnZSkge1xuICBmb3IgKHZhciBwIGluIHRvTWVyZ2UpIHtcbiAgICBiYXNlW3BdID0gdG9NZXJnZVtwXTtcbiAgfVxuXG4gIHJldHVybiBiYXNlO1xufSxcbiAgICBfbWVyZ2VEZWVwID0gZnVuY3Rpb24gX21lcmdlRGVlcChiYXNlLCB0b01lcmdlKSB7XG4gIGZvciAodmFyIHAgaW4gdG9NZXJnZSkge1xuICAgIHAgIT09IFwiX19wcm90b19fXCIgJiYgcCAhPT0gXCJjb25zdHJ1Y3RvclwiICYmIHAgIT09IFwicHJvdG90eXBlXCIgJiYgKGJhc2VbcF0gPSBfaXNPYmplY3QodG9NZXJnZVtwXSkgPyBfbWVyZ2VEZWVwKGJhc2VbcF0gfHwgKGJhc2VbcF0gPSB7fSksIHRvTWVyZ2VbcF0pIDogdG9NZXJnZVtwXSk7XG4gIH1cblxuICByZXR1cm4gYmFzZTtcbn0sXG4gICAgX2NvcHlFeGNsdWRpbmcgPSBmdW5jdGlvbiBfY29weUV4Y2x1ZGluZyhvYmosIGV4Y2x1ZGluZykge1xuICB2YXIgY29weSA9IHt9LFxuICAgICAgcDtcblxuICBmb3IgKHAgaW4gb2JqKSB7XG4gICAgcCBpbiBleGNsdWRpbmcgfHwgKGNvcHlbcF0gPSBvYmpbcF0pO1xuICB9XG5cbiAgcmV0dXJuIGNvcHk7XG59LFxuICAgIF9pbmhlcml0RGVmYXVsdHMgPSBmdW5jdGlvbiBfaW5oZXJpdERlZmF1bHRzKHZhcnMpIHtcbiAgdmFyIHBhcmVudCA9IHZhcnMucGFyZW50IHx8IF9nbG9iYWxUaW1lbGluZSxcbiAgICAgIGZ1bmMgPSB2YXJzLmtleWZyYW1lcyA/IF9zZXRLZXlmcmFtZURlZmF1bHRzKF9pc0FycmF5KHZhcnMua2V5ZnJhbWVzKSkgOiBfc2V0RGVmYXVsdHM7XG5cbiAgaWYgKF9pc05vdEZhbHNlKHZhcnMuaW5oZXJpdCkpIHtcbiAgICB3aGlsZSAocGFyZW50KSB7XG4gICAgICBmdW5jKHZhcnMsIHBhcmVudC52YXJzLmRlZmF1bHRzKTtcbiAgICAgIHBhcmVudCA9IHBhcmVudC5wYXJlbnQgfHwgcGFyZW50Ll9kcDtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gdmFycztcbn0sXG4gICAgX2FycmF5c01hdGNoID0gZnVuY3Rpb24gX2FycmF5c01hdGNoKGExLCBhMikge1xuICB2YXIgaSA9IGExLmxlbmd0aCxcbiAgICAgIG1hdGNoID0gaSA9PT0gYTIubGVuZ3RoO1xuXG4gIHdoaWxlIChtYXRjaCAmJiBpLS0gJiYgYTFbaV0gPT09IGEyW2ldKSB7fVxuXG4gIHJldHVybiBpIDwgMDtcbn0sXG4gICAgX2FkZExpbmtlZExpc3RJdGVtID0gZnVuY3Rpb24gX2FkZExpbmtlZExpc3RJdGVtKHBhcmVudCwgY2hpbGQsIGZpcnN0UHJvcCwgbGFzdFByb3AsIHNvcnRCeSkge1xuICBpZiAoZmlyc3RQcm9wID09PSB2b2lkIDApIHtcbiAgICBmaXJzdFByb3AgPSBcIl9maXJzdFwiO1xuICB9XG5cbiAgaWYgKGxhc3RQcm9wID09PSB2b2lkIDApIHtcbiAgICBsYXN0UHJvcCA9IFwiX2xhc3RcIjtcbiAgfVxuXG4gIHZhciBwcmV2ID0gcGFyZW50W2xhc3RQcm9wXSxcbiAgICAgIHQ7XG5cbiAgaWYgKHNvcnRCeSkge1xuICAgIHQgPSBjaGlsZFtzb3J0QnldO1xuXG4gICAgd2hpbGUgKHByZXYgJiYgcHJldltzb3J0QnldID4gdCkge1xuICAgICAgcHJldiA9IHByZXYuX3ByZXY7XG4gICAgfVxuICB9XG5cbiAgaWYgKHByZXYpIHtcbiAgICBjaGlsZC5fbmV4dCA9IHByZXYuX25leHQ7XG4gICAgcHJldi5fbmV4dCA9IGNoaWxkO1xuICB9IGVsc2Uge1xuICAgIGNoaWxkLl9uZXh0ID0gcGFyZW50W2ZpcnN0UHJvcF07XG4gICAgcGFyZW50W2ZpcnN0UHJvcF0gPSBjaGlsZDtcbiAgfVxuXG4gIGlmIChjaGlsZC5fbmV4dCkge1xuICAgIGNoaWxkLl9uZXh0Ll9wcmV2ID0gY2hpbGQ7XG4gIH0gZWxzZSB7XG4gICAgcGFyZW50W2xhc3RQcm9wXSA9IGNoaWxkO1xuICB9XG5cbiAgY2hpbGQuX3ByZXYgPSBwcmV2O1xuICBjaGlsZC5wYXJlbnQgPSBjaGlsZC5fZHAgPSBwYXJlbnQ7XG4gIHJldHVybiBjaGlsZDtcbn0sXG4gICAgX3JlbW92ZUxpbmtlZExpc3RJdGVtID0gZnVuY3Rpb24gX3JlbW92ZUxpbmtlZExpc3RJdGVtKHBhcmVudCwgY2hpbGQsIGZpcnN0UHJvcCwgbGFzdFByb3ApIHtcbiAgaWYgKGZpcnN0UHJvcCA9PT0gdm9pZCAwKSB7XG4gICAgZmlyc3RQcm9wID0gXCJfZmlyc3RcIjtcbiAgfVxuXG4gIGlmIChsYXN0UHJvcCA9PT0gdm9pZCAwKSB7XG4gICAgbGFzdFByb3AgPSBcIl9sYXN0XCI7XG4gIH1cblxuICB2YXIgcHJldiA9IGNoaWxkLl9wcmV2LFxuICAgICAgbmV4dCA9IGNoaWxkLl9uZXh0O1xuXG4gIGlmIChwcmV2KSB7XG4gICAgcHJldi5fbmV4dCA9IG5leHQ7XG4gIH0gZWxzZSBpZiAocGFyZW50W2ZpcnN0UHJvcF0gPT09IGNoaWxkKSB7XG4gICAgcGFyZW50W2ZpcnN0UHJvcF0gPSBuZXh0O1xuICB9XG5cbiAgaWYgKG5leHQpIHtcbiAgICBuZXh0Ll9wcmV2ID0gcHJldjtcbiAgfSBlbHNlIGlmIChwYXJlbnRbbGFzdFByb3BdID09PSBjaGlsZCkge1xuICAgIHBhcmVudFtsYXN0UHJvcF0gPSBwcmV2O1xuICB9XG5cbiAgY2hpbGQuX25leHQgPSBjaGlsZC5fcHJldiA9IGNoaWxkLnBhcmVudCA9IG51bGw7IC8vIGRvbid0IGRlbGV0ZSB0aGUgX2RwIGp1c3Qgc28gd2UgY2FuIHJldmVydCBpZiBuZWNlc3NhcnkuIEJ1dCBwYXJlbnQgc2hvdWxkIGJlIG51bGwgdG8gaW5kaWNhdGUgdGhlIGl0ZW0gaXNuJ3QgaW4gYSBsaW5rZWQgbGlzdC5cbn0sXG4gICAgX3JlbW92ZUZyb21QYXJlbnQgPSBmdW5jdGlvbiBfcmVtb3ZlRnJvbVBhcmVudChjaGlsZCwgb25seUlmUGFyZW50SGFzQXV0b1JlbW92ZSkge1xuICBjaGlsZC5wYXJlbnQgJiYgKCFvbmx5SWZQYXJlbnRIYXNBdXRvUmVtb3ZlIHx8IGNoaWxkLnBhcmVudC5hdXRvUmVtb3ZlQ2hpbGRyZW4pICYmIGNoaWxkLnBhcmVudC5yZW1vdmUgJiYgY2hpbGQucGFyZW50LnJlbW92ZShjaGlsZCk7XG4gIGNoaWxkLl9hY3QgPSAwO1xufSxcbiAgICBfdW5jYWNoZSA9IGZ1bmN0aW9uIF91bmNhY2hlKGFuaW1hdGlvbiwgY2hpbGQpIHtcbiAgaWYgKGFuaW1hdGlvbiAmJiAoIWNoaWxkIHx8IGNoaWxkLl9lbmQgPiBhbmltYXRpb24uX2R1ciB8fCBjaGlsZC5fc3RhcnQgPCAwKSkge1xuICAgIC8vIHBlcmZvcm1hbmNlIG9wdGltaXphdGlvbjogaWYgYSBjaGlsZCBhbmltYXRpb24gaXMgcGFzc2VkIGluIHdlIHNob3VsZCBvbmx5IHVuY2FjaGUgaWYgdGhhdCBjaGlsZCBFWFRFTkRTIHRoZSBhbmltYXRpb24gKGl0cyBlbmQgdGltZSBpcyBiZXlvbmQgdGhlIGVuZClcbiAgICB2YXIgYSA9IGFuaW1hdGlvbjtcblxuICAgIHdoaWxlIChhKSB7XG4gICAgICBhLl9kaXJ0eSA9IDE7XG4gICAgICBhID0gYS5wYXJlbnQ7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGFuaW1hdGlvbjtcbn0sXG4gICAgX3JlY2FjaGVBbmNlc3RvcnMgPSBmdW5jdGlvbiBfcmVjYWNoZUFuY2VzdG9ycyhhbmltYXRpb24pIHtcbiAgdmFyIHBhcmVudCA9IGFuaW1hdGlvbi5wYXJlbnQ7XG5cbiAgd2hpbGUgKHBhcmVudCAmJiBwYXJlbnQucGFyZW50KSB7XG4gICAgLy9zb21ldGltZXMgd2UgbXVzdCBmb3JjZSBhIHJlLXNvcnQgb2YgYWxsIGNoaWxkcmVuIGFuZCB1cGRhdGUgdGhlIGR1cmF0aW9uL3RvdGFsRHVyYXRpb24gb2YgYWxsIGFuY2VzdG9yIHRpbWVsaW5lcyBpbW1lZGlhdGVseSBpbiBjYXNlLCBmb3IgZXhhbXBsZSwgaW4gdGhlIG1pZGRsZSBvZiBhIHJlbmRlciBsb29wLCBvbmUgdHdlZW4gYWx0ZXJzIGFub3RoZXIgdHdlZW4ncyB0aW1lU2NhbGUgd2hpY2ggc2hvdmVzIGl0cyBzdGFydFRpbWUgYmVmb3JlIDAsIGZvcmNpbmcgdGhlIHBhcmVudCB0aW1lbGluZSB0byBzaGlmdCBhcm91bmQgYW5kIHNoaWZ0Q2hpbGRyZW4oKSB3aGljaCBjb3VsZCBhZmZlY3QgdGhhdCBuZXh0IHR3ZWVuJ3MgcmVuZGVyIChzdGFydFRpbWUpLiBEb2Vzbid0IG1hdHRlciBmb3IgdGhlIHJvb3QgdGltZWxpbmUgdGhvdWdoLlxuICAgIHBhcmVudC5fZGlydHkgPSAxO1xuICAgIHBhcmVudC50b3RhbER1cmF0aW9uKCk7XG4gICAgcGFyZW50ID0gcGFyZW50LnBhcmVudDtcbiAgfVxuXG4gIHJldHVybiBhbmltYXRpb247XG59LFxuICAgIF9yZXdpbmRTdGFydEF0ID0gZnVuY3Rpb24gX3Jld2luZFN0YXJ0QXQodHdlZW4sIHRvdGFsVGltZSwgc3VwcHJlc3NFdmVudHMsIGZvcmNlKSB7XG4gIHJldHVybiB0d2Vlbi5fc3RhcnRBdCAmJiAoX3JldmVydGluZyA/IHR3ZWVuLl9zdGFydEF0LnJldmVydChfcmV2ZXJ0Q29uZmlnTm9LaWxsKSA6IHR3ZWVuLnZhcnMuaW1tZWRpYXRlUmVuZGVyICYmICF0d2Vlbi52YXJzLmF1dG9SZXZlcnQgfHwgdHdlZW4uX3N0YXJ0QXQucmVuZGVyKHRvdGFsVGltZSwgdHJ1ZSwgZm9yY2UpKTtcbn0sXG4gICAgX2hhc05vUGF1c2VkQW5jZXN0b3JzID0gZnVuY3Rpb24gX2hhc05vUGF1c2VkQW5jZXN0b3JzKGFuaW1hdGlvbikge1xuICByZXR1cm4gIWFuaW1hdGlvbiB8fCBhbmltYXRpb24uX3RzICYmIF9oYXNOb1BhdXNlZEFuY2VzdG9ycyhhbmltYXRpb24ucGFyZW50KTtcbn0sXG4gICAgX2VsYXBzZWRDeWNsZUR1cmF0aW9uID0gZnVuY3Rpb24gX2VsYXBzZWRDeWNsZUR1cmF0aW9uKGFuaW1hdGlvbikge1xuICByZXR1cm4gYW5pbWF0aW9uLl9yZXBlYXQgPyBfYW5pbWF0aW9uQ3ljbGUoYW5pbWF0aW9uLl90VGltZSwgYW5pbWF0aW9uID0gYW5pbWF0aW9uLmR1cmF0aW9uKCkgKyBhbmltYXRpb24uX3JEZWxheSkgKiBhbmltYXRpb24gOiAwO1xufSxcbiAgICAvLyBmZWVkIGluIHRoZSB0b3RhbFRpbWUgYW5kIGN5Y2xlRHVyYXRpb24gYW5kIGl0J2xsIHJldHVybiB0aGUgY3ljbGUgKGl0ZXJhdGlvbiBtaW51cyAxKSBhbmQgaWYgdGhlIHBsYXloZWFkIGlzIGV4YWN0bHkgYXQgdGhlIHZlcnkgRU5ELCBpdCB3aWxsIE5PVCBidW1wIHVwIHRvIHRoZSBuZXh0IGN5Y2xlLlxuX2FuaW1hdGlvbkN5Y2xlID0gZnVuY3Rpb24gX2FuaW1hdGlvbkN5Y2xlKHRUaW1lLCBjeWNsZUR1cmF0aW9uKSB7XG4gIHZhciB3aG9sZSA9IE1hdGguZmxvb3IodFRpbWUgPSBfcm91bmRQcmVjaXNlKHRUaW1lIC8gY3ljbGVEdXJhdGlvbikpO1xuICByZXR1cm4gdFRpbWUgJiYgd2hvbGUgPT09IHRUaW1lID8gd2hvbGUgLSAxIDogd2hvbGU7XG59LFxuICAgIF9wYXJlbnRUb0NoaWxkVG90YWxUaW1lID0gZnVuY3Rpb24gX3BhcmVudFRvQ2hpbGRUb3RhbFRpbWUocGFyZW50VGltZSwgY2hpbGQpIHtcbiAgcmV0dXJuIChwYXJlbnRUaW1lIC0gY2hpbGQuX3N0YXJ0KSAqIGNoaWxkLl90cyArIChjaGlsZC5fdHMgPj0gMCA/IDAgOiBjaGlsZC5fZGlydHkgPyBjaGlsZC50b3RhbER1cmF0aW9uKCkgOiBjaGlsZC5fdER1cik7XG59LFxuICAgIF9zZXRFbmQgPSBmdW5jdGlvbiBfc2V0RW5kKGFuaW1hdGlvbikge1xuICByZXR1cm4gYW5pbWF0aW9uLl9lbmQgPSBfcm91bmRQcmVjaXNlKGFuaW1hdGlvbi5fc3RhcnQgKyAoYW5pbWF0aW9uLl90RHVyIC8gTWF0aC5hYnMoYW5pbWF0aW9uLl90cyB8fCBhbmltYXRpb24uX3J0cyB8fCBfdGlueU51bSkgfHwgMCkpO1xufSxcbiAgICBfYWxpZ25QbGF5aGVhZCA9IGZ1bmN0aW9uIF9hbGlnblBsYXloZWFkKGFuaW1hdGlvbiwgdG90YWxUaW1lKSB7XG4gIC8vIGFkanVzdHMgdGhlIGFuaW1hdGlvbidzIF9zdGFydCBhbmQgX2VuZCBhY2NvcmRpbmcgdG8gdGhlIHByb3ZpZGVkIHRvdGFsVGltZSAob25seSBpZiB0aGUgcGFyZW50J3Mgc21vb3RoQ2hpbGRUaW1pbmcgaXMgdHJ1ZSBhbmQgdGhlIGFuaW1hdGlvbiBpc24ndCBwYXVzZWQpLiBJdCBkb2Vzbid0IGRvIGFueSByZW5kZXJpbmcgb3IgZm9yY2luZyB0aGluZ3MgYmFjayBpbnRvIHBhcmVudCB0aW1lbGluZXMsIGV0Yy4gLSB0aGF0J3Mgd2hhdCB0b3RhbFRpbWUoKSBpcyBmb3IuXG4gIHZhciBwYXJlbnQgPSBhbmltYXRpb24uX2RwO1xuXG4gIGlmIChwYXJlbnQgJiYgcGFyZW50LnNtb290aENoaWxkVGltaW5nICYmIGFuaW1hdGlvbi5fdHMpIHtcbiAgICBhbmltYXRpb24uX3N0YXJ0ID0gX3JvdW5kUHJlY2lzZShwYXJlbnQuX3RpbWUgLSAoYW5pbWF0aW9uLl90cyA+IDAgPyB0b3RhbFRpbWUgLyBhbmltYXRpb24uX3RzIDogKChhbmltYXRpb24uX2RpcnR5ID8gYW5pbWF0aW9uLnRvdGFsRHVyYXRpb24oKSA6IGFuaW1hdGlvbi5fdER1cikgLSB0b3RhbFRpbWUpIC8gLWFuaW1hdGlvbi5fdHMpKTtcblxuICAgIF9zZXRFbmQoYW5pbWF0aW9uKTtcblxuICAgIHBhcmVudC5fZGlydHkgfHwgX3VuY2FjaGUocGFyZW50LCBhbmltYXRpb24pOyAvL2ZvciBwZXJmb3JtYW5jZSBpbXByb3ZlbWVudC4gSWYgdGhlIHBhcmVudCdzIGNhY2hlIGlzIGFscmVhZHkgZGlydHksIGl0IGFscmVhZHkgdG9vayBjYXJlIG9mIG1hcmtpbmcgdGhlIGFuY2VzdG9ycyBhcyBkaXJ0eSB0b28sIHNvIHNraXAgdGhlIGZ1bmN0aW9uIGNhbGwgaGVyZS5cbiAgfVxuXG4gIHJldHVybiBhbmltYXRpb247XG59LFxuXG4vKlxuX3RvdGFsVGltZVRvVGltZSA9IChjbGFtcGVkVG90YWxUaW1lLCBkdXJhdGlvbiwgcmVwZWF0LCByZXBlYXREZWxheSwgeW95bykgPT4ge1xuXHRsZXQgY3ljbGVEdXJhdGlvbiA9IGR1cmF0aW9uICsgcmVwZWF0RGVsYXksXG5cdFx0dGltZSA9IF9yb3VuZChjbGFtcGVkVG90YWxUaW1lICUgY3ljbGVEdXJhdGlvbik7XG5cdGlmICh0aW1lID4gZHVyYXRpb24pIHtcblx0XHR0aW1lID0gZHVyYXRpb247XG5cdH1cblx0cmV0dXJuICh5b3lvICYmICh+fihjbGFtcGVkVG90YWxUaW1lIC8gY3ljbGVEdXJhdGlvbikgJiAxKSkgPyBkdXJhdGlvbiAtIHRpbWUgOiB0aW1lO1xufSxcbiovXG5fcG9zdEFkZENoZWNrcyA9IGZ1bmN0aW9uIF9wb3N0QWRkQ2hlY2tzKHRpbWVsaW5lLCBjaGlsZCkge1xuICB2YXIgdDtcblxuICBpZiAoY2hpbGQuX3RpbWUgfHwgIWNoaWxkLl9kdXIgJiYgY2hpbGQuX2luaXR0ZWQgfHwgY2hpbGQuX3N0YXJ0IDwgdGltZWxpbmUuX3RpbWUgJiYgKGNoaWxkLl9kdXIgfHwgIWNoaWxkLmFkZCkpIHtcbiAgICAvLyBpbiBjYXNlLCBmb3IgZXhhbXBsZSwgdGhlIF9zdGFydCBpcyBtb3ZlZCBvbiBhIHR3ZWVuIHRoYXQgaGFzIGFscmVhZHkgcmVuZGVyZWQsIG9yIGlmIGl0J3MgYmVpbmcgaW5zZXJ0ZWQgaW50byBhIHRpbWVsaW5lIEJFRk9SRSB3aGVyZSB0aGUgcGxheWhlYWQgaXMgY3VycmVudGx5LiBJbWFnaW5lIGl0J3MgYXQgaXRzIGVuZCBzdGF0ZSwgdGhlbiB0aGUgc3RhcnRUaW1lIGlzIG1vdmVkIFdBWSBsYXRlciAoYWZ0ZXIgdGhlIGVuZCBvZiB0aGlzIHRpbWVsaW5lKSwgaXQgc2hvdWxkIHJlbmRlciBhdCBpdHMgYmVnaW5uaW5nLiBTcGVjaWFsIGNhc2U6IGlmIGl0J3MgYSB0aW1lbGluZSAoaGFzIC5hZGQoKSBtZXRob2QpIGFuZCBubyBkdXJhdGlvbiwgd2UgY2FuIHNraXAgcmVuZGVyaW5nIGJlY2F1c2UgdGhlIHVzZXIgbWF5IGJlIHBvcHVsYXRpbmcgaXQgQUZURVIgYWRkaW5nIGl0IHRvIGEgcGFyZW50IHRpbWVsaW5lICh1bmNvbnZlbnRpb25hbCwgYnV0IHBvc3NpYmxlLCBhbmQgd2Ugd291bGRuJ3Qgd2FudCBpdCB0byBnZXQgcmVtb3ZlZCBpZiB0aGUgcGFyZW50J3MgYXV0b1JlbW92ZUNoaWxkcmVuIGlzIHRydWUpLlxuICAgIHQgPSBfcGFyZW50VG9DaGlsZFRvdGFsVGltZSh0aW1lbGluZS5yYXdUaW1lKCksIGNoaWxkKTtcblxuICAgIGlmICghY2hpbGQuX2R1ciB8fCBfY2xhbXAoMCwgY2hpbGQudG90YWxEdXJhdGlvbigpLCB0KSAtIGNoaWxkLl90VGltZSA+IF90aW55TnVtKSB7XG4gICAgICBjaGlsZC5yZW5kZXIodCwgdHJ1ZSk7XG4gICAgfVxuICB9IC8vaWYgdGhlIHRpbWVsaW5lIGhhcyBhbHJlYWR5IGVuZGVkIGJ1dCB0aGUgaW5zZXJ0ZWQgdHdlZW4vdGltZWxpbmUgZXh0ZW5kcyB0aGUgZHVyYXRpb24sIHdlIHNob3VsZCBlbmFibGUgdGhpcyB0aW1lbGluZSBhZ2FpbiBzbyB0aGF0IGl0IHJlbmRlcnMgcHJvcGVybHkuIFdlIHNob3VsZCBhbHNvIGFsaWduIHRoZSBwbGF5aGVhZCB3aXRoIHRoZSBwYXJlbnQgdGltZWxpbmUncyB3aGVuIGFwcHJvcHJpYXRlLlxuXG5cbiAgaWYgKF91bmNhY2hlKHRpbWVsaW5lLCBjaGlsZCkuX2RwICYmIHRpbWVsaW5lLl9pbml0dGVkICYmIHRpbWVsaW5lLl90aW1lID49IHRpbWVsaW5lLl9kdXIgJiYgdGltZWxpbmUuX3RzKSB7XG4gICAgLy9pbiBjYXNlIGFueSBvZiB0aGUgYW5jZXN0b3JzIGhhZCBjb21wbGV0ZWQgYnV0IHNob3VsZCBub3cgYmUgZW5hYmxlZC4uLlxuICAgIGlmICh0aW1lbGluZS5fZHVyIDwgdGltZWxpbmUuZHVyYXRpb24oKSkge1xuICAgICAgdCA9IHRpbWVsaW5lO1xuXG4gICAgICB3aGlsZSAodC5fZHApIHtcbiAgICAgICAgdC5yYXdUaW1lKCkgPj0gMCAmJiB0LnRvdGFsVGltZSh0Ll90VGltZSk7IC8vbW92ZXMgdGhlIHRpbWVsaW5lIChzaGlmdHMgaXRzIHN0YXJ0VGltZSkgaWYgbmVjZXNzYXJ5LCBhbmQgYWxzbyBlbmFibGVzIGl0LiBJZiBpdCdzIGN1cnJlbnRseSB6ZXJvLCB0aG91Z2gsIGl0IG1heSBub3QgYmUgc2NoZWR1bGVkIHRvIHJlbmRlciB1bnRpbCBsYXRlciBzbyB0aGVyZSdzIG5vIG5lZWQgdG8gZm9yY2UgaXQgdG8gYWxpZ24gd2l0aCB0aGUgY3VycmVudCBwbGF5aGVhZCBwb3NpdGlvbi4gT25seSBtb3ZlIHRvIGNhdGNoIHVwIHdpdGggdGhlIHBsYXloZWFkLlxuXG4gICAgICAgIHQgPSB0Ll9kcDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aW1lbGluZS5felRpbWUgPSAtX3RpbnlOdW07IC8vIGhlbHBzIGVuc3VyZSB0aGF0IHRoZSBuZXh0IHJlbmRlcigpIHdpbGwgYmUgZm9yY2VkIChjcm9zc2luZ1N0YXJ0ID0gdHJ1ZSBpbiByZW5kZXIoKSksIGV2ZW4gaWYgdGhlIGR1cmF0aW9uIGhhc24ndCBjaGFuZ2VkICh3ZSdyZSBhZGRpbmcgYSBjaGlsZCB3aGljaCB3b3VsZCBuZWVkIHRvIGdldCByZW5kZXJlZCkuIERlZmluaXRlbHkgYW4gZWRnZSBjYXNlLiBOb3RlOiB3ZSBNVVNUIGRvIHRoaXMgQUZURVIgdGhlIGxvb3AgYWJvdmUgd2hlcmUgdGhlIHRvdGFsVGltZSgpIG1pZ2h0IHRyaWdnZXIgYSByZW5kZXIoKSBiZWNhdXNlIHRoaXMgX2FkZFRvVGltZWxpbmUoKSBtZXRob2QgZ2V0cyBjYWxsZWQgZnJvbSB0aGUgQW5pbWF0aW9uIGNvbnN0cnVjdG9yLCBCRUZPUkUgdHdlZW5zIGV2ZW4gcmVjb3JkIHRoZWlyIHRhcmdldHMsIGV0Yy4gc28gd2Ugd291bGRuJ3Qgd2FudCB0aGluZ3MgdG8gZ2V0IHRyaWdnZXJlZCBpbiB0aGUgd3Jvbmcgb3JkZXIuXG4gIH1cbn0sXG4gICAgX2FkZFRvVGltZWxpbmUgPSBmdW5jdGlvbiBfYWRkVG9UaW1lbGluZSh0aW1lbGluZSwgY2hpbGQsIHBvc2l0aW9uLCBza2lwQ2hlY2tzKSB7XG4gIGNoaWxkLnBhcmVudCAmJiBfcmVtb3ZlRnJvbVBhcmVudChjaGlsZCk7XG4gIGNoaWxkLl9zdGFydCA9IF9yb3VuZFByZWNpc2UoKF9pc051bWJlcihwb3NpdGlvbikgPyBwb3NpdGlvbiA6IHBvc2l0aW9uIHx8IHRpbWVsaW5lICE9PSBfZ2xvYmFsVGltZWxpbmUgPyBfcGFyc2VQb3NpdGlvbih0aW1lbGluZSwgcG9zaXRpb24sIGNoaWxkKSA6IHRpbWVsaW5lLl90aW1lKSArIGNoaWxkLl9kZWxheSk7XG4gIGNoaWxkLl9lbmQgPSBfcm91bmRQcmVjaXNlKGNoaWxkLl9zdGFydCArIChjaGlsZC50b3RhbER1cmF0aW9uKCkgLyBNYXRoLmFicyhjaGlsZC50aW1lU2NhbGUoKSkgfHwgMCkpO1xuXG4gIF9hZGRMaW5rZWRMaXN0SXRlbSh0aW1lbGluZSwgY2hpbGQsIFwiX2ZpcnN0XCIsIFwiX2xhc3RcIiwgdGltZWxpbmUuX3NvcnQgPyBcIl9zdGFydFwiIDogMCk7XG5cbiAgX2lzRnJvbU9yRnJvbVN0YXJ0KGNoaWxkKSB8fCAodGltZWxpbmUuX3JlY2VudCA9IGNoaWxkKTtcbiAgc2tpcENoZWNrcyB8fCBfcG9zdEFkZENoZWNrcyh0aW1lbGluZSwgY2hpbGQpO1xuICB0aW1lbGluZS5fdHMgPCAwICYmIF9hbGlnblBsYXloZWFkKHRpbWVsaW5lLCB0aW1lbGluZS5fdFRpbWUpOyAvLyBpZiB0aGUgdGltZWxpbmUgaXMgcmV2ZXJzZWQgYW5kIHRoZSBuZXcgY2hpbGQgbWFrZXMgaXQgbG9uZ2VyLCB3ZSBtYXkgbmVlZCB0byBhZGp1c3QgdGhlIHBhcmVudCdzIF9zdGFydCAocHVzaCBpdCBiYWNrKVxuXG4gIHJldHVybiB0aW1lbGluZTtcbn0sXG4gICAgX3Njcm9sbFRyaWdnZXIgPSBmdW5jdGlvbiBfc2Nyb2xsVHJpZ2dlcihhbmltYXRpb24sIHRyaWdnZXIpIHtcbiAgcmV0dXJuIChfZ2xvYmFscy5TY3JvbGxUcmlnZ2VyIHx8IF9taXNzaW5nUGx1Z2luKFwic2Nyb2xsVHJpZ2dlclwiLCB0cmlnZ2VyKSkgJiYgX2dsb2JhbHMuU2Nyb2xsVHJpZ2dlci5jcmVhdGUodHJpZ2dlciwgYW5pbWF0aW9uKTtcbn0sXG4gICAgX2F0dGVtcHRJbml0VHdlZW4gPSBmdW5jdGlvbiBfYXR0ZW1wdEluaXRUd2Vlbih0d2VlbiwgdGltZSwgZm9yY2UsIHN1cHByZXNzRXZlbnRzLCB0VGltZSkge1xuICBfaW5pdFR3ZWVuKHR3ZWVuLCB0aW1lLCB0VGltZSk7XG5cbiAgaWYgKCF0d2Vlbi5faW5pdHRlZCkge1xuICAgIHJldHVybiAxO1xuICB9XG5cbiAgaWYgKCFmb3JjZSAmJiB0d2Vlbi5fcHQgJiYgIV9yZXZlcnRpbmcgJiYgKHR3ZWVuLl9kdXIgJiYgdHdlZW4udmFycy5sYXp5ICE9PSBmYWxzZSB8fCAhdHdlZW4uX2R1ciAmJiB0d2Vlbi52YXJzLmxhenkpICYmIF9sYXN0UmVuZGVyZWRGcmFtZSAhPT0gX3RpY2tlci5mcmFtZSkge1xuICAgIF9sYXp5VHdlZW5zLnB1c2godHdlZW4pO1xuXG4gICAgdHdlZW4uX2xhenkgPSBbdFRpbWUsIHN1cHByZXNzRXZlbnRzXTtcbiAgICByZXR1cm4gMTtcbiAgfVxufSxcbiAgICBfcGFyZW50UGxheWhlYWRJc0JlZm9yZVN0YXJ0ID0gZnVuY3Rpb24gX3BhcmVudFBsYXloZWFkSXNCZWZvcmVTdGFydChfcmVmKSB7XG4gIHZhciBwYXJlbnQgPSBfcmVmLnBhcmVudDtcbiAgcmV0dXJuIHBhcmVudCAmJiBwYXJlbnQuX3RzICYmIHBhcmVudC5faW5pdHRlZCAmJiAhcGFyZW50Ll9sb2NrICYmIChwYXJlbnQucmF3VGltZSgpIDwgMCB8fCBfcGFyZW50UGxheWhlYWRJc0JlZm9yZVN0YXJ0KHBhcmVudCkpO1xufSxcbiAgICAvLyBjaGVjayBwYXJlbnQncyBfbG9jayBiZWNhdXNlIHdoZW4gYSB0aW1lbGluZSByZXBlYXRzL3lveW9zIGFuZCBkb2VzIGl0cyBhcnRpZmljaWFsIHdyYXBwaW5nLCB3ZSBzaG91bGRuJ3QgZm9yY2UgdGhlIHJhdGlvIGJhY2sgdG8gMFxuX2lzRnJvbU9yRnJvbVN0YXJ0ID0gZnVuY3Rpb24gX2lzRnJvbU9yRnJvbVN0YXJ0KF9yZWYyKSB7XG4gIHZhciBkYXRhID0gX3JlZjIuZGF0YTtcbiAgcmV0dXJuIGRhdGEgPT09IFwiaXNGcm9tU3RhcnRcIiB8fCBkYXRhID09PSBcImlzU3RhcnRcIjtcbn0sXG4gICAgX3JlbmRlclplcm9EdXJhdGlvblR3ZWVuID0gZnVuY3Rpb24gX3JlbmRlclplcm9EdXJhdGlvblR3ZWVuKHR3ZWVuLCB0b3RhbFRpbWUsIHN1cHByZXNzRXZlbnRzLCBmb3JjZSkge1xuICB2YXIgcHJldlJhdGlvID0gdHdlZW4ucmF0aW8sXG4gICAgICByYXRpbyA9IHRvdGFsVGltZSA8IDAgfHwgIXRvdGFsVGltZSAmJiAoIXR3ZWVuLl9zdGFydCAmJiBfcGFyZW50UGxheWhlYWRJc0JlZm9yZVN0YXJ0KHR3ZWVuKSAmJiAhKCF0d2Vlbi5faW5pdHRlZCAmJiBfaXNGcm9tT3JGcm9tU3RhcnQodHdlZW4pKSB8fCAodHdlZW4uX3RzIDwgMCB8fCB0d2Vlbi5fZHAuX3RzIDwgMCkgJiYgIV9pc0Zyb21PckZyb21TdGFydCh0d2VlbikpID8gMCA6IDEsXG4gICAgICAvLyBpZiB0aGUgdHdlZW4gb3IgaXRzIHBhcmVudCBpcyByZXZlcnNlZCBhbmQgdGhlIHRvdGFsVGltZSBpcyAwLCB3ZSBzaG91bGQgZ28gdG8gYSByYXRpbyBvZiAwLiBFZGdlIGNhc2U6IGlmIGEgZnJvbSgpIG9yIGZyb21UbygpIHN0YWdnZXIgdHdlZW4gaXMgcGxhY2VkIGxhdGVyIGluIGEgdGltZWxpbmUsIHRoZSBcInN0YXJ0QXRcIiB6ZXJvLWR1cmF0aW9uIHR3ZWVuIGNvdWxkIGluaXRpYWxseSByZW5kZXIgYXQgYSB0aW1lIHdoZW4gdGhlIHBhcmVudCB0aW1lbGluZSdzIHBsYXloZWFkIGlzIHRlY2huaWNhbGx5IEJFRk9SRSB3aGVyZSB0aGlzIHR3ZWVuIGlzLCBzbyBtYWtlIHN1cmUgdGhhdCBhbnkgXCJmcm9tXCIgYW5kIFwiZnJvbVRvXCIgc3RhcnRBdCB0d2VlbnMgYXJlIHJlbmRlcmVkIHRoZSBmaXJzdCB0aW1lIGF0IGEgcmF0aW8gb2YgMS5cbiAgcmVwZWF0RGVsYXkgPSB0d2Vlbi5fckRlbGF5LFxuICAgICAgdFRpbWUgPSAwLFxuICAgICAgcHQsXG4gICAgICBpdGVyYXRpb24sXG4gICAgICBwcmV2SXRlcmF0aW9uO1xuXG4gIGlmIChyZXBlYXREZWxheSAmJiB0d2Vlbi5fcmVwZWF0KSB7XG4gICAgLy8gaW4gY2FzZSB0aGVyZSdzIGEgemVyby1kdXJhdGlvbiB0d2VlbiB0aGF0IGhhcyBhIHJlcGVhdCB3aXRoIGEgcmVwZWF0RGVsYXlcbiAgICB0VGltZSA9IF9jbGFtcCgwLCB0d2Vlbi5fdER1ciwgdG90YWxUaW1lKTtcbiAgICBpdGVyYXRpb24gPSBfYW5pbWF0aW9uQ3ljbGUodFRpbWUsIHJlcGVhdERlbGF5KTtcbiAgICB0d2Vlbi5feW95byAmJiBpdGVyYXRpb24gJiAxICYmIChyYXRpbyA9IDEgLSByYXRpbyk7XG5cbiAgICBpZiAoaXRlcmF0aW9uICE9PSBfYW5pbWF0aW9uQ3ljbGUodHdlZW4uX3RUaW1lLCByZXBlYXREZWxheSkpIHtcbiAgICAgIC8vIGlmIGl0ZXJhdGlvbiBjaGFuZ2VkXG4gICAgICBwcmV2UmF0aW8gPSAxIC0gcmF0aW87XG4gICAgICB0d2Vlbi52YXJzLnJlcGVhdFJlZnJlc2ggJiYgdHdlZW4uX2luaXR0ZWQgJiYgdHdlZW4uaW52YWxpZGF0ZSgpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChyYXRpbyAhPT0gcHJldlJhdGlvIHx8IF9yZXZlcnRpbmcgfHwgZm9yY2UgfHwgdHdlZW4uX3pUaW1lID09PSBfdGlueU51bSB8fCAhdG90YWxUaW1lICYmIHR3ZWVuLl96VGltZSkge1xuICAgIGlmICghdHdlZW4uX2luaXR0ZWQgJiYgX2F0dGVtcHRJbml0VHdlZW4odHdlZW4sIHRvdGFsVGltZSwgZm9yY2UsIHN1cHByZXNzRXZlbnRzLCB0VGltZSkpIHtcbiAgICAgIC8vIGlmIHdlIHJlbmRlciB0aGUgdmVyeSBiZWdpbm5pbmcgKHRpbWUgPT0gMCkgb2YgYSBmcm9tVG8oKSwgd2UgbXVzdCBmb3JjZSB0aGUgcmVuZGVyIChub3JtYWwgdHdlZW5zIHdvdWxkbid0IG5lZWQgdG8gcmVuZGVyIGF0IGEgdGltZSBvZiAwIHdoZW4gdGhlIHByZXZUaW1lIHdhcyBhbHNvIDApLiBUaGlzIGlzIGFsc28gbWFuZGF0b3J5IHRvIG1ha2Ugc3VyZSBvdmVyd3JpdGluZyBraWNrcyBpbiBpbW1lZGlhdGVseS5cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBwcmV2SXRlcmF0aW9uID0gdHdlZW4uX3pUaW1lO1xuICAgIHR3ZWVuLl96VGltZSA9IHRvdGFsVGltZSB8fCAoc3VwcHJlc3NFdmVudHMgPyBfdGlueU51bSA6IDApOyAvLyB3aGVuIHRoZSBwbGF5aGVhZCBhcnJpdmVzIGF0IEVYQUNUTFkgdGltZSAwIChyaWdodCBvbiB0b3ApIG9mIGEgemVyby1kdXJhdGlvbiB0d2Vlbiwgd2UgbmVlZCB0byBkaXNjZXJuIGlmIGV2ZW50cyBhcmUgc3VwcHJlc3NlZCBzbyB0aGF0IHdoZW4gdGhlIHBsYXloZWFkIG1vdmVzIGFnYWluIChuZXh0IHRpbWUpLCBpdCdsbCB0cmlnZ2VyIHRoZSBjYWxsYmFjay4gSWYgZXZlbnRzIGFyZSBOT1Qgc3VwcHJlc3NlZCwgb2J2aW91c2x5IHRoZSBjYWxsYmFjayB3b3VsZCBiZSB0cmlnZ2VyZWQgaW4gdGhpcyByZW5kZXIuIEJhc2ljYWxseSwgdGhlIGNhbGxiYWNrIHNob3VsZCBmaXJlIGVpdGhlciB3aGVuIHRoZSBwbGF5aGVhZCBBUlJJVkVTIG9yIExFQVZFUyB0aGlzIGV4YWN0IHNwb3QsIG5vdCBib3RoLiBJbWFnaW5lIGRvaW5nIGEgdGltZWxpbmUuc2VlaygwKSBhbmQgdGhlcmUncyBhIGNhbGxiYWNrIHRoYXQgc2l0cyBhdCAwLiBTaW5jZSBldmVudHMgYXJlIHN1cHByZXNzZWQgb24gdGhhdCBzZWVrKCkgYnkgZGVmYXVsdCwgbm90aGluZyB3aWxsIGZpcmUsIGJ1dCB3aGVuIHRoZSBwbGF5aGVhZCBtb3ZlcyBvZmYgb2YgdGhhdCBwb3NpdGlvbiwgdGhlIGNhbGxiYWNrIHNob3VsZCBmaXJlLiBUaGlzIGJlaGF2aW9yIGlzIHdoYXQgcGVvcGxlIGludHVpdGl2ZWx5IGV4cGVjdC5cblxuICAgIHN1cHByZXNzRXZlbnRzIHx8IChzdXBwcmVzc0V2ZW50cyA9IHRvdGFsVGltZSAmJiAhcHJldkl0ZXJhdGlvbik7IC8vIGlmIGl0IHdhcyByZW5kZXJlZCBwcmV2aW91c2x5IGF0IGV4YWN0bHkgMCAoX3pUaW1lKSBhbmQgbm93IHRoZSBwbGF5aGVhZCBpcyBtb3ZpbmcgYXdheSwgRE9OJ1QgZmlyZSBjYWxsYmFja3Mgb3RoZXJ3aXNlIHRoZXknbGwgc2VlbSBsaWtlIGR1cGxpY2F0ZXMuXG5cbiAgICB0d2Vlbi5yYXRpbyA9IHJhdGlvO1xuICAgIHR3ZWVuLl9mcm9tICYmIChyYXRpbyA9IDEgLSByYXRpbyk7XG4gICAgdHdlZW4uX3RpbWUgPSAwO1xuICAgIHR3ZWVuLl90VGltZSA9IHRUaW1lO1xuICAgIHB0ID0gdHdlZW4uX3B0O1xuXG4gICAgd2hpbGUgKHB0KSB7XG4gICAgICBwdC5yKHJhdGlvLCBwdC5kKTtcbiAgICAgIHB0ID0gcHQuX25leHQ7XG4gICAgfVxuXG4gICAgdG90YWxUaW1lIDwgMCAmJiBfcmV3aW5kU3RhcnRBdCh0d2VlbiwgdG90YWxUaW1lLCBzdXBwcmVzc0V2ZW50cywgdHJ1ZSk7XG4gICAgdHdlZW4uX29uVXBkYXRlICYmICFzdXBwcmVzc0V2ZW50cyAmJiBfY2FsbGJhY2sodHdlZW4sIFwib25VcGRhdGVcIik7XG4gICAgdFRpbWUgJiYgdHdlZW4uX3JlcGVhdCAmJiAhc3VwcHJlc3NFdmVudHMgJiYgdHdlZW4ucGFyZW50ICYmIF9jYWxsYmFjayh0d2VlbiwgXCJvblJlcGVhdFwiKTtcblxuICAgIGlmICgodG90YWxUaW1lID49IHR3ZWVuLl90RHVyIHx8IHRvdGFsVGltZSA8IDApICYmIHR3ZWVuLnJhdGlvID09PSByYXRpbykge1xuICAgICAgcmF0aW8gJiYgX3JlbW92ZUZyb21QYXJlbnQodHdlZW4sIDEpO1xuXG4gICAgICBpZiAoIXN1cHByZXNzRXZlbnRzICYmICFfcmV2ZXJ0aW5nKSB7XG4gICAgICAgIF9jYWxsYmFjayh0d2VlbiwgcmF0aW8gPyBcIm9uQ29tcGxldGVcIiA6IFwib25SZXZlcnNlQ29tcGxldGVcIiwgdHJ1ZSk7XG5cbiAgICAgICAgdHdlZW4uX3Byb20gJiYgdHdlZW4uX3Byb20oKTtcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSBpZiAoIXR3ZWVuLl96VGltZSkge1xuICAgIHR3ZWVuLl96VGltZSA9IHRvdGFsVGltZTtcbiAgfVxufSxcbiAgICBfZmluZE5leHRQYXVzZVR3ZWVuID0gZnVuY3Rpb24gX2ZpbmROZXh0UGF1c2VUd2VlbihhbmltYXRpb24sIHByZXZUaW1lLCB0aW1lKSB7XG4gIHZhciBjaGlsZDtcblxuICBpZiAodGltZSA+IHByZXZUaW1lKSB7XG4gICAgY2hpbGQgPSBhbmltYXRpb24uX2ZpcnN0O1xuXG4gICAgd2hpbGUgKGNoaWxkICYmIGNoaWxkLl9zdGFydCA8PSB0aW1lKSB7XG4gICAgICBpZiAoY2hpbGQuZGF0YSA9PT0gXCJpc1BhdXNlXCIgJiYgY2hpbGQuX3N0YXJ0ID4gcHJldlRpbWUpIHtcbiAgICAgICAgcmV0dXJuIGNoaWxkO1xuICAgICAgfVxuXG4gICAgICBjaGlsZCA9IGNoaWxkLl9uZXh0O1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBjaGlsZCA9IGFuaW1hdGlvbi5fbGFzdDtcblxuICAgIHdoaWxlIChjaGlsZCAmJiBjaGlsZC5fc3RhcnQgPj0gdGltZSkge1xuICAgICAgaWYgKGNoaWxkLmRhdGEgPT09IFwiaXNQYXVzZVwiICYmIGNoaWxkLl9zdGFydCA8IHByZXZUaW1lKSB7XG4gICAgICAgIHJldHVybiBjaGlsZDtcbiAgICAgIH1cblxuICAgICAgY2hpbGQgPSBjaGlsZC5fcHJldjtcbiAgICB9XG4gIH1cbn0sXG4gICAgX3NldER1cmF0aW9uID0gZnVuY3Rpb24gX3NldER1cmF0aW9uKGFuaW1hdGlvbiwgZHVyYXRpb24sIHNraXBVbmNhY2hlLCBsZWF2ZVBsYXloZWFkKSB7XG4gIHZhciByZXBlYXQgPSBhbmltYXRpb24uX3JlcGVhdCxcbiAgICAgIGR1ciA9IF9yb3VuZFByZWNpc2UoZHVyYXRpb24pIHx8IDAsXG4gICAgICB0b3RhbFByb2dyZXNzID0gYW5pbWF0aW9uLl90VGltZSAvIGFuaW1hdGlvbi5fdER1cjtcbiAgdG90YWxQcm9ncmVzcyAmJiAhbGVhdmVQbGF5aGVhZCAmJiAoYW5pbWF0aW9uLl90aW1lICo9IGR1ciAvIGFuaW1hdGlvbi5fZHVyKTtcbiAgYW5pbWF0aW9uLl9kdXIgPSBkdXI7XG4gIGFuaW1hdGlvbi5fdER1ciA9ICFyZXBlYXQgPyBkdXIgOiByZXBlYXQgPCAwID8gMWUxMCA6IF9yb3VuZFByZWNpc2UoZHVyICogKHJlcGVhdCArIDEpICsgYW5pbWF0aW9uLl9yRGVsYXkgKiByZXBlYXQpO1xuICB0b3RhbFByb2dyZXNzID4gMCAmJiAhbGVhdmVQbGF5aGVhZCAmJiBfYWxpZ25QbGF5aGVhZChhbmltYXRpb24sIGFuaW1hdGlvbi5fdFRpbWUgPSBhbmltYXRpb24uX3REdXIgKiB0b3RhbFByb2dyZXNzKTtcbiAgYW5pbWF0aW9uLnBhcmVudCAmJiBfc2V0RW5kKGFuaW1hdGlvbik7XG4gIHNraXBVbmNhY2hlIHx8IF91bmNhY2hlKGFuaW1hdGlvbi5wYXJlbnQsIGFuaW1hdGlvbik7XG4gIHJldHVybiBhbmltYXRpb247XG59LFxuICAgIF9vblVwZGF0ZVRvdGFsRHVyYXRpb24gPSBmdW5jdGlvbiBfb25VcGRhdGVUb3RhbER1cmF0aW9uKGFuaW1hdGlvbikge1xuICByZXR1cm4gYW5pbWF0aW9uIGluc3RhbmNlb2YgVGltZWxpbmUgPyBfdW5jYWNoZShhbmltYXRpb24pIDogX3NldER1cmF0aW9uKGFuaW1hdGlvbiwgYW5pbWF0aW9uLl9kdXIpO1xufSxcbiAgICBfemVyb1Bvc2l0aW9uID0ge1xuICBfc3RhcnQ6IDAsXG4gIGVuZFRpbWU6IF9lbXB0eUZ1bmMsXG4gIHRvdGFsRHVyYXRpb246IF9lbXB0eUZ1bmNcbn0sXG4gICAgX3BhcnNlUG9zaXRpb24gPSBmdW5jdGlvbiBfcGFyc2VQb3NpdGlvbihhbmltYXRpb24sIHBvc2l0aW9uLCBwZXJjZW50QW5pbWF0aW9uKSB7XG4gIHZhciBsYWJlbHMgPSBhbmltYXRpb24ubGFiZWxzLFxuICAgICAgcmVjZW50ID0gYW5pbWF0aW9uLl9yZWNlbnQgfHwgX3plcm9Qb3NpdGlvbixcbiAgICAgIGNsaXBwZWREdXJhdGlvbiA9IGFuaW1hdGlvbi5kdXJhdGlvbigpID49IF9iaWdOdW0gPyByZWNlbnQuZW5kVGltZShmYWxzZSkgOiBhbmltYXRpb24uX2R1cixcbiAgICAgIC8vaW4gY2FzZSB0aGVyZSdzIGEgY2hpbGQgdGhhdCBpbmZpbml0ZWx5IHJlcGVhdHMsIHVzZXJzIGFsbW9zdCBuZXZlciBpbnRlbmQgZm9yIHRoZSBpbnNlcnRpb24gcG9pbnQgb2YgYSBuZXcgY2hpbGQgdG8gYmUgYmFzZWQgb24gYSBTVVBFUiBsb25nIHZhbHVlIGxpa2UgdGhhdCBzbyB3ZSBjbGlwIGl0IGFuZCBhc3N1bWUgdGhlIG1vc3QgcmVjZW50bHktYWRkZWQgY2hpbGQncyBlbmRUaW1lIHNob3VsZCBiZSB1c2VkIGluc3RlYWQuXG4gIGksXG4gICAgICBvZmZzZXQsXG4gICAgICBpc1BlcmNlbnQ7XG5cbiAgaWYgKF9pc1N0cmluZyhwb3NpdGlvbikgJiYgKGlzTmFOKHBvc2l0aW9uKSB8fCBwb3NpdGlvbiBpbiBsYWJlbHMpKSB7XG4gICAgLy9pZiB0aGUgc3RyaW5nIGlzIGEgbnVtYmVyIGxpa2UgXCIxXCIsIGNoZWNrIHRvIHNlZSBpZiB0aGVyZSdzIGEgbGFiZWwgd2l0aCB0aGF0IG5hbWUsIG90aGVyd2lzZSBpbnRlcnByZXQgaXQgYXMgYSBudW1iZXIgKGFic29sdXRlIHZhbHVlKS5cbiAgICBvZmZzZXQgPSBwb3NpdGlvbi5jaGFyQXQoMCk7XG4gICAgaXNQZXJjZW50ID0gcG9zaXRpb24uc3Vic3RyKC0xKSA9PT0gXCIlXCI7XG4gICAgaSA9IHBvc2l0aW9uLmluZGV4T2YoXCI9XCIpO1xuXG4gICAgaWYgKG9mZnNldCA9PT0gXCI8XCIgfHwgb2Zmc2V0ID09PSBcIj5cIikge1xuICAgICAgaSA+PSAwICYmIChwb3NpdGlvbiA9IHBvc2l0aW9uLnJlcGxhY2UoLz0vLCBcIlwiKSk7XG4gICAgICByZXR1cm4gKG9mZnNldCA9PT0gXCI8XCIgPyByZWNlbnQuX3N0YXJ0IDogcmVjZW50LmVuZFRpbWUocmVjZW50Ll9yZXBlYXQgPj0gMCkpICsgKHBhcnNlRmxvYXQocG9zaXRpb24uc3Vic3RyKDEpKSB8fCAwKSAqIChpc1BlcmNlbnQgPyAoaSA8IDAgPyByZWNlbnQgOiBwZXJjZW50QW5pbWF0aW9uKS50b3RhbER1cmF0aW9uKCkgLyAxMDAgOiAxKTtcbiAgICB9XG5cbiAgICBpZiAoaSA8IDApIHtcbiAgICAgIHBvc2l0aW9uIGluIGxhYmVscyB8fCAobGFiZWxzW3Bvc2l0aW9uXSA9IGNsaXBwZWREdXJhdGlvbik7XG4gICAgICByZXR1cm4gbGFiZWxzW3Bvc2l0aW9uXTtcbiAgICB9XG5cbiAgICBvZmZzZXQgPSBwYXJzZUZsb2F0KHBvc2l0aW9uLmNoYXJBdChpIC0gMSkgKyBwb3NpdGlvbi5zdWJzdHIoaSArIDEpKTtcblxuICAgIGlmIChpc1BlcmNlbnQgJiYgcGVyY2VudEFuaW1hdGlvbikge1xuICAgICAgb2Zmc2V0ID0gb2Zmc2V0IC8gMTAwICogKF9pc0FycmF5KHBlcmNlbnRBbmltYXRpb24pID8gcGVyY2VudEFuaW1hdGlvblswXSA6IHBlcmNlbnRBbmltYXRpb24pLnRvdGFsRHVyYXRpb24oKTtcbiAgICB9XG5cbiAgICByZXR1cm4gaSA+IDEgPyBfcGFyc2VQb3NpdGlvbihhbmltYXRpb24sIHBvc2l0aW9uLnN1YnN0cigwLCBpIC0gMSksIHBlcmNlbnRBbmltYXRpb24pICsgb2Zmc2V0IDogY2xpcHBlZER1cmF0aW9uICsgb2Zmc2V0O1xuICB9XG5cbiAgcmV0dXJuIHBvc2l0aW9uID09IG51bGwgPyBjbGlwcGVkRHVyYXRpb24gOiArcG9zaXRpb247XG59LFxuICAgIF9jcmVhdGVUd2VlblR5cGUgPSBmdW5jdGlvbiBfY3JlYXRlVHdlZW5UeXBlKHR5cGUsIHBhcmFtcywgdGltZWxpbmUpIHtcbiAgdmFyIGlzTGVnYWN5ID0gX2lzTnVtYmVyKHBhcmFtc1sxXSksXG4gICAgICB2YXJzSW5kZXggPSAoaXNMZWdhY3kgPyAyIDogMSkgKyAodHlwZSA8IDIgPyAwIDogMSksXG4gICAgICB2YXJzID0gcGFyYW1zW3ZhcnNJbmRleF0sXG4gICAgICBpclZhcnMsXG4gICAgICBwYXJlbnQ7XG5cbiAgaXNMZWdhY3kgJiYgKHZhcnMuZHVyYXRpb24gPSBwYXJhbXNbMV0pO1xuICB2YXJzLnBhcmVudCA9IHRpbWVsaW5lO1xuXG4gIGlmICh0eXBlKSB7XG4gICAgaXJWYXJzID0gdmFycztcbiAgICBwYXJlbnQgPSB0aW1lbGluZTtcblxuICAgIHdoaWxlIChwYXJlbnQgJiYgIShcImltbWVkaWF0ZVJlbmRlclwiIGluIGlyVmFycykpIHtcbiAgICAgIC8vIGluaGVyaXRhbmNlIGhhc24ndCBoYXBwZW5lZCB5ZXQsIGJ1dCBzb21lb25lIG1heSBoYXZlIHNldCBhIGRlZmF1bHQgaW4gYW4gYW5jZXN0b3IgdGltZWxpbmUuIFdlIGNvdWxkIGRvIHZhcnMuaW1tZWRpYXRlUmVuZGVyID0gX2lzTm90RmFsc2UoX2luaGVyaXREZWZhdWx0cyh2YXJzKS5pbW1lZGlhdGVSZW5kZXIpIGJ1dCB0aGF0J2QgZXhhY3QgYSBzbGlnaHQgcGVyZm9ybWFuY2UgcGVuYWx0eSBiZWNhdXNlIF9pbmhlcml0RGVmYXVsdHMoKSBhbHNvIHJ1bnMgaW4gdGhlIFR3ZWVuIGNvbnN0cnVjdG9yLiBXZSdyZSBwYXlpbmcgYSBzbWFsbCBrYiBwcmljZSBoZXJlIHRvIGdhaW4gc3BlZWQuXG4gICAgICBpclZhcnMgPSBwYXJlbnQudmFycy5kZWZhdWx0cyB8fCB7fTtcbiAgICAgIHBhcmVudCA9IF9pc05vdEZhbHNlKHBhcmVudC52YXJzLmluaGVyaXQpICYmIHBhcmVudC5wYXJlbnQ7XG4gICAgfVxuXG4gICAgdmFycy5pbW1lZGlhdGVSZW5kZXIgPSBfaXNOb3RGYWxzZShpclZhcnMuaW1tZWRpYXRlUmVuZGVyKTtcbiAgICB0eXBlIDwgMiA/IHZhcnMucnVuQmFja3dhcmRzID0gMSA6IHZhcnMuc3RhcnRBdCA9IHBhcmFtc1t2YXJzSW5kZXggLSAxXTsgLy8gXCJmcm9tXCIgdmFyc1xuICB9XG5cbiAgcmV0dXJuIG5ldyBUd2VlbihwYXJhbXNbMF0sIHZhcnMsIHBhcmFtc1t2YXJzSW5kZXggKyAxXSk7XG59LFxuICAgIF9jb25kaXRpb25hbFJldHVybiA9IGZ1bmN0aW9uIF9jb25kaXRpb25hbFJldHVybih2YWx1ZSwgZnVuYykge1xuICByZXR1cm4gdmFsdWUgfHwgdmFsdWUgPT09IDAgPyBmdW5jKHZhbHVlKSA6IGZ1bmM7XG59LFxuICAgIF9jbGFtcCA9IGZ1bmN0aW9uIF9jbGFtcChtaW4sIG1heCwgdmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlIDwgbWluID8gbWluIDogdmFsdWUgPiBtYXggPyBtYXggOiB2YWx1ZTtcbn0sXG4gICAgZ2V0VW5pdCA9IGZ1bmN0aW9uIGdldFVuaXQodmFsdWUsIHYpIHtcbiAgcmV0dXJuICFfaXNTdHJpbmcodmFsdWUpIHx8ICEodiA9IF91bml0RXhwLmV4ZWModmFsdWUpKSA/IFwiXCIgOiB2WzFdO1xufSxcbiAgICAvLyBub3RlOiBwcm90ZWN0IGFnYWluc3QgcGFkZGVkIG51bWJlcnMgYXMgc3RyaW5ncywgbGlrZSBcIjEwMC4xMDBcIi4gVGhhdCBzaG91bGRuJ3QgcmV0dXJuIFwiMDBcIiBhcyB0aGUgdW5pdC4gSWYgaXQncyBudW1lcmljLCByZXR1cm4gbm8gdW5pdC5cbmNsYW1wID0gZnVuY3Rpb24gY2xhbXAobWluLCBtYXgsIHZhbHVlKSB7XG4gIHJldHVybiBfY29uZGl0aW9uYWxSZXR1cm4odmFsdWUsIGZ1bmN0aW9uICh2KSB7XG4gICAgcmV0dXJuIF9jbGFtcChtaW4sIG1heCwgdik7XG4gIH0pO1xufSxcbiAgICBfc2xpY2UgPSBbXS5zbGljZSxcbiAgICBfaXNBcnJheUxpa2UgPSBmdW5jdGlvbiBfaXNBcnJheUxpa2UodmFsdWUsIG5vbkVtcHR5KSB7XG4gIHJldHVybiB2YWx1ZSAmJiBfaXNPYmplY3QodmFsdWUpICYmIFwibGVuZ3RoXCIgaW4gdmFsdWUgJiYgKCFub25FbXB0eSAmJiAhdmFsdWUubGVuZ3RoIHx8IHZhbHVlLmxlbmd0aCAtIDEgaW4gdmFsdWUgJiYgX2lzT2JqZWN0KHZhbHVlWzBdKSkgJiYgIXZhbHVlLm5vZGVUeXBlICYmIHZhbHVlICE9PSBfd2luO1xufSxcbiAgICBfZmxhdHRlbiA9IGZ1bmN0aW9uIF9mbGF0dGVuKGFyLCBsZWF2ZVN0cmluZ3MsIGFjY3VtdWxhdG9yKSB7XG4gIGlmIChhY2N1bXVsYXRvciA9PT0gdm9pZCAwKSB7XG4gICAgYWNjdW11bGF0b3IgPSBbXTtcbiAgfVxuXG4gIHJldHVybiBhci5mb3JFYWNoKGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIHZhciBfYWNjdW11bGF0b3I7XG5cbiAgICByZXR1cm4gX2lzU3RyaW5nKHZhbHVlKSAmJiAhbGVhdmVTdHJpbmdzIHx8IF9pc0FycmF5TGlrZSh2YWx1ZSwgMSkgPyAoX2FjY3VtdWxhdG9yID0gYWNjdW11bGF0b3IpLnB1c2guYXBwbHkoX2FjY3VtdWxhdG9yLCB0b0FycmF5KHZhbHVlKSkgOiBhY2N1bXVsYXRvci5wdXNoKHZhbHVlKTtcbiAgfSkgfHwgYWNjdW11bGF0b3I7XG59LFxuICAgIC8vIHRha2VzIGFueSB2YWx1ZSBhbmQgcmV0dXJucyBhbiBBcnJheS4gSWYgaXQncyBhIHN0cmluZyAoYW5kIGxlYXZlU3RyaW5ncyBpc24ndCB0cnVlKSwgaXQnbGwgdXNlIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoKSBhbmQgY29udmVydCB0aGF0IHRvIGFuIGFycmF5LiBJdCdsbCBhbHNvIGFjY2VwdCBpdGVyYWJsZXMgbGlrZSBqUXVlcnkgb2JqZWN0cy5cbnRvQXJyYXkgPSBmdW5jdGlvbiB0b0FycmF5KHZhbHVlLCBzY29wZSwgbGVhdmVTdHJpbmdzKSB7XG4gIHJldHVybiBfY29udGV4dCAmJiAhc2NvcGUgJiYgX2NvbnRleHQuc2VsZWN0b3IgPyBfY29udGV4dC5zZWxlY3Rvcih2YWx1ZSkgOiBfaXNTdHJpbmcodmFsdWUpICYmICFsZWF2ZVN0cmluZ3MgJiYgKF9jb3JlSW5pdHRlZCB8fCAhX3dha2UoKSkgPyBfc2xpY2UuY2FsbCgoc2NvcGUgfHwgX2RvYykucXVlcnlTZWxlY3RvckFsbCh2YWx1ZSksIDApIDogX2lzQXJyYXkodmFsdWUpID8gX2ZsYXR0ZW4odmFsdWUsIGxlYXZlU3RyaW5ncykgOiBfaXNBcnJheUxpa2UodmFsdWUpID8gX3NsaWNlLmNhbGwodmFsdWUsIDApIDogdmFsdWUgPyBbdmFsdWVdIDogW107XG59LFxuICAgIHNlbGVjdG9yID0gZnVuY3Rpb24gc2VsZWN0b3IodmFsdWUpIHtcbiAgdmFsdWUgPSB0b0FycmF5KHZhbHVlKVswXSB8fCBfd2FybihcIkludmFsaWQgc2NvcGVcIikgfHwge307XG4gIHJldHVybiBmdW5jdGlvbiAodikge1xuICAgIHZhciBlbCA9IHZhbHVlLmN1cnJlbnQgfHwgdmFsdWUubmF0aXZlRWxlbWVudCB8fCB2YWx1ZTtcbiAgICByZXR1cm4gdG9BcnJheSh2LCBlbC5xdWVyeVNlbGVjdG9yQWxsID8gZWwgOiBlbCA9PT0gdmFsdWUgPyBfd2FybihcIkludmFsaWQgc2NvcGVcIikgfHwgX2RvYy5jcmVhdGVFbGVtZW50KFwiZGl2XCIpIDogdmFsdWUpO1xuICB9O1xufSxcbiAgICBzaHVmZmxlID0gZnVuY3Rpb24gc2h1ZmZsZShhKSB7XG4gIHJldHVybiBhLnNvcnQoZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiAuNSAtIE1hdGgucmFuZG9tKCk7XG4gIH0pO1xufSxcbiAgICAvLyBhbHRlcm5hdGl2ZSB0aGF0J3MgYSBiaXQgZmFzdGVyIGFuZCBtb3JlIHJlbGlhYmx5IGRpdmVyc2UgYnV0IGJpZ2dlcjogICBmb3IgKGxldCBqLCB2LCBpID0gYS5sZW5ndGg7IGk7IGogPSAoTWF0aC5yYW5kb20oKSAqIGkpIHwgMCwgdiA9IGFbLS1pXSwgYVtpXSA9IGFbal0sIGFbal0gPSB2KTsgcmV0dXJuIGE7XG4vLyBmb3IgZGlzdHJpYnV0aW5nIHZhbHVlcyBhY3Jvc3MgYW4gQXJyYXkuIENhbiBhY2NlcHQgYSBudW1iZXIsIGEgZnVuY3Rpb24gb3IgKG1vc3QgY29tbW9ubHkpIGFuIG9iamVjdCB3aGljaCBjYW4gY29udGFpbiB0aGUgZm9sbG93aW5nIHByb3BlcnRpZXM6IHtiYXNlLCBhbW91bnQsIGZyb20sIGVhc2UsIGdyaWQsIGF4aXMsIGxlbmd0aCwgZWFjaH0uIFJldHVybnMgYSBmdW5jdGlvbiB0aGF0IGV4cGVjdHMgdGhlIGZvbGxvd2luZyBwYXJhbWV0ZXJzOiBpbmRleCwgdGFyZ2V0LCBhcnJheS5cbmRpc3RyaWJ1dGUgPSBmdW5jdGlvbiBkaXN0cmlidXRlKHYpIHtcbiAgaWYgKF9pc0Z1bmN0aW9uKHYpKSB7XG4gICAgcmV0dXJuIHY7XG4gIH1cblxuICB2YXIgdmFycyA9IF9pc09iamVjdCh2KSA/IHYgOiB7XG4gICAgZWFjaDogdlxuICB9LFxuICAgICAgLy9uOjEgaXMganVzdCB0byBpbmRpY2F0ZSB2IHdhcyBhIG51bWJlcjsgd2UgbGV2ZXJhZ2UgdGhhdCBsYXRlciB0byBzZXQgdiBhY2NvcmRpbmcgdG8gdGhlIGxlbmd0aCB3ZSBnZXQuIElmIGEgbnVtYmVyIGlzIHBhc3NlZCBpbiwgd2UgdHJlYXQgaXQgbGlrZSB0aGUgb2xkIHN0YWdnZXIgdmFsdWUgd2hlcmUgMC4xLCBmb3IgZXhhbXBsZSwgd291bGQgbWVhbiB0aGF0IHRoaW5ncyB3b3VsZCBiZSBkaXN0cmlidXRlZCB3aXRoIDAuMSBiZXR3ZWVuIGVhY2ggZWxlbWVudCBpbiB0aGUgYXJyYXkgcmF0aGVyIHRoYW4gYSB0b3RhbCBcImFtb3VudFwiIHRoYXQncyBjaHVua2VkIG91dCBhbW9uZyB0aGVtIGFsbC5cbiAgZWFzZSA9IF9wYXJzZUVhc2UodmFycy5lYXNlKSxcbiAgICAgIGZyb20gPSB2YXJzLmZyb20gfHwgMCxcbiAgICAgIGJhc2UgPSBwYXJzZUZsb2F0KHZhcnMuYmFzZSkgfHwgMCxcbiAgICAgIGNhY2hlID0ge30sXG4gICAgICBpc0RlY2ltYWwgPSBmcm9tID4gMCAmJiBmcm9tIDwgMSxcbiAgICAgIHJhdGlvcyA9IGlzTmFOKGZyb20pIHx8IGlzRGVjaW1hbCxcbiAgICAgIGF4aXMgPSB2YXJzLmF4aXMsXG4gICAgICByYXRpb1ggPSBmcm9tLFxuICAgICAgcmF0aW9ZID0gZnJvbTtcblxuICBpZiAoX2lzU3RyaW5nKGZyb20pKSB7XG4gICAgcmF0aW9YID0gcmF0aW9ZID0ge1xuICAgICAgY2VudGVyOiAuNSxcbiAgICAgIGVkZ2VzOiAuNSxcbiAgICAgIGVuZDogMVxuICAgIH1bZnJvbV0gfHwgMDtcbiAgfSBlbHNlIGlmICghaXNEZWNpbWFsICYmIHJhdGlvcykge1xuICAgIHJhdGlvWCA9IGZyb21bMF07XG4gICAgcmF0aW9ZID0gZnJvbVsxXTtcbiAgfVxuXG4gIHJldHVybiBmdW5jdGlvbiAoaSwgdGFyZ2V0LCBhKSB7XG4gICAgdmFyIGwgPSAoYSB8fCB2YXJzKS5sZW5ndGgsXG4gICAgICAgIGRpc3RhbmNlcyA9IGNhY2hlW2xdLFxuICAgICAgICBvcmlnaW5YLFxuICAgICAgICBvcmlnaW5ZLFxuICAgICAgICB4LFxuICAgICAgICB5LFxuICAgICAgICBkLFxuICAgICAgICBqLFxuICAgICAgICBtYXgsXG4gICAgICAgIG1pbixcbiAgICAgICAgd3JhcEF0O1xuXG4gICAgaWYgKCFkaXN0YW5jZXMpIHtcbiAgICAgIHdyYXBBdCA9IHZhcnMuZ3JpZCA9PT0gXCJhdXRvXCIgPyAwIDogKHZhcnMuZ3JpZCB8fCBbMSwgX2JpZ051bV0pWzFdO1xuXG4gICAgICBpZiAoIXdyYXBBdCkge1xuICAgICAgICBtYXggPSAtX2JpZ051bTtcblxuICAgICAgICB3aGlsZSAobWF4IDwgKG1heCA9IGFbd3JhcEF0KytdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmxlZnQpICYmIHdyYXBBdCA8IGwpIHt9XG5cbiAgICAgICAgd3JhcEF0IDwgbCAmJiB3cmFwQXQtLTtcbiAgICAgIH1cblxuICAgICAgZGlzdGFuY2VzID0gY2FjaGVbbF0gPSBbXTtcbiAgICAgIG9yaWdpblggPSByYXRpb3MgPyBNYXRoLm1pbih3cmFwQXQsIGwpICogcmF0aW9YIC0gLjUgOiBmcm9tICUgd3JhcEF0O1xuICAgICAgb3JpZ2luWSA9IHdyYXBBdCA9PT0gX2JpZ051bSA/IDAgOiByYXRpb3MgPyBsICogcmF0aW9ZIC8gd3JhcEF0IC0gLjUgOiBmcm9tIC8gd3JhcEF0IHwgMDtcbiAgICAgIG1heCA9IDA7XG4gICAgICBtaW4gPSBfYmlnTnVtO1xuXG4gICAgICBmb3IgKGogPSAwOyBqIDwgbDsgaisrKSB7XG4gICAgICAgIHggPSBqICUgd3JhcEF0IC0gb3JpZ2luWDtcbiAgICAgICAgeSA9IG9yaWdpblkgLSAoaiAvIHdyYXBBdCB8IDApO1xuICAgICAgICBkaXN0YW5jZXNbal0gPSBkID0gIWF4aXMgPyBfc3FydCh4ICogeCArIHkgKiB5KSA6IE1hdGguYWJzKGF4aXMgPT09IFwieVwiID8geSA6IHgpO1xuICAgICAgICBkID4gbWF4ICYmIChtYXggPSBkKTtcbiAgICAgICAgZCA8IG1pbiAmJiAobWluID0gZCk7XG4gICAgICB9XG5cbiAgICAgIGZyb20gPT09IFwicmFuZG9tXCIgJiYgc2h1ZmZsZShkaXN0YW5jZXMpO1xuICAgICAgZGlzdGFuY2VzLm1heCA9IG1heCAtIG1pbjtcbiAgICAgIGRpc3RhbmNlcy5taW4gPSBtaW47XG4gICAgICBkaXN0YW5jZXMudiA9IGwgPSAocGFyc2VGbG9hdCh2YXJzLmFtb3VudCkgfHwgcGFyc2VGbG9hdCh2YXJzLmVhY2gpICogKHdyYXBBdCA+IGwgPyBsIC0gMSA6ICFheGlzID8gTWF0aC5tYXgod3JhcEF0LCBsIC8gd3JhcEF0KSA6IGF4aXMgPT09IFwieVwiID8gbCAvIHdyYXBBdCA6IHdyYXBBdCkgfHwgMCkgKiAoZnJvbSA9PT0gXCJlZGdlc1wiID8gLTEgOiAxKTtcbiAgICAgIGRpc3RhbmNlcy5iID0gbCA8IDAgPyBiYXNlIC0gbCA6IGJhc2U7XG4gICAgICBkaXN0YW5jZXMudSA9IGdldFVuaXQodmFycy5hbW91bnQgfHwgdmFycy5lYWNoKSB8fCAwOyAvL3VuaXRcblxuICAgICAgZWFzZSA9IGVhc2UgJiYgbCA8IDAgPyBfaW52ZXJ0RWFzZShlYXNlKSA6IGVhc2U7XG4gICAgfVxuXG4gICAgbCA9IChkaXN0YW5jZXNbaV0gLSBkaXN0YW5jZXMubWluKSAvIGRpc3RhbmNlcy5tYXggfHwgMDtcbiAgICByZXR1cm4gX3JvdW5kUHJlY2lzZShkaXN0YW5jZXMuYiArIChlYXNlID8gZWFzZShsKSA6IGwpICogZGlzdGFuY2VzLnYpICsgZGlzdGFuY2VzLnU7IC8vcm91bmQgaW4gb3JkZXIgdG8gd29yayBhcm91bmQgZmxvYXRpbmcgcG9pbnQgZXJyb3JzXG4gIH07XG59LFxuICAgIF9yb3VuZE1vZGlmaWVyID0gZnVuY3Rpb24gX3JvdW5kTW9kaWZpZXIodikge1xuICAvL3Bhc3MgaW4gMC4xIGdldCBhIGZ1bmN0aW9uIHRoYXQnbGwgcm91bmQgdG8gdGhlIG5lYXJlc3QgdGVudGgsIG9yIDUgdG8gcm91bmQgdG8gdGhlIGNsb3Nlc3QgNSwgb3IgMC4wMDEgdG8gdGhlIGNsb3Nlc3QgMTAwMHRoLCBldGMuXG4gIHZhciBwID0gTWF0aC5wb3coMTAsICgodiArIFwiXCIpLnNwbGl0KFwiLlwiKVsxXSB8fCBcIlwiKS5sZW5ndGgpOyAvL3RvIGF2b2lkIGZsb2F0aW5nIHBvaW50IG1hdGggZXJyb3JzIChsaWtlIDI0ICogMC4xID09IDIuNDAwMDAwMDAwMDAwMDAwNCksIHdlIGNob3Agb2ZmIGF0IGEgc3BlY2lmaWMgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIChtdWNoIGZhc3RlciB0aGFuIHRvRml4ZWQoKSlcblxuICByZXR1cm4gZnVuY3Rpb24gKHJhdykge1xuICAgIHZhciBuID0gX3JvdW5kUHJlY2lzZShNYXRoLnJvdW5kKHBhcnNlRmxvYXQocmF3KSAvIHYpICogdiAqIHApO1xuXG4gICAgcmV0dXJuIChuIC0gbiAlIDEpIC8gcCArIChfaXNOdW1iZXIocmF3KSA/IDAgOiBnZXRVbml0KHJhdykpOyAvLyBuIC0gbiAlIDEgcmVwbGFjZXMgTWF0aC5mbG9vcigpIGluIG9yZGVyIHRvIGhhbmRsZSBuZWdhdGl2ZSB2YWx1ZXMgcHJvcGVybHkuIEZvciBleGFtcGxlLCBNYXRoLmZsb29yKC0xNTAuMDAwMDAwMDAwMDAwMDMpIGlzIDE1MSFcbiAgfTtcbn0sXG4gICAgc25hcCA9IGZ1bmN0aW9uIHNuYXAoc25hcFRvLCB2YWx1ZSkge1xuICB2YXIgaXNBcnJheSA9IF9pc0FycmF5KHNuYXBUbyksXG4gICAgICByYWRpdXMsXG4gICAgICBpczJEO1xuXG4gIGlmICghaXNBcnJheSAmJiBfaXNPYmplY3Qoc25hcFRvKSkge1xuICAgIHJhZGl1cyA9IGlzQXJyYXkgPSBzbmFwVG8ucmFkaXVzIHx8IF9iaWdOdW07XG5cbiAgICBpZiAoc25hcFRvLnZhbHVlcykge1xuICAgICAgc25hcFRvID0gdG9BcnJheShzbmFwVG8udmFsdWVzKTtcblxuICAgICAgaWYgKGlzMkQgPSAhX2lzTnVtYmVyKHNuYXBUb1swXSkpIHtcbiAgICAgICAgcmFkaXVzICo9IHJhZGl1czsgLy9wZXJmb3JtYW5jZSBvcHRpbWl6YXRpb24gc28gd2UgZG9uJ3QgaGF2ZSB0byBNYXRoLnNxcnQoKSBpbiB0aGUgbG9vcC5cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgc25hcFRvID0gX3JvdW5kTW9kaWZpZXIoc25hcFRvLmluY3JlbWVudCk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIF9jb25kaXRpb25hbFJldHVybih2YWx1ZSwgIWlzQXJyYXkgPyBfcm91bmRNb2RpZmllcihzbmFwVG8pIDogX2lzRnVuY3Rpb24oc25hcFRvKSA/IGZ1bmN0aW9uIChyYXcpIHtcbiAgICBpczJEID0gc25hcFRvKHJhdyk7XG4gICAgcmV0dXJuIE1hdGguYWJzKGlzMkQgLSByYXcpIDw9IHJhZGl1cyA/IGlzMkQgOiByYXc7XG4gIH0gOiBmdW5jdGlvbiAocmF3KSB7XG4gICAgdmFyIHggPSBwYXJzZUZsb2F0KGlzMkQgPyByYXcueCA6IHJhdyksXG4gICAgICAgIHkgPSBwYXJzZUZsb2F0KGlzMkQgPyByYXcueSA6IDApLFxuICAgICAgICBtaW4gPSBfYmlnTnVtLFxuICAgICAgICBjbG9zZXN0ID0gMCxcbiAgICAgICAgaSA9IHNuYXBUby5sZW5ndGgsXG4gICAgICAgIGR4LFxuICAgICAgICBkeTtcblxuICAgIHdoaWxlIChpLS0pIHtcbiAgICAgIGlmIChpczJEKSB7XG4gICAgICAgIGR4ID0gc25hcFRvW2ldLnggLSB4O1xuICAgICAgICBkeSA9IHNuYXBUb1tpXS55IC0geTtcbiAgICAgICAgZHggPSBkeCAqIGR4ICsgZHkgKiBkeTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGR4ID0gTWF0aC5hYnMoc25hcFRvW2ldIC0geCk7XG4gICAgICB9XG5cbiAgICAgIGlmIChkeCA8IG1pbikge1xuICAgICAgICBtaW4gPSBkeDtcbiAgICAgICAgY2xvc2VzdCA9IGk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY2xvc2VzdCA9ICFyYWRpdXMgfHwgbWluIDw9IHJhZGl1cyA/IHNuYXBUb1tjbG9zZXN0XSA6IHJhdztcbiAgICByZXR1cm4gaXMyRCB8fCBjbG9zZXN0ID09PSByYXcgfHwgX2lzTnVtYmVyKHJhdykgPyBjbG9zZXN0IDogY2xvc2VzdCArIGdldFVuaXQocmF3KTtcbiAgfSk7XG59LFxuICAgIHJhbmRvbSA9IGZ1bmN0aW9uIHJhbmRvbShtaW4sIG1heCwgcm91bmRpbmdJbmNyZW1lbnQsIHJldHVybkZ1bmN0aW9uKSB7XG4gIHJldHVybiBfY29uZGl0aW9uYWxSZXR1cm4oX2lzQXJyYXkobWluKSA/ICFtYXggOiByb3VuZGluZ0luY3JlbWVudCA9PT0gdHJ1ZSA/ICEhKHJvdW5kaW5nSW5jcmVtZW50ID0gMCkgOiAhcmV0dXJuRnVuY3Rpb24sIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gX2lzQXJyYXkobWluKSA/IG1pblt+fihNYXRoLnJhbmRvbSgpICogbWluLmxlbmd0aCldIDogKHJvdW5kaW5nSW5jcmVtZW50ID0gcm91bmRpbmdJbmNyZW1lbnQgfHwgMWUtNSkgJiYgKHJldHVybkZ1bmN0aW9uID0gcm91bmRpbmdJbmNyZW1lbnQgPCAxID8gTWF0aC5wb3coMTAsIChyb3VuZGluZ0luY3JlbWVudCArIFwiXCIpLmxlbmd0aCAtIDIpIDogMSkgJiYgTWF0aC5mbG9vcihNYXRoLnJvdW5kKChtaW4gLSByb3VuZGluZ0luY3JlbWVudCAvIDIgKyBNYXRoLnJhbmRvbSgpICogKG1heCAtIG1pbiArIHJvdW5kaW5nSW5jcmVtZW50ICogLjk5KSkgLyByb3VuZGluZ0luY3JlbWVudCkgKiByb3VuZGluZ0luY3JlbWVudCAqIHJldHVybkZ1bmN0aW9uKSAvIHJldHVybkZ1bmN0aW9uO1xuICB9KTtcbn0sXG4gICAgcGlwZSA9IGZ1bmN0aW9uIHBpcGUoKSB7XG4gIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBmdW5jdGlvbnMgPSBuZXcgQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgZnVuY3Rpb25zW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICB9XG5cbiAgcmV0dXJuIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIHJldHVybiBmdW5jdGlvbnMucmVkdWNlKGZ1bmN0aW9uICh2LCBmKSB7XG4gICAgICByZXR1cm4gZih2KTtcbiAgICB9LCB2YWx1ZSk7XG4gIH07XG59LFxuICAgIHVuaXRpemUgPSBmdW5jdGlvbiB1bml0aXplKGZ1bmMsIHVuaXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIHJldHVybiBmdW5jKHBhcnNlRmxvYXQodmFsdWUpKSArICh1bml0IHx8IGdldFVuaXQodmFsdWUpKTtcbiAgfTtcbn0sXG4gICAgbm9ybWFsaXplID0gZnVuY3Rpb24gbm9ybWFsaXplKG1pbiwgbWF4LCB2YWx1ZSkge1xuICByZXR1cm4gbWFwUmFuZ2UobWluLCBtYXgsIDAsIDEsIHZhbHVlKTtcbn0sXG4gICAgX3dyYXBBcnJheSA9IGZ1bmN0aW9uIF93cmFwQXJyYXkoYSwgd3JhcHBlciwgdmFsdWUpIHtcbiAgcmV0dXJuIF9jb25kaXRpb25hbFJldHVybih2YWx1ZSwgZnVuY3Rpb24gKGluZGV4KSB7XG4gICAgcmV0dXJuIGFbfn53cmFwcGVyKGluZGV4KV07XG4gIH0pO1xufSxcbiAgICB3cmFwID0gZnVuY3Rpb24gd3JhcChtaW4sIG1heCwgdmFsdWUpIHtcbiAgLy8gTk9URTogd3JhcCgpIENBTk5PVCBiZSBhbiBhcnJvdyBmdW5jdGlvbiEgQSB2ZXJ5IG9kZCBjb21waWxpbmcgYnVnIGNhdXNlcyBwcm9ibGVtcyAodW5yZWxhdGVkIHRvIEdTQVApLlxuICB2YXIgcmFuZ2UgPSBtYXggLSBtaW47XG4gIHJldHVybiBfaXNBcnJheShtaW4pID8gX3dyYXBBcnJheShtaW4sIHdyYXAoMCwgbWluLmxlbmd0aCksIG1heCkgOiBfY29uZGl0aW9uYWxSZXR1cm4odmFsdWUsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIHJldHVybiAocmFuZ2UgKyAodmFsdWUgLSBtaW4pICUgcmFuZ2UpICUgcmFuZ2UgKyBtaW47XG4gIH0pO1xufSxcbiAgICB3cmFwWW95byA9IGZ1bmN0aW9uIHdyYXBZb3lvKG1pbiwgbWF4LCB2YWx1ZSkge1xuICB2YXIgcmFuZ2UgPSBtYXggLSBtaW4sXG4gICAgICB0b3RhbCA9IHJhbmdlICogMjtcbiAgcmV0dXJuIF9pc0FycmF5KG1pbikgPyBfd3JhcEFycmF5KG1pbiwgd3JhcFlveW8oMCwgbWluLmxlbmd0aCAtIDEpLCBtYXgpIDogX2NvbmRpdGlvbmFsUmV0dXJuKHZhbHVlLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICB2YWx1ZSA9ICh0b3RhbCArICh2YWx1ZSAtIG1pbikgJSB0b3RhbCkgJSB0b3RhbCB8fCAwO1xuICAgIHJldHVybiBtaW4gKyAodmFsdWUgPiByYW5nZSA/IHRvdGFsIC0gdmFsdWUgOiB2YWx1ZSk7XG4gIH0pO1xufSxcbiAgICBfcmVwbGFjZVJhbmRvbSA9IGZ1bmN0aW9uIF9yZXBsYWNlUmFuZG9tKHMpIHtcbiAgcmV0dXJuIHMucmVwbGFjZShfcmFuZG9tRXhwLCBmdW5jdGlvbiAobWF0Y2gpIHtcbiAgICAvL3JlcGxhY2VzIGFsbCBvY2N1cnJlbmNlcyBvZiByYW5kb20oLi4uKSBpbiBhIHN0cmluZyB3aXRoIHRoZSBjYWxjdWxhdGVkIHJhbmRvbSB2YWx1ZS4gY2FuIGJlIGEgcmFuZ2UgbGlrZSByYW5kb20oLTEwMCwgMTAwLCA1KSBvciBhbiBhcnJheSBsaWtlIHJhbmRvbShbMCwgMTAwLCA1MDBdKVxuICAgIHZhciBhckluZGV4ID0gbWF0Y2guaW5kZXhPZihcIltcIikgKyAxLFxuICAgICAgICB2YWx1ZXMgPSBtYXRjaC5zdWJzdHJpbmcoYXJJbmRleCB8fCA3LCBhckluZGV4ID8gbWF0Y2guaW5kZXhPZihcIl1cIikgOiBtYXRjaC5sZW5ndGggLSAxKS5zcGxpdChfY29tbWFEZWxpbUV4cCk7XG4gICAgcmV0dXJuIHJhbmRvbShhckluZGV4ID8gdmFsdWVzIDogK3ZhbHVlc1swXSwgYXJJbmRleCA/IDAgOiArdmFsdWVzWzFdLCArdmFsdWVzWzJdIHx8IDFlLTUpO1xuICB9KTtcbn0sXG4gICAgbWFwUmFuZ2UgPSBmdW5jdGlvbiBtYXBSYW5nZShpbk1pbiwgaW5NYXgsIG91dE1pbiwgb3V0TWF4LCB2YWx1ZSkge1xuICB2YXIgaW5SYW5nZSA9IGluTWF4IC0gaW5NaW4sXG4gICAgICBvdXRSYW5nZSA9IG91dE1heCAtIG91dE1pbjtcbiAgcmV0dXJuIF9jb25kaXRpb25hbFJldHVybih2YWx1ZSwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgcmV0dXJuIG91dE1pbiArICgodmFsdWUgLSBpbk1pbikgLyBpblJhbmdlICogb3V0UmFuZ2UgfHwgMCk7XG4gIH0pO1xufSxcbiAgICBpbnRlcnBvbGF0ZSA9IGZ1bmN0aW9uIGludGVycG9sYXRlKHN0YXJ0LCBlbmQsIHByb2dyZXNzLCBtdXRhdGUpIHtcbiAgdmFyIGZ1bmMgPSBpc05hTihzdGFydCArIGVuZCkgPyAwIDogZnVuY3Rpb24gKHApIHtcbiAgICByZXR1cm4gKDEgLSBwKSAqIHN0YXJ0ICsgcCAqIGVuZDtcbiAgfTtcblxuICBpZiAoIWZ1bmMpIHtcbiAgICB2YXIgaXNTdHJpbmcgPSBfaXNTdHJpbmcoc3RhcnQpLFxuICAgICAgICBtYXN0ZXIgPSB7fSxcbiAgICAgICAgcCxcbiAgICAgICAgaSxcbiAgICAgICAgaW50ZXJwb2xhdG9ycyxcbiAgICAgICAgbCxcbiAgICAgICAgaWw7XG5cbiAgICBwcm9ncmVzcyA9PT0gdHJ1ZSAmJiAobXV0YXRlID0gMSkgJiYgKHByb2dyZXNzID0gbnVsbCk7XG5cbiAgICBpZiAoaXNTdHJpbmcpIHtcbiAgICAgIHN0YXJ0ID0ge1xuICAgICAgICBwOiBzdGFydFxuICAgICAgfTtcbiAgICAgIGVuZCA9IHtcbiAgICAgICAgcDogZW5kXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAoX2lzQXJyYXkoc3RhcnQpICYmICFfaXNBcnJheShlbmQpKSB7XG4gICAgICBpbnRlcnBvbGF0b3JzID0gW107XG4gICAgICBsID0gc3RhcnQubGVuZ3RoO1xuICAgICAgaWwgPSBsIC0gMjtcblxuICAgICAgZm9yIChpID0gMTsgaSA8IGw7IGkrKykge1xuICAgICAgICBpbnRlcnBvbGF0b3JzLnB1c2goaW50ZXJwb2xhdGUoc3RhcnRbaSAtIDFdLCBzdGFydFtpXSkpOyAvL2J1aWxkIHRoZSBpbnRlcnBvbGF0b3JzIHVwIGZyb250IGFzIGEgcGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9uIHNvIHRoYXQgd2hlbiB0aGUgZnVuY3Rpb24gaXMgY2FsbGVkIG1hbnkgdGltZXMsIGl0IGNhbiBqdXN0IHJldXNlIHRoZW0uXG4gICAgICB9XG5cbiAgICAgIGwtLTtcblxuICAgICAgZnVuYyA9IGZ1bmN0aW9uIGZ1bmMocCkge1xuICAgICAgICBwICo9IGw7XG4gICAgICAgIHZhciBpID0gTWF0aC5taW4oaWwsIH5+cCk7XG4gICAgICAgIHJldHVybiBpbnRlcnBvbGF0b3JzW2ldKHAgLSBpKTtcbiAgICAgIH07XG5cbiAgICAgIHByb2dyZXNzID0gZW5kO1xuICAgIH0gZWxzZSBpZiAoIW11dGF0ZSkge1xuICAgICAgc3RhcnQgPSBfbWVyZ2UoX2lzQXJyYXkoc3RhcnQpID8gW10gOiB7fSwgc3RhcnQpO1xuICAgIH1cblxuICAgIGlmICghaW50ZXJwb2xhdG9ycykge1xuICAgICAgZm9yIChwIGluIGVuZCkge1xuICAgICAgICBfYWRkUHJvcFR3ZWVuLmNhbGwobWFzdGVyLCBzdGFydCwgcCwgXCJnZXRcIiwgZW5kW3BdKTtcbiAgICAgIH1cblxuICAgICAgZnVuYyA9IGZ1bmN0aW9uIGZ1bmMocCkge1xuICAgICAgICByZXR1cm4gX3JlbmRlclByb3BUd2VlbnMocCwgbWFzdGVyKSB8fCAoaXNTdHJpbmcgPyBzdGFydC5wIDogc3RhcnQpO1xuICAgICAgfTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gX2NvbmRpdGlvbmFsUmV0dXJuKHByb2dyZXNzLCBmdW5jKTtcbn0sXG4gICAgX2dldExhYmVsSW5EaXJlY3Rpb24gPSBmdW5jdGlvbiBfZ2V0TGFiZWxJbkRpcmVjdGlvbih0aW1lbGluZSwgZnJvbVRpbWUsIGJhY2t3YXJkKSB7XG4gIC8vdXNlZCBmb3IgbmV4dExhYmVsKCkgYW5kIHByZXZpb3VzTGFiZWwoKVxuICB2YXIgbGFiZWxzID0gdGltZWxpbmUubGFiZWxzLFxuICAgICAgbWluID0gX2JpZ051bSxcbiAgICAgIHAsXG4gICAgICBkaXN0YW5jZSxcbiAgICAgIGxhYmVsO1xuXG4gIGZvciAocCBpbiBsYWJlbHMpIHtcbiAgICBkaXN0YW5jZSA9IGxhYmVsc1twXSAtIGZyb21UaW1lO1xuXG4gICAgaWYgKGRpc3RhbmNlIDwgMCA9PT0gISFiYWNrd2FyZCAmJiBkaXN0YW5jZSAmJiBtaW4gPiAoZGlzdGFuY2UgPSBNYXRoLmFicyhkaXN0YW5jZSkpKSB7XG4gICAgICBsYWJlbCA9IHA7XG4gICAgICBtaW4gPSBkaXN0YW5jZTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gbGFiZWw7XG59LFxuICAgIF9jYWxsYmFjayA9IGZ1bmN0aW9uIF9jYWxsYmFjayhhbmltYXRpb24sIHR5cGUsIGV4ZWN1dGVMYXp5Rmlyc3QpIHtcbiAgdmFyIHYgPSBhbmltYXRpb24udmFycyxcbiAgICAgIGNhbGxiYWNrID0gdlt0eXBlXSxcbiAgICAgIHByZXZDb250ZXh0ID0gX2NvbnRleHQsXG4gICAgICBjb250ZXh0ID0gYW5pbWF0aW9uLl9jdHgsXG4gICAgICBwYXJhbXMsXG4gICAgICBzY29wZSxcbiAgICAgIHJlc3VsdDtcblxuICBpZiAoIWNhbGxiYWNrKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgcGFyYW1zID0gdlt0eXBlICsgXCJQYXJhbXNcIl07XG4gIHNjb3BlID0gdi5jYWxsYmFja1Njb3BlIHx8IGFuaW1hdGlvbjtcbiAgZXhlY3V0ZUxhenlGaXJzdCAmJiBfbGF6eVR3ZWVucy5sZW5ndGggJiYgX2xhenlSZW5kZXIoKTsgLy9pbiBjYXNlIHJlbmRlcmluZyBjYXVzZWQgYW55IHR3ZWVucyB0byBsYXp5LWluaXQsIHdlIHNob3VsZCByZW5kZXIgdGhlbSBiZWNhdXNlIHR5cGljYWxseSB3aGVuIGEgdGltZWxpbmUgZmluaXNoZXMsIHVzZXJzIGV4cGVjdCB0aGluZ3MgdG8gaGF2ZSByZW5kZXJlZCBmdWxseS4gSW1hZ2luZSBhbiBvblVwZGF0ZSBvbiBhIHRpbWVsaW5lIHRoYXQgcmVwb3J0cy9jaGVja3MgdHdlZW5lZCB2YWx1ZXMuXG5cbiAgY29udGV4dCAmJiAoX2NvbnRleHQgPSBjb250ZXh0KTtcbiAgcmVzdWx0ID0gcGFyYW1zID8gY2FsbGJhY2suYXBwbHkoc2NvcGUsIHBhcmFtcykgOiBjYWxsYmFjay5jYWxsKHNjb3BlKTtcbiAgX2NvbnRleHQgPSBwcmV2Q29udGV4dDtcbiAgcmV0dXJuIHJlc3VsdDtcbn0sXG4gICAgX2ludGVycnVwdCA9IGZ1bmN0aW9uIF9pbnRlcnJ1cHQoYW5pbWF0aW9uKSB7XG4gIF9yZW1vdmVGcm9tUGFyZW50KGFuaW1hdGlvbik7XG5cbiAgYW5pbWF0aW9uLnNjcm9sbFRyaWdnZXIgJiYgYW5pbWF0aW9uLnNjcm9sbFRyaWdnZXIua2lsbCghIV9yZXZlcnRpbmcpO1xuICBhbmltYXRpb24ucHJvZ3Jlc3MoKSA8IDEgJiYgX2NhbGxiYWNrKGFuaW1hdGlvbiwgXCJvbkludGVycnVwdFwiKTtcbiAgcmV0dXJuIGFuaW1hdGlvbjtcbn0sXG4gICAgX3F1aWNrVHdlZW4sXG4gICAgX3JlZ2lzdGVyUGx1Z2luUXVldWUgPSBbXSxcbiAgICBfY3JlYXRlUGx1Z2luID0gZnVuY3Rpb24gX2NyZWF0ZVBsdWdpbihjb25maWcpIHtcbiAgaWYgKCFjb25maWcpIHJldHVybjtcbiAgY29uZmlnID0gIWNvbmZpZy5uYW1lICYmIGNvbmZpZ1tcImRlZmF1bHRcIl0gfHwgY29uZmlnOyAvLyBVTUQgcGFja2FnaW5nIHdyYXBzIHRoaW5ncyBvZGRseSwgc28gZm9yIGV4YW1wbGUgTW90aW9uUGF0aEhlbHBlciBiZWNvbWVzIHtNb3Rpb25QYXRoSGVscGVyOk1vdGlvblBhdGhIZWxwZXIsIGRlZmF1bHQ6TW90aW9uUGF0aEhlbHBlcn0uXG5cbiAgaWYgKF93aW5kb3dFeGlzdHMoKSB8fCBjb25maWcuaGVhZGxlc3MpIHtcbiAgICAvLyBlZGdlIGNhc2U6IHNvbWUgYnVpbGQgdG9vbHMgbWF5IHBhc3MgaW4gYSBudWxsL3VuZGVmaW5lZCB2YWx1ZVxuICAgIHZhciBuYW1lID0gY29uZmlnLm5hbWUsXG4gICAgICAgIGlzRnVuYyA9IF9pc0Z1bmN0aW9uKGNvbmZpZyksXG4gICAgICAgIFBsdWdpbiA9IG5hbWUgJiYgIWlzRnVuYyAmJiBjb25maWcuaW5pdCA/IGZ1bmN0aW9uICgpIHtcbiAgICAgIHRoaXMuX3Byb3BzID0gW107XG4gICAgfSA6IGNvbmZpZyxcbiAgICAgICAgLy9pbiBjYXNlIHNvbWVvbmUgcGFzc2VzIGluIGFuIG9iamVjdCB0aGF0J3Mgbm90IGEgcGx1Z2luLCBsaWtlIEN1c3RvbUVhc2VcbiAgICBpbnN0YW5jZURlZmF1bHRzID0ge1xuICAgICAgaW5pdDogX2VtcHR5RnVuYyxcbiAgICAgIHJlbmRlcjogX3JlbmRlclByb3BUd2VlbnMsXG4gICAgICBhZGQ6IF9hZGRQcm9wVHdlZW4sXG4gICAgICBraWxsOiBfa2lsbFByb3BUd2VlbnNPZixcbiAgICAgIG1vZGlmaWVyOiBfYWRkUGx1Z2luTW9kaWZpZXIsXG4gICAgICByYXdWYXJzOiAwXG4gICAgfSxcbiAgICAgICAgc3RhdGljcyA9IHtcbiAgICAgIHRhcmdldFRlc3Q6IDAsXG4gICAgICBnZXQ6IDAsXG4gICAgICBnZXRTZXR0ZXI6IF9nZXRTZXR0ZXIsXG4gICAgICBhbGlhc2VzOiB7fSxcbiAgICAgIHJlZ2lzdGVyOiAwXG4gICAgfTtcblxuICAgIF93YWtlKCk7XG5cbiAgICBpZiAoY29uZmlnICE9PSBQbHVnaW4pIHtcbiAgICAgIGlmIChfcGx1Z2luc1tuYW1lXSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIF9zZXREZWZhdWx0cyhQbHVnaW4sIF9zZXREZWZhdWx0cyhfY29weUV4Y2x1ZGluZyhjb25maWcsIGluc3RhbmNlRGVmYXVsdHMpLCBzdGF0aWNzKSk7IC8vc3RhdGljIG1ldGhvZHNcblxuXG4gICAgICBfbWVyZ2UoUGx1Z2luLnByb3RvdHlwZSwgX21lcmdlKGluc3RhbmNlRGVmYXVsdHMsIF9jb3B5RXhjbHVkaW5nKGNvbmZpZywgc3RhdGljcykpKTsgLy9pbnN0YW5jZSBtZXRob2RzXG5cblxuICAgICAgX3BsdWdpbnNbUGx1Z2luLnByb3AgPSBuYW1lXSA9IFBsdWdpbjtcblxuICAgICAgaWYgKGNvbmZpZy50YXJnZXRUZXN0KSB7XG4gICAgICAgIF9oYXJuZXNzUGx1Z2lucy5wdXNoKFBsdWdpbik7XG5cbiAgICAgICAgX3Jlc2VydmVkUHJvcHNbbmFtZV0gPSAxO1xuICAgICAgfVxuXG4gICAgICBuYW1lID0gKG5hbWUgPT09IFwiY3NzXCIgPyBcIkNTU1wiIDogbmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIG5hbWUuc3Vic3RyKDEpKSArIFwiUGx1Z2luXCI7IC8vZm9yIHRoZSBnbG9iYWwgbmFtZS4gXCJtb3Rpb25QYXRoXCIgc2hvdWxkIGJlY29tZSBNb3Rpb25QYXRoUGx1Z2luXG4gICAgfVxuXG4gICAgX2FkZEdsb2JhbChuYW1lLCBQbHVnaW4pO1xuXG4gICAgY29uZmlnLnJlZ2lzdGVyICYmIGNvbmZpZy5yZWdpc3Rlcihnc2FwLCBQbHVnaW4sIFByb3BUd2Vlbik7XG4gIH0gZWxzZSB7XG4gICAgX3JlZ2lzdGVyUGx1Z2luUXVldWUucHVzaChjb25maWcpO1xuICB9XG59LFxuXG4vKlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqIENPTE9SU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqL1xuXzI1NSA9IDI1NSxcbiAgICBfY29sb3JMb29rdXAgPSB7XG4gIGFxdWE6IFswLCBfMjU1LCBfMjU1XSxcbiAgbGltZTogWzAsIF8yNTUsIDBdLFxuICBzaWx2ZXI6IFsxOTIsIDE5MiwgMTkyXSxcbiAgYmxhY2s6IFswLCAwLCAwXSxcbiAgbWFyb29uOiBbMTI4LCAwLCAwXSxcbiAgdGVhbDogWzAsIDEyOCwgMTI4XSxcbiAgYmx1ZTogWzAsIDAsIF8yNTVdLFxuICBuYXZ5OiBbMCwgMCwgMTI4XSxcbiAgd2hpdGU6IFtfMjU1LCBfMjU1LCBfMjU1XSxcbiAgb2xpdmU6IFsxMjgsIDEyOCwgMF0sXG4gIHllbGxvdzogW18yNTUsIF8yNTUsIDBdLFxuICBvcmFuZ2U6IFtfMjU1LCAxNjUsIDBdLFxuICBncmF5OiBbMTI4LCAxMjgsIDEyOF0sXG4gIHB1cnBsZTogWzEyOCwgMCwgMTI4XSxcbiAgZ3JlZW46IFswLCAxMjgsIDBdLFxuICByZWQ6IFtfMjU1LCAwLCAwXSxcbiAgcGluazogW18yNTUsIDE5MiwgMjAzXSxcbiAgY3lhbjogWzAsIF8yNTUsIF8yNTVdLFxuICB0cmFuc3BhcmVudDogW18yNTUsIF8yNTUsIF8yNTUsIDBdXG59LFxuICAgIC8vIHBvc3NpYmxlIGZ1dHVyZSBpZGVhIHRvIHJlcGxhY2UgdGhlIGhhcmQtY29kZWQgY29sb3IgbmFtZSB2YWx1ZXMgLSBwdXQgdGhpcyBpbiB0aGUgdGlja2VyLndha2UoKSB3aGVyZSB3ZSBzZXQgdGhlIF9kb2M6XG4vLyBsZXQgY3R4ID0gX2RvYy5jcmVhdGVFbGVtZW50KFwiY2FudmFzXCIpLmdldENvbnRleHQoXCIyZFwiKTtcbi8vIF9mb3JFYWNoTmFtZShcImFxdWEsbGltZSxzaWx2ZXIsYmxhY2ssbWFyb29uLHRlYWwsYmx1ZSxuYXZ5LHdoaXRlLG9saXZlLHllbGxvdyxvcmFuZ2UsZ3JheSxwdXJwbGUsZ3JlZW4scmVkLHBpbmssY3lhblwiLCBjb2xvciA9PiB7Y3R4LmZpbGxTdHlsZSA9IGNvbG9yOyBfY29sb3JMb29rdXBbY29sb3JdID0gc3BsaXRDb2xvcihjdHguZmlsbFN0eWxlKX0pO1xuX2h1ZSA9IGZ1bmN0aW9uIF9odWUoaCwgbTEsIG0yKSB7XG4gIGggKz0gaCA8IDAgPyAxIDogaCA+IDEgPyAtMSA6IDA7XG4gIHJldHVybiAoaCAqIDYgPCAxID8gbTEgKyAobTIgLSBtMSkgKiBoICogNiA6IGggPCAuNSA/IG0yIDogaCAqIDMgPCAyID8gbTEgKyAobTIgLSBtMSkgKiAoMiAvIDMgLSBoKSAqIDYgOiBtMSkgKiBfMjU1ICsgLjUgfCAwO1xufSxcbiAgICBzcGxpdENvbG9yID0gZnVuY3Rpb24gc3BsaXRDb2xvcih2LCB0b0hTTCwgZm9yY2VBbHBoYSkge1xuICB2YXIgYSA9ICF2ID8gX2NvbG9yTG9va3VwLmJsYWNrIDogX2lzTnVtYmVyKHYpID8gW3YgPj4gMTYsIHYgPj4gOCAmIF8yNTUsIHYgJiBfMjU1XSA6IDAsXG4gICAgICByLFxuICAgICAgZyxcbiAgICAgIGIsXG4gICAgICBoLFxuICAgICAgcyxcbiAgICAgIGwsXG4gICAgICBtYXgsXG4gICAgICBtaW4sXG4gICAgICBkLFxuICAgICAgd2FzSFNMO1xuXG4gIGlmICghYSkge1xuICAgIGlmICh2LnN1YnN0cigtMSkgPT09IFwiLFwiKSB7XG4gICAgICAvL3NvbWV0aW1lcyBhIHRyYWlsaW5nIGNvbW1hIGlzIGluY2x1ZGVkIGFuZCB3ZSBzaG91bGQgY2hvcCBpdCBvZmYgKHR5cGljYWxseSBmcm9tIGEgY29tbWEtZGVsaW1pdGVkIGxpc3Qgb2YgdmFsdWVzIGxpa2UgYSB0ZXh0U2hhZG93OlwiMnB4IDJweCAycHggYmx1ZSwgNXB4IDVweCA1cHggcmdiKDI1NSwwLDApXCIgLSBpbiB0aGlzIGV4YW1wbGUgXCJibHVlLFwiIGhhcyBhIHRyYWlsaW5nIGNvbW1hLiBXZSBjb3VsZCBzdHJpcCBpdCBvdXQgaW5zaWRlIHBhcnNlQ29tcGxleCgpIGJ1dCB3ZSdkIG5lZWQgdG8gZG8gaXQgdG8gdGhlIGJlZ2lubmluZyBhbmQgZW5kaW5nIHZhbHVlcyBwbHVzIGl0IHdvdWxkbid0IHByb3ZpZGUgcHJvdGVjdGlvbiBmcm9tIG90aGVyIHBvdGVudGlhbCBzY2VuYXJpb3MgbGlrZSBpZiB0aGUgdXNlciBwYXNzZXMgaW4gYSBzaW1pbGFyIHZhbHVlLlxuICAgICAgdiA9IHYuc3Vic3RyKDAsIHYubGVuZ3RoIC0gMSk7XG4gICAgfVxuXG4gICAgaWYgKF9jb2xvckxvb2t1cFt2XSkge1xuICAgICAgYSA9IF9jb2xvckxvb2t1cFt2XTtcbiAgICB9IGVsc2UgaWYgKHYuY2hhckF0KDApID09PSBcIiNcIikge1xuICAgICAgaWYgKHYubGVuZ3RoIDwgNikge1xuICAgICAgICAvL2ZvciBzaG9ydGhhbmQgbGlrZSAjOUYwIG9yICM5RjBGIChjb3VsZCBoYXZlIGFscGhhKVxuICAgICAgICByID0gdi5jaGFyQXQoMSk7XG4gICAgICAgIGcgPSB2LmNoYXJBdCgyKTtcbiAgICAgICAgYiA9IHYuY2hhckF0KDMpO1xuICAgICAgICB2ID0gXCIjXCIgKyByICsgciArIGcgKyBnICsgYiArIGIgKyAodi5sZW5ndGggPT09IDUgPyB2LmNoYXJBdCg0KSArIHYuY2hhckF0KDQpIDogXCJcIik7XG4gICAgICB9XG5cbiAgICAgIGlmICh2Lmxlbmd0aCA9PT0gOSkge1xuICAgICAgICAvLyBoZXggd2l0aCBhbHBoYSwgbGlrZSAjZmQ1ZTUzZmZcbiAgICAgICAgYSA9IHBhcnNlSW50KHYuc3Vic3RyKDEsIDYpLCAxNik7XG4gICAgICAgIHJldHVybiBbYSA+PiAxNiwgYSA+PiA4ICYgXzI1NSwgYSAmIF8yNTUsIHBhcnNlSW50KHYuc3Vic3RyKDcpLCAxNikgLyAyNTVdO1xuICAgICAgfVxuXG4gICAgICB2ID0gcGFyc2VJbnQodi5zdWJzdHIoMSksIDE2KTtcbiAgICAgIGEgPSBbdiA+PiAxNiwgdiA+PiA4ICYgXzI1NSwgdiAmIF8yNTVdO1xuICAgIH0gZWxzZSBpZiAodi5zdWJzdHIoMCwgMykgPT09IFwiaHNsXCIpIHtcbiAgICAgIGEgPSB3YXNIU0wgPSB2Lm1hdGNoKF9zdHJpY3ROdW1FeHApO1xuXG4gICAgICBpZiAoIXRvSFNMKSB7XG4gICAgICAgIGggPSArYVswXSAlIDM2MCAvIDM2MDtcbiAgICAgICAgcyA9ICthWzFdIC8gMTAwO1xuICAgICAgICBsID0gK2FbMl0gLyAxMDA7XG4gICAgICAgIGcgPSBsIDw9IC41ID8gbCAqIChzICsgMSkgOiBsICsgcyAtIGwgKiBzO1xuICAgICAgICByID0gbCAqIDIgLSBnO1xuICAgICAgICBhLmxlbmd0aCA+IDMgJiYgKGFbM10gKj0gMSk7IC8vY2FzdCBhcyBudW1iZXJcblxuICAgICAgICBhWzBdID0gX2h1ZShoICsgMSAvIDMsIHIsIGcpO1xuICAgICAgICBhWzFdID0gX2h1ZShoLCByLCBnKTtcbiAgICAgICAgYVsyXSA9IF9odWUoaCAtIDEgLyAzLCByLCBnKTtcbiAgICAgIH0gZWxzZSBpZiAofnYuaW5kZXhPZihcIj1cIikpIHtcbiAgICAgICAgLy9pZiByZWxhdGl2ZSB2YWx1ZXMgYXJlIGZvdW5kLCBqdXN0IHJldHVybiB0aGUgcmF3IHN0cmluZ3Mgd2l0aCB0aGUgcmVsYXRpdmUgcHJlZml4ZXMgaW4gcGxhY2UuXG4gICAgICAgIGEgPSB2Lm1hdGNoKF9udW1FeHApO1xuICAgICAgICBmb3JjZUFscGhhICYmIGEubGVuZ3RoIDwgNCAmJiAoYVszXSA9IDEpO1xuICAgICAgICByZXR1cm4gYTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgYSA9IHYubWF0Y2goX3N0cmljdE51bUV4cCkgfHwgX2NvbG9yTG9va3VwLnRyYW5zcGFyZW50O1xuICAgIH1cblxuICAgIGEgPSBhLm1hcChOdW1iZXIpO1xuICB9XG5cbiAgaWYgKHRvSFNMICYmICF3YXNIU0wpIHtcbiAgICByID0gYVswXSAvIF8yNTU7XG4gICAgZyA9IGFbMV0gLyBfMjU1O1xuICAgIGIgPSBhWzJdIC8gXzI1NTtcbiAgICBtYXggPSBNYXRoLm1heChyLCBnLCBiKTtcbiAgICBtaW4gPSBNYXRoLm1pbihyLCBnLCBiKTtcbiAgICBsID0gKG1heCArIG1pbikgLyAyO1xuXG4gICAgaWYgKG1heCA9PT0gbWluKSB7XG4gICAgICBoID0gcyA9IDA7XG4gICAgfSBlbHNlIHtcbiAgICAgIGQgPSBtYXggLSBtaW47XG4gICAgICBzID0gbCA+IDAuNSA/IGQgLyAoMiAtIG1heCAtIG1pbikgOiBkIC8gKG1heCArIG1pbik7XG4gICAgICBoID0gbWF4ID09PSByID8gKGcgLSBiKSAvIGQgKyAoZyA8IGIgPyA2IDogMCkgOiBtYXggPT09IGcgPyAoYiAtIHIpIC8gZCArIDIgOiAociAtIGcpIC8gZCArIDQ7XG4gICAgICBoICo9IDYwO1xuICAgIH1cblxuICAgIGFbMF0gPSB+fihoICsgLjUpO1xuICAgIGFbMV0gPSB+fihzICogMTAwICsgLjUpO1xuICAgIGFbMl0gPSB+fihsICogMTAwICsgLjUpO1xuICB9XG5cbiAgZm9yY2VBbHBoYSAmJiBhLmxlbmd0aCA8IDQgJiYgKGFbM10gPSAxKTtcbiAgcmV0dXJuIGE7XG59LFxuICAgIF9jb2xvck9yZGVyRGF0YSA9IGZ1bmN0aW9uIF9jb2xvck9yZGVyRGF0YSh2KSB7XG4gIC8vIHN0cmlwcyBvdXQgdGhlIGNvbG9ycyBmcm9tIHRoZSBzdHJpbmcsIGZpbmRzIGFsbCB0aGUgbnVtZXJpYyBzbG90cyAod2l0aCB1bml0cykgYW5kIHJldHVybnMgYW4gYXJyYXkgb2YgdGhvc2UuIFRoZSBBcnJheSBhbHNvIGhhcyBhIFwiY1wiIHByb3BlcnR5IHdoaWNoIGlzIGFuIEFycmF5IG9mIHRoZSBpbmRleCB2YWx1ZXMgd2hlcmUgdGhlIGNvbG9ycyBiZWxvbmcuIFRoaXMgaXMgdG8gaGVscCB3b3JrIGFyb3VuZCBpc3N1ZXMgd2hlcmUgdGhlcmUncyBhIG1pcy1tYXRjaGVkIG9yZGVyIG9mIGNvbG9yL251bWVyaWMgZGF0YSBsaWtlIGRyb3Atc2hhZG93KCNmMDAgMHB4IDFweCAycHgpIGFuZCBkcm9wLXNoYWRvdygweCAxcHggMnB4ICNmMDApLiBUaGlzIGlzIGJhc2ljYWxseSBhIGhlbHBlciBmdW5jdGlvbiB1c2VkIGluIF9mb3JtYXRDb2xvcnMoKVxuICB2YXIgdmFsdWVzID0gW10sXG4gICAgICBjID0gW10sXG4gICAgICBpID0gLTE7XG4gIHYuc3BsaXQoX2NvbG9yRXhwKS5mb3JFYWNoKGZ1bmN0aW9uICh2KSB7XG4gICAgdmFyIGEgPSB2Lm1hdGNoKF9udW1XaXRoVW5pdEV4cCkgfHwgW107XG4gICAgdmFsdWVzLnB1c2guYXBwbHkodmFsdWVzLCBhKTtcbiAgICBjLnB1c2goaSArPSBhLmxlbmd0aCArIDEpO1xuICB9KTtcbiAgdmFsdWVzLmMgPSBjO1xuICByZXR1cm4gdmFsdWVzO1xufSxcbiAgICBfZm9ybWF0Q29sb3JzID0gZnVuY3Rpb24gX2Zvcm1hdENvbG9ycyhzLCB0b0hTTCwgb3JkZXJNYXRjaERhdGEpIHtcbiAgdmFyIHJlc3VsdCA9IFwiXCIsXG4gICAgICBjb2xvcnMgPSAocyArIHJlc3VsdCkubWF0Y2goX2NvbG9yRXhwKSxcbiAgICAgIHR5cGUgPSB0b0hTTCA/IFwiaHNsYShcIiA6IFwicmdiYShcIixcbiAgICAgIGkgPSAwLFxuICAgICAgYyxcbiAgICAgIHNoZWxsLFxuICAgICAgZCxcbiAgICAgIGw7XG5cbiAgaWYgKCFjb2xvcnMpIHtcbiAgICByZXR1cm4gcztcbiAgfVxuXG4gIGNvbG9ycyA9IGNvbG9ycy5tYXAoZnVuY3Rpb24gKGNvbG9yKSB7XG4gICAgcmV0dXJuIChjb2xvciA9IHNwbGl0Q29sb3IoY29sb3IsIHRvSFNMLCAxKSkgJiYgdHlwZSArICh0b0hTTCA/IGNvbG9yWzBdICsgXCIsXCIgKyBjb2xvclsxXSArIFwiJSxcIiArIGNvbG9yWzJdICsgXCIlLFwiICsgY29sb3JbM10gOiBjb2xvci5qb2luKFwiLFwiKSkgKyBcIilcIjtcbiAgfSk7XG5cbiAgaWYgKG9yZGVyTWF0Y2hEYXRhKSB7XG4gICAgZCA9IF9jb2xvck9yZGVyRGF0YShzKTtcbiAgICBjID0gb3JkZXJNYXRjaERhdGEuYztcblxuICAgIGlmIChjLmpvaW4ocmVzdWx0KSAhPT0gZC5jLmpvaW4ocmVzdWx0KSkge1xuICAgICAgc2hlbGwgPSBzLnJlcGxhY2UoX2NvbG9yRXhwLCBcIjFcIikuc3BsaXQoX251bVdpdGhVbml0RXhwKTtcbiAgICAgIGwgPSBzaGVsbC5sZW5ndGggLSAxO1xuXG4gICAgICBmb3IgKDsgaSA8IGw7IGkrKykge1xuICAgICAgICByZXN1bHQgKz0gc2hlbGxbaV0gKyAofmMuaW5kZXhPZihpKSA/IGNvbG9ycy5zaGlmdCgpIHx8IHR5cGUgKyBcIjAsMCwwLDApXCIgOiAoZC5sZW5ndGggPyBkIDogY29sb3JzLmxlbmd0aCA/IGNvbG9ycyA6IG9yZGVyTWF0Y2hEYXRhKS5zaGlmdCgpKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBpZiAoIXNoZWxsKSB7XG4gICAgc2hlbGwgPSBzLnNwbGl0KF9jb2xvckV4cCk7XG4gICAgbCA9IHNoZWxsLmxlbmd0aCAtIDE7XG5cbiAgICBmb3IgKDsgaSA8IGw7IGkrKykge1xuICAgICAgcmVzdWx0ICs9IHNoZWxsW2ldICsgY29sb3JzW2ldO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiByZXN1bHQgKyBzaGVsbFtsXTtcbn0sXG4gICAgX2NvbG9yRXhwID0gZnVuY3Rpb24gKCkge1xuICB2YXIgcyA9IFwiKD86XFxcXGIoPzooPzpyZ2J8cmdiYXxoc2x8aHNsYSlcXFxcKC4rP1xcXFwpKXxcXFxcQiMoPzpbMC05YS1mXXszLDR9KXsxLDJ9XFxcXGJcIixcbiAgICAgIC8vd2UnbGwgZHluYW1pY2FsbHkgYnVpbGQgdGhpcyBSZWd1bGFyIEV4cHJlc3Npb24gdG8gY29uc2VydmUgZmlsZSBzaXplLiBBZnRlciBidWlsZGluZyBpdCwgaXQgd2lsbCBiZSBhYmxlIHRvIGZpbmQgcmdiKCksIHJnYmEoKSwgIyAoaGV4YWRlY2ltYWwpLCBhbmQgbmFtZWQgY29sb3IgdmFsdWVzIGxpa2UgcmVkLCBibHVlLCBwdXJwbGUsIGV0Yy4sXG4gIHA7XG5cbiAgZm9yIChwIGluIF9jb2xvckxvb2t1cCkge1xuICAgIHMgKz0gXCJ8XCIgKyBwICsgXCJcXFxcYlwiO1xuICB9XG5cbiAgcmV0dXJuIG5ldyBSZWdFeHAocyArIFwiKVwiLCBcImdpXCIpO1xufSgpLFxuICAgIF9oc2xFeHAgPSAvaHNsW2FdP1xcKC8sXG4gICAgX2NvbG9yU3RyaW5nRmlsdGVyID0gZnVuY3Rpb24gX2NvbG9yU3RyaW5nRmlsdGVyKGEpIHtcbiAgdmFyIGNvbWJpbmVkID0gYS5qb2luKFwiIFwiKSxcbiAgICAgIHRvSFNMO1xuICBfY29sb3JFeHAubGFzdEluZGV4ID0gMDtcblxuICBpZiAoX2NvbG9yRXhwLnRlc3QoY29tYmluZWQpKSB7XG4gICAgdG9IU0wgPSBfaHNsRXhwLnRlc3QoY29tYmluZWQpO1xuICAgIGFbMV0gPSBfZm9ybWF0Q29sb3JzKGFbMV0sIHRvSFNMKTtcbiAgICBhWzBdID0gX2Zvcm1hdENvbG9ycyhhWzBdLCB0b0hTTCwgX2NvbG9yT3JkZXJEYXRhKGFbMV0pKTsgLy8gbWFrZSBzdXJlIHRoZSBvcmRlciBvZiBudW1iZXJzL2NvbG9ycyBtYXRjaCB3aXRoIHRoZSBFTkQgdmFsdWUuXG5cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufSxcblxuLypcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiBUSUNLRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKi9cbl90aWNrZXJBY3RpdmUsXG4gICAgX3RpY2tlciA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIF9nZXRUaW1lID0gRGF0ZS5ub3csXG4gICAgICBfbGFnVGhyZXNob2xkID0gNTAwLFxuICAgICAgX2FkanVzdGVkTGFnID0gMzMsXG4gICAgICBfc3RhcnRUaW1lID0gX2dldFRpbWUoKSxcbiAgICAgIF9sYXN0VXBkYXRlID0gX3N0YXJ0VGltZSxcbiAgICAgIF9nYXAgPSAxMDAwIC8gMjQwLFxuICAgICAgX25leHRUaW1lID0gX2dhcCxcbiAgICAgIF9saXN0ZW5lcnMgPSBbXSxcbiAgICAgIF9pZCxcbiAgICAgIF9yZXEsXG4gICAgICBfcmFmLFxuICAgICAgX3NlbGYsXG4gICAgICBfZGVsdGEsXG4gICAgICBfaSxcbiAgICAgIF90aWNrID0gZnVuY3Rpb24gX3RpY2sodikge1xuICAgIHZhciBlbGFwc2VkID0gX2dldFRpbWUoKSAtIF9sYXN0VXBkYXRlLFxuICAgICAgICBtYW51YWwgPSB2ID09PSB0cnVlLFxuICAgICAgICBvdmVybGFwLFxuICAgICAgICBkaXNwYXRjaCxcbiAgICAgICAgdGltZSxcbiAgICAgICAgZnJhbWU7XG5cbiAgICAoZWxhcHNlZCA+IF9sYWdUaHJlc2hvbGQgfHwgZWxhcHNlZCA8IDApICYmIChfc3RhcnRUaW1lICs9IGVsYXBzZWQgLSBfYWRqdXN0ZWRMYWcpO1xuICAgIF9sYXN0VXBkYXRlICs9IGVsYXBzZWQ7XG4gICAgdGltZSA9IF9sYXN0VXBkYXRlIC0gX3N0YXJ0VGltZTtcbiAgICBvdmVybGFwID0gdGltZSAtIF9uZXh0VGltZTtcblxuICAgIGlmIChvdmVybGFwID4gMCB8fCBtYW51YWwpIHtcbiAgICAgIGZyYW1lID0gKytfc2VsZi5mcmFtZTtcbiAgICAgIF9kZWx0YSA9IHRpbWUgLSBfc2VsZi50aW1lICogMTAwMDtcbiAgICAgIF9zZWxmLnRpbWUgPSB0aW1lID0gdGltZSAvIDEwMDA7XG4gICAgICBfbmV4dFRpbWUgKz0gb3ZlcmxhcCArIChvdmVybGFwID49IF9nYXAgPyA0IDogX2dhcCAtIG92ZXJsYXApO1xuICAgICAgZGlzcGF0Y2ggPSAxO1xuICAgIH1cblxuICAgIG1hbnVhbCB8fCAoX2lkID0gX3JlcShfdGljaykpOyAvL21ha2Ugc3VyZSB0aGUgcmVxdWVzdCBpcyBtYWRlIGJlZm9yZSB3ZSBkaXNwYXRjaCB0aGUgXCJ0aWNrXCIgZXZlbnQgc28gdGhhdCB0aW1pbmcgaXMgbWFpbnRhaW5lZC4gT3RoZXJ3aXNlLCBpZiBwcm9jZXNzaW5nIHRoZSBcInRpY2tcIiByZXF1aXJlcyBhIGJ1bmNoIG9mIHRpbWUgKGxpa2UgMTVtcykgYW5kIHdlJ3JlIHVzaW5nIGEgc2V0VGltZW91dCgpIHRoYXQncyBiYXNlZCBvbiAxNi43bXMsIGl0J2QgdGVjaG5pY2FsbHkgdGFrZSAzMS43bXMgYmV0d2VlbiBmcmFtZXMgb3RoZXJ3aXNlLlxuXG4gICAgaWYgKGRpc3BhdGNoKSB7XG4gICAgICBmb3IgKF9pID0gMDsgX2kgPCBfbGlzdGVuZXJzLmxlbmd0aDsgX2krKykge1xuICAgICAgICAvLyB1c2UgX2kgYW5kIGNoZWNrIF9saXN0ZW5lcnMubGVuZ3RoIGluc3RlYWQgb2YgYSB2YXJpYWJsZSBiZWNhdXNlIGEgbGlzdGVuZXIgY291bGQgZ2V0IHJlbW92ZWQgZHVyaW5nIHRoZSBsb29wLCBhbmQgaWYgdGhhdCBoYXBwZW5zIHRvIGFuIGVsZW1lbnQgbGVzcyB0aGFuIHRoZSBjdXJyZW50IGluZGV4LCBpdCdkIHRocm93IHRoaW5ncyBvZmYgaW4gdGhlIGxvb3AuXG4gICAgICAgIF9saXN0ZW5lcnNbX2ldKHRpbWUsIF9kZWx0YSwgZnJhbWUsIHYpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICBfc2VsZiA9IHtcbiAgICB0aW1lOiAwLFxuICAgIGZyYW1lOiAwLFxuICAgIHRpY2s6IGZ1bmN0aW9uIHRpY2soKSB7XG4gICAgICBfdGljayh0cnVlKTtcbiAgICB9LFxuICAgIGRlbHRhUmF0aW86IGZ1bmN0aW9uIGRlbHRhUmF0aW8oZnBzKSB7XG4gICAgICByZXR1cm4gX2RlbHRhIC8gKDEwMDAgLyAoZnBzIHx8IDYwKSk7XG4gICAgfSxcbiAgICB3YWtlOiBmdW5jdGlvbiB3YWtlKCkge1xuICAgICAgaWYgKF9jb3JlUmVhZHkpIHtcbiAgICAgICAgaWYgKCFfY29yZUluaXR0ZWQgJiYgX3dpbmRvd0V4aXN0cygpKSB7XG4gICAgICAgICAgX3dpbiA9IF9jb3JlSW5pdHRlZCA9IHdpbmRvdztcbiAgICAgICAgICBfZG9jID0gX3dpbi5kb2N1bWVudCB8fCB7fTtcbiAgICAgICAgICBfZ2xvYmFscy5nc2FwID0gZ3NhcDtcbiAgICAgICAgICAoX3dpbi5nc2FwVmVyc2lvbnMgfHwgKF93aW4uZ3NhcFZlcnNpb25zID0gW10pKS5wdXNoKGdzYXAudmVyc2lvbik7XG5cbiAgICAgICAgICBfaW5zdGFsbChfaW5zdGFsbFNjb3BlIHx8IF93aW4uR3JlZW5Tb2NrR2xvYmFscyB8fCAhX3dpbi5nc2FwICYmIF93aW4gfHwge30pO1xuXG4gICAgICAgICAgX3JlZ2lzdGVyUGx1Z2luUXVldWUuZm9yRWFjaChfY3JlYXRlUGx1Z2luKTtcbiAgICAgICAgfVxuXG4gICAgICAgIF9yYWYgPSB0eXBlb2YgcmVxdWVzdEFuaW1hdGlvbkZyYW1lICE9PSBcInVuZGVmaW5lZFwiICYmIHJlcXVlc3RBbmltYXRpb25GcmFtZTtcbiAgICAgICAgX2lkICYmIF9zZWxmLnNsZWVwKCk7XG5cbiAgICAgICAgX3JlcSA9IF9yYWYgfHwgZnVuY3Rpb24gKGYpIHtcbiAgICAgICAgICByZXR1cm4gc2V0VGltZW91dChmLCBfbmV4dFRpbWUgLSBfc2VsZi50aW1lICogMTAwMCArIDEgfCAwKTtcbiAgICAgICAgfTtcblxuICAgICAgICBfdGlja2VyQWN0aXZlID0gMTtcblxuICAgICAgICBfdGljaygyKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHNsZWVwOiBmdW5jdGlvbiBzbGVlcCgpIHtcbiAgICAgIChfcmFmID8gY2FuY2VsQW5pbWF0aW9uRnJhbWUgOiBjbGVhclRpbWVvdXQpKF9pZCk7XG4gICAgICBfdGlja2VyQWN0aXZlID0gMDtcbiAgICAgIF9yZXEgPSBfZW1wdHlGdW5jO1xuICAgIH0sXG4gICAgbGFnU21vb3RoaW5nOiBmdW5jdGlvbiBsYWdTbW9vdGhpbmcodGhyZXNob2xkLCBhZGp1c3RlZExhZykge1xuICAgICAgX2xhZ1RocmVzaG9sZCA9IHRocmVzaG9sZCB8fCBJbmZpbml0eTsgLy8gemVybyBzaG91bGQgYmUgaW50ZXJwcmV0ZWQgYXMgYmFzaWNhbGx5IHVubGltaXRlZFxuXG4gICAgICBfYWRqdXN0ZWRMYWcgPSBNYXRoLm1pbihhZGp1c3RlZExhZyB8fCAzMywgX2xhZ1RocmVzaG9sZCk7XG4gICAgfSxcbiAgICBmcHM6IGZ1bmN0aW9uIGZwcyhfZnBzKSB7XG4gICAgICBfZ2FwID0gMTAwMCAvIChfZnBzIHx8IDI0MCk7XG4gICAgICBfbmV4dFRpbWUgPSBfc2VsZi50aW1lICogMTAwMCArIF9nYXA7XG4gICAgfSxcbiAgICBhZGQ6IGZ1bmN0aW9uIGFkZChjYWxsYmFjaywgb25jZSwgcHJpb3JpdGl6ZSkge1xuICAgICAgdmFyIGZ1bmMgPSBvbmNlID8gZnVuY3Rpb24gKHQsIGQsIGYsIHYpIHtcbiAgICAgICAgY2FsbGJhY2sodCwgZCwgZiwgdik7XG5cbiAgICAgICAgX3NlbGYucmVtb3ZlKGZ1bmMpO1xuICAgICAgfSA6IGNhbGxiYWNrO1xuXG4gICAgICBfc2VsZi5yZW1vdmUoY2FsbGJhY2spO1xuXG4gICAgICBfbGlzdGVuZXJzW3ByaW9yaXRpemUgPyBcInVuc2hpZnRcIiA6IFwicHVzaFwiXShmdW5jKTtcblxuICAgICAgX3dha2UoKTtcblxuICAgICAgcmV0dXJuIGZ1bmM7XG4gICAgfSxcbiAgICByZW1vdmU6IGZ1bmN0aW9uIHJlbW92ZShjYWxsYmFjaywgaSkge1xuICAgICAgfihpID0gX2xpc3RlbmVycy5pbmRleE9mKGNhbGxiYWNrKSkgJiYgX2xpc3RlbmVycy5zcGxpY2UoaSwgMSkgJiYgX2kgPj0gaSAmJiBfaS0tO1xuICAgIH0sXG4gICAgX2xpc3RlbmVyczogX2xpc3RlbmVyc1xuICB9O1xuICByZXR1cm4gX3NlbGY7XG59KCksXG4gICAgX3dha2UgPSBmdW5jdGlvbiBfd2FrZSgpIHtcbiAgcmV0dXJuICFfdGlja2VyQWN0aXZlICYmIF90aWNrZXIud2FrZSgpO1xufSxcbiAgICAvL2Fsc28gZW5zdXJlcyB0aGUgY29yZSBjbGFzc2VzIGFyZSBpbml0aWFsaXplZC5cblxuLypcbiogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuKiBFQVNJTkdcbiogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuKi9cbl9lYXNlTWFwID0ge30sXG4gICAgX2N1c3RvbUVhc2VFeHAgPSAvXltcXGQuXFwtTV1bXFxkLlxcLSxcXHNdLyxcbiAgICBfcXVvdGVzRXhwID0gL1tcIiddL2csXG4gICAgX3BhcnNlT2JqZWN0SW5TdHJpbmcgPSBmdW5jdGlvbiBfcGFyc2VPYmplY3RJblN0cmluZyh2YWx1ZSkge1xuICAvL3Rha2VzIGEgc3RyaW5nIGxpa2UgXCJ7d2lnZ2xlczoxMCwgdHlwZTphbnRpY2lwYXRlfSlcIiBhbmQgdHVybnMgaXQgaW50byBhIHJlYWwgb2JqZWN0LiBOb3RpY2UgaXQgZW5kcyBpbiBcIilcIiBhbmQgaW5jbHVkZXMgdGhlIHt9IHdyYXBwZXJzLiBUaGlzIGlzIGJlY2F1c2Ugd2Ugb25seSB1c2UgdGhpcyBmdW5jdGlvbiBmb3IgcGFyc2luZyBlYXNlIGNvbmZpZ3MgYW5kIHByaW9yaXRpemVkIG9wdGltaXphdGlvbiByYXRoZXIgdGhhbiByZXVzYWJpbGl0eS5cbiAgdmFyIG9iaiA9IHt9LFxuICAgICAgc3BsaXQgPSB2YWx1ZS5zdWJzdHIoMSwgdmFsdWUubGVuZ3RoIC0gMykuc3BsaXQoXCI6XCIpLFxuICAgICAga2V5ID0gc3BsaXRbMF0sXG4gICAgICBpID0gMSxcbiAgICAgIGwgPSBzcGxpdC5sZW5ndGgsXG4gICAgICBpbmRleCxcbiAgICAgIHZhbCxcbiAgICAgIHBhcnNlZFZhbDtcblxuICBmb3IgKDsgaSA8IGw7IGkrKykge1xuICAgIHZhbCA9IHNwbGl0W2ldO1xuICAgIGluZGV4ID0gaSAhPT0gbCAtIDEgPyB2YWwubGFzdEluZGV4T2YoXCIsXCIpIDogdmFsLmxlbmd0aDtcbiAgICBwYXJzZWRWYWwgPSB2YWwuc3Vic3RyKDAsIGluZGV4KTtcbiAgICBvYmpba2V5XSA9IGlzTmFOKHBhcnNlZFZhbCkgPyBwYXJzZWRWYWwucmVwbGFjZShfcXVvdGVzRXhwLCBcIlwiKS50cmltKCkgOiArcGFyc2VkVmFsO1xuICAgIGtleSA9IHZhbC5zdWJzdHIoaW5kZXggKyAxKS50cmltKCk7XG4gIH1cblxuICByZXR1cm4gb2JqO1xufSxcbiAgICBfdmFsdWVJblBhcmVudGhlc2VzID0gZnVuY3Rpb24gX3ZhbHVlSW5QYXJlbnRoZXNlcyh2YWx1ZSkge1xuICB2YXIgb3BlbiA9IHZhbHVlLmluZGV4T2YoXCIoXCIpICsgMSxcbiAgICAgIGNsb3NlID0gdmFsdWUuaW5kZXhPZihcIilcIiksXG4gICAgICBuZXN0ZWQgPSB2YWx1ZS5pbmRleE9mKFwiKFwiLCBvcGVuKTtcbiAgcmV0dXJuIHZhbHVlLnN1YnN0cmluZyhvcGVuLCB+bmVzdGVkICYmIG5lc3RlZCA8IGNsb3NlID8gdmFsdWUuaW5kZXhPZihcIilcIiwgY2xvc2UgKyAxKSA6IGNsb3NlKTtcbn0sXG4gICAgX2NvbmZpZ0Vhc2VGcm9tU3RyaW5nID0gZnVuY3Rpb24gX2NvbmZpZ0Vhc2VGcm9tU3RyaW5nKG5hbWUpIHtcbiAgLy9uYW1lIGNhbiBiZSBhIHN0cmluZyBsaWtlIFwiZWxhc3RpYy5vdXQoMSwwLjUpXCIsIGFuZCBwYXNzIGluIF9lYXNlTWFwIGFzIG9iaiBhbmQgaXQnbGwgcGFyc2UgaXQgb3V0IGFuZCBjYWxsIHRoZSBhY3R1YWwgZnVuY3Rpb24gbGlrZSBfZWFzZU1hcC5FbGFzdGljLmVhc2VPdXQuY29uZmlnKDEsMC41KS4gSXQgd2lsbCBhbHNvIHBhcnNlIGN1c3RvbSBlYXNlIHN0cmluZ3MgYXMgbG9uZyBhcyBDdXN0b21FYXNlIGlzIGxvYWRlZCBhbmQgcmVnaXN0ZXJlZCAoaW50ZXJuYWxseSBhcyBfZWFzZU1hcC5fQ0UpLlxuICB2YXIgc3BsaXQgPSAobmFtZSArIFwiXCIpLnNwbGl0KFwiKFwiKSxcbiAgICAgIGVhc2UgPSBfZWFzZU1hcFtzcGxpdFswXV07XG4gIHJldHVybiBlYXNlICYmIHNwbGl0Lmxlbmd0aCA+IDEgJiYgZWFzZS5jb25maWcgPyBlYXNlLmNvbmZpZy5hcHBseShudWxsLCB+bmFtZS5pbmRleE9mKFwie1wiKSA/IFtfcGFyc2VPYmplY3RJblN0cmluZyhzcGxpdFsxXSldIDogX3ZhbHVlSW5QYXJlbnRoZXNlcyhuYW1lKS5zcGxpdChcIixcIikubWFwKF9udW1lcmljSWZQb3NzaWJsZSkpIDogX2Vhc2VNYXAuX0NFICYmIF9jdXN0b21FYXNlRXhwLnRlc3QobmFtZSkgPyBfZWFzZU1hcC5fQ0UoXCJcIiwgbmFtZSkgOiBlYXNlO1xufSxcbiAgICBfaW52ZXJ0RWFzZSA9IGZ1bmN0aW9uIF9pbnZlcnRFYXNlKGVhc2UpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIChwKSB7XG4gICAgcmV0dXJuIDEgLSBlYXNlKDEgLSBwKTtcbiAgfTtcbn0sXG4gICAgX3BhcnNlRWFzZSA9IGZ1bmN0aW9uIF9wYXJzZUVhc2UoZWFzZSwgZGVmYXVsdEVhc2UpIHtcbiAgcmV0dXJuICFlYXNlID8gZGVmYXVsdEVhc2UgOiAoX2lzRnVuY3Rpb24oZWFzZSkgPyBlYXNlIDogX2Vhc2VNYXBbZWFzZV0gfHwgX2NvbmZpZ0Vhc2VGcm9tU3RyaW5nKGVhc2UpKSB8fCBkZWZhdWx0RWFzZTtcbn0sXG4gICAgX2luc2VydEVhc2UgPSBmdW5jdGlvbiBfaW5zZXJ0RWFzZShuYW1lcywgZWFzZUluLCBlYXNlT3V0LCBlYXNlSW5PdXQpIHtcbiAgaWYgKGVhc2VPdXQgPT09IHZvaWQgMCkge1xuICAgIGVhc2VPdXQgPSBmdW5jdGlvbiBlYXNlT3V0KHApIHtcbiAgICAgIHJldHVybiAxIC0gZWFzZUluKDEgLSBwKTtcbiAgICB9O1xuICB9XG5cbiAgaWYgKGVhc2VJbk91dCA9PT0gdm9pZCAwKSB7XG4gICAgZWFzZUluT3V0ID0gZnVuY3Rpb24gZWFzZUluT3V0KHApIHtcbiAgICAgIHJldHVybiBwIDwgLjUgPyBlYXNlSW4ocCAqIDIpIC8gMiA6IDEgLSBlYXNlSW4oKDEgLSBwKSAqIDIpIC8gMjtcbiAgICB9O1xuICB9XG5cbiAgdmFyIGVhc2UgPSB7XG4gICAgZWFzZUluOiBlYXNlSW4sXG4gICAgZWFzZU91dDogZWFzZU91dCxcbiAgICBlYXNlSW5PdXQ6IGVhc2VJbk91dFxuICB9LFxuICAgICAgbG93ZXJjYXNlTmFtZTtcblxuICBfZm9yRWFjaE5hbWUobmFtZXMsIGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgX2Vhc2VNYXBbbmFtZV0gPSBfZ2xvYmFsc1tuYW1lXSA9IGVhc2U7XG4gICAgX2Vhc2VNYXBbbG93ZXJjYXNlTmFtZSA9IG5hbWUudG9Mb3dlckNhc2UoKV0gPSBlYXNlT3V0O1xuXG4gICAgZm9yICh2YXIgcCBpbiBlYXNlKSB7XG4gICAgICBfZWFzZU1hcFtsb3dlcmNhc2VOYW1lICsgKHAgPT09IFwiZWFzZUluXCIgPyBcIi5pblwiIDogcCA9PT0gXCJlYXNlT3V0XCIgPyBcIi5vdXRcIiA6IFwiLmluT3V0XCIpXSA9IF9lYXNlTWFwW25hbWUgKyBcIi5cIiArIHBdID0gZWFzZVtwXTtcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiBlYXNlO1xufSxcbiAgICBfZWFzZUluT3V0RnJvbU91dCA9IGZ1bmN0aW9uIF9lYXNlSW5PdXRGcm9tT3V0KGVhc2VPdXQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIChwKSB7XG4gICAgcmV0dXJuIHAgPCAuNSA/ICgxIC0gZWFzZU91dCgxIC0gcCAqIDIpKSAvIDIgOiAuNSArIGVhc2VPdXQoKHAgLSAuNSkgKiAyKSAvIDI7XG4gIH07XG59LFxuICAgIF9jb25maWdFbGFzdGljID0gZnVuY3Rpb24gX2NvbmZpZ0VsYXN0aWModHlwZSwgYW1wbGl0dWRlLCBwZXJpb2QpIHtcbiAgdmFyIHAxID0gYW1wbGl0dWRlID49IDEgPyBhbXBsaXR1ZGUgOiAxLFxuICAgICAgLy9ub3RlOiBpZiBhbXBsaXR1ZGUgaXMgPCAxLCB3ZSBzaW1wbHkgYWRqdXN0IHRoZSBwZXJpb2QgZm9yIGEgbW9yZSBuYXR1cmFsIGZlZWwuIE90aGVyd2lzZSB0aGUgbWF0aCBkb2Vzbid0IHdvcmsgcmlnaHQgYW5kIHRoZSBjdXJ2ZSBzdGFydHMgYXQgMS5cbiAgcDIgPSAocGVyaW9kIHx8ICh0eXBlID8gLjMgOiAuNDUpKSAvIChhbXBsaXR1ZGUgPCAxID8gYW1wbGl0dWRlIDogMSksXG4gICAgICBwMyA9IHAyIC8gXzJQSSAqIChNYXRoLmFzaW4oMSAvIHAxKSB8fCAwKSxcbiAgICAgIGVhc2VPdXQgPSBmdW5jdGlvbiBlYXNlT3V0KHApIHtcbiAgICByZXR1cm4gcCA9PT0gMSA/IDEgOiBwMSAqIE1hdGgucG93KDIsIC0xMCAqIHApICogX3NpbigocCAtIHAzKSAqIHAyKSArIDE7XG4gIH0sXG4gICAgICBlYXNlID0gdHlwZSA9PT0gXCJvdXRcIiA/IGVhc2VPdXQgOiB0eXBlID09PSBcImluXCIgPyBmdW5jdGlvbiAocCkge1xuICAgIHJldHVybiAxIC0gZWFzZU91dCgxIC0gcCk7XG4gIH0gOiBfZWFzZUluT3V0RnJvbU91dChlYXNlT3V0KTtcblxuICBwMiA9IF8yUEkgLyBwMjsgLy9wcmVjYWxjdWxhdGUgdG8gb3B0aW1pemVcblxuICBlYXNlLmNvbmZpZyA9IGZ1bmN0aW9uIChhbXBsaXR1ZGUsIHBlcmlvZCkge1xuICAgIHJldHVybiBfY29uZmlnRWxhc3RpYyh0eXBlLCBhbXBsaXR1ZGUsIHBlcmlvZCk7XG4gIH07XG5cbiAgcmV0dXJuIGVhc2U7XG59LFxuICAgIF9jb25maWdCYWNrID0gZnVuY3Rpb24gX2NvbmZpZ0JhY2sodHlwZSwgb3ZlcnNob290KSB7XG4gIGlmIChvdmVyc2hvb3QgPT09IHZvaWQgMCkge1xuICAgIG92ZXJzaG9vdCA9IDEuNzAxNTg7XG4gIH1cblxuICB2YXIgZWFzZU91dCA9IGZ1bmN0aW9uIGVhc2VPdXQocCkge1xuICAgIHJldHVybiBwID8gLS1wICogcCAqICgob3ZlcnNob290ICsgMSkgKiBwICsgb3ZlcnNob290KSArIDEgOiAwO1xuICB9LFxuICAgICAgZWFzZSA9IHR5cGUgPT09IFwib3V0XCIgPyBlYXNlT3V0IDogdHlwZSA9PT0gXCJpblwiID8gZnVuY3Rpb24gKHApIHtcbiAgICByZXR1cm4gMSAtIGVhc2VPdXQoMSAtIHApO1xuICB9IDogX2Vhc2VJbk91dEZyb21PdXQoZWFzZU91dCk7XG5cbiAgZWFzZS5jb25maWcgPSBmdW5jdGlvbiAob3ZlcnNob290KSB7XG4gICAgcmV0dXJuIF9jb25maWdCYWNrKHR5cGUsIG92ZXJzaG9vdCk7XG4gIH07XG5cbiAgcmV0dXJuIGVhc2U7XG59OyAvLyBhIGNoZWFwZXIgKGtiIGFuZCBjcHUpIGJ1dCBtb3JlIG1pbGQgd2F5IHRvIGdldCBhIHBhcmFtZXRlcml6ZWQgd2VpZ2h0ZWQgZWFzZSBieSBmZWVkaW5nIGluIGEgdmFsdWUgYmV0d2VlbiAtMSAoZWFzZUluKSBhbmQgMSAoZWFzZU91dCkgd2hlcmUgMCBpcyBsaW5lYXIuXG4vLyBfd2VpZ2h0ZWRFYXNlID0gcmF0aW8gPT4ge1xuLy8gXHRsZXQgeSA9IDAuNSArIHJhdGlvIC8gMjtcbi8vIFx0cmV0dXJuIHAgPT4gKDIgKiAoMSAtIHApICogcCAqIHkgKyBwICogcCk7XG4vLyB9LFxuLy8gYSBzdHJvbmdlciAoYnV0IG1vcmUgZXhwZW5zaXZlIGtiL2NwdSkgcGFyYW1ldGVyaXplZCB3ZWlnaHRlZCBlYXNlIHRoYXQgbGV0cyB5b3UgZmVlZCBpbiBhIHZhbHVlIGJldHdlZW4gLTEgKGVhc2VJbikgYW5kIDEgKGVhc2VPdXQpIHdoZXJlIDAgaXMgbGluZWFyLlxuLy8gX3dlaWdodGVkRWFzZVN0cm9uZyA9IHJhdGlvID0+IHtcbi8vIFx0cmF0aW8gPSAuNSArIHJhdGlvIC8gMjtcbi8vIFx0bGV0IG8gPSAxIC8gMyAqIChyYXRpbyA8IC41ID8gcmF0aW8gOiAxIC0gcmF0aW8pLFxuLy8gXHRcdGIgPSByYXRpbyAtIG8sXG4vLyBcdFx0YyA9IHJhdGlvICsgbztcbi8vIFx0cmV0dXJuIHAgPT4gcCA9PT0gMSA/IHAgOiAzICogYiAqICgxIC0gcCkgKiAoMSAtIHApICogcCArIDMgKiBjICogKDEgLSBwKSAqIHAgKiBwICsgcCAqIHAgKiBwO1xuLy8gfTtcblxuXG5fZm9yRWFjaE5hbWUoXCJMaW5lYXIsUXVhZCxDdWJpYyxRdWFydCxRdWludCxTdHJvbmdcIiwgZnVuY3Rpb24gKG5hbWUsIGkpIHtcbiAgdmFyIHBvd2VyID0gaSA8IDUgPyBpICsgMSA6IGk7XG5cbiAgX2luc2VydEVhc2UobmFtZSArIFwiLFBvd2VyXCIgKyAocG93ZXIgLSAxKSwgaSA/IGZ1bmN0aW9uIChwKSB7XG4gICAgcmV0dXJuIE1hdGgucG93KHAsIHBvd2VyKTtcbiAgfSA6IGZ1bmN0aW9uIChwKSB7XG4gICAgcmV0dXJuIHA7XG4gIH0sIGZ1bmN0aW9uIChwKSB7XG4gICAgcmV0dXJuIDEgLSBNYXRoLnBvdygxIC0gcCwgcG93ZXIpO1xuICB9LCBmdW5jdGlvbiAocCkge1xuICAgIHJldHVybiBwIDwgLjUgPyBNYXRoLnBvdyhwICogMiwgcG93ZXIpIC8gMiA6IDEgLSBNYXRoLnBvdygoMSAtIHApICogMiwgcG93ZXIpIC8gMjtcbiAgfSk7XG59KTtcblxuX2Vhc2VNYXAuTGluZWFyLmVhc2VOb25lID0gX2Vhc2VNYXAubm9uZSA9IF9lYXNlTWFwLkxpbmVhci5lYXNlSW47XG5cbl9pbnNlcnRFYXNlKFwiRWxhc3RpY1wiLCBfY29uZmlnRWxhc3RpYyhcImluXCIpLCBfY29uZmlnRWxhc3RpYyhcIm91dFwiKSwgX2NvbmZpZ0VsYXN0aWMoKSk7XG5cbihmdW5jdGlvbiAobiwgYykge1xuICB2YXIgbjEgPSAxIC8gYyxcbiAgICAgIG4yID0gMiAqIG4xLFxuICAgICAgbjMgPSAyLjUgKiBuMSxcbiAgICAgIGVhc2VPdXQgPSBmdW5jdGlvbiBlYXNlT3V0KHApIHtcbiAgICByZXR1cm4gcCA8IG4xID8gbiAqIHAgKiBwIDogcCA8IG4yID8gbiAqIE1hdGgucG93KHAgLSAxLjUgLyBjLCAyKSArIC43NSA6IHAgPCBuMyA/IG4gKiAocCAtPSAyLjI1IC8gYykgKiBwICsgLjkzNzUgOiBuICogTWF0aC5wb3cocCAtIDIuNjI1IC8gYywgMikgKyAuOTg0Mzc1O1xuICB9O1xuXG4gIF9pbnNlcnRFYXNlKFwiQm91bmNlXCIsIGZ1bmN0aW9uIChwKSB7XG4gICAgcmV0dXJuIDEgLSBlYXNlT3V0KDEgLSBwKTtcbiAgfSwgZWFzZU91dCk7XG59KSg3LjU2MjUsIDIuNzUpO1xuXG5faW5zZXJ0RWFzZShcIkV4cG9cIiwgZnVuY3Rpb24gKHApIHtcbiAgcmV0dXJuIE1hdGgucG93KDIsIDEwICogKHAgLSAxKSkgKiBwICsgcCAqIHAgKiBwICogcCAqIHAgKiBwICogKDEgLSBwKTtcbn0pOyAvLyBwcmV2aW91c2x5IDIgKiogKDEwICogKHAgLSAxKSkgYnV0IHRoYXQgZG9lc24ndCBlbmQgdXAgd2l0aCB0aGUgdmFsdWUgcXVpdGUgYXQgdGhlIHJpZ2h0IHNwb3Qgc28gd2UgZG8gYSBibGVuZGVkIGVhc2UgdG8gZW5zdXJlIGl0IGxhbmRzIHdoZXJlIGl0IHNob3VsZCBwZXJmZWN0bHkuXG5cblxuX2luc2VydEVhc2UoXCJDaXJjXCIsIGZ1bmN0aW9uIChwKSB7XG4gIHJldHVybiAtKF9zcXJ0KDEgLSBwICogcCkgLSAxKTtcbn0pO1xuXG5faW5zZXJ0RWFzZShcIlNpbmVcIiwgZnVuY3Rpb24gKHApIHtcbiAgcmV0dXJuIHAgPT09IDEgPyAxIDogLV9jb3MocCAqIF9IQUxGX1BJKSArIDE7XG59KTtcblxuX2luc2VydEVhc2UoXCJCYWNrXCIsIF9jb25maWdCYWNrKFwiaW5cIiksIF9jb25maWdCYWNrKFwib3V0XCIpLCBfY29uZmlnQmFjaygpKTtcblxuX2Vhc2VNYXAuU3RlcHBlZEVhc2UgPSBfZWFzZU1hcC5zdGVwcyA9IF9nbG9iYWxzLlN0ZXBwZWRFYXNlID0ge1xuICBjb25maWc6IGZ1bmN0aW9uIGNvbmZpZyhzdGVwcywgaW1tZWRpYXRlU3RhcnQpIHtcbiAgICBpZiAoc3RlcHMgPT09IHZvaWQgMCkge1xuICAgICAgc3RlcHMgPSAxO1xuICAgIH1cblxuICAgIHZhciBwMSA9IDEgLyBzdGVwcyxcbiAgICAgICAgcDIgPSBzdGVwcyArIChpbW1lZGlhdGVTdGFydCA/IDAgOiAxKSxcbiAgICAgICAgcDMgPSBpbW1lZGlhdGVTdGFydCA/IDEgOiAwLFxuICAgICAgICBtYXggPSAxIC0gX3RpbnlOdW07XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChwKSB7XG4gICAgICByZXR1cm4gKChwMiAqIF9jbGFtcCgwLCBtYXgsIHApIHwgMCkgKyBwMykgKiBwMTtcbiAgICB9O1xuICB9XG59O1xuX2RlZmF1bHRzLmVhc2UgPSBfZWFzZU1hcFtcInF1YWQub3V0XCJdO1xuXG5fZm9yRWFjaE5hbWUoXCJvbkNvbXBsZXRlLG9uVXBkYXRlLG9uU3RhcnQsb25SZXBlYXQsb25SZXZlcnNlQ29tcGxldGUsb25JbnRlcnJ1cHRcIiwgZnVuY3Rpb24gKG5hbWUpIHtcbiAgcmV0dXJuIF9jYWxsYmFja05hbWVzICs9IG5hbWUgKyBcIixcIiArIG5hbWUgKyBcIlBhcmFtcyxcIjtcbn0pO1xuLypcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiBDQUNIRVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqL1xuXG5cbmV4cG9ydCB2YXIgR1NDYWNoZSA9IGZ1bmN0aW9uIEdTQ2FjaGUodGFyZ2V0LCBoYXJuZXNzKSB7XG4gIHRoaXMuaWQgPSBfZ3NJRCsrO1xuICB0YXJnZXQuX2dzYXAgPSB0aGlzO1xuICB0aGlzLnRhcmdldCA9IHRhcmdldDtcbiAgdGhpcy5oYXJuZXNzID0gaGFybmVzcztcbiAgdGhpcy5nZXQgPSBoYXJuZXNzID8gaGFybmVzcy5nZXQgOiBfZ2V0UHJvcGVydHk7XG4gIHRoaXMuc2V0ID0gaGFybmVzcyA/IGhhcm5lc3MuZ2V0U2V0dGVyIDogX2dldFNldHRlcjtcbn07XG4vKlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqIEFOSU1BVElPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqL1xuXG5leHBvcnQgdmFyIEFuaW1hdGlvbiA9IC8qI19fUFVSRV9fKi9mdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIEFuaW1hdGlvbih2YXJzKSB7XG4gICAgdGhpcy52YXJzID0gdmFycztcbiAgICB0aGlzLl9kZWxheSA9ICt2YXJzLmRlbGF5IHx8IDA7XG5cbiAgICBpZiAodGhpcy5fcmVwZWF0ID0gdmFycy5yZXBlYXQgPT09IEluZmluaXR5ID8gLTIgOiB2YXJzLnJlcGVhdCB8fCAwKSB7XG4gICAgICAvLyBUT0RPOiByZXBlYXQ6IEluZmluaXR5IG9uIGEgdGltZWxpbmUncyBjaGlsZHJlbiBtdXN0IGZsYWcgdGhhdCB0aW1lbGluZSBpbnRlcm5hbGx5IGFuZCBhZmZlY3QgaXRzIHRvdGFsRHVyYXRpb24sIG90aGVyd2lzZSBpdCdsbCBzdG9wIGluIHRoZSBuZWdhdGl2ZSBkaXJlY3Rpb24gd2hlbiByZWFjaGluZyB0aGUgc3RhcnQuXG4gICAgICB0aGlzLl9yRGVsYXkgPSB2YXJzLnJlcGVhdERlbGF5IHx8IDA7XG4gICAgICB0aGlzLl95b3lvID0gISF2YXJzLnlveW8gfHwgISF2YXJzLnlveW9FYXNlO1xuICAgIH1cblxuICAgIHRoaXMuX3RzID0gMTtcblxuICAgIF9zZXREdXJhdGlvbih0aGlzLCArdmFycy5kdXJhdGlvbiwgMSwgMSk7XG5cbiAgICB0aGlzLmRhdGEgPSB2YXJzLmRhdGE7XG5cbiAgICBpZiAoX2NvbnRleHQpIHtcbiAgICAgIHRoaXMuX2N0eCA9IF9jb250ZXh0O1xuXG4gICAgICBfY29udGV4dC5kYXRhLnB1c2godGhpcyk7XG4gICAgfVxuXG4gICAgX3RpY2tlckFjdGl2ZSB8fCBfdGlja2VyLndha2UoKTtcbiAgfVxuXG4gIHZhciBfcHJvdG8gPSBBbmltYXRpb24ucHJvdG90eXBlO1xuXG4gIF9wcm90by5kZWxheSA9IGZ1bmN0aW9uIGRlbGF5KHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlIHx8IHZhbHVlID09PSAwKSB7XG4gICAgICB0aGlzLnBhcmVudCAmJiB0aGlzLnBhcmVudC5zbW9vdGhDaGlsZFRpbWluZyAmJiB0aGlzLnN0YXJ0VGltZSh0aGlzLl9zdGFydCArIHZhbHVlIC0gdGhpcy5fZGVsYXkpO1xuICAgICAgdGhpcy5fZGVsYXkgPSB2YWx1ZTtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLl9kZWxheTtcbiAgfTtcblxuICBfcHJvdG8uZHVyYXRpb24gPSBmdW5jdGlvbiBkdXJhdGlvbih2YWx1ZSkge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gdGhpcy50b3RhbER1cmF0aW9uKHRoaXMuX3JlcGVhdCA+IDAgPyB2YWx1ZSArICh2YWx1ZSArIHRoaXMuX3JEZWxheSkgKiB0aGlzLl9yZXBlYXQgOiB2YWx1ZSkgOiB0aGlzLnRvdGFsRHVyYXRpb24oKSAmJiB0aGlzLl9kdXI7XG4gIH07XG5cbiAgX3Byb3RvLnRvdGFsRHVyYXRpb24gPSBmdW5jdGlvbiB0b3RhbER1cmF0aW9uKHZhbHVlKSB7XG4gICAgaWYgKCFhcmd1bWVudHMubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gdGhpcy5fdER1cjtcbiAgICB9XG5cbiAgICB0aGlzLl9kaXJ0eSA9IDA7XG4gICAgcmV0dXJuIF9zZXREdXJhdGlvbih0aGlzLCB0aGlzLl9yZXBlYXQgPCAwID8gdmFsdWUgOiAodmFsdWUgLSB0aGlzLl9yZXBlYXQgKiB0aGlzLl9yRGVsYXkpIC8gKHRoaXMuX3JlcGVhdCArIDEpKTtcbiAgfTtcblxuICBfcHJvdG8udG90YWxUaW1lID0gZnVuY3Rpb24gdG90YWxUaW1lKF90b3RhbFRpbWUsIHN1cHByZXNzRXZlbnRzKSB7XG4gICAgX3dha2UoKTtcblxuICAgIGlmICghYXJndW1lbnRzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIHRoaXMuX3RUaW1lO1xuICAgIH1cblxuICAgIHZhciBwYXJlbnQgPSB0aGlzLl9kcDtcblxuICAgIGlmIChwYXJlbnQgJiYgcGFyZW50LnNtb290aENoaWxkVGltaW5nICYmIHRoaXMuX3RzKSB7XG4gICAgICBfYWxpZ25QbGF5aGVhZCh0aGlzLCBfdG90YWxUaW1lKTtcblxuICAgICAgIXBhcmVudC5fZHAgfHwgcGFyZW50LnBhcmVudCB8fCBfcG9zdEFkZENoZWNrcyhwYXJlbnQsIHRoaXMpOyAvLyBlZGdlIGNhc2U6IGlmIHRoaXMgaXMgYSBjaGlsZCBvZiBhIHRpbWVsaW5lIHRoYXQgYWxyZWFkeSBjb21wbGV0ZWQsIGZvciBleGFtcGxlLCB3ZSBtdXN0IHJlLWFjdGl2YXRlIHRoZSBwYXJlbnQuXG4gICAgICAvL2luIGNhc2UgYW55IG9mIHRoZSBhbmNlc3RvciB0aW1lbGluZXMgaGFkIGNvbXBsZXRlZCBidXQgc2hvdWxkIG5vdyBiZSBlbmFibGVkLCB3ZSBzaG91bGQgcmVzZXQgdGhlaXIgdG90YWxUaW1lKCkgd2hpY2ggd2lsbCBhbHNvIGVuc3VyZSB0aGF0IHRoZXkncmUgbGluZWQgdXAgcHJvcGVybHkgYW5kIGVuYWJsZWQuIFNraXAgZm9yIGFuaW1hdGlvbnMgdGhhdCBhcmUgb24gdGhlIHJvb3QgKHdhc3RlZnVsKS4gRXhhbXBsZTogYSBUaW1lbGluZUxpdGUuZXhwb3J0Um9vdCgpIGlzIHBlcmZvcm1lZCB3aGVuIHRoZXJlJ3MgYSBwYXVzZWQgdHdlZW4gb24gdGhlIHJvb3QsIHRoZSBleHBvcnQgd2lsbCBub3QgY29tcGxldGUgdW50aWwgdGhhdCB0d2VlbiBpcyB1bnBhdXNlZCwgYnV0IGltYWdpbmUgYSBjaGlsZCBnZXRzIHJlc3RhcnRlZCBsYXRlciwgYWZ0ZXIgYWxsIFt1bnBhdXNlZF0gdHdlZW5zIGhhdmUgY29tcGxldGVkLiBUaGUgc3RhcnQgb2YgdGhhdCBjaGlsZCB3b3VsZCBnZXQgcHVzaGVkIG91dCwgYnV0IG9uZSBvZiB0aGUgYW5jZXN0b3JzIG1heSBoYXZlIGNvbXBsZXRlZC5cblxuICAgICAgd2hpbGUgKHBhcmVudCAmJiBwYXJlbnQucGFyZW50KSB7XG4gICAgICAgIGlmIChwYXJlbnQucGFyZW50Ll90aW1lICE9PSBwYXJlbnQuX3N0YXJ0ICsgKHBhcmVudC5fdHMgPj0gMCA/IHBhcmVudC5fdFRpbWUgLyBwYXJlbnQuX3RzIDogKHBhcmVudC50b3RhbER1cmF0aW9uKCkgLSBwYXJlbnQuX3RUaW1lKSAvIC1wYXJlbnQuX3RzKSkge1xuICAgICAgICAgIHBhcmVudC50b3RhbFRpbWUocGFyZW50Ll90VGltZSwgdHJ1ZSk7XG4gICAgICAgIH1cblxuICAgICAgICBwYXJlbnQgPSBwYXJlbnQucGFyZW50O1xuICAgICAgfVxuXG4gICAgICBpZiAoIXRoaXMucGFyZW50ICYmIHRoaXMuX2RwLmF1dG9SZW1vdmVDaGlsZHJlbiAmJiAodGhpcy5fdHMgPiAwICYmIF90b3RhbFRpbWUgPCB0aGlzLl90RHVyIHx8IHRoaXMuX3RzIDwgMCAmJiBfdG90YWxUaW1lID4gMCB8fCAhdGhpcy5fdER1ciAmJiAhX3RvdGFsVGltZSkpIHtcbiAgICAgICAgLy9pZiB0aGUgYW5pbWF0aW9uIGRvZXNuJ3QgaGF2ZSBhIHBhcmVudCwgcHV0IGl0IGJhY2sgaW50byBpdHMgbGFzdCBwYXJlbnQgKHJlY29yZGVkIGFzIF9kcCBmb3IgZXhhY3RseSBjYXNlcyBsaWtlIHRoaXMpLiBMaW1pdCB0byBwYXJlbnRzIHdpdGggYXV0b1JlbW92ZUNoaWxkcmVuIChsaWtlIGdsb2JhbFRpbWVsaW5lKSBzbyB0aGF0IGlmIHRoZSB1c2VyIG1hbnVhbGx5IHJlbW92ZXMgYW4gYW5pbWF0aW9uIGZyb20gYSB0aW1lbGluZSBhbmQgdGhlbiBhbHRlcnMgaXRzIHBsYXloZWFkLCBpdCBkb2Vzbid0IGdldCBhZGRlZCBiYWNrIGluLlxuICAgICAgICBfYWRkVG9UaW1lbGluZSh0aGlzLl9kcCwgdGhpcywgdGhpcy5fc3RhcnQgLSB0aGlzLl9kZWxheSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX3RUaW1lICE9PSBfdG90YWxUaW1lIHx8ICF0aGlzLl9kdXIgJiYgIXN1cHByZXNzRXZlbnRzIHx8IHRoaXMuX2luaXR0ZWQgJiYgTWF0aC5hYnModGhpcy5felRpbWUpID09PSBfdGlueU51bSB8fCAhdGhpcy5faW5pdHRlZCAmJiB0aGlzLl9kdXIgJiYgX3RvdGFsVGltZSB8fCAhX3RvdGFsVGltZSAmJiAhdGhpcy5faW5pdHRlZCAmJiAodGhpcy5hZGQgfHwgdGhpcy5fcHRMb29rdXApKSB7XG4gICAgICAvLyBjaGVjayBmb3IgX3B0TG9va3VwIG9uIGEgVHdlZW4gaW5zdGFuY2UgdG8gZW5zdXJlIGl0IGhhcyBhY3R1YWxseSBmaW5pc2hlZCBiZWluZyBpbnN0YW50aWF0ZWQsIG90aGVyd2lzZSBpZiB0aGlzLnJldmVyc2UoKSBnZXRzIGNhbGxlZCBpbiB0aGUgQW5pbWF0aW9uIGNvbnN0cnVjdG9yLCBpdCBjb3VsZCB0cmlnZ2VyIGEgcmVuZGVyKCkgaGVyZSBldmVuIHRob3VnaCB0aGUgX3RhcmdldHMgd2VyZW4ndCBwb3B1bGF0ZWQsIHRodXMgd2hlbiBfaW5pdCgpIGlzIGNhbGxlZCB0aGVyZSB3b24ndCBiZSBhbnkgUHJvcFR3ZWVucyAoaXQnbGwgYWN0IGxpa2UgdGhlIHR3ZWVuIGlzIG5vbi1mdW5jdGlvbmFsKVxuICAgICAgdGhpcy5fdHMgfHwgKHRoaXMuX3BUaW1lID0gX3RvdGFsVGltZSk7IC8vIG90aGVyd2lzZSwgaWYgYW4gYW5pbWF0aW9uIGlzIHBhdXNlZCwgdGhlbiB0aGUgcGxheWhlYWQgaXMgbW92ZWQgYmFjayB0byB6ZXJvLCB0aGVuIHJlc3VtZWQsIGl0J2QgcmV2ZXJ0IGJhY2sgdG8gdGhlIG9yaWdpbmFsIHRpbWUgYXQgdGhlIHBhdXNlXG4gICAgICAvL2lmICghdGhpcy5fbG9jaykgeyAvLyBhdm9pZCBlbmRsZXNzIHJlY3Vyc2lvbiAobm90IHN1cmUgd2UgbmVlZCB0aGlzIHlldCBvciBpZiBpdCdzIHdvcnRoIHRoZSBwZXJmb3JtYW5jZSBoaXQpXG4gICAgICAvLyAgIHRoaXMuX2xvY2sgPSAxO1xuXG4gICAgICBfbGF6eVNhZmVSZW5kZXIodGhpcywgX3RvdGFsVGltZSwgc3VwcHJlc3NFdmVudHMpOyAvLyAgIHRoaXMuX2xvY2sgPSAwO1xuICAgICAgLy99XG5cbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBfcHJvdG8udGltZSA9IGZ1bmN0aW9uIHRpbWUodmFsdWUsIHN1cHByZXNzRXZlbnRzKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyB0aGlzLnRvdGFsVGltZShNYXRoLm1pbih0aGlzLnRvdGFsRHVyYXRpb24oKSwgdmFsdWUgKyBfZWxhcHNlZEN5Y2xlRHVyYXRpb24odGhpcykpICUgKHRoaXMuX2R1ciArIHRoaXMuX3JEZWxheSkgfHwgKHZhbHVlID8gdGhpcy5fZHVyIDogMCksIHN1cHByZXNzRXZlbnRzKSA6IHRoaXMuX3RpbWU7IC8vIG5vdGU6IGlmIHRoZSBtb2R1bHVzIHJlc3VsdHMgaW4gMCwgdGhlIHBsYXloZWFkIGNvdWxkIGJlIGV4YWN0bHkgYXQgdGhlIGVuZCBvciB0aGUgYmVnaW5uaW5nLCBhbmQgd2UgYWx3YXlzIGRlZmVyIHRvIHRoZSBFTkQgd2l0aCBhIG5vbi16ZXJvIHZhbHVlLCBvdGhlcndpc2UgaWYgeW91IHNldCB0aGUgdGltZSgpIHRvIHRoZSB2ZXJ5IGVuZCAoZHVyYXRpb24oKSksIGl0IHdvdWxkIHJlbmRlciBhdCB0aGUgU1RBUlQhXG4gIH07XG5cbiAgX3Byb3RvLnRvdGFsUHJvZ3Jlc3MgPSBmdW5jdGlvbiB0b3RhbFByb2dyZXNzKHZhbHVlLCBzdXBwcmVzc0V2ZW50cykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gdGhpcy50b3RhbFRpbWUodGhpcy50b3RhbER1cmF0aW9uKCkgKiB2YWx1ZSwgc3VwcHJlc3NFdmVudHMpIDogdGhpcy50b3RhbER1cmF0aW9uKCkgPyBNYXRoLm1pbigxLCB0aGlzLl90VGltZSAvIHRoaXMuX3REdXIpIDogdGhpcy5yYXdUaW1lKCkgPj0gMCAmJiB0aGlzLl9pbml0dGVkID8gMSA6IDA7XG4gIH07XG5cbiAgX3Byb3RvLnByb2dyZXNzID0gZnVuY3Rpb24gcHJvZ3Jlc3ModmFsdWUsIHN1cHByZXNzRXZlbnRzKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyB0aGlzLnRvdGFsVGltZSh0aGlzLmR1cmF0aW9uKCkgKiAodGhpcy5feW95byAmJiAhKHRoaXMuaXRlcmF0aW9uKCkgJiAxKSA/IDEgLSB2YWx1ZSA6IHZhbHVlKSArIF9lbGFwc2VkQ3ljbGVEdXJhdGlvbih0aGlzKSwgc3VwcHJlc3NFdmVudHMpIDogdGhpcy5kdXJhdGlvbigpID8gTWF0aC5taW4oMSwgdGhpcy5fdGltZSAvIHRoaXMuX2R1cikgOiB0aGlzLnJhd1RpbWUoKSA+IDAgPyAxIDogMDtcbiAgfTtcblxuICBfcHJvdG8uaXRlcmF0aW9uID0gZnVuY3Rpb24gaXRlcmF0aW9uKHZhbHVlLCBzdXBwcmVzc0V2ZW50cykge1xuICAgIHZhciBjeWNsZUR1cmF0aW9uID0gdGhpcy5kdXJhdGlvbigpICsgdGhpcy5fckRlbGF5O1xuXG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyB0aGlzLnRvdGFsVGltZSh0aGlzLl90aW1lICsgKHZhbHVlIC0gMSkgKiBjeWNsZUR1cmF0aW9uLCBzdXBwcmVzc0V2ZW50cykgOiB0aGlzLl9yZXBlYXQgPyBfYW5pbWF0aW9uQ3ljbGUodGhpcy5fdFRpbWUsIGN5Y2xlRHVyYXRpb24pICsgMSA6IDE7XG4gIH0gLy8gcG90ZW50aWFsIGZ1dHVyZSBhZGRpdGlvbjpcbiAgLy8gaXNQbGF5aW5nQmFja3dhcmRzKCkge1xuICAvLyBcdGxldCBhbmltYXRpb24gPSB0aGlzLFxuICAvLyBcdFx0b3JpZW50YXRpb24gPSAxOyAvLyAxID0gZm9yd2FyZCwgLTEgPSBiYWNrd2FyZFxuICAvLyBcdHdoaWxlIChhbmltYXRpb24pIHtcbiAgLy8gXHRcdG9yaWVudGF0aW9uICo9IGFuaW1hdGlvbi5yZXZlcnNlZCgpIHx8IChhbmltYXRpb24ucmVwZWF0KCkgJiYgIShhbmltYXRpb24uaXRlcmF0aW9uKCkgJiAxKSkgPyAtMSA6IDE7XG4gIC8vIFx0XHRhbmltYXRpb24gPSBhbmltYXRpb24ucGFyZW50O1xuICAvLyBcdH1cbiAgLy8gXHRyZXR1cm4gb3JpZW50YXRpb24gPCAwO1xuICAvLyB9XG4gIDtcblxuICBfcHJvdG8udGltZVNjYWxlID0gZnVuY3Rpb24gdGltZVNjYWxlKHZhbHVlLCBzdXBwcmVzc0V2ZW50cykge1xuICAgIGlmICghYXJndW1lbnRzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIHRoaXMuX3J0cyA9PT0gLV90aW55TnVtID8gMCA6IHRoaXMuX3J0czsgLy8gcmVjb3JkZWQgdGltZVNjYWxlLiBTcGVjaWFsIGNhc2U6IGlmIHNvbWVvbmUgY2FsbHMgcmV2ZXJzZSgpIG9uIGFuIGFuaW1hdGlvbiB3aXRoIHRpbWVTY2FsZSBvZiAwLCB3ZSBhc3NpZ24gaXQgLV90aW55TnVtIHRvIHJlbWVtYmVyIGl0J3MgcmV2ZXJzZWQuXG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX3J0cyA9PT0gdmFsdWUpIHtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHZhciB0VGltZSA9IHRoaXMucGFyZW50ICYmIHRoaXMuX3RzID8gX3BhcmVudFRvQ2hpbGRUb3RhbFRpbWUodGhpcy5wYXJlbnQuX3RpbWUsIHRoaXMpIDogdGhpcy5fdFRpbWU7IC8vIG1ha2Ugc3VyZSB0byBkbyB0aGUgcGFyZW50VG9DaGlsZFRvdGFsVGltZSgpIEJFRk9SRSBzZXR0aW5nIHRoZSBuZXcgX3RzIGJlY2F1c2UgdGhlIG9sZCBvbmUgbXVzdCBiZSB1c2VkIGluIHRoYXQgY2FsY3VsYXRpb24uXG4gICAgLy8gZnV0dXJlIGFkZGl0aW9uPyBVcCBzaWRlOiBmYXN0IGFuZCBtaW5pbWFsIGZpbGUgc2l6ZS4gRG93biBzaWRlOiBvbmx5IHdvcmtzIG9uIHRoaXMgYW5pbWF0aW9uOyBpZiBhIHRpbWVsaW5lIGlzIHJldmVyc2VkLCBmb3IgZXhhbXBsZSwgaXRzIGNoaWxkcmVucycgb25SZXZlcnNlIHdvdWxkbid0IGdldCBjYWxsZWQuXG4gICAgLy8oK3ZhbHVlIDwgMCAmJiB0aGlzLl9ydHMgPj0gMCkgJiYgX2NhbGxiYWNrKHRoaXMsIFwib25SZXZlcnNlXCIsIHRydWUpO1xuICAgIC8vIHByaW9yaXRpemUgcmVuZGVyaW5nIHdoZXJlIHRoZSBwYXJlbnQncyBwbGF5aGVhZCBsaW5lcyB1cCBpbnN0ZWFkIG9mIHRoaXMuX3RUaW1lIGJlY2F1c2UgdGhlcmUgY291bGQgYmUgYSB0d2VlbiB0aGF0J3MgYW5pbWF0aW5nIGFub3RoZXIgdHdlZW4ncyB0aW1lU2NhbGUgaW4gdGhlIHNhbWUgcmVuZGVyaW5nIGxvb3AgKHNhbWUgcGFyZW50KSwgdGh1cyBpZiB0aGUgdGltZVNjYWxlIHR3ZWVuIHJlbmRlcnMgZmlyc3QsIGl0IHdvdWxkIGFsdGVyIF9zdGFydCBCRUZPUkUgX3RUaW1lIHdhcyBzZXQgb24gdGhhdCB0aWNrIChpbiB0aGUgcmVuZGVyaW5nIGxvb3ApLCBlZmZlY3RpdmVseSBmcmVlemluZyBpdCB1bnRpbCB0aGUgdGltZVNjYWxlIHR3ZWVuIGZpbmlzaGVzLlxuXG4gICAgdGhpcy5fcnRzID0gK3ZhbHVlIHx8IDA7XG4gICAgdGhpcy5fdHMgPSB0aGlzLl9wcyB8fCB2YWx1ZSA9PT0gLV90aW55TnVtID8gMCA6IHRoaXMuX3J0czsgLy8gX3RzIGlzIHRoZSBmdW5jdGlvbmFsIHRpbWVTY2FsZSB3aGljaCB3b3VsZCBiZSAwIGlmIHRoZSBhbmltYXRpb24gaXMgcGF1c2VkLlxuXG4gICAgdGhpcy50b3RhbFRpbWUoX2NsYW1wKC1NYXRoLmFicyh0aGlzLl9kZWxheSksIHRoaXMudG90YWxEdXJhdGlvbigpLCB0VGltZSksIHN1cHByZXNzRXZlbnRzICE9PSBmYWxzZSk7XG5cbiAgICBfc2V0RW5kKHRoaXMpOyAvLyBpZiBwYXJlbnQuc21vb3RoQ2hpbGRUaW1pbmcgd2FzIGZhbHNlLCB0aGUgZW5kIHRpbWUgZGlkbid0IGdldCB1cGRhdGVkIGluIHRoZSBfYWxpZ25QbGF5aGVhZCgpIG1ldGhvZCwgc28gZG8gaXQgaGVyZS5cblxuXG4gICAgcmV0dXJuIF9yZWNhY2hlQW5jZXN0b3JzKHRoaXMpO1xuICB9O1xuXG4gIF9wcm90by5wYXVzZWQgPSBmdW5jdGlvbiBwYXVzZWQodmFsdWUpIHtcbiAgICBpZiAoIWFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICAgIHJldHVybiB0aGlzLl9wcztcbiAgICB9IC8vIHBvc3NpYmxlIGZ1dHVyZSBhZGRpdGlvbiAtIGlmIGFuIGFuaW1hdGlvbiBpcyByZW1vdmVkIGZyb20gaXRzIHBhcmVudCBhbmQgdGhlbiAucmVzdGFydCgpIG9yIC5wbGF5KCkgb3IgLnJlc3VtZSgpIGlzIGNhbGxlZCwgcGVyaGFwcyB3ZSBzaG91bGQgZm9yY2UgaXQgYmFjayBpbnRvIHRoZSBnbG9iYWxUaW1lbGluZSBidXQgYmUgY2FyZWZ1bCBiZWNhdXNlIHdoYXQgaWYgaXQncyBhbHJlYWR5IGF0IGl0cyBlbmQ/IFdlIGRvbid0IHdhbnQgaXQgdG8ganVzdCBwZXJzaXN0IGZvcmV2ZXIgYW5kIG5vdCBnZXQgcmVsZWFzZWQgZm9yIEdDLlxuICAgIC8vICF0aGlzLnBhcmVudCAmJiAhdmFsdWUgJiYgdGhpcy5fdFRpbWUgPCB0aGlzLl90RHVyICYmIHRoaXMgIT09IF9nbG9iYWxUaW1lbGluZSAmJiBfZ2xvYmFsVGltZWxpbmUuYWRkKHRoaXMpO1xuXG5cbiAgICBpZiAodGhpcy5fcHMgIT09IHZhbHVlKSB7XG4gICAgICB0aGlzLl9wcyA9IHZhbHVlO1xuXG4gICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgdGhpcy5fcFRpbWUgPSB0aGlzLl90VGltZSB8fCBNYXRoLm1heCgtdGhpcy5fZGVsYXksIHRoaXMucmF3VGltZSgpKTsgLy8gaWYgdGhlIHBhdXNlIG9jY3VycyBkdXJpbmcgdGhlIGRlbGF5IHBoYXNlLCBtYWtlIHN1cmUgdGhhdCdzIGZhY3RvcmVkIGluIHdoZW4gcmVzdW1pbmcuXG5cbiAgICAgICAgdGhpcy5fdHMgPSB0aGlzLl9hY3QgPSAwOyAvLyBfdHMgaXMgdGhlIGZ1bmN0aW9uYWwgdGltZVNjYWxlLCBzbyBhIHBhdXNlZCB0d2VlbiB3b3VsZCBlZmZlY3RpdmVseSBoYXZlIGEgdGltZVNjYWxlIG9mIDAuIFdlIHJlY29yZCB0aGUgXCJyZWFsXCIgdGltZVNjYWxlIGFzIF9ydHMgKHJlY29yZGVkIHRpbWUgc2NhbGUpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBfd2FrZSgpO1xuXG4gICAgICAgIHRoaXMuX3RzID0gdGhpcy5fcnRzOyAvL29ubHkgZGVmZXIgdG8gX3BUaW1lIChwYXVzZVRpbWUpIGlmIHRUaW1lIGlzIHplcm8uIFJlbWVtYmVyLCBzb21lb25lIGNvdWxkIHBhdXNlKCkgYW4gYW5pbWF0aW9uLCB0aGVuIHNjcnViIHRoZSBwbGF5aGVhZCBhbmQgcmVzdW1lKCkuIElmIHRoZSBwYXJlbnQgZG9lc24ndCBoYXZlIHNtb290aENoaWxkVGltaW5nLCB3ZSByZW5kZXIgYXQgdGhlIHJhd1RpbWUoKSBiZWNhdXNlIHRoZSBzdGFydFRpbWUgd29uJ3QgZ2V0IHVwZGF0ZWQuXG5cbiAgICAgICAgdGhpcy50b3RhbFRpbWUodGhpcy5wYXJlbnQgJiYgIXRoaXMucGFyZW50LnNtb290aENoaWxkVGltaW5nID8gdGhpcy5yYXdUaW1lKCkgOiB0aGlzLl90VGltZSB8fCB0aGlzLl9wVGltZSwgdGhpcy5wcm9ncmVzcygpID09PSAxICYmIE1hdGguYWJzKHRoaXMuX3pUaW1lKSAhPT0gX3RpbnlOdW0gJiYgKHRoaXMuX3RUaW1lIC09IF90aW55TnVtKSk7IC8vIGVkZ2UgY2FzZTogYW5pbWF0aW9uLnByb2dyZXNzKDEpLnBhdXNlKCkucGxheSgpIHdvdWxkbid0IHJlbmRlciBhZ2FpbiBiZWNhdXNlIHRoZSBwbGF5aGVhZCBpcyBhbHJlYWR5IGF0IHRoZSBlbmQsIGJ1dCB0aGUgY2FsbCB0byB0b3RhbFRpbWUoKSBiZWxvdyB3aWxsIGFkZCBpdCBiYWNrIHRvIGl0cyBwYXJlbnQuLi5hbmQgbm90IHJlbW92ZSBpdCBhZ2FpbiAoc2luY2UgcmVtb3Zpbmcgb25seSBoYXBwZW5zIHVwb24gcmVuZGVyaW5nIGF0IGEgbmV3IHRpbWUpLiBPZmZzZXR0aW5nIHRoZSBfdFRpbWUgc2xpZ2h0bHkgaXMgZG9uZSBzaW1wbHkgdG8gY2F1c2UgdGhlIGZpbmFsIHJlbmRlciBpbiB0b3RhbFRpbWUoKSB0aGF0J2xsIHBvcCBpdCBvZmYgaXRzIHRpbWVsaW5lIChpZiBhdXRvUmVtb3ZlQ2hpbGRyZW4gaXMgdHJ1ZSwgb2YgY291cnNlKS4gQ2hlY2sgdG8gbWFrZSBzdXJlIF96VGltZSBpc24ndCAtX3RpbnlOdW0gdG8gYXZvaWQgYW4gZWRnZSBjYXNlIHdoZXJlIHRoZSBwbGF5aGVhZCBpcyBwdXNoZWQgdG8gdGhlIGVuZCBidXQgSU5TSURFIGEgdHdlZW4vY2FsbGJhY2ssIHRoZSB0aW1lbGluZSBpdHNlbGYgaXMgcGF1c2VkIHRodXMgaGFsdGluZyByZW5kZXJpbmcgYW5kIGxlYXZpbmcgYSBmZXcgdW5yZW5kZXJlZC4gV2hlbiByZXN1bWluZywgaXQgd291bGRuJ3QgcmVuZGVyIHRob3NlIG90aGVyd2lzZS5cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBfcHJvdG8uc3RhcnRUaW1lID0gZnVuY3Rpb24gc3RhcnRUaW1lKHZhbHVlKSB7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICAgIHRoaXMuX3N0YXJ0ID0gX3JvdW5kUHJlY2lzZSh2YWx1ZSk7XG4gICAgICB2YXIgcGFyZW50ID0gdGhpcy5wYXJlbnQgfHwgdGhpcy5fZHA7XG4gICAgICBwYXJlbnQgJiYgKHBhcmVudC5fc29ydCB8fCAhdGhpcy5wYXJlbnQpICYmIF9hZGRUb1RpbWVsaW5lKHBhcmVudCwgdGhpcywgdGhpcy5fc3RhcnQgLSB0aGlzLl9kZWxheSk7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5fc3RhcnQ7XG4gIH07XG5cbiAgX3Byb3RvLmVuZFRpbWUgPSBmdW5jdGlvbiBlbmRUaW1lKGluY2x1ZGVSZXBlYXRzKSB7XG4gICAgcmV0dXJuIHRoaXMuX3N0YXJ0ICsgKF9pc05vdEZhbHNlKGluY2x1ZGVSZXBlYXRzKSA/IHRoaXMudG90YWxEdXJhdGlvbigpIDogdGhpcy5kdXJhdGlvbigpKSAvIE1hdGguYWJzKHRoaXMuX3RzIHx8IDEpO1xuICB9O1xuXG4gIF9wcm90by5yYXdUaW1lID0gZnVuY3Rpb24gcmF3VGltZSh3cmFwUmVwZWF0cykge1xuICAgIHZhciBwYXJlbnQgPSB0aGlzLnBhcmVudCB8fCB0aGlzLl9kcDsgLy8gX2RwID0gZGV0YWNoZWQgcGFyZW50XG5cbiAgICByZXR1cm4gIXBhcmVudCA/IHRoaXMuX3RUaW1lIDogd3JhcFJlcGVhdHMgJiYgKCF0aGlzLl90cyB8fCB0aGlzLl9yZXBlYXQgJiYgdGhpcy5fdGltZSAmJiB0aGlzLnRvdGFsUHJvZ3Jlc3MoKSA8IDEpID8gdGhpcy5fdFRpbWUgJSAodGhpcy5fZHVyICsgdGhpcy5fckRlbGF5KSA6ICF0aGlzLl90cyA/IHRoaXMuX3RUaW1lIDogX3BhcmVudFRvQ2hpbGRUb3RhbFRpbWUocGFyZW50LnJhd1RpbWUod3JhcFJlcGVhdHMpLCB0aGlzKTtcbiAgfTtcblxuICBfcHJvdG8ucmV2ZXJ0ID0gZnVuY3Rpb24gcmV2ZXJ0KGNvbmZpZykge1xuICAgIGlmIChjb25maWcgPT09IHZvaWQgMCkge1xuICAgICAgY29uZmlnID0gX3JldmVydENvbmZpZztcbiAgICB9XG5cbiAgICB2YXIgcHJldklzUmV2ZXJ0aW5nID0gX3JldmVydGluZztcbiAgICBfcmV2ZXJ0aW5nID0gY29uZmlnO1xuXG4gICAgaWYgKF9pc1JldmVydFdvcnRoeSh0aGlzKSkge1xuICAgICAgdGhpcy50aW1lbGluZSAmJiB0aGlzLnRpbWVsaW5lLnJldmVydChjb25maWcpO1xuICAgICAgdGhpcy50b3RhbFRpbWUoLTAuMDEsIGNvbmZpZy5zdXBwcmVzc0V2ZW50cyk7XG4gICAgfVxuXG4gICAgdGhpcy5kYXRhICE9PSBcIm5lc3RlZFwiICYmIGNvbmZpZy5raWxsICE9PSBmYWxzZSAmJiB0aGlzLmtpbGwoKTtcbiAgICBfcmV2ZXJ0aW5nID0gcHJldklzUmV2ZXJ0aW5nO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIF9wcm90by5nbG9iYWxUaW1lID0gZnVuY3Rpb24gZ2xvYmFsVGltZShyYXdUaW1lKSB7XG4gICAgdmFyIGFuaW1hdGlvbiA9IHRoaXMsXG4gICAgICAgIHRpbWUgPSBhcmd1bWVudHMubGVuZ3RoID8gcmF3VGltZSA6IGFuaW1hdGlvbi5yYXdUaW1lKCk7XG5cbiAgICB3aGlsZSAoYW5pbWF0aW9uKSB7XG4gICAgICB0aW1lID0gYW5pbWF0aW9uLl9zdGFydCArIHRpbWUgLyAoTWF0aC5hYnMoYW5pbWF0aW9uLl90cykgfHwgMSk7XG4gICAgICBhbmltYXRpb24gPSBhbmltYXRpb24uX2RwO1xuICAgIH1cblxuICAgIHJldHVybiAhdGhpcy5wYXJlbnQgJiYgdGhpcy5fc2F0ID8gdGhpcy5fc2F0Lmdsb2JhbFRpbWUocmF3VGltZSkgOiB0aW1lOyAvLyB0aGUgX3N0YXJ0QXQgdHdlZW5zIGZvciAuZnJvbVRvKCkgYW5kIC5mcm9tKCkgdGhhdCBoYXZlIGltbWVkaWF0ZVJlbmRlciBzaG91bGQgYWx3YXlzIGJlIEZJUlNUIGluIHRoZSB0aW1lbGluZSAoaW1wb3J0YW50IGZvciBjb250ZXh0LnJldmVydCgpKS4gXCJfc2F0XCIgc3RhbmRzIGZvciBfc3RhcnRBdFR3ZWVuLCByZWZlcnJpbmcgdG8gdGhlIHBhcmVudCB0d2VlbiB0aGF0IGNyZWF0ZWQgdGhlIF9zdGFydEF0LiBXZSBtdXN0IGRpc2Nlcm4gaWYgdGhhdCB0d2VlbiBoYWQgaW1tZWRpYXRlUmVuZGVyIHNvIHRoYXQgd2UgY2FuIGtub3cgd2hldGhlciBvciBub3QgdG8gcHJpb3JpdGl6ZSBpdCBpbiByZXZlcnQoKS5cbiAgfTtcblxuICBfcHJvdG8ucmVwZWF0ID0gZnVuY3Rpb24gcmVwZWF0KHZhbHVlKSB7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICAgIHRoaXMuX3JlcGVhdCA9IHZhbHVlID09PSBJbmZpbml0eSA/IC0yIDogdmFsdWU7XG4gICAgICByZXR1cm4gX29uVXBkYXRlVG90YWxEdXJhdGlvbih0aGlzKTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5fcmVwZWF0ID09PSAtMiA/IEluZmluaXR5IDogdGhpcy5fcmVwZWF0O1xuICB9O1xuXG4gIF9wcm90by5yZXBlYXREZWxheSA9IGZ1bmN0aW9uIHJlcGVhdERlbGF5KHZhbHVlKSB7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICAgIHZhciB0aW1lID0gdGhpcy5fdGltZTtcbiAgICAgIHRoaXMuX3JEZWxheSA9IHZhbHVlO1xuXG4gICAgICBfb25VcGRhdGVUb3RhbER1cmF0aW9uKHRoaXMpO1xuXG4gICAgICByZXR1cm4gdGltZSA/IHRoaXMudGltZSh0aW1lKSA6IHRoaXM7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX3JEZWxheTtcbiAgfTtcblxuICBfcHJvdG8ueW95byA9IGZ1bmN0aW9uIHlveW8odmFsdWUpIHtcbiAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCkge1xuICAgICAgdGhpcy5feW95byA9IHZhbHVlO1xuICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX3lveW87XG4gIH07XG5cbiAgX3Byb3RvLnNlZWsgPSBmdW5jdGlvbiBzZWVrKHBvc2l0aW9uLCBzdXBwcmVzc0V2ZW50cykge1xuICAgIHJldHVybiB0aGlzLnRvdGFsVGltZShfcGFyc2VQb3NpdGlvbih0aGlzLCBwb3NpdGlvbiksIF9pc05vdEZhbHNlKHN1cHByZXNzRXZlbnRzKSk7XG4gIH07XG5cbiAgX3Byb3RvLnJlc3RhcnQgPSBmdW5jdGlvbiByZXN0YXJ0KGluY2x1ZGVEZWxheSwgc3VwcHJlc3NFdmVudHMpIHtcbiAgICB0aGlzLnBsYXkoKS50b3RhbFRpbWUoaW5jbHVkZURlbGF5ID8gLXRoaXMuX2RlbGF5IDogMCwgX2lzTm90RmFsc2Uoc3VwcHJlc3NFdmVudHMpKTtcbiAgICB0aGlzLl9kdXIgfHwgKHRoaXMuX3pUaW1lID0gLV90aW55TnVtKTsgLy8gZW5zdXJlcyBvbkNvbXBsZXRlIGZpcmVzIG9uIGEgemVyby1kdXJhdGlvbiBhbmltYXRpb24gdGhhdCBnZXRzIHJlc3RhcnRlZC5cblxuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIF9wcm90by5wbGF5ID0gZnVuY3Rpb24gcGxheShmcm9tLCBzdXBwcmVzc0V2ZW50cykge1xuICAgIGZyb20gIT0gbnVsbCAmJiB0aGlzLnNlZWsoZnJvbSwgc3VwcHJlc3NFdmVudHMpO1xuICAgIHJldHVybiB0aGlzLnJldmVyc2VkKGZhbHNlKS5wYXVzZWQoZmFsc2UpO1xuICB9O1xuXG4gIF9wcm90by5yZXZlcnNlID0gZnVuY3Rpb24gcmV2ZXJzZShmcm9tLCBzdXBwcmVzc0V2ZW50cykge1xuICAgIGZyb20gIT0gbnVsbCAmJiB0aGlzLnNlZWsoZnJvbSB8fCB0aGlzLnRvdGFsRHVyYXRpb24oKSwgc3VwcHJlc3NFdmVudHMpO1xuICAgIHJldHVybiB0aGlzLnJldmVyc2VkKHRydWUpLnBhdXNlZChmYWxzZSk7XG4gIH07XG5cbiAgX3Byb3RvLnBhdXNlID0gZnVuY3Rpb24gcGF1c2UoYXRUaW1lLCBzdXBwcmVzc0V2ZW50cykge1xuICAgIGF0VGltZSAhPSBudWxsICYmIHRoaXMuc2VlayhhdFRpbWUsIHN1cHByZXNzRXZlbnRzKTtcbiAgICByZXR1cm4gdGhpcy5wYXVzZWQodHJ1ZSk7XG4gIH07XG5cbiAgX3Byb3RvLnJlc3VtZSA9IGZ1bmN0aW9uIHJlc3VtZSgpIHtcbiAgICByZXR1cm4gdGhpcy5wYXVzZWQoZmFsc2UpO1xuICB9O1xuXG4gIF9wcm90by5yZXZlcnNlZCA9IGZ1bmN0aW9uIHJldmVyc2VkKHZhbHVlKSB7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICAgICEhdmFsdWUgIT09IHRoaXMucmV2ZXJzZWQoKSAmJiB0aGlzLnRpbWVTY2FsZSgtdGhpcy5fcnRzIHx8ICh2YWx1ZSA/IC1fdGlueU51bSA6IDApKTsgLy8gaW4gY2FzZSB0aW1lU2NhbGUgaXMgemVybywgcmV2ZXJzaW5nIHdvdWxkIGhhdmUgbm8gZWZmZWN0IHNvIHdlIHVzZSBfdGlueU51bS5cblxuICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX3J0cyA8IDA7XG4gIH07XG5cbiAgX3Byb3RvLmludmFsaWRhdGUgPSBmdW5jdGlvbiBpbnZhbGlkYXRlKCkge1xuICAgIHRoaXMuX2luaXR0ZWQgPSB0aGlzLl9hY3QgPSAwO1xuICAgIHRoaXMuX3pUaW1lID0gLV90aW55TnVtO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIF9wcm90by5pc0FjdGl2ZSA9IGZ1bmN0aW9uIGlzQWN0aXZlKCkge1xuICAgIHZhciBwYXJlbnQgPSB0aGlzLnBhcmVudCB8fCB0aGlzLl9kcCxcbiAgICAgICAgc3RhcnQgPSB0aGlzLl9zdGFydCxcbiAgICAgICAgcmF3VGltZTtcbiAgICByZXR1cm4gISEoIXBhcmVudCB8fCB0aGlzLl90cyAmJiB0aGlzLl9pbml0dGVkICYmIHBhcmVudC5pc0FjdGl2ZSgpICYmIChyYXdUaW1lID0gcGFyZW50LnJhd1RpbWUodHJ1ZSkpID49IHN0YXJ0ICYmIHJhd1RpbWUgPCB0aGlzLmVuZFRpbWUodHJ1ZSkgLSBfdGlueU51bSk7XG4gIH07XG5cbiAgX3Byb3RvLmV2ZW50Q2FsbGJhY2sgPSBmdW5jdGlvbiBldmVudENhbGxiYWNrKHR5cGUsIGNhbGxiYWNrLCBwYXJhbXMpIHtcbiAgICB2YXIgdmFycyA9IHRoaXMudmFycztcblxuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID4gMSkge1xuICAgICAgaWYgKCFjYWxsYmFjaykge1xuICAgICAgICBkZWxldGUgdmFyc1t0eXBlXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhcnNbdHlwZV0gPSBjYWxsYmFjaztcbiAgICAgICAgcGFyYW1zICYmICh2YXJzW3R5cGUgKyBcIlBhcmFtc1wiXSA9IHBhcmFtcyk7XG4gICAgICAgIHR5cGUgPT09IFwib25VcGRhdGVcIiAmJiAodGhpcy5fb25VcGRhdGUgPSBjYWxsYmFjayk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHJldHVybiB2YXJzW3R5cGVdO1xuICB9O1xuXG4gIF9wcm90by50aGVuID0gZnVuY3Rpb24gdGhlbihvbkZ1bGZpbGxlZCkge1xuICAgIHZhciBzZWxmID0gdGhpcyxcbiAgICAgICAgcHJldlByb20gPSBzZWxmLl9wcm9tO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSkge1xuICAgICAgdmFyIGYgPSBfaXNGdW5jdGlvbihvbkZ1bGZpbGxlZCkgPyBvbkZ1bGZpbGxlZCA6IF9wYXNzVGhyb3VnaCxcbiAgICAgICAgICBfcmVzb2x2ZSA9IGZ1bmN0aW9uIF9yZXNvbHZlKCkge1xuICAgICAgICB2YXIgX3RoZW4gPSBzZWxmLnRoZW47XG4gICAgICAgIHNlbGYudGhlbiA9IG51bGw7IC8vIHRlbXBvcmFyaWx5IG51bGwgdGhlIHRoZW4oKSBtZXRob2QgdG8gYXZvaWQgYW4gaW5maW5pdGUgbG9vcCAoc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9ncmVlbnNvY2svR1NBUC9pc3N1ZXMvMzIyKVxuXG4gICAgICAgIHByZXZQcm9tICYmIHByZXZQcm9tKCk7XG4gICAgICAgIF9pc0Z1bmN0aW9uKGYpICYmIChmID0gZihzZWxmKSkgJiYgKGYudGhlbiB8fCBmID09PSBzZWxmKSAmJiAoc2VsZi50aGVuID0gX3RoZW4pO1xuICAgICAgICByZXNvbHZlKGYpO1xuICAgICAgICBzZWxmLnRoZW4gPSBfdGhlbjtcbiAgICAgIH07XG5cbiAgICAgIGlmIChzZWxmLl9pbml0dGVkICYmIHNlbGYudG90YWxQcm9ncmVzcygpID09PSAxICYmIHNlbGYuX3RzID49IDAgfHwgIXNlbGYuX3RUaW1lICYmIHNlbGYuX3RzIDwgMCkge1xuICAgICAgICBfcmVzb2x2ZSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2VsZi5fcHJvbSA9IF9yZXNvbHZlO1xuICAgICAgfVxuICAgIH0pO1xuICB9O1xuXG4gIF9wcm90by5raWxsID0gZnVuY3Rpb24ga2lsbCgpIHtcbiAgICBfaW50ZXJydXB0KHRoaXMpO1xuICB9O1xuXG4gIHJldHVybiBBbmltYXRpb247XG59KCk7XG5cbl9zZXREZWZhdWx0cyhBbmltYXRpb24ucHJvdG90eXBlLCB7XG4gIF90aW1lOiAwLFxuICBfc3RhcnQ6IDAsXG4gIF9lbmQ6IDAsXG4gIF90VGltZTogMCxcbiAgX3REdXI6IDAsXG4gIF9kaXJ0eTogMCxcbiAgX3JlcGVhdDogMCxcbiAgX3lveW86IGZhbHNlLFxuICBwYXJlbnQ6IG51bGwsXG4gIF9pbml0dGVkOiBmYWxzZSxcbiAgX3JEZWxheTogMCxcbiAgX3RzOiAxLFxuICBfZHA6IDAsXG4gIHJhdGlvOiAwLFxuICBfelRpbWU6IC1fdGlueU51bSxcbiAgX3Byb206IDAsXG4gIF9wczogZmFsc2UsXG4gIF9ydHM6IDFcbn0pO1xuLypcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqIFRJTUVMSU5FXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKi9cblxuXG5leHBvcnQgdmFyIFRpbWVsaW5lID0gLyojX19QVVJFX18qL2Z1bmN0aW9uIChfQW5pbWF0aW9uKSB7XG4gIF9pbmhlcml0c0xvb3NlKFRpbWVsaW5lLCBfQW5pbWF0aW9uKTtcblxuICBmdW5jdGlvbiBUaW1lbGluZSh2YXJzLCBwb3NpdGlvbikge1xuICAgIHZhciBfdGhpcztcblxuICAgIGlmICh2YXJzID09PSB2b2lkIDApIHtcbiAgICAgIHZhcnMgPSB7fTtcbiAgICB9XG5cbiAgICBfdGhpcyA9IF9BbmltYXRpb24uY2FsbCh0aGlzLCB2YXJzKSB8fCB0aGlzO1xuICAgIF90aGlzLmxhYmVscyA9IHt9O1xuICAgIF90aGlzLnNtb290aENoaWxkVGltaW5nID0gISF2YXJzLnNtb290aENoaWxkVGltaW5nO1xuICAgIF90aGlzLmF1dG9SZW1vdmVDaGlsZHJlbiA9ICEhdmFycy5hdXRvUmVtb3ZlQ2hpbGRyZW47XG4gICAgX3RoaXMuX3NvcnQgPSBfaXNOb3RGYWxzZSh2YXJzLnNvcnRDaGlsZHJlbik7XG4gICAgX2dsb2JhbFRpbWVsaW5lICYmIF9hZGRUb1RpbWVsaW5lKHZhcnMucGFyZW50IHx8IF9nbG9iYWxUaW1lbGluZSwgX2Fzc2VydFRoaXNJbml0aWFsaXplZChfdGhpcyksIHBvc2l0aW9uKTtcbiAgICB2YXJzLnJldmVyc2VkICYmIF90aGlzLnJldmVyc2UoKTtcbiAgICB2YXJzLnBhdXNlZCAmJiBfdGhpcy5wYXVzZWQodHJ1ZSk7XG4gICAgdmFycy5zY3JvbGxUcmlnZ2VyICYmIF9zY3JvbGxUcmlnZ2VyKF9hc3NlcnRUaGlzSW5pdGlhbGl6ZWQoX3RoaXMpLCB2YXJzLnNjcm9sbFRyaWdnZXIpO1xuICAgIHJldHVybiBfdGhpcztcbiAgfVxuXG4gIHZhciBfcHJvdG8yID0gVGltZWxpbmUucHJvdG90eXBlO1xuXG4gIF9wcm90bzIudG8gPSBmdW5jdGlvbiB0byh0YXJnZXRzLCB2YXJzLCBwb3NpdGlvbikge1xuICAgIF9jcmVhdGVUd2VlblR5cGUoMCwgYXJndW1lbnRzLCB0aGlzKTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIF9wcm90bzIuZnJvbSA9IGZ1bmN0aW9uIGZyb20odGFyZ2V0cywgdmFycywgcG9zaXRpb24pIHtcbiAgICBfY3JlYXRlVHdlZW5UeXBlKDEsIGFyZ3VtZW50cywgdGhpcyk7XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBfcHJvdG8yLmZyb21UbyA9IGZ1bmN0aW9uIGZyb21Ubyh0YXJnZXRzLCBmcm9tVmFycywgdG9WYXJzLCBwb3NpdGlvbikge1xuICAgIF9jcmVhdGVUd2VlblR5cGUoMiwgYXJndW1lbnRzLCB0aGlzKTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIF9wcm90bzIuc2V0ID0gZnVuY3Rpb24gc2V0KHRhcmdldHMsIHZhcnMsIHBvc2l0aW9uKSB7XG4gICAgdmFycy5kdXJhdGlvbiA9IDA7XG4gICAgdmFycy5wYXJlbnQgPSB0aGlzO1xuICAgIF9pbmhlcml0RGVmYXVsdHModmFycykucmVwZWF0RGVsYXkgfHwgKHZhcnMucmVwZWF0ID0gMCk7XG4gICAgdmFycy5pbW1lZGlhdGVSZW5kZXIgPSAhIXZhcnMuaW1tZWRpYXRlUmVuZGVyO1xuICAgIG5ldyBUd2Vlbih0YXJnZXRzLCB2YXJzLCBfcGFyc2VQb3NpdGlvbih0aGlzLCBwb3NpdGlvbiksIDEpO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIF9wcm90bzIuY2FsbCA9IGZ1bmN0aW9uIGNhbGwoY2FsbGJhY2ssIHBhcmFtcywgcG9zaXRpb24pIHtcbiAgICByZXR1cm4gX2FkZFRvVGltZWxpbmUodGhpcywgVHdlZW4uZGVsYXllZENhbGwoMCwgY2FsbGJhY2ssIHBhcmFtcyksIHBvc2l0aW9uKTtcbiAgfSAvL09OTFkgZm9yIGJhY2t3YXJkIGNvbXBhdGliaWxpdHkhIE1heWJlIGRlbGV0ZT9cbiAgO1xuXG4gIF9wcm90bzIuc3RhZ2dlclRvID0gZnVuY3Rpb24gc3RhZ2dlclRvKHRhcmdldHMsIGR1cmF0aW9uLCB2YXJzLCBzdGFnZ2VyLCBwb3NpdGlvbiwgb25Db21wbGV0ZUFsbCwgb25Db21wbGV0ZUFsbFBhcmFtcykge1xuICAgIHZhcnMuZHVyYXRpb24gPSBkdXJhdGlvbjtcbiAgICB2YXJzLnN0YWdnZXIgPSB2YXJzLnN0YWdnZXIgfHwgc3RhZ2dlcjtcbiAgICB2YXJzLm9uQ29tcGxldGUgPSBvbkNvbXBsZXRlQWxsO1xuICAgIHZhcnMub25Db21wbGV0ZVBhcmFtcyA9IG9uQ29tcGxldGVBbGxQYXJhbXM7XG4gICAgdmFycy5wYXJlbnQgPSB0aGlzO1xuICAgIG5ldyBUd2Vlbih0YXJnZXRzLCB2YXJzLCBfcGFyc2VQb3NpdGlvbih0aGlzLCBwb3NpdGlvbikpO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIF9wcm90bzIuc3RhZ2dlckZyb20gPSBmdW5jdGlvbiBzdGFnZ2VyRnJvbSh0YXJnZXRzLCBkdXJhdGlvbiwgdmFycywgc3RhZ2dlciwgcG9zaXRpb24sIG9uQ29tcGxldGVBbGwsIG9uQ29tcGxldGVBbGxQYXJhbXMpIHtcbiAgICB2YXJzLnJ1bkJhY2t3YXJkcyA9IDE7XG4gICAgX2luaGVyaXREZWZhdWx0cyh2YXJzKS5pbW1lZGlhdGVSZW5kZXIgPSBfaXNOb3RGYWxzZSh2YXJzLmltbWVkaWF0ZVJlbmRlcik7XG4gICAgcmV0dXJuIHRoaXMuc3RhZ2dlclRvKHRhcmdldHMsIGR1cmF0aW9uLCB2YXJzLCBzdGFnZ2VyLCBwb3NpdGlvbiwgb25Db21wbGV0ZUFsbCwgb25Db21wbGV0ZUFsbFBhcmFtcyk7XG4gIH07XG5cbiAgX3Byb3RvMi5zdGFnZ2VyRnJvbVRvID0gZnVuY3Rpb24gc3RhZ2dlckZyb21Ubyh0YXJnZXRzLCBkdXJhdGlvbiwgZnJvbVZhcnMsIHRvVmFycywgc3RhZ2dlciwgcG9zaXRpb24sIG9uQ29tcGxldGVBbGwsIG9uQ29tcGxldGVBbGxQYXJhbXMpIHtcbiAgICB0b1ZhcnMuc3RhcnRBdCA9IGZyb21WYXJzO1xuICAgIF9pbmhlcml0RGVmYXVsdHModG9WYXJzKS5pbW1lZGlhdGVSZW5kZXIgPSBfaXNOb3RGYWxzZSh0b1ZhcnMuaW1tZWRpYXRlUmVuZGVyKTtcbiAgICByZXR1cm4gdGhpcy5zdGFnZ2VyVG8odGFyZ2V0cywgZHVyYXRpb24sIHRvVmFycywgc3RhZ2dlciwgcG9zaXRpb24sIG9uQ29tcGxldGVBbGwsIG9uQ29tcGxldGVBbGxQYXJhbXMpO1xuICB9O1xuXG4gIF9wcm90bzIucmVuZGVyID0gZnVuY3Rpb24gcmVuZGVyKHRvdGFsVGltZSwgc3VwcHJlc3NFdmVudHMsIGZvcmNlKSB7XG4gICAgdmFyIHByZXZUaW1lID0gdGhpcy5fdGltZSxcbiAgICAgICAgdER1ciA9IHRoaXMuX2RpcnR5ID8gdGhpcy50b3RhbER1cmF0aW9uKCkgOiB0aGlzLl90RHVyLFxuICAgICAgICBkdXIgPSB0aGlzLl9kdXIsXG4gICAgICAgIHRUaW1lID0gdG90YWxUaW1lIDw9IDAgPyAwIDogX3JvdW5kUHJlY2lzZSh0b3RhbFRpbWUpLFxuICAgICAgICAvLyBpZiBhIHBhdXNlZCB0aW1lbGluZSBpcyByZXN1bWVkIChvciBpdHMgX3N0YXJ0IGlzIHVwZGF0ZWQgZm9yIGFub3RoZXIgcmVhc29uLi4ud2hpY2ggcm91bmRzIGl0KSwgdGhhdCBjb3VsZCByZXN1bHQgaW4gdGhlIHBsYXloZWFkIHNoaWZ0aW5nIGEgKip0aW55KiogYW1vdW50IGFuZCBhIHplcm8tZHVyYXRpb24gY2hpbGQgYXQgdGhhdCBzcG90IG1heSBnZXQgcmVuZGVyZWQgYXQgYSBkaWZmZXJlbnQgcmF0aW8sIGxpa2UgaXRzIHRvdGFsVGltZSBpbiByZW5kZXIoKSBtYXkgYmUgMWUtMTcgaW5zdGVhZCBvZiAwLCBmb3IgZXhhbXBsZS5cbiAgICBjcm9zc2luZ1N0YXJ0ID0gdGhpcy5felRpbWUgPCAwICE9PSB0b3RhbFRpbWUgPCAwICYmICh0aGlzLl9pbml0dGVkIHx8ICFkdXIpLFxuICAgICAgICB0aW1lLFxuICAgICAgICBjaGlsZCxcbiAgICAgICAgbmV4dCxcbiAgICAgICAgaXRlcmF0aW9uLFxuICAgICAgICBjeWNsZUR1cmF0aW9uLFxuICAgICAgICBwcmV2UGF1c2VkLFxuICAgICAgICBwYXVzZVR3ZWVuLFxuICAgICAgICB0aW1lU2NhbGUsXG4gICAgICAgIHByZXZTdGFydCxcbiAgICAgICAgcHJldkl0ZXJhdGlvbixcbiAgICAgICAgeW95byxcbiAgICAgICAgaXNZb3lvO1xuICAgIHRoaXMgIT09IF9nbG9iYWxUaW1lbGluZSAmJiB0VGltZSA+IHREdXIgJiYgdG90YWxUaW1lID49IDAgJiYgKHRUaW1lID0gdER1cik7XG5cbiAgICBpZiAodFRpbWUgIT09IHRoaXMuX3RUaW1lIHx8IGZvcmNlIHx8IGNyb3NzaW5nU3RhcnQpIHtcbiAgICAgIGlmIChwcmV2VGltZSAhPT0gdGhpcy5fdGltZSAmJiBkdXIpIHtcbiAgICAgICAgLy9pZiB0b3RhbER1cmF0aW9uKCkgZmluZHMgYSBjaGlsZCB3aXRoIGEgbmVnYXRpdmUgc3RhcnRUaW1lIGFuZCBzbW9vdGhDaGlsZFRpbWluZyBpcyB0cnVlLCB0aGluZ3MgZ2V0IHNoaWZ0ZWQgYXJvdW5kIGludGVybmFsbHkgc28gd2UgbmVlZCB0byBhZGp1c3QgdGhlIHRpbWUgYWNjb3JkaW5nbHkuIEZvciBleGFtcGxlLCBpZiBhIHR3ZWVuIHN0YXJ0cyBhdCAtMzAgd2UgbXVzdCBzaGlmdCBFVkVSWVRISU5HIGZvcndhcmQgMzAgc2Vjb25kcyBhbmQgbW92ZSB0aGlzIHRpbWVsaW5lJ3Mgc3RhcnRUaW1lIGJhY2t3YXJkIGJ5IDMwIHNlY29uZHMgc28gdGhhdCB0aGluZ3MgYWxpZ24gd2l0aCB0aGUgcGxheWhlYWQgKG5vIGp1bXApLlxuICAgICAgICB0VGltZSArPSB0aGlzLl90aW1lIC0gcHJldlRpbWU7XG4gICAgICAgIHRvdGFsVGltZSArPSB0aGlzLl90aW1lIC0gcHJldlRpbWU7XG4gICAgICB9XG5cbiAgICAgIHRpbWUgPSB0VGltZTtcbiAgICAgIHByZXZTdGFydCA9IHRoaXMuX3N0YXJ0O1xuICAgICAgdGltZVNjYWxlID0gdGhpcy5fdHM7XG4gICAgICBwcmV2UGF1c2VkID0gIXRpbWVTY2FsZTtcblxuICAgICAgaWYgKGNyb3NzaW5nU3RhcnQpIHtcbiAgICAgICAgZHVyIHx8IChwcmV2VGltZSA9IHRoaXMuX3pUaW1lKTsgLy93aGVuIHRoZSBwbGF5aGVhZCBhcnJpdmVzIGF0IEVYQUNUTFkgdGltZSAwIChyaWdodCBvbiB0b3ApIG9mIGEgemVyby1kdXJhdGlvbiB0aW1lbGluZSwgd2UgbmVlZCB0byBkaXNjZXJuIGlmIGV2ZW50cyBhcmUgc3VwcHJlc3NlZCBzbyB0aGF0IHdoZW4gdGhlIHBsYXloZWFkIG1vdmVzIGFnYWluIChuZXh0IHRpbWUpLCBpdCdsbCB0cmlnZ2VyIHRoZSBjYWxsYmFjay4gSWYgZXZlbnRzIGFyZSBOT1Qgc3VwcHJlc3NlZCwgb2J2aW91c2x5IHRoZSBjYWxsYmFjayB3b3VsZCBiZSB0cmlnZ2VyZWQgaW4gdGhpcyByZW5kZXIuIEJhc2ljYWxseSwgdGhlIGNhbGxiYWNrIHNob3VsZCBmaXJlIGVpdGhlciB3aGVuIHRoZSBwbGF5aGVhZCBBUlJJVkVTIG9yIExFQVZFUyB0aGlzIGV4YWN0IHNwb3QsIG5vdCBib3RoLiBJbWFnaW5lIGRvaW5nIGEgdGltZWxpbmUuc2VlaygwKSBhbmQgdGhlcmUncyBhIGNhbGxiYWNrIHRoYXQgc2l0cyBhdCAwLiBTaW5jZSBldmVudHMgYXJlIHN1cHByZXNzZWQgb24gdGhhdCBzZWVrKCkgYnkgZGVmYXVsdCwgbm90aGluZyB3aWxsIGZpcmUsIGJ1dCB3aGVuIHRoZSBwbGF5aGVhZCBtb3ZlcyBvZmYgb2YgdGhhdCBwb3NpdGlvbiwgdGhlIGNhbGxiYWNrIHNob3VsZCBmaXJlLiBUaGlzIGJlaGF2aW9yIGlzIHdoYXQgcGVvcGxlIGludHVpdGl2ZWx5IGV4cGVjdC5cblxuICAgICAgICAodG90YWxUaW1lIHx8ICFzdXBwcmVzc0V2ZW50cykgJiYgKHRoaXMuX3pUaW1lID0gdG90YWxUaW1lKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHRoaXMuX3JlcGVhdCkge1xuICAgICAgICAvL2FkanVzdCB0aGUgdGltZSBmb3IgcmVwZWF0cyBhbmQgeW95b3NcbiAgICAgICAgeW95byA9IHRoaXMuX3lveW87XG4gICAgICAgIGN5Y2xlRHVyYXRpb24gPSBkdXIgKyB0aGlzLl9yRGVsYXk7XG5cbiAgICAgICAgaWYgKHRoaXMuX3JlcGVhdCA8IC0xICYmIHRvdGFsVGltZSA8IDApIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy50b3RhbFRpbWUoY3ljbGVEdXJhdGlvbiAqIDEwMCArIHRvdGFsVGltZSwgc3VwcHJlc3NFdmVudHMsIGZvcmNlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRpbWUgPSBfcm91bmRQcmVjaXNlKHRUaW1lICUgY3ljbGVEdXJhdGlvbik7IC8vcm91bmQgdG8gYXZvaWQgZmxvYXRpbmcgcG9pbnQgZXJyb3JzLiAoNCAlIDAuOCBzaG91bGQgYmUgMCBidXQgc29tZSBicm93c2VycyByZXBvcnQgaXQgYXMgMC43OTk5OTk5OSEpXG5cbiAgICAgICAgaWYgKHRUaW1lID09PSB0RHVyKSB7XG4gICAgICAgICAgLy8gdGhlIHREdXIgPT09IHRUaW1lIGlzIGZvciBlZGdlIGNhc2VzIHdoZXJlIHRoZXJlJ3MgYSBsZW5ndGh5IGRlY2ltYWwgb24gdGhlIGR1cmF0aW9uIGFuZCBpdCBtYXkgcmVhY2ggdGhlIHZlcnkgZW5kIGJ1dCB0aGUgdGltZSBpcyByZW5kZXJlZCBhcyBub3QtcXVpdGUtdGhlcmUgKHJlbWVtYmVyLCB0RHVyIGlzIHJvdW5kZWQgdG8gNCBkZWNpbWFscyB3aGVyZWFzIGR1ciBpc24ndClcbiAgICAgICAgICBpdGVyYXRpb24gPSB0aGlzLl9yZXBlYXQ7XG4gICAgICAgICAgdGltZSA9IGR1cjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwcmV2SXRlcmF0aW9uID0gX3JvdW5kUHJlY2lzZSh0VGltZSAvIGN5Y2xlRHVyYXRpb24pOyAvLyBmdWxsIGRlY2ltYWwgdmVyc2lvbiBvZiBpdGVyYXRpb25zLCBub3QgdGhlIHByZXZpb3VzIGl0ZXJhdGlvbiAod2UncmUgcmV1c2luZyBwcmV2SXRlcmF0aW9uIHZhcmlhYmxlIGZvciBlZmZpY2llbmN5KVxuXG4gICAgICAgICAgaXRlcmF0aW9uID0gfn5wcmV2SXRlcmF0aW9uO1xuXG4gICAgICAgICAgaWYgKGl0ZXJhdGlvbiAmJiBpdGVyYXRpb24gPT09IHByZXZJdGVyYXRpb24pIHtcbiAgICAgICAgICAgIHRpbWUgPSBkdXI7XG4gICAgICAgICAgICBpdGVyYXRpb24tLTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICB0aW1lID4gZHVyICYmICh0aW1lID0gZHVyKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHByZXZJdGVyYXRpb24gPSBfYW5pbWF0aW9uQ3ljbGUodGhpcy5fdFRpbWUsIGN5Y2xlRHVyYXRpb24pO1xuICAgICAgICAhcHJldlRpbWUgJiYgdGhpcy5fdFRpbWUgJiYgcHJldkl0ZXJhdGlvbiAhPT0gaXRlcmF0aW9uICYmIHRoaXMuX3RUaW1lIC0gcHJldkl0ZXJhdGlvbiAqIGN5Y2xlRHVyYXRpb24gLSB0aGlzLl9kdXIgPD0gMCAmJiAocHJldkl0ZXJhdGlvbiA9IGl0ZXJhdGlvbik7IC8vIGVkZ2UgY2FzZSAtIGlmIHNvbWVvbmUgZG9lcyBhZGRQYXVzZSgpIGF0IHRoZSB2ZXJ5IGJlZ2lubmluZyBvZiBhIHJlcGVhdGluZyB0aW1lbGluZSwgdGhhdCBwYXVzZSBpcyB0ZWNobmljYWxseSBhdCB0aGUgc2FtZSBzcG90IGFzIHRoZSBlbmQgd2hpY2ggY2F1c2VzIHRoaXMuX3RpbWUgdG8gZ2V0IHNldCB0byAwIHdoZW4gdGhlIHRvdGFsVGltZSB3b3VsZCBub3JtYWxseSBwbGFjZSB0aGUgcGxheWhlYWQgYXQgdGhlIGVuZC4gU2VlIGh0dHBzOi8vZ3NhcC5jb20vZm9ydW1zL3RvcGljLzIzODIzLWNsb3NpbmctbmF2LWFuaW1hdGlvbi1ub3Qtd29ya2luZy1vbi1pZS1hbmQtaXBob25lLTYtbWF5YmUtb3RoZXItb2xkZXItYnJvd3Nlci8/dGFiPWNvbW1lbnRzI2NvbW1lbnQtMTEzMDA1IGFsc28sIHRoaXMuX3RUaW1lIC0gcHJldkl0ZXJhdGlvbiAqIGN5Y2xlRHVyYXRpb24gLSB0aGlzLl9kdXIgPD0gMCBqdXN0IGNoZWNrcyB0byBtYWtlIHN1cmUgaXQgd2Fzbid0IHByZXZpb3VzbHkgaW4gdGhlIFwicmVwZWF0RGVsYXlcIiBwb3J0aW9uXG5cbiAgICAgICAgaWYgKHlveW8gJiYgaXRlcmF0aW9uICYgMSkge1xuICAgICAgICAgIHRpbWUgPSBkdXIgLSB0aW1lO1xuICAgICAgICAgIGlzWW95byA9IDE7XG4gICAgICAgIH1cbiAgICAgICAgLypcbiAgICAgICAgbWFrZSBzdXJlIGNoaWxkcmVuIGF0IHRoZSBlbmQvYmVnaW5uaW5nIG9mIHRoZSB0aW1lbGluZSBhcmUgcmVuZGVyZWQgcHJvcGVybHkuIElmLCBmb3IgZXhhbXBsZSxcbiAgICAgICAgYSAzLXNlY29uZCBsb25nIHRpbWVsaW5lIHJlbmRlcmVkIGF0IDIuOSBzZWNvbmRzIHByZXZpb3VzbHksIGFuZCBub3cgcmVuZGVycyBhdCAzLjIgc2Vjb25kcyAod2hpY2hcbiAgICAgICAgd291bGQgZ2V0IHRyYW5zbGF0ZWQgdG8gMi44IHNlY29uZHMgaWYgdGhlIHRpbWVsaW5lIHlveW9zIG9yIDAuMiBzZWNvbmRzIGlmIGl0IGp1c3QgcmVwZWF0cyksIHRoZXJlXG4gICAgICAgIGNvdWxkIGJlIGEgY2FsbGJhY2sgb3IgYSBzaG9ydCB0d2VlbiB0aGF0J3MgYXQgMi45NSBvciAzIHNlY29uZHMgaW4gd2hpY2ggd291bGRuJ3QgcmVuZGVyLiBTb1xuICAgICAgICB3ZSBuZWVkIHRvIHB1c2ggdGhlIHRpbWVsaW5lIHRvIHRoZSBlbmQgKGFuZC9vciBiZWdpbm5pbmcgZGVwZW5kaW5nIG9uIGl0cyB5b3lvIHZhbHVlKS4gQWxzbyB3ZSBtdXN0XG4gICAgICAgIGVuc3VyZSB0aGF0IHplcm8tZHVyYXRpb24gdHdlZW5zIGF0IHRoZSB2ZXJ5IGJlZ2lubmluZyBvciBlbmQgb2YgdGhlIFRpbWVsaW5lIHdvcmsuXG4gICAgICAgICovXG5cblxuICAgICAgICBpZiAoaXRlcmF0aW9uICE9PSBwcmV2SXRlcmF0aW9uICYmICF0aGlzLl9sb2NrKSB7XG4gICAgICAgICAgdmFyIHJld2luZGluZyA9IHlveW8gJiYgcHJldkl0ZXJhdGlvbiAmIDEsXG4gICAgICAgICAgICAgIGRvZXNXcmFwID0gcmV3aW5kaW5nID09PSAoeW95byAmJiBpdGVyYXRpb24gJiAxKTtcbiAgICAgICAgICBpdGVyYXRpb24gPCBwcmV2SXRlcmF0aW9uICYmIChyZXdpbmRpbmcgPSAhcmV3aW5kaW5nKTtcbiAgICAgICAgICBwcmV2VGltZSA9IHJld2luZGluZyA/IDAgOiB0VGltZSAlIGR1ciA/IGR1ciA6IHRUaW1lOyAvLyBpZiB0aGUgcGxheWhlYWQgaXMgbGFuZGluZyBleGFjdGx5IGF0IHRoZSBlbmQgb2YgYW4gaXRlcmF0aW9uLCB1c2UgdGhhdCB0b3RhbFRpbWUgcmF0aGVyIHRoYW4gb25seSB0aGUgZHVyYXRpb24sIG90aGVyd2lzZSBpdCdsbCBza2lwIHRoZSAybmQgcmVuZGVyIHNpbmNlIGl0J3MgZWZmZWN0aXZlbHkgYXQgdGhlIHNhbWUgdGltZS5cblxuICAgICAgICAgIHRoaXMuX2xvY2sgPSAxO1xuICAgICAgICAgIHRoaXMucmVuZGVyKHByZXZUaW1lIHx8IChpc1lveW8gPyAwIDogX3JvdW5kUHJlY2lzZShpdGVyYXRpb24gKiBjeWNsZUR1cmF0aW9uKSksIHN1cHByZXNzRXZlbnRzLCAhZHVyKS5fbG9jayA9IDA7XG4gICAgICAgICAgdGhpcy5fdFRpbWUgPSB0VGltZTsgLy8gaWYgYSB1c2VyIGdldHMgdGhlIGl0ZXJhdGlvbigpIGluc2lkZSB0aGUgb25SZXBlYXQsIGZvciBleGFtcGxlLCBpdCBzaG91bGQgYmUgYWNjdXJhdGUuXG5cbiAgICAgICAgICAhc3VwcHJlc3NFdmVudHMgJiYgdGhpcy5wYXJlbnQgJiYgX2NhbGxiYWNrKHRoaXMsIFwib25SZXBlYXRcIik7XG5cbiAgICAgICAgICBpZiAodGhpcy52YXJzLnJlcGVhdFJlZnJlc2ggJiYgIWlzWW95bykge1xuICAgICAgICAgICAgdGhpcy5pbnZhbGlkYXRlKCkuX2xvY2sgPSAxO1xuICAgICAgICAgICAgcHJldkl0ZXJhdGlvbiA9IGl0ZXJhdGlvbjsgLy8gb3RoZXJ3aXNlLCB0aGUgb25TdGFydCgpIG1heSBmaXJlIG9uIHRoZSAybmQgaXRlcmF0aW9uLlxuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChwcmV2VGltZSAmJiBwcmV2VGltZSAhPT0gdGhpcy5fdGltZSB8fCBwcmV2UGF1c2VkICE9PSAhdGhpcy5fdHMgfHwgdGhpcy52YXJzLm9uUmVwZWF0ICYmICF0aGlzLnBhcmVudCAmJiAhdGhpcy5fYWN0KSB7XG4gICAgICAgICAgICAvLyBpZiBwcmV2VGltZSBpcyAwIGFuZCB3ZSByZW5kZXIgYXQgdGhlIHZlcnkgZW5kLCBfdGltZSB3aWxsIGJlIHRoZSBlbmQsIHRodXMgd29uJ3QgbWF0Y2guIFNvIGluIHRoaXMgZWRnZSBjYXNlLCBwcmV2VGltZSB3b24ndCBtYXRjaCBfdGltZSBidXQgdGhhdCdzIG9rYXkuIElmIGl0IGdldHMga2lsbGVkIGluIHRoZSBvblJlcGVhdCwgZWplY3QgYXMgd2VsbC5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGR1ciA9IHRoaXMuX2R1cjsgLy8gaW4gY2FzZSB0aGUgZHVyYXRpb24gY2hhbmdlZCBpbiB0aGUgb25SZXBlYXRcblxuICAgICAgICAgIHREdXIgPSB0aGlzLl90RHVyO1xuXG4gICAgICAgICAgaWYgKGRvZXNXcmFwKSB7XG4gICAgICAgICAgICB0aGlzLl9sb2NrID0gMjtcbiAgICAgICAgICAgIHByZXZUaW1lID0gcmV3aW5kaW5nID8gZHVyIDogLTAuMDAwMTtcbiAgICAgICAgICAgIHRoaXMucmVuZGVyKHByZXZUaW1lLCB0cnVlKTtcbiAgICAgICAgICAgIHRoaXMudmFycy5yZXBlYXRSZWZyZXNoICYmICFpc1lveW8gJiYgdGhpcy5pbnZhbGlkYXRlKCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdGhpcy5fbG9jayA9IDA7XG5cbiAgICAgICAgICBpZiAoIXRoaXMuX3RzICYmICFwcmV2UGF1c2VkKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHRoaXMuX2hhc1BhdXNlICYmICF0aGlzLl9mb3JjaW5nICYmIHRoaXMuX2xvY2sgPCAyKSB7XG4gICAgICAgIHBhdXNlVHdlZW4gPSBfZmluZE5leHRQYXVzZVR3ZWVuKHRoaXMsIF9yb3VuZFByZWNpc2UocHJldlRpbWUpLCBfcm91bmRQcmVjaXNlKHRpbWUpKTtcblxuICAgICAgICBpZiAocGF1c2VUd2Vlbikge1xuICAgICAgICAgIHRUaW1lIC09IHRpbWUgLSAodGltZSA9IHBhdXNlVHdlZW4uX3N0YXJ0KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB0aGlzLl90VGltZSA9IHRUaW1lO1xuICAgICAgdGhpcy5fdGltZSA9IHRpbWU7XG4gICAgICB0aGlzLl9hY3QgPSAhIXRpbWVTY2FsZTsgLy8gYXMgbG9uZyBhcyBpdCdzIG5vdCBwYXVzZWQsIGZvcmNlIGl0IHRvIGJlIGFjdGl2ZSBzbyB0aGF0IGlmIHRoZSB1c2VyIHJlbmRlcnMgaW5kZXBlbmRlbnQgb2YgdGhlIHBhcmVudCB0aW1lbGluZSwgaXQnbGwgYmUgZm9yY2VkIHRvIHJlLXJlbmRlciBvbiB0aGUgbmV4dCB0aWNrLlxuXG4gICAgICBpZiAoIXRoaXMuX2luaXR0ZWQpIHtcbiAgICAgICAgdGhpcy5fb25VcGRhdGUgPSB0aGlzLnZhcnMub25VcGRhdGU7XG4gICAgICAgIHRoaXMuX2luaXR0ZWQgPSAxO1xuICAgICAgICB0aGlzLl96VGltZSA9IHRvdGFsVGltZTtcbiAgICAgICAgcHJldlRpbWUgPSAwOyAvLyB1cG9uIGluaXQsIHRoZSBwbGF5aGVhZCBzaG91bGQgYWx3YXlzIGdvIGZvcndhcmQ7IHNvbWVvbmUgY291bGQgaW52YWxpZGF0ZSgpIGEgY29tcGxldGVkIHRpbWVsaW5lIGFuZCB0aGVuIGlmIHRoZXkgcmVzdGFydCgpLCB0aGF0IHdvdWxkIG1ha2UgY2hpbGQgdHdlZW5zIHJlbmRlciBpbiByZXZlcnNlIG9yZGVyIHdoaWNoIGNvdWxkIGxvY2sgaW4gdGhlIHdyb25nIHN0YXJ0aW5nIHZhbHVlcyBpZiB0aGV5IGJ1aWxkIG9uIGVhY2ggb3RoZXIsIGxpa2UgdGwudG8ob2JqLCB7eDogMTAwfSkudG8ob2JqLCB7eDogMH0pLlxuICAgICAgfVxuXG4gICAgICBpZiAoIXByZXZUaW1lICYmIHRUaW1lICYmIGR1ciAmJiAhc3VwcHJlc3NFdmVudHMgJiYgIXByZXZJdGVyYXRpb24pIHtcbiAgICAgICAgX2NhbGxiYWNrKHRoaXMsIFwib25TdGFydFwiKTtcblxuICAgICAgICBpZiAodGhpcy5fdFRpbWUgIT09IHRUaW1lKSB7XG4gICAgICAgICAgLy8gaW4gY2FzZSB0aGUgb25TdGFydCB0cmlnZ2VyZWQgYSByZW5kZXIgYXQgYSBkaWZmZXJlbnQgc3BvdCwgZWplY3QuIExpa2UgaWYgc29tZW9uZSBkaWQgYW5pbWF0aW9uLnBhdXNlKDAuNSkgb3Igc29tZXRoaW5nIGluc2lkZSB0aGUgb25TdGFydC5cbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAodGltZSA+PSBwcmV2VGltZSAmJiB0b3RhbFRpbWUgPj0gMCkge1xuICAgICAgICBjaGlsZCA9IHRoaXMuX2ZpcnN0O1xuXG4gICAgICAgIHdoaWxlIChjaGlsZCkge1xuICAgICAgICAgIG5leHQgPSBjaGlsZC5fbmV4dDtcblxuICAgICAgICAgIGlmICgoY2hpbGQuX2FjdCB8fCB0aW1lID49IGNoaWxkLl9zdGFydCkgJiYgY2hpbGQuX3RzICYmIHBhdXNlVHdlZW4gIT09IGNoaWxkKSB7XG4gICAgICAgICAgICBpZiAoY2hpbGQucGFyZW50ICE9PSB0aGlzKSB7XG4gICAgICAgICAgICAgIC8vIGFuIGV4dHJlbWUgZWRnZSBjYXNlIC0gdGhlIGNoaWxkJ3MgcmVuZGVyIGNvdWxkIGRvIHNvbWV0aGluZyBsaWtlIGtpbGwoKSB0aGUgXCJuZXh0XCIgb25lIGluIHRoZSBsaW5rZWQgbGlzdCwgb3IgcmVwYXJlbnQgaXQuIEluIHRoYXQgY2FzZSB3ZSBtdXN0IHJlLWluaXRpYXRlIHRoZSB3aG9sZSByZW5kZXIgdG8gYmUgc2FmZS5cbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucmVuZGVyKHRvdGFsVGltZSwgc3VwcHJlc3NFdmVudHMsIGZvcmNlKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY2hpbGQucmVuZGVyKGNoaWxkLl90cyA+IDAgPyAodGltZSAtIGNoaWxkLl9zdGFydCkgKiBjaGlsZC5fdHMgOiAoY2hpbGQuX2RpcnR5ID8gY2hpbGQudG90YWxEdXJhdGlvbigpIDogY2hpbGQuX3REdXIpICsgKHRpbWUgLSBjaGlsZC5fc3RhcnQpICogY2hpbGQuX3RzLCBzdXBwcmVzc0V2ZW50cywgZm9yY2UpO1xuXG4gICAgICAgICAgICBpZiAodGltZSAhPT0gdGhpcy5fdGltZSB8fCAhdGhpcy5fdHMgJiYgIXByZXZQYXVzZWQpIHtcbiAgICAgICAgICAgICAgLy9pbiBjYXNlIGEgdHdlZW4gcGF1c2VzIG9yIHNlZWtzIHRoZSB0aW1lbGluZSB3aGVuIHJlbmRlcmluZywgbGlrZSBpbnNpZGUgb2YgYW4gb25VcGRhdGUvb25Db21wbGV0ZVxuICAgICAgICAgICAgICBwYXVzZVR3ZWVuID0gMDtcbiAgICAgICAgICAgICAgbmV4dCAmJiAodFRpbWUgKz0gdGhpcy5felRpbWUgPSAtX3RpbnlOdW0pOyAvLyBpdCBkaWRuJ3QgZmluaXNoIHJlbmRlcmluZywgc28gZmxhZyB6VGltZSBhcyBuZWdhdGl2ZSBzbyB0aGF0IHRoZSBuZXh0IHRpbWUgcmVuZGVyKCkgaXMgY2FsbGVkIGl0J2xsIGJlIGZvcmNlZCAodG8gcmVuZGVyIGFueSByZW1haW5pbmcgY2hpbGRyZW4pXG5cbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgY2hpbGQgPSBuZXh0O1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjaGlsZCA9IHRoaXMuX2xhc3Q7XG4gICAgICAgIHZhciBhZGp1c3RlZFRpbWUgPSB0b3RhbFRpbWUgPCAwID8gdG90YWxUaW1lIDogdGltZTsgLy93aGVuIHRoZSBwbGF5aGVhZCBnb2VzIGJhY2t3YXJkIGJleW9uZCB0aGUgc3RhcnQgb2YgdGhpcyB0aW1lbGluZSwgd2UgbXVzdCBwYXNzIHRoYXQgaW5mb3JtYXRpb24gZG93biB0byB0aGUgY2hpbGQgYW5pbWF0aW9ucyBzbyB0aGF0IHplcm8tZHVyYXRpb24gdHdlZW5zIGtub3cgd2hldGhlciB0byByZW5kZXIgdGhlaXIgc3RhcnRpbmcgb3IgZW5kaW5nIHZhbHVlcy5cblxuICAgICAgICB3aGlsZSAoY2hpbGQpIHtcbiAgICAgICAgICBuZXh0ID0gY2hpbGQuX3ByZXY7XG5cbiAgICAgICAgICBpZiAoKGNoaWxkLl9hY3QgfHwgYWRqdXN0ZWRUaW1lIDw9IGNoaWxkLl9lbmQpICYmIGNoaWxkLl90cyAmJiBwYXVzZVR3ZWVuICE9PSBjaGlsZCkge1xuICAgICAgICAgICAgaWYgKGNoaWxkLnBhcmVudCAhPT0gdGhpcykge1xuICAgICAgICAgICAgICAvLyBhbiBleHRyZW1lIGVkZ2UgY2FzZSAtIHRoZSBjaGlsZCdzIHJlbmRlciBjb3VsZCBkbyBzb21ldGhpbmcgbGlrZSBraWxsKCkgdGhlIFwibmV4dFwiIG9uZSBpbiB0aGUgbGlua2VkIGxpc3QsIG9yIHJlcGFyZW50IGl0LiBJbiB0aGF0IGNhc2Ugd2UgbXVzdCByZS1pbml0aWF0ZSB0aGUgd2hvbGUgcmVuZGVyIHRvIGJlIHNhZmUuXG4gICAgICAgICAgICAgIHJldHVybiB0aGlzLnJlbmRlcih0b3RhbFRpbWUsIHN1cHByZXNzRXZlbnRzLCBmb3JjZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNoaWxkLnJlbmRlcihjaGlsZC5fdHMgPiAwID8gKGFkanVzdGVkVGltZSAtIGNoaWxkLl9zdGFydCkgKiBjaGlsZC5fdHMgOiAoY2hpbGQuX2RpcnR5ID8gY2hpbGQudG90YWxEdXJhdGlvbigpIDogY2hpbGQuX3REdXIpICsgKGFkanVzdGVkVGltZSAtIGNoaWxkLl9zdGFydCkgKiBjaGlsZC5fdHMsIHN1cHByZXNzRXZlbnRzLCBmb3JjZSB8fCBfcmV2ZXJ0aW5nICYmIF9pc1JldmVydFdvcnRoeShjaGlsZCkpOyAvLyBpZiByZXZlcnRpbmcsIHdlIHNob3VsZCBhbHdheXMgZm9yY2UgcmVuZGVycyBvZiBpbml0dGVkIHR3ZWVucyAoYnV0IHJlbWVtYmVyIHRoYXQgLmZyb21UbygpIG9yIC5mcm9tKCkgbWF5IGhhdmUgYSBfc3RhcnRBdCBidXQgbm90IF9pbml0dGVkIHlldCkuIElmLCBmb3IgZXhhbXBsZSwgYSAuZnJvbVRvKCkgdHdlZW4gd2l0aCBhIHN0YWdnZXIgKHdoaWNoIGNyZWF0ZXMgYW4gaW50ZXJuYWwgdGltZWxpbmUpIGdldHMgcmV2ZXJ0ZWQgQkVGT1JFIHNvbWUgb2YgaXRzIGNoaWxkIHR3ZWVucyByZW5kZXIgZm9yIHRoZSBmaXJzdCB0aW1lLCBpdCBtYXkgbm90IHByb3Blcmx5IHRyaWdnZXIgdGhlbSB0byByZXZlcnQuXG5cbiAgICAgICAgICAgIGlmICh0aW1lICE9PSB0aGlzLl90aW1lIHx8ICF0aGlzLl90cyAmJiAhcHJldlBhdXNlZCkge1xuICAgICAgICAgICAgICAvL2luIGNhc2UgYSB0d2VlbiBwYXVzZXMgb3Igc2Vla3MgdGhlIHRpbWVsaW5lIHdoZW4gcmVuZGVyaW5nLCBsaWtlIGluc2lkZSBvZiBhbiBvblVwZGF0ZS9vbkNvbXBsZXRlXG4gICAgICAgICAgICAgIHBhdXNlVHdlZW4gPSAwO1xuICAgICAgICAgICAgICBuZXh0ICYmICh0VGltZSArPSB0aGlzLl96VGltZSA9IGFkanVzdGVkVGltZSA/IC1fdGlueU51bSA6IF90aW55TnVtKTsgLy8gaXQgZGlkbid0IGZpbmlzaCByZW5kZXJpbmcsIHNvIGFkanVzdCB6VGltZSBzbyB0aGF0IHNvIHRoYXQgdGhlIG5leHQgdGltZSByZW5kZXIoKSBpcyBjYWxsZWQgaXQnbGwgYmUgZm9yY2VkICh0byByZW5kZXIgYW55IHJlbWFpbmluZyBjaGlsZHJlbilcblxuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjaGlsZCA9IG5leHQ7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHBhdXNlVHdlZW4gJiYgIXN1cHByZXNzRXZlbnRzKSB7XG4gICAgICAgIHRoaXMucGF1c2UoKTtcbiAgICAgICAgcGF1c2VUd2Vlbi5yZW5kZXIodGltZSA+PSBwcmV2VGltZSA/IDAgOiAtX3RpbnlOdW0pLl96VGltZSA9IHRpbWUgPj0gcHJldlRpbWUgPyAxIDogLTE7XG5cbiAgICAgICAgaWYgKHRoaXMuX3RzKSB7XG4gICAgICAgICAgLy90aGUgY2FsbGJhY2sgcmVzdW1lZCBwbGF5YmFjayEgU28gc2luY2Ugd2UgbWF5IGhhdmUgaGVsZCBiYWNrIHRoZSBwbGF5aGVhZCBkdWUgdG8gd2hlcmUgdGhlIHBhdXNlIGlzIHBvc2l0aW9uZWQsIGdvIGFoZWFkIGFuZCBqdW1wIHRvIHdoZXJlIGl0J3MgU1VQUE9TRUQgdG8gYmUgKGlmIG5vIHBhdXNlIGhhcHBlbmVkKS5cbiAgICAgICAgICB0aGlzLl9zdGFydCA9IHByZXZTdGFydDsgLy9pZiB0aGUgcGF1c2Ugd2FzIGF0IGFuIGVhcmxpZXIgdGltZSBhbmQgdGhlIHVzZXIgcmVzdW1lZCBpbiB0aGUgY2FsbGJhY2ssIGl0IGNvdWxkIHJlcG9zaXRpb24gdGhlIHRpbWVsaW5lIChjaGFuZ2luZyBpdHMgc3RhcnRUaW1lKSwgdGhyb3dpbmcgdGhpbmdzIG9mZiBzbGlnaHRseSwgc28gd2UgbWFrZSBzdXJlIHRoZSBfc3RhcnQgZG9lc24ndCBzaGlmdC5cblxuICAgICAgICAgIF9zZXRFbmQodGhpcyk7XG5cbiAgICAgICAgICByZXR1cm4gdGhpcy5yZW5kZXIodG90YWxUaW1lLCBzdXBwcmVzc0V2ZW50cywgZm9yY2UpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHRoaXMuX29uVXBkYXRlICYmICFzdXBwcmVzc0V2ZW50cyAmJiBfY2FsbGJhY2sodGhpcywgXCJvblVwZGF0ZVwiLCB0cnVlKTtcbiAgICAgIGlmICh0VGltZSA9PT0gdER1ciAmJiB0aGlzLl90VGltZSA+PSB0aGlzLnRvdGFsRHVyYXRpb24oKSB8fCAhdFRpbWUgJiYgcHJldlRpbWUpIGlmIChwcmV2U3RhcnQgPT09IHRoaXMuX3N0YXJ0IHx8IE1hdGguYWJzKHRpbWVTY2FsZSkgIT09IE1hdGguYWJzKHRoaXMuX3RzKSkgaWYgKCF0aGlzLl9sb2NrKSB7XG4gICAgICAgIC8vIHJlbWVtYmVyLCBhIGNoaWxkJ3MgY2FsbGJhY2sgbWF5IGFsdGVyIHRoaXMgdGltZWxpbmUncyBwbGF5aGVhZCBvciB0aW1lU2NhbGUgd2hpY2ggaXMgd2h5IHdlIG5lZWQgdG8gYWRkIHNvbWUgb2YgdGhlc2UgY2hlY2tzLlxuICAgICAgICAodG90YWxUaW1lIHx8ICFkdXIpICYmICh0VGltZSA9PT0gdER1ciAmJiB0aGlzLl90cyA+IDAgfHwgIXRUaW1lICYmIHRoaXMuX3RzIDwgMCkgJiYgX3JlbW92ZUZyb21QYXJlbnQodGhpcywgMSk7IC8vIGRvbid0IHJlbW92ZSBpZiB0aGUgdGltZWxpbmUgaXMgcmV2ZXJzZWQgYW5kIHRoZSBwbGF5aGVhZCBpc24ndCBhdCAwLCBvdGhlcndpc2UgdGwucHJvZ3Jlc3MoMSkucmV2ZXJzZSgpIHdvbid0IHdvcmsuIE9ubHkgcmVtb3ZlIGlmIHRoZSBwbGF5aGVhZCBpcyBhdCB0aGUgZW5kIGFuZCB0aW1lU2NhbGUgaXMgcG9zaXRpdmUsIG9yIGlmIHRoZSBwbGF5aGVhZCBpcyBhdCAwIGFuZCB0aGUgdGltZVNjYWxlIGlzIG5lZ2F0aXZlLlxuXG4gICAgICAgIGlmICghc3VwcHJlc3NFdmVudHMgJiYgISh0b3RhbFRpbWUgPCAwICYmICFwcmV2VGltZSkgJiYgKHRUaW1lIHx8IHByZXZUaW1lIHx8ICF0RHVyKSkge1xuICAgICAgICAgIF9jYWxsYmFjayh0aGlzLCB0VGltZSA9PT0gdER1ciAmJiB0b3RhbFRpbWUgPj0gMCA/IFwib25Db21wbGV0ZVwiIDogXCJvblJldmVyc2VDb21wbGV0ZVwiLCB0cnVlKTtcblxuICAgICAgICAgIHRoaXMuX3Byb20gJiYgISh0VGltZSA8IHREdXIgJiYgdGhpcy50aW1lU2NhbGUoKSA+IDApICYmIHRoaXMuX3Byb20oKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIF9wcm90bzIuYWRkID0gZnVuY3Rpb24gYWRkKGNoaWxkLCBwb3NpdGlvbikge1xuICAgIHZhciBfdGhpczIgPSB0aGlzO1xuXG4gICAgX2lzTnVtYmVyKHBvc2l0aW9uKSB8fCAocG9zaXRpb24gPSBfcGFyc2VQb3NpdGlvbih0aGlzLCBwb3NpdGlvbiwgY2hpbGQpKTtcblxuICAgIGlmICghKGNoaWxkIGluc3RhbmNlb2YgQW5pbWF0aW9uKSkge1xuICAgICAgaWYgKF9pc0FycmF5KGNoaWxkKSkge1xuICAgICAgICBjaGlsZC5mb3JFYWNoKGZ1bmN0aW9uIChvYmopIHtcbiAgICAgICAgICByZXR1cm4gX3RoaXMyLmFkZChvYmosIHBvc2l0aW9uKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgfVxuXG4gICAgICBpZiAoX2lzU3RyaW5nKGNoaWxkKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5hZGRMYWJlbChjaGlsZCwgcG9zaXRpb24pO1xuICAgICAgfVxuXG4gICAgICBpZiAoX2lzRnVuY3Rpb24oY2hpbGQpKSB7XG4gICAgICAgIGNoaWxkID0gVHdlZW4uZGVsYXllZENhbGwoMCwgY2hpbGQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMgIT09IGNoaWxkID8gX2FkZFRvVGltZWxpbmUodGhpcywgY2hpbGQsIHBvc2l0aW9uKSA6IHRoaXM7IC8vZG9uJ3QgYWxsb3cgYSB0aW1lbGluZSB0byBiZSBhZGRlZCB0byBpdHNlbGYgYXMgYSBjaGlsZCFcbiAgfTtcblxuICBfcHJvdG8yLmdldENoaWxkcmVuID0gZnVuY3Rpb24gZ2V0Q2hpbGRyZW4obmVzdGVkLCB0d2VlbnMsIHRpbWVsaW5lcywgaWdub3JlQmVmb3JlVGltZSkge1xuICAgIGlmIChuZXN0ZWQgPT09IHZvaWQgMCkge1xuICAgICAgbmVzdGVkID0gdHJ1ZTtcbiAgICB9XG5cbiAgICBpZiAodHdlZW5zID09PSB2b2lkIDApIHtcbiAgICAgIHR3ZWVucyA9IHRydWU7XG4gICAgfVxuXG4gICAgaWYgKHRpbWVsaW5lcyA9PT0gdm9pZCAwKSB7XG4gICAgICB0aW1lbGluZXMgPSB0cnVlO1xuICAgIH1cblxuICAgIGlmIChpZ25vcmVCZWZvcmVUaW1lID09PSB2b2lkIDApIHtcbiAgICAgIGlnbm9yZUJlZm9yZVRpbWUgPSAtX2JpZ051bTtcbiAgICB9XG5cbiAgICB2YXIgYSA9IFtdLFxuICAgICAgICBjaGlsZCA9IHRoaXMuX2ZpcnN0O1xuXG4gICAgd2hpbGUgKGNoaWxkKSB7XG4gICAgICBpZiAoY2hpbGQuX3N0YXJ0ID49IGlnbm9yZUJlZm9yZVRpbWUpIHtcbiAgICAgICAgaWYgKGNoaWxkIGluc3RhbmNlb2YgVHdlZW4pIHtcbiAgICAgICAgICB0d2VlbnMgJiYgYS5wdXNoKGNoaWxkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aW1lbGluZXMgJiYgYS5wdXNoKGNoaWxkKTtcbiAgICAgICAgICBuZXN0ZWQgJiYgYS5wdXNoLmFwcGx5KGEsIGNoaWxkLmdldENoaWxkcmVuKHRydWUsIHR3ZWVucywgdGltZWxpbmVzKSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY2hpbGQgPSBjaGlsZC5fbmV4dDtcbiAgICB9XG5cbiAgICByZXR1cm4gYTtcbiAgfTtcblxuICBfcHJvdG8yLmdldEJ5SWQgPSBmdW5jdGlvbiBnZXRCeUlkKGlkKSB7XG4gICAgdmFyIGFuaW1hdGlvbnMgPSB0aGlzLmdldENoaWxkcmVuKDEsIDEsIDEpLFxuICAgICAgICBpID0gYW5pbWF0aW9ucy5sZW5ndGg7XG5cbiAgICB3aGlsZSAoaS0tKSB7XG4gICAgICBpZiAoYW5pbWF0aW9uc1tpXS52YXJzLmlkID09PSBpZCkge1xuICAgICAgICByZXR1cm4gYW5pbWF0aW9uc1tpXTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgX3Byb3RvMi5yZW1vdmUgPSBmdW5jdGlvbiByZW1vdmUoY2hpbGQpIHtcbiAgICBpZiAoX2lzU3RyaW5nKGNoaWxkKSkge1xuICAgICAgcmV0dXJuIHRoaXMucmVtb3ZlTGFiZWwoY2hpbGQpO1xuICAgIH1cblxuICAgIGlmIChfaXNGdW5jdGlvbihjaGlsZCkpIHtcbiAgICAgIHJldHVybiB0aGlzLmtpbGxUd2VlbnNPZihjaGlsZCk7XG4gICAgfVxuXG4gICAgY2hpbGQucGFyZW50ID09PSB0aGlzICYmIF9yZW1vdmVMaW5rZWRMaXN0SXRlbSh0aGlzLCBjaGlsZCk7XG5cbiAgICBpZiAoY2hpbGQgPT09IHRoaXMuX3JlY2VudCkge1xuICAgICAgdGhpcy5fcmVjZW50ID0gdGhpcy5fbGFzdDtcbiAgICB9XG5cbiAgICByZXR1cm4gX3VuY2FjaGUodGhpcyk7XG4gIH07XG5cbiAgX3Byb3RvMi50b3RhbFRpbWUgPSBmdW5jdGlvbiB0b3RhbFRpbWUoX3RvdGFsVGltZTIsIHN1cHByZXNzRXZlbnRzKSB7XG4gICAgaWYgKCFhcmd1bWVudHMubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gdGhpcy5fdFRpbWU7XG4gICAgfVxuXG4gICAgdGhpcy5fZm9yY2luZyA9IDE7XG5cbiAgICBpZiAoIXRoaXMuX2RwICYmIHRoaXMuX3RzKSB7XG4gICAgICAvL3NwZWNpYWwgY2FzZSBmb3IgdGhlIGdsb2JhbCB0aW1lbGluZSAob3IgYW55IG90aGVyIHRoYXQgaGFzIG5vIHBhcmVudCBvciBkZXRhY2hlZCBwYXJlbnQpLlxuICAgICAgdGhpcy5fc3RhcnQgPSBfcm91bmRQcmVjaXNlKF90aWNrZXIudGltZSAtICh0aGlzLl90cyA+IDAgPyBfdG90YWxUaW1lMiAvIHRoaXMuX3RzIDogKHRoaXMudG90YWxEdXJhdGlvbigpIC0gX3RvdGFsVGltZTIpIC8gLXRoaXMuX3RzKSk7XG4gICAgfVxuXG4gICAgX0FuaW1hdGlvbi5wcm90b3R5cGUudG90YWxUaW1lLmNhbGwodGhpcywgX3RvdGFsVGltZTIsIHN1cHByZXNzRXZlbnRzKTtcblxuICAgIHRoaXMuX2ZvcmNpbmcgPSAwO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIF9wcm90bzIuYWRkTGFiZWwgPSBmdW5jdGlvbiBhZGRMYWJlbChsYWJlbCwgcG9zaXRpb24pIHtcbiAgICB0aGlzLmxhYmVsc1tsYWJlbF0gPSBfcGFyc2VQb3NpdGlvbih0aGlzLCBwb3NpdGlvbik7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgX3Byb3RvMi5yZW1vdmVMYWJlbCA9IGZ1bmN0aW9uIHJlbW92ZUxhYmVsKGxhYmVsKSB7XG4gICAgZGVsZXRlIHRoaXMubGFiZWxzW2xhYmVsXTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBfcHJvdG8yLmFkZFBhdXNlID0gZnVuY3Rpb24gYWRkUGF1c2UocG9zaXRpb24sIGNhbGxiYWNrLCBwYXJhbXMpIHtcbiAgICB2YXIgdCA9IFR3ZWVuLmRlbGF5ZWRDYWxsKDAsIGNhbGxiYWNrIHx8IF9lbXB0eUZ1bmMsIHBhcmFtcyk7XG4gICAgdC5kYXRhID0gXCJpc1BhdXNlXCI7XG4gICAgdGhpcy5faGFzUGF1c2UgPSAxO1xuICAgIHJldHVybiBfYWRkVG9UaW1lbGluZSh0aGlzLCB0LCBfcGFyc2VQb3NpdGlvbih0aGlzLCBwb3NpdGlvbikpO1xuICB9O1xuXG4gIF9wcm90bzIucmVtb3ZlUGF1c2UgPSBmdW5jdGlvbiByZW1vdmVQYXVzZShwb3NpdGlvbikge1xuICAgIHZhciBjaGlsZCA9IHRoaXMuX2ZpcnN0O1xuICAgIHBvc2l0aW9uID0gX3BhcnNlUG9zaXRpb24odGhpcywgcG9zaXRpb24pO1xuXG4gICAgd2hpbGUgKGNoaWxkKSB7XG4gICAgICBpZiAoY2hpbGQuX3N0YXJ0ID09PSBwb3NpdGlvbiAmJiBjaGlsZC5kYXRhID09PSBcImlzUGF1c2VcIikge1xuICAgICAgICBfcmVtb3ZlRnJvbVBhcmVudChjaGlsZCk7XG4gICAgICB9XG5cbiAgICAgIGNoaWxkID0gY2hpbGQuX25leHQ7XG4gICAgfVxuICB9O1xuXG4gIF9wcm90bzIua2lsbFR3ZWVuc09mID0gZnVuY3Rpb24ga2lsbFR3ZWVuc09mKHRhcmdldHMsIHByb3BzLCBvbmx5QWN0aXZlKSB7XG4gICAgdmFyIHR3ZWVucyA9IHRoaXMuZ2V0VHdlZW5zT2YodGFyZ2V0cywgb25seUFjdGl2ZSksXG4gICAgICAgIGkgPSB0d2VlbnMubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGktLSkge1xuICAgICAgX292ZXJ3cml0aW5nVHdlZW4gIT09IHR3ZWVuc1tpXSAmJiB0d2VlbnNbaV0ua2lsbCh0YXJnZXRzLCBwcm9wcyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgX3Byb3RvMi5nZXRUd2VlbnNPZiA9IGZ1bmN0aW9uIGdldFR3ZWVuc09mKHRhcmdldHMsIG9ubHlBY3RpdmUpIHtcbiAgICB2YXIgYSA9IFtdLFxuICAgICAgICBwYXJzZWRUYXJnZXRzID0gdG9BcnJheSh0YXJnZXRzKSxcbiAgICAgICAgY2hpbGQgPSB0aGlzLl9maXJzdCxcbiAgICAgICAgaXNHbG9iYWxUaW1lID0gX2lzTnVtYmVyKG9ubHlBY3RpdmUpLFxuICAgICAgICAvLyBhIG51bWJlciBpcyBpbnRlcnByZXRlZCBhcyBhIGdsb2JhbCB0aW1lLiBJZiB0aGUgYW5pbWF0aW9uIHNwYW5zXG4gICAgY2hpbGRyZW47XG5cbiAgICB3aGlsZSAoY2hpbGQpIHtcbiAgICAgIGlmIChjaGlsZCBpbnN0YW5jZW9mIFR3ZWVuKSB7XG4gICAgICAgIGlmIChfYXJyYXlDb250YWluc0FueShjaGlsZC5fdGFyZ2V0cywgcGFyc2VkVGFyZ2V0cykgJiYgKGlzR2xvYmFsVGltZSA/ICghX292ZXJ3cml0aW5nVHdlZW4gfHwgY2hpbGQuX2luaXR0ZWQgJiYgY2hpbGQuX3RzKSAmJiBjaGlsZC5nbG9iYWxUaW1lKDApIDw9IG9ubHlBY3RpdmUgJiYgY2hpbGQuZ2xvYmFsVGltZShjaGlsZC50b3RhbER1cmF0aW9uKCkpID4gb25seUFjdGl2ZSA6ICFvbmx5QWN0aXZlIHx8IGNoaWxkLmlzQWN0aXZlKCkpKSB7XG4gICAgICAgICAgLy8gbm90ZTogaWYgdGhpcyBpcyBmb3Igb3ZlcndyaXRpbmcsIGl0IHNob3VsZCBvbmx5IGJlIGZvciB0d2VlbnMgdGhhdCBhcmVuJ3QgcGF1c2VkIGFuZCBhcmUgaW5pdHRlZC5cbiAgICAgICAgICBhLnB1c2goY2hpbGQpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKChjaGlsZHJlbiA9IGNoaWxkLmdldFR3ZWVuc09mKHBhcnNlZFRhcmdldHMsIG9ubHlBY3RpdmUpKS5sZW5ndGgpIHtcbiAgICAgICAgYS5wdXNoLmFwcGx5KGEsIGNoaWxkcmVuKTtcbiAgICAgIH1cblxuICAgICAgY2hpbGQgPSBjaGlsZC5fbmV4dDtcbiAgICB9XG5cbiAgICByZXR1cm4gYTtcbiAgfSAvLyBwb3RlbnRpYWwgZnV0dXJlIGZlYXR1cmUgLSB0YXJnZXRzKCkgb24gdGltZWxpbmVzXG4gIC8vIHRhcmdldHMoKSB7XG4gIC8vIFx0bGV0IHJlc3VsdCA9IFtdO1xuICAvLyBcdHRoaXMuZ2V0Q2hpbGRyZW4odHJ1ZSwgdHJ1ZSwgZmFsc2UpLmZvckVhY2godCA9PiByZXN1bHQucHVzaCguLi50LnRhcmdldHMoKSkpO1xuICAvLyBcdHJldHVybiByZXN1bHQuZmlsdGVyKCh2LCBpKSA9PiByZXN1bHQuaW5kZXhPZih2KSA9PT0gaSk7XG4gIC8vIH1cbiAgO1xuXG4gIF9wcm90bzIudHdlZW5UbyA9IGZ1bmN0aW9uIHR3ZWVuVG8ocG9zaXRpb24sIHZhcnMpIHtcbiAgICB2YXJzID0gdmFycyB8fCB7fTtcblxuICAgIHZhciB0bCA9IHRoaXMsXG4gICAgICAgIGVuZFRpbWUgPSBfcGFyc2VQb3NpdGlvbih0bCwgcG9zaXRpb24pLFxuICAgICAgICBfdmFycyA9IHZhcnMsXG4gICAgICAgIHN0YXJ0QXQgPSBfdmFycy5zdGFydEF0LFxuICAgICAgICBfb25TdGFydCA9IF92YXJzLm9uU3RhcnQsXG4gICAgICAgIG9uU3RhcnRQYXJhbXMgPSBfdmFycy5vblN0YXJ0UGFyYW1zLFxuICAgICAgICBpbW1lZGlhdGVSZW5kZXIgPSBfdmFycy5pbW1lZGlhdGVSZW5kZXIsXG4gICAgICAgIGluaXR0ZWQsXG4gICAgICAgIHR3ZWVuID0gVHdlZW4udG8odGwsIF9zZXREZWZhdWx0cyh7XG4gICAgICBlYXNlOiB2YXJzLmVhc2UgfHwgXCJub25lXCIsXG4gICAgICBsYXp5OiBmYWxzZSxcbiAgICAgIGltbWVkaWF0ZVJlbmRlcjogZmFsc2UsXG4gICAgICB0aW1lOiBlbmRUaW1lLFxuICAgICAgb3ZlcndyaXRlOiBcImF1dG9cIixcbiAgICAgIGR1cmF0aW9uOiB2YXJzLmR1cmF0aW9uIHx8IE1hdGguYWJzKChlbmRUaW1lIC0gKHN0YXJ0QXQgJiYgXCJ0aW1lXCIgaW4gc3RhcnRBdCA/IHN0YXJ0QXQudGltZSA6IHRsLl90aW1lKSkgLyB0bC50aW1lU2NhbGUoKSkgfHwgX3RpbnlOdW0sXG4gICAgICBvblN0YXJ0OiBmdW5jdGlvbiBvblN0YXJ0KCkge1xuICAgICAgICB0bC5wYXVzZSgpO1xuXG4gICAgICAgIGlmICghaW5pdHRlZCkge1xuICAgICAgICAgIHZhciBkdXJhdGlvbiA9IHZhcnMuZHVyYXRpb24gfHwgTWF0aC5hYnMoKGVuZFRpbWUgLSAoc3RhcnRBdCAmJiBcInRpbWVcIiBpbiBzdGFydEF0ID8gc3RhcnRBdC50aW1lIDogdGwuX3RpbWUpKSAvIHRsLnRpbWVTY2FsZSgpKTtcbiAgICAgICAgICB0d2Vlbi5fZHVyICE9PSBkdXJhdGlvbiAmJiBfc2V0RHVyYXRpb24odHdlZW4sIGR1cmF0aW9uLCAwLCAxKS5yZW5kZXIodHdlZW4uX3RpbWUsIHRydWUsIHRydWUpO1xuICAgICAgICAgIGluaXR0ZWQgPSAxO1xuICAgICAgICB9XG5cbiAgICAgICAgX29uU3RhcnQgJiYgX29uU3RhcnQuYXBwbHkodHdlZW4sIG9uU3RhcnRQYXJhbXMgfHwgW10pOyAvL2luIGNhc2UgdGhlIHVzZXIgaGFkIGFuIG9uU3RhcnQgaW4gdGhlIHZhcnMgLSB3ZSBkb24ndCB3YW50IHRvIG92ZXJ3cml0ZSBpdC5cbiAgICAgIH1cbiAgICB9LCB2YXJzKSk7XG5cbiAgICByZXR1cm4gaW1tZWRpYXRlUmVuZGVyID8gdHdlZW4ucmVuZGVyKDApIDogdHdlZW47XG4gIH07XG5cbiAgX3Byb3RvMi50d2VlbkZyb21UbyA9IGZ1bmN0aW9uIHR3ZWVuRnJvbVRvKGZyb21Qb3NpdGlvbiwgdG9Qb3NpdGlvbiwgdmFycykge1xuICAgIHJldHVybiB0aGlzLnR3ZWVuVG8odG9Qb3NpdGlvbiwgX3NldERlZmF1bHRzKHtcbiAgICAgIHN0YXJ0QXQ6IHtcbiAgICAgICAgdGltZTogX3BhcnNlUG9zaXRpb24odGhpcywgZnJvbVBvc2l0aW9uKVxuICAgICAgfVxuICAgIH0sIHZhcnMpKTtcbiAgfTtcblxuICBfcHJvdG8yLnJlY2VudCA9IGZ1bmN0aW9uIHJlY2VudCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVjZW50O1xuICB9O1xuXG4gIF9wcm90bzIubmV4dExhYmVsID0gZnVuY3Rpb24gbmV4dExhYmVsKGFmdGVyVGltZSkge1xuICAgIGlmIChhZnRlclRpbWUgPT09IHZvaWQgMCkge1xuICAgICAgYWZ0ZXJUaW1lID0gdGhpcy5fdGltZTtcbiAgICB9XG5cbiAgICByZXR1cm4gX2dldExhYmVsSW5EaXJlY3Rpb24odGhpcywgX3BhcnNlUG9zaXRpb24odGhpcywgYWZ0ZXJUaW1lKSk7XG4gIH07XG5cbiAgX3Byb3RvMi5wcmV2aW91c0xhYmVsID0gZnVuY3Rpb24gcHJldmlvdXNMYWJlbChiZWZvcmVUaW1lKSB7XG4gICAgaWYgKGJlZm9yZVRpbWUgPT09IHZvaWQgMCkge1xuICAgICAgYmVmb3JlVGltZSA9IHRoaXMuX3RpbWU7XG4gICAgfVxuXG4gICAgcmV0dXJuIF9nZXRMYWJlbEluRGlyZWN0aW9uKHRoaXMsIF9wYXJzZVBvc2l0aW9uKHRoaXMsIGJlZm9yZVRpbWUpLCAxKTtcbiAgfTtcblxuICBfcHJvdG8yLmN1cnJlbnRMYWJlbCA9IGZ1bmN0aW9uIGN1cnJlbnRMYWJlbCh2YWx1ZSkge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gdGhpcy5zZWVrKHZhbHVlLCB0cnVlKSA6IHRoaXMucHJldmlvdXNMYWJlbCh0aGlzLl90aW1lICsgX3RpbnlOdW0pO1xuICB9O1xuXG4gIF9wcm90bzIuc2hpZnRDaGlsZHJlbiA9IGZ1bmN0aW9uIHNoaWZ0Q2hpbGRyZW4oYW1vdW50LCBhZGp1c3RMYWJlbHMsIGlnbm9yZUJlZm9yZVRpbWUpIHtcbiAgICBpZiAoaWdub3JlQmVmb3JlVGltZSA9PT0gdm9pZCAwKSB7XG4gICAgICBpZ25vcmVCZWZvcmVUaW1lID0gMDtcbiAgICB9XG5cbiAgICB2YXIgY2hpbGQgPSB0aGlzLl9maXJzdCxcbiAgICAgICAgbGFiZWxzID0gdGhpcy5sYWJlbHMsXG4gICAgICAgIHA7XG4gICAgYW1vdW50ID0gX3JvdW5kUHJlY2lzZShhbW91bnQpO1xuXG4gICAgd2hpbGUgKGNoaWxkKSB7XG4gICAgICBpZiAoY2hpbGQuX3N0YXJ0ID49IGlnbm9yZUJlZm9yZVRpbWUpIHtcbiAgICAgICAgY2hpbGQuX3N0YXJ0ICs9IGFtb3VudDtcbiAgICAgICAgY2hpbGQuX2VuZCArPSBhbW91bnQ7XG4gICAgICB9XG5cbiAgICAgIGNoaWxkID0gY2hpbGQuX25leHQ7XG4gICAgfVxuXG4gICAgaWYgKGFkanVzdExhYmVscykge1xuICAgICAgZm9yIChwIGluIGxhYmVscykge1xuICAgICAgICBpZiAobGFiZWxzW3BdID49IGlnbm9yZUJlZm9yZVRpbWUpIHtcbiAgICAgICAgICBsYWJlbHNbcF0gKz0gYW1vdW50O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIF91bmNhY2hlKHRoaXMpO1xuICB9O1xuXG4gIF9wcm90bzIuaW52YWxpZGF0ZSA9IGZ1bmN0aW9uIGludmFsaWRhdGUoc29mdCkge1xuICAgIHZhciBjaGlsZCA9IHRoaXMuX2ZpcnN0O1xuICAgIHRoaXMuX2xvY2sgPSAwO1xuXG4gICAgd2hpbGUgKGNoaWxkKSB7XG4gICAgICBjaGlsZC5pbnZhbGlkYXRlKHNvZnQpO1xuICAgICAgY2hpbGQgPSBjaGlsZC5fbmV4dDtcbiAgICB9XG5cbiAgICByZXR1cm4gX0FuaW1hdGlvbi5wcm90b3R5cGUuaW52YWxpZGF0ZS5jYWxsKHRoaXMsIHNvZnQpO1xuICB9O1xuXG4gIF9wcm90bzIuY2xlYXIgPSBmdW5jdGlvbiBjbGVhcihpbmNsdWRlTGFiZWxzKSB7XG4gICAgaWYgKGluY2x1ZGVMYWJlbHMgPT09IHZvaWQgMCkge1xuICAgICAgaW5jbHVkZUxhYmVscyA9IHRydWU7XG4gICAgfVxuXG4gICAgdmFyIGNoaWxkID0gdGhpcy5fZmlyc3QsXG4gICAgICAgIG5leHQ7XG5cbiAgICB3aGlsZSAoY2hpbGQpIHtcbiAgICAgIG5leHQgPSBjaGlsZC5fbmV4dDtcbiAgICAgIHRoaXMucmVtb3ZlKGNoaWxkKTtcbiAgICAgIGNoaWxkID0gbmV4dDtcbiAgICB9XG5cbiAgICB0aGlzLl9kcCAmJiAodGhpcy5fdGltZSA9IHRoaXMuX3RUaW1lID0gdGhpcy5fcFRpbWUgPSAwKTtcbiAgICBpbmNsdWRlTGFiZWxzICYmICh0aGlzLmxhYmVscyA9IHt9KTtcbiAgICByZXR1cm4gX3VuY2FjaGUodGhpcyk7XG4gIH07XG5cbiAgX3Byb3RvMi50b3RhbER1cmF0aW9uID0gZnVuY3Rpb24gdG90YWxEdXJhdGlvbih2YWx1ZSkge1xuICAgIHZhciBtYXggPSAwLFxuICAgICAgICBzZWxmID0gdGhpcyxcbiAgICAgICAgY2hpbGQgPSBzZWxmLl9sYXN0LFxuICAgICAgICBwcmV2U3RhcnQgPSBfYmlnTnVtLFxuICAgICAgICBwcmV2LFxuICAgICAgICBzdGFydCxcbiAgICAgICAgcGFyZW50O1xuXG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICAgIHJldHVybiBzZWxmLnRpbWVTY2FsZSgoc2VsZi5fcmVwZWF0IDwgMCA/IHNlbGYuZHVyYXRpb24oKSA6IHNlbGYudG90YWxEdXJhdGlvbigpKSAvIChzZWxmLnJldmVyc2VkKCkgPyAtdmFsdWUgOiB2YWx1ZSkpO1xuICAgIH1cblxuICAgIGlmIChzZWxmLl9kaXJ0eSkge1xuICAgICAgcGFyZW50ID0gc2VsZi5wYXJlbnQ7XG5cbiAgICAgIHdoaWxlIChjaGlsZCkge1xuICAgICAgICBwcmV2ID0gY2hpbGQuX3ByZXY7IC8vcmVjb3JkIGl0IGhlcmUgaW4gY2FzZSB0aGUgdHdlZW4gY2hhbmdlcyBwb3NpdGlvbiBpbiB0aGUgc2VxdWVuY2UuLi5cblxuICAgICAgICBjaGlsZC5fZGlydHkgJiYgY2hpbGQudG90YWxEdXJhdGlvbigpOyAvL2NvdWxkIGNoYW5nZSB0aGUgdHdlZW4uX3N0YXJ0VGltZSwgc28gbWFrZSBzdXJlIHRoZSBhbmltYXRpb24ncyBjYWNoZSBpcyBjbGVhbiBiZWZvcmUgYW5hbHl6aW5nIGl0LlxuXG4gICAgICAgIHN0YXJ0ID0gY2hpbGQuX3N0YXJ0O1xuXG4gICAgICAgIGlmIChzdGFydCA+IHByZXZTdGFydCAmJiBzZWxmLl9zb3J0ICYmIGNoaWxkLl90cyAmJiAhc2VsZi5fbG9jaykge1xuICAgICAgICAgIC8vaW4gY2FzZSBvbmUgb2YgdGhlIHR3ZWVucyBzaGlmdGVkIG91dCBvZiBvcmRlciwgaXQgbmVlZHMgdG8gYmUgcmUtaW5zZXJ0ZWQgaW50byB0aGUgY29ycmVjdCBwb3NpdGlvbiBpbiB0aGUgc2VxdWVuY2VcbiAgICAgICAgICBzZWxmLl9sb2NrID0gMTsgLy9wcmV2ZW50IGVuZGxlc3MgcmVjdXJzaXZlIGNhbGxzIC0gdGhlcmUgYXJlIG1ldGhvZHMgdGhhdCBnZXQgdHJpZ2dlcmVkIHRoYXQgY2hlY2sgZHVyYXRpb24vdG90YWxEdXJhdGlvbiB3aGVuIHdlIGFkZCgpLlxuXG4gICAgICAgICAgX2FkZFRvVGltZWxpbmUoc2VsZiwgY2hpbGQsIHN0YXJ0IC0gY2hpbGQuX2RlbGF5LCAxKS5fbG9jayA9IDA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcHJldlN0YXJ0ID0gc3RhcnQ7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoc3RhcnQgPCAwICYmIGNoaWxkLl90cykge1xuICAgICAgICAgIC8vY2hpbGRyZW4gYXJlbid0IGFsbG93ZWQgdG8gaGF2ZSBuZWdhdGl2ZSBzdGFydFRpbWVzIHVubGVzcyBzbW9vdGhDaGlsZFRpbWluZyBpcyB0cnVlLCBzbyBhZGp1c3QgaGVyZSBpZiBvbmUgaXMgZm91bmQuXG4gICAgICAgICAgbWF4IC09IHN0YXJ0O1xuXG4gICAgICAgICAgaWYgKCFwYXJlbnQgJiYgIXNlbGYuX2RwIHx8IHBhcmVudCAmJiBwYXJlbnQuc21vb3RoQ2hpbGRUaW1pbmcpIHtcbiAgICAgICAgICAgIHNlbGYuX3N0YXJ0ICs9IF9yb3VuZFByZWNpc2Uoc3RhcnQgLyBzZWxmLl90cyk7XG4gICAgICAgICAgICBzZWxmLl90aW1lIC09IHN0YXJ0O1xuICAgICAgICAgICAgc2VsZi5fdFRpbWUgLT0gc3RhcnQ7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgc2VsZi5zaGlmdENoaWxkcmVuKC1zdGFydCwgZmFsc2UsIC0xZTk5OSk7XG4gICAgICAgICAgcHJldlN0YXJ0ID0gMDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNoaWxkLl9lbmQgPiBtYXggJiYgY2hpbGQuX3RzICYmIChtYXggPSBjaGlsZC5fZW5kKTtcbiAgICAgICAgY2hpbGQgPSBwcmV2O1xuICAgICAgfVxuXG4gICAgICBfc2V0RHVyYXRpb24oc2VsZiwgc2VsZiA9PT0gX2dsb2JhbFRpbWVsaW5lICYmIHNlbGYuX3RpbWUgPiBtYXggPyBzZWxmLl90aW1lIDogbWF4LCAxLCAxKTtcblxuICAgICAgc2VsZi5fZGlydHkgPSAwO1xuICAgIH1cblxuICAgIHJldHVybiBzZWxmLl90RHVyO1xuICB9O1xuXG4gIFRpbWVsaW5lLnVwZGF0ZVJvb3QgPSBmdW5jdGlvbiB1cGRhdGVSb290KHRpbWUpIHtcbiAgICBpZiAoX2dsb2JhbFRpbWVsaW5lLl90cykge1xuICAgICAgX2xhenlTYWZlUmVuZGVyKF9nbG9iYWxUaW1lbGluZSwgX3BhcmVudFRvQ2hpbGRUb3RhbFRpbWUodGltZSwgX2dsb2JhbFRpbWVsaW5lKSk7XG5cbiAgICAgIF9sYXN0UmVuZGVyZWRGcmFtZSA9IF90aWNrZXIuZnJhbWU7XG4gICAgfVxuXG4gICAgaWYgKF90aWNrZXIuZnJhbWUgPj0gX25leHRHQ0ZyYW1lKSB7XG4gICAgICBfbmV4dEdDRnJhbWUgKz0gX2NvbmZpZy5hdXRvU2xlZXAgfHwgMTIwO1xuICAgICAgdmFyIGNoaWxkID0gX2dsb2JhbFRpbWVsaW5lLl9maXJzdDtcbiAgICAgIGlmICghY2hpbGQgfHwgIWNoaWxkLl90cykgaWYgKF9jb25maWcuYXV0b1NsZWVwICYmIF90aWNrZXIuX2xpc3RlbmVycy5sZW5ndGggPCAyKSB7XG4gICAgICAgIHdoaWxlIChjaGlsZCAmJiAhY2hpbGQuX3RzKSB7XG4gICAgICAgICAgY2hpbGQgPSBjaGlsZC5fbmV4dDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNoaWxkIHx8IF90aWNrZXIuc2xlZXAoKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIFRpbWVsaW5lO1xufShBbmltYXRpb24pO1xuXG5fc2V0RGVmYXVsdHMoVGltZWxpbmUucHJvdG90eXBlLCB7XG4gIF9sb2NrOiAwLFxuICBfaGFzUGF1c2U6IDAsXG4gIF9mb3JjaW5nOiAwXG59KTtcblxudmFyIF9hZGRDb21wbGV4U3RyaW5nUHJvcFR3ZWVuID0gZnVuY3Rpb24gX2FkZENvbXBsZXhTdHJpbmdQcm9wVHdlZW4odGFyZ2V0LCBwcm9wLCBzdGFydCwgZW5kLCBzZXR0ZXIsIHN0cmluZ0ZpbHRlciwgZnVuY1BhcmFtKSB7XG4gIC8vbm90ZTogd2UgY2FsbCBfYWRkQ29tcGxleFN0cmluZ1Byb3BUd2Vlbi5jYWxsKHR3ZWVuSW5zdGFuY2UuLi4pIHRvIGVuc3VyZSB0aGF0IGl0J3Mgc2NvcGVkIHByb3Blcmx5LiBXZSBtYXkgY2FsbCBpdCBmcm9tIHdpdGhpbiBhIHBsdWdpbiB0b28sIHRodXMgXCJ0aGlzXCIgd291bGQgcmVmZXIgdG8gdGhlIHBsdWdpbi5cbiAgdmFyIHB0ID0gbmV3IFByb3BUd2Vlbih0aGlzLl9wdCwgdGFyZ2V0LCBwcm9wLCAwLCAxLCBfcmVuZGVyQ29tcGxleFN0cmluZywgbnVsbCwgc2V0dGVyKSxcbiAgICAgIGluZGV4ID0gMCxcbiAgICAgIG1hdGNoSW5kZXggPSAwLFxuICAgICAgcmVzdWx0LFxuICAgICAgc3RhcnROdW1zLFxuICAgICAgY29sb3IsXG4gICAgICBlbmROdW0sXG4gICAgICBjaHVuayxcbiAgICAgIHN0YXJ0TnVtLFxuICAgICAgaGFzUmFuZG9tLFxuICAgICAgYTtcbiAgcHQuYiA9IHN0YXJ0O1xuICBwdC5lID0gZW5kO1xuICBzdGFydCArPSBcIlwiOyAvL2Vuc3VyZSB2YWx1ZXMgYXJlIHN0cmluZ3NcblxuICBlbmQgKz0gXCJcIjtcblxuICBpZiAoaGFzUmFuZG9tID0gfmVuZC5pbmRleE9mKFwicmFuZG9tKFwiKSkge1xuICAgIGVuZCA9IF9yZXBsYWNlUmFuZG9tKGVuZCk7XG4gIH1cblxuICBpZiAoc3RyaW5nRmlsdGVyKSB7XG4gICAgYSA9IFtzdGFydCwgZW5kXTtcbiAgICBzdHJpbmdGaWx0ZXIoYSwgdGFyZ2V0LCBwcm9wKTsgLy9wYXNzIGFuIGFycmF5IHdpdGggdGhlIHN0YXJ0aW5nIGFuZCBlbmRpbmcgdmFsdWVzIGFuZCBsZXQgdGhlIGZpbHRlciBkbyB3aGF0ZXZlciBpdCBuZWVkcyB0byB0aGUgdmFsdWVzLlxuXG4gICAgc3RhcnQgPSBhWzBdO1xuICAgIGVuZCA9IGFbMV07XG4gIH1cblxuICBzdGFydE51bXMgPSBzdGFydC5tYXRjaChfY29tcGxleFN0cmluZ051bUV4cCkgfHwgW107XG5cbiAgd2hpbGUgKHJlc3VsdCA9IF9jb21wbGV4U3RyaW5nTnVtRXhwLmV4ZWMoZW5kKSkge1xuICAgIGVuZE51bSA9IHJlc3VsdFswXTtcbiAgICBjaHVuayA9IGVuZC5zdWJzdHJpbmcoaW5kZXgsIHJlc3VsdC5pbmRleCk7XG5cbiAgICBpZiAoY29sb3IpIHtcbiAgICAgIGNvbG9yID0gKGNvbG9yICsgMSkgJSA1O1xuICAgIH0gZWxzZSBpZiAoY2h1bmsuc3Vic3RyKC01KSA9PT0gXCJyZ2JhKFwiKSB7XG4gICAgICBjb2xvciA9IDE7XG4gICAgfVxuXG4gICAgaWYgKGVuZE51bSAhPT0gc3RhcnROdW1zW21hdGNoSW5kZXgrK10pIHtcbiAgICAgIHN0YXJ0TnVtID0gcGFyc2VGbG9hdChzdGFydE51bXNbbWF0Y2hJbmRleCAtIDFdKSB8fCAwOyAvL3RoZXNlIG5lc3RlZCBQcm9wVHdlZW5zIGFyZSBoYW5kbGVkIGluIGEgc3BlY2lhbCB3YXkgLSB3ZSdsbCBuZXZlciBhY3R1YWxseSBjYWxsIGEgcmVuZGVyIG9yIHNldHRlciBtZXRob2Qgb24gdGhlbS4gV2UnbGwganVzdCBsb29wIHRocm91Z2ggdGhlbSBpbiB0aGUgcGFyZW50IGNvbXBsZXggc3RyaW5nIFByb3BUd2VlbidzIHJlbmRlciBtZXRob2QuXG5cbiAgICAgIHB0Ll9wdCA9IHtcbiAgICAgICAgX25leHQ6IHB0Ll9wdCxcbiAgICAgICAgcDogY2h1bmsgfHwgbWF0Y2hJbmRleCA9PT0gMSA/IGNodW5rIDogXCIsXCIsXG4gICAgICAgIC8vbm90ZTogU1ZHIHNwZWMgYWxsb3dzIG9taXNzaW9uIG9mIGNvbW1hL3NwYWNlIHdoZW4gYSBuZWdhdGl2ZSBzaWduIGlzIHdlZGdlZCBiZXR3ZWVuIHR3byBudW1iZXJzLCBsaWtlIDIuNS01LjMgaW5zdGVhZCBvZiAyLjUsLTUuMyBidXQgd2hlbiB0d2VlbmluZywgdGhlIG5lZ2F0aXZlIHZhbHVlIG1heSBzd2l0Y2ggdG8gcG9zaXRpdmUsIHNvIHdlIGluc2VydCB0aGUgY29tbWEganVzdCBpbiBjYXNlLlxuICAgICAgICBzOiBzdGFydE51bSxcbiAgICAgICAgYzogZW5kTnVtLmNoYXJBdCgxKSA9PT0gXCI9XCIgPyBfcGFyc2VSZWxhdGl2ZShzdGFydE51bSwgZW5kTnVtKSAtIHN0YXJ0TnVtIDogcGFyc2VGbG9hdChlbmROdW0pIC0gc3RhcnROdW0sXG4gICAgICAgIG06IGNvbG9yICYmIGNvbG9yIDwgNCA/IE1hdGgucm91bmQgOiAwXG4gICAgICB9O1xuICAgICAgaW5kZXggPSBfY29tcGxleFN0cmluZ051bUV4cC5sYXN0SW5kZXg7XG4gICAgfVxuICB9XG5cbiAgcHQuYyA9IGluZGV4IDwgZW5kLmxlbmd0aCA/IGVuZC5zdWJzdHJpbmcoaW5kZXgsIGVuZC5sZW5ndGgpIDogXCJcIjsgLy93ZSB1c2UgdGhlIFwiY1wiIG9mIHRoZSBQcm9wVHdlZW4gdG8gc3RvcmUgdGhlIGZpbmFsIHBhcnQgb2YgdGhlIHN0cmluZyAoYWZ0ZXIgdGhlIGxhc3QgbnVtYmVyKVxuXG4gIHB0LmZwID0gZnVuY1BhcmFtO1xuXG4gIGlmIChfcmVsRXhwLnRlc3QoZW5kKSB8fCBoYXNSYW5kb20pIHtcbiAgICBwdC5lID0gMDsgLy9pZiB0aGUgZW5kIHN0cmluZyBjb250YWlucyByZWxhdGl2ZSB2YWx1ZXMgb3IgZHluYW1pYyByYW5kb20oLi4uKSB2YWx1ZXMsIGRlbGV0ZSB0aGUgZW5kIGl0IHNvIHRoYXQgb24gdGhlIGZpbmFsIHJlbmRlciB3ZSBkb24ndCBhY3R1YWxseSBzZXQgaXQgdG8gdGhlIHN0cmluZyB3aXRoICs9IG9yIC09IGNoYXJhY3RlcnMgKGZvcmNlcyBpdCB0byB1c2UgdGhlIGNhbGN1bGF0ZWQgdmFsdWUpLlxuICB9XG5cbiAgdGhpcy5fcHQgPSBwdDsgLy9zdGFydCB0aGUgbGlua2VkIGxpc3Qgd2l0aCB0aGlzIG5ldyBQcm9wVHdlZW4uIFJlbWVtYmVyLCB3ZSBjYWxsIF9hZGRDb21wbGV4U3RyaW5nUHJvcFR3ZWVuLmNhbGwodHdlZW5JbnN0YW5jZS4uLikgdG8gZW5zdXJlIHRoYXQgaXQncyBzY29wZWQgcHJvcGVybHkuIFdlIG1heSBjYWxsIGl0IGZyb20gd2l0aGluIGEgcGx1Z2luIHRvbywgdGh1cyBcInRoaXNcIiB3b3VsZCByZWZlciB0byB0aGUgcGx1Z2luLlxuXG4gIHJldHVybiBwdDtcbn0sXG4gICAgX2FkZFByb3BUd2VlbiA9IGZ1bmN0aW9uIF9hZGRQcm9wVHdlZW4odGFyZ2V0LCBwcm9wLCBzdGFydCwgZW5kLCBpbmRleCwgdGFyZ2V0cywgbW9kaWZpZXIsIHN0cmluZ0ZpbHRlciwgZnVuY1BhcmFtLCBvcHRpb25hbCkge1xuICBfaXNGdW5jdGlvbihlbmQpICYmIChlbmQgPSBlbmQoaW5kZXggfHwgMCwgdGFyZ2V0LCB0YXJnZXRzKSk7XG4gIHZhciBjdXJyZW50VmFsdWUgPSB0YXJnZXRbcHJvcF0sXG4gICAgICBwYXJzZWRTdGFydCA9IHN0YXJ0ICE9PSBcImdldFwiID8gc3RhcnQgOiAhX2lzRnVuY3Rpb24oY3VycmVudFZhbHVlKSA/IGN1cnJlbnRWYWx1ZSA6IGZ1bmNQYXJhbSA/IHRhcmdldFtwcm9wLmluZGV4T2YoXCJzZXRcIikgfHwgIV9pc0Z1bmN0aW9uKHRhcmdldFtcImdldFwiICsgcHJvcC5zdWJzdHIoMyldKSA/IHByb3AgOiBcImdldFwiICsgcHJvcC5zdWJzdHIoMyldKGZ1bmNQYXJhbSkgOiB0YXJnZXRbcHJvcF0oKSxcbiAgICAgIHNldHRlciA9ICFfaXNGdW5jdGlvbihjdXJyZW50VmFsdWUpID8gX3NldHRlclBsYWluIDogZnVuY1BhcmFtID8gX3NldHRlckZ1bmNXaXRoUGFyYW0gOiBfc2V0dGVyRnVuYyxcbiAgICAgIHB0O1xuXG4gIGlmIChfaXNTdHJpbmcoZW5kKSkge1xuICAgIGlmICh+ZW5kLmluZGV4T2YoXCJyYW5kb20oXCIpKSB7XG4gICAgICBlbmQgPSBfcmVwbGFjZVJhbmRvbShlbmQpO1xuICAgIH1cblxuICAgIGlmIChlbmQuY2hhckF0KDEpID09PSBcIj1cIikge1xuICAgICAgcHQgPSBfcGFyc2VSZWxhdGl2ZShwYXJzZWRTdGFydCwgZW5kKSArIChnZXRVbml0KHBhcnNlZFN0YXJ0KSB8fCAwKTtcblxuICAgICAgaWYgKHB0IHx8IHB0ID09PSAwKSB7XG4gICAgICAgIC8vIHRvIGF2b2lkIGlzTmFOLCBsaWtlIGlmIHNvbWVvbmUgcGFzc2VzIGluIGEgdmFsdWUgbGlrZSBcIiE9IHdoYXRldmVyXCJcbiAgICAgICAgZW5kID0gcHQ7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKCFvcHRpb25hbCB8fCBwYXJzZWRTdGFydCAhPT0gZW5kIHx8IF9mb3JjZUFsbFByb3BUd2VlbnMpIHtcbiAgICBpZiAoIWlzTmFOKHBhcnNlZFN0YXJ0ICogZW5kKSAmJiBlbmQgIT09IFwiXCIpIHtcbiAgICAgIC8vIGZ1biBmYWN0OiBhbnkgbnVtYmVyIG11bHRpcGxpZWQgYnkgXCJcIiBpcyBldmFsdWF0ZWQgYXMgdGhlIG51bWJlciAwIVxuICAgICAgcHQgPSBuZXcgUHJvcFR3ZWVuKHRoaXMuX3B0LCB0YXJnZXQsIHByb3AsICtwYXJzZWRTdGFydCB8fCAwLCBlbmQgLSAocGFyc2VkU3RhcnQgfHwgMCksIHR5cGVvZiBjdXJyZW50VmFsdWUgPT09IFwiYm9vbGVhblwiID8gX3JlbmRlckJvb2xlYW4gOiBfcmVuZGVyUGxhaW4sIDAsIHNldHRlcik7XG4gICAgICBmdW5jUGFyYW0gJiYgKHB0LmZwID0gZnVuY1BhcmFtKTtcbiAgICAgIG1vZGlmaWVyICYmIHB0Lm1vZGlmaWVyKG1vZGlmaWVyLCB0aGlzLCB0YXJnZXQpO1xuICAgICAgcmV0dXJuIHRoaXMuX3B0ID0gcHQ7XG4gICAgfVxuXG4gICAgIWN1cnJlbnRWYWx1ZSAmJiAhKHByb3AgaW4gdGFyZ2V0KSAmJiBfbWlzc2luZ1BsdWdpbihwcm9wLCBlbmQpO1xuICAgIHJldHVybiBfYWRkQ29tcGxleFN0cmluZ1Byb3BUd2Vlbi5jYWxsKHRoaXMsIHRhcmdldCwgcHJvcCwgcGFyc2VkU3RhcnQsIGVuZCwgc2V0dGVyLCBzdHJpbmdGaWx0ZXIgfHwgX2NvbmZpZy5zdHJpbmdGaWx0ZXIsIGZ1bmNQYXJhbSk7XG4gIH1cbn0sXG4gICAgLy9jcmVhdGVzIGEgY29weSBvZiB0aGUgdmFycyBvYmplY3QgYW5kIHByb2Nlc3NlcyBhbnkgZnVuY3Rpb24tYmFzZWQgdmFsdWVzIChwdXR0aW5nIHRoZSByZXN1bHRpbmcgdmFsdWVzIGRpcmVjdGx5IGludG8gdGhlIGNvcHkpIGFzIHdlbGwgYXMgc3RyaW5ncyB3aXRoIFwicmFuZG9tKClcIiBpbiB0aGVtLiBJdCBkb2VzIE5PVCBwcm9jZXNzIHJlbGF0aXZlIHZhbHVlcy5cbl9wcm9jZXNzVmFycyA9IGZ1bmN0aW9uIF9wcm9jZXNzVmFycyh2YXJzLCBpbmRleCwgdGFyZ2V0LCB0YXJnZXRzLCB0d2Vlbikge1xuICBfaXNGdW5jdGlvbih2YXJzKSAmJiAodmFycyA9IF9wYXJzZUZ1bmNPclN0cmluZyh2YXJzLCB0d2VlbiwgaW5kZXgsIHRhcmdldCwgdGFyZ2V0cykpO1xuXG4gIGlmICghX2lzT2JqZWN0KHZhcnMpIHx8IHZhcnMuc3R5bGUgJiYgdmFycy5ub2RlVHlwZSB8fCBfaXNBcnJheSh2YXJzKSB8fCBfaXNUeXBlZEFycmF5KHZhcnMpKSB7XG4gICAgcmV0dXJuIF9pc1N0cmluZyh2YXJzKSA/IF9wYXJzZUZ1bmNPclN0cmluZyh2YXJzLCB0d2VlbiwgaW5kZXgsIHRhcmdldCwgdGFyZ2V0cykgOiB2YXJzO1xuICB9XG5cbiAgdmFyIGNvcHkgPSB7fSxcbiAgICAgIHA7XG5cbiAgZm9yIChwIGluIHZhcnMpIHtcbiAgICBjb3B5W3BdID0gX3BhcnNlRnVuY09yU3RyaW5nKHZhcnNbcF0sIHR3ZWVuLCBpbmRleCwgdGFyZ2V0LCB0YXJnZXRzKTtcbiAgfVxuXG4gIHJldHVybiBjb3B5O1xufSxcbiAgICBfY2hlY2tQbHVnaW4gPSBmdW5jdGlvbiBfY2hlY2tQbHVnaW4ocHJvcGVydHksIHZhcnMsIHR3ZWVuLCBpbmRleCwgdGFyZ2V0LCB0YXJnZXRzKSB7XG4gIHZhciBwbHVnaW4sIHB0LCBwdExvb2t1cCwgaTtcblxuICBpZiAoX3BsdWdpbnNbcHJvcGVydHldICYmIChwbHVnaW4gPSBuZXcgX3BsdWdpbnNbcHJvcGVydHldKCkpLmluaXQodGFyZ2V0LCBwbHVnaW4ucmF3VmFycyA/IHZhcnNbcHJvcGVydHldIDogX3Byb2Nlc3NWYXJzKHZhcnNbcHJvcGVydHldLCBpbmRleCwgdGFyZ2V0LCB0YXJnZXRzLCB0d2VlbiksIHR3ZWVuLCBpbmRleCwgdGFyZ2V0cykgIT09IGZhbHNlKSB7XG4gICAgdHdlZW4uX3B0ID0gcHQgPSBuZXcgUHJvcFR3ZWVuKHR3ZWVuLl9wdCwgdGFyZ2V0LCBwcm9wZXJ0eSwgMCwgMSwgcGx1Z2luLnJlbmRlciwgcGx1Z2luLCAwLCBwbHVnaW4ucHJpb3JpdHkpO1xuXG4gICAgaWYgKHR3ZWVuICE9PSBfcXVpY2tUd2Vlbikge1xuICAgICAgcHRMb29rdXAgPSB0d2Vlbi5fcHRMb29rdXBbdHdlZW4uX3RhcmdldHMuaW5kZXhPZih0YXJnZXQpXTsgLy9ub3RlOiB3ZSBjYW4ndCB1c2UgdHdlZW4uX3B0TG9va3VwW2luZGV4XSBiZWNhdXNlIGZvciBzdGFnZ2VyZWQgdHdlZW5zLCB0aGUgaW5kZXggZnJvbSB0aGUgZnVsbFRhcmdldHMgYXJyYXkgd29uJ3QgbWF0Y2ggd2hhdCBpdCBpcyBpbiBlYWNoIGluZGl2aWR1YWwgdHdlZW4gdGhhdCBzcGF3bnMgZnJvbSB0aGUgc3RhZ2dlci5cblxuICAgICAgaSA9IHBsdWdpbi5fcHJvcHMubGVuZ3RoO1xuXG4gICAgICB3aGlsZSAoaS0tKSB7XG4gICAgICAgIHB0TG9va3VwW3BsdWdpbi5fcHJvcHNbaV1dID0gcHQ7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHBsdWdpbjtcbn0sXG4gICAgX292ZXJ3cml0aW5nVHdlZW4sXG4gICAgLy9zdG9yZSBhIHJlZmVyZW5jZSB0ZW1wb3JhcmlseSBzbyB3ZSBjYW4gYXZvaWQgb3ZlcndyaXRpbmcgaXRzZWxmLlxuX2ZvcmNlQWxsUHJvcFR3ZWVucyxcbiAgICBfaW5pdFR3ZWVuID0gZnVuY3Rpb24gX2luaXRUd2Vlbih0d2VlbiwgdGltZSwgdFRpbWUpIHtcbiAgdmFyIHZhcnMgPSB0d2Vlbi52YXJzLFxuICAgICAgZWFzZSA9IHZhcnMuZWFzZSxcbiAgICAgIHN0YXJ0QXQgPSB2YXJzLnN0YXJ0QXQsXG4gICAgICBpbW1lZGlhdGVSZW5kZXIgPSB2YXJzLmltbWVkaWF0ZVJlbmRlcixcbiAgICAgIGxhenkgPSB2YXJzLmxhenksXG4gICAgICBvblVwZGF0ZSA9IHZhcnMub25VcGRhdGUsXG4gICAgICBydW5CYWNrd2FyZHMgPSB2YXJzLnJ1bkJhY2t3YXJkcyxcbiAgICAgIHlveW9FYXNlID0gdmFycy55b3lvRWFzZSxcbiAgICAgIGtleWZyYW1lcyA9IHZhcnMua2V5ZnJhbWVzLFxuICAgICAgYXV0b1JldmVydCA9IHZhcnMuYXV0b1JldmVydCxcbiAgICAgIGR1ciA9IHR3ZWVuLl9kdXIsXG4gICAgICBwcmV2U3RhcnRBdCA9IHR3ZWVuLl9zdGFydEF0LFxuICAgICAgdGFyZ2V0cyA9IHR3ZWVuLl90YXJnZXRzLFxuICAgICAgcGFyZW50ID0gdHdlZW4ucGFyZW50LFxuICAgICAgZnVsbFRhcmdldHMgPSBwYXJlbnQgJiYgcGFyZW50LmRhdGEgPT09IFwibmVzdGVkXCIgPyBwYXJlbnQudmFycy50YXJnZXRzIDogdGFyZ2V0cyxcbiAgICAgIGF1dG9PdmVyd3JpdGUgPSB0d2Vlbi5fb3ZlcndyaXRlID09PSBcImF1dG9cIiAmJiAhX3N1cHByZXNzT3ZlcndyaXRlcyxcbiAgICAgIHRsID0gdHdlZW4udGltZWxpbmUsXG4gICAgICByZXZlcnNlRWFzZSA9IHZhcnMuZWFzZVJldmVyc2UgfHwgeW95b0Vhc2UsXG4gICAgICBjbGVhblZhcnMsXG4gICAgICBpLFxuICAgICAgcCxcbiAgICAgIHB0LFxuICAgICAgdGFyZ2V0LFxuICAgICAgaGFzUHJpb3JpdHksXG4gICAgICBnc0RhdGEsXG4gICAgICBoYXJuZXNzLFxuICAgICAgcGx1Z2luLFxuICAgICAgcHRMb29rdXAsXG4gICAgICBpbmRleCxcbiAgICAgIGhhcm5lc3NWYXJzLFxuICAgICAgb3ZlcndyaXR0ZW47XG4gIHRsICYmICgha2V5ZnJhbWVzIHx8ICFlYXNlKSAmJiAoZWFzZSA9IFwibm9uZVwiKTtcbiAgdHdlZW4uX2Vhc2UgPSBfcGFyc2VFYXNlKGVhc2UsIF9kZWZhdWx0cy5lYXNlKTtcbiAgdHdlZW4uX3JFYXNlID0gcmV2ZXJzZUVhc2UgJiYgKF9wYXJzZUVhc2UocmV2ZXJzZUVhc2UpIHx8IHR3ZWVuLl9lYXNlKTtcbiAgdHdlZW4uX2Zyb20gPSAhdGwgJiYgISF2YXJzLnJ1bkJhY2t3YXJkczsgLy9uZXN0ZWQgdGltZWxpbmVzIHNob3VsZCBuZXZlciBydW4gYmFja3dhcmRzIC0gdGhlIGJhY2t3YXJkcy1uZXNzIGlzIGluIHRoZSBjaGlsZCB0d2VlbnMuXG5cbiAgaWYgKHR3ZWVuLl9mcm9tKSB0d2Vlbi5yYXRpbyA9IDE7XG5cbiAgaWYgKCF0bCB8fCBrZXlmcmFtZXMgJiYgIXZhcnMuc3RhZ2dlcikge1xuICAgIC8vaWYgdGhlcmUncyBhbiBpbnRlcm5hbCB0aW1lbGluZSwgc2tpcCBhbGwgdGhlIHBhcnNpbmcgYmVjYXVzZSB3ZSBwYXNzZWQgdGhhdCB0YXNrIGRvd24gdGhlIGNoYWluLlxuICAgIGhhcm5lc3MgPSB0YXJnZXRzWzBdID8gX2dldENhY2hlKHRhcmdldHNbMF0pLmhhcm5lc3MgOiAwO1xuICAgIGhhcm5lc3NWYXJzID0gaGFybmVzcyAmJiB2YXJzW2hhcm5lc3MucHJvcF07IC8vc29tZW9uZSBtYXkgbmVlZCB0byBzcGVjaWZ5IENTUy1zcGVjaWZpYyB2YWx1ZXMgQU5EIG5vbi1DU1MgdmFsdWVzLCBsaWtlIGlmIHRoZSBlbGVtZW50IGhhcyBhbiBcInhcIiBwcm9wZXJ0eSBwbHVzIGl0J3MgYSBzdGFuZGFyZCBET00gZWxlbWVudC4gV2UgYWxsb3cgcGVvcGxlIHRvIGRpc3Rpbmd1aXNoIGJ5IHdyYXBwaW5nIHBsdWdpbi1zcGVjaWZpYyBzdHVmZiBpbiBhIGNzczp7fSBvYmplY3QgZm9yIGV4YW1wbGUuXG5cbiAgICBjbGVhblZhcnMgPSBfY29weUV4Y2x1ZGluZyh2YXJzLCBfcmVzZXJ2ZWRQcm9wcyk7XG5cbiAgICBpZiAocHJldlN0YXJ0QXQpIHtcbiAgICAgIHByZXZTdGFydEF0Ll96VGltZSA8IDAgJiYgcHJldlN0YXJ0QXQucHJvZ3Jlc3MoMSk7IC8vIGluIGNhc2UgaXQncyBhIGxhenkgc3RhcnRBdCB0aGF0IGhhc24ndCByZW5kZXJlZCB5ZXQuXG5cbiAgICAgIHRpbWUgPCAwICYmIHJ1bkJhY2t3YXJkcyAmJiBpbW1lZGlhdGVSZW5kZXIgJiYgIWF1dG9SZXZlcnQgPyBwcmV2U3RhcnRBdC5yZW5kZXIoLTEsIHRydWUpIDogcHJldlN0YXJ0QXQucmV2ZXJ0KHJ1bkJhY2t3YXJkcyAmJiBkdXIgPyBfcmV2ZXJ0Q29uZmlnTm9LaWxsIDogX3N0YXJ0QXRSZXZlcnRDb25maWcpOyAvLyBpZiBpdCdzIGEgXCJzdGFydEF0XCIgKG5vdCBcImZyb20oKVwiIG9yIHJ1bkJhY2t3YXJkczogdHJ1ZSksIHdlIG9ubHkgbmVlZCB0byBkbyBhIHNoYWxsb3cgcmV2ZXJ0IChrZWVwIHRyYW5zZm9ybXMgY2FjaGVkIGluIENTU1BsdWdpbilcbiAgICAgIC8vIGRvbid0IGp1c3QgX3JlbW92ZUZyb21QYXJlbnQocHJldlN0YXJ0QXQucmVuZGVyKC0xLCB0cnVlKSkgYmVjYXVzZSB0aGF0J2xsIGxlYXZlIGlubGluZSBzdHlsZXMuIFdlJ3JlIGNyZWF0aW5nIGEgbmV3IF9zdGFydEF0IGZvciBcInN0YXJ0QXRcIiB0d2VlbnMgdGhhdCByZS1jYXB0dXJlIHRoaW5ncyB0byBlbnN1cmUgdGhhdCBpZiB0aGUgcHJlLXR3ZWVuIHZhbHVlcyBjaGFuZ2VkIHNpbmNlIHRoZSB0d2VlbiB3YXMgY3JlYXRlZCwgdGhleSdyZSByZWNvcmRlZC5cblxuICAgICAgcHJldlN0YXJ0QXQuX2xhenkgPSAwO1xuICAgIH1cblxuICAgIGlmIChzdGFydEF0KSB7XG4gICAgICBfcmVtb3ZlRnJvbVBhcmVudCh0d2Vlbi5fc3RhcnRBdCA9IFR3ZWVuLnNldCh0YXJnZXRzLCBfc2V0RGVmYXVsdHMoe1xuICAgICAgICBkYXRhOiBcImlzU3RhcnRcIixcbiAgICAgICAgb3ZlcndyaXRlOiBmYWxzZSxcbiAgICAgICAgcGFyZW50OiBwYXJlbnQsXG4gICAgICAgIGltbWVkaWF0ZVJlbmRlcjogdHJ1ZSxcbiAgICAgICAgbGF6eTogIXByZXZTdGFydEF0ICYmIF9pc05vdEZhbHNlKGxhenkpLFxuICAgICAgICBzdGFydEF0OiBudWxsLFxuICAgICAgICBkZWxheTogMCxcbiAgICAgICAgb25VcGRhdGU6IG9uVXBkYXRlICYmIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZXR1cm4gX2NhbGxiYWNrKHR3ZWVuLCBcIm9uVXBkYXRlXCIpO1xuICAgICAgICB9LFxuICAgICAgICBzdGFnZ2VyOiAwXG4gICAgICB9LCBzdGFydEF0KSkpOyAvL2NvcHkgdGhlIHByb3BlcnRpZXMvdmFsdWVzIGludG8gYSBuZXcgb2JqZWN0IHRvIGF2b2lkIGNvbGxpc2lvbnMsIGxpa2UgdmFyIHRvID0ge3g6MH0sIGZyb20gPSB7eDo1MDB9OyB0aW1lbGluZS5mcm9tVG8oZSwgZnJvbSwgdG8pLmZyb21UbyhlLCB0bywgZnJvbSk7XG5cblxuICAgICAgdHdlZW4uX3N0YXJ0QXQuX2RwID0gMDsgLy8gZG9uJ3QgYWxsb3cgaXQgdG8gZ2V0IHB1dCBiYWNrIGludG8gcm9vdCB0aW1lbGluZSEgTGlrZSB3aGVuIHJldmVydCgpIGlzIGNhbGxlZCBhbmQgdG90YWxUaW1lKCkgZ2V0cyBzZXQuXG5cbiAgICAgIHR3ZWVuLl9zdGFydEF0Ll9zYXQgPSB0d2VlbjsgLy8gdXNlZCBpbiBnbG9iYWxUaW1lKCkuIF9zYXQgc3RhbmRzIGZvciBfc3RhcnRBdFR3ZWVuXG5cbiAgICAgIHRpbWUgPCAwICYmIChfcmV2ZXJ0aW5nIHx8ICFpbW1lZGlhdGVSZW5kZXIgJiYgIWF1dG9SZXZlcnQpICYmIHR3ZWVuLl9zdGFydEF0LnJldmVydChfcmV2ZXJ0Q29uZmlnTm9LaWxsKTsgLy8gcmFyZSBlZGdlIGNhc2UsIGxpa2UgaWYgYSByZW5kZXIgaXMgZm9yY2VkIGluIHRoZSBuZWdhdGl2ZSBkaXJlY3Rpb24gb2YgYSBub24taW5pdHRlZCB0d2Vlbi5cblxuICAgICAgaWYgKGltbWVkaWF0ZVJlbmRlcikge1xuICAgICAgICBpZiAoZHVyICYmIHRpbWUgPD0gMCAmJiB0VGltZSA8PSAwKSB7XG4gICAgICAgICAgLy8gY2hlY2sgdFRpbWUgaGVyZSBiZWNhdXNlIGluIHRoZSBjYXNlIG9mIGEgeW95byB0d2VlbiB3aG9zZSBwbGF5aGVhZCBnZXRzIHB1c2hlZCB0byB0aGUgZW5kIGxpa2UgdHdlZW4ucHJvZ3Jlc3MoMSksIHdlIHNob3VsZCBhbGxvdyBpdCB0aHJvdWdoIHNvIHRoYXQgdGhlIG9uQ29tcGxldGUgZ2V0cyBmaXJlZCBwcm9wZXJseS5cbiAgICAgICAgICB0aW1lICYmICh0d2Vlbi5felRpbWUgPSB0aW1lKTtcbiAgICAgICAgICByZXR1cm47IC8vd2Ugc2tpcCBpbml0aWFsaXphdGlvbiBoZXJlIHNvIHRoYXQgb3ZlcndyaXRpbmcgZG9lc24ndCBvY2N1ciB1bnRpbCB0aGUgdHdlZW4gYWN0dWFsbHkgYmVnaW5zLiBPdGhlcndpc2UsIGlmIHlvdSBjcmVhdGUgc2V2ZXJhbCBpbW1lZGlhdGVSZW5kZXI6dHJ1ZSB0d2VlbnMgb2YgdGhlIHNhbWUgdGFyZ2V0L3Byb3BlcnRpZXMgdG8gZHJvcCBpbnRvIGEgVGltZWxpbmUsIHRoZSBsYXN0IG9uZSBjcmVhdGVkIHdvdWxkIG92ZXJ3cml0ZSB0aGUgZmlyc3Qgb25lcyBiZWNhdXNlIHRoZXkgZGlkbid0IGdldCBwbGFjZWQgaW50byB0aGUgdGltZWxpbmUgeWV0IGJlZm9yZSB0aGUgZmlyc3QgcmVuZGVyIG9jY3VycyBhbmQga2lja3MgaW4gb3ZlcndyaXRpbmcuXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHJ1bkJhY2t3YXJkcyAmJiBkdXIpIHtcbiAgICAgIC8vIGZyb20oKSB0d2VlbnMgbXVzdCBiZSBoYW5kbGVkIHVuaXF1ZWx5OiB0aGVpciBiZWdpbm5pbmcgdmFsdWVzIG11c3QgYmUgcmVuZGVyZWQgYnV0IHdlIGRvbid0IHdhbnQgb3ZlcndyaXRpbmcgdG8gb2NjdXIgeWV0ICh3aGVuIHRpbWUgaXMgc3RpbGwgMCkuIFdhaXQgdW50aWwgdGhlIHR3ZWVuIGFjdHVhbGx5IGJlZ2lucyBiZWZvcmUgZG9pbmcgYWxsIHRoZSByb3V0aW5lcyBsaWtlIG92ZXJ3cml0aW5nLiBBdCB0aGF0IHRpbWUsIHdlIHNob3VsZCByZW5kZXIgYXQgdGhlIEVORCBvZiB0aGUgdHdlZW4gdG8gZW5zdXJlIHRoYXQgdGhpbmdzIGluaXRpYWxpemUgY29ycmVjdGx5IChyZW1lbWJlciwgZnJvbSgpIHR3ZWVucyBnbyBiYWNrd2FyZHMpXG4gICAgICBpZiAoIXByZXZTdGFydEF0KSB7XG4gICAgICAgIHRpbWUgJiYgKGltbWVkaWF0ZVJlbmRlciA9IGZhbHNlKTsgLy9pbiByYXJlIGNhc2VzIChsaWtlIGlmIGEgZnJvbSgpIHR3ZWVuIHJ1bnMgYW5kIHRoZW4gaXMgaW52YWxpZGF0ZSgpLWVkKSwgaW1tZWRpYXRlUmVuZGVyIGNvdWxkIGJlIHRydWUgYnV0IHRoZSBpbml0aWFsIGZvcmNlZC1yZW5kZXIgZ2V0cyBza2lwcGVkLCBzbyB0aGVyZSdzIG5vIG5lZWQgdG8gZm9yY2UgdGhlIHJlbmRlciBpbiB0aGlzIGNvbnRleHQgd2hlbiB0aGUgX3RpbWUgaXMgZ3JlYXRlciB0aGFuIDBcblxuICAgICAgICBwID0gX3NldERlZmF1bHRzKHtcbiAgICAgICAgICBvdmVyd3JpdGU6IGZhbHNlLFxuICAgICAgICAgIGRhdGE6IFwiaXNGcm9tU3RhcnRcIixcbiAgICAgICAgICAvL3dlIHRhZyB0aGUgdHdlZW4gd2l0aCBhcyBcImlzRnJvbVN0YXJ0XCIgc28gdGhhdCBpZiBbaW5zaWRlIGEgcGx1Z2luXSB3ZSBuZWVkIHRvIG9ubHkgZG8gc29tZXRoaW5nIGF0IHRoZSB2ZXJ5IEVORCBvZiBhIHR3ZWVuLCB3ZSBoYXZlIGEgd2F5IG9mIGlkZW50aWZ5aW5nIHRoaXMgdHdlZW4gYXMgbWVyZWx5IHRoZSBvbmUgdGhhdCdzIHNldHRpbmcgdGhlIGJlZ2lubmluZyB2YWx1ZXMgZm9yIGEgXCJmcm9tKClcIiB0d2Vlbi4gRm9yIGV4YW1wbGUsIGNsZWFyUHJvcHMgaW4gQ1NTUGx1Z2luIHNob3VsZCBvbmx5IGdldCBhcHBsaWVkIGF0IHRoZSB2ZXJ5IEVORCBvZiBhIHR3ZWVuIGFuZCB3aXRob3V0IHRoaXMgdGFnLCBmcm9tKC4uLntoZWlnaHQ6MTAwLCBjbGVhclByb3BzOlwiaGVpZ2h0XCIsIGRlbGF5OjF9KSB3b3VsZCB3aXBlIHRoZSBoZWlnaHQgYXQgdGhlIGJlZ2lubmluZyBvZiB0aGUgdHdlZW4gYW5kIGFmdGVyIDEgc2Vjb25kLCBpdCdkIGtpY2sgYmFjayBpbi5cbiAgICAgICAgICBsYXp5OiBpbW1lZGlhdGVSZW5kZXIgJiYgIXByZXZTdGFydEF0ICYmIF9pc05vdEZhbHNlKGxhenkpLFxuICAgICAgICAgIGltbWVkaWF0ZVJlbmRlcjogaW1tZWRpYXRlUmVuZGVyLFxuICAgICAgICAgIC8vemVyby1kdXJhdGlvbiB0d2VlbnMgcmVuZGVyIGltbWVkaWF0ZWx5IGJ5IGRlZmF1bHQsIGJ1dCBpZiB3ZSdyZSBub3Qgc3BlY2lmaWNhbGx5IGluc3RydWN0ZWQgdG8gcmVuZGVyIHRoaXMgdHdlZW4gaW1tZWRpYXRlbHksIHdlIHNob3VsZCBza2lwIHRoaXMgYW5kIG1lcmVseSBfaW5pdCgpIHRvIHJlY29yZCB0aGUgc3RhcnRpbmcgdmFsdWVzIChyZW5kZXJpbmcgdGhlbSBpbW1lZGlhdGVseSB3b3VsZCBwdXNoIHRoZW0gdG8gY29tcGxldGlvbiB3aGljaCBpcyB3YXN0ZWZ1bCBpbiB0aGF0IGNhc2UgLSB3ZSdkIGhhdmUgdG8gcmVuZGVyKC0xKSBpbW1lZGlhdGVseSBhZnRlcilcbiAgICAgICAgICBzdGFnZ2VyOiAwLFxuICAgICAgICAgIHBhcmVudDogcGFyZW50IC8vZW5zdXJlcyB0aGF0IG5lc3RlZCB0d2VlbnMgdGhhdCBoYWQgYSBzdGFnZ2VyIGFyZSBoYW5kbGVkIHByb3Blcmx5LCBsaWtlIGdzYXAuZnJvbShcIi5jbGFzc1wiLCB7eTogZ3NhcC51dGlscy53cmFwKFstMTAwLDEwMF0pLCBzdGFnZ2VyOiAwLjV9KVxuXG4gICAgICAgIH0sIGNsZWFuVmFycyk7XG4gICAgICAgIGhhcm5lc3NWYXJzICYmIChwW2hhcm5lc3MucHJvcF0gPSBoYXJuZXNzVmFycyk7IC8vIGluIGNhc2Ugc29tZW9uZSBkb2VzIHNvbWV0aGluZyBsaWtlIC5mcm9tKC4uLiwge2Nzczp7fX0pXG5cbiAgICAgICAgX3JlbW92ZUZyb21QYXJlbnQodHdlZW4uX3N0YXJ0QXQgPSBUd2Vlbi5zZXQodGFyZ2V0cywgcCkpO1xuXG4gICAgICAgIHR3ZWVuLl9zdGFydEF0Ll9kcCA9IDA7IC8vIGRvbid0IGFsbG93IGl0IHRvIGdldCBwdXQgYmFjayBpbnRvIHJvb3QgdGltZWxpbmUhXG5cbiAgICAgICAgdHdlZW4uX3N0YXJ0QXQuX3NhdCA9IHR3ZWVuOyAvLyB1c2VkIGluIGdsb2JhbFRpbWUoKVxuXG4gICAgICAgIHRpbWUgPCAwICYmIChfcmV2ZXJ0aW5nID8gdHdlZW4uX3N0YXJ0QXQucmV2ZXJ0KF9yZXZlcnRDb25maWdOb0tpbGwpIDogdHdlZW4uX3N0YXJ0QXQucmVuZGVyKC0xLCB0cnVlKSk7XG4gICAgICAgIHR3ZWVuLl96VGltZSA9IHRpbWU7XG5cbiAgICAgICAgaWYgKCFpbW1lZGlhdGVSZW5kZXIpIHtcbiAgICAgICAgICBfaW5pdFR3ZWVuKHR3ZWVuLl9zdGFydEF0LCBfdGlueU51bSwgX3RpbnlOdW0pOyAvL2Vuc3VyZXMgdGhhdCB0aGUgaW5pdGlhbCB2YWx1ZXMgYXJlIHJlY29yZGVkXG5cbiAgICAgICAgfSBlbHNlIGlmICghdGltZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHR3ZWVuLl9wdCA9IHR3ZWVuLl9wdENhY2hlID0gMDtcbiAgICBsYXp5ID0gZHVyICYmIF9pc05vdEZhbHNlKGxhenkpIHx8IGxhenkgJiYgIWR1cjtcblxuICAgIGZvciAoaSA9IDA7IGkgPCB0YXJnZXRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB0YXJnZXQgPSB0YXJnZXRzW2ldO1xuICAgICAgZ3NEYXRhID0gdGFyZ2V0Ll9nc2FwIHx8IF9oYXJuZXNzKHRhcmdldHMpW2ldLl9nc2FwO1xuICAgICAgdHdlZW4uX3B0TG9va3VwW2ldID0gcHRMb29rdXAgPSB7fTtcbiAgICAgIF9sYXp5TG9va3VwW2dzRGF0YS5pZF0gJiYgX2xhenlUd2VlbnMubGVuZ3RoICYmIF9sYXp5UmVuZGVyKCk7IC8vaWYgb3RoZXIgdHdlZW5zIG9mIHRoZSBzYW1lIHRhcmdldCBoYXZlIHJlY2VudGx5IGluaXR0ZWQgYnV0IGhhdmVuJ3QgcmVuZGVyZWQgeWV0LCB3ZSd2ZSBnb3QgdG8gZm9yY2UgdGhlIHJlbmRlciBzbyB0aGF0IHRoZSBzdGFydGluZyB2YWx1ZXMgYXJlIGNvcnJlY3QgKGltYWdpbmUgcG9wdWxhdGluZyBhIHRpbWVsaW5lIHdpdGggYSBidW5jaCBvZiBzZXF1ZW50aWFsIHR3ZWVucyBhbmQgdGhlbiBqdW1waW5nIHRvIHRoZSBlbmQpXG5cbiAgICAgIGluZGV4ID0gZnVsbFRhcmdldHMgPT09IHRhcmdldHMgPyBpIDogZnVsbFRhcmdldHMuaW5kZXhPZih0YXJnZXQpO1xuXG4gICAgICBpZiAoaGFybmVzcyAmJiAocGx1Z2luID0gbmV3IGhhcm5lc3MoKSkuaW5pdCh0YXJnZXQsIGhhcm5lc3NWYXJzIHx8IGNsZWFuVmFycywgdHdlZW4sIGluZGV4LCBmdWxsVGFyZ2V0cykgIT09IGZhbHNlKSB7XG4gICAgICAgIHR3ZWVuLl9wdCA9IHB0ID0gbmV3IFByb3BUd2Vlbih0d2Vlbi5fcHQsIHRhcmdldCwgcGx1Z2luLm5hbWUsIDAsIDEsIHBsdWdpbi5yZW5kZXIsIHBsdWdpbiwgMCwgcGx1Z2luLnByaW9yaXR5KTtcblxuICAgICAgICBwbHVnaW4uX3Byb3BzLmZvckVhY2goZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgICAgICBwdExvb2t1cFtuYW1lXSA9IHB0O1xuICAgICAgICB9KTtcblxuICAgICAgICBwbHVnaW4ucHJpb3JpdHkgJiYgKGhhc1ByaW9yaXR5ID0gMSk7XG4gICAgICB9XG5cbiAgICAgIGlmICghaGFybmVzcyB8fCBoYXJuZXNzVmFycykge1xuICAgICAgICBmb3IgKHAgaW4gY2xlYW5WYXJzKSB7XG4gICAgICAgICAgaWYgKF9wbHVnaW5zW3BdICYmIChwbHVnaW4gPSBfY2hlY2tQbHVnaW4ocCwgY2xlYW5WYXJzLCB0d2VlbiwgaW5kZXgsIHRhcmdldCwgZnVsbFRhcmdldHMpKSkge1xuICAgICAgICAgICAgcGx1Z2luLnByaW9yaXR5ICYmIChoYXNQcmlvcml0eSA9IDEpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBwdExvb2t1cFtwXSA9IHB0ID0gX2FkZFByb3BUd2Vlbi5jYWxsKHR3ZWVuLCB0YXJnZXQsIHAsIFwiZ2V0XCIsIGNsZWFuVmFyc1twXSwgaW5kZXgsIGZ1bGxUYXJnZXRzLCAwLCB2YXJzLnN0cmluZ0ZpbHRlcik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHR3ZWVuLl9vcCAmJiB0d2Vlbi5fb3BbaV0gJiYgdHdlZW4ua2lsbCh0YXJnZXQsIHR3ZWVuLl9vcFtpXSk7XG5cbiAgICAgIGlmIChhdXRvT3ZlcndyaXRlICYmIHR3ZWVuLl9wdCkge1xuICAgICAgICBfb3ZlcndyaXRpbmdUd2VlbiA9IHR3ZWVuO1xuXG4gICAgICAgIF9nbG9iYWxUaW1lbGluZS5raWxsVHdlZW5zT2YodGFyZ2V0LCBwdExvb2t1cCwgdHdlZW4uZ2xvYmFsVGltZSh0aW1lKSk7IC8vIG1ha2Ugc3VyZSB0aGUgb3ZlcndyaXRpbmcgZG9lc24ndCBvdmVyd3JpdGUgVEhJUyB0d2VlbiEhIVxuXG5cbiAgICAgICAgb3ZlcndyaXR0ZW4gPSAhdHdlZW4ucGFyZW50O1xuICAgICAgICBfb3ZlcndyaXRpbmdUd2VlbiA9IDA7XG4gICAgICB9XG5cbiAgICAgIHR3ZWVuLl9wdCAmJiBsYXp5ICYmIChfbGF6eUxvb2t1cFtnc0RhdGEuaWRdID0gMSk7XG4gICAgfVxuXG4gICAgaGFzUHJpb3JpdHkgJiYgX3NvcnRQcm9wVHdlZW5zQnlQcmlvcml0eSh0d2Vlbik7XG4gICAgdHdlZW4uX29uSW5pdCAmJiB0d2Vlbi5fb25Jbml0KHR3ZWVuKTsgLy9wbHVnaW5zIGxpa2UgUm91bmRQcm9wcyBtdXN0IHdhaXQgdW50aWwgQUxMIG9mIHRoZSBQcm9wVHdlZW5zIGFyZSBpbnN0YW50aWF0ZWQuIEluIHRoZSBwbHVnaW4ncyBpbml0KCkgZnVuY3Rpb24sIGl0IHNldHMgdGhlIF9vbkluaXQgb24gdGhlIHR3ZWVuIGluc3RhbmNlLiBNYXkgbm90IGJlIHByZXR0eS9pbnR1aXRpdmUsIGJ1dCBpdCdzIGZhc3QgYW5kIGtlZXBzIGZpbGUgc2l6ZSBkb3duLlxuICB9XG5cbiAgdHdlZW4uX29uVXBkYXRlID0gb25VcGRhdGU7XG4gIHR3ZWVuLl9pbml0dGVkID0gKCF0d2Vlbi5fb3AgfHwgdHdlZW4uX3B0KSAmJiAhb3ZlcndyaXR0ZW47IC8vIGlmIG92ZXJ3cml0dGVuUHJvcHMgcmVzdWx0ZWQgaW4gdGhlIGVudGlyZSB0d2VlbiBiZWluZyBraWxsZWQsIGRvIE5PVCBmbGFnIGl0IGFzIGluaXR0ZWQgb3IgZWxzZSBpdCBtYXkgcmVuZGVyIGZvciBvbmUgdGljay5cblxuICBrZXlmcmFtZXMgJiYgdGltZSA8PSAwICYmIHRsLnJlbmRlcihfYmlnTnVtLCB0cnVlLCB0cnVlKTsgLy8gaWYgdGhlcmUncyBhIDAlIGtleWZyYW1lLCBpdCdsbCByZW5kZXIgaW4gdGhlIFwiYmVmb3JlXCIgc3RhdGUgZm9yIGFueSBzdGFnZ2VyZWQvZGVsYXllZCBhbmltYXRpb25zIHRodXMgd2hlbiB0aGUgZm9sbG93aW5nIHR3ZWVuIGluaXRpYWxpemVzLCBpdCdsbCB1c2UgdGhlIFwiYmVmb3JlXCIgc3RhdGUgaW5zdGVhZCBvZiB0aGUgXCJhZnRlclwiIHN0YXRlIGFzIHRoZSBpbml0aWFsIHZhbHVlcy5cbn0sXG4gICAgX3VwZGF0ZVByb3BUd2VlbnMgPSBmdW5jdGlvbiBfdXBkYXRlUHJvcFR3ZWVucyh0d2VlbiwgcHJvcGVydHksIHZhbHVlLCBzdGFydCwgc3RhcnRJc1JlbGF0aXZlLCByYXRpbywgdGltZSwgc2tpcFJlY3Vyc2lvbikge1xuICB2YXIgcHRDYWNoZSA9ICh0d2Vlbi5fcHQgJiYgdHdlZW4uX3B0Q2FjaGUgfHwgKHR3ZWVuLl9wdENhY2hlID0ge30pKVtwcm9wZXJ0eV0sXG4gICAgICBwdCxcbiAgICAgIHJvb3RQVCxcbiAgICAgIGxvb2t1cCxcbiAgICAgIGk7XG5cbiAgaWYgKCFwdENhY2hlKSB7XG4gICAgcHRDYWNoZSA9IHR3ZWVuLl9wdENhY2hlW3Byb3BlcnR5XSA9IFtdO1xuICAgIGxvb2t1cCA9IHR3ZWVuLl9wdExvb2t1cDtcbiAgICBpID0gdHdlZW4uX3RhcmdldHMubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGktLSkge1xuICAgICAgcHQgPSBsb29rdXBbaV1bcHJvcGVydHldO1xuXG4gICAgICBpZiAocHQgJiYgcHQuZCAmJiBwdC5kLl9wdCkge1xuICAgICAgICAvLyBpdCdzIGEgcGx1Z2luLCBzbyBmaW5kIHRoZSBuZXN0ZWQgUHJvcFR3ZWVuXG4gICAgICAgIHB0ID0gcHQuZC5fcHQ7XG5cbiAgICAgICAgd2hpbGUgKHB0ICYmIHB0LnAgIT09IHByb3BlcnR5ICYmIHB0LmZwICE9PSBwcm9wZXJ0eSkge1xuICAgICAgICAgIC8vIFwiZnBcIiBpcyBmdW5jdGlvblBhcmFtIGZvciB0aGluZ3MgbGlrZSBzZXR0aW5nIENTUyB2YXJpYWJsZXMgd2hpY2ggcmVxdWlyZSAuc2V0UHJvcGVydHkoXCItLXZhci1uYW1lXCIsIHZhbHVlKVxuICAgICAgICAgIHB0ID0gcHQuX25leHQ7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKCFwdCkge1xuICAgICAgICAvLyB0aGVyZSBpcyBubyBQcm9wVHdlZW4gYXNzb2NpYXRlZCB3aXRoIHRoYXQgcHJvcGVydHksIHNvIHdlIG11c3QgRk9SQ0Ugb25lIHRvIGJlIGNyZWF0ZWQgYW5kIGRpdGNoIG91dCBvZiB0aGlzXG4gICAgICAgIC8vIGlmIHRoZSB0d2VlbiBoYXMgb3RoZXIgcHJvcGVydGllcyB0aGF0IGFscmVhZHkgcmVuZGVyZWQgYXQgbmV3IHBvc2l0aW9ucywgd2UnZCBub3JtYWxseSBoYXZlIHRvIHJld2luZCB0byBwdXQgdGhlbSBiYWNrIGxpa2UgdHdlZW4ucmVuZGVyKDAsIHRydWUpIGJlZm9yZSBmb3JjaW5nIGFuIF9pbml0VHdlZW4oKSwgYnV0IHRoYXQgY2FuIGNyZWF0ZSBhbm90aGVyIGVkZ2UgY2FzZSBsaWtlIHR3ZWVuaW5nIGEgdGltZWxpbmUncyBwcm9ncmVzcyB3b3VsZCB0cmlnZ2VyIG9uVXBkYXRlcyB0byBmaXJlIHdoaWNoIGNvdWxkIG1vdmUgb3RoZXIgdGhpbmdzIGFyb3VuZC4gSXQncyBiZXR0ZXIgdG8ganVzdCBpbmZvcm0gdXNlcnMgdGhhdCAucmVzZXRUbygpIHNob3VsZCBPTkxZIGJlIHVzZWQgZm9yIHR3ZWVucyB0aGF0IGFscmVhZHkgaGF2ZSB0aGF0IHByb3BlcnR5LiBGb3IgZXhhbXBsZSwgeW91IGNhbid0IGdzYXAudG8oLi4ueyB5OiAwIH0pIGFuZCB0aGVuIHR3ZWVuLnJlc3RUbyhcInhcIiwgMjAwKSBmb3IgZXhhbXBsZS5cbiAgICAgICAgX2ZvcmNlQWxsUHJvcFR3ZWVucyA9IDE7IC8vIG90aGVyd2lzZSwgd2hlbiB3ZSBfYWRkUHJvcFR3ZWVuKCkgYW5kIGl0IGZpbmRzIG5vIGNoYW5nZSBiZXR3ZWVuIHRoZSBzdGFydCBhbmQgZW5kIHZhbHVlcywgaXQgc2tpcHMgY3JlYXRpbmcgYSBQcm9wVHdlZW4gKGZvciBlZmZpY2llbmN5Li4ud2h5IHR3ZWVuIHdoZW4gdGhlcmUncyBubyBkaWZmZXJlbmNlPykgYnV0IGluIHRoaXMgY2FzZSB3ZSBORUVEIHRoYXQgUHJvcFR3ZWVuIGNyZWF0ZWQgc28gd2UgY2FuIGVkaXQgaXQuXG5cbiAgICAgICAgdHdlZW4udmFyc1twcm9wZXJ0eV0gPSBcIis9MFwiO1xuXG4gICAgICAgIF9pbml0VHdlZW4odHdlZW4sIHRpbWUpO1xuXG4gICAgICAgIF9mb3JjZUFsbFByb3BUd2VlbnMgPSAwO1xuICAgICAgICByZXR1cm4gc2tpcFJlY3Vyc2lvbiA/IF93YXJuKHByb3BlcnR5ICsgXCIgbm90IGVsaWdpYmxlIGZvciByZXNldC4gVHJ5IHNwbGl0dGluZyBpbnRvIGluZGl2aWR1YWwgcHJvcGVydGllc1wiKSA6IDE7IC8vIGlmIHNvbWVvbmUgdHJpZXMgdG8gZG8gYSBxdWlja1RvKCkgb24gYSBzcGVjaWFsIHByb3BlcnR5IGxpa2UgYm9yZGVyUmFkaXVzIHdoaWNoIG11c3QgZ2V0IHNwbGl0IGludG8gNCBkaWZmZXJlbnQgcHJvcGVydGllcywgdGhhdCdzIG5vdCBlbGlnaWJsZSBmb3IgLnJlc2V0VG8oKS5cbiAgICAgIH1cblxuICAgICAgcHRDYWNoZS5wdXNoKHB0KTtcbiAgICB9XG4gIH1cblxuICBpID0gcHRDYWNoZS5sZW5ndGg7XG5cbiAgd2hpbGUgKGktLSkge1xuICAgIHJvb3RQVCA9IHB0Q2FjaGVbaV07XG4gICAgcHQgPSByb290UFQuX3B0IHx8IHJvb3RQVDsgLy8gY29tcGxleCB2YWx1ZXMgbWF5IGhhdmUgbmVzdGVkIFByb3BUd2VlbnMuIFdlIG9ubHkgYWNjb21tb2RhdGUgdGhlIEZJUlNUIHZhbHVlLlxuXG4gICAgcHQucyA9IChzdGFydCB8fCBzdGFydCA9PT0gMCkgJiYgIXN0YXJ0SXNSZWxhdGl2ZSA/IHN0YXJ0IDogcHQucyArIChzdGFydCB8fCAwKSArIHJhdGlvICogcHQuYztcbiAgICBwdC5jID0gdmFsdWUgLSBwdC5zO1xuICAgIHJvb3RQVC5lICYmIChyb290UFQuZSA9IF9yb3VuZCh2YWx1ZSkgKyBnZXRVbml0KHJvb3RQVC5lKSk7IC8vIG1haW5seSBmb3IgQ1NTUGx1Z2luIChlbmQgdmFsdWUpXG5cbiAgICByb290UFQuYiAmJiAocm9vdFBULmIgPSBwdC5zICsgZ2V0VW5pdChyb290UFQuYikpOyAvLyAoYmVnaW5uaW5nIHZhbHVlKVxuICB9XG59LFxuICAgIF9hZGRBbGlhc2VzVG9WYXJzID0gZnVuY3Rpb24gX2FkZEFsaWFzZXNUb1ZhcnModGFyZ2V0cywgdmFycykge1xuICB2YXIgaGFybmVzcyA9IHRhcmdldHNbMF0gPyBfZ2V0Q2FjaGUodGFyZ2V0c1swXSkuaGFybmVzcyA6IDAsXG4gICAgICBwcm9wZXJ0eUFsaWFzZXMgPSBoYXJuZXNzICYmIGhhcm5lc3MuYWxpYXNlcyxcbiAgICAgIGNvcHksXG4gICAgICBwLFxuICAgICAgaSxcbiAgICAgIGFsaWFzZXM7XG5cbiAgaWYgKCFwcm9wZXJ0eUFsaWFzZXMpIHtcbiAgICByZXR1cm4gdmFycztcbiAgfVxuXG4gIGNvcHkgPSBfbWVyZ2Uoe30sIHZhcnMpO1xuXG4gIGZvciAocCBpbiBwcm9wZXJ0eUFsaWFzZXMpIHtcbiAgICBpZiAocCBpbiBjb3B5KSB7XG4gICAgICBhbGlhc2VzID0gcHJvcGVydHlBbGlhc2VzW3BdLnNwbGl0KFwiLFwiKTtcbiAgICAgIGkgPSBhbGlhc2VzLmxlbmd0aDtcblxuICAgICAgd2hpbGUgKGktLSkge1xuICAgICAgICBjb3B5W2FsaWFzZXNbaV1dID0gY29weVtwXTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gY29weTtcbn0sXG4gICAgLy8gcGFyc2VzIG11bHRpcGxlIGZvcm1hdHMsIGxpa2Uge1wiMCVcIjoge3g6IDEwMH0sIHtcIjUwJVwiOiB7eDogLTIwfX0gYW5kIHsgeDoge1wiMCVcIjogMTAwLCBcIjUwJVwiOiAtMjB9IH0sIGFuZCBhbiBcImVhc2VcIiBjYW4gYmUgc2V0IG9uIGFueSBvYmplY3QuIFdlIHBvcHVsYXRlIGFuIFwiYWxsUHJvcHNcIiBvYmplY3Qgd2l0aCBhbiBBcnJheSBmb3IgZWFjaCBwcm9wZXJ0eSwgbGlrZSB7eDogW3t9LCB7fV0sIHk6W3t9LCB7fV19IHdpdGggZGF0YSBmb3IgZWFjaCBwcm9wZXJ0eSB0d2Vlbi4gVGhlIG9iamVjdHMgaGF2ZSBhIFwidFwiICh0aW1lKSwgXCJ2XCIsICh2YWx1ZSksIGFuZCBcImVcIiAoZWFzZSkgcHJvcGVydHkuIFRoaXMgYWxsb3dzIHVzIHRvIHBpZWNlIHRvZ2V0aGVyIGEgdGltZWxpbmUgbGF0ZXIuXG5fcGFyc2VLZXlmcmFtZSA9IGZ1bmN0aW9uIF9wYXJzZUtleWZyYW1lKHByb3AsIG9iaiwgYWxsUHJvcHMsIGVhc2VFYWNoKSB7XG4gIHZhciBlYXNlID0gb2JqLmVhc2UgfHwgZWFzZUVhY2ggfHwgXCJwb3dlcjEuaW5PdXRcIixcbiAgICAgIHAsXG4gICAgICBhO1xuXG4gIGlmIChfaXNBcnJheShvYmopKSB7XG4gICAgYSA9IGFsbFByb3BzW3Byb3BdIHx8IChhbGxQcm9wc1twcm9wXSA9IFtdKTsgLy8gdCA9IHRpbWUgKG91dCBvZiAxMDApLCB2ID0gdmFsdWUsIGUgPSBlYXNlXG5cbiAgICBvYmouZm9yRWFjaChmdW5jdGlvbiAodmFsdWUsIGkpIHtcbiAgICAgIHJldHVybiBhLnB1c2goe1xuICAgICAgICB0OiBpIC8gKG9iai5sZW5ndGggLSAxKSAqIDEwMCxcbiAgICAgICAgdjogdmFsdWUsXG4gICAgICAgIGU6IGVhc2VcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGZvciAocCBpbiBvYmopIHtcbiAgICAgIGEgPSBhbGxQcm9wc1twXSB8fCAoYWxsUHJvcHNbcF0gPSBbXSk7XG4gICAgICBwID09PSBcImVhc2VcIiB8fCBhLnB1c2goe1xuICAgICAgICB0OiBwYXJzZUZsb2F0KHByb3ApLFxuICAgICAgICB2OiBvYmpbcF0sXG4gICAgICAgIGU6IGVhc2VcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxufSxcbiAgICBfcGFyc2VGdW5jT3JTdHJpbmcgPSBmdW5jdGlvbiBfcGFyc2VGdW5jT3JTdHJpbmcodmFsdWUsIHR3ZWVuLCBpLCB0YXJnZXQsIHRhcmdldHMpIHtcbiAgcmV0dXJuIF9pc0Z1bmN0aW9uKHZhbHVlKSA/IHZhbHVlLmNhbGwodHdlZW4sIGksIHRhcmdldCwgdGFyZ2V0cykgOiBfaXNTdHJpbmcodmFsdWUpICYmIH52YWx1ZS5pbmRleE9mKFwicmFuZG9tKFwiKSA/IF9yZXBsYWNlUmFuZG9tKHZhbHVlKSA6IHZhbHVlO1xufSxcbiAgICBfc3RhZ2dlclR3ZWVuUHJvcHMgPSBfY2FsbGJhY2tOYW1lcyArIFwicmVwZWF0LHJlcGVhdERlbGF5LHlveW8scmVwZWF0UmVmcmVzaCx5b3lvRWFzZSxlYXNlUmV2ZXJzZSxhdXRvUmV2ZXJ0XCIsXG4gICAgX3N0YWdnZXJQcm9wc1RvU2tpcCA9IHt9O1xuXG5fZm9yRWFjaE5hbWUoX3N0YWdnZXJUd2VlblByb3BzICsgXCIsaWQsc3RhZ2dlcixkZWxheSxkdXJhdGlvbixwYXVzZWQsc2Nyb2xsVHJpZ2dlclwiLCBmdW5jdGlvbiAobmFtZSkge1xuICByZXR1cm4gX3N0YWdnZXJQcm9wc1RvU2tpcFtuYW1lXSA9IDE7XG59KTtcbi8qXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogVFdFRU5cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKi9cblxuXG5leHBvcnQgdmFyIFR3ZWVuID0gLyojX19QVVJFX18qL2Z1bmN0aW9uIChfQW5pbWF0aW9uMikge1xuICBfaW5oZXJpdHNMb29zZShUd2VlbiwgX0FuaW1hdGlvbjIpO1xuXG4gIGZ1bmN0aW9uIFR3ZWVuKHRhcmdldHMsIHZhcnMsIHBvc2l0aW9uLCBza2lwSW5oZXJpdCkge1xuICAgIHZhciBfdGhpczM7XG5cbiAgICBpZiAodHlwZW9mIHZhcnMgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgIHBvc2l0aW9uLmR1cmF0aW9uID0gdmFycztcbiAgICAgIHZhcnMgPSBwb3NpdGlvbjtcbiAgICAgIHBvc2l0aW9uID0gbnVsbDtcbiAgICB9XG5cbiAgICBfdGhpczMgPSBfQW5pbWF0aW9uMi5jYWxsKHRoaXMsIHNraXBJbmhlcml0ID8gdmFycyA6IF9pbmhlcml0RGVmYXVsdHModmFycykpIHx8IHRoaXM7XG4gICAgdmFyIF90aGlzMyR2YXJzID0gX3RoaXMzLnZhcnMsXG4gICAgICAgIGR1cmF0aW9uID0gX3RoaXMzJHZhcnMuZHVyYXRpb24sXG4gICAgICAgIGRlbGF5ID0gX3RoaXMzJHZhcnMuZGVsYXksXG4gICAgICAgIGltbWVkaWF0ZVJlbmRlciA9IF90aGlzMyR2YXJzLmltbWVkaWF0ZVJlbmRlcixcbiAgICAgICAgc3RhZ2dlciA9IF90aGlzMyR2YXJzLnN0YWdnZXIsXG4gICAgICAgIG92ZXJ3cml0ZSA9IF90aGlzMyR2YXJzLm92ZXJ3cml0ZSxcbiAgICAgICAga2V5ZnJhbWVzID0gX3RoaXMzJHZhcnMua2V5ZnJhbWVzLFxuICAgICAgICBkZWZhdWx0cyA9IF90aGlzMyR2YXJzLmRlZmF1bHRzLFxuICAgICAgICBzY3JvbGxUcmlnZ2VyID0gX3RoaXMzJHZhcnMuc2Nyb2xsVHJpZ2dlcixcbiAgICAgICAgcGFyZW50ID0gdmFycy5wYXJlbnQgfHwgX2dsb2JhbFRpbWVsaW5lLFxuICAgICAgICBwYXJzZWRUYXJnZXRzID0gKF9pc0FycmF5KHRhcmdldHMpIHx8IF9pc1R5cGVkQXJyYXkodGFyZ2V0cykgPyBfaXNOdW1iZXIodGFyZ2V0c1swXSkgOiBcImxlbmd0aFwiIGluIHZhcnMpID8gW3RhcmdldHNdIDogdG9BcnJheSh0YXJnZXRzKSxcbiAgICAgICAgdGwsXG4gICAgICAgIGksXG4gICAgICAgIGNvcHksXG4gICAgICAgIGwsXG4gICAgICAgIHAsXG4gICAgICAgIGN1clRhcmdldCxcbiAgICAgICAgc3RhZ2dlckZ1bmMsXG4gICAgICAgIHN0YWdnZXJWYXJzVG9NZXJnZTtcbiAgICBfdGhpczMuX3RhcmdldHMgPSBwYXJzZWRUYXJnZXRzLmxlbmd0aCA/IF9oYXJuZXNzKHBhcnNlZFRhcmdldHMpIDogX3dhcm4oXCJHU0FQIHRhcmdldCBcIiArIHRhcmdldHMgKyBcIiBub3QgZm91bmQuIGh0dHBzOi8vZ3NhcC5jb21cIiwgIV9jb25maWcubnVsbFRhcmdldFdhcm4pIHx8IFtdO1xuICAgIF90aGlzMy5fcHRMb29rdXAgPSBbXTsgLy9Qcm9wVHdlZW4gbG9va3VwLiBBbiBhcnJheSBjb250YWluaW5nIGFuIG9iamVjdCBmb3IgZWFjaCB0YXJnZXQsIGhhdmluZyBrZXlzIGZvciBlYWNoIHR3ZWVuaW5nIHByb3BlcnR5XG5cbiAgICBfdGhpczMuX292ZXJ3cml0ZSA9IG92ZXJ3cml0ZTtcblxuICAgIGlmIChrZXlmcmFtZXMgfHwgc3RhZ2dlciB8fCBfaXNGdW5jT3JTdHJpbmcoZHVyYXRpb24pIHx8IF9pc0Z1bmNPclN0cmluZyhkZWxheSkpIHtcbiAgICAgIHZhcnMgPSBfdGhpczMudmFycztcbiAgICAgIHZhciBlYXNlUmV2ZXJzZSA9IHZhcnMuZWFzZVJldmVyc2UgfHwgdmFycy55b3lvRWFzZTtcbiAgICAgIHRsID0gX3RoaXMzLnRpbWVsaW5lID0gbmV3IFRpbWVsaW5lKHtcbiAgICAgICAgZGF0YTogXCJuZXN0ZWRcIixcbiAgICAgICAgZGVmYXVsdHM6IGRlZmF1bHRzIHx8IHt9LFxuICAgICAgICB0YXJnZXRzOiBwYXJlbnQgJiYgcGFyZW50LmRhdGEgPT09IFwibmVzdGVkXCIgPyBwYXJlbnQudmFycy50YXJnZXRzIDogcGFyc2VkVGFyZ2V0c1xuICAgICAgfSk7IC8vIHdlIG5lZWQgdG8gc3RvcmUgdGhlIHRhcmdldHMgYmVjYXVzZSBmb3Igc3RhZ2dlcnMgYW5kIGtleWZyYW1lcywgd2UgZW5kIHVwIGNyZWF0aW5nIGFuIGluZGl2aWR1YWwgdHdlZW4gZm9yIGVhY2ggYnV0IGZ1bmN0aW9uLWJhc2VkIHZhbHVlcyBuZWVkIHRvIGtub3cgdGhlIGluZGV4IGFuZCB0aGUgd2hvbGUgQXJyYXkgb2YgdGFyZ2V0cy5cblxuICAgICAgdGwua2lsbCgpO1xuICAgICAgdGwucGFyZW50ID0gdGwuX2RwID0gX2Fzc2VydFRoaXNJbml0aWFsaXplZChfdGhpczMpO1xuICAgICAgdGwuX3N0YXJ0ID0gMDtcblxuICAgICAgaWYgKHN0YWdnZXIgfHwgX2lzRnVuY09yU3RyaW5nKGR1cmF0aW9uKSB8fCBfaXNGdW5jT3JTdHJpbmcoZGVsYXkpKSB7XG4gICAgICAgIGwgPSBwYXJzZWRUYXJnZXRzLmxlbmd0aDtcbiAgICAgICAgc3RhZ2dlckZ1bmMgPSBzdGFnZ2VyICYmIGRpc3RyaWJ1dGUoc3RhZ2dlcik7XG5cbiAgICAgICAgaWYgKF9pc09iamVjdChzdGFnZ2VyKSkge1xuICAgICAgICAgIC8vdXNlcnMgY2FuIHBhc3MgaW4gY2FsbGJhY2tzIGxpa2Ugb25TdGFydC9vbkNvbXBsZXRlIGluIHRoZSBzdGFnZ2VyIG9iamVjdC4gVGhlc2Ugc2hvdWxkIGZpcmUgd2l0aCBlYWNoIGluZGl2aWR1YWwgdHdlZW4uXG4gICAgICAgICAgZm9yIChwIGluIHN0YWdnZXIpIHtcbiAgICAgICAgICAgIGlmICh+X3N0YWdnZXJUd2VlblByb3BzLmluZGV4T2YocCkpIHtcbiAgICAgICAgICAgICAgc3RhZ2dlclZhcnNUb01lcmdlIHx8IChzdGFnZ2VyVmFyc1RvTWVyZ2UgPSB7fSk7XG4gICAgICAgICAgICAgIHN0YWdnZXJWYXJzVG9NZXJnZVtwXSA9IHN0YWdnZXJbcF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZm9yIChpID0gMDsgaSA8IGw7IGkrKykge1xuICAgICAgICAgIGNvcHkgPSBfY29weUV4Y2x1ZGluZyh2YXJzLCBfc3RhZ2dlclByb3BzVG9Ta2lwKTtcbiAgICAgICAgICBjb3B5LnN0YWdnZXIgPSAwO1xuICAgICAgICAgIGVhc2VSZXZlcnNlICYmIChjb3B5LmVhc2VSZXZlcnNlID0gZWFzZVJldmVyc2UpO1xuICAgICAgICAgIHN0YWdnZXJWYXJzVG9NZXJnZSAmJiBfbWVyZ2UoY29weSwgc3RhZ2dlclZhcnNUb01lcmdlKTtcbiAgICAgICAgICBjdXJUYXJnZXQgPSBwYXJzZWRUYXJnZXRzW2ldOyAvL2Rvbid0IGp1c3QgY29weSBkdXJhdGlvbiBvciBkZWxheSBiZWNhdXNlIGlmIHRoZXkncmUgYSBzdHJpbmcgb3IgZnVuY3Rpb24sIHdlJ2QgZW5kIHVwIGluIGFuIGluZmluaXRlIGxvb3AgYmVjYXVzZSBfaXNGdW5jT3JTdHJpbmcoKSB3b3VsZCBldmFsdWF0ZSBhcyB0cnVlIGluIHRoZSBjaGlsZCB0d2VlbnMsIGVudGVyaW5nIHRoaXMgbG9vcCwgZXRjLiBTbyB3ZSBwYXJzZSB0aGUgdmFsdWUgc3RyYWlnaHQgZnJvbSB2YXJzIGFuZCBkZWZhdWx0IHRvIDAuXG5cbiAgICAgICAgICBjb3B5LmR1cmF0aW9uID0gK19wYXJzZUZ1bmNPclN0cmluZyhkdXJhdGlvbiwgX2Fzc2VydFRoaXNJbml0aWFsaXplZChfdGhpczMpLCBpLCBjdXJUYXJnZXQsIHBhcnNlZFRhcmdldHMpO1xuICAgICAgICAgIGNvcHkuZGVsYXkgPSAoK19wYXJzZUZ1bmNPclN0cmluZyhkZWxheSwgX2Fzc2VydFRoaXNJbml0aWFsaXplZChfdGhpczMpLCBpLCBjdXJUYXJnZXQsIHBhcnNlZFRhcmdldHMpIHx8IDApIC0gX3RoaXMzLl9kZWxheTtcblxuICAgICAgICAgIGlmICghc3RhZ2dlciAmJiBsID09PSAxICYmIGNvcHkuZGVsYXkpIHtcbiAgICAgICAgICAgIC8vIGlmIHNvbWVvbmUgZG9lcyBkZWxheTpcInJhbmRvbSgxLCA1KVwiLCByZXBlYXQ6LTEsIGZvciBleGFtcGxlLCB0aGUgZGVsYXkgc2hvdWxkbid0IGJlIGluc2lkZSB0aGUgcmVwZWF0LlxuICAgICAgICAgICAgX3RoaXMzLl9kZWxheSA9IGRlbGF5ID0gY29weS5kZWxheTtcbiAgICAgICAgICAgIF90aGlzMy5fc3RhcnQgKz0gZGVsYXk7XG4gICAgICAgICAgICBjb3B5LmRlbGF5ID0gMDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICB0bC50byhjdXJUYXJnZXQsIGNvcHksIHN0YWdnZXJGdW5jID8gc3RhZ2dlckZ1bmMoaSwgY3VyVGFyZ2V0LCBwYXJzZWRUYXJnZXRzKSA6IDApO1xuICAgICAgICAgIHRsLl9lYXNlID0gX2Vhc2VNYXAubm9uZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRsLmR1cmF0aW9uKCkgPyBkdXJhdGlvbiA9IGRlbGF5ID0gMCA6IF90aGlzMy50aW1lbGluZSA9IDA7IC8vIGlmIHRoZSB0aW1lbGluZSdzIGR1cmF0aW9uIGlzIDAsIHdlIGRvbid0IG5lZWQgYSB0aW1lbGluZSBpbnRlcm5hbGx5IVxuICAgICAgfSBlbHNlIGlmIChrZXlmcmFtZXMpIHtcbiAgICAgICAgX2luaGVyaXREZWZhdWx0cyhfc2V0RGVmYXVsdHModGwudmFycy5kZWZhdWx0cywge1xuICAgICAgICAgIGVhc2U6IFwibm9uZVwiXG4gICAgICAgIH0pKTtcblxuICAgICAgICB0bC5fZWFzZSA9IF9wYXJzZUVhc2Uoa2V5ZnJhbWVzLmVhc2UgfHwgdmFycy5lYXNlIHx8IFwibm9uZVwiKTtcbiAgICAgICAgdmFyIHRpbWUgPSAwLFxuICAgICAgICAgICAgYSxcbiAgICAgICAgICAgIGtmLFxuICAgICAgICAgICAgdjtcblxuICAgICAgICBpZiAoX2lzQXJyYXkoa2V5ZnJhbWVzKSkge1xuICAgICAgICAgIGtleWZyYW1lcy5mb3JFYWNoKGZ1bmN0aW9uIChmcmFtZSkge1xuICAgICAgICAgICAgcmV0dXJuIHRsLnRvKHBhcnNlZFRhcmdldHMsIGZyYW1lLCBcIj5cIik7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdGwuZHVyYXRpb24oKTsgLy8gdG8gZW5zdXJlIHRsLl9kdXIgaXMgY2FjaGVkIGJlY2F1c2Ugd2UgdGFwIGludG8gaXQgZm9yIHBlcmZvcm1hbmNlIHB1cnBvc2VzIGluIHRoZSByZW5kZXIoKSBtZXRob2QuXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29weSA9IHt9O1xuXG4gICAgICAgICAgZm9yIChwIGluIGtleWZyYW1lcykge1xuICAgICAgICAgICAgcCA9PT0gXCJlYXNlXCIgfHwgcCA9PT0gXCJlYXNlRWFjaFwiIHx8IF9wYXJzZUtleWZyYW1lKHAsIGtleWZyYW1lc1twXSwgY29weSwga2V5ZnJhbWVzLmVhc2VFYWNoKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBmb3IgKHAgaW4gY29weSkge1xuICAgICAgICAgICAgYSA9IGNvcHlbcF0uc29ydChmdW5jdGlvbiAoYSwgYikge1xuICAgICAgICAgICAgICByZXR1cm4gYS50IC0gYi50O1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aW1lID0gMDtcblxuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAga2YgPSBhW2ldO1xuICAgICAgICAgICAgICB2ID0ge1xuICAgICAgICAgICAgICAgIGVhc2U6IGtmLmUsXG4gICAgICAgICAgICAgICAgZHVyYXRpb246IChrZi50IC0gKGkgPyBhW2kgLSAxXS50IDogMCkpIC8gMTAwICogZHVyYXRpb25cbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgdltwXSA9IGtmLnY7XG4gICAgICAgICAgICAgIHRsLnRvKHBhcnNlZFRhcmdldHMsIHYsIHRpbWUpO1xuICAgICAgICAgICAgICB0aW1lICs9IHYuZHVyYXRpb247XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdGwuZHVyYXRpb24oKSA8IGR1cmF0aW9uICYmIHRsLnRvKHt9LCB7XG4gICAgICAgICAgICBkdXJhdGlvbjogZHVyYXRpb24gLSB0bC5kdXJhdGlvbigpXG4gICAgICAgICAgfSk7IC8vIGluIGNhc2Uga2V5ZnJhbWVzIGRpZG4ndCBnbyB0byAxMDAlXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgZHVyYXRpb24gfHwgX3RoaXMzLmR1cmF0aW9uKGR1cmF0aW9uID0gdGwuZHVyYXRpb24oKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIF90aGlzMy50aW1lbGluZSA9IDA7IC8vc3BlZWQgb3B0aW1pemF0aW9uLCBmYXN0ZXIgbG9va3VwcyAobm8gZ29pbmcgdXAgdGhlIHByb3RvdHlwZSBjaGFpbilcbiAgICB9XG5cbiAgICBpZiAob3ZlcndyaXRlID09PSB0cnVlICYmICFfc3VwcHJlc3NPdmVyd3JpdGVzKSB7XG4gICAgICBfb3ZlcndyaXRpbmdUd2VlbiA9IF9hc3NlcnRUaGlzSW5pdGlhbGl6ZWQoX3RoaXMzKTtcblxuICAgICAgX2dsb2JhbFRpbWVsaW5lLmtpbGxUd2VlbnNPZihwYXJzZWRUYXJnZXRzKTtcblxuICAgICAgX292ZXJ3cml0aW5nVHdlZW4gPSAwO1xuICAgIH1cblxuICAgIF9hZGRUb1RpbWVsaW5lKHBhcmVudCwgX2Fzc2VydFRoaXNJbml0aWFsaXplZChfdGhpczMpLCBwb3NpdGlvbik7XG5cbiAgICB2YXJzLnJldmVyc2VkICYmIF90aGlzMy5yZXZlcnNlKCk7XG4gICAgdmFycy5wYXVzZWQgJiYgX3RoaXMzLnBhdXNlZCh0cnVlKTtcblxuICAgIGlmIChpbW1lZGlhdGVSZW5kZXIgfHwgIWR1cmF0aW9uICYmICFrZXlmcmFtZXMgJiYgX3RoaXMzLl9zdGFydCA9PT0gX3JvdW5kUHJlY2lzZShwYXJlbnQuX3RpbWUpICYmIF9pc05vdEZhbHNlKGltbWVkaWF0ZVJlbmRlcikgJiYgX2hhc05vUGF1c2VkQW5jZXN0b3JzKF9hc3NlcnRUaGlzSW5pdGlhbGl6ZWQoX3RoaXMzKSkgJiYgcGFyZW50LmRhdGEgIT09IFwibmVzdGVkXCIpIHtcbiAgICAgIF90aGlzMy5fdFRpbWUgPSAtX3RpbnlOdW07IC8vZm9yY2VzIGEgcmVuZGVyIHdpdGhvdXQgaGF2aW5nIHRvIHNldCB0aGUgcmVuZGVyKCkgXCJmb3JjZVwiIHBhcmFtZXRlciB0byB0cnVlIGJlY2F1c2Ugd2Ugd2FudCB0byBhbGxvdyBsYXp5aW5nIGJ5IGRlZmF1bHQgKHVzaW5nIHRoZSBcImZvcmNlXCIgcGFyYW1ldGVyIGFsd2F5cyBmb3JjZXMgYW4gaW1tZWRpYXRlIGZ1bGwgcmVuZGVyKVxuXG4gICAgICBfdGhpczMucmVuZGVyKE1hdGgubWF4KDAsIC1kZWxheSkgfHwgMCk7IC8vaW4gY2FzZSBkZWxheSBpcyBuZWdhdGl2ZVxuXG4gICAgfVxuXG4gICAgc2Nyb2xsVHJpZ2dlciAmJiBfc2Nyb2xsVHJpZ2dlcihfYXNzZXJ0VGhpc0luaXRpYWxpemVkKF90aGlzMyksIHNjcm9sbFRyaWdnZXIpO1xuICAgIHJldHVybiBfdGhpczM7XG4gIH1cblxuICB2YXIgX3Byb3RvMyA9IFR3ZWVuLnByb3RvdHlwZTtcblxuICBfcHJvdG8zLnJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlcih0b3RhbFRpbWUsIHN1cHByZXNzRXZlbnRzLCBmb3JjZSkge1xuICAgIHZhciBwcmV2VGltZSA9IHRoaXMuX3RpbWUsXG4gICAgICAgIHREdXIgPSB0aGlzLl90RHVyLFxuICAgICAgICBkdXIgPSB0aGlzLl9kdXIsXG4gICAgICAgIGlzTmVnYXRpdmUgPSB0b3RhbFRpbWUgPCAwLFxuICAgICAgICB0VGltZSA9IHRvdGFsVGltZSA+IHREdXIgLSBfdGlueU51bSAmJiAhaXNOZWdhdGl2ZSA/IHREdXIgOiB0b3RhbFRpbWUgPCBfdGlueU51bSA/IDAgOiB0b3RhbFRpbWUsXG4gICAgICAgIHRpbWUsXG4gICAgICAgIHB0LFxuICAgICAgICBpdGVyYXRpb24sXG4gICAgICAgIGN5Y2xlRHVyYXRpb24sXG4gICAgICAgIHByZXZJdGVyYXRpb24sXG4gICAgICAgIGlzWW95byxcbiAgICAgICAgcmF0aW8sXG4gICAgICAgIHRpbWVsaW5lO1xuXG4gICAgaWYgKCFkdXIpIHtcbiAgICAgIF9yZW5kZXJaZXJvRHVyYXRpb25Ud2Vlbih0aGlzLCB0b3RhbFRpbWUsIHN1cHByZXNzRXZlbnRzLCBmb3JjZSk7XG4gICAgfSBlbHNlIGlmICh0VGltZSAhPT0gdGhpcy5fdFRpbWUgfHwgIXRvdGFsVGltZSB8fCBmb3JjZSB8fCAhdGhpcy5faW5pdHRlZCAmJiB0aGlzLl90VGltZSB8fCB0aGlzLl9zdGFydEF0ICYmIHRoaXMuX3pUaW1lIDwgMCAhPT0gaXNOZWdhdGl2ZSB8fCB0aGlzLl9sYXp5KSB7XG4gICAgICAvLyB0aGlzIHNlbnNlcyBpZiB3ZSdyZSBjcm9zc2luZyBvdmVyIHRoZSBzdGFydCB0aW1lLCBpbiB3aGljaCBjYXNlIHdlIG11c3QgcmVjb3JkIF96VGltZSBhbmQgZm9yY2UgdGhlIHJlbmRlciwgYnV0IHdlIGRvIGl0IGluIHRoaXMgbGVuZ3RoeSBjb25kaXRpb25hbCB3YXkgZm9yIHBlcmZvcm1hbmNlIHJlYXNvbnMgKHVzdWFsbHkgd2UgY2FuIHNraXAgdGhlIGNhbGN1bGF0aW9ucyk6IHRoaXMuX2luaXR0ZWQgJiYgKHRoaXMuX3pUaW1lIDwgMCkgIT09ICh0b3RhbFRpbWUgPCAwKVxuICAgICAgdGltZSA9IHRUaW1lO1xuICAgICAgdGltZWxpbmUgPSB0aGlzLnRpbWVsaW5lO1xuXG4gICAgICBpZiAodGhpcy5fcmVwZWF0KSB7XG4gICAgICAgIC8vYWRqdXN0IHRoZSB0aW1lIGZvciByZXBlYXRzIGFuZCB5b3lvc1xuICAgICAgICBjeWNsZUR1cmF0aW9uID0gZHVyICsgdGhpcy5fckRlbGF5O1xuXG4gICAgICAgIGlmICh0aGlzLl9yZXBlYXQgPCAtMSAmJiBpc05lZ2F0aXZlKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMudG90YWxUaW1lKGN5Y2xlRHVyYXRpb24gKiAxMDAgKyB0b3RhbFRpbWUsIHN1cHByZXNzRXZlbnRzLCBmb3JjZSk7XG4gICAgICAgIH1cblxuICAgICAgICB0aW1lID0gX3JvdW5kUHJlY2lzZSh0VGltZSAlIGN5Y2xlRHVyYXRpb24pOyAvL3JvdW5kIHRvIGF2b2lkIGZsb2F0aW5nIHBvaW50IGVycm9ycy4gKDQgJSAwLjggc2hvdWxkIGJlIDAgYnV0IHNvbWUgYnJvd3NlcnMgcmVwb3J0IGl0IGFzIDAuNzk5OTk5OTkhKVxuXG4gICAgICAgIGlmICh0VGltZSA9PT0gdER1cikge1xuICAgICAgICAgIC8vIHRoZSB0RHVyID09PSB0VGltZSBpcyBmb3IgZWRnZSBjYXNlcyB3aGVyZSB0aGVyZSdzIGEgbGVuZ3RoeSBkZWNpbWFsIG9uIHRoZSBkdXJhdGlvbiBhbmQgaXQgbWF5IHJlYWNoIHRoZSB2ZXJ5IGVuZCBidXQgdGhlIHRpbWUgaXMgcmVuZGVyZWQgYXMgbm90LXF1aXRlLXRoZXJlIChyZW1lbWJlciwgdER1ciBpcyByb3VuZGVkIHRvIDQgZGVjaW1hbHMgd2hlcmVhcyBkdXIgaXNuJ3QpXG4gICAgICAgICAgaXRlcmF0aW9uID0gdGhpcy5fcmVwZWF0O1xuICAgICAgICAgIHRpbWUgPSBkdXI7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcHJldkl0ZXJhdGlvbiA9IF9yb3VuZFByZWNpc2UodFRpbWUgLyBjeWNsZUR1cmF0aW9uKTsgLy8gZnVsbCBkZWNpbWFsIHZlcnNpb24gb2YgaXRlcmF0aW9ucywgbm90IHRoZSBwcmV2aW91cyBpdGVyYXRpb24gKHdlJ3JlIHJldXNpbmcgcHJldkl0ZXJhdGlvbiB2YXJpYWJsZSBmb3IgZWZmaWNpZW5jeSlcblxuICAgICAgICAgIGl0ZXJhdGlvbiA9IH5+cHJldkl0ZXJhdGlvbjtcblxuICAgICAgICAgIGlmIChpdGVyYXRpb24gJiYgaXRlcmF0aW9uID09PSBwcmV2SXRlcmF0aW9uKSB7XG4gICAgICAgICAgICB0aW1lID0gZHVyO1xuICAgICAgICAgICAgaXRlcmF0aW9uLS07XG4gICAgICAgICAgfSBlbHNlIGlmICh0aW1lID4gZHVyKSB7XG4gICAgICAgICAgICB0aW1lID0gZHVyO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlzWW95byA9IHRoaXMuX3lveW8gJiYgaXRlcmF0aW9uICYgMTtcbiAgICAgICAgaWYgKGlzWW95bykgdGltZSA9IGR1ciAtIHRpbWU7XG4gICAgICAgIHByZXZJdGVyYXRpb24gPSBfYW5pbWF0aW9uQ3ljbGUodGhpcy5fdFRpbWUsIGN5Y2xlRHVyYXRpb24pO1xuXG4gICAgICAgIGlmICh0aW1lID09PSBwcmV2VGltZSAmJiAhZm9yY2UgJiYgdGhpcy5faW5pdHRlZCAmJiBpdGVyYXRpb24gPT09IHByZXZJdGVyYXRpb24pIHtcbiAgICAgICAgICAvL2NvdWxkIGJlIGR1cmluZyB0aGUgcmVwZWF0RGVsYXkgcGFydC4gTm8gbmVlZCB0byByZW5kZXIgYW5kIGZpcmUgY2FsbGJhY2tzLlxuICAgICAgICAgIHRoaXMuX3RUaW1lID0gdFRpbWU7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaXRlcmF0aW9uICE9PSBwcmV2SXRlcmF0aW9uKSB7XG4gICAgICAgICAgLy9yZXBlYXRSZWZyZXNoIGZ1bmN0aW9uYWxpdHlcbiAgICAgICAgICBpZiAodGhpcy52YXJzLnJlcGVhdFJlZnJlc2ggJiYgIWlzWW95byAmJiAhdGhpcy5fbG9jayAmJiB0aW1lICE9PSBjeWNsZUR1cmF0aW9uICYmIHRoaXMuX2luaXR0ZWQpIHtcbiAgICAgICAgICAgIC8vIHRoaXMuX3RpbWUgd2lsbCA9PT0gY3ljbGVEdXJhdGlvbiB3aGVuIHdlIHJlbmRlciBhdCBFWEFDVExZIHRoZSBlbmQgb2YgYW4gaXRlcmF0aW9uLiBXaXRob3V0IHRoaXMgY29uZGl0aW9uLCBpdCdkIG9mdGVuIGRvIHRoZSByZXBlYXRSZWZyZXNoIHJlbmRlciBUV0lDRSAoYWdhaW4gb24gdGhlIHZlcnkgbmV4dCB0aWNrKS5cbiAgICAgICAgICAgIHRoaXMuX2xvY2sgPSBmb3JjZSA9IDE7IC8vZm9yY2UsIG90aGVyd2lzZSBpZiBsYXp5IGlzIHRydWUsIHRoZSBfYXR0ZW1wdEluaXRUd2VlbigpIHdpbGwgcmV0dXJuIGFuZCB3ZSdsbCBqdW1wIG91dCBhbmQgZ2V0IGNhdWdodCBib3VuY2luZyBvbiBlYWNoIHRpY2suXG5cbiAgICAgICAgICAgIHRoaXMucmVuZGVyKF9yb3VuZFByZWNpc2UoY3ljbGVEdXJhdGlvbiAqIGl0ZXJhdGlvbiksIHRydWUpLmludmFsaWRhdGUoKS5fbG9jayA9IDA7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmICghdGhpcy5faW5pdHRlZCkge1xuICAgICAgICBpZiAoX2F0dGVtcHRJbml0VHdlZW4odGhpcywgaXNOZWdhdGl2ZSA/IHRvdGFsVGltZSA6IHRpbWUsIGZvcmNlLCBzdXBwcmVzc0V2ZW50cywgdFRpbWUpKSB7XG4gICAgICAgICAgdGhpcy5fdFRpbWUgPSAwOyAvLyBpbiBjb25zdHJ1Y3RvciBpZiBpbW1lZGlhdGVSZW5kZXIgaXMgdHJ1ZSwgd2Ugc2V0IF90VGltZSB0byAtX3RpbnlOdW0gdG8gaGF2ZSB0aGUgcGxheWhlYWQgY3Jvc3MgdGhlIHN0YXJ0aW5nIHBvaW50IGJ1dCB3ZSBjYW4ndCBsZWF2ZSBfdFRpbWUgYXMgYSBuZWdhdGl2ZSBudW1iZXIuXG5cbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwcmV2VGltZSAhPT0gdGhpcy5fdGltZSAmJiAhKGZvcmNlICYmIHRoaXMudmFycy5yZXBlYXRSZWZyZXNoICYmIGl0ZXJhdGlvbiAhPT0gcHJldkl0ZXJhdGlvbikpIHtcbiAgICAgICAgICAvLyByYXJlIGVkZ2UgY2FzZSAtIGR1cmluZyBpbml0aWFsaXphdGlvbiwgYW4gb25VcGRhdGUgaW4gdGhlIF9zdGFydEF0ICguZnJvbVRvKCkpIG1pZ2h0IGZvcmNlIHRoaXMgdHdlZW4gdG8gcmVuZGVyIGF0IGEgZGlmZmVyZW50IHNwb3QgaW4gd2hpY2ggY2FzZSB3ZSBzaG91bGQgZGl0Y2ggdGhpcyByZW5kZXIoKSBjYWxsIHNvIHRoYXQgaXQgZG9lc24ndCByZXZlcnQgdGhlIHZhbHVlcy4gQnV0IHdlIGFsc28gZG9uJ3Qgd2FudCB0byBkdW1wIGlmIHdlJ3JlIGRvaW5nIGEgcmVwZWF0UmVmcmVzaCByZW5kZXIhXG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZHVyICE9PSB0aGlzLl9kdXIpIHtcbiAgICAgICAgICAvLyB3aGlsZSBpbml0dGluZywgYSBwbHVnaW4gbGlrZSBJbmVydGlhUGx1Z2luIG1pZ2h0IGFsdGVyIHRoZSBkdXJhdGlvbiwgc28gcmVydW4gZnJvbSB0aGUgc3RhcnQgdG8gZW5zdXJlIGV2ZXJ5dGhpbmcgcmVuZGVycyBhcyBpdCBzaG91bGQuXG4gICAgICAgICAgcmV0dXJuIHRoaXMucmVuZGVyKHRvdGFsVGltZSwgc3VwcHJlc3NFdmVudHMsIGZvcmNlKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAodGhpcy5fckVhc2UpIHtcbiAgICAgICAgdmFyIGludiA9IHRpbWUgPCBwcmV2VGltZTtcblxuICAgICAgICBpZiAoaW52ICE9PSB0aGlzLl9pbnYpIHtcbiAgICAgICAgICB2YXIgc2VnRHVyID0gaW52ID8gcHJldlRpbWUgOiBkdXIgLSBwcmV2VGltZTtcbiAgICAgICAgICB0aGlzLl9pbnYgPSBpbnY7XG4gICAgICAgICAgaWYgKHRoaXMuX2Zyb20pIHRoaXMucmF0aW8gPSAxIC0gdGhpcy5yYXRpbztcbiAgICAgICAgICB0aGlzLl9pbnZSYXRpbyA9IHRoaXMucmF0aW87XG4gICAgICAgICAgdGhpcy5faW52VGltZSA9IHByZXZUaW1lO1xuICAgICAgICAgIHRoaXMuX2ludlJlY2lwID0gc2VnRHVyID8gKGludiA/IC0xIDogMSkgLyBzZWdEdXIgOiAwO1xuICAgICAgICAgIHRoaXMuX2ludlNjYWxlID0gaW52ID8gLXRoaXMucmF0aW8gOiAxIC0gdGhpcy5yYXRpbztcbiAgICAgICAgICB0aGlzLl9pbnZFYXNlID0gaW52ID8gdGhpcy5fckVhc2UgOiB0aGlzLl9lYXNlO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5yYXRpbyA9IHJhdGlvID0gdGhpcy5faW52UmF0aW8gKyB0aGlzLl9pbnZTY2FsZSAqIHRoaXMuX2ludkVhc2UoKHRpbWUgLSB0aGlzLl9pbnZUaW1lKSAqIHRoaXMuX2ludlJlY2lwKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMucmF0aW8gPSByYXRpbyA9IHRoaXMuX2Vhc2UodGltZSAvIGR1cik7XG4gICAgICB9XG5cbiAgICAgIGlmICh0aGlzLl9mcm9tKSB0aGlzLnJhdGlvID0gcmF0aW8gPSAxIC0gcmF0aW87XG4gICAgICB0aGlzLl90VGltZSA9IHRUaW1lO1xuICAgICAgdGhpcy5fdGltZSA9IHRpbWU7XG5cbiAgICAgIGlmICghdGhpcy5fYWN0ICYmIHRoaXMuX3RzKSB7XG4gICAgICAgIHRoaXMuX2FjdCA9IDE7IC8vYXMgbG9uZyBhcyBpdCdzIG5vdCBwYXVzZWQsIGZvcmNlIGl0IHRvIGJlIGFjdGl2ZSBzbyB0aGF0IGlmIHRoZSB1c2VyIHJlbmRlcnMgaW5kZXBlbmRlbnQgb2YgdGhlIHBhcmVudCB0aW1lbGluZSwgaXQnbGwgYmUgZm9yY2VkIHRvIHJlLXJlbmRlciBvbiB0aGUgbmV4dCB0aWNrLlxuXG4gICAgICAgIHRoaXMuX2xhenkgPSAwO1xuICAgICAgfVxuXG4gICAgICBpZiAoIXByZXZUaW1lICYmIHRUaW1lICYmICFzdXBwcmVzc0V2ZW50cyAmJiAhcHJldkl0ZXJhdGlvbikge1xuICAgICAgICBfY2FsbGJhY2sodGhpcywgXCJvblN0YXJ0XCIpO1xuXG4gICAgICAgIGlmICh0aGlzLl90VGltZSAhPT0gdFRpbWUpIHtcbiAgICAgICAgICAvLyBpbiBjYXNlIHRoZSBvblN0YXJ0IHRyaWdnZXJlZCBhIHJlbmRlciBhdCBhIGRpZmZlcmVudCBzcG90LCBlamVjdC4gTGlrZSBpZiBzb21lb25lIGRpZCBhbmltYXRpb24ucGF1c2UoMC41KSBvciBzb21ldGhpbmcgaW5zaWRlIHRoZSBvblN0YXJ0LlxuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHB0ID0gdGhpcy5fcHQ7XG5cbiAgICAgIHdoaWxlIChwdCkge1xuICAgICAgICBwdC5yKHJhdGlvLCBwdC5kKTtcbiAgICAgICAgcHQgPSBwdC5fbmV4dDtcbiAgICAgIH1cblxuICAgICAgdGltZWxpbmUgJiYgdGltZWxpbmUucmVuZGVyKHRvdGFsVGltZSA8IDAgPyB0b3RhbFRpbWUgOiB0aW1lbGluZS5fZHVyICogdGltZWxpbmUuX2Vhc2UodGltZSAvIHRoaXMuX2R1ciksIHN1cHByZXNzRXZlbnRzLCBmb3JjZSkgfHwgdGhpcy5fc3RhcnRBdCAmJiAodGhpcy5felRpbWUgPSB0b3RhbFRpbWUpO1xuXG4gICAgICBpZiAodGhpcy5fb25VcGRhdGUgJiYgIXN1cHByZXNzRXZlbnRzKSB7XG4gICAgICAgIGlzTmVnYXRpdmUgJiYgX3Jld2luZFN0YXJ0QXQodGhpcywgdG90YWxUaW1lLCBzdXBwcmVzc0V2ZW50cywgZm9yY2UpOyAvL25vdGU6IGZvciBwZXJmb3JtYW5jZSByZWFzb25zLCB3ZSB0dWNrIHRoaXMgY29uZGl0aW9uYWwgbG9naWMgaW5zaWRlIGxlc3MgdHJhdmVsZWQgYXJlYXMgKG1vc3QgdHdlZW5zIGRvbid0IGhhdmUgYW4gb25VcGRhdGUpLiBXZSdkIGp1c3QgaGF2ZSBpdCBhdCB0aGUgZW5kIGJlZm9yZSB0aGUgb25Db21wbGV0ZSwgYnV0IHRoZSB2YWx1ZXMgc2hvdWxkIGJlIHVwZGF0ZWQgYmVmb3JlIGFueSBvblVwZGF0ZSBpcyBjYWxsZWQsIHNvIHdlIEFMU08gcHV0IGl0IGhlcmUgYW5kIHRoZW4gaWYgaXQncyBub3QgY2FsbGVkLCB3ZSBkbyBzbyBsYXRlciBuZWFyIHRoZSBvbkNvbXBsZXRlLlxuXG4gICAgICAgIF9jYWxsYmFjayh0aGlzLCBcIm9uVXBkYXRlXCIpO1xuICAgICAgfVxuXG4gICAgICB0aGlzLl9yZXBlYXQgJiYgaXRlcmF0aW9uICE9PSBwcmV2SXRlcmF0aW9uICYmIHRoaXMudmFycy5vblJlcGVhdCAmJiAhc3VwcHJlc3NFdmVudHMgJiYgdGhpcy5wYXJlbnQgJiYgX2NhbGxiYWNrKHRoaXMsIFwib25SZXBlYXRcIik7XG5cbiAgICAgIGlmICgodFRpbWUgPT09IHRoaXMuX3REdXIgfHwgIXRUaW1lKSAmJiB0aGlzLl90VGltZSA9PT0gdFRpbWUpIHtcbiAgICAgICAgaXNOZWdhdGl2ZSAmJiAhdGhpcy5fb25VcGRhdGUgJiYgX3Jld2luZFN0YXJ0QXQodGhpcywgdG90YWxUaW1lLCB0cnVlLCB0cnVlKTtcbiAgICAgICAgKHRvdGFsVGltZSB8fCAhZHVyKSAmJiAodFRpbWUgPT09IHRoaXMuX3REdXIgJiYgdGhpcy5fdHMgPiAwIHx8ICF0VGltZSAmJiB0aGlzLl90cyA8IDApICYmIF9yZW1vdmVGcm9tUGFyZW50KHRoaXMsIDEpOyAvLyBkb24ndCByZW1vdmUgaWYgd2UncmUgcmVuZGVyaW5nIGF0IGV4YWN0bHkgYSB0aW1lIG9mIDAsIGFzIHRoZXJlIGNvdWxkIGJlIGF1dG9SZXZlcnQgdmFsdWVzIHRoYXQgc2hvdWxkIGdldCBzZXQgb24gdGhlIG5leHQgdGljayAoaWYgdGhlIHBsYXloZWFkIGdvZXMgYmFja3dhcmQgYmV5b25kIHRoZSBzdGFydFRpbWUsIG5lZ2F0aXZlIHRvdGFsVGltZSkuIERvbid0IHJlbW92ZSBpZiB0aGUgdGltZWxpbmUgaXMgcmV2ZXJzZWQgYW5kIHRoZSBwbGF5aGVhZCBpc24ndCBhdCAwLCBvdGhlcndpc2UgdGwucHJvZ3Jlc3MoMSkucmV2ZXJzZSgpIHdvbid0IHdvcmsuIE9ubHkgcmVtb3ZlIGlmIHRoZSBwbGF5aGVhZCBpcyBhdCB0aGUgZW5kIGFuZCB0aW1lU2NhbGUgaXMgcG9zaXRpdmUsIG9yIGlmIHRoZSBwbGF5aGVhZCBpcyBhdCAwIGFuZCB0aGUgdGltZVNjYWxlIGlzIG5lZ2F0aXZlLlxuXG4gICAgICAgIGlmICghc3VwcHJlc3NFdmVudHMgJiYgIShpc05lZ2F0aXZlICYmICFwcmV2VGltZSkgJiYgKHRUaW1lIHx8IHByZXZUaW1lIHx8IGlzWW95bykpIHtcbiAgICAgICAgICAvLyBpZiBwcmV2VGltZSBhbmQgdFRpbWUgYXJlIHplcm8sIHdlIHNob3VsZG4ndCBmaXJlIHRoZSBvblJldmVyc2VDb21wbGV0ZS4gVGhpcyBjb3VsZCBoYXBwZW4gaWYgeW91IGdzYXAudG8oLi4uIHtwYXVzZWQ6dHJ1ZX0pLnBsYXkoKTtcbiAgICAgICAgICBfY2FsbGJhY2sodGhpcywgdFRpbWUgPT09IHREdXIgPyBcIm9uQ29tcGxldGVcIiA6IFwib25SZXZlcnNlQ29tcGxldGVcIiwgdHJ1ZSk7XG5cbiAgICAgICAgICB0aGlzLl9wcm9tICYmICEodFRpbWUgPCB0RHVyICYmIHRoaXMudGltZVNjYWxlKCkgPiAwKSAmJiB0aGlzLl9wcm9tKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBfcHJvdG8zLnRhcmdldHMgPSBmdW5jdGlvbiB0YXJnZXRzKCkge1xuICAgIHJldHVybiB0aGlzLl90YXJnZXRzO1xuICB9O1xuXG4gIF9wcm90bzMuaW52YWxpZGF0ZSA9IGZ1bmN0aW9uIGludmFsaWRhdGUoc29mdCkge1xuICAgIC8vIFwic29mdFwiIGdpdmVzIHVzIGEgd2F5IHRvIGNsZWFyIG91dCBldmVyeXRoaW5nIEVYQ0VQVCB0aGUgcmVjb3JkZWQgcHJlLVwiZnJvbVwiIHBvcnRpb24gb2YgZnJvbSgpIHR3ZWVucy4gT3RoZXJ3aXNlLCBmb3IgZXhhbXBsZSwgaWYgeW91IHR3ZWVuLnByb2dyZXNzKDEpLnJlbmRlcigwLCB0cnVlIHRydWUpLmludmFsaWRhdGUoKSwgdGhlIFwiZnJvbVwiIHZhbHVlcyB3b3VsZCBwZXJzaXN0IGFuZCB0aGVuIG9uIHRoZSBuZXh0IHJlbmRlciwgdGhlIGZyb20oKSB0d2VlbnMgd291bGQgaW5pdGlhbGl6ZSBhbmQgdGhlIGN1cnJlbnQgdmFsdWUgd291bGQgbWF0Y2ggdGhlIFwiZnJvbVwiIHZhbHVlcywgdGh1cyBhbmltYXRlIGZyb20gdGhlIHNhbWUgdmFsdWUgdG8gdGhlIHNhbWUgdmFsdWUgKG5vIGFuaW1hdGlvbikuIFdlIHRhcCBpbnRvIHRoaXMgaW4gU2Nyb2xsVHJpZ2dlcidzIHJlZnJlc2goKSB3aGVyZSB3ZSBtdXN0IHB1c2ggYSB0d2VlbiB0byBjb21wbGV0aW9uIGFuZCB0aGVuIGJhY2sgYWdhaW4gYnV0IGhvbm9yIGl0cyBpbml0IHN0YXRlIGluIGNhc2UgdGhlIHR3ZWVuIGlzIGRlcGVuZGVudCBvbiBhbm90aGVyIHR3ZWVuIGZ1cnRoZXIgdXAgb24gdGhlIHBhZ2UuXG4gICAgKCFzb2Z0IHx8ICF0aGlzLnZhcnMucnVuQmFja3dhcmRzKSAmJiAodGhpcy5fc3RhcnRBdCA9IDApO1xuICAgIHRoaXMuX3B0ID0gdGhpcy5fb3AgPSB0aGlzLl9vblVwZGF0ZSA9IHRoaXMuX2xhenkgPSB0aGlzLnJhdGlvID0gMDtcbiAgICB0aGlzLl9wdExvb2t1cCA9IFtdO1xuICAgIHRoaXMudGltZWxpbmUgJiYgdGhpcy50aW1lbGluZS5pbnZhbGlkYXRlKHNvZnQpO1xuICAgIHJldHVybiBfQW5pbWF0aW9uMi5wcm90b3R5cGUuaW52YWxpZGF0ZS5jYWxsKHRoaXMsIHNvZnQpO1xuICB9O1xuXG4gIF9wcm90bzMucmVzZXRUbyA9IGZ1bmN0aW9uIHJlc2V0VG8ocHJvcGVydHksIHZhbHVlLCBzdGFydCwgc3RhcnRJc1JlbGF0aXZlLCBza2lwUmVjdXJzaW9uKSB7XG4gICAgX3RpY2tlckFjdGl2ZSB8fCBfdGlja2VyLndha2UoKTtcbiAgICB0aGlzLl90cyB8fCB0aGlzLnBsYXkoKTtcbiAgICB2YXIgdGltZSA9IE1hdGgubWluKHRoaXMuX2R1ciwgKHRoaXMuX2RwLl90aW1lIC0gdGhpcy5fc3RhcnQpICogdGhpcy5fdHMpLFxuICAgICAgICByYXRpbztcbiAgICB0aGlzLl9pbml0dGVkIHx8IF9pbml0VHdlZW4odGhpcywgdGltZSk7XG4gICAgcmF0aW8gPSB0aGlzLl9lYXNlKHRpbWUgLyB0aGlzLl9kdXIpOyAvLyBkb24ndCBqdXN0IGdldCB0d2Vlbi5yYXRpbyBiZWNhdXNlIGl0IG1heSBub3QgaGF2ZSByZW5kZXJlZCB5ZXQuXG4gICAgLy8gcG9zc2libGUgZnV0dXJlIGFkZGl0aW9uIHRvIGFsbG93IGFuIG9iamVjdCB3aXRoIG11bHRpcGxlIHZhbHVlcyB0byB1cGRhdGUsIGxpa2UgdHdlZW4ucmVzZXRUbyh7eDogMTAwLCB5OiAyMDB9KTsgQXQgdGhpcyBwb2ludCwgaXQgZG9lc24ndCBzZWVtIHdvcnRoIHRoZSBhZGRlZCBrYiBnaXZlbiB0aGUgZmFjdCB0aGF0IG1vc3QgdXNlcnMgd2lsbCBsaWtlbHkgb3B0IGZvciB0aGUgY29udmVuaWVudCBnc2FwLnF1aWNrVG8oKSB3YXkgb2YgaW50ZXJhY3Rpbmcgd2l0aCB0aGlzIG1ldGhvZC5cbiAgICAvLyBpZiAoX2lzT2JqZWN0KHByb3BlcnR5KSkgeyAvLyBwZXJmb3JtYW5jZSBvcHRpbWl6YXRpb25cbiAgICAvLyBcdGZvciAocCBpbiBwcm9wZXJ0eSkge1xuICAgIC8vIFx0XHRpZiAoX3VwZGF0ZVByb3BUd2VlbnModGhpcywgcCwgcHJvcGVydHlbcF0sIHZhbHVlID8gdmFsdWVbcF0gOiBudWxsLCBzdGFydCwgcmF0aW8sIHRpbWUpKSB7XG4gICAgLy8gXHRcdFx0cmV0dXJuIHRoaXMucmVzZXRUbyhwcm9wZXJ0eSwgdmFsdWUsIHN0YXJ0LCBzdGFydElzUmVsYXRpdmUpOyAvLyBpZiBhIFByb3BUd2VlbiB3YXNuJ3QgZm91bmQgZm9yIHRoZSBwcm9wZXJ0eSwgaXQnbGwgZ2V0IGZvcmNlZCB3aXRoIGEgcmUtaW5pdGlhbGl6YXRpb24gc28gd2UgbmVlZCB0byBqdW1wIG91dCBhbmQgc3RhcnQgb3ZlciBhZ2Fpbi5cbiAgICAvLyBcdFx0fVxuICAgIC8vIFx0fVxuICAgIC8vIH0gZWxzZSB7XG5cbiAgICBpZiAoX3VwZGF0ZVByb3BUd2VlbnModGhpcywgcHJvcGVydHksIHZhbHVlLCBzdGFydCwgc3RhcnRJc1JlbGF0aXZlLCByYXRpbywgdGltZSwgc2tpcFJlY3Vyc2lvbikpIHtcbiAgICAgIHJldHVybiB0aGlzLnJlc2V0VG8ocHJvcGVydHksIHZhbHVlLCBzdGFydCwgc3RhcnRJc1JlbGF0aXZlLCAxKTsgLy8gaWYgYSBQcm9wVHdlZW4gd2Fzbid0IGZvdW5kIGZvciB0aGUgcHJvcGVydHksIGl0J2xsIGdldCBmb3JjZWQgd2l0aCBhIHJlLWluaXRpYWxpemF0aW9uIHNvIHdlIG5lZWQgdG8ganVtcCBvdXQgYW5kIHN0YXJ0IG92ZXIgYWdhaW4uXG4gICAgfSAvL31cblxuXG4gICAgX2FsaWduUGxheWhlYWQodGhpcywgMCk7XG5cbiAgICB0aGlzLnBhcmVudCB8fCBfYWRkTGlua2VkTGlzdEl0ZW0odGhpcy5fZHAsIHRoaXMsIFwiX2ZpcnN0XCIsIFwiX2xhc3RcIiwgdGhpcy5fZHAuX3NvcnQgPyBcIl9zdGFydFwiIDogMCk7XG4gICAgcmV0dXJuIHRoaXMucmVuZGVyKDApO1xuICB9O1xuXG4gIF9wcm90bzMua2lsbCA9IGZ1bmN0aW9uIGtpbGwodGFyZ2V0cywgdmFycykge1xuICAgIGlmICh2YXJzID09PSB2b2lkIDApIHtcbiAgICAgIHZhcnMgPSBcImFsbFwiO1xuICAgIH1cblxuICAgIGlmICghdGFyZ2V0cyAmJiAoIXZhcnMgfHwgdmFycyA9PT0gXCJhbGxcIikpIHtcbiAgICAgIHRoaXMuX2xhenkgPSB0aGlzLl9wdCA9IDA7XG4gICAgICB0aGlzLnBhcmVudCA/IF9pbnRlcnJ1cHQodGhpcykgOiB0aGlzLnNjcm9sbFRyaWdnZXIgJiYgdGhpcy5zY3JvbGxUcmlnZ2VyLmtpbGwoISFfcmV2ZXJ0aW5nKTtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnRpbWVsaW5lKSB7XG4gICAgICB2YXIgdER1ciA9IHRoaXMudGltZWxpbmUudG90YWxEdXJhdGlvbigpO1xuICAgICAgdGhpcy50aW1lbGluZS5raWxsVHdlZW5zT2YodGFyZ2V0cywgdmFycywgX292ZXJ3cml0aW5nVHdlZW4gJiYgX292ZXJ3cml0aW5nVHdlZW4udmFycy5vdmVyd3JpdGUgIT09IHRydWUpLl9maXJzdCB8fCBfaW50ZXJydXB0KHRoaXMpOyAvLyBpZiBub3RoaW5nIGlzIGxlZnQgdHdlZW5pbmcsIGludGVycnVwdC5cblxuICAgICAgdGhpcy5wYXJlbnQgJiYgdER1ciAhPT0gdGhpcy50aW1lbGluZS50b3RhbER1cmF0aW9uKCkgJiYgX3NldER1cmF0aW9uKHRoaXMsIHRoaXMuX2R1ciAqIHRoaXMudGltZWxpbmUuX3REdXIgLyB0RHVyLCAwLCAxKTsgLy8gaWYgYSBuZXN0ZWQgdHdlZW4gaXMga2lsbGVkIHRoYXQgY2hhbmdlcyB0aGUgZHVyYXRpb24sIGl0IHNob3VsZCBhZmZlY3QgdGhpcyB0d2VlbidzIGR1cmF0aW9uLiBXZSBtdXN0IHVzZSB0aGUgcmF0aW8sIHRob3VnaCwgYmVjYXVzZSBzb21ldGltZXMgdGhlIGludGVybmFsIHRpbWVsaW5lIGlzIHN0cmV0Y2hlZCBsaWtlIGZvciBrZXlmcmFtZXMgd2hlcmUgdGhleSBkb24ndCBhbGwgYWRkIHVwIHRvIHdoYXRldmVyIHRoZSBwYXJlbnQgdHdlZW4ncyBkdXJhdGlvbiB3YXMgc2V0IHRvLlxuXG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICB2YXIgcGFyc2VkVGFyZ2V0cyA9IHRoaXMuX3RhcmdldHMsXG4gICAgICAgIGtpbGxpbmdUYXJnZXRzID0gdGFyZ2V0cyA/IHRvQXJyYXkodGFyZ2V0cykgOiBwYXJzZWRUYXJnZXRzLFxuICAgICAgICBwcm9wVHdlZW5Mb29rdXAgPSB0aGlzLl9wdExvb2t1cCxcbiAgICAgICAgZmlyc3RQVCA9IHRoaXMuX3B0LFxuICAgICAgICBvdmVyd3JpdHRlblByb3BzLFxuICAgICAgICBjdXJMb29rdXAsXG4gICAgICAgIGN1ck92ZXJ3cml0ZVByb3BzLFxuICAgICAgICBwcm9wcyxcbiAgICAgICAgcCxcbiAgICAgICAgcHQsXG4gICAgICAgIGk7XG5cbiAgICBpZiAoKCF2YXJzIHx8IHZhcnMgPT09IFwiYWxsXCIpICYmIF9hcnJheXNNYXRjaChwYXJzZWRUYXJnZXRzLCBraWxsaW5nVGFyZ2V0cykpIHtcbiAgICAgIHZhcnMgPT09IFwiYWxsXCIgJiYgKHRoaXMuX3B0ID0gMCk7XG4gICAgICByZXR1cm4gX2ludGVycnVwdCh0aGlzKTtcbiAgICB9XG5cbiAgICBvdmVyd3JpdHRlblByb3BzID0gdGhpcy5fb3AgPSB0aGlzLl9vcCB8fCBbXTtcblxuICAgIGlmICh2YXJzICE9PSBcImFsbFwiKSB7XG4gICAgICAvL3NvIHBlb3BsZSBjYW4gcGFzcyBpbiBhIGNvbW1hLWRlbGltaXRlZCBsaXN0IG9mIHByb3BlcnR5IG5hbWVzXG4gICAgICBpZiAoX2lzU3RyaW5nKHZhcnMpKSB7XG4gICAgICAgIHAgPSB7fTtcblxuICAgICAgICBfZm9yRWFjaE5hbWUodmFycywgZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgICAgICByZXR1cm4gcFtuYW1lXSA9IDE7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHZhcnMgPSBwO1xuICAgICAgfVxuXG4gICAgICB2YXJzID0gX2FkZEFsaWFzZXNUb1ZhcnMocGFyc2VkVGFyZ2V0cywgdmFycyk7XG4gICAgfVxuXG4gICAgaSA9IHBhcnNlZFRhcmdldHMubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGktLSkge1xuICAgICAgaWYgKH5raWxsaW5nVGFyZ2V0cy5pbmRleE9mKHBhcnNlZFRhcmdldHNbaV0pKSB7XG4gICAgICAgIGN1ckxvb2t1cCA9IHByb3BUd2Vlbkxvb2t1cFtpXTtcblxuICAgICAgICBpZiAodmFycyA9PT0gXCJhbGxcIikge1xuICAgICAgICAgIG92ZXJ3cml0dGVuUHJvcHNbaV0gPSB2YXJzO1xuICAgICAgICAgIHByb3BzID0gY3VyTG9va3VwO1xuICAgICAgICAgIGN1ck92ZXJ3cml0ZVByb3BzID0ge307XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY3VyT3ZlcndyaXRlUHJvcHMgPSBvdmVyd3JpdHRlblByb3BzW2ldID0gb3ZlcndyaXR0ZW5Qcm9wc1tpXSB8fCB7fTtcbiAgICAgICAgICBwcm9wcyA9IHZhcnM7XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKHAgaW4gcHJvcHMpIHtcbiAgICAgICAgICBwdCA9IGN1ckxvb2t1cCAmJiBjdXJMb29rdXBbcF07XG5cbiAgICAgICAgICBpZiAocHQpIHtcbiAgICAgICAgICAgIGlmICghKFwia2lsbFwiIGluIHB0LmQpIHx8IHB0LmQua2lsbChwKSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICBfcmVtb3ZlTGlua2VkTGlzdEl0ZW0odGhpcywgcHQsIFwiX3B0XCIpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBkZWxldGUgY3VyTG9va3VwW3BdO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChjdXJPdmVyd3JpdGVQcm9wcyAhPT0gXCJhbGxcIikge1xuICAgICAgICAgICAgY3VyT3ZlcndyaXRlUHJvcHNbcF0gPSAxO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMuX2luaXR0ZWQgJiYgIXRoaXMuX3B0ICYmIGZpcnN0UFQgJiYgX2ludGVycnVwdCh0aGlzKTsgLy9pZiBhbGwgdHdlZW5pbmcgcHJvcGVydGllcyBhcmUga2lsbGVkLCBraWxsIHRoZSB0d2Vlbi4gV2l0aG91dCB0aGlzIGxpbmUsIGlmIHRoZXJlJ3MgYSB0d2VlbiB3aXRoIG11bHRpcGxlIHRhcmdldHMgYW5kIHRoZW4geW91IGtpbGxUd2VlbnNPZigpIGVhY2ggdGFyZ2V0IGluZGl2aWR1YWxseSwgdGhlIHR3ZWVuIHdvdWxkIHRlY2huaWNhbGx5IHN0aWxsIHJlbWFpbiBhY3RpdmUgYW5kIGZpcmUgaXRzIG9uQ29tcGxldGUgZXZlbiB0aG91Z2ggdGhlcmUgYXJlbid0IGFueSBtb3JlIHByb3BlcnRpZXMgdHdlZW5pbmcuXG5cbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBUd2Vlbi50byA9IGZ1bmN0aW9uIHRvKHRhcmdldHMsIHZhcnMpIHtcbiAgICByZXR1cm4gbmV3IFR3ZWVuKHRhcmdldHMsIHZhcnMsIGFyZ3VtZW50c1syXSk7XG4gIH07XG5cbiAgVHdlZW4uZnJvbSA9IGZ1bmN0aW9uIGZyb20odGFyZ2V0cywgdmFycykge1xuICAgIHJldHVybiBfY3JlYXRlVHdlZW5UeXBlKDEsIGFyZ3VtZW50cyk7XG4gIH07XG5cbiAgVHdlZW4uZGVsYXllZENhbGwgPSBmdW5jdGlvbiBkZWxheWVkQ2FsbChkZWxheSwgY2FsbGJhY2ssIHBhcmFtcywgc2NvcGUpIHtcbiAgICByZXR1cm4gbmV3IFR3ZWVuKGNhbGxiYWNrLCAwLCB7XG4gICAgICBpbW1lZGlhdGVSZW5kZXI6IGZhbHNlLFxuICAgICAgbGF6eTogZmFsc2UsXG4gICAgICBvdmVyd3JpdGU6IGZhbHNlLFxuICAgICAgZGVsYXk6IGRlbGF5LFxuICAgICAgb25Db21wbGV0ZTogY2FsbGJhY2ssXG4gICAgICBvblJldmVyc2VDb21wbGV0ZTogY2FsbGJhY2ssXG4gICAgICBvbkNvbXBsZXRlUGFyYW1zOiBwYXJhbXMsXG4gICAgICBvblJldmVyc2VDb21wbGV0ZVBhcmFtczogcGFyYW1zLFxuICAgICAgY2FsbGJhY2tTY29wZTogc2NvcGVcbiAgICB9KTsgLy8gd2UgbXVzdCB1c2Ugb25SZXZlcnNlQ29tcGxldGUgdG9vIGZvciB0aGluZ3MgbGlrZSB0aW1lbGluZS5hZGQoKCkgPT4gey4uLn0pIHdoaWNoIHNob3VsZCBiZSB0cmlnZ2VyZWQgaW4gQk9USCBkaXJlY3Rpb25zIChmb3J3YXJkIGFuZCByZXZlcnNlKVxuICB9O1xuXG4gIFR3ZWVuLmZyb21UbyA9IGZ1bmN0aW9uIGZyb21Ubyh0YXJnZXRzLCBmcm9tVmFycywgdG9WYXJzKSB7XG4gICAgcmV0dXJuIF9jcmVhdGVUd2VlblR5cGUoMiwgYXJndW1lbnRzKTtcbiAgfTtcblxuICBUd2Vlbi5zZXQgPSBmdW5jdGlvbiBzZXQodGFyZ2V0cywgdmFycykge1xuICAgIHZhcnMuZHVyYXRpb24gPSAwO1xuICAgIHZhcnMucmVwZWF0RGVsYXkgfHwgKHZhcnMucmVwZWF0ID0gMCk7XG4gICAgcmV0dXJuIG5ldyBUd2Vlbih0YXJnZXRzLCB2YXJzKTtcbiAgfTtcblxuICBUd2Vlbi5raWxsVHdlZW5zT2YgPSBmdW5jdGlvbiBraWxsVHdlZW5zT2YodGFyZ2V0cywgcHJvcHMsIG9ubHlBY3RpdmUpIHtcbiAgICByZXR1cm4gX2dsb2JhbFRpbWVsaW5lLmtpbGxUd2VlbnNPZih0YXJnZXRzLCBwcm9wcywgb25seUFjdGl2ZSk7XG4gIH07XG5cbiAgcmV0dXJuIFR3ZWVuO1xufShBbmltYXRpb24pO1xuXG5fc2V0RGVmYXVsdHMoVHdlZW4ucHJvdG90eXBlLCB7XG4gIF90YXJnZXRzOiBbXSxcbiAgX2xhenk6IDAsXG4gIF9zdGFydEF0OiAwLFxuICBfb3A6IDAsXG4gIF9vbkluaXQ6IDBcbn0pOyAvL2FkZCB0aGUgcGVydGluZW50IHRpbWVsaW5lIG1ldGhvZHMgdG8gVHdlZW4gaW5zdGFuY2VzIHNvIHRoYXQgdXNlcnMgY2FuIGNoYWluIGNvbnZlbmllbnRseSBhbmQgY3JlYXRlIGEgdGltZWxpbmUgYXV0b21hdGljYWxseS4gKHJlbW92ZWQgZHVlIHRvIGNvbmNlcm5zIHRoYXQgaXQnZCB1bHRpbWF0ZWx5IGFkZCB0byBtb3JlIGNvbmZ1c2lvbiBlc3BlY2lhbGx5IGZvciBiZWdpbm5lcnMpXG4vLyBfZm9yRWFjaE5hbWUoXCJ0byxmcm9tLGZyb21UbyxzZXQsY2FsbCxhZGQsYWRkTGFiZWwsYWRkUGF1c2VcIiwgbmFtZSA9PiB7XG4vLyBcdFR3ZWVuLnByb3RvdHlwZVtuYW1lXSA9IGZ1bmN0aW9uKCkge1xuLy8gXHRcdGxldCB0bCA9IG5ldyBUaW1lbGluZSgpO1xuLy8gXHRcdHJldHVybiBfYWRkVG9UaW1lbGluZSh0bCwgdGhpcylbbmFtZV0uYXBwbHkodGwsIHRvQXJyYXkoYXJndW1lbnRzKSk7XG4vLyBcdH1cbi8vIH0pO1xuLy9mb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eS4gTGV2ZXJhZ2UgdGhlIHRpbWVsaW5lIGNhbGxzLlxuXG5cbl9mb3JFYWNoTmFtZShcInN0YWdnZXJUbyxzdGFnZ2VyRnJvbSxzdGFnZ2VyRnJvbVRvXCIsIGZ1bmN0aW9uIChuYW1lKSB7XG4gIFR3ZWVuW25hbWVdID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciB0bCA9IG5ldyBUaW1lbGluZSgpLFxuICAgICAgICBwYXJhbXMgPSBfc2xpY2UuY2FsbChhcmd1bWVudHMsIDApO1xuXG4gICAgcGFyYW1zLnNwbGljZShuYW1lID09PSBcInN0YWdnZXJGcm9tVG9cIiA/IDUgOiA0LCAwLCAwKTtcbiAgICByZXR1cm4gdGxbbmFtZV0uYXBwbHkodGwsIHBhcmFtcyk7XG4gIH07XG59KTtcbi8qXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogUFJPUFRXRUVOXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICovXG5cblxudmFyIF9zZXR0ZXJQbGFpbiA9IGZ1bmN0aW9uIF9zZXR0ZXJQbGFpbih0YXJnZXQsIHByb3BlcnR5LCB2YWx1ZSkge1xuICByZXR1cm4gdGFyZ2V0W3Byb3BlcnR5XSA9IHZhbHVlO1xufSxcbiAgICBfc2V0dGVyRnVuYyA9IGZ1bmN0aW9uIF9zZXR0ZXJGdW5jKHRhcmdldCwgcHJvcGVydHksIHZhbHVlKSB7XG4gIHJldHVybiB0YXJnZXRbcHJvcGVydHldKHZhbHVlKTtcbn0sXG4gICAgX3NldHRlckZ1bmNXaXRoUGFyYW0gPSBmdW5jdGlvbiBfc2V0dGVyRnVuY1dpdGhQYXJhbSh0YXJnZXQsIHByb3BlcnR5LCB2YWx1ZSwgZGF0YSkge1xuICByZXR1cm4gdGFyZ2V0W3Byb3BlcnR5XShkYXRhLmZwLCB2YWx1ZSk7XG59LFxuICAgIF9zZXR0ZXJBdHRyaWJ1dGUgPSBmdW5jdGlvbiBfc2V0dGVyQXR0cmlidXRlKHRhcmdldCwgcHJvcGVydHksIHZhbHVlKSB7XG4gIHJldHVybiB0YXJnZXQuc2V0QXR0cmlidXRlKHByb3BlcnR5LCB2YWx1ZSk7XG59LFxuICAgIF9nZXRTZXR0ZXIgPSBmdW5jdGlvbiBfZ2V0U2V0dGVyKHRhcmdldCwgcHJvcGVydHkpIHtcbiAgcmV0dXJuIF9pc0Z1bmN0aW9uKHRhcmdldFtwcm9wZXJ0eV0pID8gX3NldHRlckZ1bmMgOiBfaXNVbmRlZmluZWQodGFyZ2V0W3Byb3BlcnR5XSkgJiYgdGFyZ2V0LnNldEF0dHJpYnV0ZSA/IF9zZXR0ZXJBdHRyaWJ1dGUgOiBfc2V0dGVyUGxhaW47XG59LFxuICAgIF9yZW5kZXJQbGFpbiA9IGZ1bmN0aW9uIF9yZW5kZXJQbGFpbihyYXRpbywgZGF0YSkge1xuICByZXR1cm4gZGF0YS5zZXQoZGF0YS50LCBkYXRhLnAsIE1hdGgucm91bmQoKGRhdGEucyArIGRhdGEuYyAqIHJhdGlvKSAqIDEwMDAwMDApIC8gMTAwMDAwMCwgZGF0YSk7XG59LFxuICAgIF9yZW5kZXJCb29sZWFuID0gZnVuY3Rpb24gX3JlbmRlckJvb2xlYW4ocmF0aW8sIGRhdGEpIHtcbiAgcmV0dXJuIGRhdGEuc2V0KGRhdGEudCwgZGF0YS5wLCAhIShkYXRhLnMgKyBkYXRhLmMgKiByYXRpbyksIGRhdGEpO1xufSxcbiAgICBfcmVuZGVyQ29tcGxleFN0cmluZyA9IGZ1bmN0aW9uIF9yZW5kZXJDb21wbGV4U3RyaW5nKHJhdGlvLCBkYXRhKSB7XG4gIHZhciBwdCA9IGRhdGEuX3B0LFxuICAgICAgcyA9IFwiXCI7XG5cbiAgaWYgKCFyYXRpbyAmJiBkYXRhLmIpIHtcbiAgICAvL2IgPSBiZWdpbm5pbmcgc3RyaW5nXG4gICAgcyA9IGRhdGEuYjtcbiAgfSBlbHNlIGlmIChyYXRpbyA9PT0gMSAmJiBkYXRhLmUpIHtcbiAgICAvL2UgPSBlbmRpbmcgc3RyaW5nXG4gICAgcyA9IGRhdGEuZTtcbiAgfSBlbHNlIHtcbiAgICB3aGlsZSAocHQpIHtcbiAgICAgIHMgPSBwdC5wICsgKHB0Lm0gPyBwdC5tKHB0LnMgKyBwdC5jICogcmF0aW8pIDogTWF0aC5yb3VuZCgocHQucyArIHB0LmMgKiByYXRpbykgKiAxMDAwMCkgLyAxMDAwMCkgKyBzOyAvL3dlIHVzZSB0aGUgXCJwXCIgcHJvcGVydHkgZm9yIHRoZSB0ZXh0IGluYmV0d2VlbiAobGlrZSBhIHN1ZmZpeCkuIEFuZCBpbiB0aGUgY29udGV4dCBvZiBhIGNvbXBsZXggc3RyaW5nLCB0aGUgbW9kaWZpZXIgKG0pIGlzIHR5cGljYWxseSBqdXN0IE1hdGgucm91bmQoKSwgbGlrZSBmb3IgUkdCIGNvbG9ycy5cblxuICAgICAgcHQgPSBwdC5fbmV4dDtcbiAgICB9XG5cbiAgICBzICs9IGRhdGEuYzsgLy93ZSB1c2UgdGhlIFwiY1wiIG9mIHRoZSBQcm9wVHdlZW4gdG8gc3RvcmUgdGhlIGZpbmFsIGNodW5rIG9mIG5vbi1udW1lcmljIHRleHQuXG4gIH1cblxuICBkYXRhLnNldChkYXRhLnQsIGRhdGEucCwgcywgZGF0YSk7XG59LFxuICAgIF9yZW5kZXJQcm9wVHdlZW5zID0gZnVuY3Rpb24gX3JlbmRlclByb3BUd2VlbnMocmF0aW8sIGRhdGEpIHtcbiAgdmFyIHB0ID0gZGF0YS5fcHQ7XG5cbiAgd2hpbGUgKHB0KSB7XG4gICAgcHQucihyYXRpbywgcHQuZCk7XG4gICAgcHQgPSBwdC5fbmV4dDtcbiAgfVxufSxcbiAgICBfYWRkUGx1Z2luTW9kaWZpZXIgPSBmdW5jdGlvbiBfYWRkUGx1Z2luTW9kaWZpZXIobW9kaWZpZXIsIHR3ZWVuLCB0YXJnZXQsIHByb3BlcnR5KSB7XG4gIHZhciBwdCA9IHRoaXMuX3B0LFxuICAgICAgbmV4dDtcblxuICB3aGlsZSAocHQpIHtcbiAgICBuZXh0ID0gcHQuX25leHQ7XG4gICAgcHQucCA9PT0gcHJvcGVydHkgJiYgcHQubW9kaWZpZXIobW9kaWZpZXIsIHR3ZWVuLCB0YXJnZXQpO1xuICAgIHB0ID0gbmV4dDtcbiAgfVxufSxcbiAgICBfa2lsbFByb3BUd2VlbnNPZiA9IGZ1bmN0aW9uIF9raWxsUHJvcFR3ZWVuc09mKHByb3BlcnR5KSB7XG4gIHZhciBwdCA9IHRoaXMuX3B0LFxuICAgICAgaGFzTm9uRGVwZW5kZW50UmVtYWluaW5nLFxuICAgICAgbmV4dDtcblxuICB3aGlsZSAocHQpIHtcbiAgICBuZXh0ID0gcHQuX25leHQ7XG5cbiAgICBpZiAocHQucCA9PT0gcHJvcGVydHkgJiYgIXB0Lm9wIHx8IHB0Lm9wID09PSBwcm9wZXJ0eSkge1xuICAgICAgX3JlbW92ZUxpbmtlZExpc3RJdGVtKHRoaXMsIHB0LCBcIl9wdFwiKTtcbiAgICB9IGVsc2UgaWYgKCFwdC5kZXApIHtcbiAgICAgIGhhc05vbkRlcGVuZGVudFJlbWFpbmluZyA9IDE7XG4gICAgfVxuXG4gICAgcHQgPSBuZXh0O1xuICB9XG5cbiAgcmV0dXJuICFoYXNOb25EZXBlbmRlbnRSZW1haW5pbmc7XG59LFxuICAgIF9zZXR0ZXJXaXRoTW9kaWZpZXIgPSBmdW5jdGlvbiBfc2V0dGVyV2l0aE1vZGlmaWVyKHRhcmdldCwgcHJvcGVydHksIHZhbHVlLCBkYXRhKSB7XG4gIGRhdGEubVNldCh0YXJnZXQsIHByb3BlcnR5LCBkYXRhLm0uY2FsbChkYXRhLnR3ZWVuLCB2YWx1ZSwgZGF0YS5tdCksIGRhdGEpO1xufSxcbiAgICBfc29ydFByb3BUd2VlbnNCeVByaW9yaXR5ID0gZnVuY3Rpb24gX3NvcnRQcm9wVHdlZW5zQnlQcmlvcml0eShwYXJlbnQpIHtcbiAgdmFyIHB0ID0gcGFyZW50Ll9wdCxcbiAgICAgIG5leHQsXG4gICAgICBwdDIsXG4gICAgICBmaXJzdCxcbiAgICAgIGxhc3Q7IC8vc29ydHMgdGhlIFByb3BUd2VlbiBsaW5rZWQgbGlzdCBpbiBvcmRlciBvZiBwcmlvcml0eSBiZWNhdXNlIHNvbWUgcGx1Z2lucyBuZWVkIHRvIGRvIHRoZWlyIHdvcmsgYWZ0ZXIgQUxMIG9mIHRoZSBQcm9wVHdlZW5zIHdlcmUgY3JlYXRlZCAobGlrZSBSb3VuZFByb3BzUGx1Z2luIGFuZCBNb2RpZmllcnNQbHVnaW4pXG5cbiAgd2hpbGUgKHB0KSB7XG4gICAgbmV4dCA9IHB0Ll9uZXh0O1xuICAgIHB0MiA9IGZpcnN0O1xuXG4gICAgd2hpbGUgKHB0MiAmJiBwdDIucHIgPiBwdC5wcikge1xuICAgICAgcHQyID0gcHQyLl9uZXh0O1xuICAgIH1cblxuICAgIGlmIChwdC5fcHJldiA9IHB0MiA/IHB0Mi5fcHJldiA6IGxhc3QpIHtcbiAgICAgIHB0Ll9wcmV2Ll9uZXh0ID0gcHQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZpcnN0ID0gcHQ7XG4gICAgfVxuXG4gICAgaWYgKHB0Ll9uZXh0ID0gcHQyKSB7XG4gICAgICBwdDIuX3ByZXYgPSBwdDtcbiAgICB9IGVsc2Uge1xuICAgICAgbGFzdCA9IHB0O1xuICAgIH1cblxuICAgIHB0ID0gbmV4dDtcbiAgfVxuXG4gIHBhcmVudC5fcHQgPSBmaXJzdDtcbn07IC8vUHJvcFR3ZWVuIGtleTogdCA9IHRhcmdldCwgcCA9IHByb3AsIHIgPSByZW5kZXJlciwgZCA9IGRhdGEsIHMgPSBzdGFydCwgYyA9IGNoYW5nZSwgb3AgPSBvdmVyd3JpdGVQcm9wZXJ0eSAoT05MWSBwb3B1bGF0ZWQgd2hlbiBpdCdzIGRpZmZlcmVudCB0aGFuIHApLCBwciA9IHByaW9yaXR5LCBfbmV4dC9fcHJldiBmb3IgdGhlIGxpbmtlZCBsaXN0IHNpYmxpbmdzLCBzZXQgPSBzZXR0ZXIsIG0gPSBtb2RpZmllciwgbVNldCA9IG1vZGlmaWVyU2V0dGVyICh0aGUgb3JpZ2luYWwgc2V0dGVyLCBiZWZvcmUgYSBtb2RpZmllciB3YXMgYWRkZWQpXG5cblxuZXhwb3J0IHZhciBQcm9wVHdlZW4gPSAvKiNfX1BVUkVfXyovZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBQcm9wVHdlZW4obmV4dCwgdGFyZ2V0LCBwcm9wLCBzdGFydCwgY2hhbmdlLCByZW5kZXJlciwgZGF0YSwgc2V0dGVyLCBwcmlvcml0eSkge1xuICAgIHRoaXMudCA9IHRhcmdldDtcbiAgICB0aGlzLnMgPSBzdGFydDtcbiAgICB0aGlzLmMgPSBjaGFuZ2U7XG4gICAgdGhpcy5wID0gcHJvcDtcbiAgICB0aGlzLnIgPSByZW5kZXJlciB8fCBfcmVuZGVyUGxhaW47XG4gICAgdGhpcy5kID0gZGF0YSB8fCB0aGlzO1xuICAgIHRoaXMuc2V0ID0gc2V0dGVyIHx8IF9zZXR0ZXJQbGFpbjtcbiAgICB0aGlzLnByID0gcHJpb3JpdHkgfHwgMDtcbiAgICB0aGlzLl9uZXh0ID0gbmV4dDtcblxuICAgIGlmIChuZXh0KSB7XG4gICAgICBuZXh0Ll9wcmV2ID0gdGhpcztcbiAgICB9XG4gIH1cblxuICB2YXIgX3Byb3RvNCA9IFByb3BUd2Vlbi5wcm90b3R5cGU7XG5cbiAgX3Byb3RvNC5tb2RpZmllciA9IGZ1bmN0aW9uIG1vZGlmaWVyKGZ1bmMsIHR3ZWVuLCB0YXJnZXQpIHtcbiAgICB0aGlzLm1TZXQgPSB0aGlzLm1TZXQgfHwgdGhpcy5zZXQ7IC8vaW4gY2FzZSBpdCB3YXMgYWxyZWFkeSBzZXQgKGEgUHJvcFR3ZWVuIGNhbiBvbmx5IGhhdmUgb25lIG1vZGlmaWVyKVxuXG4gICAgdGhpcy5zZXQgPSBfc2V0dGVyV2l0aE1vZGlmaWVyO1xuICAgIHRoaXMubSA9IGZ1bmM7XG4gICAgdGhpcy5tdCA9IHRhcmdldDsgLy9tb2RpZmllciB0YXJnZXRcblxuICAgIHRoaXMudHdlZW4gPSB0d2VlbjtcbiAgfTtcblxuICByZXR1cm4gUHJvcFR3ZWVuO1xufSgpOyAvL0luaXRpYWxpemF0aW9uIHRhc2tzXG5cbl9mb3JFYWNoTmFtZShfY2FsbGJhY2tOYW1lcyArIFwicGFyZW50LGR1cmF0aW9uLGVhc2UsZGVsYXksb3ZlcndyaXRlLHJ1bkJhY2t3YXJkcyxzdGFydEF0LHlveW8saW1tZWRpYXRlUmVuZGVyLHJlcGVhdCxyZXBlYXREZWxheSxkYXRhLHBhdXNlZCxyZXZlcnNlZCxsYXp5LGNhbGxiYWNrU2NvcGUsc3RyaW5nRmlsdGVyLGlkLHlveW9FYXNlLHN0YWdnZXIsaW5oZXJpdCxyZXBlYXRSZWZyZXNoLGtleWZyYW1lcyxhdXRvUmV2ZXJ0LHNjcm9sbFRyaWdnZXIsZWFzZVJldmVyc2VcIiwgZnVuY3Rpb24gKG5hbWUpIHtcbiAgcmV0dXJuIF9yZXNlcnZlZFByb3BzW25hbWVdID0gMTtcbn0pO1xuXG5fZ2xvYmFscy5Ud2Vlbk1heCA9IF9nbG9iYWxzLlR3ZWVuTGl0ZSA9IFR3ZWVuO1xuX2dsb2JhbHMuVGltZWxpbmVMaXRlID0gX2dsb2JhbHMuVGltZWxpbmVNYXggPSBUaW1lbGluZTtcbl9nbG9iYWxUaW1lbGluZSA9IG5ldyBUaW1lbGluZSh7XG4gIHNvcnRDaGlsZHJlbjogZmFsc2UsXG4gIGRlZmF1bHRzOiBfZGVmYXVsdHMsXG4gIGF1dG9SZW1vdmVDaGlsZHJlbjogdHJ1ZSxcbiAgaWQ6IFwicm9vdFwiLFxuICBzbW9vdGhDaGlsZFRpbWluZzogdHJ1ZVxufSk7XG5fY29uZmlnLnN0cmluZ0ZpbHRlciA9IF9jb2xvclN0cmluZ0ZpbHRlcjtcblxudmFyIF9tZWRpYSA9IFtdLFxuICAgIF9saXN0ZW5lcnMgPSB7fSxcbiAgICBfZW1wdHlBcnJheSA9IFtdLFxuICAgIF9sYXN0TWVkaWFUaW1lID0gMCxcbiAgICBfY29udGV4dElEID0gMCxcbiAgICBfZGlzcGF0Y2ggPSBmdW5jdGlvbiBfZGlzcGF0Y2godHlwZSkge1xuICByZXR1cm4gKF9saXN0ZW5lcnNbdHlwZV0gfHwgX2VtcHR5QXJyYXkpLm1hcChmdW5jdGlvbiAoZikge1xuICAgIHJldHVybiBmKCk7XG4gIH0pO1xufSxcbiAgICBfb25NZWRpYUNoYW5nZSA9IGZ1bmN0aW9uIF9vbk1lZGlhQ2hhbmdlKCkge1xuICB2YXIgdGltZSA9IERhdGUubm93KCksXG4gICAgICBtYXRjaGVzID0gW107XG5cbiAgaWYgKHRpbWUgLSBfbGFzdE1lZGlhVGltZSA+IDIpIHtcbiAgICBfZGlzcGF0Y2goXCJtYXRjaE1lZGlhSW5pdFwiKTtcblxuICAgIF9tZWRpYS5mb3JFYWNoKGZ1bmN0aW9uIChjKSB7XG4gICAgICB2YXIgcXVlcmllcyA9IGMucXVlcmllcyxcbiAgICAgICAgICBjb25kaXRpb25zID0gYy5jb25kaXRpb25zLFxuICAgICAgICAgIG1hdGNoLFxuICAgICAgICAgIHAsXG4gICAgICAgICAgYW55TWF0Y2gsXG4gICAgICAgICAgdG9nZ2xlZDtcblxuICAgICAgZm9yIChwIGluIHF1ZXJpZXMpIHtcbiAgICAgICAgbWF0Y2ggPSBfd2luLm1hdGNoTWVkaWEocXVlcmllc1twXSkubWF0Y2hlczsgLy8gRmlyZWZveCBkb2Vzbid0IHVwZGF0ZSB0aGUgXCJtYXRjaGVzXCIgcHJvcGVydHkgb2YgdGhlIE1lZGlhUXVlcnlMaXN0IG9iamVjdCBjb3JyZWN0bHkgLSBpdCBvbmx5IGRvZXMgc28gYXMgaXQgY2FsbHMgaXRzIGNoYW5nZSBoYW5kbGVyIC0gc28gd2UgbXVzdCByZS1jcmVhdGUgYSBtZWRpYSBxdWVyeSBoZXJlIHRvIGVuc3VyZSBpdCdzIGFjY3VyYXRlLlxuXG4gICAgICAgIG1hdGNoICYmIChhbnlNYXRjaCA9IDEpO1xuXG4gICAgICAgIGlmIChtYXRjaCAhPT0gY29uZGl0aW9uc1twXSkge1xuICAgICAgICAgIGNvbmRpdGlvbnNbcF0gPSBtYXRjaDtcbiAgICAgICAgICB0b2dnbGVkID0gMTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAodG9nZ2xlZCkge1xuICAgICAgICBjLnJldmVydCgpO1xuICAgICAgICBhbnlNYXRjaCAmJiBtYXRjaGVzLnB1c2goYyk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBfZGlzcGF0Y2goXCJtYXRjaE1lZGlhUmV2ZXJ0XCIpO1xuXG4gICAgbWF0Y2hlcy5mb3JFYWNoKGZ1bmN0aW9uIChjKSB7XG4gICAgICByZXR1cm4gYy5vbk1hdGNoKGMsIGZ1bmN0aW9uIChmdW5jKSB7XG4gICAgICAgIHJldHVybiBjLmFkZChudWxsLCBmdW5jKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIF9sYXN0TWVkaWFUaW1lID0gdGltZTtcblxuICAgIF9kaXNwYXRjaChcIm1hdGNoTWVkaWFcIik7XG4gIH1cbn07XG5cbnZhciBDb250ZXh0ID0gLyojX19QVVJFX18qL2Z1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gQ29udGV4dChmdW5jLCBzY29wZSkge1xuICAgIHRoaXMuc2VsZWN0b3IgPSBzY29wZSAmJiBzZWxlY3RvcihzY29wZSk7XG4gICAgdGhpcy5kYXRhID0gW107XG4gICAgdGhpcy5fciA9IFtdOyAvLyByZXR1cm5lZC9jbGVhbnVwIGZ1bmN0aW9uc1xuXG4gICAgdGhpcy5pc1JldmVydGVkID0gZmFsc2U7XG4gICAgdGhpcy5pZCA9IF9jb250ZXh0SUQrKzsgLy8gdG8gd29yayBhcm91bmQgaXNzdWVzIHRoYXQgZnJhbWV3b3JrcyBsaWtlIFZ1ZSBjYXVzZSBieSBtYWtpbmcgdGhpbmdzIGludG8gUHJveGllcyB3aGljaCBtYWtlIGl0IGltcG9zc2libGUgdG8gZG8gc29tZXRoaW5nIGxpa2UgX21lZGlhLmluZGV4T2YodGhpcykgYmVjYXVzZSBcInRoaXNcIiB3b3VsZCBubyBsb25nZXIgcmVmZXIgdG8gdGhlIENvbnRleHQgaW5zdGFuY2UgaXRzZWxmIC0gaXQnZCByZWZlciB0byBhIFByb3h5ISBXZSBuZWVkZWQgYSB3YXkgdG8gaWRlbnRpZnkgdGhlIGNvbnRleHQgdW5pcXVlbHlcblxuICAgIGZ1bmMgJiYgdGhpcy5hZGQoZnVuYyk7XG4gIH1cblxuICB2YXIgX3Byb3RvNSA9IENvbnRleHQucHJvdG90eXBlO1xuXG4gIF9wcm90bzUuYWRkID0gZnVuY3Rpb24gYWRkKG5hbWUsIGZ1bmMsIHNjb3BlKSB7XG4gICAgLy8gcG9zc2libGUgZnV0dXJlIGFkZGl0aW9uIGlmIHdlIG5lZWQgdGhlIGFiaWxpdHkgdG8gYWRkKCkgYW4gYW5pbWF0aW9uIHRvIGEgY29udGV4dCBhbmQgZm9yIHdoYXRldmVyIHJlYXNvbiBjYW5ub3QgY3JlYXRlIHRoYXQgYW5pbWF0aW9uIGluc2lkZSBvZiBhIGNvbnRleHQuYWRkKCgpID0+IHsuLi59KSBmdW5jdGlvbi5cbiAgICAvLyBpZiAobmFtZSAmJiBfaXNGdW5jdGlvbihuYW1lLnJldmVydCkpIHtcbiAgICAvLyBcdHRoaXMuZGF0YS5wdXNoKG5hbWUpO1xuICAgIC8vIFx0cmV0dXJuIChuYW1lLl9jdHggPSB0aGlzKTtcbiAgICAvLyB9XG4gICAgaWYgKF9pc0Z1bmN0aW9uKG5hbWUpKSB7XG4gICAgICBzY29wZSA9IGZ1bmM7XG4gICAgICBmdW5jID0gbmFtZTtcbiAgICAgIG5hbWUgPSBfaXNGdW5jdGlvbjtcbiAgICB9XG5cbiAgICB2YXIgc2VsZiA9IHRoaXMsXG4gICAgICAgIGYgPSBmdW5jdGlvbiBmKCkge1xuICAgICAgdmFyIHByZXYgPSBfY29udGV4dCxcbiAgICAgICAgICBwcmV2U2VsZWN0b3IgPSBzZWxmLnNlbGVjdG9yLFxuICAgICAgICAgIHJlc3VsdDtcbiAgICAgIHByZXYgJiYgcHJldiAhPT0gc2VsZiAmJiBwcmV2LmRhdGEucHVzaChzZWxmKTtcbiAgICAgIHNjb3BlICYmIChzZWxmLnNlbGVjdG9yID0gc2VsZWN0b3Ioc2NvcGUpKTtcbiAgICAgIF9jb250ZXh0ID0gc2VsZjtcbiAgICAgIHJlc3VsdCA9IGZ1bmMuYXBwbHkoc2VsZiwgYXJndW1lbnRzKTtcbiAgICAgIF9pc0Z1bmN0aW9uKHJlc3VsdCkgJiYgc2VsZi5fci5wdXNoKHJlc3VsdCk7XG4gICAgICBfY29udGV4dCA9IHByZXY7XG4gICAgICBzZWxmLnNlbGVjdG9yID0gcHJldlNlbGVjdG9yO1xuICAgICAgc2VsZi5pc1JldmVydGVkID0gZmFsc2U7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH07XG5cbiAgICBzZWxmLmxhc3QgPSBmO1xuICAgIHJldHVybiBuYW1lID09PSBfaXNGdW5jdGlvbiA/IGYoc2VsZiwgZnVuY3Rpb24gKGZ1bmMpIHtcbiAgICAgIHJldHVybiBzZWxmLmFkZChudWxsLCBmdW5jKTtcbiAgICB9KSA6IG5hbWUgPyBzZWxmW25hbWVdID0gZiA6IGY7XG4gIH07XG5cbiAgX3Byb3RvNS5pZ25vcmUgPSBmdW5jdGlvbiBpZ25vcmUoZnVuYykge1xuICAgIHZhciBwcmV2ID0gX2NvbnRleHQ7XG4gICAgX2NvbnRleHQgPSBudWxsO1xuICAgIGZ1bmModGhpcyk7XG4gICAgX2NvbnRleHQgPSBwcmV2O1xuICB9O1xuXG4gIF9wcm90bzUuZ2V0VHdlZW5zID0gZnVuY3Rpb24gZ2V0VHdlZW5zKCkge1xuICAgIHZhciBhID0gW107XG4gICAgdGhpcy5kYXRhLmZvckVhY2goZnVuY3Rpb24gKGUpIHtcbiAgICAgIHJldHVybiBlIGluc3RhbmNlb2YgQ29udGV4dCA/IGEucHVzaC5hcHBseShhLCBlLmdldFR3ZWVucygpKSA6IGUgaW5zdGFuY2VvZiBUd2VlbiAmJiAhKGUucGFyZW50ICYmIGUucGFyZW50LmRhdGEgPT09IFwibmVzdGVkXCIpICYmIGEucHVzaChlKTtcbiAgICB9KTtcbiAgICByZXR1cm4gYTtcbiAgfTtcblxuICBfcHJvdG81LmNsZWFyID0gZnVuY3Rpb24gY2xlYXIoKSB7XG4gICAgdGhpcy5fci5sZW5ndGggPSB0aGlzLmRhdGEubGVuZ3RoID0gMDtcbiAgfTtcblxuICBfcHJvdG81LmtpbGwgPSBmdW5jdGlvbiBraWxsKHJldmVydCwgbWF0Y2hNZWRpYSkge1xuICAgIHZhciBfdGhpczQgPSB0aGlzO1xuXG4gICAgaWYgKHJldmVydCkge1xuICAgICAgKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHR3ZWVucyA9IF90aGlzNC5nZXRUd2VlbnMoKSxcbiAgICAgICAgICAgIGkgPSBfdGhpczQuZGF0YS5sZW5ndGgsXG4gICAgICAgICAgICB0O1xuXG4gICAgICAgIHdoaWxlIChpLS0pIHtcbiAgICAgICAgICAvLyBGbGlwIHBsdWdpbiB0d2VlbnMgYXJlIHZlcnkgZGlmZmVyZW50IGluIHRoYXQgdGhleSBzaG91bGQgYWN0dWFsbHkgYmUgcHVzaGVkIHRvIHRoZWlyIGVuZC4gVGhlIHBsdWdpbiByZXBsYWNlcyB0aGUgdGltZWxpbmUncyAucmV2ZXJ0KCkgbWV0aG9kIHRvIGRvIGV4YWN0bHkgdGhhdC4gQnV0IHdlIGFsc28gbmVlZCB0byByZW1vdmUgYW55IG9mIHRob3NlIG5lc3RlZCB0d2VlbnMgaW5zaWRlIHRoZSBmbGlwIHRpbWVsaW5lIHNvIHRoYXQgdGhleSBkb24ndCBnZXQgaW5kaXZpZHVhbGx5IHJldmVydGVkLlxuICAgICAgICAgIHQgPSBfdGhpczQuZGF0YVtpXTtcblxuICAgICAgICAgIGlmICh0LmRhdGEgPT09IFwiaXNGbGlwXCIpIHtcbiAgICAgICAgICAgIHQucmV2ZXJ0KCk7XG4gICAgICAgICAgICB0LmdldENoaWxkcmVuKHRydWUsIHRydWUsIGZhbHNlKS5mb3JFYWNoKGZ1bmN0aW9uICh0d2Vlbikge1xuICAgICAgICAgICAgICByZXR1cm4gdHdlZW5zLnNwbGljZSh0d2VlbnMuaW5kZXhPZih0d2VlbiksIDEpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IC8vIHNhdmUgYXMgYW4gb2JqZWN0IHNvIHRoYXQgd2UgY2FuIGNhY2hlIHRoZSBnbG9iYWxUaW1lIGZvciBlYWNoIHR3ZWVuIHRvIG9wdGltaXplIHBlcmZvcm1hbmNlIGR1cmluZyB0aGUgc29ydFxuXG5cbiAgICAgICAgdHdlZW5zLm1hcChmdW5jdGlvbiAodCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBnOiB0Ll9kdXIgfHwgdC5fZGVsYXkgfHwgdC5fc2F0ICYmICF0Ll9zYXQudmFycy5pbW1lZGlhdGVSZW5kZXIgPyB0Lmdsb2JhbFRpbWUoMCkgOiAtSW5maW5pdHksXG4gICAgICAgICAgICB0OiB0XG4gICAgICAgICAgfTtcbiAgICAgICAgfSkuc29ydChmdW5jdGlvbiAoYSwgYikge1xuICAgICAgICAgIHJldHVybiBiLmcgLSBhLmcgfHwgLUluZmluaXR5O1xuICAgICAgICB9KS5mb3JFYWNoKGZ1bmN0aW9uIChvKSB7XG4gICAgICAgICAgcmV0dXJuIG8udC5yZXZlcnQocmV2ZXJ0KTtcbiAgICAgICAgfSk7IC8vIG5vdGU6IGFsbCBvZiB0aGUgX3N0YXJ0QXQgdHdlZW5zIHNob3VsZCBiZSByZXZlcnRlZCBpbiByZXZlcnNlIG9yZGVyIHRoYXQgdGhleSB3ZXJlIGNyZWF0ZWQsIGFuZCB0aGV5J2xsIGFsbCBoYXZlIHRoZSBzYW1lIGdsb2JhbFRpbWUgKC0xKSBzbyB0aGUgXCIgfHwgLTFcIiBpbiB0aGUgc29ydCBrZWVwcyB0aGUgb3JkZXIgcHJvcGVybHkuXG5cbiAgICAgICAgaSA9IF90aGlzNC5kYXRhLmxlbmd0aDtcblxuICAgICAgICB3aGlsZSAoaS0tKSB7XG4gICAgICAgICAgLy8gbWFrZSBzdXJlIHdlIGxvb3AgYmFja3dhcmRzIHNvIHRoYXQsIGZvciBleGFtcGxlLCBTcGxpdFRleHRzIHRoYXQgd2VyZSBjcmVhdGVkIGxhdGVyIG9uIHRoZSBzYW1lIGVsZW1lbnQgZ2V0IHJldmVydGVkIGZpcnN0XG4gICAgICAgICAgdCA9IF90aGlzNC5kYXRhW2ldO1xuXG4gICAgICAgICAgaWYgKHQgaW5zdGFuY2VvZiBUaW1lbGluZSkge1xuICAgICAgICAgICAgaWYgKHQuZGF0YSAhPT0gXCJuZXN0ZWRcIikge1xuICAgICAgICAgICAgICB0LnNjcm9sbFRyaWdnZXIgJiYgdC5zY3JvbGxUcmlnZ2VyLnJldmVydCgpO1xuICAgICAgICAgICAgICB0LmtpbGwoKTsgLy8gZG9uJ3QgcmV2ZXJ0KCkgdGhlIHRpbWVsaW5lIGJlY2F1c2UgdGhhdCdzIGR1cGxpY2F0aW5nIGVmZm9ydHMgc2luY2Ugd2UgYWxyZWFkeSByZXZlcnRlZCBhbGwgdGhlIHR3ZWVuc1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAhKHQgaW5zdGFuY2VvZiBUd2VlbikgJiYgdC5yZXZlcnQgJiYgdC5yZXZlcnQocmV2ZXJ0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBfdGhpczQuX3IuZm9yRWFjaChmdW5jdGlvbiAoZikge1xuICAgICAgICAgIHJldHVybiBmKHJldmVydCwgX3RoaXM0KTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgX3RoaXM0LmlzUmV2ZXJ0ZWQgPSB0cnVlO1xuICAgICAgfSkoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5kYXRhLmZvckVhY2goZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgcmV0dXJuIGUua2lsbCAmJiBlLmtpbGwoKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHRoaXMuY2xlYXIoKTtcblxuICAgIGlmIChtYXRjaE1lZGlhKSB7XG4gICAgICB2YXIgaSA9IF9tZWRpYS5sZW5ndGg7XG5cbiAgICAgIHdoaWxlIChpLS0pIHtcbiAgICAgICAgLy8gcHJldmlvdXNseSwgd2UgY2hlY2tlZCBfbWVkaWEuaW5kZXhPZih0aGlzKSwgYnV0IHNvbWUgZnJhbWV3b3JrcyBsaWtlIFZ1ZSBlbmZvcmNlIFByb3h5IG9iamVjdHMgdGhhdCBtYWtlIGl0IGltcG9zc2libGUgdG8gZ2V0IHRoZSBwcm9wZXIgcmVzdWx0IHRoYXQgd2F5LCBzbyB3ZSBtdXN0IHVzZSBhIHVuaXF1ZSBJRCBudW1iZXIgaW5zdGVhZC5cbiAgICAgICAgX21lZGlhW2ldLmlkID09PSB0aGlzLmlkICYmIF9tZWRpYS5zcGxpY2UoaSwgMSk7XG4gICAgICB9XG4gICAgfVxuICB9IC8vIGtpbGxXaXRoQ2xlYW51cCgpIHtcbiAgLy8gXHR0aGlzLmtpbGwoKTtcbiAgLy8gXHR0aGlzLl9yLmZvckVhY2goZiA9PiBmKGZhbHNlLCB0aGlzKSk7XG4gIC8vIH1cbiAgO1xuXG4gIF9wcm90bzUucmV2ZXJ0ID0gZnVuY3Rpb24gcmV2ZXJ0KGNvbmZpZykge1xuICAgIHRoaXMua2lsbChjb25maWcgfHwge30pO1xuICB9O1xuXG4gIHJldHVybiBDb250ZXh0O1xufSgpO1xuXG52YXIgTWF0Y2hNZWRpYSA9IC8qI19fUFVSRV9fKi9mdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIE1hdGNoTWVkaWEoc2NvcGUpIHtcbiAgICB0aGlzLmNvbnRleHRzID0gW107XG4gICAgdGhpcy5zY29wZSA9IHNjb3BlO1xuICAgIF9jb250ZXh0ICYmIF9jb250ZXh0LmRhdGEucHVzaCh0aGlzKTtcbiAgfVxuXG4gIHZhciBfcHJvdG82ID0gTWF0Y2hNZWRpYS5wcm90b3R5cGU7XG5cbiAgX3Byb3RvNi5hZGQgPSBmdW5jdGlvbiBhZGQoY29uZGl0aW9ucywgZnVuYywgc2NvcGUpIHtcbiAgICBfaXNPYmplY3QoY29uZGl0aW9ucykgfHwgKGNvbmRpdGlvbnMgPSB7XG4gICAgICBtYXRjaGVzOiBjb25kaXRpb25zXG4gICAgfSk7XG4gICAgdmFyIGNvbnRleHQgPSBuZXcgQ29udGV4dCgwLCBzY29wZSB8fCB0aGlzLnNjb3BlKSxcbiAgICAgICAgY29uZCA9IGNvbnRleHQuY29uZGl0aW9ucyA9IHt9LFxuICAgICAgICBtcSxcbiAgICAgICAgcCxcbiAgICAgICAgYWN0aXZlO1xuICAgIF9jb250ZXh0ICYmICFjb250ZXh0LnNlbGVjdG9yICYmIChjb250ZXh0LnNlbGVjdG9yID0gX2NvbnRleHQuc2VsZWN0b3IpOyAvLyBpbiBjYXNlIGEgY29udGV4dCBpcyBjcmVhdGVkIGluc2lkZSBhIGNvbnRleHQuIExpa2UgYSBnc2FwLm1hdGNoTWVkaWEoKSB0aGF0J3MgaW5zaWRlIGEgc2NvcGVkIGdzYXAuY29udGV4dCgpXG5cbiAgICB0aGlzLmNvbnRleHRzLnB1c2goY29udGV4dCk7XG4gICAgZnVuYyA9IGNvbnRleHQuYWRkKFwib25NYXRjaFwiLCBmdW5jKTtcbiAgICBjb250ZXh0LnF1ZXJpZXMgPSBjb25kaXRpb25zO1xuXG4gICAgZm9yIChwIGluIGNvbmRpdGlvbnMpIHtcbiAgICAgIGlmIChwID09PSBcImFsbFwiKSB7XG4gICAgICAgIGFjdGl2ZSA9IDE7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBtcSA9IF93aW4ubWF0Y2hNZWRpYShjb25kaXRpb25zW3BdKTtcblxuICAgICAgICBpZiAobXEpIHtcbiAgICAgICAgICBfbWVkaWEuaW5kZXhPZihjb250ZXh0KSA8IDAgJiYgX21lZGlhLnB1c2goY29udGV4dCk7XG4gICAgICAgICAgKGNvbmRbcF0gPSBtcS5tYXRjaGVzKSAmJiAoYWN0aXZlID0gMSk7XG4gICAgICAgICAgbXEuYWRkTGlzdGVuZXIgPyBtcS5hZGRMaXN0ZW5lcihfb25NZWRpYUNoYW5nZSkgOiBtcS5hZGRFdmVudExpc3RlbmVyKFwiY2hhbmdlXCIsIF9vbk1lZGlhQ2hhbmdlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIGFjdGl2ZSAmJiBmdW5jKGNvbnRleHQsIGZ1bmN0aW9uIChmKSB7XG4gICAgICByZXR1cm4gY29udGV4dC5hZGQobnVsbCwgZik7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH0gLy8gcmVmcmVzaCgpIHtcbiAgLy8gXHRsZXQgdGltZSA9IF9sYXN0TWVkaWFUaW1lLFxuICAvLyBcdFx0bWVkaWEgPSBfbWVkaWE7XG4gIC8vIFx0X2xhc3RNZWRpYVRpbWUgPSAtMTtcbiAgLy8gXHRfbWVkaWEgPSB0aGlzLmNvbnRleHRzO1xuICAvLyBcdF9vbk1lZGlhQ2hhbmdlKCk7XG4gIC8vIFx0X2xhc3RNZWRpYVRpbWUgPSB0aW1lO1xuICAvLyBcdF9tZWRpYSA9IG1lZGlhO1xuICAvLyB9XG4gIDtcblxuICBfcHJvdG82LnJldmVydCA9IGZ1bmN0aW9uIHJldmVydChjb25maWcpIHtcbiAgICB0aGlzLmtpbGwoY29uZmlnIHx8IHt9KTtcbiAgfTtcblxuICBfcHJvdG82LmtpbGwgPSBmdW5jdGlvbiBraWxsKHJldmVydCkge1xuICAgIHRoaXMuY29udGV4dHMuZm9yRWFjaChmdW5jdGlvbiAoYykge1xuICAgICAgcmV0dXJuIGMua2lsbChyZXZlcnQsIHRydWUpO1xuICAgIH0pO1xuICB9O1xuXG4gIHJldHVybiBNYXRjaE1lZGlhO1xufSgpO1xuLypcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiBHU0FQXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICovXG5cblxudmFyIF9nc2FwID0ge1xuICByZWdpc3RlclBsdWdpbjogZnVuY3Rpb24gcmVnaXN0ZXJQbHVnaW4oKSB7XG4gICAgZm9yICh2YXIgX2xlbjIgPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4yKSwgX2tleTIgPSAwOyBfa2V5MiA8IF9sZW4yOyBfa2V5MisrKSB7XG4gICAgICBhcmdzW19rZXkyXSA9IGFyZ3VtZW50c1tfa2V5Ml07XG4gICAgfVxuXG4gICAgYXJncy5mb3JFYWNoKGZ1bmN0aW9uIChjb25maWcpIHtcbiAgICAgIHJldHVybiBfY3JlYXRlUGx1Z2luKGNvbmZpZyk7XG4gICAgfSk7XG4gIH0sXG4gIHRpbWVsaW5lOiBmdW5jdGlvbiB0aW1lbGluZSh2YXJzKSB7XG4gICAgcmV0dXJuIG5ldyBUaW1lbGluZSh2YXJzKTtcbiAgfSxcbiAgZ2V0VHdlZW5zT2Y6IGZ1bmN0aW9uIGdldFR3ZWVuc09mKHRhcmdldHMsIG9ubHlBY3RpdmUpIHtcbiAgICByZXR1cm4gX2dsb2JhbFRpbWVsaW5lLmdldFR3ZWVuc09mKHRhcmdldHMsIG9ubHlBY3RpdmUpO1xuICB9LFxuICBnZXRQcm9wZXJ0eTogZnVuY3Rpb24gZ2V0UHJvcGVydHkodGFyZ2V0LCBwcm9wZXJ0eSwgdW5pdCwgdW5jYWNoZSkge1xuICAgIF9pc1N0cmluZyh0YXJnZXQpICYmICh0YXJnZXQgPSB0b0FycmF5KHRhcmdldClbMF0pOyAvL2luIGNhc2Ugc2VsZWN0b3IgdGV4dCBvciBhbiBhcnJheSBpcyBwYXNzZWQgaW5cblxuICAgIHZhciBnZXR0ZXIgPSBfZ2V0Q2FjaGUodGFyZ2V0IHx8IHt9KS5nZXQsXG4gICAgICAgIGZvcm1hdCA9IHVuaXQgPyBfcGFzc1Rocm91Z2ggOiBfbnVtZXJpY0lmUG9zc2libGU7XG5cbiAgICB1bml0ID09PSBcIm5hdGl2ZVwiICYmICh1bml0ID0gXCJcIik7XG4gICAgcmV0dXJuICF0YXJnZXQgPyB0YXJnZXQgOiAhcHJvcGVydHkgPyBmdW5jdGlvbiAocHJvcGVydHksIHVuaXQsIHVuY2FjaGUpIHtcbiAgICAgIHJldHVybiBmb3JtYXQoKF9wbHVnaW5zW3Byb3BlcnR5XSAmJiBfcGx1Z2luc1twcm9wZXJ0eV0uZ2V0IHx8IGdldHRlcikodGFyZ2V0LCBwcm9wZXJ0eSwgdW5pdCwgdW5jYWNoZSkpO1xuICAgIH0gOiBmb3JtYXQoKF9wbHVnaW5zW3Byb3BlcnR5XSAmJiBfcGx1Z2luc1twcm9wZXJ0eV0uZ2V0IHx8IGdldHRlcikodGFyZ2V0LCBwcm9wZXJ0eSwgdW5pdCwgdW5jYWNoZSkpO1xuICB9LFxuICBxdWlja1NldHRlcjogZnVuY3Rpb24gcXVpY2tTZXR0ZXIodGFyZ2V0LCBwcm9wZXJ0eSwgdW5pdCkge1xuICAgIHRhcmdldCA9IHRvQXJyYXkodGFyZ2V0KTtcblxuICAgIGlmICh0YXJnZXQubGVuZ3RoID4gMSkge1xuICAgICAgdmFyIHNldHRlcnMgPSB0YXJnZXQubWFwKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgIHJldHVybiBnc2FwLnF1aWNrU2V0dGVyKHQsIHByb3BlcnR5LCB1bml0KTtcbiAgICAgIH0pLFxuICAgICAgICAgIGwgPSBzZXR0ZXJzLmxlbmd0aDtcbiAgICAgIHJldHVybiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgdmFyIGkgPSBsO1xuXG4gICAgICAgIHdoaWxlIChpLS0pIHtcbiAgICAgICAgICBzZXR0ZXJzW2ldKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9XG5cbiAgICB0YXJnZXQgPSB0YXJnZXRbMF0gfHwge307XG5cbiAgICB2YXIgUGx1Z2luID0gX3BsdWdpbnNbcHJvcGVydHldLFxuICAgICAgICBjYWNoZSA9IF9nZXRDYWNoZSh0YXJnZXQpLFxuICAgICAgICBwID0gY2FjaGUuaGFybmVzcyAmJiAoY2FjaGUuaGFybmVzcy5hbGlhc2VzIHx8IHt9KVtwcm9wZXJ0eV0gfHwgcHJvcGVydHksXG4gICAgICAgIC8vIGluIGNhc2UgaXQncyBhbiBhbGlhcywgbGlrZSBcInJvdGF0ZVwiIGZvciBcInJvdGF0aW9uXCIuXG4gICAgc2V0dGVyID0gUGx1Z2luID8gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICB2YXIgcCA9IG5ldyBQbHVnaW4oKTtcbiAgICAgIF9xdWlja1R3ZWVuLl9wdCA9IDA7XG4gICAgICBwLmluaXQodGFyZ2V0LCB1bml0ID8gdmFsdWUgKyB1bml0IDogdmFsdWUsIF9xdWlja1R3ZWVuLCAwLCBbdGFyZ2V0XSk7XG4gICAgICBwLnJlbmRlcigxLCBwKTtcbiAgICAgIF9xdWlja1R3ZWVuLl9wdCAmJiBfcmVuZGVyUHJvcFR3ZWVucygxLCBfcXVpY2tUd2Vlbik7XG4gICAgfSA6IGNhY2hlLnNldCh0YXJnZXQsIHApO1xuXG4gICAgcmV0dXJuIFBsdWdpbiA/IHNldHRlciA6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgcmV0dXJuIHNldHRlcih0YXJnZXQsIHAsIHVuaXQgPyB2YWx1ZSArIHVuaXQgOiB2YWx1ZSwgY2FjaGUsIDEpO1xuICAgIH07XG4gIH0sXG4gIHF1aWNrVG86IGZ1bmN0aW9uIHF1aWNrVG8odGFyZ2V0LCBwcm9wZXJ0eSwgdmFycykge1xuICAgIHZhciBfc2V0RGVmYXVsdHMyO1xuXG4gICAgdmFyIHR3ZWVuID0gZ3NhcC50byh0YXJnZXQsIF9zZXREZWZhdWx0cygoX3NldERlZmF1bHRzMiA9IHt9LCBfc2V0RGVmYXVsdHMyW3Byb3BlcnR5XSA9IFwiKz0wLjFcIiwgX3NldERlZmF1bHRzMi5wYXVzZWQgPSB0cnVlLCBfc2V0RGVmYXVsdHMyLnN0YWdnZXIgPSAwLCBfc2V0RGVmYXVsdHMyKSwgdmFycyB8fCB7fSkpLFxuICAgICAgICBmdW5jID0gZnVuY3Rpb24gZnVuYyh2YWx1ZSwgc3RhcnQsIHN0YXJ0SXNSZWxhdGl2ZSkge1xuICAgICAgcmV0dXJuIHR3ZWVuLnJlc2V0VG8ocHJvcGVydHksIHZhbHVlLCBzdGFydCwgc3RhcnRJc1JlbGF0aXZlKTtcbiAgICB9O1xuXG4gICAgZnVuYy50d2VlbiA9IHR3ZWVuO1xuICAgIHJldHVybiBmdW5jO1xuICB9LFxuICBpc1R3ZWVuaW5nOiBmdW5jdGlvbiBpc1R3ZWVuaW5nKHRhcmdldHMpIHtcbiAgICByZXR1cm4gX2dsb2JhbFRpbWVsaW5lLmdldFR3ZWVuc09mKHRhcmdldHMsIHRydWUpLmxlbmd0aCA+IDA7XG4gIH0sXG4gIGRlZmF1bHRzOiBmdW5jdGlvbiBkZWZhdWx0cyh2YWx1ZSkge1xuICAgIHZhbHVlICYmIHZhbHVlLmVhc2UgJiYgKHZhbHVlLmVhc2UgPSBfcGFyc2VFYXNlKHZhbHVlLmVhc2UsIF9kZWZhdWx0cy5lYXNlKSk7XG4gICAgcmV0dXJuIF9tZXJnZURlZXAoX2RlZmF1bHRzLCB2YWx1ZSB8fCB7fSk7XG4gIH0sXG4gIGNvbmZpZzogZnVuY3Rpb24gY29uZmlnKHZhbHVlKSB7XG4gICAgcmV0dXJuIF9tZXJnZURlZXAoX2NvbmZpZywgdmFsdWUgfHwge30pO1xuICB9LFxuICByZWdpc3RlckVmZmVjdDogZnVuY3Rpb24gcmVnaXN0ZXJFZmZlY3QoX3JlZjMpIHtcbiAgICB2YXIgbmFtZSA9IF9yZWYzLm5hbWUsXG4gICAgICAgIGVmZmVjdCA9IF9yZWYzLmVmZmVjdCxcbiAgICAgICAgcGx1Z2lucyA9IF9yZWYzLnBsdWdpbnMsXG4gICAgICAgIGRlZmF1bHRzID0gX3JlZjMuZGVmYXVsdHMsXG4gICAgICAgIGV4dGVuZFRpbWVsaW5lID0gX3JlZjMuZXh0ZW5kVGltZWxpbmU7XG4gICAgKHBsdWdpbnMgfHwgXCJcIikuc3BsaXQoXCIsXCIpLmZvckVhY2goZnVuY3Rpb24gKHBsdWdpbk5hbWUpIHtcbiAgICAgIHJldHVybiBwbHVnaW5OYW1lICYmICFfcGx1Z2luc1twbHVnaW5OYW1lXSAmJiAhX2dsb2JhbHNbcGx1Z2luTmFtZV0gJiYgX3dhcm4obmFtZSArIFwiIGVmZmVjdCByZXF1aXJlcyBcIiArIHBsdWdpbk5hbWUgKyBcIiBwbHVnaW4uXCIpO1xuICAgIH0pO1xuXG4gICAgX2VmZmVjdHNbbmFtZV0gPSBmdW5jdGlvbiAodGFyZ2V0cywgdmFycywgdGwpIHtcbiAgICAgIHJldHVybiBlZmZlY3QodG9BcnJheSh0YXJnZXRzKSwgX3NldERlZmF1bHRzKHZhcnMgfHwge30sIGRlZmF1bHRzKSwgdGwpO1xuICAgIH07XG5cbiAgICBpZiAoZXh0ZW5kVGltZWxpbmUpIHtcbiAgICAgIFRpbWVsaW5lLnByb3RvdHlwZVtuYW1lXSA9IGZ1bmN0aW9uICh0YXJnZXRzLCB2YXJzLCBwb3NpdGlvbikge1xuICAgICAgICByZXR1cm4gdGhpcy5hZGQoX2VmZmVjdHNbbmFtZV0odGFyZ2V0cywgX2lzT2JqZWN0KHZhcnMpID8gdmFycyA6IChwb3NpdGlvbiA9IHZhcnMpICYmIHt9LCB0aGlzKSwgcG9zaXRpb24pO1xuICAgICAgfTtcbiAgICB9XG4gIH0sXG4gIHJlZ2lzdGVyRWFzZTogZnVuY3Rpb24gcmVnaXN0ZXJFYXNlKG5hbWUsIGVhc2UpIHtcbiAgICBfZWFzZU1hcFtuYW1lXSA9IF9wYXJzZUVhc2UoZWFzZSk7XG4gIH0sXG4gIHBhcnNlRWFzZTogZnVuY3Rpb24gcGFyc2VFYXNlKGVhc2UsIGRlZmF1bHRFYXNlKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyBfcGFyc2VFYXNlKGVhc2UsIGRlZmF1bHRFYXNlKSA6IF9lYXNlTWFwO1xuICB9LFxuICBnZXRCeUlkOiBmdW5jdGlvbiBnZXRCeUlkKGlkKSB7XG4gICAgcmV0dXJuIF9nbG9iYWxUaW1lbGluZS5nZXRCeUlkKGlkKTtcbiAgfSxcbiAgZXhwb3J0Um9vdDogZnVuY3Rpb24gZXhwb3J0Um9vdCh2YXJzLCBpbmNsdWRlRGVsYXllZENhbGxzKSB7XG4gICAgaWYgKHZhcnMgPT09IHZvaWQgMCkge1xuICAgICAgdmFycyA9IHt9O1xuICAgIH1cblxuICAgIHZhciB0bCA9IG5ldyBUaW1lbGluZSh2YXJzKSxcbiAgICAgICAgY2hpbGQsXG4gICAgICAgIG5leHQ7XG4gICAgdGwuc21vb3RoQ2hpbGRUaW1pbmcgPSBfaXNOb3RGYWxzZSh2YXJzLnNtb290aENoaWxkVGltaW5nKTtcblxuICAgIF9nbG9iYWxUaW1lbGluZS5yZW1vdmUodGwpO1xuXG4gICAgdGwuX2RwID0gMDsgLy9vdGhlcndpc2UgaXQnbGwgZ2V0IHJlLWFjdGl2YXRlZCB3aGVuIGFkZGluZyBjaGlsZHJlbiBhbmQgYmUgcmUtaW50cm9kdWNlZCBpbnRvIF9nbG9iYWxUaW1lbGluZSdzIGxpbmtlZCBsaXN0ICh0aGVuIGFkZGVkIHRvIGl0c2VsZikuXG5cbiAgICB0bC5fdGltZSA9IHRsLl90VGltZSA9IF9nbG9iYWxUaW1lbGluZS5fdGltZTtcbiAgICBjaGlsZCA9IF9nbG9iYWxUaW1lbGluZS5fZmlyc3Q7XG5cbiAgICB3aGlsZSAoY2hpbGQpIHtcbiAgICAgIG5leHQgPSBjaGlsZC5fbmV4dDtcblxuICAgICAgaWYgKGluY2x1ZGVEZWxheWVkQ2FsbHMgfHwgISghY2hpbGQuX2R1ciAmJiBjaGlsZCBpbnN0YW5jZW9mIFR3ZWVuICYmIGNoaWxkLnZhcnMub25Db21wbGV0ZSA9PT0gY2hpbGQuX3RhcmdldHNbMF0pKSB7XG4gICAgICAgIF9hZGRUb1RpbWVsaW5lKHRsLCBjaGlsZCwgY2hpbGQuX3N0YXJ0IC0gY2hpbGQuX2RlbGF5KTtcbiAgICAgIH1cblxuICAgICAgY2hpbGQgPSBuZXh0O1xuICAgIH1cblxuICAgIF9hZGRUb1RpbWVsaW5lKF9nbG9iYWxUaW1lbGluZSwgdGwsIDApO1xuXG4gICAgcmV0dXJuIHRsO1xuICB9LFxuICBjb250ZXh0OiBmdW5jdGlvbiBjb250ZXh0KGZ1bmMsIHNjb3BlKSB7XG4gICAgcmV0dXJuIGZ1bmMgPyBuZXcgQ29udGV4dChmdW5jLCBzY29wZSkgOiBfY29udGV4dDtcbiAgfSxcbiAgbWF0Y2hNZWRpYTogZnVuY3Rpb24gbWF0Y2hNZWRpYShzY29wZSkge1xuICAgIHJldHVybiBuZXcgTWF0Y2hNZWRpYShzY29wZSk7XG4gIH0sXG4gIG1hdGNoTWVkaWFSZWZyZXNoOiBmdW5jdGlvbiBtYXRjaE1lZGlhUmVmcmVzaCgpIHtcbiAgICByZXR1cm4gX21lZGlhLmZvckVhY2goZnVuY3Rpb24gKGMpIHtcbiAgICAgIHZhciBjb25kID0gYy5jb25kaXRpb25zLFxuICAgICAgICAgIGZvdW5kLFxuICAgICAgICAgIHA7XG5cbiAgICAgIGZvciAocCBpbiBjb25kKSB7XG4gICAgICAgIGlmIChjb25kW3BdKSB7XG4gICAgICAgICAgY29uZFtwXSA9IGZhbHNlO1xuICAgICAgICAgIGZvdW5kID0gMTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBmb3VuZCAmJiBjLnJldmVydCgpO1xuICAgIH0pIHx8IF9vbk1lZGlhQ2hhbmdlKCk7XG4gIH0sXG4gIGFkZEV2ZW50TGlzdGVuZXI6IGZ1bmN0aW9uIGFkZEV2ZW50TGlzdGVuZXIodHlwZSwgY2FsbGJhY2spIHtcbiAgICB2YXIgYSA9IF9saXN0ZW5lcnNbdHlwZV0gfHwgKF9saXN0ZW5lcnNbdHlwZV0gPSBbXSk7XG4gICAgfmEuaW5kZXhPZihjYWxsYmFjaykgfHwgYS5wdXNoKGNhbGxiYWNrKTtcbiAgfSxcbiAgcmVtb3ZlRXZlbnRMaXN0ZW5lcjogZnVuY3Rpb24gcmVtb3ZlRXZlbnRMaXN0ZW5lcih0eXBlLCBjYWxsYmFjaykge1xuICAgIHZhciBhID0gX2xpc3RlbmVyc1t0eXBlXSxcbiAgICAgICAgaSA9IGEgJiYgYS5pbmRleE9mKGNhbGxiYWNrKTtcbiAgICBpID49IDAgJiYgYS5zcGxpY2UoaSwgMSk7XG4gIH0sXG4gIHV0aWxzOiB7XG4gICAgd3JhcDogd3JhcCxcbiAgICB3cmFwWW95bzogd3JhcFlveW8sXG4gICAgZGlzdHJpYnV0ZTogZGlzdHJpYnV0ZSxcbiAgICByYW5kb206IHJhbmRvbSxcbiAgICBzbmFwOiBzbmFwLFxuICAgIG5vcm1hbGl6ZTogbm9ybWFsaXplLFxuICAgIGdldFVuaXQ6IGdldFVuaXQsXG4gICAgY2xhbXA6IGNsYW1wLFxuICAgIHNwbGl0Q29sb3I6IHNwbGl0Q29sb3IsXG4gICAgdG9BcnJheTogdG9BcnJheSxcbiAgICBzZWxlY3Rvcjogc2VsZWN0b3IsXG4gICAgbWFwUmFuZ2U6IG1hcFJhbmdlLFxuICAgIHBpcGU6IHBpcGUsXG4gICAgdW5pdGl6ZTogdW5pdGl6ZSxcbiAgICBpbnRlcnBvbGF0ZTogaW50ZXJwb2xhdGUsXG4gICAgc2h1ZmZsZTogc2h1ZmZsZVxuICB9LFxuICBpbnN0YWxsOiBfaW5zdGFsbCxcbiAgZWZmZWN0czogX2VmZmVjdHMsXG4gIHRpY2tlcjogX3RpY2tlcixcbiAgdXBkYXRlUm9vdDogVGltZWxpbmUudXBkYXRlUm9vdCxcbiAgcGx1Z2luczogX3BsdWdpbnMsXG4gIGdsb2JhbFRpbWVsaW5lOiBfZ2xvYmFsVGltZWxpbmUsXG4gIGNvcmU6IHtcbiAgICBQcm9wVHdlZW46IFByb3BUd2VlbixcbiAgICBnbG9iYWxzOiBfYWRkR2xvYmFsLFxuICAgIFR3ZWVuOiBUd2VlbixcbiAgICBUaW1lbGluZTogVGltZWxpbmUsXG4gICAgQW5pbWF0aW9uOiBBbmltYXRpb24sXG4gICAgZ2V0Q2FjaGU6IF9nZXRDYWNoZSxcbiAgICBfcmVtb3ZlTGlua2VkTGlzdEl0ZW06IF9yZW1vdmVMaW5rZWRMaXN0SXRlbSxcbiAgICByZXZlcnRpbmc6IGZ1bmN0aW9uIHJldmVydGluZygpIHtcbiAgICAgIHJldHVybiBfcmV2ZXJ0aW5nO1xuICAgIH0sXG4gICAgY29udGV4dDogZnVuY3Rpb24gY29udGV4dCh0b0FkZCkge1xuICAgICAgaWYgKHRvQWRkICYmIF9jb250ZXh0KSB7XG4gICAgICAgIF9jb250ZXh0LmRhdGEucHVzaCh0b0FkZCk7XG5cbiAgICAgICAgdG9BZGQuX2N0eCA9IF9jb250ZXh0O1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gX2NvbnRleHQ7XG4gICAgfSxcbiAgICBzdXBwcmVzc092ZXJ3cml0ZXM6IGZ1bmN0aW9uIHN1cHByZXNzT3ZlcndyaXRlcyh2YWx1ZSkge1xuICAgICAgcmV0dXJuIF9zdXBwcmVzc092ZXJ3cml0ZXMgPSB2YWx1ZTtcbiAgICB9XG4gIH1cbn07XG5cbl9mb3JFYWNoTmFtZShcInRvLGZyb20sZnJvbVRvLGRlbGF5ZWRDYWxsLHNldCxraWxsVHdlZW5zT2ZcIiwgZnVuY3Rpb24gKG5hbWUpIHtcbiAgcmV0dXJuIF9nc2FwW25hbWVdID0gVHdlZW5bbmFtZV07XG59KTtcblxuX3RpY2tlci5hZGQoVGltZWxpbmUudXBkYXRlUm9vdCk7XG5cbl9xdWlja1R3ZWVuID0gX2dzYXAudG8oe30sIHtcbiAgZHVyYXRpb246IDBcbn0pOyAvLyAtLS0tIEVYVFJBIFBMVUdJTlMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxudmFyIF9nZXRQbHVnaW5Qcm9wVHdlZW4gPSBmdW5jdGlvbiBfZ2V0UGx1Z2luUHJvcFR3ZWVuKHBsdWdpbiwgcHJvcCkge1xuICB2YXIgcHQgPSBwbHVnaW4uX3B0O1xuXG4gIHdoaWxlIChwdCAmJiBwdC5wICE9PSBwcm9wICYmIHB0Lm9wICE9PSBwcm9wICYmIHB0LmZwICE9PSBwcm9wKSB7XG4gICAgcHQgPSBwdC5fbmV4dDtcbiAgfVxuXG4gIHJldHVybiBwdDtcbn0sXG4gICAgX2FkZE1vZGlmaWVycyA9IGZ1bmN0aW9uIF9hZGRNb2RpZmllcnModHdlZW4sIG1vZGlmaWVycykge1xuICB2YXIgdGFyZ2V0cyA9IHR3ZWVuLl90YXJnZXRzLFxuICAgICAgcCxcbiAgICAgIGksXG4gICAgICBwdDtcblxuICBmb3IgKHAgaW4gbW9kaWZpZXJzKSB7XG4gICAgaSA9IHRhcmdldHMubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGktLSkge1xuICAgICAgcHQgPSB0d2Vlbi5fcHRMb29rdXBbaV1bcF07XG5cbiAgICAgIGlmIChwdCAmJiAocHQgPSBwdC5kKSkge1xuICAgICAgICBpZiAocHQuX3B0KSB7XG4gICAgICAgICAgLy8gaXMgYSBwbHVnaW5cbiAgICAgICAgICBwdCA9IF9nZXRQbHVnaW5Qcm9wVHdlZW4ocHQsIHApO1xuICAgICAgICB9XG5cbiAgICAgICAgcHQgJiYgcHQubW9kaWZpZXIgJiYgcHQubW9kaWZpZXIobW9kaWZpZXJzW3BdLCB0d2VlbiwgdGFyZ2V0c1tpXSwgcCk7XG4gICAgICB9XG4gICAgfVxuICB9XG59LFxuICAgIF9idWlsZE1vZGlmaWVyUGx1Z2luID0gZnVuY3Rpb24gX2J1aWxkTW9kaWZpZXJQbHVnaW4obmFtZSwgbW9kaWZpZXIpIHtcbiAgcmV0dXJuIHtcbiAgICBuYW1lOiBuYW1lLFxuICAgIGhlYWRsZXNzOiAxLFxuICAgIHJhd1ZhcnM6IDEsXG4gICAgLy9kb24ndCBwcmUtcHJvY2VzcyBmdW5jdGlvbi1iYXNlZCB2YWx1ZXMgb3IgXCJyYW5kb20oKVwiIHN0cmluZ3MuXG4gICAgaW5pdDogZnVuY3Rpb24gaW5pdCh0YXJnZXQsIHZhcnMsIHR3ZWVuKSB7XG4gICAgICB0d2Vlbi5fb25Jbml0ID0gZnVuY3Rpb24gKHR3ZWVuKSB7XG4gICAgICAgIHZhciB0ZW1wLCBwO1xuXG4gICAgICAgIGlmIChfaXNTdHJpbmcodmFycykpIHtcbiAgICAgICAgICB0ZW1wID0ge307XG5cbiAgICAgICAgICBfZm9yRWFjaE5hbWUodmFycywgZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgICAgICAgIHJldHVybiB0ZW1wW25hbWVdID0gMTtcbiAgICAgICAgICB9KTsgLy9pZiB0aGUgdXNlciBwYXNzZXMgaW4gYSBjb21tYS1kZWxpbWl0ZWQgbGlzdCBvZiBwcm9wZXJ0eSBuYW1lcyB0byByb3VuZFByb3BzLCBsaWtlIFwieCx5XCIsIHdlIHJvdW5kIHRvIHdob2xlIG51bWJlcnMuXG5cblxuICAgICAgICAgIHZhcnMgPSB0ZW1wO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG1vZGlmaWVyKSB7XG4gICAgICAgICAgdGVtcCA9IHt9O1xuXG4gICAgICAgICAgZm9yIChwIGluIHZhcnMpIHtcbiAgICAgICAgICAgIHRlbXBbcF0gPSBtb2RpZmllcih2YXJzW3BdKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICB2YXJzID0gdGVtcDtcbiAgICAgICAgfVxuXG4gICAgICAgIF9hZGRNb2RpZmllcnModHdlZW4sIHZhcnMpO1xuICAgICAgfTtcbiAgICB9XG4gIH07XG59OyAvL3JlZ2lzdGVyIGNvcmUgcGx1Z2luc1xuXG5cbmV4cG9ydCB2YXIgZ3NhcCA9IF9nc2FwLnJlZ2lzdGVyUGx1Z2luKHtcbiAgbmFtZTogXCJhdHRyXCIsXG4gIGluaXQ6IGZ1bmN0aW9uIGluaXQodGFyZ2V0LCB2YXJzLCB0d2VlbiwgaW5kZXgsIHRhcmdldHMpIHtcbiAgICB2YXIgcCwgcHQsIHY7XG4gICAgdGhpcy50d2VlbiA9IHR3ZWVuO1xuXG4gICAgZm9yIChwIGluIHZhcnMpIHtcbiAgICAgIHYgPSB0YXJnZXQuZ2V0QXR0cmlidXRlKHApIHx8IFwiXCI7XG4gICAgICBwdCA9IHRoaXMuYWRkKHRhcmdldCwgXCJzZXRBdHRyaWJ1dGVcIiwgKHYgfHwgMCkgKyBcIlwiLCB2YXJzW3BdLCBpbmRleCwgdGFyZ2V0cywgMCwgMCwgcCk7XG4gICAgICBwdC5vcCA9IHA7XG4gICAgICBwdC5iID0gdjsgLy8gcmVjb3JkIHRoZSBiZWdpbm5pbmcgdmFsdWUgc28gd2UgY2FuIHJldmVydCgpXG5cbiAgICAgIHRoaXMuX3Byb3BzLnB1c2gocCk7XG4gICAgfVxuICB9LFxuICByZW5kZXI6IGZ1bmN0aW9uIHJlbmRlcihyYXRpbywgZGF0YSkge1xuICAgIHZhciBwdCA9IGRhdGEuX3B0O1xuXG4gICAgd2hpbGUgKHB0KSB7XG4gICAgICBfcmV2ZXJ0aW5nID8gcHQuc2V0KHB0LnQsIHB0LnAsIHB0LmIsIHB0KSA6IHB0LnIocmF0aW8sIHB0LmQpOyAvLyBpZiByZXZlcnRpbmcsIGdvIGJhY2sgdG8gdGhlIG9yaWdpbmFsIChwdC5iKVxuXG4gICAgICBwdCA9IHB0Ll9uZXh0O1xuICAgIH1cbiAgfVxufSwge1xuICBuYW1lOiBcImVuZEFycmF5XCIsXG4gIGhlYWRsZXNzOiAxLFxuICBpbml0OiBmdW5jdGlvbiBpbml0KHRhcmdldCwgdmFsdWUpIHtcbiAgICB2YXIgaSA9IHZhbHVlLmxlbmd0aDtcblxuICAgIHdoaWxlIChpLS0pIHtcbiAgICAgIHRoaXMuYWRkKHRhcmdldCwgaSwgdGFyZ2V0W2ldIHx8IDAsIHZhbHVlW2ldLCAwLCAwLCAwLCAwLCAwLCAxKTtcbiAgICB9XG4gIH1cbn0sIF9idWlsZE1vZGlmaWVyUGx1Z2luKFwicm91bmRQcm9wc1wiLCBfcm91bmRNb2RpZmllciksIF9idWlsZE1vZGlmaWVyUGx1Z2luKFwibW9kaWZpZXJzXCIpLCBfYnVpbGRNb2RpZmllclBsdWdpbihcInNuYXBcIiwgc25hcCkpIHx8IF9nc2FwOyAvL3RvIHByZXZlbnQgdGhlIGNvcmUgcGx1Z2lucyBmcm9tIGJlaW5nIGRyb3BwZWQgdmlhIGFnZ3Jlc3NpdmUgdHJlZSBzaGFraW5nLCB3ZSBtdXN0IGluY2x1ZGUgdGhlbSBpbiB0aGUgdmFyaWFibGUgZGVjbGFyYXRpb24gaW4gdGhpcyB3YXkuXG5cblR3ZWVuLnZlcnNpb24gPSBUaW1lbGluZS52ZXJzaW9uID0gZ3NhcC52ZXJzaW9uID0gXCIzLjE1LjBcIjtcbl9jb3JlUmVhZHkgPSAxO1xuX3dpbmRvd0V4aXN0cygpICYmIF93YWtlKCk7XG52YXIgUG93ZXIwID0gX2Vhc2VNYXAuUG93ZXIwLFxuICAgIFBvd2VyMSA9IF9lYXNlTWFwLlBvd2VyMSxcbiAgICBQb3dlcjIgPSBfZWFzZU1hcC5Qb3dlcjIsXG4gICAgUG93ZXIzID0gX2Vhc2VNYXAuUG93ZXIzLFxuICAgIFBvd2VyNCA9IF9lYXNlTWFwLlBvd2VyNCxcbiAgICBMaW5lYXIgPSBfZWFzZU1hcC5MaW5lYXIsXG4gICAgUXVhZCA9IF9lYXNlTWFwLlF1YWQsXG4gICAgQ3ViaWMgPSBfZWFzZU1hcC5DdWJpYyxcbiAgICBRdWFydCA9IF9lYXNlTWFwLlF1YXJ0LFxuICAgIFF1aW50ID0gX2Vhc2VNYXAuUXVpbnQsXG4gICAgU3Ryb25nID0gX2Vhc2VNYXAuU3Ryb25nLFxuICAgIEVsYXN0aWMgPSBfZWFzZU1hcC5FbGFzdGljLFxuICAgIEJhY2sgPSBfZWFzZU1hcC5CYWNrLFxuICAgIFN0ZXBwZWRFYXNlID0gX2Vhc2VNYXAuU3RlcHBlZEVhc2UsXG4gICAgQm91bmNlID0gX2Vhc2VNYXAuQm91bmNlLFxuICAgIFNpbmUgPSBfZWFzZU1hcC5TaW5lLFxuICAgIEV4cG8gPSBfZWFzZU1hcC5FeHBvLFxuICAgIENpcmMgPSBfZWFzZU1hcC5DaXJjO1xuZXhwb3J0IHsgUG93ZXIwLCBQb3dlcjEsIFBvd2VyMiwgUG93ZXIzLCBQb3dlcjQsIExpbmVhciwgUXVhZCwgQ3ViaWMsIFF1YXJ0LCBRdWludCwgU3Ryb25nLCBFbGFzdGljLCBCYWNrLCBTdGVwcGVkRWFzZSwgQm91bmNlLCBTaW5lLCBFeHBvLCBDaXJjIH07XG5leHBvcnQgeyBUd2VlbiBhcyBUd2Vlbk1heCwgVHdlZW4gYXMgVHdlZW5MaXRlLCBUaW1lbGluZSBhcyBUaW1lbGluZU1heCwgVGltZWxpbmUgYXMgVGltZWxpbmVMaXRlLCBnc2FwIGFzIGRlZmF1bHQsIHdyYXAsIHdyYXBZb3lvLCBkaXN0cmlidXRlLCByYW5kb20sIHNuYXAsIG5vcm1hbGl6ZSwgZ2V0VW5pdCwgY2xhbXAsIHNwbGl0Q29sb3IsIHRvQXJyYXksIHNlbGVjdG9yLCBtYXBSYW5nZSwgcGlwZSwgdW5pdGl6ZSwgaW50ZXJwb2xhdGUsIHNodWZmbGUgfTsgLy9leHBvcnQgc29tZSBpbnRlcm5hbCBtZXRob2RzL29yb2plY3RzIGZvciB1c2UgaW4gQ1NTUGx1Z2luIHNvIHRoYXQgd2UgY2FuIGV4dGVybmFsaXplIHRoYXQgZmlsZSBhbmQgYWxsb3cgY3VzdG9tIGJ1aWxkcyB0aGF0IGV4Y2x1ZGUgaXQuXG5cbmV4cG9ydCB7IF9nZXRQcm9wZXJ0eSwgX251bUV4cCwgX251bVdpdGhVbml0RXhwLCBfaXNTdHJpbmcsIF9pc1VuZGVmaW5lZCwgX3JlbmRlckNvbXBsZXhTdHJpbmcsIF9yZWxFeHAsIF9zZXREZWZhdWx0cywgX3JlbW92ZUxpbmtlZExpc3RJdGVtLCBfZm9yRWFjaE5hbWUsIF9zb3J0UHJvcFR3ZWVuc0J5UHJpb3JpdHksIF9jb2xvclN0cmluZ0ZpbHRlciwgX3JlcGxhY2VSYW5kb20sIF9jaGVja1BsdWdpbiwgX3BsdWdpbnMsIF90aWNrZXIsIF9jb25maWcsIF9yb3VuZE1vZGlmaWVyLCBfcm91bmQsIF9taXNzaW5nUGx1Z2luLCBfZ2V0U2V0dGVyLCBfZ2V0Q2FjaGUsIF9jb2xvckV4cCwgX3BhcnNlUmVsYXRpdmUgfTsiLCIvKiFcbiAqIENTU1BsdWdpbiAzLjE1LjBcbiAqIGh0dHBzOi8vZ3NhcC5jb21cbiAqXG4gKiBDb3B5cmlnaHQgMjAwOC0yMDI2LCBHcmVlblNvY2suIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKiBTdWJqZWN0IHRvIHRoZSB0ZXJtcyBhdCBodHRwczovL2dzYXAuY29tL3N0YW5kYXJkLWxpY2Vuc2VcbiAqIEBhdXRob3I6IEphY2sgRG95bGUsIGphY2tAZ3JlZW5zb2NrLmNvbVxuKi9cblxuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB7IGdzYXAsIF9nZXRQcm9wZXJ0eSwgX251bUV4cCwgX251bVdpdGhVbml0RXhwLCBnZXRVbml0LCBfaXNTdHJpbmcsIF9pc1VuZGVmaW5lZCwgX3JlbmRlckNvbXBsZXhTdHJpbmcsIF9yZWxFeHAsIF9mb3JFYWNoTmFtZSwgX3NvcnRQcm9wVHdlZW5zQnlQcmlvcml0eSwgX2NvbG9yU3RyaW5nRmlsdGVyLCBfY2hlY2tQbHVnaW4sIF9yZXBsYWNlUmFuZG9tLCBfcGx1Z2lucywgR1NDYWNoZSwgUHJvcFR3ZWVuLCBfY29uZmlnLCBfdGlja2VyLCBfcm91bmQsIF9taXNzaW5nUGx1Z2luLCBfZ2V0U2V0dGVyLCBfZ2V0Q2FjaGUsIF9jb2xvckV4cCwgX3BhcnNlUmVsYXRpdmUsIF9zZXREZWZhdWx0cywgX3JlbW92ZUxpbmtlZExpc3RJdGVtIC8vZm9yIHRoZSBjb21tZW50ZWQtb3V0IGNsYXNzTmFtZSBmZWF0dXJlLlxufSBmcm9tIFwiLi9nc2FwLWNvcmUuanNcIjtcblxudmFyIF93aW4sXG4gICAgX2RvYyxcbiAgICBfZG9jRWxlbWVudCxcbiAgICBfcGx1Z2luSW5pdHRlZCxcbiAgICBfdGVtcERpdixcbiAgICBfdGVtcERpdlN0eWxlcixcbiAgICBfcmVjZW50U2V0dGVyUGx1Z2luLFxuICAgIF9yZXZlcnRpbmcsXG4gICAgX3dpbmRvd0V4aXN0cyA9IGZ1bmN0aW9uIF93aW5kb3dFeGlzdHMoKSB7XG4gIHJldHVybiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiO1xufSxcbiAgICBfdHJhbnNmb3JtUHJvcHMgPSB7fSxcbiAgICBfUkFEMkRFRyA9IDE4MCAvIE1hdGguUEksXG4gICAgX0RFRzJSQUQgPSBNYXRoLlBJIC8gMTgwLFxuICAgIF9hdGFuMiA9IE1hdGguYXRhbjIsXG4gICAgX2JpZ051bSA9IDFlOCxcbiAgICBfY2Fwc0V4cCA9IC8oW0EtWl0pL2csXG4gICAgX2hvcml6b250YWxFeHAgPSAvKGxlZnR8cmlnaHR8d2lkdGh8bWFyZ2lufHBhZGRpbmd8eCkvaSxcbiAgICBfY29tcGxleEV4cCA9IC9bXFxzLFxcKF1cXFMvLFxuICAgIF9wcm9wZXJ0eUFsaWFzZXMgPSB7XG4gIGF1dG9BbHBoYTogXCJvcGFjaXR5LHZpc2liaWxpdHlcIixcbiAgc2NhbGU6IFwic2NhbGVYLHNjYWxlWVwiLFxuICBhbHBoYTogXCJvcGFjaXR5XCJcbn0sXG4gICAgX3JlbmRlckNTU1Byb3AgPSBmdW5jdGlvbiBfcmVuZGVyQ1NTUHJvcChyYXRpbywgZGF0YSkge1xuICByZXR1cm4gZGF0YS5zZXQoZGF0YS50LCBkYXRhLnAsIE1hdGgucm91bmQoKGRhdGEucyArIGRhdGEuYyAqIHJhdGlvKSAqIDEwMDAwKSAvIDEwMDAwICsgZGF0YS51LCBkYXRhKTtcbn0sXG4gICAgX3JlbmRlclByb3BXaXRoRW5kID0gZnVuY3Rpb24gX3JlbmRlclByb3BXaXRoRW5kKHJhdGlvLCBkYXRhKSB7XG4gIHJldHVybiBkYXRhLnNldChkYXRhLnQsIGRhdGEucCwgcmF0aW8gPT09IDEgPyBkYXRhLmUgOiBNYXRoLnJvdW5kKChkYXRhLnMgKyBkYXRhLmMgKiByYXRpbykgKiAxMDAwMCkgLyAxMDAwMCArIGRhdGEudSwgZGF0YSk7XG59LFxuICAgIF9yZW5kZXJDU1NQcm9wV2l0aEJlZ2lubmluZyA9IGZ1bmN0aW9uIF9yZW5kZXJDU1NQcm9wV2l0aEJlZ2lubmluZyhyYXRpbywgZGF0YSkge1xuICByZXR1cm4gZGF0YS5zZXQoZGF0YS50LCBkYXRhLnAsIHJhdGlvID8gTWF0aC5yb3VuZCgoZGF0YS5zICsgZGF0YS5jICogcmF0aW8pICogMTAwMDApIC8gMTAwMDAgKyBkYXRhLnUgOiBkYXRhLmIsIGRhdGEpO1xufSxcbiAgICAvL2lmIHVuaXRzIGNoYW5nZSwgd2UgbmVlZCBhIHdheSB0byByZW5kZXIgdGhlIG9yaWdpbmFsIHVuaXQvdmFsdWUgd2hlbiB0aGUgdHdlZW4gZ29lcyBhbGwgdGhlIHdheSBiYWNrIHRvIHRoZSBiZWdpbm5pbmcgKHJhdGlvOjApXG5fcmVuZGVyQ1NTUHJvcFdpdGhCZWdpbm5pbmdBbmRFbmQgPSBmdW5jdGlvbiBfcmVuZGVyQ1NTUHJvcFdpdGhCZWdpbm5pbmdBbmRFbmQocmF0aW8sIGRhdGEpIHtcbiAgcmV0dXJuIGRhdGEuc2V0KGRhdGEudCwgZGF0YS5wLCByYXRpbyA9PT0gMSA/IGRhdGEuZSA6IHJhdGlvID8gTWF0aC5yb3VuZCgoZGF0YS5zICsgZGF0YS5jICogcmF0aW8pICogMTAwMDApIC8gMTAwMDAgKyBkYXRhLnUgOiBkYXRhLmIsIGRhdGEpO1xufSxcbiAgICAvL2lmIHVuaXRzIGNoYW5nZSwgd2UgbmVlZCBhIHdheSB0byByZW5kZXIgdGhlIG9yaWdpbmFsIHVuaXQvdmFsdWUgd2hlbiB0aGUgdHdlZW4gZ29lcyBhbGwgdGhlIHdheSBiYWNrIHRvIHRoZSBiZWdpbm5pbmcgKHJhdGlvOjApXG5fcmVuZGVyUm91bmRlZENTU1Byb3AgPSBmdW5jdGlvbiBfcmVuZGVyUm91bmRlZENTU1Byb3AocmF0aW8sIGRhdGEpIHtcbiAgdmFyIHZhbHVlID0gZGF0YS5zICsgZGF0YS5jICogcmF0aW87XG4gIGRhdGEuc2V0KGRhdGEudCwgZGF0YS5wLCB+fih2YWx1ZSArICh2YWx1ZSA8IDAgPyAtLjUgOiAuNSkpICsgZGF0YS51LCBkYXRhKTtcbn0sXG4gICAgX3JlbmRlck5vblR3ZWVuaW5nVmFsdWUgPSBmdW5jdGlvbiBfcmVuZGVyTm9uVHdlZW5pbmdWYWx1ZShyYXRpbywgZGF0YSkge1xuICByZXR1cm4gZGF0YS5zZXQoZGF0YS50LCBkYXRhLnAsIHJhdGlvID8gZGF0YS5lIDogZGF0YS5iLCBkYXRhKTtcbn0sXG4gICAgX3JlbmRlck5vblR3ZWVuaW5nVmFsdWVPbmx5QXRFbmQgPSBmdW5jdGlvbiBfcmVuZGVyTm9uVHdlZW5pbmdWYWx1ZU9ubHlBdEVuZChyYXRpbywgZGF0YSkge1xuICByZXR1cm4gZGF0YS5zZXQoZGF0YS50LCBkYXRhLnAsIHJhdGlvICE9PSAxID8gZGF0YS5iIDogZGF0YS5lLCBkYXRhKTtcbn0sXG4gICAgX3NldHRlckNTU1N0eWxlID0gZnVuY3Rpb24gX3NldHRlckNTU1N0eWxlKHRhcmdldCwgcHJvcGVydHksIHZhbHVlKSB7XG4gIHJldHVybiB0YXJnZXQuc3R5bGVbcHJvcGVydHldID0gdmFsdWU7XG59LFxuICAgIF9zZXR0ZXJDU1NQcm9wID0gZnVuY3Rpb24gX3NldHRlckNTU1Byb3AodGFyZ2V0LCBwcm9wZXJ0eSwgdmFsdWUpIHtcbiAgcmV0dXJuIHRhcmdldC5zdHlsZS5zZXRQcm9wZXJ0eShwcm9wZXJ0eSwgdmFsdWUpO1xufSxcbiAgICBfc2V0dGVyVHJhbnNmb3JtID0gZnVuY3Rpb24gX3NldHRlclRyYW5zZm9ybSh0YXJnZXQsIHByb3BlcnR5LCB2YWx1ZSkge1xuICByZXR1cm4gdGFyZ2V0Ll9nc2FwW3Byb3BlcnR5XSA9IHZhbHVlO1xufSxcbiAgICBfc2V0dGVyU2NhbGUgPSBmdW5jdGlvbiBfc2V0dGVyU2NhbGUodGFyZ2V0LCBwcm9wZXJ0eSwgdmFsdWUpIHtcbiAgcmV0dXJuIHRhcmdldC5fZ3NhcC5zY2FsZVggPSB0YXJnZXQuX2dzYXAuc2NhbGVZID0gdmFsdWU7XG59LFxuICAgIF9zZXR0ZXJTY2FsZVdpdGhSZW5kZXIgPSBmdW5jdGlvbiBfc2V0dGVyU2NhbGVXaXRoUmVuZGVyKHRhcmdldCwgcHJvcGVydHksIHZhbHVlLCBkYXRhLCByYXRpbykge1xuICB2YXIgY2FjaGUgPSB0YXJnZXQuX2dzYXA7XG4gIGNhY2hlLnNjYWxlWCA9IGNhY2hlLnNjYWxlWSA9IHZhbHVlO1xuICBjYWNoZS5yZW5kZXJUcmFuc2Zvcm0ocmF0aW8sIGNhY2hlKTtcbn0sXG4gICAgX3NldHRlclRyYW5zZm9ybVdpdGhSZW5kZXIgPSBmdW5jdGlvbiBfc2V0dGVyVHJhbnNmb3JtV2l0aFJlbmRlcih0YXJnZXQsIHByb3BlcnR5LCB2YWx1ZSwgZGF0YSwgcmF0aW8pIHtcbiAgdmFyIGNhY2hlID0gdGFyZ2V0Ll9nc2FwO1xuICBjYWNoZVtwcm9wZXJ0eV0gPSB2YWx1ZTtcbiAgY2FjaGUucmVuZGVyVHJhbnNmb3JtKHJhdGlvLCBjYWNoZSk7XG59LFxuICAgIF90cmFuc2Zvcm1Qcm9wID0gXCJ0cmFuc2Zvcm1cIixcbiAgICBfdHJhbnNmb3JtT3JpZ2luUHJvcCA9IF90cmFuc2Zvcm1Qcm9wICsgXCJPcmlnaW5cIixcbiAgICBfc2F2ZVN0eWxlID0gZnVuY3Rpb24gX3NhdmVTdHlsZShwcm9wZXJ0eSwgaXNOb3RDU1MpIHtcbiAgdmFyIF90aGlzID0gdGhpcztcblxuICB2YXIgdGFyZ2V0ID0gdGhpcy50YXJnZXQsXG4gICAgICBzdHlsZSA9IHRhcmdldC5zdHlsZSxcbiAgICAgIGNhY2hlID0gdGFyZ2V0Ll9nc2FwO1xuXG4gIGlmIChwcm9wZXJ0eSBpbiBfdHJhbnNmb3JtUHJvcHMgJiYgc3R5bGUpIHtcbiAgICB0aGlzLnRmbSA9IHRoaXMudGZtIHx8IHt9O1xuXG4gICAgaWYgKHByb3BlcnR5ICE9PSBcInRyYW5zZm9ybVwiKSB7XG4gICAgICBwcm9wZXJ0eSA9IF9wcm9wZXJ0eUFsaWFzZXNbcHJvcGVydHldIHx8IHByb3BlcnR5O1xuICAgICAgfnByb3BlcnR5LmluZGV4T2YoXCIsXCIpID8gcHJvcGVydHkuc3BsaXQoXCIsXCIpLmZvckVhY2goZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgcmV0dXJuIF90aGlzLnRmbVthXSA9IF9nZXQodGFyZ2V0LCBhKTtcbiAgICAgIH0pIDogdGhpcy50Zm1bcHJvcGVydHldID0gY2FjaGUueCA/IGNhY2hlW3Byb3BlcnR5XSA6IF9nZXQodGFyZ2V0LCBwcm9wZXJ0eSk7IC8vIG5vdGU6IHNjYWxlIHdvdWxkIG1hcCB0byBcInNjYWxlWCxzY2FsZVlcIiwgdGh1cyB3ZSBsb29wIGFuZCBhcHBseSB0aGVtIGJvdGguXG5cbiAgICAgIHByb3BlcnR5ID09PSBfdHJhbnNmb3JtT3JpZ2luUHJvcCAmJiAodGhpcy50Zm0uek9yaWdpbiA9IGNhY2hlLnpPcmlnaW4pO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gX3Byb3BlcnR5QWxpYXNlcy50cmFuc2Zvcm0uc3BsaXQoXCIsXCIpLmZvckVhY2goZnVuY3Rpb24gKHApIHtcbiAgICAgICAgcmV0dXJuIF9zYXZlU3R5bGUuY2FsbChfdGhpcywgcCwgaXNOb3RDU1MpO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMucHJvcHMuaW5kZXhPZihfdHJhbnNmb3JtUHJvcCkgPj0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChjYWNoZS5zdmcpIHtcbiAgICAgIHRoaXMuc3ZnbyA9IHRhcmdldC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXN2Zy1vcmlnaW5cIik7XG4gICAgICB0aGlzLnByb3BzLnB1c2goX3RyYW5zZm9ybU9yaWdpblByb3AsIGlzTm90Q1NTLCBcIlwiKTtcbiAgICB9XG5cbiAgICBwcm9wZXJ0eSA9IF90cmFuc2Zvcm1Qcm9wO1xuICB9XG5cbiAgKHN0eWxlIHx8IGlzTm90Q1NTKSAmJiB0aGlzLnByb3BzLnB1c2gocHJvcGVydHksIGlzTm90Q1NTLCBzdHlsZVtwcm9wZXJ0eV0pO1xufSxcbiAgICBfcmVtb3ZlSW5kZXBlbmRlbnRUcmFuc2Zvcm1zID0gZnVuY3Rpb24gX3JlbW92ZUluZGVwZW5kZW50VHJhbnNmb3JtcyhzdHlsZSkge1xuICBpZiAoc3R5bGUudHJhbnNsYXRlKSB7XG4gICAgc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2xhdGVcIik7XG4gICAgc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJzY2FsZVwiKTtcbiAgICBzdHlsZS5yZW1vdmVQcm9wZXJ0eShcInJvdGF0ZVwiKTtcbiAgfVxufSxcbiAgICBfcmV2ZXJ0U3R5bGUgPSBmdW5jdGlvbiBfcmV2ZXJ0U3R5bGUoKSB7XG4gIHZhciBwcm9wcyA9IHRoaXMucHJvcHMsXG4gICAgICB0YXJnZXQgPSB0aGlzLnRhcmdldCxcbiAgICAgIHN0eWxlID0gdGFyZ2V0LnN0eWxlLFxuICAgICAgY2FjaGUgPSB0YXJnZXQuX2dzYXAsXG4gICAgICBpLFxuICAgICAgcDtcblxuICBmb3IgKGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpICs9IDMpIHtcbiAgICAvLyBzdG9yZWQgbGlrZSB0aGlzOiBwcm9wZXJ0eSwgaXNOb3RDU1MsIHZhbHVlXG4gICAgaWYgKCFwcm9wc1tpICsgMV0pIHtcbiAgICAgIHByb3BzW2kgKyAyXSA/IHN0eWxlW3Byb3BzW2ldXSA9IHByb3BzW2kgKyAyXSA6IHN0eWxlLnJlbW92ZVByb3BlcnR5KHByb3BzW2ldLnN1YnN0cigwLCAyKSA9PT0gXCItLVwiID8gcHJvcHNbaV0gOiBwcm9wc1tpXS5yZXBsYWNlKF9jYXBzRXhwLCBcIi0kMVwiKS50b0xvd2VyQ2FzZSgpKTtcbiAgICB9IGVsc2UgaWYgKHByb3BzW2kgKyAxXSA9PT0gMikge1xuICAgICAgLy8gbm9uLUNTUyB2YWx1ZSAoZnVuY3Rpb24tYmFzZWQpXG4gICAgICB0YXJnZXRbcHJvcHNbaV1dKHByb3BzW2kgKyAyXSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIG5vbi1DU1MgdmFsdWUgKG5vdCBmdW5jdGlvbi1iYXNlZClcbiAgICAgIHRhcmdldFtwcm9wc1tpXV0gPSBwcm9wc1tpICsgMl07XG4gICAgfVxuICB9XG5cbiAgaWYgKHRoaXMudGZtKSB7XG4gICAgZm9yIChwIGluIHRoaXMudGZtKSB7XG4gICAgICBjYWNoZVtwXSA9IHRoaXMudGZtW3BdO1xuICAgIH1cblxuICAgIGlmIChjYWNoZS5zdmcpIHtcbiAgICAgIGNhY2hlLnJlbmRlclRyYW5zZm9ybSgpO1xuICAgICAgdGFyZ2V0LnNldEF0dHJpYnV0ZShcImRhdGEtc3ZnLW9yaWdpblwiLCB0aGlzLnN2Z28gfHwgXCJcIik7XG4gICAgfVxuXG4gICAgaSA9IF9yZXZlcnRpbmcoKTtcblxuICAgIGlmICgoIWkgfHwgIWkuaXNTdGFydCkgJiYgIXN0eWxlW190cmFuc2Zvcm1Qcm9wXSkge1xuICAgICAgX3JlbW92ZUluZGVwZW5kZW50VHJhbnNmb3JtcyhzdHlsZSk7XG5cbiAgICAgIGlmIChjYWNoZS56T3JpZ2luICYmIHN0eWxlW190cmFuc2Zvcm1PcmlnaW5Qcm9wXSkge1xuICAgICAgICBzdHlsZVtfdHJhbnNmb3JtT3JpZ2luUHJvcF0gKz0gXCIgXCIgKyBjYWNoZS56T3JpZ2luICsgXCJweFwiOyAvLyBzaW5jZSB3ZSdyZSB1bmNhY2hpbmcsIHdlIG11c3QgcHV0IHRoZSB6T3JpZ2luIGJhY2sgaW50byB0aGUgdHJhbnNmb3JtT3JpZ2luIHNvIHRoYXQgd2UgY2FuIHB1bGwgaXQgb3V0IGFjY3VyYXRlbHkgd2hlbiB3ZSBwYXJzZSBhZ2Fpbi4gT3RoZXJ3aXNlLCB3ZSdkIGxvc2UgdGhlIHogcG9ydGlvbiBvZiB0aGUgb3JpZ2luIHNpbmNlIHdlIGV4dHJhY3QgaXQgdG8gcHJvdGVjdCBmcm9tIFNhZmFyaSBidWdzLlxuXG4gICAgICAgIGNhY2hlLnpPcmlnaW4gPSAwO1xuICAgICAgICBjYWNoZS5yZW5kZXJUcmFuc2Zvcm0oKTtcbiAgICAgIH1cblxuICAgICAgY2FjaGUudW5jYWNoZSA9IDE7IC8vIGlmIGl0J3MgYSBzdGFydEF0IHRoYXQncyBiZWluZyByZXZlcnRlZCBpbiB0aGUgX2luaXRUd2VlbigpIG9mIHRoZSBjb3JlLCB3ZSBkb24ndCBuZWVkIHRvIHVuY2FjaGUgdHJhbnNmb3Jtcy4gVGhpcyBpcyBwdXJlbHkgYSBwZXJmb3JtYW5jZSBvcHRpbWl6YXRpb24uXG4gICAgfVxuICB9XG59LFxuICAgIF9nZXRTdHlsZVNhdmVyID0gZnVuY3Rpb24gX2dldFN0eWxlU2F2ZXIodGFyZ2V0LCBwcm9wZXJ0aWVzKSB7XG4gIHZhciBzYXZlciA9IHtcbiAgICB0YXJnZXQ6IHRhcmdldCxcbiAgICBwcm9wczogW10sXG4gICAgcmV2ZXJ0OiBfcmV2ZXJ0U3R5bGUsXG4gICAgc2F2ZTogX3NhdmVTdHlsZVxuICB9O1xuICB0YXJnZXQuX2dzYXAgfHwgZ3NhcC5jb3JlLmdldENhY2hlKHRhcmdldCk7IC8vIGp1c3QgbWFrZSBzdXJlIHRoZXJlJ3MgYSBfZ3NhcCBjYWNoZSBkZWZpbmVkIGJlY2F1c2Ugd2UgcmVhZCBmcm9tIGl0IGluIF9zYXZlU3R5bGUoKSBhbmQgaXQncyBtb3JlIGVmZmljaWVudCB0byBqdXN0IGNoZWNrIGl0IGhlcmUgb25jZS5cblxuICBwcm9wZXJ0aWVzICYmIHRhcmdldC5zdHlsZSAmJiB0YXJnZXQubm9kZVR5cGUgJiYgcHJvcGVydGllcy5zcGxpdChcIixcIikuZm9yRWFjaChmdW5jdGlvbiAocCkge1xuICAgIHJldHVybiBzYXZlci5zYXZlKHApO1xuICB9KTsgLy8gbWFrZSBzdXJlIGl0J3MgYSBET00gbm9kZSB0b28uXG5cbiAgcmV0dXJuIHNhdmVyO1xufSxcbiAgICBfc3VwcG9ydHMzRCxcbiAgICBfY3JlYXRlRWxlbWVudCA9IGZ1bmN0aW9uIF9jcmVhdGVFbGVtZW50KHR5cGUsIG5zKSB7XG4gIHZhciBlID0gX2RvYy5jcmVhdGVFbGVtZW50TlMgPyBfZG9jLmNyZWF0ZUVsZW1lbnROUygobnMgfHwgXCJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hodG1sXCIpLnJlcGxhY2UoL15odHRwcy8sIFwiaHR0cFwiKSwgdHlwZSkgOiBfZG9jLmNyZWF0ZUVsZW1lbnQodHlwZSk7IC8vc29tZSBzZXJ2ZXJzIHN3YXAgaW4gaHR0cHMgZm9yIGh0dHAgaW4gdGhlIG5hbWVzcGFjZSB3aGljaCBjYW4gYnJlYWsgdGhpbmdzLCBtYWtpbmcgXCJzdHlsZVwiIGluYWNjZXNzaWJsZS5cblxuICByZXR1cm4gZSAmJiBlLnN0eWxlID8gZSA6IF9kb2MuY3JlYXRlRWxlbWVudCh0eXBlKTsgLy9zb21lIGVudmlyb25tZW50cyB3b24ndCBhbGxvdyBhY2Nlc3MgdG8gdGhlIGVsZW1lbnQncyBzdHlsZSB3aGVuIGNyZWF0ZWQgd2l0aCBhIG5hbWVzcGFjZSBpbiB3aGljaCBjYXNlIHdlIGRlZmF1bHQgdG8gdGhlIHN0YW5kYXJkIGNyZWF0ZUVsZW1lbnQoKSB0byB3b3JrIGFyb3VuZCB0aGUgaXNzdWUuIEFsc28gbm90ZSB0aGF0IHdoZW4gR1NBUCBpcyBlbWJlZGRlZCBkaXJlY3RseSBpbnNpZGUgYW4gU1ZHIGZpbGUsIGNyZWF0ZUVsZW1lbnQoKSB3b24ndCBhbGxvdyBhY2Nlc3MgdG8gdGhlIHN0eWxlIG9iamVjdCBpbiBGaXJlZm94IChzZWUgaHR0cHM6Ly9nc2FwLmNvbS9mb3J1bXMvdG9waWMvMjAyMTUtcHJvYmxlbS11c2luZy10d2Vlbm1heC1pbi1zdGFuZGFsb25lLXNlbGYtY29udGFpbmluZy1zdmctZmlsZS1lcnItY2Fubm90LXNldC1wcm9wZXJ0eS1jc3N0ZXh0LW9mLXVuZGVmaW5lZC8pLlxufSxcbiAgICBfZ2V0Q29tcHV0ZWRQcm9wZXJ0eSA9IGZ1bmN0aW9uIF9nZXRDb21wdXRlZFByb3BlcnR5KHRhcmdldCwgcHJvcGVydHksIHNraXBQcmVmaXhGYWxsYmFjaykge1xuICB2YXIgY3MgPSBnZXRDb21wdXRlZFN0eWxlKHRhcmdldCk7XG4gIHJldHVybiBjc1twcm9wZXJ0eV0gfHwgY3MuZ2V0UHJvcGVydHlWYWx1ZShwcm9wZXJ0eS5yZXBsYWNlKF9jYXBzRXhwLCBcIi0kMVwiKS50b0xvd2VyQ2FzZSgpKSB8fCBjcy5nZXRQcm9wZXJ0eVZhbHVlKHByb3BlcnR5KSB8fCAhc2tpcFByZWZpeEZhbGxiYWNrICYmIF9nZXRDb21wdXRlZFByb3BlcnR5KHRhcmdldCwgX2NoZWNrUHJvcFByZWZpeChwcm9wZXJ0eSkgfHwgcHJvcGVydHksIDEpIHx8IFwiXCI7IC8vY3NzIHZhcmlhYmxlcyBtYXkgbm90IG5lZWQgY2FwcyBzd2FwcGVkIG91dCBmb3IgZGFzaGVzIGFuZCBsb3dlcmNhc2UuXG59LFxuICAgIF9wcmVmaXhlcyA9IFwiTyxNb3osbXMsTXMsV2Via2l0XCIuc3BsaXQoXCIsXCIpLFxuICAgIF9jaGVja1Byb3BQcmVmaXggPSBmdW5jdGlvbiBfY2hlY2tQcm9wUHJlZml4KHByb3BlcnR5LCBlbGVtZW50LCBwcmVmZXJQcmVmaXgpIHtcbiAgdmFyIGUgPSBlbGVtZW50IHx8IF90ZW1wRGl2LFxuICAgICAgcyA9IGUuc3R5bGUsXG4gICAgICBpID0gNTtcblxuICBpZiAocHJvcGVydHkgaW4gcyAmJiAhcHJlZmVyUHJlZml4KSB7XG4gICAgcmV0dXJuIHByb3BlcnR5O1xuICB9XG5cbiAgcHJvcGVydHkgPSBwcm9wZXJ0eS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHByb3BlcnR5LnN1YnN0cigxKTtcblxuICB3aGlsZSAoaS0tICYmICEoX3ByZWZpeGVzW2ldICsgcHJvcGVydHkgaW4gcykpIHt9XG5cbiAgcmV0dXJuIGkgPCAwID8gbnVsbCA6IChpID09PSAzID8gXCJtc1wiIDogaSA+PSAwID8gX3ByZWZpeGVzW2ldIDogXCJcIikgKyBwcm9wZXJ0eTtcbn0sXG4gICAgX2luaXRDb3JlID0gZnVuY3Rpb24gX2luaXRDb3JlKCkge1xuICBpZiAoX3dpbmRvd0V4aXN0cygpICYmIHdpbmRvdy5kb2N1bWVudCkge1xuICAgIF93aW4gPSB3aW5kb3c7XG4gICAgX2RvYyA9IF93aW4uZG9jdW1lbnQ7XG4gICAgX2RvY0VsZW1lbnQgPSBfZG9jLmRvY3VtZW50RWxlbWVudDtcbiAgICBfdGVtcERpdiA9IF9jcmVhdGVFbGVtZW50KFwiZGl2XCIpIHx8IHtcbiAgICAgIHN0eWxlOiB7fVxuICAgIH07XG4gICAgX3RlbXBEaXZTdHlsZXIgPSBfY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICBfdHJhbnNmb3JtUHJvcCA9IF9jaGVja1Byb3BQcmVmaXgoX3RyYW5zZm9ybVByb3ApO1xuICAgIF90cmFuc2Zvcm1PcmlnaW5Qcm9wID0gX3RyYW5zZm9ybVByb3AgKyBcIk9yaWdpblwiO1xuICAgIF90ZW1wRGl2LnN0eWxlLmNzc1RleHQgPSBcImJvcmRlci13aWR0aDowO2xpbmUtaGVpZ2h0OjA7cG9zaXRpb246YWJzb2x1dGU7cGFkZGluZzowXCI7IC8vbWFrZSBzdXJlIHRvIG92ZXJyaWRlIGNlcnRhaW4gcHJvcGVydGllcyB0aGF0IG1heSBjb250YW1pbmF0ZSBtZWFzdXJlbWVudHMsIGluIGNhc2UgdGhlIHVzZXIgaGFzIG92ZXJyZWFjaGluZyBzdHlsZSBzaGVldHMuXG5cbiAgICBfc3VwcG9ydHMzRCA9ICEhX2NoZWNrUHJvcFByZWZpeChcInBlcnNwZWN0aXZlXCIpO1xuICAgIF9yZXZlcnRpbmcgPSBnc2FwLmNvcmUucmV2ZXJ0aW5nO1xuICAgIF9wbHVnaW5Jbml0dGVkID0gMTtcbiAgfVxufSxcbiAgICBfZ2V0UmVwYXJlbnRlZENsb25lQkJveCA9IGZ1bmN0aW9uIF9nZXRSZXBhcmVudGVkQ2xvbmVCQm94KHRhcmdldCkge1xuICAvL3dvcmtzIGFyb3VuZCBpc3N1ZXMgaW4gc29tZSBicm93c2VycyAobGlrZSBGaXJlZm94KSB0aGF0IGRvbid0IGNvcnJlY3RseSByZXBvcnQgZ2V0QkJveCgpIG9uIFNWRyBlbGVtZW50cyBpbnNpZGUgYSA8ZGVmcz4gZWxlbWVudCBhbmQvb3IgPG1hc2s+LiBXZSB0cnkgY3JlYXRpbmcgYW4gU1ZHLCBhZGRpbmcgaXQgdG8gdGhlIGRvY3VtZW50RWxlbWVudCBhbmQgdG9zcyB0aGUgZWxlbWVudCBpbiB0aGVyZSBzbyB0aGF0IGl0J3MgZGVmaW5pdGVseSBwYXJ0IG9mIHRoZSByZW5kZXJpbmcgdHJlZSwgdGhlbiBncmFiIHRoZSBiYm94IGFuZCBpZiBpdCB3b3Jrcywgd2UgYWN0dWFsbHkgc3dhcCBvdXQgdGhlIG9yaWdpbmFsIGdldEJCb3goKSBtZXRob2QgZm9yIG91ciBvd24gdGhhdCBkb2VzIHRoZXNlIGV4dHJhIHN0ZXBzIHdoZW5ldmVyIGdldEJCb3ggaXMgbmVlZGVkLiBUaGlzIGhlbHBzIGVuc3VyZSB0aGF0IHBlcmZvcm1hbmNlIGlzIG9wdGltYWwgKG9ubHkgZG8gYWxsIHRoZXNlIGV4dHJhIHN0ZXBzIHdoZW4gYWJzb2x1dGVseSBuZWNlc3NhcnkuLi5tb3N0IGVsZW1lbnRzIGRvbid0IG5lZWQgaXQpLlxuICB2YXIgb3duZXIgPSB0YXJnZXQub3duZXJTVkdFbGVtZW50LFxuICAgICAgc3ZnID0gX2NyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgb3duZXIgJiYgb3duZXIuZ2V0QXR0cmlidXRlKFwieG1sbnNcIikgfHwgXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiKSxcbiAgICAgIGNsb25lID0gdGFyZ2V0LmNsb25lTm9kZSh0cnVlKSxcbiAgICAgIGJib3g7XG5cbiAgY2xvbmUuc3R5bGUuZGlzcGxheSA9IFwiYmxvY2tcIjtcbiAgc3ZnLmFwcGVuZENoaWxkKGNsb25lKTtcblxuICBfZG9jRWxlbWVudC5hcHBlbmRDaGlsZChzdmcpO1xuXG4gIHRyeSB7XG4gICAgYmJveCA9IGNsb25lLmdldEJCb3goKTtcbiAgfSBjYXRjaCAoZSkge31cblxuICBzdmcucmVtb3ZlQ2hpbGQoY2xvbmUpO1xuXG4gIF9kb2NFbGVtZW50LnJlbW92ZUNoaWxkKHN2Zyk7XG5cbiAgcmV0dXJuIGJib3g7XG59LFxuICAgIF9nZXRBdHRyaWJ1dGVGYWxsYmFja3MgPSBmdW5jdGlvbiBfZ2V0QXR0cmlidXRlRmFsbGJhY2tzKHRhcmdldCwgYXR0cmlidXRlc0FycmF5KSB7XG4gIHZhciBpID0gYXR0cmlidXRlc0FycmF5Lmxlbmd0aDtcblxuICB3aGlsZSAoaS0tKSB7XG4gICAgaWYgKHRhcmdldC5oYXNBdHRyaWJ1dGUoYXR0cmlidXRlc0FycmF5W2ldKSkge1xuICAgICAgcmV0dXJuIHRhcmdldC5nZXRBdHRyaWJ1dGUoYXR0cmlidXRlc0FycmF5W2ldKTtcbiAgICB9XG4gIH1cbn0sXG4gICAgX2dldEJCb3ggPSBmdW5jdGlvbiBfZ2V0QkJveCh0YXJnZXQpIHtcbiAgdmFyIGJvdW5kcywgY2xvbmVkO1xuXG4gIHRyeSB7XG4gICAgYm91bmRzID0gdGFyZ2V0LmdldEJCb3goKTsgLy9GaXJlZm94IHRocm93cyBlcnJvcnMgaWYgeW91IHRyeSBjYWxsaW5nIGdldEJCb3goKSBvbiBhbiBTVkcgZWxlbWVudCB0aGF0J3Mgbm90IHJlbmRlcmVkIChsaWtlIGluIGEgPHN5bWJvbD4gb3IgPGRlZnM+KS4gaHR0cHM6Ly9idWd6aWxsYS5tb3ppbGxhLm9yZy9zaG93X2J1Zy5jZ2k/aWQ9NjEyMTE4XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgYm91bmRzID0gX2dldFJlcGFyZW50ZWRDbG9uZUJCb3godGFyZ2V0KTtcbiAgICBjbG9uZWQgPSAxO1xuICB9XG5cbiAgYm91bmRzICYmIChib3VuZHMud2lkdGggfHwgYm91bmRzLmhlaWdodCkgfHwgY2xvbmVkIHx8IChib3VuZHMgPSBfZ2V0UmVwYXJlbnRlZENsb25lQkJveCh0YXJnZXQpKTsgLy9zb21lIGJyb3dzZXJzIChsaWtlIEZpcmVmb3gpIG1pc3JlcG9ydCB0aGUgYm91bmRzIGlmIHRoZSBlbGVtZW50IGhhcyB6ZXJvIHdpZHRoIGFuZCBoZWlnaHQgKGl0IGp1c3QgYXNzdW1lcyBpdCdzIGF0IHg6MCwgeTowKSwgdGh1cyB3ZSBuZWVkIHRvIG1hbnVhbGx5IGdyYWIgdGhlIHBvc2l0aW9uIGluIHRoYXQgY2FzZS5cblxuICByZXR1cm4gYm91bmRzICYmICFib3VuZHMud2lkdGggJiYgIWJvdW5kcy54ICYmICFib3VuZHMueSA/IHtcbiAgICB4OiArX2dldEF0dHJpYnV0ZUZhbGxiYWNrcyh0YXJnZXQsIFtcInhcIiwgXCJjeFwiLCBcIngxXCJdKSB8fCAwLFxuICAgIHk6ICtfZ2V0QXR0cmlidXRlRmFsbGJhY2tzKHRhcmdldCwgW1wieVwiLCBcImN5XCIsIFwieTFcIl0pIHx8IDAsXG4gICAgd2lkdGg6IDAsXG4gICAgaGVpZ2h0OiAwXG4gIH0gOiBib3VuZHM7XG59LFxuICAgIF9pc1NWRyA9IGZ1bmN0aW9uIF9pc1NWRyhlKSB7XG4gIHJldHVybiAhIShlLmdldENUTSAmJiAoIWUucGFyZW50Tm9kZSB8fCBlLm93bmVyU1ZHRWxlbWVudCkgJiYgX2dldEJCb3goZSkpO1xufSxcbiAgICAvL3JlcG9ydHMgaWYgdGhlIGVsZW1lbnQgaXMgYW4gU1ZHIG9uIHdoaWNoIGdldEJCb3goKSBhY3R1YWxseSB3b3Jrc1xuX3JlbW92ZVByb3BlcnR5ID0gZnVuY3Rpb24gX3JlbW92ZVByb3BlcnR5KHRhcmdldCwgcHJvcGVydHkpIHtcbiAgaWYgKHByb3BlcnR5KSB7XG4gICAgdmFyIHN0eWxlID0gdGFyZ2V0LnN0eWxlLFxuICAgICAgICBmaXJzdDJDaGFycztcblxuICAgIGlmIChwcm9wZXJ0eSBpbiBfdHJhbnNmb3JtUHJvcHMgJiYgcHJvcGVydHkgIT09IF90cmFuc2Zvcm1PcmlnaW5Qcm9wKSB7XG4gICAgICBwcm9wZXJ0eSA9IF90cmFuc2Zvcm1Qcm9wO1xuICAgIH1cblxuICAgIGlmIChzdHlsZS5yZW1vdmVQcm9wZXJ0eSkge1xuICAgICAgZmlyc3QyQ2hhcnMgPSBwcm9wZXJ0eS5zdWJzdHIoMCwgMik7XG5cbiAgICAgIGlmIChmaXJzdDJDaGFycyA9PT0gXCJtc1wiIHx8IHByb3BlcnR5LnN1YnN0cigwLCA2KSA9PT0gXCJ3ZWJraXRcIikge1xuICAgICAgICAvL01pY3Jvc29mdCBhbmQgc29tZSBXZWJraXQgYnJvd3NlcnMgZG9uJ3QgY29uZm9ybSB0byB0aGUgc3RhbmRhcmQgb2YgY2FwaXRhbGl6aW5nIHRoZSBmaXJzdCBwcmVmaXggY2hhcmFjdGVyLCBzbyB3ZSBhZGp1c3Qgc28gdGhhdCB3aGVuIHdlIHByZWZpeCB0aGUgY2FwcyB3aXRoIGEgZGFzaCwgaXQncyBjb3JyZWN0IChvdGhlcndpc2UgaXQnZCBiZSBcIm1zLXRyYW5zZm9ybVwiIGluc3RlYWQgb2YgXCItbXMtdHJhbnNmb3JtXCIgZm9yIElFOSwgZm9yIGV4YW1wbGUpXG4gICAgICAgIHByb3BlcnR5ID0gXCItXCIgKyBwcm9wZXJ0eTtcbiAgICAgIH1cblxuICAgICAgc3R5bGUucmVtb3ZlUHJvcGVydHkoZmlyc3QyQ2hhcnMgPT09IFwiLS1cIiA/IHByb3BlcnR5IDogcHJvcGVydHkucmVwbGFjZShfY2Fwc0V4cCwgXCItJDFcIikudG9Mb3dlckNhc2UoKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vbm90ZTogb2xkIHZlcnNpb25zIG9mIElFIHVzZSBcInJlbW92ZUF0dHJpYnV0ZSgpXCIgaW5zdGVhZCBvZiBcInJlbW92ZVByb3BlcnR5KClcIlxuICAgICAgc3R5bGUucmVtb3ZlQXR0cmlidXRlKHByb3BlcnR5KTtcbiAgICB9XG4gIH1cbn0sXG4gICAgX2FkZE5vblR3ZWVuaW5nUFQgPSBmdW5jdGlvbiBfYWRkTm9uVHdlZW5pbmdQVChwbHVnaW4sIHRhcmdldCwgcHJvcGVydHksIGJlZ2lubmluZywgZW5kLCBvbmx5U2V0QXRFbmQpIHtcbiAgdmFyIHB0ID0gbmV3IFByb3BUd2VlbihwbHVnaW4uX3B0LCB0YXJnZXQsIHByb3BlcnR5LCAwLCAxLCBvbmx5U2V0QXRFbmQgPyBfcmVuZGVyTm9uVHdlZW5pbmdWYWx1ZU9ubHlBdEVuZCA6IF9yZW5kZXJOb25Ud2VlbmluZ1ZhbHVlKTtcbiAgcGx1Z2luLl9wdCA9IHB0O1xuICBwdC5iID0gYmVnaW5uaW5nO1xuICBwdC5lID0gZW5kO1xuXG4gIHBsdWdpbi5fcHJvcHMucHVzaChwcm9wZXJ0eSk7XG5cbiAgcmV0dXJuIHB0O1xufSxcbiAgICBfbm9uQ29udmVydGlibGVVbml0cyA9IHtcbiAgZGVnOiAxLFxuICByYWQ6IDEsXG4gIHR1cm46IDFcbn0sXG4gICAgX25vblN0YW5kYXJkTGF5b3V0cyA9IHtcbiAgZ3JpZDogMSxcbiAgZmxleDogMVxufSxcbiAgICAvL3Rha2VzIGEgc2luZ2xlIHZhbHVlIGxpa2UgMjBweCBhbmQgY29udmVydHMgaXQgdG8gdGhlIHVuaXQgc3BlY2lmaWVkLCBsaWtlIFwiJVwiLCByZXR1cm5pbmcgb25seSB0aGUgbnVtZXJpYyBhbW91bnQuXG5fY29udmVydFRvVW5pdCA9IGZ1bmN0aW9uIF9jb252ZXJ0VG9Vbml0KHRhcmdldCwgcHJvcGVydHksIHZhbHVlLCB1bml0KSB7XG4gIHZhciBjdXJWYWx1ZSA9IHBhcnNlRmxvYXQodmFsdWUpIHx8IDAsXG4gICAgICBjdXJVbml0ID0gKHZhbHVlICsgXCJcIikudHJpbSgpLnN1YnN0cigoY3VyVmFsdWUgKyBcIlwiKS5sZW5ndGgpIHx8IFwicHhcIixcbiAgICAgIC8vIHNvbWUgYnJvd3NlcnMgbGVhdmUgZXh0cmEgd2hpdGVzcGFjZSBhdCB0aGUgYmVnaW5uaW5nIG9mIENTUyB2YXJpYWJsZXMsIGhlbmNlIHRoZSBuZWVkIHRvIHRyaW0oKVxuICBzdHlsZSA9IF90ZW1wRGl2LnN0eWxlLFxuICAgICAgaG9yaXpvbnRhbCA9IF9ob3Jpem9udGFsRXhwLnRlc3QocHJvcGVydHkpLFxuICAgICAgaXNSb290U1ZHID0gdGFyZ2V0LnRhZ05hbWUudG9Mb3dlckNhc2UoKSA9PT0gXCJzdmdcIixcbiAgICAgIG1lYXN1cmVQcm9wZXJ0eSA9IChpc1Jvb3RTVkcgPyBcImNsaWVudFwiIDogXCJvZmZzZXRcIikgKyAoaG9yaXpvbnRhbCA/IFwiV2lkdGhcIiA6IFwiSGVpZ2h0XCIpLFxuICAgICAgYW1vdW50ID0gMTAwLFxuICAgICAgdG9QaXhlbHMgPSB1bml0ID09PSBcInB4XCIsXG4gICAgICB0b1BlcmNlbnQgPSB1bml0ID09PSBcIiVcIixcbiAgICAgIHB4LFxuICAgICAgcGFyZW50LFxuICAgICAgY2FjaGUsXG4gICAgICBpc1NWRztcblxuICBpZiAodW5pdCA9PT0gY3VyVW5pdCB8fCAhY3VyVmFsdWUgfHwgX25vbkNvbnZlcnRpYmxlVW5pdHNbdW5pdF0gfHwgX25vbkNvbnZlcnRpYmxlVW5pdHNbY3VyVW5pdF0pIHtcbiAgICByZXR1cm4gY3VyVmFsdWU7XG4gIH1cblxuICBjdXJVbml0ICE9PSBcInB4XCIgJiYgIXRvUGl4ZWxzICYmIChjdXJWYWx1ZSA9IF9jb252ZXJ0VG9Vbml0KHRhcmdldCwgcHJvcGVydHksIHZhbHVlLCBcInB4XCIpKTtcbiAgaXNTVkcgPSB0YXJnZXQuZ2V0Q1RNICYmIF9pc1NWRyh0YXJnZXQpO1xuXG4gIGlmICgodG9QZXJjZW50IHx8IGN1clVuaXQgPT09IFwiJVwiKSAmJiAoX3RyYW5zZm9ybVByb3BzW3Byb3BlcnR5XSB8fCB+cHJvcGVydHkuaW5kZXhPZihcImFkaXVzXCIpKSkge1xuICAgIHB4ID0gaXNTVkcgPyB0YXJnZXQuZ2V0QkJveCgpW2hvcml6b250YWwgPyBcIndpZHRoXCIgOiBcImhlaWdodFwiXSA6IHRhcmdldFttZWFzdXJlUHJvcGVydHldO1xuICAgIHJldHVybiBfcm91bmQodG9QZXJjZW50ID8gY3VyVmFsdWUgLyBweCAqIGFtb3VudCA6IGN1clZhbHVlIC8gMTAwICogcHgpO1xuICB9XG5cbiAgc3R5bGVbaG9yaXpvbnRhbCA/IFwid2lkdGhcIiA6IFwiaGVpZ2h0XCJdID0gYW1vdW50ICsgKHRvUGl4ZWxzID8gY3VyVW5pdCA6IHVuaXQpO1xuICBwYXJlbnQgPSB1bml0ICE9PSBcInJlbVwiICYmIH5wcm9wZXJ0eS5pbmRleE9mKFwiYWRpdXNcIikgfHwgdW5pdCA9PT0gXCJlbVwiICYmIHRhcmdldC5hcHBlbmRDaGlsZCAmJiAhaXNSb290U1ZHID8gdGFyZ2V0IDogdGFyZ2V0LnBhcmVudE5vZGU7XG5cbiAgaWYgKGlzU1ZHKSB7XG4gICAgcGFyZW50ID0gKHRhcmdldC5vd25lclNWR0VsZW1lbnQgfHwge30pLnBhcmVudE5vZGU7XG4gIH1cblxuICBpZiAoIXBhcmVudCB8fCBwYXJlbnQgPT09IF9kb2MgfHwgIXBhcmVudC5hcHBlbmRDaGlsZCkge1xuICAgIHBhcmVudCA9IF9kb2MuYm9keTtcbiAgfVxuXG4gIGNhY2hlID0gcGFyZW50Ll9nc2FwO1xuXG4gIGlmIChjYWNoZSAmJiB0b1BlcmNlbnQgJiYgY2FjaGUud2lkdGggJiYgaG9yaXpvbnRhbCAmJiBjYWNoZS50aW1lID09PSBfdGlja2VyLnRpbWUgJiYgIWNhY2hlLnVuY2FjaGUpIHtcbiAgICByZXR1cm4gX3JvdW5kKGN1clZhbHVlIC8gY2FjaGUud2lkdGggKiBhbW91bnQpO1xuICB9IGVsc2Uge1xuICAgIGlmICh0b1BlcmNlbnQgJiYgKHByb3BlcnR5ID09PSBcImhlaWdodFwiIHx8IHByb3BlcnR5ID09PSBcIndpZHRoXCIpKSB7XG4gICAgICAvLyBpZiB3ZSdyZSBkZWFsaW5nIHdpdGggd2lkdGgvaGVpZ2h0IHRoYXQncyBpbnNpZGUgYSBjb250YWluZXIgd2l0aCBwYWRkaW5nIGFuZC9vciBpdCdzIGEgZmxleGJveC9ncmlkIGNvbnRhaW5lciwgd2UgbXVzdCBhcHBseSBpdCB0byB0aGUgdGFyZ2V0IGl0c2VsZiByYXRoZXIgdGhhbiB0aGUgX3RlbXBEaXYgaW4gb3JkZXIgdG8gZW5zdXJlIGNvbXBsZXRlIGFjY3VyYWN5LCBmYWN0b3JpbmcgaW4gdGhlIHBhcmVudCdzIHBhZGRpbmcuXG4gICAgICB2YXIgdiA9IHRhcmdldC5zdHlsZVtwcm9wZXJ0eV07XG4gICAgICB0YXJnZXQuc3R5bGVbcHJvcGVydHldID0gYW1vdW50ICsgdW5pdDtcbiAgICAgIHB4ID0gdGFyZ2V0W21lYXN1cmVQcm9wZXJ0eV07XG4gICAgICB2ID8gdGFyZ2V0LnN0eWxlW3Byb3BlcnR5XSA9IHYgOiBfcmVtb3ZlUHJvcGVydHkodGFyZ2V0LCBwcm9wZXJ0eSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICh0b1BlcmNlbnQgfHwgY3VyVW5pdCA9PT0gXCIlXCIpICYmICFfbm9uU3RhbmRhcmRMYXlvdXRzW19nZXRDb21wdXRlZFByb3BlcnR5KHBhcmVudCwgXCJkaXNwbGF5XCIpXSAmJiAoc3R5bGUucG9zaXRpb24gPSBfZ2V0Q29tcHV0ZWRQcm9wZXJ0eSh0YXJnZXQsIFwicG9zaXRpb25cIikpO1xuICAgICAgcGFyZW50ID09PSB0YXJnZXQgJiYgKHN0eWxlLnBvc2l0aW9uID0gXCJzdGF0aWNcIik7IC8vIGxpa2UgZm9yIGJvcmRlclJhZGl1cywgaWYgaXQncyBhICUgd2UgbXVzdCBoYXZlIGl0IHJlbGF0aXZlIHRvIHRoZSB0YXJnZXQgaXRzZWxmIGJ1dCB0aGF0IG1heSBub3QgaGF2ZSBwb3NpdGlvbjogcmVsYXRpdmUgb3IgcG9zaXRpb246IGFic29sdXRlIGluIHdoaWNoIGNhc2UgaXQnZCBnbyB1cCB0aGUgY2hhaW4gdW50aWwgaXQgZmluZHMgaXRzIG9mZnNldFBhcmVudCAoYmFkKS4gcG9zaXRpb246IHN0YXRpYyBwcm90ZWN0cyBhZ2FpbnN0IHRoYXQuXG5cbiAgICAgIHBhcmVudC5hcHBlbmRDaGlsZChfdGVtcERpdik7XG4gICAgICBweCA9IF90ZW1wRGl2W21lYXN1cmVQcm9wZXJ0eV07XG4gICAgICBwYXJlbnQucmVtb3ZlQ2hpbGQoX3RlbXBEaXYpO1xuICAgICAgc3R5bGUucG9zaXRpb24gPSBcImFic29sdXRlXCI7XG4gICAgfVxuXG4gICAgaWYgKGhvcml6b250YWwgJiYgdG9QZXJjZW50KSB7XG4gICAgICBjYWNoZSA9IF9nZXRDYWNoZShwYXJlbnQpO1xuICAgICAgY2FjaGUudGltZSA9IF90aWNrZXIudGltZTtcbiAgICAgIGNhY2hlLndpZHRoID0gcGFyZW50W21lYXN1cmVQcm9wZXJ0eV07XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIF9yb3VuZCh0b1BpeGVscyA/IHB4ICogY3VyVmFsdWUgLyBhbW91bnQgOiBweCAmJiBjdXJWYWx1ZSA/IGFtb3VudCAvIHB4ICogY3VyVmFsdWUgOiAwKTtcbn0sXG4gICAgX2dldCA9IGZ1bmN0aW9uIF9nZXQodGFyZ2V0LCBwcm9wZXJ0eSwgdW5pdCwgdW5jYWNoZSkge1xuICB2YXIgdmFsdWU7XG4gIF9wbHVnaW5Jbml0dGVkIHx8IF9pbml0Q29yZSgpO1xuXG4gIGlmIChwcm9wZXJ0eSBpbiBfcHJvcGVydHlBbGlhc2VzICYmIHByb3BlcnR5ICE9PSBcInRyYW5zZm9ybVwiKSB7XG4gICAgcHJvcGVydHkgPSBfcHJvcGVydHlBbGlhc2VzW3Byb3BlcnR5XTtcblxuICAgIGlmICh+cHJvcGVydHkuaW5kZXhPZihcIixcIikpIHtcbiAgICAgIHByb3BlcnR5ID0gcHJvcGVydHkuc3BsaXQoXCIsXCIpWzBdO1xuICAgIH1cbiAgfVxuXG4gIGlmIChfdHJhbnNmb3JtUHJvcHNbcHJvcGVydHldICYmIHByb3BlcnR5ICE9PSBcInRyYW5zZm9ybVwiKSB7XG4gICAgdmFsdWUgPSBfcGFyc2VUcmFuc2Zvcm0odGFyZ2V0LCB1bmNhY2hlKTtcbiAgICB2YWx1ZSA9IHByb3BlcnR5ICE9PSBcInRyYW5zZm9ybU9yaWdpblwiID8gdmFsdWVbcHJvcGVydHldIDogdmFsdWUuc3ZnID8gdmFsdWUub3JpZ2luIDogX2ZpcnN0VHdvT25seShfZ2V0Q29tcHV0ZWRQcm9wZXJ0eSh0YXJnZXQsIF90cmFuc2Zvcm1PcmlnaW5Qcm9wKSkgKyBcIiBcIiArIHZhbHVlLnpPcmlnaW4gKyBcInB4XCI7XG4gIH0gZWxzZSB7XG4gICAgdmFsdWUgPSB0YXJnZXQuc3R5bGVbcHJvcGVydHldO1xuXG4gICAgaWYgKCF2YWx1ZSB8fCB2YWx1ZSA9PT0gXCJhdXRvXCIgfHwgdW5jYWNoZSB8fCB+KHZhbHVlICsgXCJcIikuaW5kZXhPZihcImNhbGMoXCIpKSB7XG4gICAgICB2YWx1ZSA9IF9zcGVjaWFsUHJvcHNbcHJvcGVydHldICYmIF9zcGVjaWFsUHJvcHNbcHJvcGVydHldKHRhcmdldCwgcHJvcGVydHksIHVuaXQpIHx8IF9nZXRDb21wdXRlZFByb3BlcnR5KHRhcmdldCwgcHJvcGVydHkpIHx8IF9nZXRQcm9wZXJ0eSh0YXJnZXQsIHByb3BlcnR5KSB8fCAocHJvcGVydHkgPT09IFwib3BhY2l0eVwiID8gMSA6IDApOyAvLyBub3RlOiBzb21lIGJyb3dzZXJzLCBsaWtlIEZpcmVmb3gsIGRvbid0IHJlcG9ydCBib3JkZXJSYWRpdXMgY29ycmVjdGx5ISBJbnN0ZWFkLCBpdCBvbmx5IHJlcG9ydHMgZXZlcnkgY29ybmVyIGxpa2UgIGJvcmRlclRvcExlZnRSYWRpdXNcbiAgICB9XG4gIH1cblxuICByZXR1cm4gdW5pdCAmJiAhfih2YWx1ZSArIFwiXCIpLnRyaW0oKS5pbmRleE9mKFwiIFwiKSA/IF9jb252ZXJ0VG9Vbml0KHRhcmdldCwgcHJvcGVydHksIHZhbHVlLCB1bml0KSArIHVuaXQgOiB2YWx1ZTtcbn0sXG4gICAgX3R3ZWVuQ29tcGxleENTU1N0cmluZyA9IGZ1bmN0aW9uIF90d2VlbkNvbXBsZXhDU1NTdHJpbmcodGFyZ2V0LCBwcm9wLCBzdGFydCwgZW5kKSB7XG4gIC8vIG5vdGU6IHdlIGNhbGwgX3R3ZWVuQ29tcGxleENTU1N0cmluZy5jYWxsKHBsdWdpbkluc3RhbmNlLi4uKSB0byBlbnN1cmUgdGhhdCBpdCdzIHNjb3BlZCBwcm9wZXJseS4gV2UgbWF5IGNhbGwgaXQgZnJvbSB3aXRoaW4gYSBwbHVnaW4gdG9vLCB0aHVzIFwidGhpc1wiIHdvdWxkIHJlZmVyIHRvIHRoZSBwbHVnaW4uXG4gIGlmICghc3RhcnQgfHwgc3RhcnQgPT09IFwibm9uZVwiKSB7XG4gICAgLy8gc29tZSBicm93c2VycyBsaWtlIFNhZmFyaSBhY3R1YWxseSBQUkVGRVIgdGhlIHByZWZpeGVkIHByb3BlcnR5IGFuZCBtaXMtcmVwb3J0IHRoZSB1bnByZWZpeGVkIHZhbHVlIGxpa2UgY2xpcFBhdGggKEJVRykuIEluIG90aGVyIHdvcmRzLCBldmVuIHRob3VnaCBjbGlwUGF0aCBleGlzdHMgaW4gdGhlIHN0eWxlIChcImNsaXBQYXRoXCIgaW4gdGFyZ2V0LnN0eWxlKSBhbmQgaXQncyBzZXQgaW4gdGhlIENTUyBwcm9wZXJseSAoYWxvbmcgd2l0aCAtd2Via2l0LWNsaXAtcGF0aCksIFNhZmFyaSByZXBvcnRzIGNsaXBQYXRoIGFzIFwibm9uZVwiIHdoZXJlYXMgV2Via2l0Q2xpcFBhdGggcmVwb3J0cyBhY2N1cmF0ZWx5IGxpa2UgXCJlbGxpcHNlKDEwMCUgMCUgYXQgNTAlIDAlKVwiLCBzbyBpbiB0aGlzIGNhc2Ugd2UgbXVzdCBTV0lUQ0ggdG8gdXNpbmcgdGhlIHByZWZpeGVkIHByb3BlcnR5IGluc3RlYWQuIFNlZSBodHRwczovL2dzYXAuY29tL2ZvcnVtcy90b3BpYy8xODMxMC1jbGlwcGF0aC1kb2VzbnQtd29yay1vbi1pb3MvXG4gICAgdmFyIHAgPSBfY2hlY2tQcm9wUHJlZml4KHByb3AsIHRhcmdldCwgMSksXG4gICAgICAgIHMgPSBwICYmIF9nZXRDb21wdXRlZFByb3BlcnR5KHRhcmdldCwgcCwgMSk7XG5cbiAgICBpZiAocyAmJiBzICE9PSBzdGFydCkge1xuICAgICAgcHJvcCA9IHA7XG4gICAgICBzdGFydCA9IHM7XG4gICAgfSBlbHNlIGlmIChwcm9wID09PSBcImJvcmRlckNvbG9yXCIpIHtcbiAgICAgIHN0YXJ0ID0gX2dldENvbXB1dGVkUHJvcGVydHkodGFyZ2V0LCBcImJvcmRlclRvcENvbG9yXCIpOyAvLyBGaXJlZm94IGJ1ZzogYWx3YXlzIHJlcG9ydHMgXCJib3JkZXJDb2xvclwiIGFzIFwiXCIsIHNvIHdlIG11c3QgZmFsbCBiYWNrIHRvIGJvcmRlclRvcENvbG9yLiBTZWUgaHR0cHM6Ly9nc2FwLmNvbS9mb3J1bXMvdG9waWMvMjQ1ODMtaG93LXRvLXJldHVybi1jb2xvcnMtdGhhdC1pLWhhZC1hZnRlci1yZXZlcnNlL1xuICAgIH1cbiAgfVxuXG4gIHZhciBwdCA9IG5ldyBQcm9wVHdlZW4odGhpcy5fcHQsIHRhcmdldC5zdHlsZSwgcHJvcCwgMCwgMSwgX3JlbmRlckNvbXBsZXhTdHJpbmcpLFxuICAgICAgaW5kZXggPSAwLFxuICAgICAgbWF0Y2hJbmRleCA9IDAsXG4gICAgICBhLFxuICAgICAgcmVzdWx0LFxuICAgICAgc3RhcnRWYWx1ZXMsXG4gICAgICBzdGFydE51bSxcbiAgICAgIGNvbG9yLFxuICAgICAgc3RhcnRWYWx1ZSxcbiAgICAgIGVuZFZhbHVlLFxuICAgICAgZW5kTnVtLFxuICAgICAgY2h1bmssXG4gICAgICBlbmRVbml0LFxuICAgICAgc3RhcnRVbml0LFxuICAgICAgZW5kVmFsdWVzO1xuICBwdC5iID0gc3RhcnQ7XG4gIHB0LmUgPSBlbmQ7XG4gIHN0YXJ0ICs9IFwiXCI7IC8vIGVuc3VyZSB2YWx1ZXMgYXJlIHN0cmluZ3NcblxuICBlbmQgKz0gXCJcIjtcblxuICBpZiAoZW5kLnN1YnN0cmluZygwLCA2KSA9PT0gXCJ2YXIoLS1cIikge1xuICAgIGVuZCA9IF9nZXRDb21wdXRlZFByb3BlcnR5KHRhcmdldCwgZW5kLnN1YnN0cmluZyg0LCBlbmQuaW5kZXhPZihcIilcIikpKTtcbiAgfVxuXG4gIGlmIChlbmQgPT09IFwiYXV0b1wiKSB7XG4gICAgc3RhcnRWYWx1ZSA9IHRhcmdldC5zdHlsZVtwcm9wXTtcbiAgICB0YXJnZXQuc3R5bGVbcHJvcF0gPSBlbmQ7XG4gICAgZW5kID0gX2dldENvbXB1dGVkUHJvcGVydHkodGFyZ2V0LCBwcm9wKSB8fCBlbmQ7XG4gICAgc3RhcnRWYWx1ZSA/IHRhcmdldC5zdHlsZVtwcm9wXSA9IHN0YXJ0VmFsdWUgOiBfcmVtb3ZlUHJvcGVydHkodGFyZ2V0LCBwcm9wKTtcbiAgfVxuXG4gIGEgPSBbc3RhcnQsIGVuZF07XG5cbiAgX2NvbG9yU3RyaW5nRmlsdGVyKGEpOyAvLyBwYXNzIGFuIGFycmF5IHdpdGggdGhlIHN0YXJ0aW5nIGFuZCBlbmRpbmcgdmFsdWVzIGFuZCBsZXQgdGhlIGZpbHRlciBkbyB3aGF0ZXZlciBpdCBuZWVkcyB0byB0aGUgdmFsdWVzLiBJZiBjb2xvcnMgYXJlIGZvdW5kLCBpdCByZXR1cm5zIHRydWUgYW5kIHRoZW4gd2UgbXVzdCBtYXRjaCB3aGVyZSB0aGUgY29sb3Igc2hvd3MgdXAgb3JkZXItd2lzZSBiZWNhdXNlIGZvciB0aGluZ3MgbGlrZSBib3hTaGFkb3csIHNvbWV0aW1lcyB0aGUgYnJvd3NlciBwcm92aWRlcyB0aGUgY29tcHV0ZWQgdmFsdWVzIHdpdGggdGhlIGNvbG9yIEZJUlNULCBidXQgdGhlIHVzZXIgcHJvdmlkZXMgaXQgd2l0aCB0aGUgY29sb3IgTEFTVCwgc28gZmxpcCB0aGVtIGlmIG5lY2Vzc2FyeS4gU2FtZSBmb3IgZHJvcC1zaGFkb3coKS5cblxuXG4gIHN0YXJ0ID0gYVswXTtcbiAgZW5kID0gYVsxXTtcbiAgc3RhcnRWYWx1ZXMgPSBzdGFydC5tYXRjaChfbnVtV2l0aFVuaXRFeHApIHx8IFtdO1xuICBlbmRWYWx1ZXMgPSBlbmQubWF0Y2goX251bVdpdGhVbml0RXhwKSB8fCBbXTtcblxuICBpZiAoZW5kVmFsdWVzLmxlbmd0aCkge1xuICAgIHdoaWxlIChyZXN1bHQgPSBfbnVtV2l0aFVuaXRFeHAuZXhlYyhlbmQpKSB7XG4gICAgICBlbmRWYWx1ZSA9IHJlc3VsdFswXTtcbiAgICAgIGNodW5rID0gZW5kLnN1YnN0cmluZyhpbmRleCwgcmVzdWx0LmluZGV4KTtcblxuICAgICAgaWYgKGNvbG9yKSB7XG4gICAgICAgIGNvbG9yID0gKGNvbG9yICsgMSkgJSA1O1xuICAgICAgfSBlbHNlIGlmIChjaHVuay5zdWJzdHIoLTUpID09PSBcInJnYmEoXCIgfHwgY2h1bmsuc3Vic3RyKC01KSA9PT0gXCJoc2xhKFwiKSB7XG4gICAgICAgIGNvbG9yID0gMTtcbiAgICAgIH1cblxuICAgICAgaWYgKGVuZFZhbHVlICE9PSAoc3RhcnRWYWx1ZSA9IHN0YXJ0VmFsdWVzW21hdGNoSW5kZXgrK10gfHwgXCJcIikpIHtcbiAgICAgICAgc3RhcnROdW0gPSBwYXJzZUZsb2F0KHN0YXJ0VmFsdWUpIHx8IDA7XG4gICAgICAgIHN0YXJ0VW5pdCA9IHN0YXJ0VmFsdWUuc3Vic3RyKChzdGFydE51bSArIFwiXCIpLmxlbmd0aCk7XG4gICAgICAgIGVuZFZhbHVlLmNoYXJBdCgxKSA9PT0gXCI9XCIgJiYgKGVuZFZhbHVlID0gX3BhcnNlUmVsYXRpdmUoc3RhcnROdW0sIGVuZFZhbHVlKSArIHN0YXJ0VW5pdCk7XG4gICAgICAgIGVuZE51bSA9IHBhcnNlRmxvYXQoZW5kVmFsdWUpO1xuICAgICAgICBlbmRVbml0ID0gZW5kVmFsdWUuc3Vic3RyKChlbmROdW0gKyBcIlwiKS5sZW5ndGgpO1xuICAgICAgICBpbmRleCA9IF9udW1XaXRoVW5pdEV4cC5sYXN0SW5kZXggLSBlbmRVbml0Lmxlbmd0aDtcblxuICAgICAgICBpZiAoIWVuZFVuaXQpIHtcbiAgICAgICAgICAvL2lmIHNvbWV0aGluZyBsaWtlIFwicGVyc3BlY3RpdmU6MzAwXCIgaXMgcGFzc2VkIGluIGFuZCB3ZSBtdXN0IGFkZCBhIHVuaXQgdG8gdGhlIGVuZFxuICAgICAgICAgIGVuZFVuaXQgPSBlbmRVbml0IHx8IF9jb25maWcudW5pdHNbcHJvcF0gfHwgc3RhcnRVbml0O1xuXG4gICAgICAgICAgaWYgKGluZGV4ID09PSBlbmQubGVuZ3RoKSB7XG4gICAgICAgICAgICBlbmQgKz0gZW5kVW5pdDtcbiAgICAgICAgICAgIHB0LmUgKz0gZW5kVW5pdDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoc3RhcnRVbml0ICE9PSBlbmRVbml0KSB7XG4gICAgICAgICAgc3RhcnROdW0gPSBfY29udmVydFRvVW5pdCh0YXJnZXQsIHByb3AsIHN0YXJ0VmFsdWUsIGVuZFVuaXQpIHx8IDA7XG4gICAgICAgIH0gLy8gdGhlc2UgbmVzdGVkIFByb3BUd2VlbnMgYXJlIGhhbmRsZWQgaW4gYSBzcGVjaWFsIHdheSAtIHdlJ2xsIG5ldmVyIGFjdHVhbGx5IGNhbGwgYSByZW5kZXIgb3Igc2V0dGVyIG1ldGhvZCBvbiB0aGVtLiBXZSdsbCBqdXN0IGxvb3AgdGhyb3VnaCB0aGVtIGluIHRoZSBwYXJlbnQgY29tcGxleCBzdHJpbmcgUHJvcFR3ZWVuJ3MgcmVuZGVyIG1ldGhvZC5cblxuXG4gICAgICAgIHB0Ll9wdCA9IHtcbiAgICAgICAgICBfbmV4dDogcHQuX3B0LFxuICAgICAgICAgIHA6IGNodW5rIHx8IG1hdGNoSW5kZXggPT09IDEgPyBjaHVuayA6IFwiLFwiLFxuICAgICAgICAgIC8vbm90ZTogU1ZHIHNwZWMgYWxsb3dzIG9taXNzaW9uIG9mIGNvbW1hL3NwYWNlIHdoZW4gYSBuZWdhdGl2ZSBzaWduIGlzIHdlZGdlZCBiZXR3ZWVuIHR3byBudW1iZXJzLCBsaWtlIDIuNS01LjMgaW5zdGVhZCBvZiAyLjUsLTUuMyBidXQgd2hlbiB0d2VlbmluZywgdGhlIG5lZ2F0aXZlIHZhbHVlIG1heSBzd2l0Y2ggdG8gcG9zaXRpdmUsIHNvIHdlIGluc2VydCB0aGUgY29tbWEganVzdCBpbiBjYXNlLlxuICAgICAgICAgIHM6IHN0YXJ0TnVtLFxuICAgICAgICAgIGM6IGVuZE51bSAtIHN0YXJ0TnVtLFxuICAgICAgICAgIG06IGNvbG9yICYmIGNvbG9yIDwgNCB8fCBwcm9wID09PSBcInpJbmRleFwiID8gTWF0aC5yb3VuZCA6IDBcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBwdC5jID0gaW5kZXggPCBlbmQubGVuZ3RoID8gZW5kLnN1YnN0cmluZyhpbmRleCwgZW5kLmxlbmd0aCkgOiBcIlwiOyAvL3dlIHVzZSB0aGUgXCJjXCIgb2YgdGhlIFByb3BUd2VlbiB0byBzdG9yZSB0aGUgZmluYWwgcGFydCBvZiB0aGUgc3RyaW5nIChhZnRlciB0aGUgbGFzdCBudW1iZXIpXG4gIH0gZWxzZSB7XG4gICAgcHQuciA9IHByb3AgPT09IFwiZGlzcGxheVwiICYmIGVuZCA9PT0gXCJub25lXCIgPyBfcmVuZGVyTm9uVHdlZW5pbmdWYWx1ZU9ubHlBdEVuZCA6IF9yZW5kZXJOb25Ud2VlbmluZ1ZhbHVlO1xuICB9XG5cbiAgX3JlbEV4cC50ZXN0KGVuZCkgJiYgKHB0LmUgPSAwKTsgLy9pZiB0aGUgZW5kIHN0cmluZyBjb250YWlucyByZWxhdGl2ZSB2YWx1ZXMgb3IgZHluYW1pYyByYW5kb20oLi4uKSB2YWx1ZXMsIGRlbGV0ZSB0aGUgZW5kIGl0IHNvIHRoYXQgb24gdGhlIGZpbmFsIHJlbmRlciB3ZSBkb24ndCBhY3R1YWxseSBzZXQgaXQgdG8gdGhlIHN0cmluZyB3aXRoICs9IG9yIC09IGNoYXJhY3RlcnMgKGZvcmNlcyBpdCB0byB1c2UgdGhlIGNhbGN1bGF0ZWQgdmFsdWUpLlxuXG4gIHRoaXMuX3B0ID0gcHQ7IC8vc3RhcnQgdGhlIGxpbmtlZCBsaXN0IHdpdGggdGhpcyBuZXcgUHJvcFR3ZWVuLiBSZW1lbWJlciwgd2UgY2FsbCBfdHdlZW5Db21wbGV4Q1NTU3RyaW5nLmNhbGwocGx1Z2luSW5zdGFuY2UuLi4pIHRvIGVuc3VyZSB0aGF0IGl0J3Mgc2NvcGVkIHByb3Blcmx5LiBXZSBtYXkgY2FsbCBpdCBmcm9tIHdpdGhpbiBhbm90aGVyIHBsdWdpbiB0b28sIHRodXMgXCJ0aGlzXCIgd291bGQgcmVmZXIgdG8gdGhlIHBsdWdpbi5cblxuICByZXR1cm4gcHQ7XG59LFxuICAgIF9rZXl3b3JkVG9QZXJjZW50ID0ge1xuICB0b3A6IFwiMCVcIixcbiAgYm90dG9tOiBcIjEwMCVcIixcbiAgbGVmdDogXCIwJVwiLFxuICByaWdodDogXCIxMDAlXCIsXG4gIGNlbnRlcjogXCI1MCVcIlxufSxcbiAgICBfY29udmVydEtleXdvcmRzVG9QZXJjZW50YWdlcyA9IGZ1bmN0aW9uIF9jb252ZXJ0S2V5d29yZHNUb1BlcmNlbnRhZ2VzKHZhbHVlKSB7XG4gIHZhciBzcGxpdCA9IHZhbHVlLnNwbGl0KFwiIFwiKSxcbiAgICAgIHggPSBzcGxpdFswXSxcbiAgICAgIHkgPSBzcGxpdFsxXSB8fCBcIjUwJVwiO1xuXG4gIGlmICh4ID09PSBcInRvcFwiIHx8IHggPT09IFwiYm90dG9tXCIgfHwgeSA9PT0gXCJsZWZ0XCIgfHwgeSA9PT0gXCJyaWdodFwiKSB7XG4gICAgLy90aGUgdXNlciBwcm92aWRlZCB0aGVtIGluIHRoZSB3cm9uZyBvcmRlciwgc28gZmxpcCB0aGVtXG4gICAgdmFsdWUgPSB4O1xuICAgIHggPSB5O1xuICAgIHkgPSB2YWx1ZTtcbiAgfVxuXG4gIHNwbGl0WzBdID0gX2tleXdvcmRUb1BlcmNlbnRbeF0gfHwgeDtcbiAgc3BsaXRbMV0gPSBfa2V5d29yZFRvUGVyY2VudFt5XSB8fCB5O1xuICByZXR1cm4gc3BsaXQuam9pbihcIiBcIik7XG59LFxuICAgIF9yZW5kZXJDbGVhclByb3BzID0gZnVuY3Rpb24gX3JlbmRlckNsZWFyUHJvcHMocmF0aW8sIGRhdGEpIHtcbiAgaWYgKGRhdGEudHdlZW4gJiYgZGF0YS50d2Vlbi5fdGltZSA9PT0gZGF0YS50d2Vlbi5fZHVyKSB7XG4gICAgdmFyIHRhcmdldCA9IGRhdGEudCxcbiAgICAgICAgc3R5bGUgPSB0YXJnZXQuc3R5bGUsXG4gICAgICAgIHByb3BzID0gZGF0YS51LFxuICAgICAgICBjYWNoZSA9IHRhcmdldC5fZ3NhcCxcbiAgICAgICAgcHJvcCxcbiAgICAgICAgY2xlYXJUcmFuc2Zvcm1zLFxuICAgICAgICBpO1xuXG4gICAgaWYgKHByb3BzID09PSBcImFsbFwiIHx8IHByb3BzID09PSB0cnVlKSB7XG4gICAgICBzdHlsZS5jc3NUZXh0ID0gXCJcIjtcbiAgICAgIGNsZWFyVHJhbnNmb3JtcyA9IDE7XG4gICAgfSBlbHNlIHtcbiAgICAgIHByb3BzID0gcHJvcHMuc3BsaXQoXCIsXCIpO1xuICAgICAgaSA9IHByb3BzLmxlbmd0aDtcblxuICAgICAgd2hpbGUgKC0taSA+IC0xKSB7XG4gICAgICAgIHByb3AgPSBwcm9wc1tpXTtcblxuICAgICAgICBpZiAoX3RyYW5zZm9ybVByb3BzW3Byb3BdKSB7XG4gICAgICAgICAgY2xlYXJUcmFuc2Zvcm1zID0gMTtcbiAgICAgICAgICBwcm9wID0gcHJvcCA9PT0gXCJ0cmFuc2Zvcm1PcmlnaW5cIiA/IF90cmFuc2Zvcm1PcmlnaW5Qcm9wIDogX3RyYW5zZm9ybVByb3A7XG4gICAgICAgIH1cblxuICAgICAgICBfcmVtb3ZlUHJvcGVydHkodGFyZ2V0LCBwcm9wKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoY2xlYXJUcmFuc2Zvcm1zKSB7XG4gICAgICBfcmVtb3ZlUHJvcGVydHkodGFyZ2V0LCBfdHJhbnNmb3JtUHJvcCk7XG5cbiAgICAgIGlmIChjYWNoZSkge1xuICAgICAgICBjYWNoZS5zdmcgJiYgdGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZShcInRyYW5zZm9ybVwiKTtcbiAgICAgICAgc3R5bGUuc2NhbGUgPSBzdHlsZS5yb3RhdGUgPSBzdHlsZS50cmFuc2xhdGUgPSBcIm5vbmVcIjtcblxuICAgICAgICBfcGFyc2VUcmFuc2Zvcm0odGFyZ2V0LCAxKTsgLy8gZm9yY2UgYWxsIHRoZSBjYWNoZWQgdmFsdWVzIGJhY2sgdG8gXCJub3JtYWxcIi9pZGVudGl0eSwgb3RoZXJ3aXNlIGlmIHRoZXJlJ3MgYW5vdGhlciB0d2VlbiB0aGF0J3MgYWxyZWFkeSBzZXQgdG8gcmVuZGVyIHRyYW5zZm9ybXMgb24gdGhpcyBlbGVtZW50LCBpdCBjb3VsZCBkaXNwbGF5IHRoZSB3cm9uZyB2YWx1ZXMuXG5cblxuICAgICAgICBjYWNoZS51bmNhY2hlID0gMTtcblxuICAgICAgICBfcmVtb3ZlSW5kZXBlbmRlbnRUcmFuc2Zvcm1zKHN0eWxlKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn0sXG4gICAgLy8gbm90ZTogc3BlY2lhbFByb3BzIHNob3VsZCByZXR1cm4gMSBpZiAoYW5kIG9ubHkgaWYpIHRoZXkgaGF2ZSBhIG5vbi16ZXJvIHByaW9yaXR5LiBJdCBpbmRpY2F0ZXMgd2UgbmVlZCB0byBzb3J0IHRoZSBsaW5rZWQgbGlzdC5cbl9zcGVjaWFsUHJvcHMgPSB7XG4gIGNsZWFyUHJvcHM6IGZ1bmN0aW9uIGNsZWFyUHJvcHMocGx1Z2luLCB0YXJnZXQsIHByb3BlcnR5LCBlbmRWYWx1ZSwgdHdlZW4pIHtcbiAgICBpZiAodHdlZW4uZGF0YSAhPT0gXCJpc0Zyb21TdGFydFwiKSB7XG4gICAgICB2YXIgcHQgPSBwbHVnaW4uX3B0ID0gbmV3IFByb3BUd2VlbihwbHVnaW4uX3B0LCB0YXJnZXQsIHByb3BlcnR5LCAwLCAwLCBfcmVuZGVyQ2xlYXJQcm9wcyk7XG4gICAgICBwdC51ID0gZW5kVmFsdWU7XG4gICAgICBwdC5wciA9IC0xMDtcbiAgICAgIHB0LnR3ZWVuID0gdHdlZW47XG5cbiAgICAgIHBsdWdpbi5fcHJvcHMucHVzaChwcm9wZXJ0eSk7XG5cbiAgICAgIHJldHVybiAxO1xuICAgIH1cbiAgfVxuICAvKiBjbGFzc05hbWUgZmVhdHVyZSAoYWJvdXQgMC40a2IgZ3ppcHBlZCkuXG4gICwgY2xhc3NOYW1lKHBsdWdpbiwgdGFyZ2V0LCBwcm9wZXJ0eSwgZW5kVmFsdWUsIHR3ZWVuKSB7XG4gIFx0bGV0IF9yZW5kZXJDbGFzc05hbWUgPSAocmF0aW8sIGRhdGEpID0+IHtcbiAgXHRcdFx0ZGF0YS5jc3MucmVuZGVyKHJhdGlvLCBkYXRhLmNzcyk7XG4gIFx0XHRcdGlmICghcmF0aW8gfHwgcmF0aW8gPT09IDEpIHtcbiAgXHRcdFx0XHRsZXQgaW5saW5lID0gZGF0YS5ybXYsXG4gIFx0XHRcdFx0XHR0YXJnZXQgPSBkYXRhLnQsXG4gIFx0XHRcdFx0XHRwO1xuICBcdFx0XHRcdHRhcmdldC5zZXRBdHRyaWJ1dGUoXCJjbGFzc1wiLCByYXRpbyA/IGRhdGEuZSA6IGRhdGEuYik7XG4gIFx0XHRcdFx0Zm9yIChwIGluIGlubGluZSkge1xuICBcdFx0XHRcdFx0X3JlbW92ZVByb3BlcnR5KHRhcmdldCwgcCk7XG4gIFx0XHRcdFx0fVxuICBcdFx0XHR9XG4gIFx0XHR9LFxuICBcdFx0X2dldEFsbFN0eWxlcyA9ICh0YXJnZXQpID0+IHtcbiAgXHRcdFx0bGV0IHN0eWxlcyA9IHt9LFxuICBcdFx0XHRcdGNvbXB1dGVkID0gZ2V0Q29tcHV0ZWRTdHlsZSh0YXJnZXQpLFxuICBcdFx0XHRcdHA7XG4gIFx0XHRcdGZvciAocCBpbiBjb21wdXRlZCkge1xuICBcdFx0XHRcdGlmIChpc05hTihwKSAmJiBwICE9PSBcImNzc1RleHRcIiAmJiBwICE9PSBcImxlbmd0aFwiKSB7XG4gIFx0XHRcdFx0XHRzdHlsZXNbcF0gPSBjb21wdXRlZFtwXTtcbiAgXHRcdFx0XHR9XG4gIFx0XHRcdH1cbiAgXHRcdFx0X3NldERlZmF1bHRzKHN0eWxlcywgX3BhcnNlVHJhbnNmb3JtKHRhcmdldCwgMSkpO1xuICBcdFx0XHRyZXR1cm4gc3R5bGVzO1xuICBcdFx0fSxcbiAgXHRcdHN0YXJ0Q2xhc3NMaXN0ID0gdGFyZ2V0LmdldEF0dHJpYnV0ZShcImNsYXNzXCIpLFxuICBcdFx0c3R5bGUgPSB0YXJnZXQuc3R5bGUsXG4gIFx0XHRjc3NUZXh0ID0gc3R5bGUuY3NzVGV4dCxcbiAgXHRcdGNhY2hlID0gdGFyZ2V0Ll9nc2FwLFxuICBcdFx0Y2xhc3NQVCA9IGNhY2hlLmNsYXNzUFQsXG4gIFx0XHRpbmxpbmVUb1JlbW92ZUF0RW5kID0ge30sXG4gIFx0XHRkYXRhID0ge3Q6dGFyZ2V0LCBwbHVnaW46cGx1Z2luLCBybXY6aW5saW5lVG9SZW1vdmVBdEVuZCwgYjpzdGFydENsYXNzTGlzdCwgZTooZW5kVmFsdWUuY2hhckF0KDEpICE9PSBcIj1cIikgPyBlbmRWYWx1ZSA6IHN0YXJ0Q2xhc3NMaXN0LnJlcGxhY2UobmV3IFJlZ0V4cChcIig/OlxcXFxzfF4pXCIgKyBlbmRWYWx1ZS5zdWJzdHIoMikgKyBcIig/IVtcXFxcdy1dKVwiKSwgXCJcIikgKyAoKGVuZFZhbHVlLmNoYXJBdCgwKSA9PT0gXCIrXCIpID8gXCIgXCIgKyBlbmRWYWx1ZS5zdWJzdHIoMikgOiBcIlwiKX0sXG4gIFx0XHRjaGFuZ2luZ1ZhcnMgPSB7fSxcbiAgXHRcdHN0YXJ0VmFycyA9IF9nZXRBbGxTdHlsZXModGFyZ2V0KSxcbiAgXHRcdHRyYW5zZm9ybVJlbGF0ZWQgPSAvKHRyYW5zZm9ybXxwZXJzcGVjdGl2ZSkvaSxcbiAgXHRcdGVuZFZhcnMsIHA7XG4gIFx0aWYgKGNsYXNzUFQpIHtcbiAgXHRcdGNsYXNzUFQucigxLCBjbGFzc1BULmQpO1xuICBcdFx0X3JlbW92ZUxpbmtlZExpc3RJdGVtKGNsYXNzUFQuZC5wbHVnaW4sIGNsYXNzUFQsIFwiX3B0XCIpO1xuICBcdH1cbiAgXHR0YXJnZXQuc2V0QXR0cmlidXRlKFwiY2xhc3NcIiwgZGF0YS5lKTtcbiAgXHRlbmRWYXJzID0gX2dldEFsbFN0eWxlcyh0YXJnZXQsIHRydWUpO1xuICBcdHRhcmdldC5zZXRBdHRyaWJ1dGUoXCJjbGFzc1wiLCBzdGFydENsYXNzTGlzdCk7XG4gIFx0Zm9yIChwIGluIGVuZFZhcnMpIHtcbiAgXHRcdGlmIChlbmRWYXJzW3BdICE9PSBzdGFydFZhcnNbcF0gJiYgIXRyYW5zZm9ybVJlbGF0ZWQudGVzdChwKSkge1xuICBcdFx0XHRjaGFuZ2luZ1ZhcnNbcF0gPSBlbmRWYXJzW3BdO1xuICBcdFx0XHRpZiAoIXN0eWxlW3BdICYmIHN0eWxlW3BdICE9PSBcIjBcIikge1xuICBcdFx0XHRcdGlubGluZVRvUmVtb3ZlQXRFbmRbcF0gPSAxO1xuICBcdFx0XHR9XG4gIFx0XHR9XG4gIFx0fVxuICBcdGNhY2hlLmNsYXNzUFQgPSBwbHVnaW4uX3B0ID0gbmV3IFByb3BUd2VlbihwbHVnaW4uX3B0LCB0YXJnZXQsIFwiY2xhc3NOYW1lXCIsIDAsIDAsIF9yZW5kZXJDbGFzc05hbWUsIGRhdGEsIDAsIC0xMSk7XG4gIFx0aWYgKHN0eWxlLmNzc1RleHQgIT09IGNzc1RleHQpIHsgLy9vbmx5IGFwcGx5IGlmIHRoaW5ncyBjaGFuZ2UuIE90aGVyd2lzZSwgaW4gY2FzZXMgbGlrZSBhIGJhY2tncm91bmQtaW1hZ2UgdGhhdCdzIHB1bGxlZCBkeW5hbWljYWxseSwgaXQgY291bGQgY2F1c2UgYSByZWZyZXNoLiBTZWUgaHR0cHM6Ly9nc2FwLmNvbS9mb3J1bXMvdG9waWMvMjAzNjgtcG9zc2libGUtZ3NhcC1idWctc3dpdGNoaW5nLWNsYXNzbmFtZXMtaW4tY2hyb21lLy5cbiAgXHRcdHN0eWxlLmNzc1RleHQgPSBjc3NUZXh0OyAvL3dlIHJlY29yZGVkIGNzc1RleHQgYmVmb3JlIHdlIHN3YXBwZWQgY2xhc3NlcyBhbmQgcmFuIF9nZXRBbGxTdHlsZXMoKSBiZWNhdXNlIGluIGNhc2VzIHdoZW4gYSBjbGFzc05hbWUgdHdlZW4gaXMgb3ZlcndyaXR0ZW4sIHdlIHJlbW92ZSBhbGwgdGhlIHJlbGF0ZWQgdHdlZW5pbmcgcHJvcGVydGllcyBmcm9tIHRoYXQgY2xhc3MgY2hhbmdlIChvdGhlcndpc2UgY2xhc3Mtc3BlY2lmaWMgc3R1ZmYgY2FuJ3Qgb3ZlcnJpZGUgcHJvcGVydGllcyB3ZSd2ZSBkaXJlY3RseSBzZXQgb24gdGhlIHRhcmdldCdzIHN0eWxlIG9iamVjdCBkdWUgdG8gc3BlY2lmaWNpdHkpLlxuICBcdH1cbiAgXHRfcGFyc2VUcmFuc2Zvcm0odGFyZ2V0LCB0cnVlKTsgLy90byBjbGVhciB0aGUgY2FjaGluZyBvZiB0cmFuc2Zvcm1zXG4gIFx0ZGF0YS5jc3MgPSBuZXcgZ3NhcC5wbHVnaW5zLmNzcygpO1xuICBcdGRhdGEuY3NzLmluaXQodGFyZ2V0LCBjaGFuZ2luZ1ZhcnMsIHR3ZWVuKTtcbiAgXHRwbHVnaW4uX3Byb3BzLnB1c2goLi4uZGF0YS5jc3MuX3Byb3BzKTtcbiAgXHRyZXR1cm4gMTtcbiAgfVxuICAqL1xuXG59LFxuXG4vKlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqIFRSQU5TRk9STVNcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKi9cbl9pZGVudGl0eTJETWF0cml4ID0gWzEsIDAsIDAsIDEsIDAsIDBdLFxuICAgIF9yb3RhdGlvbmFsUHJvcGVydGllcyA9IHt9LFxuICAgIF9pc051bGxUcmFuc2Zvcm0gPSBmdW5jdGlvbiBfaXNOdWxsVHJhbnNmb3JtKHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZSA9PT0gXCJtYXRyaXgoMSwgMCwgMCwgMSwgMCwgMClcIiB8fCB2YWx1ZSA9PT0gXCJub25lXCIgfHwgIXZhbHVlO1xufSxcbiAgICBfZ2V0Q29tcHV0ZWRUcmFuc2Zvcm1NYXRyaXhBc0FycmF5ID0gZnVuY3Rpb24gX2dldENvbXB1dGVkVHJhbnNmb3JtTWF0cml4QXNBcnJheSh0YXJnZXQpIHtcbiAgdmFyIG1hdHJpeFN0cmluZyA9IF9nZXRDb21wdXRlZFByb3BlcnR5KHRhcmdldCwgX3RyYW5zZm9ybVByb3ApO1xuXG4gIHJldHVybiBfaXNOdWxsVHJhbnNmb3JtKG1hdHJpeFN0cmluZykgPyBfaWRlbnRpdHkyRE1hdHJpeCA6IG1hdHJpeFN0cmluZy5zdWJzdHIoNykubWF0Y2goX251bUV4cCkubWFwKF9yb3VuZCk7XG59LFxuICAgIF9nZXRNYXRyaXggPSBmdW5jdGlvbiBfZ2V0TWF0cml4KHRhcmdldCwgZm9yY2UyRCkge1xuICB2YXIgY2FjaGUgPSB0YXJnZXQuX2dzYXAgfHwgX2dldENhY2hlKHRhcmdldCksXG4gICAgICBzdHlsZSA9IHRhcmdldC5zdHlsZSxcbiAgICAgIG1hdHJpeCA9IF9nZXRDb21wdXRlZFRyYW5zZm9ybU1hdHJpeEFzQXJyYXkodGFyZ2V0KSxcbiAgICAgIHBhcmVudCxcbiAgICAgIG5leHRTaWJsaW5nLFxuICAgICAgdGVtcCxcbiAgICAgIGFkZGVkVG9ET007XG5cbiAgaWYgKGNhY2hlLnN2ZyAmJiB0YXJnZXQuZ2V0QXR0cmlidXRlKFwidHJhbnNmb3JtXCIpKSB7XG4gICAgdGVtcCA9IHRhcmdldC50cmFuc2Zvcm0uYmFzZVZhbC5jb25zb2xpZGF0ZSgpLm1hdHJpeDsgLy9lbnN1cmVzIHRoYXQgZXZlbiBjb21wbGV4IHZhbHVlcyBsaWtlIFwidHJhbnNsYXRlKDUwLDYwKSByb3RhdGUoMTM1LDAsMClcIiBhcmUgcGFyc2VkIGJlY2F1c2UgaXQgbWFzaGVzIGl0IGludG8gYSBtYXRyaXguXG5cbiAgICBtYXRyaXggPSBbdGVtcC5hLCB0ZW1wLmIsIHRlbXAuYywgdGVtcC5kLCB0ZW1wLmUsIHRlbXAuZl07XG4gICAgcmV0dXJuIG1hdHJpeC5qb2luKFwiLFwiKSA9PT0gXCIxLDAsMCwxLDAsMFwiID8gX2lkZW50aXR5MkRNYXRyaXggOiBtYXRyaXg7XG4gIH0gZWxzZSBpZiAobWF0cml4ID09PSBfaWRlbnRpdHkyRE1hdHJpeCAmJiAhdGFyZ2V0Lm9mZnNldFBhcmVudCAmJiB0YXJnZXQgIT09IF9kb2NFbGVtZW50ICYmICFjYWNoZS5zdmcpIHtcbiAgICAvL25vdGU6IGlmIG9mZnNldFBhcmVudCBpcyBudWxsLCB0aGF0IG1lYW5zIHRoZSBlbGVtZW50IGlzbid0IGluIHRoZSBub3JtYWwgZG9jdW1lbnQgZmxvdywgbGlrZSBpZiBpdCBoYXMgZGlzcGxheTpub25lIG9yIG9uZSBvZiBpdHMgYW5jZXN0b3JzIGhhcyBkaXNwbGF5Om5vbmUpLiBGaXJlZm94IHJldHVybnMgbnVsbCBmb3IgZ2V0Q29tcHV0ZWRTdHlsZSgpIGlmIHRoZSBlbGVtZW50IGlzIGluIGFuIGlmcmFtZSB0aGF0IGhhcyBkaXNwbGF5Om5vbmUuIGh0dHBzOi8vYnVnemlsbGEubW96aWxsYS5vcmcvc2hvd19idWcuY2dpP2lkPTU0ODM5N1xuICAgIC8vYnJvd3NlcnMgZG9uJ3QgcmVwb3J0IHRyYW5zZm9ybXMgYWNjdXJhdGVseSB1bmxlc3MgdGhlIGVsZW1lbnQgaXMgaW4gdGhlIERPTSBhbmQgaGFzIGEgZGlzcGxheSB2YWx1ZSB0aGF0J3Mgbm90IFwibm9uZVwiLiBGaXJlZm94IGFuZCBNaWNyb3NvZnQgYnJvd3NlcnMgaGF2ZSBhIHBhcnRpYWwgYnVnIHdoZXJlIHRoZXknbGwgcmVwb3J0IHRyYW5zZm9ybXMgZXZlbiBpZiBkaXNwbGF5Om5vbmUgQlVUIG5vdCBhbnkgcGVyY2VudGFnZS1iYXNlZCB2YWx1ZXMgbGlrZSB0cmFuc2xhdGUoLTUwJSwgOHB4KSB3aWxsIGJlIHJlcG9ydGVkIGFzIGlmIGl0J3MgdHJhbnNsYXRlKDAsIDhweCkuXG4gICAgdGVtcCA9IHN0eWxlLmRpc3BsYXk7XG4gICAgc3R5bGUuZGlzcGxheSA9IFwiYmxvY2tcIjtcbiAgICBwYXJlbnQgPSB0YXJnZXQucGFyZW50Tm9kZTtcblxuICAgIGlmICghcGFyZW50IHx8ICF0YXJnZXQub2Zmc2V0UGFyZW50ICYmICF0YXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGgpIHtcbiAgICAgIC8vIG5vdGU6IGluIDMuMy4wIHdlIHN3aXRjaGVkIHRhcmdldC5vZmZzZXRQYXJlbnQgdG8gX2RvYy5ib2R5LmNvbnRhaW5zKHRhcmdldCkgdG8gYXZvaWQgW3NvbWV0aW1lcyB1bm5lY2Vzc2FyeV0gTXV0YXRpb25PYnNlcnZlciBjYWxscyBidXQgdGhhdCB3YXNuJ3QgYWRlcXVhdGUgYmVjYXVzZSB0aGVyZSBhcmUgZWRnZSBjYXNlcyB3aGVyZSBuZXN0ZWQgcG9zaXRpb246IGZpeGVkIGVsZW1lbnRzIG5lZWQgdG8gZ2V0IHJlcGFyZW50ZWQgdG8gYWNjdXJhdGVseSBzZW5zZSB0cmFuc2Zvcm1zLiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2dyZWVuc29jay9HU0FQL2lzc3Vlcy8zODggYW5kIGh0dHBzOi8vZ2l0aHViLmNvbS9ncmVlbnNvY2svR1NBUC9pc3N1ZXMvMzc1LiBOb3RlOiBwb3NpdGlvbjogZml4ZWQgZWxlbWVudHMgcmVwb3J0IGEgbnVsbCBvZmZzZXRQYXJlbnQgYnV0IHRoZXkgY291bGQgYWxzbyBiZSBpbnZpc2libGUgYmVjYXVzZSB0aGV5J3JlIGluIGFuIGFuY2VzdG9yIHdpdGggZGlzcGxheTogbm9uZSwgc28gd2UgY2hlY2sgZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuIFdlIG9ubHkgd2FudCB0byBhbHRlciB0aGUgRE9NIGlmIHdlIGFic29sdXRlbHkgaGF2ZSB0byBiZWNhdXNlIGl0IGNhbiBjYXVzZSBpZnJhbWUgY29udGVudCB0byByZWxvYWQsIGxpa2UgYSBWaW1lbyB2aWRlby5cbiAgICAgIGFkZGVkVG9ET00gPSAxOyAvL2ZsYWdcblxuICAgICAgbmV4dFNpYmxpbmcgPSB0YXJnZXQubmV4dEVsZW1lbnRTaWJsaW5nO1xuXG4gICAgICBfZG9jRWxlbWVudC5hcHBlbmRDaGlsZCh0YXJnZXQpOyAvL3dlIG11c3QgYWRkIGl0IHRvIHRoZSBET00gaW4gb3JkZXIgdG8gZ2V0IHZhbHVlcyBwcm9wZXJseVxuXG4gICAgfVxuXG4gICAgbWF0cml4ID0gX2dldENvbXB1dGVkVHJhbnNmb3JtTWF0cml4QXNBcnJheSh0YXJnZXQpO1xuICAgIHRlbXAgPyBzdHlsZS5kaXNwbGF5ID0gdGVtcCA6IF9yZW1vdmVQcm9wZXJ0eSh0YXJnZXQsIFwiZGlzcGxheVwiKTtcblxuICAgIGlmIChhZGRlZFRvRE9NKSB7XG4gICAgICBuZXh0U2libGluZyA/IHBhcmVudC5pbnNlcnRCZWZvcmUodGFyZ2V0LCBuZXh0U2libGluZykgOiBwYXJlbnQgPyBwYXJlbnQuYXBwZW5kQ2hpbGQodGFyZ2V0KSA6IF9kb2NFbGVtZW50LnJlbW92ZUNoaWxkKHRhcmdldCk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGZvcmNlMkQgJiYgbWF0cml4Lmxlbmd0aCA+IDYgPyBbbWF0cml4WzBdLCBtYXRyaXhbMV0sIG1hdHJpeFs0XSwgbWF0cml4WzVdLCBtYXRyaXhbMTJdLCBtYXRyaXhbMTNdXSA6IG1hdHJpeDtcbn0sXG4gICAgX2FwcGx5U1ZHT3JpZ2luID0gZnVuY3Rpb24gX2FwcGx5U1ZHT3JpZ2luKHRhcmdldCwgb3JpZ2luLCBvcmlnaW5Jc0Fic29sdXRlLCBzbW9vdGgsIG1hdHJpeEFycmF5LCBwbHVnaW5Ub0FkZFByb3BUd2VlbnNUbykge1xuICB2YXIgY2FjaGUgPSB0YXJnZXQuX2dzYXAsXG4gICAgICBtYXRyaXggPSBtYXRyaXhBcnJheSB8fCBfZ2V0TWF0cml4KHRhcmdldCwgdHJ1ZSksXG4gICAgICB4T3JpZ2luT2xkID0gY2FjaGUueE9yaWdpbiB8fCAwLFxuICAgICAgeU9yaWdpbk9sZCA9IGNhY2hlLnlPcmlnaW4gfHwgMCxcbiAgICAgIHhPZmZzZXRPbGQgPSBjYWNoZS54T2Zmc2V0IHx8IDAsXG4gICAgICB5T2Zmc2V0T2xkID0gY2FjaGUueU9mZnNldCB8fCAwLFxuICAgICAgYSA9IG1hdHJpeFswXSxcbiAgICAgIGIgPSBtYXRyaXhbMV0sXG4gICAgICBjID0gbWF0cml4WzJdLFxuICAgICAgZCA9IG1hdHJpeFszXSxcbiAgICAgIHR4ID0gbWF0cml4WzRdLFxuICAgICAgdHkgPSBtYXRyaXhbNV0sXG4gICAgICBvcmlnaW5TcGxpdCA9IG9yaWdpbi5zcGxpdChcIiBcIiksXG4gICAgICB4T3JpZ2luID0gcGFyc2VGbG9hdChvcmlnaW5TcGxpdFswXSkgfHwgMCxcbiAgICAgIHlPcmlnaW4gPSBwYXJzZUZsb2F0KG9yaWdpblNwbGl0WzFdKSB8fCAwLFxuICAgICAgYm91bmRzLFxuICAgICAgZGV0ZXJtaW5hbnQsXG4gICAgICB4LFxuICAgICAgeTtcblxuICBpZiAoIW9yaWdpbklzQWJzb2x1dGUpIHtcbiAgICBib3VuZHMgPSBfZ2V0QkJveCh0YXJnZXQpO1xuICAgIHhPcmlnaW4gPSBib3VuZHMueCArICh+b3JpZ2luU3BsaXRbMF0uaW5kZXhPZihcIiVcIikgPyB4T3JpZ2luIC8gMTAwICogYm91bmRzLndpZHRoIDogeE9yaWdpbik7XG4gICAgeU9yaWdpbiA9IGJvdW5kcy55ICsgKH4ob3JpZ2luU3BsaXRbMV0gfHwgb3JpZ2luU3BsaXRbMF0pLmluZGV4T2YoXCIlXCIpID8geU9yaWdpbiAvIDEwMCAqIGJvdW5kcy5oZWlnaHQgOiB5T3JpZ2luKTsgLy8gaWYgKCEoXCJ4T3JpZ2luXCIgaW4gY2FjaGUpICYmICh4T3JpZ2luIHx8IHlPcmlnaW4pKSB7IC8vIGFkZGVkIGluIDMuMTIuMywgcmV2ZXJ0ZWQgaW4gMy4xMi40OyByZXF1aXJlcyBtb3JlIGV4cGxvcmF0aW9uXG4gICAgLy8gXHR4T3JpZ2luIC09IGJvdW5kcy54O1xuICAgIC8vIFx0eU9yaWdpbiAtPSBib3VuZHMueTtcbiAgICAvLyB9XG4gIH0gZWxzZSBpZiAobWF0cml4ICE9PSBfaWRlbnRpdHkyRE1hdHJpeCAmJiAoZGV0ZXJtaW5hbnQgPSBhICogZCAtIGIgKiBjKSkge1xuICAgIC8vaWYgaXQncyB6ZXJvIChsaWtlIGlmIHNjYWxlWCBhbmQgc2NhbGVZIGFyZSB6ZXJvKSwgc2tpcCBpdCB0byBhdm9pZCBlcnJvcnMgd2l0aCBkaXZpZGluZyBieSB6ZXJvLlxuICAgIHggPSB4T3JpZ2luICogKGQgLyBkZXRlcm1pbmFudCkgKyB5T3JpZ2luICogKC1jIC8gZGV0ZXJtaW5hbnQpICsgKGMgKiB0eSAtIGQgKiB0eCkgLyBkZXRlcm1pbmFudDtcbiAgICB5ID0geE9yaWdpbiAqICgtYiAvIGRldGVybWluYW50KSArIHlPcmlnaW4gKiAoYSAvIGRldGVybWluYW50KSAtIChhICogdHkgLSBiICogdHgpIC8gZGV0ZXJtaW5hbnQ7XG4gICAgeE9yaWdpbiA9IHg7XG4gICAgeU9yaWdpbiA9IHk7IC8vIHRoZW9yeTogd2Ugb25seSBoYWQgdG8gZG8gdGhpcyBmb3Igc21vb3RoaW5nIGFuZCBpdCBhc3N1bWVzIHRoYXQgdGhlIHByZXZpb3VzIG9uZSB3YXMgbm90IG9yaWdpbklzQWJzb2x1dGUuXG4gIH1cblxuICBpZiAoc21vb3RoIHx8IHNtb290aCAhPT0gZmFsc2UgJiYgY2FjaGUuc21vb3RoKSB7XG4gICAgdHggPSB4T3JpZ2luIC0geE9yaWdpbk9sZDtcbiAgICB0eSA9IHlPcmlnaW4gLSB5T3JpZ2luT2xkO1xuICAgIGNhY2hlLnhPZmZzZXQgPSB4T2Zmc2V0T2xkICsgKHR4ICogYSArIHR5ICogYykgLSB0eDtcbiAgICBjYWNoZS55T2Zmc2V0ID0geU9mZnNldE9sZCArICh0eCAqIGIgKyB0eSAqIGQpIC0gdHk7XG4gIH0gZWxzZSB7XG4gICAgY2FjaGUueE9mZnNldCA9IGNhY2hlLnlPZmZzZXQgPSAwO1xuICB9XG5cbiAgY2FjaGUueE9yaWdpbiA9IHhPcmlnaW47XG4gIGNhY2hlLnlPcmlnaW4gPSB5T3JpZ2luO1xuICBjYWNoZS5zbW9vdGggPSAhIXNtb290aDtcbiAgY2FjaGUub3JpZ2luID0gb3JpZ2luO1xuICBjYWNoZS5vcmlnaW5Jc0Fic29sdXRlID0gISFvcmlnaW5Jc0Fic29sdXRlO1xuICB0YXJnZXQuc3R5bGVbX3RyYW5zZm9ybU9yaWdpblByb3BdID0gXCIwcHggMHB4XCI7IC8vb3RoZXJ3aXNlLCBpZiBzb21lb25lIHNldHMgIGFuIG9yaWdpbiB2aWEgQ1NTLCBpdCB3aWxsIGxpa2VseSBpbnRlcmZlcmUgd2l0aCB0aGUgU1ZHIHRyYW5zZm9ybSBhdHRyaWJ1dGUgb25lcyAoYmVjYXVzZSByZW1lbWJlciwgd2UncmUgYmFraW5nIHRoZSBvcmlnaW4gaW50byB0aGUgbWF0cml4KCkgdmFsdWUpLlxuXG4gIGlmIChwbHVnaW5Ub0FkZFByb3BUd2VlbnNUbykge1xuICAgIF9hZGROb25Ud2VlbmluZ1BUKHBsdWdpblRvQWRkUHJvcFR3ZWVuc1RvLCBjYWNoZSwgXCJ4T3JpZ2luXCIsIHhPcmlnaW5PbGQsIHhPcmlnaW4pO1xuXG4gICAgX2FkZE5vblR3ZWVuaW5nUFQocGx1Z2luVG9BZGRQcm9wVHdlZW5zVG8sIGNhY2hlLCBcInlPcmlnaW5cIiwgeU9yaWdpbk9sZCwgeU9yaWdpbik7XG5cbiAgICBfYWRkTm9uVHdlZW5pbmdQVChwbHVnaW5Ub0FkZFByb3BUd2VlbnNUbywgY2FjaGUsIFwieE9mZnNldFwiLCB4T2Zmc2V0T2xkLCBjYWNoZS54T2Zmc2V0KTtcblxuICAgIF9hZGROb25Ud2VlbmluZ1BUKHBsdWdpblRvQWRkUHJvcFR3ZWVuc1RvLCBjYWNoZSwgXCJ5T2Zmc2V0XCIsIHlPZmZzZXRPbGQsIGNhY2hlLnlPZmZzZXQpO1xuICB9XG5cbiAgdGFyZ2V0LnNldEF0dHJpYnV0ZShcImRhdGEtc3ZnLW9yaWdpblwiLCB4T3JpZ2luICsgXCIgXCIgKyB5T3JpZ2luKTtcbn0sXG4gICAgX3BhcnNlVHJhbnNmb3JtID0gZnVuY3Rpb24gX3BhcnNlVHJhbnNmb3JtKHRhcmdldCwgdW5jYWNoZSkge1xuICB2YXIgY2FjaGUgPSB0YXJnZXQuX2dzYXAgfHwgbmV3IEdTQ2FjaGUodGFyZ2V0KTtcblxuICBpZiAoXCJ4XCIgaW4gY2FjaGUgJiYgIXVuY2FjaGUgJiYgIWNhY2hlLnVuY2FjaGUpIHtcbiAgICByZXR1cm4gY2FjaGU7XG4gIH1cblxuICB2YXIgc3R5bGUgPSB0YXJnZXQuc3R5bGUsXG4gICAgICBpbnZlcnRlZFNjYWxlWCA9IGNhY2hlLnNjYWxlWCA8IDAsXG4gICAgICBweCA9IFwicHhcIixcbiAgICAgIGRlZyA9IFwiZGVnXCIsXG4gICAgICBjcyA9IGdldENvbXB1dGVkU3R5bGUodGFyZ2V0KSxcbiAgICAgIG9yaWdpbiA9IF9nZXRDb21wdXRlZFByb3BlcnR5KHRhcmdldCwgX3RyYW5zZm9ybU9yaWdpblByb3ApIHx8IFwiMFwiLFxuICAgICAgeCxcbiAgICAgIHksXG4gICAgICB6LFxuICAgICAgc2NhbGVYLFxuICAgICAgc2NhbGVZLFxuICAgICAgcm90YXRpb24sXG4gICAgICByb3RhdGlvblgsXG4gICAgICByb3RhdGlvblksXG4gICAgICBza2V3WCxcbiAgICAgIHNrZXdZLFxuICAgICAgcGVyc3BlY3RpdmUsXG4gICAgICB4T3JpZ2luLFxuICAgICAgeU9yaWdpbixcbiAgICAgIG1hdHJpeCxcbiAgICAgIGFuZ2xlLFxuICAgICAgY29zLFxuICAgICAgc2luLFxuICAgICAgYSxcbiAgICAgIGIsXG4gICAgICBjLFxuICAgICAgZCxcbiAgICAgIGExMixcbiAgICAgIGEyMixcbiAgICAgIHQxLFxuICAgICAgdDIsXG4gICAgICB0MyxcbiAgICAgIGExMyxcbiAgICAgIGEyMyxcbiAgICAgIGEzMyxcbiAgICAgIGE0MixcbiAgICAgIGE0MyxcbiAgICAgIGEzMjtcbiAgeCA9IHkgPSB6ID0gcm90YXRpb24gPSByb3RhdGlvblggPSByb3RhdGlvblkgPSBza2V3WCA9IHNrZXdZID0gcGVyc3BlY3RpdmUgPSAwO1xuICBzY2FsZVggPSBzY2FsZVkgPSAxO1xuICBjYWNoZS5zdmcgPSAhISh0YXJnZXQuZ2V0Q1RNICYmIF9pc1NWRyh0YXJnZXQpKTtcblxuICBpZiAoY3MudHJhbnNsYXRlKSB7XG4gICAgLy8gYWNjb21tb2RhdGUgaW5kZXBlbmRlbnQgdHJhbnNmb3JtcyBieSBjb21iaW5pbmcgdGhlbSBpbnRvIG5vcm1hbCBvbmVzLlxuICAgIGlmIChjcy50cmFuc2xhdGUgIT09IFwibm9uZVwiIHx8IGNzLnNjYWxlICE9PSBcIm5vbmVcIiB8fCBjcy5yb3RhdGUgIT09IFwibm9uZVwiKSB7XG4gICAgICBzdHlsZVtfdHJhbnNmb3JtUHJvcF0gPSAoY3MudHJhbnNsYXRlICE9PSBcIm5vbmVcIiA/IFwidHJhbnNsYXRlM2QoXCIgKyAoY3MudHJhbnNsYXRlICsgXCIgMCAwXCIpLnNwbGl0KFwiIFwiKS5zbGljZSgwLCAzKS5qb2luKFwiLCBcIikgKyBcIikgXCIgOiBcIlwiKSArIChjcy5yb3RhdGUgIT09IFwibm9uZVwiID8gXCJyb3RhdGUoXCIgKyBjcy5yb3RhdGUgKyBcIikgXCIgOiBcIlwiKSArIChjcy5zY2FsZSAhPT0gXCJub25lXCIgPyBcInNjYWxlKFwiICsgY3Muc2NhbGUuc3BsaXQoXCIgXCIpLmpvaW4oXCIsXCIpICsgXCIpIFwiIDogXCJcIikgKyAoY3NbX3RyYW5zZm9ybVByb3BdICE9PSBcIm5vbmVcIiA/IGNzW190cmFuc2Zvcm1Qcm9wXSA6IFwiXCIpO1xuICAgIH1cblxuICAgIHN0eWxlLnNjYWxlID0gc3R5bGUucm90YXRlID0gc3R5bGUudHJhbnNsYXRlID0gXCJub25lXCI7XG4gIH1cblxuICBtYXRyaXggPSBfZ2V0TWF0cml4KHRhcmdldCwgY2FjaGUuc3ZnKTtcblxuICBpZiAoY2FjaGUuc3ZnKSB7XG4gICAgaWYgKGNhY2hlLnVuY2FjaGUpIHtcbiAgICAgIC8vIGlmIGNhY2hlLnVuY2FjaGUgaXMgdHJ1ZSAoYW5kIG1heWJlIGlmIG9yaWdpbiBpcyAwLDApLCB3ZSBuZWVkIHRvIHNldCBlbGVtZW50LnN0eWxlLnRyYW5zZm9ybU9yaWdpbiA9IChjYWNoZS54T3JpZ2luIC0gYmJveC54KSArIFwicHggXCIgKyAoY2FjaGUueU9yaWdpbiAtIGJib3gueSkgKyBcInB4XCIuIFByZXZpb3VzbHkgd2UgbGV0IHRoZSBkYXRhLXN2Zy1vcmlnaW4gc3RheSBpbnN0ZWFkLCBidXQgd2hlbiBpbnRyb2R1Y2luZyByZXZlcnQoKSwgaXQgY29tcGxpY2F0ZWQgdGhpbmdzLlxuICAgICAgdDIgPSB0YXJnZXQuZ2V0QkJveCgpO1xuICAgICAgb3JpZ2luID0gY2FjaGUueE9yaWdpbiAtIHQyLnggKyBcInB4IFwiICsgKGNhY2hlLnlPcmlnaW4gLSB0Mi55KSArIFwicHhcIjtcbiAgICAgIHQxID0gXCJcIjtcbiAgICB9IGVsc2Uge1xuICAgICAgdDEgPSAhdW5jYWNoZSAmJiB0YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1zdmctb3JpZ2luXCIpOyAvLyAgUmVtZW1iZXIsIHRvIHdvcmsgYXJvdW5kIGJyb3dzZXIgaW5jb25zaXN0ZW5jaWVzIHdlIGFsd2F5cyBmb3JjZSBTVkcgZWxlbWVudHMnIHRyYW5zZm9ybU9yaWdpbiB0byAwLDAgYW5kIG9mZnNldCB0aGUgdHJhbnNsYXRpb24gYWNjb3JkaW5nbHkuXG4gICAgfVxuXG4gICAgX2FwcGx5U1ZHT3JpZ2luKHRhcmdldCwgdDEgfHwgb3JpZ2luLCAhIXQxIHx8IGNhY2hlLm9yaWdpbklzQWJzb2x1dGUsIGNhY2hlLnNtb290aCAhPT0gZmFsc2UsIG1hdHJpeCk7XG4gIH1cblxuICB4T3JpZ2luID0gY2FjaGUueE9yaWdpbiB8fCAwO1xuICB5T3JpZ2luID0gY2FjaGUueU9yaWdpbiB8fCAwO1xuXG4gIGlmIChtYXRyaXggIT09IF9pZGVudGl0eTJETWF0cml4KSB7XG4gICAgYSA9IG1hdHJpeFswXTsgLy9hMTFcblxuICAgIGIgPSBtYXRyaXhbMV07IC8vYTIxXG5cbiAgICBjID0gbWF0cml4WzJdOyAvL2EzMVxuXG4gICAgZCA9IG1hdHJpeFszXTsgLy9hNDFcblxuICAgIHggPSBhMTIgPSBtYXRyaXhbNF07XG4gICAgeSA9IGEyMiA9IG1hdHJpeFs1XTsgLy8yRCBtYXRyaXhcblxuICAgIGlmIChtYXRyaXgubGVuZ3RoID09PSA2KSB7XG4gICAgICBzY2FsZVggPSBNYXRoLnNxcnQoYSAqIGEgKyBiICogYik7XG4gICAgICBzY2FsZVkgPSBNYXRoLnNxcnQoZCAqIGQgKyBjICogYyk7XG4gICAgICByb3RhdGlvbiA9IGEgfHwgYiA/IF9hdGFuMihiLCBhKSAqIF9SQUQyREVHIDogMDsgLy9ub3RlOiBpZiBzY2FsZVggaXMgMCwgd2UgY2Fubm90IGFjY3VyYXRlbHkgbWVhc3VyZSByb3RhdGlvbi4gU2FtZSBmb3Igc2tld1ggd2l0aCBhIHNjYWxlWSBvZiAwLiBUaGVyZWZvcmUsIHdlIGRlZmF1bHQgdG8gdGhlIHByZXZpb3VzbHkgcmVjb3JkZWQgdmFsdWUgKG9yIHplcm8gaWYgdGhhdCBkb2Vzbid0IGV4aXN0KS5cblxuICAgICAgc2tld1ggPSBjIHx8IGQgPyBfYXRhbjIoYywgZCkgKiBfUkFEMkRFRyArIHJvdGF0aW9uIDogMDtcbiAgICAgIHNrZXdYICYmIChzY2FsZVkgKj0gTWF0aC5hYnMoTWF0aC5jb3Moc2tld1ggKiBfREVHMlJBRCkpKTtcblxuICAgICAgaWYgKGNhY2hlLnN2Zykge1xuICAgICAgICB4IC09IHhPcmlnaW4gLSAoeE9yaWdpbiAqIGEgKyB5T3JpZ2luICogYyk7XG4gICAgICAgIHkgLT0geU9yaWdpbiAtICh4T3JpZ2luICogYiArIHlPcmlnaW4gKiBkKTtcbiAgICAgIH0gLy8zRCBtYXRyaXhcblxuICAgIH0gZWxzZSB7XG4gICAgICBhMzIgPSBtYXRyaXhbNl07XG4gICAgICBhNDIgPSBtYXRyaXhbN107XG4gICAgICBhMTMgPSBtYXRyaXhbOF07XG4gICAgICBhMjMgPSBtYXRyaXhbOV07XG4gICAgICBhMzMgPSBtYXRyaXhbMTBdO1xuICAgICAgYTQzID0gbWF0cml4WzExXTtcbiAgICAgIHggPSBtYXRyaXhbMTJdO1xuICAgICAgeSA9IG1hdHJpeFsxM107XG4gICAgICB6ID0gbWF0cml4WzE0XTtcbiAgICAgIGFuZ2xlID0gX2F0YW4yKGEzMiwgYTMzKTtcbiAgICAgIHJvdGF0aW9uWCA9IGFuZ2xlICogX1JBRDJERUc7IC8vcm90YXRpb25YXG5cbiAgICAgIGlmIChhbmdsZSkge1xuICAgICAgICBjb3MgPSBNYXRoLmNvcygtYW5nbGUpO1xuICAgICAgICBzaW4gPSBNYXRoLnNpbigtYW5nbGUpO1xuICAgICAgICB0MSA9IGExMiAqIGNvcyArIGExMyAqIHNpbjtcbiAgICAgICAgdDIgPSBhMjIgKiBjb3MgKyBhMjMgKiBzaW47XG4gICAgICAgIHQzID0gYTMyICogY29zICsgYTMzICogc2luO1xuICAgICAgICBhMTMgPSBhMTIgKiAtc2luICsgYTEzICogY29zO1xuICAgICAgICBhMjMgPSBhMjIgKiAtc2luICsgYTIzICogY29zO1xuICAgICAgICBhMzMgPSBhMzIgKiAtc2luICsgYTMzICogY29zO1xuICAgICAgICBhNDMgPSBhNDIgKiAtc2luICsgYTQzICogY29zO1xuICAgICAgICBhMTIgPSB0MTtcbiAgICAgICAgYTIyID0gdDI7XG4gICAgICAgIGEzMiA9IHQzO1xuICAgICAgfSAvL3JvdGF0aW9uWVxuXG5cbiAgICAgIGFuZ2xlID0gX2F0YW4yKC1jLCBhMzMpO1xuICAgICAgcm90YXRpb25ZID0gYW5nbGUgKiBfUkFEMkRFRztcblxuICAgICAgaWYgKGFuZ2xlKSB7XG4gICAgICAgIGNvcyA9IE1hdGguY29zKC1hbmdsZSk7XG4gICAgICAgIHNpbiA9IE1hdGguc2luKC1hbmdsZSk7XG4gICAgICAgIHQxID0gYSAqIGNvcyAtIGExMyAqIHNpbjtcbiAgICAgICAgdDIgPSBiICogY29zIC0gYTIzICogc2luO1xuICAgICAgICB0MyA9IGMgKiBjb3MgLSBhMzMgKiBzaW47XG4gICAgICAgIGE0MyA9IGQgKiBzaW4gKyBhNDMgKiBjb3M7XG4gICAgICAgIGEgPSB0MTtcbiAgICAgICAgYiA9IHQyO1xuICAgICAgICBjID0gdDM7XG4gICAgICB9IC8vcm90YXRpb25aXG5cblxuICAgICAgYW5nbGUgPSBfYXRhbjIoYiwgYSk7XG4gICAgICByb3RhdGlvbiA9IGFuZ2xlICogX1JBRDJERUc7XG5cbiAgICAgIGlmIChhbmdsZSkge1xuICAgICAgICBjb3MgPSBNYXRoLmNvcyhhbmdsZSk7XG4gICAgICAgIHNpbiA9IE1hdGguc2luKGFuZ2xlKTtcbiAgICAgICAgdDEgPSBhICogY29zICsgYiAqIHNpbjtcbiAgICAgICAgdDIgPSBhMTIgKiBjb3MgKyBhMjIgKiBzaW47XG4gICAgICAgIGIgPSBiICogY29zIC0gYSAqIHNpbjtcbiAgICAgICAgYTIyID0gYTIyICogY29zIC0gYTEyICogc2luO1xuICAgICAgICBhID0gdDE7XG4gICAgICAgIGExMiA9IHQyO1xuICAgICAgfVxuXG4gICAgICBpZiAocm90YXRpb25YICYmIE1hdGguYWJzKHJvdGF0aW9uWCkgKyBNYXRoLmFicyhyb3RhdGlvbikgPiAzNTkuOSkge1xuICAgICAgICAvL3doZW4gcm90YXRpb25ZIGlzIHNldCwgaXQgd2lsbCBvZnRlbiBiZSBwYXJzZWQgYXMgMTgwIGRlZ3JlZXMgZGlmZmVyZW50IHRoYW4gaXQgc2hvdWxkIGJlLCBhbmQgcm90YXRpb25YIGFuZCByb3RhdGlvbiBib3RoIGJlaW5nIDE4MCAoaXQgbG9va3MgdGhlIHNhbWUpLCBzbyB3ZSBhZGp1c3QgZm9yIHRoYXQgaGVyZS5cbiAgICAgICAgcm90YXRpb25YID0gcm90YXRpb24gPSAwO1xuICAgICAgICByb3RhdGlvblkgPSAxODAgLSByb3RhdGlvblk7XG4gICAgICB9XG5cbiAgICAgIHNjYWxlWCA9IF9yb3VuZChNYXRoLnNxcnQoYSAqIGEgKyBiICogYiArIGMgKiBjKSk7XG4gICAgICBzY2FsZVkgPSBfcm91bmQoTWF0aC5zcXJ0KGEyMiAqIGEyMiArIGEzMiAqIGEzMikpO1xuICAgICAgYW5nbGUgPSBfYXRhbjIoYTEyLCBhMjIpO1xuICAgICAgc2tld1ggPSBNYXRoLmFicyhhbmdsZSkgPiAwLjAwMDIgPyBhbmdsZSAqIF9SQUQyREVHIDogMDtcbiAgICAgIHBlcnNwZWN0aXZlID0gYTQzID8gMSAvIChhNDMgPCAwID8gLWE0MyA6IGE0MykgOiAwO1xuICAgIH1cblxuICAgIGlmIChjYWNoZS5zdmcpIHtcbiAgICAgIC8vc2Vuc2UgaWYgdGhlcmUgYXJlIENTUyB0cmFuc2Zvcm1zIGFwcGxpZWQgb24gYW4gU1ZHIGVsZW1lbnQgaW4gd2hpY2ggY2FzZSB3ZSBtdXN0IG92ZXJ3cml0ZSB0aGVtIHdoZW4gcmVuZGVyaW5nLiBUaGUgdHJhbnNmb3JtIGF0dHJpYnV0ZSBpcyBtb3JlIHJlbGlhYmxlIGNyb3NzLWJyb3dzZXIsIGJ1dCB3ZSBjYW4ndCBqdXN0IHJlbW92ZSB0aGUgQ1NTIG9uZXMgYmVjYXVzZSB0aGV5IG1heSBiZSBhcHBsaWVkIGluIGEgQ1NTIHJ1bGUgc29tZXdoZXJlIChub3QganVzdCBpbmxpbmUpLlxuICAgICAgdDEgPSB0YXJnZXQuZ2V0QXR0cmlidXRlKFwidHJhbnNmb3JtXCIpO1xuICAgICAgY2FjaGUuZm9yY2VDU1MgPSB0YXJnZXQuc2V0QXR0cmlidXRlKFwidHJhbnNmb3JtXCIsIFwiXCIpIHx8ICFfaXNOdWxsVHJhbnNmb3JtKF9nZXRDb21wdXRlZFByb3BlcnR5KHRhcmdldCwgX3RyYW5zZm9ybVByb3ApKTtcbiAgICAgIHQxICYmIHRhcmdldC5zZXRBdHRyaWJ1dGUoXCJ0cmFuc2Zvcm1cIiwgdDEpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChNYXRoLmFicyhza2V3WCkgPiA5MCAmJiBNYXRoLmFicyhza2V3WCkgPCAyNzApIHtcbiAgICBpZiAoaW52ZXJ0ZWRTY2FsZVgpIHtcbiAgICAgIHNjYWxlWCAqPSAtMTtcbiAgICAgIHNrZXdYICs9IHJvdGF0aW9uIDw9IDAgPyAxODAgOiAtMTgwO1xuICAgICAgcm90YXRpb24gKz0gcm90YXRpb24gPD0gMCA/IDE4MCA6IC0xODA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNjYWxlWSAqPSAtMTtcbiAgICAgIHNrZXdYICs9IHNrZXdYIDw9IDAgPyAxODAgOiAtMTgwO1xuICAgIH1cbiAgfVxuXG4gIHVuY2FjaGUgPSB1bmNhY2hlIHx8IGNhY2hlLnVuY2FjaGU7XG4gIGNhY2hlLnggPSB4IC0gKChjYWNoZS54UGVyY2VudCA9IHggJiYgKCF1bmNhY2hlICYmIGNhY2hlLnhQZXJjZW50IHx8IChNYXRoLnJvdW5kKHRhcmdldC5vZmZzZXRXaWR0aCAvIDIpID09PSBNYXRoLnJvdW5kKC14KSA/IC01MCA6IDApKSkgPyB0YXJnZXQub2Zmc2V0V2lkdGggKiBjYWNoZS54UGVyY2VudCAvIDEwMCA6IDApICsgcHg7XG4gIGNhY2hlLnkgPSB5IC0gKChjYWNoZS55UGVyY2VudCA9IHkgJiYgKCF1bmNhY2hlICYmIGNhY2hlLnlQZXJjZW50IHx8IChNYXRoLnJvdW5kKHRhcmdldC5vZmZzZXRIZWlnaHQgLyAyKSA9PT0gTWF0aC5yb3VuZCgteSkgPyAtNTAgOiAwKSkpID8gdGFyZ2V0Lm9mZnNldEhlaWdodCAqIGNhY2hlLnlQZXJjZW50IC8gMTAwIDogMCkgKyBweDtcbiAgY2FjaGUueiA9IHogKyBweDtcbiAgY2FjaGUuc2NhbGVYID0gX3JvdW5kKHNjYWxlWCk7XG4gIGNhY2hlLnNjYWxlWSA9IF9yb3VuZChzY2FsZVkpO1xuICBjYWNoZS5yb3RhdGlvbiA9IF9yb3VuZChyb3RhdGlvbikgKyBkZWc7XG4gIGNhY2hlLnJvdGF0aW9uWCA9IF9yb3VuZChyb3RhdGlvblgpICsgZGVnO1xuICBjYWNoZS5yb3RhdGlvblkgPSBfcm91bmQocm90YXRpb25ZKSArIGRlZztcbiAgY2FjaGUuc2tld1ggPSBza2V3WCArIGRlZztcbiAgY2FjaGUuc2tld1kgPSBza2V3WSArIGRlZztcbiAgY2FjaGUudHJhbnNmb3JtUGVyc3BlY3RpdmUgPSBwZXJzcGVjdGl2ZSArIHB4O1xuXG4gIGlmIChjYWNoZS56T3JpZ2luID0gcGFyc2VGbG9hdChvcmlnaW4uc3BsaXQoXCIgXCIpWzJdKSB8fCAhdW5jYWNoZSAmJiBjYWNoZS56T3JpZ2luIHx8IDApIHtcbiAgICBzdHlsZVtfdHJhbnNmb3JtT3JpZ2luUHJvcF0gPSBfZmlyc3RUd29Pbmx5KG9yaWdpbik7XG4gIH1cblxuICBjYWNoZS54T2Zmc2V0ID0gY2FjaGUueU9mZnNldCA9IDA7XG4gIGNhY2hlLmZvcmNlM0QgPSBfY29uZmlnLmZvcmNlM0Q7XG4gIGNhY2hlLnJlbmRlclRyYW5zZm9ybSA9IGNhY2hlLnN2ZyA/IF9yZW5kZXJTVkdUcmFuc2Zvcm1zIDogX3N1cHBvcnRzM0QgPyBfcmVuZGVyQ1NTVHJhbnNmb3JtcyA6IF9yZW5kZXJOb24zRFRyYW5zZm9ybXM7XG4gIGNhY2hlLnVuY2FjaGUgPSAwO1xuICByZXR1cm4gY2FjaGU7XG59LFxuICAgIF9maXJzdFR3b09ubHkgPSBmdW5jdGlvbiBfZmlyc3RUd29Pbmx5KHZhbHVlKSB7XG4gIHJldHVybiAodmFsdWUgPSB2YWx1ZS5zcGxpdChcIiBcIikpWzBdICsgXCIgXCIgKyB2YWx1ZVsxXTtcbn0sXG4gICAgLy9mb3IgaGFuZGxpbmcgdHJhbnNmb3JtT3JpZ2luIHZhbHVlcywgc3RyaXBwaW5nIG91dCB0aGUgM3JkIGRpbWVuc2lvblxuX2FkZFB4VHJhbnNsYXRlID0gZnVuY3Rpb24gX2FkZFB4VHJhbnNsYXRlKHRhcmdldCwgc3RhcnQsIHZhbHVlKSB7XG4gIHZhciB1bml0ID0gZ2V0VW5pdChzdGFydCk7XG4gIHJldHVybiBfcm91bmQocGFyc2VGbG9hdChzdGFydCkgKyBwYXJzZUZsb2F0KF9jb252ZXJ0VG9Vbml0KHRhcmdldCwgXCJ4XCIsIHZhbHVlICsgXCJweFwiLCB1bml0KSkpICsgdW5pdDtcbn0sXG4gICAgX3JlbmRlck5vbjNEVHJhbnNmb3JtcyA9IGZ1bmN0aW9uIF9yZW5kZXJOb24zRFRyYW5zZm9ybXMocmF0aW8sIGNhY2hlKSB7XG4gIGNhY2hlLnogPSBcIjBweFwiO1xuICBjYWNoZS5yb3RhdGlvblkgPSBjYWNoZS5yb3RhdGlvblggPSBcIjBkZWdcIjtcbiAgY2FjaGUuZm9yY2UzRCA9IDA7XG5cbiAgX3JlbmRlckNTU1RyYW5zZm9ybXMocmF0aW8sIGNhY2hlKTtcbn0sXG4gICAgX3plcm9EZWcgPSBcIjBkZWdcIixcbiAgICBfemVyb1B4ID0gXCIwcHhcIixcbiAgICBfZW5kUGFyZW50aGVzaXMgPSBcIikgXCIsXG4gICAgX3JlbmRlckNTU1RyYW5zZm9ybXMgPSBmdW5jdGlvbiBfcmVuZGVyQ1NTVHJhbnNmb3JtcyhyYXRpbywgY2FjaGUpIHtcbiAgdmFyIF9yZWYgPSBjYWNoZSB8fCB0aGlzLFxuICAgICAgeFBlcmNlbnQgPSBfcmVmLnhQZXJjZW50LFxuICAgICAgeVBlcmNlbnQgPSBfcmVmLnlQZXJjZW50LFxuICAgICAgeCA9IF9yZWYueCxcbiAgICAgIHkgPSBfcmVmLnksXG4gICAgICB6ID0gX3JlZi56LFxuICAgICAgcm90YXRpb24gPSBfcmVmLnJvdGF0aW9uLFxuICAgICAgcm90YXRpb25ZID0gX3JlZi5yb3RhdGlvblksXG4gICAgICByb3RhdGlvblggPSBfcmVmLnJvdGF0aW9uWCxcbiAgICAgIHNrZXdYID0gX3JlZi5za2V3WCxcbiAgICAgIHNrZXdZID0gX3JlZi5za2V3WSxcbiAgICAgIHNjYWxlWCA9IF9yZWYuc2NhbGVYLFxuICAgICAgc2NhbGVZID0gX3JlZi5zY2FsZVksXG4gICAgICB0cmFuc2Zvcm1QZXJzcGVjdGl2ZSA9IF9yZWYudHJhbnNmb3JtUGVyc3BlY3RpdmUsXG4gICAgICBmb3JjZTNEID0gX3JlZi5mb3JjZTNELFxuICAgICAgdGFyZ2V0ID0gX3JlZi50YXJnZXQsXG4gICAgICB6T3JpZ2luID0gX3JlZi56T3JpZ2luLFxuICAgICAgdHJhbnNmb3JtcyA9IFwiXCIsXG4gICAgICB1c2UzRCA9IGZvcmNlM0QgPT09IFwiYXV0b1wiICYmIHJhdGlvICYmIHJhdGlvICE9PSAxIHx8IGZvcmNlM0QgPT09IHRydWU7IC8vIFNhZmFyaSBoYXMgYSBidWcgdGhhdCBjYXVzZXMgaXQgbm90IHRvIHJlbmRlciAzRCB0cmFuc2Zvcm0tb3JpZ2luIHZhbHVlcyBwcm9wZXJseSwgc28gd2UgZm9yY2UgdGhlIHogb3JpZ2luIHRvIDAsIHJlY29yZCBpdCBpbiB0aGUgY2FjaGUsIGFuZCB0aGVuIGRvIHRoZSBtYXRoIGhlcmUgdG8gb2Zmc2V0IHRoZSB0cmFuc2xhdGUgdmFsdWVzIGFjY29yZGluZ2x5IChiYXNpY2FsbHkgZG8gdGhlIDNEIHRyYW5zZm9ybS1vcmlnaW4gcGFydCBtYW51YWxseSlcblxuXG4gIGlmICh6T3JpZ2luICYmIChyb3RhdGlvblggIT09IF96ZXJvRGVnIHx8IHJvdGF0aW9uWSAhPT0gX3plcm9EZWcpKSB7XG4gICAgdmFyIGFuZ2xlID0gcGFyc2VGbG9hdChyb3RhdGlvblkpICogX0RFRzJSQUQsXG4gICAgICAgIGExMyA9IE1hdGguc2luKGFuZ2xlKSxcbiAgICAgICAgYTMzID0gTWF0aC5jb3MoYW5nbGUpLFxuICAgICAgICBjb3M7XG5cbiAgICBhbmdsZSA9IHBhcnNlRmxvYXQocm90YXRpb25YKSAqIF9ERUcyUkFEO1xuICAgIGNvcyA9IE1hdGguY29zKGFuZ2xlKTtcbiAgICB4ID0gX2FkZFB4VHJhbnNsYXRlKHRhcmdldCwgeCwgYTEzICogY29zICogLXpPcmlnaW4pO1xuICAgIHkgPSBfYWRkUHhUcmFuc2xhdGUodGFyZ2V0LCB5LCAtTWF0aC5zaW4oYW5nbGUpICogLXpPcmlnaW4pO1xuICAgIHogPSBfYWRkUHhUcmFuc2xhdGUodGFyZ2V0LCB6LCBhMzMgKiBjb3MgKiAtek9yaWdpbiArIHpPcmlnaW4pO1xuICB9XG5cbiAgaWYgKHRyYW5zZm9ybVBlcnNwZWN0aXZlICE9PSBfemVyb1B4KSB7XG4gICAgdHJhbnNmb3JtcyArPSBcInBlcnNwZWN0aXZlKFwiICsgdHJhbnNmb3JtUGVyc3BlY3RpdmUgKyBfZW5kUGFyZW50aGVzaXM7XG4gIH1cblxuICBpZiAoeFBlcmNlbnQgfHwgeVBlcmNlbnQpIHtcbiAgICB0cmFuc2Zvcm1zICs9IFwidHJhbnNsYXRlKFwiICsgeFBlcmNlbnQgKyBcIiUsIFwiICsgeVBlcmNlbnQgKyBcIiUpIFwiO1xuICB9XG5cbiAgaWYgKHVzZTNEIHx8IHggIT09IF96ZXJvUHggfHwgeSAhPT0gX3plcm9QeCB8fCB6ICE9PSBfemVyb1B4KSB7XG4gICAgdHJhbnNmb3JtcyArPSB6ICE9PSBfemVyb1B4IHx8IHVzZTNEID8gXCJ0cmFuc2xhdGUzZChcIiArIHggKyBcIiwgXCIgKyB5ICsgXCIsIFwiICsgeiArIFwiKSBcIiA6IFwidHJhbnNsYXRlKFwiICsgeCArIFwiLCBcIiArIHkgKyBfZW5kUGFyZW50aGVzaXM7XG4gIH1cblxuICBpZiAocm90YXRpb24gIT09IF96ZXJvRGVnKSB7XG4gICAgdHJhbnNmb3JtcyArPSBcInJvdGF0ZShcIiArIHJvdGF0aW9uICsgX2VuZFBhcmVudGhlc2lzO1xuICB9XG5cbiAgaWYgKHJvdGF0aW9uWSAhPT0gX3plcm9EZWcpIHtcbiAgICB0cmFuc2Zvcm1zICs9IFwicm90YXRlWShcIiArIHJvdGF0aW9uWSArIF9lbmRQYXJlbnRoZXNpcztcbiAgfVxuXG4gIGlmIChyb3RhdGlvblggIT09IF96ZXJvRGVnKSB7XG4gICAgdHJhbnNmb3JtcyArPSBcInJvdGF0ZVgoXCIgKyByb3RhdGlvblggKyBfZW5kUGFyZW50aGVzaXM7XG4gIH1cblxuICBpZiAoc2tld1ggIT09IF96ZXJvRGVnIHx8IHNrZXdZICE9PSBfemVyb0RlZykge1xuICAgIHRyYW5zZm9ybXMgKz0gXCJza2V3KFwiICsgc2tld1ggKyBcIiwgXCIgKyBza2V3WSArIF9lbmRQYXJlbnRoZXNpcztcbiAgfVxuXG4gIGlmIChzY2FsZVggIT09IDEgfHwgc2NhbGVZICE9PSAxKSB7XG4gICAgdHJhbnNmb3JtcyArPSBcInNjYWxlKFwiICsgc2NhbGVYICsgXCIsIFwiICsgc2NhbGVZICsgX2VuZFBhcmVudGhlc2lzO1xuICB9XG5cbiAgdGFyZ2V0LnN0eWxlW190cmFuc2Zvcm1Qcm9wXSA9IHRyYW5zZm9ybXMgfHwgXCJ0cmFuc2xhdGUoMCwgMClcIjtcbn0sXG4gICAgX3JlbmRlclNWR1RyYW5zZm9ybXMgPSBmdW5jdGlvbiBfcmVuZGVyU1ZHVHJhbnNmb3JtcyhyYXRpbywgY2FjaGUpIHtcbiAgdmFyIF9yZWYyID0gY2FjaGUgfHwgdGhpcyxcbiAgICAgIHhQZXJjZW50ID0gX3JlZjIueFBlcmNlbnQsXG4gICAgICB5UGVyY2VudCA9IF9yZWYyLnlQZXJjZW50LFxuICAgICAgeCA9IF9yZWYyLngsXG4gICAgICB5ID0gX3JlZjIueSxcbiAgICAgIHJvdGF0aW9uID0gX3JlZjIucm90YXRpb24sXG4gICAgICBza2V3WCA9IF9yZWYyLnNrZXdYLFxuICAgICAgc2tld1kgPSBfcmVmMi5za2V3WSxcbiAgICAgIHNjYWxlWCA9IF9yZWYyLnNjYWxlWCxcbiAgICAgIHNjYWxlWSA9IF9yZWYyLnNjYWxlWSxcbiAgICAgIHRhcmdldCA9IF9yZWYyLnRhcmdldCxcbiAgICAgIHhPcmlnaW4gPSBfcmVmMi54T3JpZ2luLFxuICAgICAgeU9yaWdpbiA9IF9yZWYyLnlPcmlnaW4sXG4gICAgICB4T2Zmc2V0ID0gX3JlZjIueE9mZnNldCxcbiAgICAgIHlPZmZzZXQgPSBfcmVmMi55T2Zmc2V0LFxuICAgICAgZm9yY2VDU1MgPSBfcmVmMi5mb3JjZUNTUyxcbiAgICAgIHR4ID0gcGFyc2VGbG9hdCh4KSxcbiAgICAgIHR5ID0gcGFyc2VGbG9hdCh5KSxcbiAgICAgIGExMSxcbiAgICAgIGEyMSxcbiAgICAgIGExMixcbiAgICAgIGEyMixcbiAgICAgIHRlbXA7XG5cbiAgcm90YXRpb24gPSBwYXJzZUZsb2F0KHJvdGF0aW9uKTtcbiAgc2tld1ggPSBwYXJzZUZsb2F0KHNrZXdYKTtcbiAgc2tld1kgPSBwYXJzZUZsb2F0KHNrZXdZKTtcblxuICBpZiAoc2tld1kpIHtcbiAgICAvL2ZvciBwZXJmb3JtYW5jZSByZWFzb25zLCB3ZSBjb21iaW5lIGFsbCBza2V3aW5nIGludG8gdGhlIHNrZXdYIGFuZCByb3RhdGlvbiB2YWx1ZXMuIFJlbWVtYmVyLCBhIHNrZXdZIG9mIDEwIGRlZ3JlZXMgbG9va3MgdGhlIHNhbWUgYXMgYSByb3RhdGlvbiBvZiAxMCBkZWdyZWVzIHBsdXMgYSBza2V3WCBvZiAxMCBkZWdyZWVzLlxuICAgIHNrZXdZID0gcGFyc2VGbG9hdChza2V3WSk7XG4gICAgc2tld1ggKz0gc2tld1k7XG4gICAgcm90YXRpb24gKz0gc2tld1k7XG4gIH1cblxuICBpZiAocm90YXRpb24gfHwgc2tld1gpIHtcbiAgICByb3RhdGlvbiAqPSBfREVHMlJBRDtcbiAgICBza2V3WCAqPSBfREVHMlJBRDtcbiAgICBhMTEgPSBNYXRoLmNvcyhyb3RhdGlvbikgKiBzY2FsZVg7XG4gICAgYTIxID0gTWF0aC5zaW4ocm90YXRpb24pICogc2NhbGVYO1xuICAgIGExMiA9IE1hdGguc2luKHJvdGF0aW9uIC0gc2tld1gpICogLXNjYWxlWTtcbiAgICBhMjIgPSBNYXRoLmNvcyhyb3RhdGlvbiAtIHNrZXdYKSAqIHNjYWxlWTtcblxuICAgIGlmIChza2V3WCkge1xuICAgICAgc2tld1kgKj0gX0RFRzJSQUQ7XG4gICAgICB0ZW1wID0gTWF0aC50YW4oc2tld1ggLSBza2V3WSk7XG4gICAgICB0ZW1wID0gTWF0aC5zcXJ0KDEgKyB0ZW1wICogdGVtcCk7XG4gICAgICBhMTIgKj0gdGVtcDtcbiAgICAgIGEyMiAqPSB0ZW1wO1xuXG4gICAgICBpZiAoc2tld1kpIHtcbiAgICAgICAgdGVtcCA9IE1hdGgudGFuKHNrZXdZKTtcbiAgICAgICAgdGVtcCA9IE1hdGguc3FydCgxICsgdGVtcCAqIHRlbXApO1xuICAgICAgICBhMTEgKj0gdGVtcDtcbiAgICAgICAgYTIxICo9IHRlbXA7XG4gICAgICB9XG4gICAgfVxuXG4gICAgYTExID0gX3JvdW5kKGExMSk7XG4gICAgYTIxID0gX3JvdW5kKGEyMSk7XG4gICAgYTEyID0gX3JvdW5kKGExMik7XG4gICAgYTIyID0gX3JvdW5kKGEyMik7XG4gIH0gZWxzZSB7XG4gICAgYTExID0gc2NhbGVYO1xuICAgIGEyMiA9IHNjYWxlWTtcbiAgICBhMjEgPSBhMTIgPSAwO1xuICB9XG5cbiAgaWYgKHR4ICYmICF+KHggKyBcIlwiKS5pbmRleE9mKFwicHhcIikgfHwgdHkgJiYgIX4oeSArIFwiXCIpLmluZGV4T2YoXCJweFwiKSkge1xuICAgIHR4ID0gX2NvbnZlcnRUb1VuaXQodGFyZ2V0LCBcInhcIiwgeCwgXCJweFwiKTtcbiAgICB0eSA9IF9jb252ZXJ0VG9Vbml0KHRhcmdldCwgXCJ5XCIsIHksIFwicHhcIik7XG4gIH1cblxuICBpZiAoeE9yaWdpbiB8fCB5T3JpZ2luIHx8IHhPZmZzZXQgfHwgeU9mZnNldCkge1xuICAgIHR4ID0gX3JvdW5kKHR4ICsgeE9yaWdpbiAtICh4T3JpZ2luICogYTExICsgeU9yaWdpbiAqIGExMikgKyB4T2Zmc2V0KTtcbiAgICB0eSA9IF9yb3VuZCh0eSArIHlPcmlnaW4gLSAoeE9yaWdpbiAqIGEyMSArIHlPcmlnaW4gKiBhMjIpICsgeU9mZnNldCk7XG4gIH1cblxuICBpZiAoeFBlcmNlbnQgfHwgeVBlcmNlbnQpIHtcbiAgICAvL1RoZSBTVkcgc3BlYyBkb2Vzbid0IHN1cHBvcnQgcGVyY2VudGFnZS1iYXNlZCB0cmFuc2xhdGlvbiBpbiB0aGUgXCJ0cmFuc2Zvcm1cIiBhdHRyaWJ1dGUsIHNvIHdlIG1lcmdlIGl0IGludG8gdGhlIHRyYW5zbGF0aW9uIHRvIHNpbXVsYXRlIGl0LlxuICAgIHRlbXAgPSB0YXJnZXQuZ2V0QkJveCgpO1xuICAgIHR4ID0gX3JvdW5kKHR4ICsgeFBlcmNlbnQgLyAxMDAgKiB0ZW1wLndpZHRoKTtcbiAgICB0eSA9IF9yb3VuZCh0eSArIHlQZXJjZW50IC8gMTAwICogdGVtcC5oZWlnaHQpO1xuICB9XG5cbiAgdGVtcCA9IFwibWF0cml4KFwiICsgYTExICsgXCIsXCIgKyBhMjEgKyBcIixcIiArIGExMiArIFwiLFwiICsgYTIyICsgXCIsXCIgKyB0eCArIFwiLFwiICsgdHkgKyBcIilcIjtcbiAgdGFyZ2V0LnNldEF0dHJpYnV0ZShcInRyYW5zZm9ybVwiLCB0ZW1wKTtcbiAgZm9yY2VDU1MgJiYgKHRhcmdldC5zdHlsZVtfdHJhbnNmb3JtUHJvcF0gPSB0ZW1wKTsgLy9zb21lIGJyb3dzZXJzIHByaW9yaXRpemUgQ1NTIHRyYW5zZm9ybXMgb3ZlciB0aGUgdHJhbnNmb3JtIGF0dHJpYnV0ZS4gV2hlbiB3ZSBzZW5zZSB0aGF0IHRoZSB1c2VyIGhhcyBDU1MgdHJhbnNmb3JtcyBhcHBsaWVkLCB3ZSBtdXN0IG92ZXJ3cml0ZSB0aGVtIHRoaXMgd2F5IChvdGhlcndpc2Ugc29tZSBicm93c2VyIHNpbXBseSB3b24ndCByZW5kZXIgdGhlIHRyYW5zZm9ybSBhdHRyaWJ1dGUgY2hhbmdlcyEpXG59LFxuICAgIF9hZGRSb3RhdGlvbmFsUHJvcFR3ZWVuID0gZnVuY3Rpb24gX2FkZFJvdGF0aW9uYWxQcm9wVHdlZW4ocGx1Z2luLCB0YXJnZXQsIHByb3BlcnR5LCBzdGFydE51bSwgZW5kVmFsdWUpIHtcbiAgdmFyIGNhcCA9IDM2MCxcbiAgICAgIGlzU3RyaW5nID0gX2lzU3RyaW5nKGVuZFZhbHVlKSxcbiAgICAgIGVuZE51bSA9IHBhcnNlRmxvYXQoZW5kVmFsdWUpICogKGlzU3RyaW5nICYmIH5lbmRWYWx1ZS5pbmRleE9mKFwicmFkXCIpID8gX1JBRDJERUcgOiAxKSxcbiAgICAgIGNoYW5nZSA9IGVuZE51bSAtIHN0YXJ0TnVtLFxuICAgICAgZmluYWxWYWx1ZSA9IHN0YXJ0TnVtICsgY2hhbmdlICsgXCJkZWdcIixcbiAgICAgIGRpcmVjdGlvbixcbiAgICAgIHB0O1xuXG4gIGlmIChpc1N0cmluZykge1xuICAgIGRpcmVjdGlvbiA9IGVuZFZhbHVlLnNwbGl0KFwiX1wiKVsxXTtcblxuICAgIGlmIChkaXJlY3Rpb24gPT09IFwic2hvcnRcIikge1xuICAgICAgY2hhbmdlICU9IGNhcDtcblxuICAgICAgaWYgKGNoYW5nZSAhPT0gY2hhbmdlICUgKGNhcCAvIDIpKSB7XG4gICAgICAgIGNoYW5nZSArPSBjaGFuZ2UgPCAwID8gY2FwIDogLWNhcDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoZGlyZWN0aW9uID09PSBcImN3XCIgJiYgY2hhbmdlIDwgMCkge1xuICAgICAgY2hhbmdlID0gKGNoYW5nZSArIGNhcCAqIF9iaWdOdW0pICUgY2FwIC0gfn4oY2hhbmdlIC8gY2FwKSAqIGNhcDtcbiAgICB9IGVsc2UgaWYgKGRpcmVjdGlvbiA9PT0gXCJjY3dcIiAmJiBjaGFuZ2UgPiAwKSB7XG4gICAgICBjaGFuZ2UgPSAoY2hhbmdlIC0gY2FwICogX2JpZ051bSkgJSBjYXAgLSB+fihjaGFuZ2UgLyBjYXApICogY2FwO1xuICAgIH1cbiAgfVxuXG4gIHBsdWdpbi5fcHQgPSBwdCA9IG5ldyBQcm9wVHdlZW4ocGx1Z2luLl9wdCwgdGFyZ2V0LCBwcm9wZXJ0eSwgc3RhcnROdW0sIGNoYW5nZSwgX3JlbmRlclByb3BXaXRoRW5kKTtcbiAgcHQuZSA9IGZpbmFsVmFsdWU7XG4gIHB0LnUgPSBcImRlZ1wiO1xuXG4gIHBsdWdpbi5fcHJvcHMucHVzaChwcm9wZXJ0eSk7XG5cbiAgcmV0dXJuIHB0O1xufSxcbiAgICBfYXNzaWduID0gZnVuY3Rpb24gX2Fzc2lnbih0YXJnZXQsIHNvdXJjZSkge1xuICAvLyBJbnRlcm5ldCBFeHBsb3JlciBkb2Vzbid0IGhhdmUgT2JqZWN0LmFzc2lnbigpLCBzbyB3ZSByZWNyZWF0ZSBpdCBoZXJlLlxuICBmb3IgKHZhciBwIGluIHNvdXJjZSkge1xuICAgIHRhcmdldFtwXSA9IHNvdXJjZVtwXTtcbiAgfVxuXG4gIHJldHVybiB0YXJnZXQ7XG59LFxuICAgIF9hZGRSYXdUcmFuc2Zvcm1QVHMgPSBmdW5jdGlvbiBfYWRkUmF3VHJhbnNmb3JtUFRzKHBsdWdpbiwgdHJhbnNmb3JtcywgdGFyZ2V0KSB7XG4gIC8vZm9yIGhhbmRsaW5nIGNhc2VzIHdoZXJlIHNvbWVvbmUgcGFzc2VzIGluIGEgd2hvbGUgdHJhbnNmb3JtIHN0cmluZywgbGlrZSB0cmFuc2Zvcm06IFwic2NhbGUoMiwgMykgcm90YXRlKDIwZGVnKSB0cmFuc2xhdGVZKDMwZW0pXCJcbiAgdmFyIHN0YXJ0Q2FjaGUgPSBfYXNzaWduKHt9LCB0YXJnZXQuX2dzYXApLFxuICAgICAgZXhjbHVkZSA9IFwicGVyc3BlY3RpdmUsZm9yY2UzRCx0cmFuc2Zvcm1PcmlnaW4sc3ZnT3JpZ2luXCIsXG4gICAgICBzdHlsZSA9IHRhcmdldC5zdHlsZSxcbiAgICAgIGVuZENhY2hlLFxuICAgICAgcCxcbiAgICAgIHN0YXJ0VmFsdWUsXG4gICAgICBlbmRWYWx1ZSxcbiAgICAgIHN0YXJ0TnVtLFxuICAgICAgZW5kTnVtLFxuICAgICAgc3RhcnRVbml0LFxuICAgICAgZW5kVW5pdDtcblxuICBpZiAoc3RhcnRDYWNoZS5zdmcpIHtcbiAgICBzdGFydFZhbHVlID0gdGFyZ2V0LmdldEF0dHJpYnV0ZShcInRyYW5zZm9ybVwiKTtcbiAgICB0YXJnZXQuc2V0QXR0cmlidXRlKFwidHJhbnNmb3JtXCIsIFwiXCIpO1xuICAgIHN0eWxlW190cmFuc2Zvcm1Qcm9wXSA9IHRyYW5zZm9ybXM7XG4gICAgZW5kQ2FjaGUgPSBfcGFyc2VUcmFuc2Zvcm0odGFyZ2V0LCAxKTtcblxuICAgIF9yZW1vdmVQcm9wZXJ0eSh0YXJnZXQsIF90cmFuc2Zvcm1Qcm9wKTtcblxuICAgIHRhcmdldC5zZXRBdHRyaWJ1dGUoXCJ0cmFuc2Zvcm1cIiwgc3RhcnRWYWx1ZSk7XG4gIH0gZWxzZSB7XG4gICAgc3RhcnRWYWx1ZSA9IGdldENvbXB1dGVkU3R5bGUodGFyZ2V0KVtfdHJhbnNmb3JtUHJvcF07XG4gICAgc3R5bGVbX3RyYW5zZm9ybVByb3BdID0gdHJhbnNmb3JtcztcbiAgICBlbmRDYWNoZSA9IF9wYXJzZVRyYW5zZm9ybSh0YXJnZXQsIDEpO1xuICAgIHN0eWxlW190cmFuc2Zvcm1Qcm9wXSA9IHN0YXJ0VmFsdWU7XG4gIH1cblxuICBmb3IgKHAgaW4gX3RyYW5zZm9ybVByb3BzKSB7XG4gICAgc3RhcnRWYWx1ZSA9IHN0YXJ0Q2FjaGVbcF07XG4gICAgZW5kVmFsdWUgPSBlbmRDYWNoZVtwXTtcblxuICAgIGlmIChzdGFydFZhbHVlICE9PSBlbmRWYWx1ZSAmJiBleGNsdWRlLmluZGV4T2YocCkgPCAwKSB7XG4gICAgICAvL3R3ZWVuaW5nIHRvIG5vIHBlcnNwZWN0aXZlIGdpdmVzIHZlcnkgdW5pbnR1aXRpdmUgcmVzdWx0cyAtIGp1c3Qga2VlcCB0aGUgc2FtZSBwZXJzcGVjdGl2ZSBpbiB0aGF0IGNhc2UuXG4gICAgICBzdGFydFVuaXQgPSBnZXRVbml0KHN0YXJ0VmFsdWUpO1xuICAgICAgZW5kVW5pdCA9IGdldFVuaXQoZW5kVmFsdWUpO1xuICAgICAgc3RhcnROdW0gPSBzdGFydFVuaXQgIT09IGVuZFVuaXQgPyBfY29udmVydFRvVW5pdCh0YXJnZXQsIHAsIHN0YXJ0VmFsdWUsIGVuZFVuaXQpIDogcGFyc2VGbG9hdChzdGFydFZhbHVlKTtcbiAgICAgIGVuZE51bSA9IHBhcnNlRmxvYXQoZW5kVmFsdWUpO1xuICAgICAgcGx1Z2luLl9wdCA9IG5ldyBQcm9wVHdlZW4ocGx1Z2luLl9wdCwgZW5kQ2FjaGUsIHAsIHN0YXJ0TnVtLCBlbmROdW0gLSBzdGFydE51bSwgX3JlbmRlckNTU1Byb3ApO1xuICAgICAgcGx1Z2luLl9wdC51ID0gZW5kVW5pdCB8fCAwO1xuXG4gICAgICBwbHVnaW4uX3Byb3BzLnB1c2gocCk7XG4gICAgfVxuICB9XG5cbiAgX2Fzc2lnbihlbmRDYWNoZSwgc3RhcnRDYWNoZSk7XG59OyAvLyBoYW5kbGUgc3BsaXR0aW5nIGFwYXJ0IHBhZGRpbmcsIG1hcmdpbiwgYm9yZGVyV2lkdGgsIGFuZCBib3JkZXJSYWRpdXMgaW50byB0aGVpciA0IGNvbXBvbmVudHMuIEZpcmVmb3gsIGZvciBleGFtcGxlLCB3b24ndCByZXBvcnQgYm9yZGVyUmFkaXVzIGNvcnJlY3RseSAtIGl0IHdpbGwgb25seSBkbyBib3JkZXJUb3BMZWZ0UmFkaXVzIGFuZCB0aGUgb3RoZXIgY29ybmVycy4gV2UgYWxzbyB3YW50IHRvIGhhbmRsZSBwYWRkaW5nVG9wLCBtYXJnaW5MZWZ0LCBib3JkZXJSaWdodFdpZHRoLCBldGMuXG5cblxuX2ZvckVhY2hOYW1lKFwicGFkZGluZyxtYXJnaW4sV2lkdGgsUmFkaXVzXCIsIGZ1bmN0aW9uIChuYW1lLCBpbmRleCkge1xuICB2YXIgdCA9IFwiVG9wXCIsXG4gICAgICByID0gXCJSaWdodFwiLFxuICAgICAgYiA9IFwiQm90dG9tXCIsXG4gICAgICBsID0gXCJMZWZ0XCIsXG4gICAgICBwcm9wcyA9IChpbmRleCA8IDMgPyBbdCwgciwgYiwgbF0gOiBbdCArIGwsIHQgKyByLCBiICsgciwgYiArIGxdKS5tYXAoZnVuY3Rpb24gKHNpZGUpIHtcbiAgICByZXR1cm4gaW5kZXggPCAyID8gbmFtZSArIHNpZGUgOiBcImJvcmRlclwiICsgc2lkZSArIG5hbWU7XG4gIH0pO1xuXG4gIF9zcGVjaWFsUHJvcHNbaW5kZXggPiAxID8gXCJib3JkZXJcIiArIG5hbWUgOiBuYW1lXSA9IGZ1bmN0aW9uIChwbHVnaW4sIHRhcmdldCwgcHJvcGVydHksIGVuZFZhbHVlLCB0d2Vlbikge1xuICAgIHZhciBhLCB2YXJzO1xuXG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPCA0KSB7XG4gICAgICAvLyBnZXR0ZXIsIHBhc3NlZCB0YXJnZXQsIHByb3BlcnR5LCBhbmQgdW5pdCAoZnJvbSBfZ2V0KCkpXG4gICAgICBhID0gcHJvcHMubWFwKGZ1bmN0aW9uIChwcm9wKSB7XG4gICAgICAgIHJldHVybiBfZ2V0KHBsdWdpbiwgcHJvcCwgcHJvcGVydHkpO1xuICAgICAgfSk7XG4gICAgICB2YXJzID0gYS5qb2luKFwiIFwiKTtcbiAgICAgIHJldHVybiB2YXJzLnNwbGl0KGFbMF0pLmxlbmd0aCA9PT0gNSA/IGFbMF0gOiB2YXJzO1xuICAgIH1cblxuICAgIGEgPSAoZW5kVmFsdWUgKyBcIlwiKS5zcGxpdChcIiBcIik7XG4gICAgdmFycyA9IHt9O1xuICAgIHByb3BzLmZvckVhY2goZnVuY3Rpb24gKHByb3AsIGkpIHtcbiAgICAgIHJldHVybiB2YXJzW3Byb3BdID0gYVtpXSA9IGFbaV0gfHwgYVsoaSAtIDEpIC8gMiB8IDBdO1xuICAgIH0pO1xuICAgIHBsdWdpbi5pbml0KHRhcmdldCwgdmFycywgdHdlZW4pO1xuICB9O1xufSk7XG5cbmV4cG9ydCB2YXIgQ1NTUGx1Z2luID0ge1xuICBuYW1lOiBcImNzc1wiLFxuICByZWdpc3RlcjogX2luaXRDb3JlLFxuICB0YXJnZXRUZXN0OiBmdW5jdGlvbiB0YXJnZXRUZXN0KHRhcmdldCkge1xuICAgIHJldHVybiB0YXJnZXQuc3R5bGUgJiYgdGFyZ2V0Lm5vZGVUeXBlO1xuICB9LFxuICBpbml0OiBmdW5jdGlvbiBpbml0KHRhcmdldCwgdmFycywgdHdlZW4sIGluZGV4LCB0YXJnZXRzKSB7XG4gICAgdmFyIHByb3BzID0gdGhpcy5fcHJvcHMsXG4gICAgICAgIHN0eWxlID0gdGFyZ2V0LnN0eWxlLFxuICAgICAgICBzdGFydEF0ID0gdHdlZW4udmFycy5zdGFydEF0LFxuICAgICAgICBzdGFydFZhbHVlLFxuICAgICAgICBlbmRWYWx1ZSxcbiAgICAgICAgZW5kTnVtLFxuICAgICAgICBzdGFydE51bSxcbiAgICAgICAgdHlwZSxcbiAgICAgICAgc3BlY2lhbFByb3AsXG4gICAgICAgIHAsXG4gICAgICAgIHN0YXJ0VW5pdCxcbiAgICAgICAgZW5kVW5pdCxcbiAgICAgICAgcmVsYXRpdmUsXG4gICAgICAgIGlzVHJhbnNmb3JtUmVsYXRlZCxcbiAgICAgICAgdHJhbnNmb3JtUHJvcFR3ZWVuLFxuICAgICAgICBjYWNoZSxcbiAgICAgICAgc21vb3RoLFxuICAgICAgICBoYXNQcmlvcml0eSxcbiAgICAgICAgaW5saW5lUHJvcHMsXG4gICAgICAgIGZpbmFsVHJhbnNmb3JtVmFsdWU7XG4gICAgX3BsdWdpbkluaXR0ZWQgfHwgX2luaXRDb3JlKCk7IC8vIHdlIG1heSBjYWxsIGluaXQoKSBtdWx0aXBsZSB0aW1lcyBvbiB0aGUgc2FtZSBwbHVnaW4gaW5zdGFuY2UsIGxpa2Ugd2hlbiBhZGRpbmcgc3BlY2lhbCBwcm9wZXJ0aWVzLCBzbyBtYWtlIHN1cmUgd2UgZG9uJ3Qgb3ZlcndyaXRlIHRoZSByZXZlcnQgZGF0YSBvciBpbmxpbmVQcm9wc1xuXG4gICAgdGhpcy5zdHlsZXMgPSB0aGlzLnN0eWxlcyB8fCBfZ2V0U3R5bGVTYXZlcih0YXJnZXQpO1xuICAgIGlubGluZVByb3BzID0gdGhpcy5zdHlsZXMucHJvcHM7XG4gICAgdGhpcy50d2VlbiA9IHR3ZWVuO1xuXG4gICAgZm9yIChwIGluIHZhcnMpIHtcbiAgICAgIGlmIChwID09PSBcImF1dG9Sb3VuZFwiKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBlbmRWYWx1ZSA9IHZhcnNbcF07XG5cbiAgICAgIGlmIChfcGx1Z2luc1twXSAmJiBfY2hlY2tQbHVnaW4ocCwgdmFycywgdHdlZW4sIGluZGV4LCB0YXJnZXQsIHRhcmdldHMpKSB7XG4gICAgICAgIC8vIHBsdWdpbnNcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIHR5cGUgPSB0eXBlb2YgZW5kVmFsdWU7XG4gICAgICBzcGVjaWFsUHJvcCA9IF9zcGVjaWFsUHJvcHNbcF07XG5cbiAgICAgIGlmICh0eXBlID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgZW5kVmFsdWUgPSBlbmRWYWx1ZS5jYWxsKHR3ZWVuLCBpbmRleCwgdGFyZ2V0LCB0YXJnZXRzKTtcbiAgICAgICAgdHlwZSA9IHR5cGVvZiBlbmRWYWx1ZTtcbiAgICAgIH1cblxuICAgICAgaWYgKHR5cGUgPT09IFwic3RyaW5nXCIgJiYgfmVuZFZhbHVlLmluZGV4T2YoXCJyYW5kb20oXCIpKSB7XG4gICAgICAgIGVuZFZhbHVlID0gX3JlcGxhY2VSYW5kb20oZW5kVmFsdWUpO1xuICAgICAgfVxuXG4gICAgICBpZiAoc3BlY2lhbFByb3ApIHtcbiAgICAgICAgc3BlY2lhbFByb3AodGhpcywgdGFyZ2V0LCBwLCBlbmRWYWx1ZSwgdHdlZW4pICYmIChoYXNQcmlvcml0eSA9IDEpO1xuICAgICAgfSBlbHNlIGlmIChwLnN1YnN0cigwLCAyKSA9PT0gXCItLVwiKSB7XG4gICAgICAgIC8vQ1NTIHZhcmlhYmxlXG4gICAgICAgIHN0YXJ0VmFsdWUgPSAoZ2V0Q29tcHV0ZWRTdHlsZSh0YXJnZXQpLmdldFByb3BlcnR5VmFsdWUocCkgKyBcIlwiKS50cmltKCk7XG4gICAgICAgIGVuZFZhbHVlICs9IFwiXCI7XG4gICAgICAgIF9jb2xvckV4cC5sYXN0SW5kZXggPSAwO1xuXG4gICAgICAgIGlmICghX2NvbG9yRXhwLnRlc3Qoc3RhcnRWYWx1ZSkpIHtcbiAgICAgICAgICAvLyBjb2xvcnMgZG9uJ3QgaGF2ZSB1bml0c1xuICAgICAgICAgIHN0YXJ0VW5pdCA9IGdldFVuaXQoc3RhcnRWYWx1ZSk7XG4gICAgICAgICAgZW5kVW5pdCA9IGdldFVuaXQoZW5kVmFsdWUpO1xuICAgICAgICAgIGVuZFVuaXQgPyBzdGFydFVuaXQgIT09IGVuZFVuaXQgJiYgKHN0YXJ0VmFsdWUgPSBfY29udmVydFRvVW5pdCh0YXJnZXQsIHAsIHN0YXJ0VmFsdWUsIGVuZFVuaXQpICsgZW5kVW5pdCkgOiBzdGFydFVuaXQgJiYgKGVuZFZhbHVlICs9IHN0YXJ0VW5pdCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmFkZChzdHlsZSwgXCJzZXRQcm9wZXJ0eVwiLCBzdGFydFZhbHVlLCBlbmRWYWx1ZSwgaW5kZXgsIHRhcmdldHMsIDAsIDAsIHApO1xuICAgICAgICBwcm9wcy5wdXNoKHApO1xuICAgICAgICBpbmxpbmVQcm9wcy5wdXNoKHAsIDAsIHN0eWxlW3BdKTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZSAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICBpZiAoc3RhcnRBdCAmJiBwIGluIHN0YXJ0QXQpIHtcbiAgICAgICAgICAvLyBpbiBjYXNlIHNvbWVvbmUgaGFyZC1jb2RlcyBhIGNvbXBsZXggdmFsdWUgYXMgdGhlIHN0YXJ0LCBsaWtlIHRvcDogXCJjYWxjKDJ2aCAvIDIpXCIuIFdpdGhvdXQgdGhpcywgaXQnZCB1c2UgdGhlIGNvbXB1dGVkIHZhbHVlIChhbHdheXMgaW4gcHgpXG4gICAgICAgICAgc3RhcnRWYWx1ZSA9IHR5cGVvZiBzdGFydEF0W3BdID09PSBcImZ1bmN0aW9uXCIgPyBzdGFydEF0W3BdLmNhbGwodHdlZW4sIGluZGV4LCB0YXJnZXQsIHRhcmdldHMpIDogc3RhcnRBdFtwXTtcbiAgICAgICAgICBfaXNTdHJpbmcoc3RhcnRWYWx1ZSkgJiYgfnN0YXJ0VmFsdWUuaW5kZXhPZihcInJhbmRvbShcIikgJiYgKHN0YXJ0VmFsdWUgPSBfcmVwbGFjZVJhbmRvbShzdGFydFZhbHVlKSk7XG4gICAgICAgICAgZ2V0VW5pdChzdGFydFZhbHVlICsgXCJcIikgfHwgc3RhcnRWYWx1ZSA9PT0gXCJhdXRvXCIgfHwgKHN0YXJ0VmFsdWUgKz0gX2NvbmZpZy51bml0c1twXSB8fCBnZXRVbml0KF9nZXQodGFyZ2V0LCBwKSkgfHwgXCJcIik7IC8vIGZvciBjYXNlcyB3aGVuIHNvbWVvbmUgcGFzc2VzIGluIGEgdW5pdGxlc3MgdmFsdWUgbGlrZSB7eDogMTAwfTsgaWYgd2UgdHJ5IHNldHRpbmcgdHJhbnNsYXRlKDEwMCwgMHB4KSBpdCB3b24ndCB3b3JrLlxuXG4gICAgICAgICAgKHN0YXJ0VmFsdWUgKyBcIlwiKS5jaGFyQXQoMSkgPT09IFwiPVwiICYmIChzdGFydFZhbHVlID0gX2dldCh0YXJnZXQsIHApKTsgLy8gY2FuJ3Qgd29yayB3aXRoIHJlbGF0aXZlIHZhbHVlc1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHN0YXJ0VmFsdWUgPSBfZ2V0KHRhcmdldCwgcCk7XG4gICAgICAgIH1cblxuICAgICAgICBzdGFydE51bSA9IHBhcnNlRmxvYXQoc3RhcnRWYWx1ZSk7XG4gICAgICAgIHJlbGF0aXZlID0gdHlwZSA9PT0gXCJzdHJpbmdcIiAmJiBlbmRWYWx1ZS5jaGFyQXQoMSkgPT09IFwiPVwiICYmIGVuZFZhbHVlLnN1YnN0cigwLCAyKTtcbiAgICAgICAgcmVsYXRpdmUgJiYgKGVuZFZhbHVlID0gZW5kVmFsdWUuc3Vic3RyKDIpKTtcbiAgICAgICAgZW5kTnVtID0gcGFyc2VGbG9hdChlbmRWYWx1ZSk7XG5cbiAgICAgICAgaWYgKHAgaW4gX3Byb3BlcnR5QWxpYXNlcykge1xuICAgICAgICAgIGlmIChwID09PSBcImF1dG9BbHBoYVwiKSB7XG4gICAgICAgICAgICAvL3NwZWNpYWwgY2FzZSB3aGVyZSB3ZSBjb250cm9sIHRoZSB2aXNpYmlsaXR5IGFsb25nIHdpdGggb3BhY2l0eS4gV2Ugc3RpbGwgYWxsb3cgdGhlIG9wYWNpdHkgdmFsdWUgdG8gcGFzcyB0aHJvdWdoIGFuZCBnZXQgdHdlZW5lZC5cbiAgICAgICAgICAgIGlmIChzdGFydE51bSA9PT0gMSAmJiBfZ2V0KHRhcmdldCwgXCJ2aXNpYmlsaXR5XCIpID09PSBcImhpZGRlblwiICYmIGVuZE51bSkge1xuICAgICAgICAgICAgICAvL2lmIHZpc2liaWxpdHkgaXMgaW5pdGlhbGx5IHNldCB0byBcImhpZGRlblwiLCB3ZSBzaG91bGQgaW50ZXJwcmV0IHRoYXQgYXMgaW50ZW50IHRvIG1ha2Ugb3BhY2l0eSAwIChhIGNvbnZlbmllbmNlKVxuICAgICAgICAgICAgICBzdGFydE51bSA9IDA7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlubGluZVByb3BzLnB1c2goXCJ2aXNpYmlsaXR5XCIsIDAsIHN0eWxlLnZpc2liaWxpdHkpO1xuXG4gICAgICAgICAgICBfYWRkTm9uVHdlZW5pbmdQVCh0aGlzLCBzdHlsZSwgXCJ2aXNpYmlsaXR5XCIsIHN0YXJ0TnVtID8gXCJpbmhlcml0XCIgOiBcImhpZGRlblwiLCBlbmROdW0gPyBcImluaGVyaXRcIiA6IFwiaGlkZGVuXCIsICFlbmROdW0pO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChwICE9PSBcInNjYWxlXCIgJiYgcCAhPT0gXCJ0cmFuc2Zvcm1cIikge1xuICAgICAgICAgICAgcCA9IF9wcm9wZXJ0eUFsaWFzZXNbcF07XG4gICAgICAgICAgICB+cC5pbmRleE9mKFwiLFwiKSAmJiAocCA9IHAuc3BsaXQoXCIsXCIpWzBdKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpc1RyYW5zZm9ybVJlbGF0ZWQgPSBwIGluIF90cmFuc2Zvcm1Qcm9wczsgLy8tLS0gVFJBTlNGT1JNLVJFTEFURUQgLS0tXG5cbiAgICAgICAgaWYgKGlzVHJhbnNmb3JtUmVsYXRlZCkge1xuICAgICAgICAgIHRoaXMuc3R5bGVzLnNhdmUocCk7XG4gICAgICAgICAgZmluYWxUcmFuc2Zvcm1WYWx1ZSA9IGVuZFZhbHVlOyAvLyB0aGlzIGlzIGFsd2F5cyB0aGUgc2FtZSBhcyBlbmRWYWx1ZSBleGNlcHQgd2hlbiBpdCdzIGEgdmFyKC0tKSB2YWx1ZSwgaW4gd2hpY2ggY2FzZSB3ZSBuZWVkIHRvIGNhbGN1bGF0ZSB0aGUgZW5kIHZhbHVlLlxuXG4gICAgICAgICAgaWYgKHR5cGUgPT09IFwic3RyaW5nXCIgJiYgZW5kVmFsdWUuc3Vic3RyaW5nKDAsIDYpID09PSBcInZhcigtLVwiKSB7XG4gICAgICAgICAgICBlbmRWYWx1ZSA9IF9nZXRDb21wdXRlZFByb3BlcnR5KHRhcmdldCwgZW5kVmFsdWUuc3Vic3RyaW5nKDQsIGVuZFZhbHVlLmluZGV4T2YoXCIpXCIpKSk7XG5cbiAgICAgICAgICAgIGlmIChlbmRWYWx1ZS5zdWJzdHJpbmcoMCwgNSkgPT09IFwiY2FsYyhcIikge1xuICAgICAgICAgICAgICB2YXIgb3JpZ1BlcnNwZWN0aXZlID0gdGFyZ2V0LnN0eWxlLnBlcnNwZWN0aXZlO1xuICAgICAgICAgICAgICB0YXJnZXQuc3R5bGUucGVyc3BlY3RpdmUgPSBlbmRWYWx1ZTtcbiAgICAgICAgICAgICAgZW5kVmFsdWUgPSBfZ2V0Q29tcHV0ZWRQcm9wZXJ0eSh0YXJnZXQsIFwicGVyc3BlY3RpdmVcIik7XG4gICAgICAgICAgICAgIG9yaWdQZXJzcGVjdGl2ZSA/IHRhcmdldC5zdHlsZS5wZXJzcGVjdGl2ZSA9IG9yaWdQZXJzcGVjdGl2ZSA6IF9yZW1vdmVQcm9wZXJ0eSh0YXJnZXQsIFwicGVyc3BlY3RpdmVcIik7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGVuZE51bSA9IHBhcnNlRmxvYXQoZW5kVmFsdWUpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmICghdHJhbnNmb3JtUHJvcFR3ZWVuKSB7XG4gICAgICAgICAgICBjYWNoZSA9IHRhcmdldC5fZ3NhcDtcbiAgICAgICAgICAgIGNhY2hlLnJlbmRlclRyYW5zZm9ybSAmJiAhdmFycy5wYXJzZVRyYW5zZm9ybSB8fCBfcGFyc2VUcmFuc2Zvcm0odGFyZ2V0LCB2YXJzLnBhcnNlVHJhbnNmb3JtKTsgLy8gaWYsIGZvciBleGFtcGxlLCBnc2FwLnNldCguLi4ge3RyYW5zZm9ybTpcInRyYW5zbGF0ZVgoNTB2dylcIn0pLCB0aGUgX2dldCgpIGNhbGwgZG9lc24ndCBwYXJzZSB0aGUgdHJhbnNmb3JtLCB0aHVzIGNhY2hlLnJlbmRlclRyYW5zZm9ybSB3b24ndCBiZSBzZXQgeWV0IHNvIGZvcmNlIHRoZSBwYXJzaW5nIG9mIHRoZSB0cmFuc2Zvcm0gaGVyZS5cblxuICAgICAgICAgICAgc21vb3RoID0gdmFycy5zbW9vdGhPcmlnaW4gIT09IGZhbHNlICYmIGNhY2hlLnNtb290aDtcbiAgICAgICAgICAgIHRyYW5zZm9ybVByb3BUd2VlbiA9IHRoaXMuX3B0ID0gbmV3IFByb3BUd2Vlbih0aGlzLl9wdCwgc3R5bGUsIF90cmFuc2Zvcm1Qcm9wLCAwLCAxLCBjYWNoZS5yZW5kZXJUcmFuc2Zvcm0sIGNhY2hlLCAwLCAtMSk7IC8vdGhlIGZpcnN0IHRpbWUgdGhyb3VnaCwgY3JlYXRlIHRoZSByZW5kZXJpbmcgUHJvcFR3ZWVuIHNvIHRoYXQgaXQgcnVucyBMQVNUIChpbiB0aGUgbGlua2VkIGxpc3QsIHdlIGtlZXAgYWRkaW5nIHRvIHRoZSBiZWdpbm5pbmcpXG5cbiAgICAgICAgICAgIHRyYW5zZm9ybVByb3BUd2Vlbi5kZXAgPSAxOyAvL2ZsYWcgaXQgYXMgZGVwZW5kZW50IHNvIHRoYXQgaWYgdGhpbmdzIGdldCBraWxsZWQvb3ZlcndyaXR0ZW4gYW5kIHRoaXMgaXMgdGhlIG9ubHkgUHJvcFR3ZWVuIGxlZnQsIHdlIGNhbiBzYWZlbHkga2lsbCB0aGUgd2hvbGUgdHdlZW4uXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHAgPT09IFwic2NhbGVcIikge1xuICAgICAgICAgICAgdGhpcy5fcHQgPSBuZXcgUHJvcFR3ZWVuKHRoaXMuX3B0LCBjYWNoZSwgXCJzY2FsZVlcIiwgY2FjaGUuc2NhbGVZLCAocmVsYXRpdmUgPyBfcGFyc2VSZWxhdGl2ZShjYWNoZS5zY2FsZVksIHJlbGF0aXZlICsgZW5kTnVtKSA6IGVuZE51bSkgLSBjYWNoZS5zY2FsZVkgfHwgMCwgX3JlbmRlckNTU1Byb3ApO1xuICAgICAgICAgICAgdGhpcy5fcHQudSA9IDA7XG4gICAgICAgICAgICBwcm9wcy5wdXNoKFwic2NhbGVZXCIsIHApO1xuICAgICAgICAgICAgcCArPSBcIlhcIjtcbiAgICAgICAgICB9IGVsc2UgaWYgKHAgPT09IFwidHJhbnNmb3JtT3JpZ2luXCIpIHtcbiAgICAgICAgICAgIGlubGluZVByb3BzLnB1c2goX3RyYW5zZm9ybU9yaWdpblByb3AsIDAsIHN0eWxlW190cmFuc2Zvcm1PcmlnaW5Qcm9wXSk7XG4gICAgICAgICAgICBlbmRWYWx1ZSA9IF9jb252ZXJ0S2V5d29yZHNUb1BlcmNlbnRhZ2VzKGVuZFZhbHVlKTsgLy9pbiBjYXNlIHNvbWV0aGluZyBsaWtlIFwibGVmdCB0b3BcIiBvciBcImJvdHRvbSByaWdodFwiIGlzIHBhc3NlZCBpbi4gQ29udmVydCB0byBwZXJjZW50YWdlcy5cblxuICAgICAgICAgICAgaWYgKGNhY2hlLnN2Zykge1xuICAgICAgICAgICAgICBfYXBwbHlTVkdPcmlnaW4odGFyZ2V0LCBlbmRWYWx1ZSwgMCwgc21vb3RoLCAwLCB0aGlzKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGVuZFVuaXQgPSBwYXJzZUZsb2F0KGVuZFZhbHVlLnNwbGl0KFwiIFwiKVsyXSkgfHwgMDsgLy9oYW5kbGUgdGhlIHpPcmlnaW4gc2VwYXJhdGVseSFcblxuICAgICAgICAgICAgICBlbmRVbml0ICE9PSBjYWNoZS56T3JpZ2luICYmIF9hZGROb25Ud2VlbmluZ1BUKHRoaXMsIGNhY2hlLCBcInpPcmlnaW5cIiwgY2FjaGUuek9yaWdpbiwgZW5kVW5pdCk7XG5cbiAgICAgICAgICAgICAgX2FkZE5vblR3ZWVuaW5nUFQodGhpcywgc3R5bGUsIHAsIF9maXJzdFR3b09ubHkoc3RhcnRWYWx1ZSksIF9maXJzdFR3b09ubHkoZW5kVmFsdWUpKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfSBlbHNlIGlmIChwID09PSBcInN2Z09yaWdpblwiKSB7XG4gICAgICAgICAgICBfYXBwbHlTVkdPcmlnaW4odGFyZ2V0LCBlbmRWYWx1ZSwgMSwgc21vb3RoLCAwLCB0aGlzKTtcblxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfSBlbHNlIGlmIChwIGluIF9yb3RhdGlvbmFsUHJvcGVydGllcykge1xuICAgICAgICAgICAgX2FkZFJvdGF0aW9uYWxQcm9wVHdlZW4odGhpcywgY2FjaGUsIHAsIHN0YXJ0TnVtLCByZWxhdGl2ZSA/IF9wYXJzZVJlbGF0aXZlKHN0YXJ0TnVtLCByZWxhdGl2ZSArIGVuZFZhbHVlKSA6IGVuZFZhbHVlKTtcblxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfSBlbHNlIGlmIChwID09PSBcInNtb290aE9yaWdpblwiKSB7XG4gICAgICAgICAgICBfYWRkTm9uVHdlZW5pbmdQVCh0aGlzLCBjYWNoZSwgXCJzbW9vdGhcIiwgY2FjaGUuc21vb3RoLCBlbmRWYWx1ZSk7XG5cbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH0gZWxzZSBpZiAocCA9PT0gXCJmb3JjZTNEXCIpIHtcbiAgICAgICAgICAgIGNhY2hlW3BdID0gZW5kVmFsdWU7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHAgPT09IFwidHJhbnNmb3JtXCIpIHtcbiAgICAgICAgICAgIF9hZGRSYXdUcmFuc2Zvcm1QVHModGhpcywgZW5kVmFsdWUsIHRhcmdldCk7XG5cbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmICghKHAgaW4gc3R5bGUpKSB7XG4gICAgICAgICAgcCA9IF9jaGVja1Byb3BQcmVmaXgocCkgfHwgcDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpc1RyYW5zZm9ybVJlbGF0ZWQgfHwgKGVuZE51bSB8fCBlbmROdW0gPT09IDApICYmIChzdGFydE51bSB8fCBzdGFydE51bSA9PT0gMCkgJiYgIV9jb21wbGV4RXhwLnRlc3QoZW5kVmFsdWUpICYmIHAgaW4gc3R5bGUpIHtcbiAgICAgICAgICBzdGFydFVuaXQgPSAoc3RhcnRWYWx1ZSArIFwiXCIpLnN1YnN0cigoc3RhcnROdW0gKyBcIlwiKS5sZW5ndGgpO1xuICAgICAgICAgIGVuZE51bSB8fCAoZW5kTnVtID0gMCk7IC8vIHByb3RlY3QgYWdhaW5zdCBOYU5cblxuICAgICAgICAgIGVuZFVuaXQgPSBnZXRVbml0KGVuZFZhbHVlKSB8fCAocCBpbiBfY29uZmlnLnVuaXRzID8gX2NvbmZpZy51bml0c1twXSA6IHN0YXJ0VW5pdCk7XG4gICAgICAgICAgc3RhcnRVbml0ICE9PSBlbmRVbml0ICYmIChzdGFydE51bSA9IF9jb252ZXJ0VG9Vbml0KHRhcmdldCwgcCwgc3RhcnRWYWx1ZSwgZW5kVW5pdCkpO1xuICAgICAgICAgIHRoaXMuX3B0ID0gbmV3IFByb3BUd2Vlbih0aGlzLl9wdCwgaXNUcmFuc2Zvcm1SZWxhdGVkID8gY2FjaGUgOiBzdHlsZSwgcCwgc3RhcnROdW0sIChyZWxhdGl2ZSA/IF9wYXJzZVJlbGF0aXZlKHN0YXJ0TnVtLCByZWxhdGl2ZSArIGVuZE51bSkgOiBlbmROdW0pIC0gc3RhcnROdW0sICFpc1RyYW5zZm9ybVJlbGF0ZWQgJiYgKGVuZFVuaXQgPT09IFwicHhcIiB8fCBwID09PSBcInpJbmRleFwiKSAmJiB2YXJzLmF1dG9Sb3VuZCAhPT0gZmFsc2UgPyBfcmVuZGVyUm91bmRlZENTU1Byb3AgOiBfcmVuZGVyQ1NTUHJvcCk7XG4gICAgICAgICAgdGhpcy5fcHQudSA9IGVuZFVuaXQgfHwgMDtcblxuICAgICAgICAgIGlmIChpc1RyYW5zZm9ybVJlbGF0ZWQgJiYgZmluYWxUcmFuc2Zvcm1WYWx1ZSAhPT0gZW5kVmFsdWUpIHtcbiAgICAgICAgICAgIHRoaXMuX3B0LmIgPSBzdGFydFZhbHVlO1xuICAgICAgICAgICAgdGhpcy5fcHQuZSA9IGZpbmFsVHJhbnNmb3JtVmFsdWU7XG4gICAgICAgICAgICB0aGlzLl9wdC5yID0gX3JlbmRlckNTU1Byb3BXaXRoQmVnaW5uaW5nQW5kRW5kO1xuICAgICAgICAgIH0gZWxzZSBpZiAoc3RhcnRVbml0ICE9PSBlbmRVbml0ICYmIGVuZFVuaXQgIT09IFwiJVwiKSB7XG4gICAgICAgICAgICAvL3doZW4gdGhlIHR3ZWVuIGdvZXMgYWxsIHRoZSB3YXkgYmFjayB0byB0aGUgYmVnaW5uaW5nLCB3ZSBuZWVkIHRvIHJldmVydCBpdCB0byB0aGUgT0xEL09SSUdJTkFMIHZhbHVlICh3aXRoIHRob3NlIHVuaXRzKS4gV2UgcmVjb3JkIHRoYXQgYXMgYSBcImJcIiAoYmVnaW5uaW5nKSBwcm9wZXJ0eSBhbmQgcG9pbnQgdG8gYSByZW5kZXIgbWV0aG9kIHRoYXQgaGFuZGxlcyB0aGF0LiAocGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9uKVxuICAgICAgICAgICAgdGhpcy5fcHQuYiA9IHN0YXJ0VmFsdWU7XG4gICAgICAgICAgICB0aGlzLl9wdC5yID0gX3JlbmRlckNTU1Byb3BXaXRoQmVnaW5uaW5nO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmICghKHAgaW4gc3R5bGUpKSB7XG4gICAgICAgICAgaWYgKHAgaW4gdGFyZ2V0KSB7XG4gICAgICAgICAgICAvL21heWJlIGl0J3Mgbm90IGEgc3R5bGUgLSBpdCBjb3VsZCBiZSBhIHByb3BlcnR5IGFkZGVkIGRpcmVjdGx5IHRvIGFuIGVsZW1lbnQgaW4gd2hpY2ggY2FzZSB3ZSdsbCB0cnkgdG8gYW5pbWF0ZSB0aGF0LlxuICAgICAgICAgICAgdGhpcy5hZGQodGFyZ2V0LCBwLCBzdGFydFZhbHVlIHx8IHRhcmdldFtwXSwgcmVsYXRpdmUgPyByZWxhdGl2ZSArIGVuZFZhbHVlIDogZW5kVmFsdWUsIGluZGV4LCB0YXJnZXRzKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHAgIT09IFwicGFyc2VUcmFuc2Zvcm1cIikge1xuICAgICAgICAgICAgX21pc3NpbmdQbHVnaW4ocCwgZW5kVmFsdWUpO1xuXG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgX3R3ZWVuQ29tcGxleENTU1N0cmluZy5jYWxsKHRoaXMsIHRhcmdldCwgcCwgc3RhcnRWYWx1ZSwgcmVsYXRpdmUgPyByZWxhdGl2ZSArIGVuZFZhbHVlIDogZW5kVmFsdWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaXNUcmFuc2Zvcm1SZWxhdGVkIHx8IChwIGluIHN0eWxlID8gaW5saW5lUHJvcHMucHVzaChwLCAwLCBzdHlsZVtwXSkgOiB0eXBlb2YgdGFyZ2V0W3BdID09PSBcImZ1bmN0aW9uXCIgPyBpbmxpbmVQcm9wcy5wdXNoKHAsIDIsIHRhcmdldFtwXSgpKSA6IGlubGluZVByb3BzLnB1c2gocCwgMSwgc3RhcnRWYWx1ZSB8fCB0YXJnZXRbcF0pKTtcbiAgICAgICAgcHJvcHMucHVzaChwKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBoYXNQcmlvcml0eSAmJiBfc29ydFByb3BUd2VlbnNCeVByaW9yaXR5KHRoaXMpO1xuICB9LFxuICByZW5kZXI6IGZ1bmN0aW9uIHJlbmRlcihyYXRpbywgZGF0YSkge1xuICAgIGlmIChkYXRhLnR3ZWVuLl90aW1lIHx8ICFfcmV2ZXJ0aW5nKCkpIHtcbiAgICAgIHZhciBwdCA9IGRhdGEuX3B0O1xuXG4gICAgICB3aGlsZSAocHQpIHtcbiAgICAgICAgcHQucihyYXRpbywgcHQuZCk7XG4gICAgICAgIHB0ID0gcHQuX25leHQ7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGRhdGEuc3R5bGVzLnJldmVydCgpO1xuICAgIH1cbiAgfSxcbiAgZ2V0OiBfZ2V0LFxuICBhbGlhc2VzOiBfcHJvcGVydHlBbGlhc2VzLFxuICBnZXRTZXR0ZXI6IGZ1bmN0aW9uIGdldFNldHRlcih0YXJnZXQsIHByb3BlcnR5LCBwbHVnaW4pIHtcbiAgICAvL3JldHVybnMgYSBzZXR0ZXIgZnVuY3Rpb24gdGhhdCBhY2NlcHRzIHRhcmdldCwgcHJvcGVydHksIHZhbHVlIGFuZCBhcHBsaWVzIGl0IGFjY29yZGluZ2x5LiBSZW1lbWJlciwgcHJvcGVydGllcyBsaWtlIFwieFwiIGFyZW4ndCBhcyBzaW1wbGUgYXMgdGFyZ2V0LnN0eWxlLnByb3BlcnR5ID0gdmFsdWUgYmVjYXVzZSB0aGV5J3ZlIGdvdCB0byBiZSBhcHBsaWVkIHRvIGEgcHJveHkgb2JqZWN0IGFuZCB0aGVuIG1lcmdlZCBpbnRvIGEgdHJhbnNmb3JtIHN0cmluZyBpbiBhIHJlbmRlcmVyLlxuICAgIHZhciBwID0gX3Byb3BlcnR5QWxpYXNlc1twcm9wZXJ0eV07XG4gICAgcCAmJiBwLmluZGV4T2YoXCIsXCIpIDwgMCAmJiAocHJvcGVydHkgPSBwKTtcbiAgICByZXR1cm4gcHJvcGVydHkgaW4gX3RyYW5zZm9ybVByb3BzICYmIHByb3BlcnR5ICE9PSBfdHJhbnNmb3JtT3JpZ2luUHJvcCAmJiAodGFyZ2V0Ll9nc2FwLnggfHwgX2dldCh0YXJnZXQsIFwieFwiKSkgPyBwbHVnaW4gJiYgX3JlY2VudFNldHRlclBsdWdpbiA9PT0gcGx1Z2luID8gcHJvcGVydHkgPT09IFwic2NhbGVcIiA/IF9zZXR0ZXJTY2FsZSA6IF9zZXR0ZXJUcmFuc2Zvcm0gOiAoX3JlY2VudFNldHRlclBsdWdpbiA9IHBsdWdpbiB8fCB7fSkgJiYgKHByb3BlcnR5ID09PSBcInNjYWxlXCIgPyBfc2V0dGVyU2NhbGVXaXRoUmVuZGVyIDogX3NldHRlclRyYW5zZm9ybVdpdGhSZW5kZXIpIDogdGFyZ2V0LnN0eWxlICYmICFfaXNVbmRlZmluZWQodGFyZ2V0LnN0eWxlW3Byb3BlcnR5XSkgPyBfc2V0dGVyQ1NTU3R5bGUgOiB+cHJvcGVydHkuaW5kZXhPZihcIi1cIikgPyBfc2V0dGVyQ1NTUHJvcCA6IF9nZXRTZXR0ZXIodGFyZ2V0LCBwcm9wZXJ0eSk7XG4gIH0sXG4gIGNvcmU6IHtcbiAgICBfcmVtb3ZlUHJvcGVydHk6IF9yZW1vdmVQcm9wZXJ0eSxcbiAgICBfZ2V0TWF0cml4OiBfZ2V0TWF0cml4XG4gIH1cbn07XG5nc2FwLnV0aWxzLmNoZWNrUHJlZml4ID0gX2NoZWNrUHJvcFByZWZpeDtcbmdzYXAuY29yZS5nZXRTdHlsZVNhdmVyID0gX2dldFN0eWxlU2F2ZXI7XG5cbihmdW5jdGlvbiAocG9zaXRpb25BbmRTY2FsZSwgcm90YXRpb24sIG90aGVycywgYWxpYXNlcykge1xuICB2YXIgYWxsID0gX2ZvckVhY2hOYW1lKHBvc2l0aW9uQW5kU2NhbGUgKyBcIixcIiArIHJvdGF0aW9uICsgXCIsXCIgKyBvdGhlcnMsIGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgX3RyYW5zZm9ybVByb3BzW25hbWVdID0gMTtcbiAgfSk7XG5cbiAgX2ZvckVhY2hOYW1lKHJvdGF0aW9uLCBmdW5jdGlvbiAobmFtZSkge1xuICAgIF9jb25maWcudW5pdHNbbmFtZV0gPSBcImRlZ1wiO1xuICAgIF9yb3RhdGlvbmFsUHJvcGVydGllc1tuYW1lXSA9IDE7XG4gIH0pO1xuXG4gIF9wcm9wZXJ0eUFsaWFzZXNbYWxsWzEzXV0gPSBwb3NpdGlvbkFuZFNjYWxlICsgXCIsXCIgKyByb3RhdGlvbjtcblxuICBfZm9yRWFjaE5hbWUoYWxpYXNlcywgZnVuY3Rpb24gKG5hbWUpIHtcbiAgICB2YXIgc3BsaXQgPSBuYW1lLnNwbGl0KFwiOlwiKTtcbiAgICBfcHJvcGVydHlBbGlhc2VzW3NwbGl0WzFdXSA9IGFsbFtzcGxpdFswXV07XG4gIH0pO1xufSkoXCJ4LHkseixzY2FsZSxzY2FsZVgsc2NhbGVZLHhQZXJjZW50LHlQZXJjZW50XCIsIFwicm90YXRpb24scm90YXRpb25YLHJvdGF0aW9uWSxza2V3WCxza2V3WVwiLCBcInRyYW5zZm9ybSx0cmFuc2Zvcm1PcmlnaW4sc3ZnT3JpZ2luLGZvcmNlM0Qsc21vb3RoT3JpZ2luLHRyYW5zZm9ybVBlcnNwZWN0aXZlXCIsIFwiMDp0cmFuc2xhdGVYLDE6dHJhbnNsYXRlWSwyOnRyYW5zbGF0ZVosODpyb3RhdGUsODpyb3RhdGlvblosODpyb3RhdGVaLDk6cm90YXRlWCwxMDpyb3RhdGVZXCIpO1xuXG5fZm9yRWFjaE5hbWUoXCJ4LHkseix0b3AscmlnaHQsYm90dG9tLGxlZnQsd2lkdGgsaGVpZ2h0LGZvbnRTaXplLHBhZGRpbmcsbWFyZ2luLHBlcnNwZWN0aXZlXCIsIGZ1bmN0aW9uIChuYW1lKSB7XG4gIF9jb25maWcudW5pdHNbbmFtZV0gPSBcInB4XCI7XG59KTtcblxuZ3NhcC5yZWdpc3RlclBsdWdpbihDU1NQbHVnaW4pO1xuZXhwb3J0IHsgQ1NTUGx1Z2luIGFzIGRlZmF1bHQsIF9nZXRCQm94LCBfY3JlYXRlRWxlbWVudCwgX2NoZWNrUHJvcFByZWZpeCBhcyBjaGVja1ByZWZpeCB9OyIsImltcG9ydCB7IGdzYXAsIFBvd2VyMCwgUG93ZXIxLCBQb3dlcjIsIFBvd2VyMywgUG93ZXI0LCBMaW5lYXIsIFF1YWQsIEN1YmljLCBRdWFydCwgUXVpbnQsIFN0cm9uZywgRWxhc3RpYywgQmFjaywgU3RlcHBlZEVhc2UsIEJvdW5jZSwgU2luZSwgRXhwbywgQ2lyYywgVHdlZW5MaXRlLCBUaW1lbGluZUxpdGUsIFRpbWVsaW5lTWF4IH0gZnJvbSBcIi4vZ3NhcC1jb3JlLmpzXCI7XG5pbXBvcnQgeyBDU1NQbHVnaW4gfSBmcm9tIFwiLi9DU1NQbHVnaW4uanNcIjtcbnZhciBnc2FwV2l0aENTUyA9IGdzYXAucmVnaXN0ZXJQbHVnaW4oQ1NTUGx1Z2luKSB8fCBnc2FwLFxuICAgIC8vIHRvIHByb3RlY3QgZnJvbSB0cmVlIHNoYWtpbmdcblR3ZWVuTWF4V2l0aENTUyA9IGdzYXBXaXRoQ1NTLmNvcmUuVHdlZW47XG5leHBvcnQgeyBnc2FwV2l0aENTUyBhcyBnc2FwLCBnc2FwV2l0aENTUyBhcyBkZWZhdWx0LCBDU1NQbHVnaW4sIFR3ZWVuTWF4V2l0aENTUyBhcyBUd2Vlbk1heCwgVHdlZW5MaXRlLCBUaW1lbGluZU1heCwgVGltZWxpbmVMaXRlLCBQb3dlcjAsIFBvd2VyMSwgUG93ZXIyLCBQb3dlcjMsIFBvd2VyNCwgTGluZWFyLCBRdWFkLCBDdWJpYywgUXVhcnQsIFF1aW50LCBTdHJvbmcsIEVsYXN0aWMsIEJhY2ssIFN0ZXBwZWRFYXNlLCBCb3VuY2UsIFNpbmUsIEV4cG8sIENpcmMgfTsiXSwibWFwcGluZ3MiOiI7QUFBQSxTQUFTLHVCQUF1QixNQUFNO0NBQUUsSUFBSSxTQUFTLEtBQUssR0FBSyxNQUFNLElBQUksZUFBZSwyREFBMkQ7Q0FBSyxPQUFPO0FBQU07QUFFckssU0FBUyxlQUFlLFVBQVUsWUFBWTtDQUFFLFNBQVMsWUFBWSxPQUFPLE9BQU8sV0FBVyxTQUFTO0NBQUcsU0FBUyxVQUFVLGNBQWM7Q0FBVSxTQUFTLFlBQVk7QUFBWTs7Ozs7Ozs7O0FBWXRMLElBQUksVUFBVTtDQUNaLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsZ0JBQWdCO0NBQ2hCLE9BQU8sRUFDTCxZQUFZLEdBQ2Q7QUFDRjtJQUNJLFlBQVk7Q0FDZCxVQUFVO0NBQ1YsV0FBVztDQUNYLE9BQU87QUFDVDtJQUNJO0lBQ0FBO0lBQ0E7SUFDQUMsWUFBVTtJQUNWLFdBQVcsSUFBSUE7SUFDZixPQUFPLEtBQUssS0FBSztJQUNqQixXQUFXLE9BQU87SUFDbEIsUUFBUTtJQUNSLFFBQVEsS0FBSztJQUNiLE9BQU8sS0FBSztJQUNaLE9BQU8sS0FBSztJQUNaLFlBQVksU0FBUyxVQUFVLE9BQU87Q0FDeEMsT0FBTyxPQUFPLFVBQVU7QUFDMUI7SUFDSSxjQUFjLFNBQVMsWUFBWSxPQUFPO0NBQzVDLE9BQU8sT0FBTyxVQUFVO0FBQzFCO0lBQ0ksWUFBWSxTQUFTLFVBQVUsT0FBTztDQUN4QyxPQUFPLE9BQU8sVUFBVTtBQUMxQjtJQUNJLGVBQWUsU0FBUyxhQUFhLE9BQU87Q0FDOUMsT0FBTyxPQUFPLFVBQVU7QUFDMUI7SUFDSSxZQUFZLFNBQVMsVUFBVSxPQUFPO0NBQ3hDLE9BQU8sT0FBTyxVQUFVO0FBQzFCO0lBQ0ksY0FBYyxTQUFTLFlBQVksT0FBTztDQUM1QyxPQUFPLFVBQVU7QUFDbkI7SUFDSUMsa0JBQWdCLFNBQVMsZ0JBQWdCO0NBQzNDLE9BQU8sT0FBTyxXQUFXO0FBQzNCO0lBQ0ksa0JBQWtCLFNBQVMsZ0JBQWdCLE9BQU87Q0FDcEQsT0FBTyxZQUFZLEtBQUssS0FBSyxVQUFVLEtBQUs7QUFDOUM7SUFDSSxnQkFBZ0IsT0FBTyxnQkFBZ0IsY0FBYyxZQUFZLFVBQVUsV0FBWSxDQUFDO0lBRTVGLFdBQVcsTUFBTTtJQUNiLGFBQWE7SUFDYixpQkFBaUI7SUFDakIsZ0JBQWdCO0lBRXBCLFVBQVU7SUFFVixrQkFBa0I7SUFDZCx1QkFBdUI7SUFFM0IsVUFBVTtJQUNOLHFCQUFxQjtJQUV6QixXQUFXO0lBQ1A7SUFDQUM7SUFDQTtJQUNBQztJQUNBLFdBQVcsQ0FBQztJQUNaLGdCQUFnQixDQUFDO0lBQ2pCO0lBQ0EsV0FBVyxTQUFTLFNBQVMsT0FBTztDQUN0QyxRQUFRLGdCQUFnQixPQUFPLE9BQU8sUUFBUSxNQUFNO0FBQ3REO0lBQ0ksaUJBQWlCLFNBQVMsZUFBZSxVQUFVLE9BQU87Q0FDNUQsT0FBTyxRQUFRLEtBQUssb0JBQW9CLFVBQVUsVUFBVSxPQUFPLHVDQUF1QztBQUM1RztJQUNJLFFBQVEsU0FBUyxNQUFNLFNBQVMsVUFBVTtDQUM1QyxPQUFPLENBQUMsWUFBWSxRQUFRLEtBQUssT0FBTztBQUMxQztJQUNJLGFBQWEsU0FBUyxXQUFXLE1BQU0sS0FBSztDQUM5QyxPQUFPLFNBQVMsU0FBUyxRQUFRLFFBQVEsa0JBQWtCLGNBQWMsUUFBUSxRQUFRO0FBQzNGO0lBQ0ksYUFBYSxTQUFTLGFBQWE7Q0FDckMsT0FBTztBQUNUO0lBQ0ksdUJBQXVCO0NBQ3pCLGdCQUFnQjtDQUNoQixTQUFTO0NBQ1QsTUFBTTtBQUNSO0lBQ0ksc0JBQXNCO0NBQ3hCLGdCQUFnQjtDQUNoQixNQUFNO0FBQ1I7SUFDSSxnQkFBZ0IsRUFDbEIsZ0JBQWdCLEtBQ2xCO0lBQ0ksaUJBQWlCLENBQUM7SUFDbEIsY0FBYyxDQUFDO0lBQ2YsY0FBYyxDQUFDO0lBQ2Y7SUFDQSxXQUFXLENBQUM7SUFDWixXQUFXLENBQUM7SUFDWixlQUFlO0lBQ2Ysa0JBQWtCLENBQUM7SUFDbkIsaUJBQWlCO0lBQ2pCLFdBQVcsU0FBUyxTQUFTLFNBQVM7Q0FDeEMsSUFBSSxTQUFTLFFBQVEsSUFDakIsZUFDQTtDQUNKLFVBQVUsTUFBTSxLQUFLLFlBQVksTUFBTSxNQUFNLFVBQVUsQ0FBQyxPQUFPO0NBRS9ELElBQUksRUFBRSxpQkFBaUIsT0FBTyxTQUFTLENBQUMsRUFBQSxDQUFHLFVBQVU7RUFFbkQsSUFBSSxnQkFBZ0I7RUFFcEIsT0FBTyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxXQUFXLE1BQU07RUFFbkQsZ0JBQWdCLGdCQUFnQjtDQUNsQztDQUVBLElBQUksUUFBUTtDQUVaLE9BQU8sS0FDTCxRQUFRLE9BQU8sUUFBUSxFQUFFLENBQUMsVUFBVSxRQUFRLEVBQUUsQ0FBQyxRQUFRLElBQUksUUFBUSxRQUFRLElBQUksYUFBYSxPQUFPLFFBQVEsT0FBTyxHQUFHLENBQUM7Q0FHeEgsT0FBTztBQUNUO0lBQ0ksWUFBWSxTQUFTLFVBQVUsUUFBUTtDQUN6QyxPQUFPLE9BQU8sU0FBUyxTQUFTLFFBQVEsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDdEQ7SUFDSSxlQUFlLFNBQVMsYUFBYSxRQUFRLFVBQVUsR0FBRztDQUM1RCxRQUFRLElBQUksT0FBTyxjQUFjLFlBQVksQ0FBQyxJQUFJLE9BQU8sU0FBUyxDQUFDLElBQUksYUFBYSxDQUFDLEtBQUssT0FBTyxnQkFBZ0IsT0FBTyxhQUFhLFFBQVEsS0FBSztBQUNwSjtJQUNJLGVBQWUsU0FBUyxhQUFhLE9BQU8sTUFBTTtDQUNwRCxRQUFRLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBQSxDQUFHLFFBQVEsSUFBSSxLQUFLO0FBQ3JEO0lBRUEsU0FBUyxTQUFTLE9BQU8sT0FBTztDQUM5QixPQUFPLEtBQUssTUFBTSxRQUFRLEdBQU0sSUFBSSxPQUFVO0FBQ2hEO0lBQ0ksZ0JBQWdCLFNBQVMsY0FBYyxPQUFPO0NBQ2hELE9BQU8sS0FBSyxNQUFNLFFBQVEsR0FBUSxJQUFJLE9BQVk7QUFDcEQ7SUFFQSxpQkFBaUIsU0FBUyxlQUFlLE9BQU8sT0FBTztDQUNyRCxJQUFJLFdBQVcsTUFBTSxPQUFPLENBQUMsR0FDekIsTUFBTSxXQUFXLE1BQU0sT0FBTyxDQUFDLENBQUM7Q0FDcEMsUUFBUSxXQUFXLEtBQUs7Q0FDeEIsT0FBTyxhQUFhLE1BQU0sUUFBUSxNQUFNLGFBQWEsTUFBTSxRQUFRLE1BQU0sYUFBYSxNQUFNLFFBQVEsTUFBTSxRQUFRO0FBQ3BIO0lBQ0ksb0JBQW9CLFNBQVMsa0JBQWtCLFVBQVUsUUFBUTtDQUVuRSxJQUFJLElBQUksT0FBTyxRQUNYLElBQUk7Q0FFUixPQUFPLFNBQVMsUUFBUSxPQUFPLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFBSTtDQUVoRCxPQUFPLElBQUk7QUFDYjtJQUNJLGNBQWMsU0FBUyxjQUFjO0NBQ3ZDLElBQUksSUFBSSxZQUFZLFFBQ2hCLElBQUksWUFBWSxNQUFNLENBQUMsR0FDdkIsR0FDQTtDQUVKLGNBQWMsQ0FBQztDQUNmLFlBQVksU0FBUztDQUVyQixLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztFQUN0QixRQUFRLEVBQUU7RUFDVixTQUFTLE1BQU0sVUFBVSxNQUFNLE9BQU8sTUFBTSxNQUFNLElBQUksTUFBTSxNQUFNLElBQUksSUFBSSxDQUFDLENBQUMsUUFBUTtDQUN0RjtBQUNGO0lBQ0ksa0JBQWtCLFNBQVMsZ0JBQWdCLFdBQVc7Q0FDeEQsT0FBTyxDQUFDLEVBQUUsVUFBVSxZQUFZLFVBQVUsWUFBWSxVQUFVO0FBQ2xFO0lBQ0ksa0JBQWtCLFNBQVMsZ0JBQWdCLFdBQVcsTUFBTSxnQkFBZ0IsT0FBTztDQUNyRixZQUFZLFVBQVUsQ0FBQ0osZ0JBQWMsWUFBWTtDQUNqRCxVQUFVLE9BQU8sTUFBTSxnQkFBZ0IsU0FBUyxDQUFDLEVBQUVBLGdCQUFjLE9BQU8sS0FBSyxnQkFBZ0IsU0FBUyxFQUFFO0NBQ3hHLFlBQVksVUFBVSxDQUFDQSxnQkFBYyxZQUFZO0FBQ25EO0lBQ0kscUJBQXFCLFNBQVMsbUJBQW1CLE9BQU87Q0FDMUQsSUFBSSxJQUFJLFdBQVcsS0FBSztDQUN4QixRQUFRLEtBQUssTUFBTSxPQUFPLFFBQVEsR0FBQSxDQUFJLE1BQU0sa0JBQWtCLENBQUMsQ0FBQyxTQUFTLElBQUksSUFBSSxVQUFVLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUNySDtJQUNJLGVBQWUsU0FBUyxhQUFhLEdBQUc7Q0FDMUMsT0FBTztBQUNUO0lBQ0ksZUFBZSxTQUFTLGFBQWEsS0FBSyxVQUFVO0NBQ3RELEtBQUssSUFBSSxLQUFLLFVBQ1osS0FBSyxRQUFRLElBQUksS0FBSyxTQUFTO0NBR2pDLE9BQU87QUFDVDtJQUNJLHVCQUF1QixTQUFTLHFCQUFxQixpQkFBaUI7Q0FDeEUsT0FBTyxTQUFVLEtBQUssVUFBVTtFQUM5QixLQUFLLElBQUksS0FBSyxVQUNaLEtBQUssT0FBTyxNQUFNLGNBQWMsbUJBQW1CLE1BQU0sV0FBVyxJQUFJLEtBQUssU0FBUztDQUUxRjtBQUNGO0lBQ0ksU0FBUyxTQUFTLE9BQU8sTUFBTSxTQUFTO0NBQzFDLEtBQUssSUFBSSxLQUFLLFNBQ1osS0FBSyxLQUFLLFFBQVE7Q0FHcEIsT0FBTztBQUNUO0lBQ0ksYUFBYSxTQUFTLFdBQVcsTUFBTSxTQUFTO0NBQ2xELEtBQUssSUFBSSxLQUFLLFNBQ1osTUFBTSxlQUFlLE1BQU0saUJBQWlCLE1BQU0sZ0JBQWdCLEtBQUssS0FBSyxVQUFVLFFBQVEsRUFBRSxJQUFJLFdBQVcsS0FBSyxPQUFPLEtBQUssS0FBSyxDQUFDLElBQUksUUFBUSxFQUFFLElBQUksUUFBUTtDQUdsSyxPQUFPO0FBQ1Q7SUFDSSxpQkFBaUIsU0FBUyxlQUFlLEtBQUssV0FBVztDQUMzRCxJQUFJLE9BQU8sQ0FBQyxHQUNSO0NBRUosS0FBSyxLQUFLLEtBQ1IsS0FBSyxjQUFjLEtBQUssS0FBSyxJQUFJO0NBR25DLE9BQU87QUFDVDtJQUNJLG1CQUFtQixTQUFTLGlCQUFpQixNQUFNO0NBQ3JELElBQUksU0FBUyxLQUFLLFVBQVUsaUJBQ3hCLE9BQU8sS0FBSyxZQUFZLHFCQUFxQixTQUFTLEtBQUssU0FBUyxDQUFDLElBQUk7Q0FFN0UsSUFBSSxZQUFZLEtBQUssT0FBTyxHQUMxQixPQUFPLFFBQVE7RUFDYixLQUFLLE1BQU0sT0FBTyxLQUFLLFFBQVE7RUFDL0IsU0FBUyxPQUFPLFVBQVUsT0FBTztDQUNuQztDQUdGLE9BQU87QUFDVDtJQUNJLGVBQWUsU0FBUyxhQUFhLElBQUksSUFBSTtDQUMvQyxJQUFJLElBQUksR0FBRyxRQUNQLFFBQVEsTUFBTSxHQUFHO0NBRXJCLE9BQU8sU0FBUyxPQUFPLEdBQUcsT0FBTyxHQUFHO0NBRXBDLE9BQU8sSUFBSTtBQUNiO0lBQ0kscUJBQXFCLFNBQVMsbUJBQW1CLFFBQVEsT0FBTyxXQUFXLFVBQVUsUUFBUTtDQUMvRixJQUFJLGNBQWMsS0FBSyxHQUNyQixZQUFZO0NBR2QsSUFBSSxhQUFhLEtBQUssR0FDcEIsV0FBVztDQUdiLElBQUksT0FBTyxPQUFPLFdBQ2Q7Q0FFSixJQUFJLFFBQVE7RUFDVixJQUFJLE1BQU07RUFFVixPQUFPLFFBQVEsS0FBSyxVQUFVLEdBQzVCLE9BQU8sS0FBSztDQUVoQjtDQUVBLElBQUksTUFBTTtFQUNSLE1BQU0sUUFBUSxLQUFLO0VBQ25CLEtBQUssUUFBUTtDQUNmLE9BQU87RUFDTCxNQUFNLFFBQVEsT0FBTztFQUNyQixPQUFPLGFBQWE7Q0FDdEI7Q0FFQSxJQUFJLE1BQU0sT0FDUixNQUFNLE1BQU0sUUFBUTtNQUVwQixPQUFPLFlBQVk7Q0FHckIsTUFBTSxRQUFRO0NBQ2QsTUFBTSxTQUFTLE1BQU0sTUFBTTtDQUMzQixPQUFPO0FBQ1Q7SUFDSSx3QkFBd0IsU0FBUyxzQkFBc0IsUUFBUSxPQUFPLFdBQVcsVUFBVTtDQUM3RixJQUFJLGNBQWMsS0FBSyxHQUNyQixZQUFZO0NBR2QsSUFBSSxhQUFhLEtBQUssR0FDcEIsV0FBVztDQUdiLElBQUksT0FBTyxNQUFNLE9BQ2IsT0FBTyxNQUFNO0NBRWpCLElBQUksTUFDRixLQUFLLFFBQVE7TUFDUixJQUFJLE9BQU8sZUFBZSxPQUMvQixPQUFPLGFBQWE7Q0FHdEIsSUFBSSxNQUNGLEtBQUssUUFBUTtNQUNSLElBQUksT0FBTyxjQUFjLE9BQzlCLE9BQU8sWUFBWTtDQUdyQixNQUFNLFFBQVEsTUFBTSxRQUFRLE1BQU0sU0FBUztBQUM3QztJQUNJLG9CQUFvQixTQUFTLGtCQUFrQixPQUFPLDJCQUEyQjtDQUNuRixNQUFNLFdBQVcsQ0FBQyw2QkFBNkIsTUFBTSxPQUFPLHVCQUF1QixNQUFNLE9BQU8sVUFBVSxNQUFNLE9BQU8sT0FBTyxLQUFLO0NBQ25JLE1BQU0sT0FBTztBQUNmO0lBQ0ksV0FBVyxTQUFTLFNBQVMsV0FBVyxPQUFPO0NBQ2pELElBQUksY0FBYyxDQUFDLFNBQVMsTUFBTSxPQUFPLFVBQVUsUUFBUSxNQUFNLFNBQVMsSUFBSTtFQUU1RSxJQUFJLElBQUk7RUFFUixPQUFPLEdBQUc7R0FDUixFQUFFLFNBQVM7R0FDWCxJQUFJLEVBQUU7RUFDUjtDQUNGO0NBRUEsT0FBTztBQUNUO0lBQ0ksb0JBQW9CLFNBQVMsa0JBQWtCLFdBQVc7Q0FDNUQsSUFBSSxTQUFTLFVBQVU7Q0FFdkIsT0FBTyxVQUFVLE9BQU8sUUFBUTtFQUU5QixPQUFPLFNBQVM7RUFDaEIsT0FBTyxjQUFjO0VBQ3JCLFNBQVMsT0FBTztDQUNsQjtDQUVBLE9BQU87QUFDVDtJQUNJLGlCQUFpQixTQUFTLGVBQWUsT0FBTyxXQUFXLGdCQUFnQixPQUFPO0NBQ3BGLE9BQU8sTUFBTSxhQUFhQSxlQUFhLE1BQU0sU0FBUyxPQUFPLG1CQUFtQixJQUFJLE1BQU0sS0FBSyxtQkFBbUIsQ0FBQyxNQUFNLEtBQUssY0FBYyxNQUFNLFNBQVMsT0FBTyxXQUFXLE1BQU0sS0FBSztBQUMxTDtJQUNJLHdCQUF3QixTQUFTLHNCQUFzQixXQUFXO0NBQ3BFLE9BQU8sQ0FBQyxhQUFhLFVBQVUsT0FBTyxzQkFBc0IsVUFBVSxNQUFNO0FBQzlFO0lBQ0ksd0JBQXdCLFNBQVMsc0JBQXNCLFdBQVc7Q0FDcEUsT0FBTyxVQUFVLFVBQVUsZ0JBQWdCLFVBQVUsUUFBUSxZQUFZLFVBQVUsU0FBUyxJQUFJLFVBQVUsT0FBTyxJQUFJLFlBQVk7QUFDbkk7SUFFQSxrQkFBa0IsU0FBUyxnQkFBZ0IsT0FBTyxlQUFlO0NBQy9ELElBQUksUUFBUSxLQUFLLE1BQU0sUUFBUSxjQUFjLFFBQVEsYUFBYSxDQUFDO0NBQ25FLE9BQU8sU0FBUyxVQUFVLFFBQVEsUUFBUSxJQUFJO0FBQ2hEO0lBQ0ksMEJBQTBCLFNBQVMsd0JBQXdCLFlBQVksT0FBTztDQUNoRixRQUFRLGFBQWEsTUFBTSxVQUFVLE1BQU0sT0FBTyxNQUFNLE9BQU8sSUFBSSxJQUFJLE1BQU0sU0FBUyxNQUFNLGNBQWMsSUFBSSxNQUFNO0FBQ3RIO0lBQ0ksVUFBVSxTQUFTLFFBQVEsV0FBVztDQUN4QyxPQUFPLFVBQVUsT0FBTyxjQUFjLFVBQVUsVUFBVSxVQUFVLFFBQVEsS0FBSyxJQUFJLFVBQVUsT0FBTyxVQUFVLFFBQVEsUUFBUSxLQUFLLEVBQUU7QUFDekk7SUFDSSxpQkFBaUIsU0FBUyxlQUFlLFdBQVcsV0FBVztDQUVqRSxJQUFJLFNBQVMsVUFBVTtDQUV2QixJQUFJLFVBQVUsT0FBTyxxQkFBcUIsVUFBVSxLQUFLO0VBQ3ZELFVBQVUsU0FBUyxjQUFjLE9BQU8sU0FBUyxVQUFVLE1BQU0sSUFBSSxZQUFZLFVBQVUsUUFBUSxVQUFVLFNBQVMsVUFBVSxjQUFjLElBQUksVUFBVSxTQUFTLGFBQWEsQ0FBQyxVQUFVLElBQUk7RUFFak0sUUFBUSxTQUFTO0VBRWpCLE9BQU8sVUFBVSxTQUFTLFFBQVEsU0FBUztDQUM3QztDQUVBLE9BQU87QUFDVDtJQVlBLGlCQUFpQixTQUFTLGVBQWUsVUFBVSxPQUFPO0NBQ3hELElBQUk7Q0FFSixJQUFJLE1BQU0sU0FBUyxDQUFDLE1BQU0sUUFBUSxNQUFNLFlBQVksTUFBTSxTQUFTLFNBQVMsVUFBVSxNQUFNLFFBQVEsQ0FBQyxNQUFNLE1BQU07RUFFL0csSUFBSSx3QkFBd0IsU0FBUyxRQUFRLEdBQUcsS0FBSztFQUVyRCxJQUFJLENBQUMsTUFBTSxRQUFRLE9BQU8sR0FBRyxNQUFNLGNBQWMsR0FBRyxDQUFDLElBQUksTUFBTSxTQUFTLFVBQ3RFLE1BQU0sT0FBTyxHQUFHLElBQUk7Q0FFeEI7Q0FHQSxJQUFJLFNBQVMsVUFBVSxLQUFLLENBQUMsQ0FBQyxPQUFPLFNBQVMsWUFBWSxTQUFTLFNBQVMsU0FBUyxRQUFRLFNBQVMsS0FBSztFQUV6RyxJQUFJLFNBQVMsT0FBTyxTQUFTLFNBQVMsR0FBRztHQUN2QyxJQUFJO0dBRUosT0FBTyxFQUFFLEtBQUs7SUFDWixFQUFFLFFBQVEsS0FBSyxLQUFLLEVBQUUsVUFBVSxFQUFFLE1BQU07SUFFeEMsSUFBSSxFQUFFO0dBQ1I7RUFDRjtFQUVBLFNBQVMsU0FBUyxDQUFDO0NBQ3JCO0FBQ0Y7SUFDSSxpQkFBaUIsU0FBUyxlQUFlLFVBQVUsT0FBTyxVQUFVLFlBQVk7Q0FDbEYsTUFBTSxVQUFVLGtCQUFrQixLQUFLO0NBQ3ZDLE1BQU0sU0FBUyxlQUFlLFVBQVUsUUFBUSxJQUFJLFdBQVcsWUFBWSxhQUFhLGtCQUFrQixlQUFlLFVBQVUsVUFBVSxLQUFLLElBQUksU0FBUyxTQUFTLE1BQU0sTUFBTTtDQUNwTCxNQUFNLE9BQU8sY0FBYyxNQUFNLFVBQVUsTUFBTSxjQUFjLElBQUksS0FBSyxJQUFJLE1BQU0sVUFBVSxDQUFDLEtBQUssRUFBRTtDQUVwRyxtQkFBbUIsVUFBVSxPQUFPLFVBQVUsU0FBUyxTQUFTLFFBQVEsV0FBVyxDQUFDO0NBRXBGLG1CQUFtQixLQUFLLE1BQU0sU0FBUyxVQUFVO0NBQ2pELGNBQWMsZUFBZSxVQUFVLEtBQUs7Q0FDNUMsU0FBUyxNQUFNLEtBQUssZUFBZSxVQUFVLFNBQVMsTUFBTTtDQUU1RCxPQUFPO0FBQ1Q7SUFDSSxpQkFBaUIsU0FBUyxlQUFlLFdBQVcsU0FBUztDQUMvRCxRQUFRLFNBQVMsaUJBQWlCLGVBQWUsaUJBQWlCLE9BQU8sTUFBTSxTQUFTLGNBQWMsT0FBTyxTQUFTLFNBQVM7QUFDakk7SUFDSSxvQkFBb0IsU0FBUyxrQkFBa0IsT0FBTyxNQUFNLE9BQU8sZ0JBQWdCLE9BQU87Q0FDNUYsV0FBVyxPQUFPLE1BQU0sS0FBSztDQUU3QixJQUFJLENBQUMsTUFBTSxVQUNULE9BQU87Q0FHVCxJQUFJLENBQUMsU0FBUyxNQUFNLE9BQU8sQ0FBQ0EsaUJBQWUsTUFBTSxRQUFRLE1BQU0sS0FBSyxTQUFTLFNBQVMsQ0FBQyxNQUFNLFFBQVEsTUFBTSxLQUFLLFNBQVMsdUJBQXVCLFFBQVEsT0FBTztFQUM3SixZQUFZLEtBQUssS0FBSztFQUV0QixNQUFNLFFBQVEsQ0FBQyxPQUFPLGNBQWM7RUFDcEMsT0FBTztDQUNUO0FBQ0Y7SUFDSSwrQkFBK0IsU0FBUyw2QkFBNkIsTUFBTTtDQUM3RSxJQUFJLFNBQVMsS0FBSztDQUNsQixPQUFPLFVBQVUsT0FBTyxPQUFPLE9BQU8sWUFBWSxDQUFDLE9BQU8sVUFBVSxPQUFPLFFBQVEsSUFBSSxLQUFLLDZCQUE2QixNQUFNO0FBQ2pJO0lBRUEscUJBQXFCLFNBQVMsbUJBQW1CLE9BQU87Q0FDdEQsSUFBSSxPQUFPLE1BQU07Q0FDakIsT0FBTyxTQUFTLGlCQUFpQixTQUFTO0FBQzVDO0lBQ0ksMkJBQTJCLFNBQVMseUJBQXlCLE9BQU8sV0FBVyxnQkFBZ0IsT0FBTztDQUN4RyxJQUFJLFlBQVksTUFBTSxPQUNsQixRQUFRLFlBQVksS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUFNLFVBQVUsNkJBQTZCLEtBQUssS0FBSyxFQUFFLENBQUMsTUFBTSxZQUFZLG1CQUFtQixLQUFLLE9BQU8sTUFBTSxNQUFNLEtBQUssTUFBTSxJQUFJLE1BQU0sTUFBTSxDQUFDLG1CQUFtQixLQUFLLEtBQUssSUFBSSxHQUVqTyxjQUFjLE1BQU0sU0FDaEIsUUFBUSxHQUNSLElBQ0EsV0FDQTtDQUVKLElBQUksZUFBZSxNQUFNLFNBQVM7RUFFaEMsUUFBUSxPQUFPLEdBQUcsTUFBTSxPQUFPLFNBQVM7RUFDeEMsWUFBWSxnQkFBZ0IsT0FBTyxXQUFXO0VBQzlDLE1BQU0sU0FBUyxZQUFZLE1BQU0sUUFBUSxJQUFJO0VBRTdDLElBQUksY0FBYyxnQkFBZ0IsTUFBTSxRQUFRLFdBQVcsR0FBRztHQUU1RCxZQUFZLElBQUk7R0FDaEIsTUFBTSxLQUFLLGlCQUFpQixNQUFNLFlBQVksTUFBTSxXQUFXO0VBQ2pFO0NBQ0Y7Q0FFQSxJQUFJLFVBQVUsYUFBYUEsZ0JBQWMsU0FBUyxNQUFNLFdBQVcsWUFBWSxDQUFDLGFBQWEsTUFBTSxRQUFRO0VBQ3pHLElBQUksQ0FBQyxNQUFNLFlBQVksa0JBQWtCLE9BQU8sV0FBVyxPQUFPLGdCQUFnQixLQUFLLEdBRXJGO0VBR0YsZ0JBQWdCLE1BQU07RUFDdEIsTUFBTSxTQUFTLGNBQWMsaUJBQWlCLFdBQVc7RUFFekQsbUJBQW1CLGlCQUFpQixhQUFhLENBQUM7RUFFbEQsTUFBTSxRQUFRO0VBQ2QsTUFBTSxVQUFVLFFBQVEsSUFBSTtFQUM1QixNQUFNLFFBQVE7RUFDZCxNQUFNLFNBQVM7RUFDZixLQUFLLE1BQU07RUFFWCxPQUFPLElBQUk7R0FDVCxHQUFHLEVBQUUsT0FBTyxHQUFHLENBQUM7R0FDaEIsS0FBSyxHQUFHO0VBQ1Y7RUFFQSxZQUFZLEtBQUssZUFBZSxPQUFPLFdBQVcsZ0JBQWdCLElBQUk7RUFDdEUsTUFBTSxhQUFhLENBQUMsa0JBQWtCLFVBQVUsT0FBTyxVQUFVO0VBQ2pFLFNBQVMsTUFBTSxXQUFXLENBQUMsa0JBQWtCLE1BQU0sVUFBVSxVQUFVLE9BQU8sVUFBVTtFQUV4RixLQUFLLGFBQWEsTUFBTSxTQUFTLFlBQVksTUFBTSxNQUFNLFVBQVUsT0FBTztHQUN4RSxTQUFTLGtCQUFrQixPQUFPLENBQUM7R0FFbkMsSUFBSSxDQUFDLGtCQUFrQixDQUFDQSxjQUFZO0lBQ2xDLFVBQVUsT0FBTyxRQUFRLGVBQWUscUJBQXFCLElBQUk7SUFFakUsTUFBTSxTQUFTLE1BQU0sTUFBTTtHQUM3QjtFQUNGO0NBQ0YsT0FBTyxJQUFJLENBQUMsTUFBTSxRQUNoQixNQUFNLFNBQVM7QUFFbkI7SUFDSSxzQkFBc0IsU0FBUyxvQkFBb0IsV0FBVyxVQUFVLE1BQU07Q0FDaEYsSUFBSTtDQUVKLElBQUksT0FBTyxVQUFVO0VBQ25CLFFBQVEsVUFBVTtFQUVsQixPQUFPLFNBQVMsTUFBTSxVQUFVLE1BQU07R0FDcEMsSUFBSSxNQUFNLFNBQVMsYUFBYSxNQUFNLFNBQVMsVUFDN0MsT0FBTztHQUdULFFBQVEsTUFBTTtFQUNoQjtDQUNGLE9BQU87RUFDTCxRQUFRLFVBQVU7RUFFbEIsT0FBTyxTQUFTLE1BQU0sVUFBVSxNQUFNO0dBQ3BDLElBQUksTUFBTSxTQUFTLGFBQWEsTUFBTSxTQUFTLFVBQzdDLE9BQU87R0FHVCxRQUFRLE1BQU07RUFDaEI7Q0FDRjtBQUNGO0lBQ0ksZUFBZSxTQUFTLGFBQWEsV0FBVyxVQUFVLGFBQWEsZUFBZTtDQUN4RixJQUFJLFNBQVMsVUFBVSxTQUNuQixNQUFNLGNBQWMsUUFBUSxLQUFLLEdBQ2pDLGdCQUFnQixVQUFVLFNBQVMsVUFBVTtDQUNqRCxpQkFBaUIsQ0FBQyxrQkFBa0IsVUFBVSxTQUFTLE1BQU0sVUFBVTtDQUN2RSxVQUFVLE9BQU87Q0FDakIsVUFBVSxRQUFRLENBQUMsU0FBUyxNQUFNLFNBQVMsSUFBSSxPQUFPLGNBQWMsT0FBTyxTQUFTLEtBQUssVUFBVSxVQUFVLE1BQU07Q0FDbkgsZ0JBQWdCLEtBQUssQ0FBQyxpQkFBaUIsZUFBZSxXQUFXLFVBQVUsU0FBUyxVQUFVLFFBQVEsYUFBYTtDQUNuSCxVQUFVLFVBQVUsUUFBUSxTQUFTO0NBQ3JDLGVBQWUsU0FBUyxVQUFVLFFBQVEsU0FBUztDQUNuRCxPQUFPO0FBQ1Q7SUFDSSx5QkFBeUIsU0FBUyx1QkFBdUIsV0FBVztDQUN0RSxPQUFPLHFCQUFxQixXQUFXLFNBQVMsU0FBUyxJQUFJLGFBQWEsV0FBVyxVQUFVLElBQUk7QUFDckc7SUFDSSxnQkFBZ0I7Q0FDbEIsUUFBUTtDQUNSLFNBQVM7Q0FDVCxlQUFlO0FBQ2pCO0lBQ0ksaUJBQWlCLFNBQVMsZUFBZSxXQUFXLFVBQVUsa0JBQWtCO0NBQ2xGLElBQUksU0FBUyxVQUFVLFFBQ25CLFNBQVMsVUFBVSxXQUFXLGVBQzlCLGtCQUFrQixVQUFVLFNBQVMsS0FBS0MsWUFBVSxPQUFPLFFBQVEsS0FBSyxJQUFJLFVBQVUsTUFFMUYsR0FDSSxRQUNBO0NBRUosSUFBSSxVQUFVLFFBQVEsTUFBTSxNQUFNLFFBQVEsS0FBSyxZQUFZLFNBQVM7RUFFbEUsU0FBUyxTQUFTLE9BQU8sQ0FBQztFQUMxQixZQUFZLFNBQVMsT0FBTyxFQUFFLE1BQU07RUFDcEMsSUFBSSxTQUFTLFFBQVEsR0FBRztFQUV4QixJQUFJLFdBQVcsT0FBTyxXQUFXLEtBQUs7R0FDcEMsS0FBSyxNQUFNLFdBQVcsU0FBUyxRQUFRLEtBQUssRUFBRTtHQUM5QyxRQUFRLFdBQVcsTUFBTSxPQUFPLFNBQVMsT0FBTyxRQUFRLE9BQU8sV0FBVyxDQUFDLE1BQU0sV0FBVyxTQUFTLE9BQU8sQ0FBQyxDQUFDLEtBQUssTUFBTSxhQUFhLElBQUksSUFBSSxTQUFTLGlCQUFBLENBQWtCLGNBQWMsSUFBSSxNQUFNO0VBQ25NO0VBRUEsSUFBSSxJQUFJLEdBQUc7R0FDVCxZQUFZLFdBQVcsT0FBTyxZQUFZO0dBQzFDLE9BQU8sT0FBTztFQUNoQjtFQUVBLFNBQVMsV0FBVyxTQUFTLE9BQU8sSUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLElBQUksQ0FBQyxDQUFDO0VBRW5FLElBQUksYUFBYSxrQkFDZixTQUFTLFNBQVMsT0FBTyxTQUFTLGdCQUFnQixJQUFJLGlCQUFpQixLQUFLLGlCQUFBLENBQWtCLGNBQWM7RUFHOUcsT0FBTyxJQUFJLElBQUksZUFBZSxXQUFXLFNBQVMsT0FBTyxHQUFHLElBQUksQ0FBQyxHQUFHLGdCQUFnQixJQUFJLFNBQVMsa0JBQWtCO0NBQ3JIO0NBRUEsT0FBTyxZQUFZLE9BQU8sa0JBQWtCLENBQUM7QUFDL0M7SUFDSSxtQkFBbUIsU0FBUyxpQkFBaUIsTUFBTSxRQUFRLFVBQVU7Q0FDdkUsSUFBSSxXQUFXLFVBQVUsT0FBTyxFQUFFLEdBQzlCLGFBQWEsV0FBVyxJQUFJLE1BQU0sT0FBTyxJQUFJLElBQUksSUFDakQsT0FBTyxPQUFPLFlBQ2QsUUFDQTtDQUVKLGFBQWEsS0FBSyxXQUFXLE9BQU87Q0FDcEMsS0FBSyxTQUFTO0NBRWQsSUFBSSxNQUFNO0VBQ1IsU0FBUztFQUNULFNBQVM7RUFFVCxPQUFPLFVBQVUsRUFBRSxxQkFBcUIsU0FBUztHQUUvQyxTQUFTLE9BQU8sS0FBSyxZQUFZLENBQUM7R0FDbEMsU0FBUyxZQUFZLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTztFQUN0RDtFQUVBLEtBQUssa0JBQWtCLFlBQVksT0FBTyxlQUFlO0VBQ3pELE9BQU8sSUFBSSxLQUFLLGVBQWUsSUFBSSxLQUFLLFVBQVUsT0FBTyxZQUFZO0NBQ3ZFO0NBRUEsT0FBTyxJQUFJLE1BQU0sT0FBTyxJQUFJLE1BQU0sT0FBTyxZQUFZLEVBQUU7QUFDekQ7SUFDSSxxQkFBcUIsU0FBUyxtQkFBbUIsT0FBTyxNQUFNO0NBQ2hFLE9BQU8sU0FBUyxVQUFVLElBQUksS0FBSyxLQUFLLElBQUk7QUFDOUM7SUFDSSxTQUFTLFNBQVMsT0FBTyxLQUFLLEtBQUssT0FBTztDQUM1QyxPQUFPLFFBQVEsTUFBTSxNQUFNLFFBQVEsTUFBTSxNQUFNO0FBQ2pEO0lBQ0ksVUFBVSxTQUFTLFFBQVEsT0FBTyxHQUFHO0NBQ3ZDLE9BQU8sQ0FBQyxVQUFVLEtBQUssS0FBSyxFQUFFLElBQUksU0FBUyxLQUFLLEtBQUssS0FBSyxLQUFLLEVBQUU7QUFDbkU7SUFFQSxRQUFRLFNBQVMsTUFBTSxLQUFLLEtBQUssT0FBTztDQUN0QyxPQUFPLG1CQUFtQixPQUFPLFNBQVUsR0FBRztFQUM1QyxPQUFPLE9BQU8sS0FBSyxLQUFLLENBQUM7Q0FDM0IsQ0FBQztBQUNIO0lBQ0ksU0FBUyxDQUFDLENBQUMsQ0FBQztJQUNaLGVBQWUsU0FBUyxhQUFhLE9BQU8sVUFBVTtDQUN4RCxPQUFPLFNBQVMsVUFBVSxLQUFLLEtBQUssWUFBWSxVQUFVLENBQUMsWUFBWSxDQUFDLE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxTQUFTLFVBQVUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLFlBQVksVUFBVUU7QUFDNUs7SUFDSSxXQUFXLFNBQVMsU0FBUyxJQUFJLGNBQWMsYUFBYTtDQUM5RCxJQUFJLGdCQUFnQixLQUFLLEdBQ3ZCLGNBQWMsQ0FBQztDQUdqQixPQUFPLEdBQUcsUUFBUSxTQUFVLE9BQU87RUFDakMsSUFBSTtFQUVKLE9BQU8sVUFBVSxLQUFLLEtBQUssQ0FBQyxnQkFBZ0IsYUFBYSxPQUFPLENBQUMsS0FBSyxlQUFlLFlBQUEsQ0FBYSxLQUFLLE1BQU0sY0FBYyxRQUFRLEtBQUssQ0FBQyxJQUFJLFlBQVksS0FBSyxLQUFLO0NBQ3JLLENBQUMsS0FBSztBQUNSO0lBRUEsVUFBVSxTQUFTLFFBQVEsT0FBTyxPQUFPLGNBQWM7Q0FDckQsT0FBTyxZQUFZLENBQUMsU0FBUyxTQUFTLFdBQVcsU0FBUyxTQUFTLEtBQUssSUFBSSxVQUFVLEtBQUssS0FBSyxDQUFDLGlCQUFpQixnQkFBZ0IsQ0FBQyxNQUFNLEtBQUssT0FBTyxNQUFNLFNBQVNDLE9BQUFBLENBQU0saUJBQWlCLEtBQUssR0FBRyxDQUFDLElBQUksU0FBUyxLQUFLLElBQUksU0FBUyxPQUFPLFlBQVksSUFBSSxhQUFhLEtBQUssSUFBSSxPQUFPLEtBQUssT0FBTyxDQUFDLElBQUksUUFBUSxDQUFDLEtBQUssSUFBSSxDQUFDO0FBQzdUO0lBQ0ksV0FBVyxTQUFTLFNBQVMsT0FBTztDQUN0QyxRQUFRLFFBQVEsS0FBSyxDQUFDLENBQUMsTUFBTSxNQUFNLGVBQWUsS0FBSyxDQUFDO0NBQ3hELE9BQU8sU0FBVSxHQUFHO0VBQ2xCLElBQUksS0FBSyxNQUFNLFdBQVcsTUFBTSxpQkFBaUI7RUFDakQsT0FBTyxRQUFRLEdBQUcsR0FBRyxtQkFBbUIsS0FBSyxPQUFPLFFBQVEsTUFBTSxlQUFlLEtBQUtBLE9BQUssY0FBYyxLQUFLLElBQUksS0FBSztDQUN6SDtBQUNGO0lBQ0ksVUFBVSxTQUFTLFFBQVEsR0FBRztDQUNoQyxPQUFPLEVBQUUsS0FBSyxXQUFZO0VBQ3hCLE9BQU8sS0FBSyxLQUFLLE9BQU87Q0FDMUIsQ0FBQztBQUNIO0lBR0EsYUFBYSxTQUFTLFdBQVcsR0FBRztDQUNsQyxJQUFJLFlBQVksQ0FBQyxHQUNmLE9BQU87Q0FHVCxJQUFJLE9BQU8sVUFBVSxDQUFDLElBQUksSUFBSSxFQUM1QixNQUFNLEVBQ1IsR0FFQSxPQUFPLFdBQVcsS0FBSyxJQUFJLEdBQ3ZCLE9BQU8sS0FBSyxRQUFRLEdBQ3BCLE9BQU8sV0FBVyxLQUFLLElBQUksS0FBSyxHQUNoQyxRQUFRLENBQUMsR0FDVCxZQUFZLE9BQU8sS0FBSyxPQUFPLEdBQy9CLFNBQVMsTUFBTSxJQUFJLEtBQUssV0FDeEIsT0FBTyxLQUFLLE1BQ1osU0FBUyxNQUNULFNBQVM7Q0FFYixJQUFJLFVBQVUsSUFBSSxHQUNoQixTQUFTLFNBQVM7RUFDaEIsUUFBUTtFQUNSLE9BQU87RUFDUCxLQUFLO0NBQ1AsRUFBRSxTQUFTO01BQ04sSUFBSSxDQUFDLGFBQWEsUUFBUTtFQUMvQixTQUFTLEtBQUs7RUFDZCxTQUFTLEtBQUs7Q0FDaEI7Q0FFQSxPQUFPLFNBQVUsR0FBRyxRQUFRLEdBQUc7RUFDN0IsSUFBSSxLQUFLLEtBQUssS0FBQSxDQUFNLFFBQ2hCLFlBQVksTUFBTSxJQUNsQixTQUNBLFNBQ0EsR0FDQSxHQUNBLEdBQ0EsR0FDQSxLQUNBLEtBQ0E7RUFFSixJQUFJLENBQUMsV0FBVztHQUNkLFNBQVMsS0FBSyxTQUFTLFNBQVMsS0FBSyxLQUFLLFFBQVEsQ0FBQyxHQUFHSCxTQUFPLEVBQUEsQ0FBRztHQUVoRSxJQUFJLENBQUMsUUFBUTtJQUNYLE1BQU0sQ0FBQ0E7SUFFUCxPQUFPLE9BQU8sTUFBTSxFQUFFLFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLFNBQVMsU0FBUztJQUUxRSxTQUFTLEtBQUs7R0FDaEI7R0FFQSxZQUFZLE1BQU0sS0FBSyxDQUFDO0dBQ3hCLFVBQVUsU0FBUyxLQUFLLElBQUksUUFBUSxDQUFDLElBQUksU0FBUyxLQUFLLE9BQU87R0FDOUQsVUFBVSxXQUFXQSxZQUFVLElBQUksU0FBUyxJQUFJLFNBQVMsU0FBUyxLQUFLLE9BQU8sU0FBUztHQUN2RixNQUFNO0dBQ04sTUFBTUE7R0FFTixLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztJQUN0QixJQUFJLElBQUksU0FBUztJQUNqQixJQUFJLFdBQVcsSUFBSSxTQUFTO0lBQzVCLFVBQVUsS0FBSyxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksU0FBUyxNQUFNLElBQUksQ0FBQztJQUMvRSxJQUFJLFFBQVEsTUFBTTtJQUNsQixJQUFJLFFBQVEsTUFBTTtHQUNwQjtHQUVBLFNBQVMsWUFBWSxRQUFRLFNBQVM7R0FDdEMsVUFBVSxNQUFNLE1BQU07R0FDdEIsVUFBVSxNQUFNO0dBQ2hCLFVBQVUsSUFBSSxLQUFLLFdBQVcsS0FBSyxNQUFNLEtBQUssV0FBVyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLElBQUksUUFBUSxJQUFJLE1BQU0sSUFBSSxTQUFTLE1BQU0sSUFBSSxTQUFTLFdBQVcsTUFBTSxTQUFTLFVBQVUsS0FBSztHQUN4TSxVQUFVLElBQUksSUFBSSxJQUFJLE9BQU8sSUFBSTtHQUNqQyxVQUFVLElBQUksUUFBUSxLQUFLLFVBQVUsS0FBSyxJQUFJLEtBQUs7R0FFbkQsT0FBTyxRQUFRLElBQUksSUFBSSxZQUFZLElBQUksSUFBSTtFQUM3QztFQUVBLEtBQUssVUFBVSxLQUFLLFVBQVUsT0FBTyxVQUFVLE9BQU87RUFDdEQsT0FBTyxjQUFjLFVBQVUsS0FBSyxPQUFPLEtBQUssQ0FBQyxJQUFJLEtBQUssVUFBVSxDQUFDLElBQUksVUFBVTtDQUNyRjtBQUNGO0lBQ0ksaUJBQWlCLFNBQVMsZUFBZSxHQUFHO0NBRTlDLElBQUksSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJLEdBQUEsQ0FBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBQSxDQUFJLE1BQU07Q0FFMUQsT0FBTyxTQUFVLEtBQUs7RUFDcEIsSUFBSSxJQUFJLGNBQWMsS0FBSyxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUM7RUFFN0QsUUFBUSxJQUFJLElBQUksS0FBSyxLQUFLLFVBQVUsR0FBRyxJQUFJLElBQUksUUFBUSxHQUFHO0NBQzVEO0FBQ0Y7SUFDSSxPQUFPLFNBQVMsS0FBSyxRQUFRLE9BQU87Q0FDdEMsSUFBSSxVQUFVLFNBQVMsTUFBTSxHQUN6QixRQUNBO0NBRUosSUFBSSxDQUFDLFdBQVcsVUFBVSxNQUFNLEdBQUc7RUFDakMsU0FBUyxVQUFVLE9BQU8sVUFBVUE7RUFFcEMsSUFBSSxPQUFPLFFBQVE7R0FDakIsU0FBUyxRQUFRLE9BQU8sTUFBTTtHQUU5QixJQUFJLE9BQU8sQ0FBQyxVQUFVLE9BQU8sRUFBRSxHQUM3QixVQUFVO0VBRWQsT0FDRSxTQUFTLGVBQWUsT0FBTyxTQUFTO0NBRTVDO0NBRUEsT0FBTyxtQkFBbUIsT0FBTyxDQUFDLFVBQVUsZUFBZSxNQUFNLElBQUksWUFBWSxNQUFNLElBQUksU0FBVSxLQUFLO0VBQ3hHLE9BQU8sT0FBTyxHQUFHO0VBQ2pCLE9BQU8sS0FBSyxJQUFJLE9BQU8sR0FBRyxLQUFLLFNBQVMsT0FBTztDQUNqRCxJQUFJLFNBQVUsS0FBSztFQUNqQixJQUFJLElBQUksV0FBVyxPQUFPLElBQUksSUFBSSxHQUFHLEdBQ2pDLElBQUksV0FBVyxPQUFPLElBQUksSUFBSSxDQUFDLEdBQy9CLE1BQU1BLFdBQ04sVUFBVSxHQUNWLElBQUksT0FBTyxRQUNYLElBQ0E7RUFFSixPQUFPLEtBQUs7R0FDVixJQUFJLE1BQU07SUFDUixLQUFLLE9BQU8sRUFBRSxDQUFDLElBQUk7SUFDbkIsS0FBSyxPQUFPLEVBQUUsQ0FBQyxJQUFJO0lBQ25CLEtBQUssS0FBSyxLQUFLLEtBQUs7R0FDdEIsT0FDRSxLQUFLLEtBQUssSUFBSSxPQUFPLEtBQUssQ0FBQztHQUc3QixJQUFJLEtBQUssS0FBSztJQUNaLE1BQU07SUFDTixVQUFVO0dBQ1o7RUFDRjtFQUVBLFVBQVUsQ0FBQyxVQUFVLE9BQU8sU0FBUyxPQUFPLFdBQVc7RUFDdkQsT0FBTyxRQUFRLFlBQVksT0FBTyxVQUFVLEdBQUcsSUFBSSxVQUFVLFVBQVUsUUFBUSxHQUFHO0NBQ3BGLENBQUM7QUFDSDtJQUNJLFNBQVMsU0FBUyxPQUFPLEtBQUssS0FBSyxtQkFBbUIsZ0JBQWdCO0NBQ3hFLE9BQU8sbUJBQW1CLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxzQkFBc0IsT0FBTyxDQUFDLEVBQUUsb0JBQW9CLEtBQUssQ0FBQyxnQkFBZ0IsV0FBWTtFQUNySSxPQUFPLFNBQVMsR0FBRyxJQUFJLElBQUksQ0FBQyxFQUFFLEtBQUssT0FBTyxJQUFJLElBQUksWUFBWSxvQkFBb0IscUJBQXFCLFVBQVUsaUJBQWlCLG9CQUFvQixJQUFJLEtBQUssSUFBSSxLQUFLLG9CQUFvQixHQUFBLENBQUksU0FBUyxDQUFDLElBQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPLE1BQU0sb0JBQW9CLElBQUksS0FBSyxPQUFPLEtBQUssTUFBTSxNQUFNLG9CQUFvQixRQUFRLGlCQUFpQixJQUFJLG9CQUFvQixjQUFjLElBQUk7Q0FDL1gsQ0FBQztBQUNIO0lBQ0ksT0FBTyxTQUFTLE9BQU87Q0FDekIsS0FBSyxJQUFJLE9BQU8sVUFBVSxRQUFRLFlBQVksSUFBSSxNQUFNLElBQUksR0FBRyxPQUFPLEdBQUcsT0FBTyxNQUFNLFFBQ3BGLFVBQVUsUUFBUSxVQUFVO0NBRzlCLE9BQU8sU0FBVSxPQUFPO0VBQ3RCLE9BQU8sVUFBVSxPQUFPLFNBQVUsR0FBRyxHQUFHO0dBQ3RDLE9BQU8sRUFBRSxDQUFDO0VBQ1osR0FBRyxLQUFLO0NBQ1Y7QUFDRjtJQUNJLFVBQVUsU0FBUyxRQUFRLE1BQU0sTUFBTTtDQUN6QyxPQUFPLFNBQVUsT0FBTztFQUN0QixPQUFPLEtBQUssV0FBVyxLQUFLLENBQUMsS0FBSyxRQUFRLFFBQVEsS0FBSztDQUN6RDtBQUNGO0lBQ0ksWUFBWSxTQUFTLFVBQVUsS0FBSyxLQUFLLE9BQU87Q0FDbEQsT0FBTyxTQUFTLEtBQUssS0FBSyxHQUFHLEdBQUcsS0FBSztBQUN2QztJQUNJLGFBQWEsU0FBUyxXQUFXLEdBQUcsU0FBUyxPQUFPO0NBQ3RELE9BQU8sbUJBQW1CLE9BQU8sU0FBVSxPQUFPO0VBQ2hELE9BQU8sRUFBRSxDQUFDLENBQUMsUUFBUSxLQUFLO0NBQzFCLENBQUM7QUFDSDtJQUNJLE9BQU8sU0FBUyxLQUFLLEtBQUssS0FBSyxPQUFPO0NBRXhDLElBQUksUUFBUSxNQUFNO0NBQ2xCLE9BQU8sU0FBUyxHQUFHLElBQUksV0FBVyxLQUFLLEtBQUssR0FBRyxJQUFJLE1BQU0sR0FBRyxHQUFHLElBQUksbUJBQW1CLE9BQU8sU0FBVSxPQUFPO0VBQzVHLFFBQVEsU0FBUyxRQUFRLE9BQU8sU0FBUyxRQUFRO0NBQ25ELENBQUM7QUFDSDtJQUNJLFdBQVcsU0FBUyxTQUFTLEtBQUssS0FBSyxPQUFPO0NBQ2hELElBQUksUUFBUSxNQUFNLEtBQ2QsUUFBUSxRQUFRO0NBQ3BCLE9BQU8sU0FBUyxHQUFHLElBQUksV0FBVyxLQUFLLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxtQkFBbUIsT0FBTyxTQUFVLE9BQU87RUFDcEgsU0FBUyxTQUFTLFFBQVEsT0FBTyxTQUFTLFNBQVM7RUFDbkQsT0FBTyxPQUFPLFFBQVEsUUFBUSxRQUFRLFFBQVE7Q0FDaEQsQ0FBQztBQUNIO0lBQ0ksaUJBQWlCLFNBQVMsZUFBZSxHQUFHO0NBQzlDLE9BQU8sRUFBRSxRQUFRLFlBQVksU0FBVSxPQUFPO0VBRTVDLElBQUksVUFBVSxNQUFNLFFBQVEsR0FBRyxJQUFJLEdBQy9CLFNBQVMsTUFBTSxVQUFVLFdBQVcsR0FBRyxVQUFVLE1BQU0sUUFBUSxHQUFHLElBQUksTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sY0FBYztFQUNoSCxPQUFPLE9BQU8sVUFBVSxTQUFTLENBQUMsT0FBTyxJQUFJLFVBQVUsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFJO0NBQzNGLENBQUM7QUFDSDtJQUNJLFdBQVcsU0FBUyxTQUFTLE9BQU8sT0FBTyxRQUFRLFFBQVEsT0FBTztDQUNwRSxJQUFJLFVBQVUsUUFBUSxPQUNsQixXQUFXLFNBQVM7Q0FDeEIsT0FBTyxtQkFBbUIsT0FBTyxTQUFVLE9BQU87RUFDaEQsT0FBTyxXQUFXLFFBQVEsU0FBUyxVQUFVLFlBQVk7Q0FDM0QsQ0FBQztBQUNIO0lBQ0ksY0FBYyxTQUFTLFlBQVksT0FBTyxLQUFLLFVBQVUsUUFBUTtDQUNuRSxJQUFJLE9BQU8sTUFBTSxRQUFRLEdBQUcsSUFBSSxJQUFJLFNBQVUsR0FBRztFQUMvQyxRQUFRLElBQUksS0FBSyxRQUFRLElBQUk7Q0FDL0I7Q0FFQSxJQUFJLENBQUMsTUFBTTtFQUNULElBQUksV0FBVyxVQUFVLEtBQUssR0FDMUIsU0FBUyxDQUFDLEdBQ1YsR0FDQSxHQUNBLGVBQ0EsR0FDQTtFQUVKLGFBQWEsU0FBUyxTQUFTLE9BQU8sV0FBVztFQUVqRCxJQUFJLFVBQVU7R0FDWixRQUFRLEVBQ04sR0FBRyxNQUNMO0dBQ0EsTUFBTSxFQUNKLEdBQUcsSUFDTDtFQUNGLE9BQU8sSUFBSSxTQUFTLEtBQUssS0FBSyxDQUFDLFNBQVMsR0FBRyxHQUFHO0dBQzVDLGdCQUFnQixDQUFDO0dBQ2pCLElBQUksTUFBTTtHQUNWLEtBQUssSUFBSTtHQUVULEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxLQUNqQixjQUFjLEtBQUssWUFBWSxNQUFNLElBQUksSUFBSSxNQUFNLEVBQUUsQ0FBQztHQUd4RDtHQUVBLE9BQU8sU0FBUyxLQUFLLEdBQUc7SUFDdEIsS0FBSztJQUNMLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztJQUN4QixPQUFPLGNBQWMsRUFBRSxDQUFDLElBQUksQ0FBQztHQUMvQjtHQUVBLFdBQVc7RUFDYixPQUFPLElBQUksQ0FBQyxRQUNWLFFBQVEsT0FBTyxTQUFTLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUs7RUFHakQsSUFBSSxDQUFDLGVBQWU7R0FDbEIsS0FBSyxLQUFLLEtBQ1IsY0FBYyxLQUFLLFFBQVEsT0FBTyxHQUFHLE9BQU8sSUFBSSxFQUFFO0dBR3BELE9BQU8sU0FBUyxLQUFLLEdBQUc7SUFDdEIsT0FBTyxrQkFBa0IsR0FBRyxNQUFNLE1BQU0sV0FBVyxNQUFNLElBQUk7R0FDL0Q7RUFDRjtDQUNGO0NBRUEsT0FBTyxtQkFBbUIsVUFBVSxJQUFJO0FBQzFDO0lBQ0ksdUJBQXVCLFNBQVMscUJBQXFCLFVBQVUsVUFBVSxVQUFVO0NBRXJGLElBQUksU0FBUyxTQUFTLFFBQ2xCLE1BQU1BLFdBQ04sR0FDQSxVQUNBO0NBRUosS0FBSyxLQUFLLFFBQVE7RUFDaEIsV0FBVyxPQUFPLEtBQUs7RUFFdkIsSUFBSSxXQUFXLE1BQU0sQ0FBQyxDQUFDLFlBQVksWUFBWSxPQUFPLFdBQVcsS0FBSyxJQUFJLFFBQVEsSUFBSTtHQUNwRixRQUFRO0dBQ1IsTUFBTTtFQUNSO0NBQ0Y7Q0FFQSxPQUFPO0FBQ1Q7SUFDSSxZQUFZLFNBQVMsVUFBVSxXQUFXLE1BQU0sa0JBQWtCO0NBQ3BFLElBQUksSUFBSSxVQUFVLE1BQ2QsV0FBVyxFQUFFLE9BQ2IsY0FBYyxVQUNkLFVBQVUsVUFBVSxNQUNwQixRQUNBLE9BQ0E7Q0FFSixJQUFJLENBQUMsVUFDSDtDQUdGLFNBQVMsRUFBRSxPQUFPO0NBQ2xCLFFBQVEsRUFBRSxpQkFBaUI7Q0FDM0Isb0JBQW9CLFlBQVksVUFBVSxZQUFZO0NBRXRELFlBQVksV0FBVztDQUN2QixTQUFTLFNBQVMsU0FBUyxNQUFNLE9BQU8sTUFBTSxJQUFJLFNBQVMsS0FBSyxLQUFLO0NBQ3JFLFdBQVc7Q0FDWCxPQUFPO0FBQ1Q7SUFDSSxhQUFhLFNBQVMsV0FBVyxXQUFXO0NBQzlDLGtCQUFrQixTQUFTO0NBRTNCLFVBQVUsaUJBQWlCLFVBQVUsY0FBYyxLQUFLLENBQUMsQ0FBQ0QsWUFBVTtDQUNwRSxVQUFVLFNBQVMsSUFBSSxLQUFLLFVBQVUsV0FBVyxhQUFhO0NBQzlELE9BQU87QUFDVDtJQUNJO0lBQ0EsdUJBQXVCLENBQUM7SUFDeEIsZ0JBQWdCLFNBQVMsY0FBYyxRQUFRO0NBQ2pELElBQUksQ0FBQyxRQUFRO0NBQ2IsU0FBUyxDQUFDLE9BQU8sUUFBUSxPQUFPLGNBQWM7Q0FFOUMsSUFBSUUsZ0JBQWMsS0FBSyxPQUFPLFVBQVU7RUFFdEMsSUFBSSxPQUFPLE9BQU8sTUFDZCxTQUFTLFlBQVksTUFBTSxHQUMzQixTQUFTLFFBQVEsQ0FBQyxVQUFVLE9BQU8sT0FBTyxXQUFZO0dBQ3hELEtBQUssU0FBUyxDQUFDO0VBQ2pCLElBQUksUUFFSixtQkFBbUI7R0FDakIsTUFBTTtHQUNOLFFBQVE7R0FDUixLQUFLO0dBQ0wsTUFBTTtHQUNOLFVBQVU7R0FDVixTQUFTO0VBQ1gsR0FDSSxVQUFVO0dBQ1osWUFBWTtHQUNaLEtBQUs7R0FDTCxXQUFXO0dBQ1gsU0FBUyxDQUFDO0dBQ1YsVUFBVTtFQUNaO0VBRUEsTUFBTTtFQUVOLElBQUksV0FBVyxRQUFRO0dBQ3JCLElBQUksU0FBUyxPQUNYO0dBR0YsYUFBYSxRQUFRLGFBQWEsZUFBZSxRQUFRLGdCQUFnQixHQUFHLE9BQU8sQ0FBQztHQUdwRixPQUFPLE9BQU8sV0FBVyxPQUFPLGtCQUFrQixlQUFlLFFBQVEsT0FBTyxDQUFDLENBQUM7R0FHbEYsU0FBUyxPQUFPLE9BQU8sUUFBUTtHQUUvQixJQUFJLE9BQU8sWUFBWTtJQUNyQixnQkFBZ0IsS0FBSyxNQUFNO0lBRTNCLGVBQWUsUUFBUTtHQUN6QjtHQUVBLFFBQVEsU0FBUyxRQUFRLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBSSxLQUFLLE9BQU8sQ0FBQyxLQUFLO0VBQ3BGO0VBRUEsV0FBVyxNQUFNLE1BQU07RUFFdkIsT0FBTyxZQUFZLE9BQU8sU0FBUyxNQUFNLFFBQVEsU0FBUztDQUM1RCxPQUNFLHFCQUFxQixLQUFLLE1BQU07QUFFcEM7SUFPQSxPQUFPO0lBQ0gsZUFBZTtDQUNqQixNQUFNO0VBQUM7RUFBRztFQUFNO0NBQUk7Q0FDcEIsTUFBTTtFQUFDO0VBQUc7RUFBTTtDQUFDO0NBQ2pCLFFBQVE7RUFBQztFQUFLO0VBQUs7Q0FBRztDQUN0QixPQUFPO0VBQUM7RUFBRztFQUFHO0NBQUM7Q0FDZixRQUFRO0VBQUM7RUFBSztFQUFHO0NBQUM7Q0FDbEIsTUFBTTtFQUFDO0VBQUc7RUFBSztDQUFHO0NBQ2xCLE1BQU07RUFBQztFQUFHO0VBQUc7Q0FBSTtDQUNqQixNQUFNO0VBQUM7RUFBRztFQUFHO0NBQUc7Q0FDaEIsT0FBTztFQUFDO0VBQU07RUFBTTtDQUFJO0NBQ3hCLE9BQU87RUFBQztFQUFLO0VBQUs7Q0FBQztDQUNuQixRQUFRO0VBQUM7RUFBTTtFQUFNO0NBQUM7Q0FDdEIsUUFBUTtFQUFDO0VBQU07RUFBSztDQUFDO0NBQ3JCLE1BQU07RUFBQztFQUFLO0VBQUs7Q0FBRztDQUNwQixRQUFRO0VBQUM7RUFBSztFQUFHO0NBQUc7Q0FDcEIsT0FBTztFQUFDO0VBQUc7RUFBSztDQUFDO0NBQ2pCLEtBQUs7RUFBQztFQUFNO0VBQUc7Q0FBQztDQUNoQixNQUFNO0VBQUM7RUFBTTtFQUFLO0NBQUc7Q0FDckIsTUFBTTtFQUFDO0VBQUc7RUFBTTtDQUFJO0NBQ3BCLGFBQWE7RUFBQztFQUFNO0VBQU07RUFBTTtDQUFDO0FBQ25DO0lBSUEsT0FBTyxTQUFTLEtBQUssR0FBRyxJQUFJLElBQUk7Q0FDOUIsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksS0FBSztDQUM5QixRQUFRLElBQUksSUFBSSxJQUFJLE1BQU0sS0FBSyxNQUFNLElBQUksSUFBSSxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxNQUFNLEtBQUssT0FBTyxJQUFJLElBQUksS0FBSyxJQUFJLE1BQU0sT0FBTyxLQUFLO0FBQzlIO0lBQ0ksYUFBYSxTQUFTLFdBQVcsR0FBRyxPQUFPLFlBQVk7Q0FDekQsSUFBSSxJQUFJLENBQUMsSUFBSSxhQUFhLFFBQVEsVUFBVSxDQUFDLElBQUk7RUFBQyxLQUFLO0VBQUksS0FBSyxJQUFJO0VBQU0sSUFBSTtDQUFJLElBQUksR0FDbEYsR0FDQSxHQUNBLEdBQ0EsR0FDQSxHQUNBLEdBQ0EsS0FDQSxLQUNBLEdBQ0E7Q0FFSixJQUFJLENBQUMsR0FBRztFQUNOLElBQUksRUFBRSxPQUFPLEVBQUUsTUFBTSxLQUVuQixJQUFJLEVBQUUsT0FBTyxHQUFHLEVBQUUsU0FBUyxDQUFDO0VBRzlCLElBQUksYUFBYSxJQUNmLElBQUksYUFBYTtPQUNaLElBQUksRUFBRSxPQUFPLENBQUMsTUFBTSxLQUFLO0dBQzlCLElBQUksRUFBRSxTQUFTLEdBQUc7SUFFaEIsSUFBSSxFQUFFLE9BQU8sQ0FBQztJQUNkLElBQUksRUFBRSxPQUFPLENBQUM7SUFDZCxJQUFJLEVBQUUsT0FBTyxDQUFDO0lBQ2QsSUFBSSxNQUFNLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLEVBQUUsV0FBVyxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtHQUNsRjtHQUVBLElBQUksRUFBRSxXQUFXLEdBQUc7SUFFbEIsSUFBSSxTQUFTLEVBQUUsT0FBTyxHQUFHLENBQUMsR0FBRyxFQUFFO0lBQy9CLE9BQU87S0FBQyxLQUFLO0tBQUksS0FBSyxJQUFJO0tBQU0sSUFBSTtLQUFNLFNBQVMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUk7SUFBRztHQUMzRTtHQUVBLElBQUksU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUU7R0FDNUIsSUFBSTtJQUFDLEtBQUs7SUFBSSxLQUFLLElBQUk7SUFBTSxJQUFJO0dBQUk7RUFDdkMsT0FBTyxJQUFJLEVBQUUsT0FBTyxHQUFHLENBQUMsTUFBTSxPQUFPO0dBQ25DLElBQUksU0FBUyxFQUFFLE1BQU0sYUFBYTtHQUVsQyxJQUFJLENBQUMsT0FBTztJQUNWLElBQUksQ0FBQyxFQUFFLEtBQUssTUFBTTtJQUNsQixJQUFJLENBQUMsRUFBRSxLQUFLO0lBQ1osSUFBSSxDQUFDLEVBQUUsS0FBSztJQUNaLElBQUksS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJO0lBQ3hDLElBQUksSUFBSSxJQUFJO0lBQ1osRUFBRSxTQUFTLE1BQU0sRUFBRSxNQUFNO0lBRXpCLEVBQUUsS0FBSyxLQUFLLElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQztJQUMzQixFQUFFLEtBQUssS0FBSyxHQUFHLEdBQUcsQ0FBQztJQUNuQixFQUFFLEtBQUssS0FBSyxJQUFJLElBQUksR0FBRyxHQUFHLENBQUM7R0FDN0IsT0FBTyxJQUFJLENBQUMsRUFBRSxRQUFRLEdBQUcsR0FBRztJQUUxQixJQUFJLEVBQUUsTUFBTSxPQUFPO0lBQ25CLGNBQWMsRUFBRSxTQUFTLE1BQU0sRUFBRSxLQUFLO0lBQ3RDLE9BQU87R0FDVDtFQUNGLE9BQ0UsSUFBSSxFQUFFLE1BQU0sYUFBYSxLQUFLLGFBQWE7RUFHN0MsSUFBSSxFQUFFLElBQUksTUFBTTtDQUNsQjtDQUVBLElBQUksU0FBUyxDQUFDLFFBQVE7RUFDcEIsSUFBSSxFQUFFLEtBQUs7RUFDWCxJQUFJLEVBQUUsS0FBSztFQUNYLElBQUksRUFBRSxLQUFLO0VBQ1gsTUFBTSxLQUFLLElBQUksR0FBRyxHQUFHLENBQUM7RUFDdEIsTUFBTSxLQUFLLElBQUksR0FBRyxHQUFHLENBQUM7RUFDdEIsS0FBSyxNQUFNLE9BQU87RUFFbEIsSUFBSSxRQUFRLEtBQ1YsSUFBSSxJQUFJO09BQ0g7R0FDTCxJQUFJLE1BQU07R0FDVixJQUFJLElBQUksS0FBTSxLQUFLLElBQUksTUFBTSxPQUFPLEtBQUssTUFBTTtHQUMvQyxJQUFJLFFBQVEsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLFFBQVEsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJO0dBQzVGLEtBQUs7RUFDUDtFQUVBLEVBQUUsS0FBSyxDQUFDLEVBQUUsSUFBSTtFQUNkLEVBQUUsS0FBSyxDQUFDLEVBQUUsSUFBSSxNQUFNO0VBQ3BCLEVBQUUsS0FBSyxDQUFDLEVBQUUsSUFBSSxNQUFNO0NBQ3RCO0NBRUEsY0FBYyxFQUFFLFNBQVMsTUFBTSxFQUFFLEtBQUs7Q0FDdEMsT0FBTztBQUNUO0lBQ0ksa0JBQWtCLFNBQVMsZ0JBQWdCLEdBQUc7Q0FFaEQsSUFBSSxTQUFTLENBQUMsR0FDVixJQUFJLENBQUMsR0FDTCxJQUFJO0NBQ1IsRUFBRSxNQUFNLFNBQVMsQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0VBQ3RDLElBQUksSUFBSSxFQUFFLE1BQU0sZUFBZSxLQUFLLENBQUM7RUFDckMsT0FBTyxLQUFLLE1BQU0sUUFBUSxDQUFDO0VBQzNCLEVBQUUsS0FBSyxLQUFLLEVBQUUsU0FBUyxDQUFDO0NBQzFCLENBQUM7Q0FDRCxPQUFPLElBQUk7Q0FDWCxPQUFPO0FBQ1Q7SUFDSSxnQkFBZ0IsU0FBUyxjQUFjLEdBQUcsT0FBTyxnQkFBZ0I7Q0FDbkUsSUFBSSxTQUFTLElBQ1QsVUFBVSxJQUFJLE9BQUEsQ0FBUSxNQUFNLFNBQVMsR0FDckMsT0FBTyxRQUFRLFVBQVUsU0FDekIsSUFBSSxHQUNKLEdBQ0EsT0FDQSxHQUNBO0NBRUosSUFBSSxDQUFDLFFBQ0gsT0FBTztDQUdULFNBQVMsT0FBTyxJQUFJLFNBQVUsT0FBTztFQUNuQyxRQUFRLFFBQVEsV0FBVyxPQUFPLE9BQU8sQ0FBQyxNQUFNLFFBQVEsUUFBUSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssT0FBTyxNQUFNLEtBQUssT0FBTyxNQUFNLEtBQUssTUFBTSxLQUFLLEdBQUcsS0FBSztDQUNySixDQUFDO0NBRUQsSUFBSSxnQkFBZ0I7RUFDbEIsSUFBSSxnQkFBZ0IsQ0FBQztFQUNyQixJQUFJLGVBQWU7RUFFbkIsSUFBSSxFQUFFLEtBQUssTUFBTSxNQUFNLEVBQUUsRUFBRSxLQUFLLE1BQU0sR0FBRztHQUN2QyxRQUFRLEVBQUUsUUFBUSxXQUFXLEdBQUcsQ0FBQyxDQUFDLE1BQU0sZUFBZTtHQUN2RCxJQUFJLE1BQU0sU0FBUztHQUVuQixPQUFPLElBQUksR0FBRyxLQUNaLFVBQVUsTUFBTSxNQUFNLENBQUMsRUFBRSxRQUFRLENBQUMsSUFBSSxPQUFPLE1BQU0sS0FBSyxPQUFPLGNBQWMsRUFBRSxTQUFTLElBQUksT0FBTyxTQUFTLFNBQVMsZUFBQSxDQUFnQixNQUFNO0VBRS9JO0NBQ0Y7Q0FFQSxJQUFJLENBQUMsT0FBTztFQUNWLFFBQVEsRUFBRSxNQUFNLFNBQVM7RUFDekIsSUFBSSxNQUFNLFNBQVM7RUFFbkIsT0FBTyxJQUFJLEdBQUcsS0FDWixVQUFVLE1BQU0sS0FBSyxPQUFPO0NBRWhDO0NBRUEsT0FBTyxTQUFTLE1BQU07QUFDeEI7SUFDSSxZQUFZLFdBQVk7Q0FDMUIsSUFBSSxJQUFJLDBFQUVSO0NBRUEsS0FBSyxLQUFLLGNBQ1IsS0FBSyxNQUFNLElBQUk7Q0FHakIsT0FBTyxJQUFJLE9BQU8sSUFBSSxLQUFLLElBQUk7QUFDakMsRUFBRTtJQUNFLFVBQVU7SUFDVixxQkFBcUIsU0FBUyxtQkFBbUIsR0FBRztDQUN0RCxJQUFJLFdBQVcsRUFBRSxLQUFLLEdBQUcsR0FDckI7Q0FDSixVQUFVLFlBQVk7Q0FFdEIsSUFBSSxVQUFVLEtBQUssUUFBUSxHQUFHO0VBQzVCLFFBQVEsUUFBUSxLQUFLLFFBQVE7RUFDN0IsRUFBRSxLQUFLLGNBQWMsRUFBRSxJQUFJLEtBQUs7RUFDaEMsRUFBRSxLQUFLLGNBQWMsRUFBRSxJQUFJLE9BQU8sZ0JBQWdCLEVBQUUsRUFBRSxDQUFDO0VBRXZELE9BQU87Q0FDVDtBQUNGO0lBT0E7SUFDSSxVQUFVLFdBQVk7Q0FDeEIsSUFBSSxXQUFXLEtBQUssS0FDaEIsZ0JBQWdCLEtBQ2hCLGVBQWUsSUFDZixhQUFhLFNBQVMsR0FDdEIsY0FBYyxZQUNkLE9BQU8sTUFBTyxLQUNkLFlBQVksTUFDWixhQUFhLENBQUMsR0FDZCxLQUNBLE1BQ0EsTUFDQSxPQUNBLFFBQ0EsSUFDQSxRQUFRLFNBQVMsTUFBTSxHQUFHO0VBQzVCLElBQUksVUFBVSxTQUFTLElBQUksYUFDdkIsU0FBUyxNQUFNLE1BQ2YsU0FDQSxVQUNBLE1BQ0E7RUFFSixDQUFDLFVBQVUsaUJBQWlCLFVBQVUsT0FBTyxjQUFjLFVBQVU7RUFDckUsZUFBZTtFQUNmLE9BQU8sY0FBYztFQUNyQixVQUFVLE9BQU87RUFFakIsSUFBSSxVQUFVLEtBQUssUUFBUTtHQUN6QixRQUFRLEVBQUUsTUFBTTtHQUNoQixTQUFTLE9BQU8sTUFBTSxPQUFPO0dBQzdCLE1BQU0sT0FBTyxPQUFPLE9BQU87R0FDM0IsYUFBYSxXQUFXLFdBQVcsT0FBTyxJQUFJLE9BQU87R0FDckQsV0FBVztFQUNiO0VBRUEsV0FBVyxNQUFNLEtBQUssS0FBSztFQUUzQixJQUFJLFVBQ0YsS0FBSyxLQUFLLEdBQUcsS0FBSyxXQUFXLFFBQVEsTUFFbkMsV0FBVyxHQUFHLENBQUMsTUFBTSxRQUFRLE9BQU8sQ0FBQztDQUczQztDQUVBLFFBQVE7RUFDTixNQUFNO0VBQ04sT0FBTztFQUNQLE1BQU0sU0FBUyxPQUFPO0dBQ3BCLE1BQU0sSUFBSTtFQUNaO0VBQ0EsWUFBWSxTQUFTLFdBQVcsS0FBSztHQUNuQyxPQUFPLFVBQVUsT0FBUSxPQUFPO0VBQ2xDO0VBQ0EsTUFBTSxTQUFTLE9BQU87R0FDcEIsSUFBSSxZQUFZO0lBQ2QsSUFBSSxDQUFDLGdCQUFnQkEsZ0JBQWMsR0FBRztLQUNwQyxTQUFPLGVBQWU7S0FDdEIsU0FBT0MsT0FBSyxZQUFZLENBQUM7S0FDekIsU0FBUyxPQUFPO0tBQ2hCLENBQUNBLE9BQUssaUJBQWlCLE9BQUssZUFBZSxDQUFDLEdBQUEsQ0FBSSxLQUFLLEtBQUssT0FBTztLQUVqRSxTQUFTLGlCQUFpQkEsT0FBSyxvQkFBb0IsQ0FBQ0EsT0FBSyxRQUFRQSxVQUFRLENBQUMsQ0FBQztLQUUzRSxxQkFBcUIsUUFBUSxhQUFhO0lBQzVDO0lBRUEsT0FBTyxPQUFPLDBCQUEwQixlQUFlO0lBQ3ZELE9BQU8sTUFBTSxNQUFNO0lBRW5CLE9BQU8sUUFBUSxTQUFVLEdBQUc7S0FDMUIsT0FBTyxXQUFXLEdBQUcsWUFBWSxNQUFNLE9BQU8sTUFBTyxJQUFJLENBQUM7SUFDNUQ7SUFFQSxnQkFBZ0I7SUFFaEIsTUFBTSxDQUFDO0dBQ1Q7RUFDRjtFQUNBLE9BQU8sU0FBUyxRQUFRO0dBQ3RCLENBQUMsT0FBTyx1QkFBdUIsYUFBQSxDQUFjLEdBQUc7R0FDaEQsZ0JBQWdCO0dBQ2hCLE9BQU87RUFDVDtFQUNBLGNBQWMsU0FBUyxhQUFhLFdBQVcsYUFBYTtHQUMxRCxnQkFBZ0IsYUFBYTtHQUU3QixlQUFlLEtBQUssSUFBSSxlQUFlLElBQUksYUFBYTtFQUMxRDtFQUNBLEtBQUssU0FBUyxJQUFJLE1BQU07R0FDdEIsT0FBTyxPQUFRLFFBQVE7R0FDdkIsWUFBWSxNQUFNLE9BQU8sTUFBTztFQUNsQztFQUNBLEtBQUssU0FBUyxJQUFJLFVBQVUsTUFBTSxZQUFZO0dBQzVDLElBQUksT0FBTyxPQUFPLFNBQVUsR0FBRyxHQUFHLEdBQUcsR0FBRztJQUN0QyxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7SUFFbkIsTUFBTSxPQUFPLElBQUk7R0FDbkIsSUFBSTtHQUVKLE1BQU0sT0FBTyxRQUFRO0dBRXJCLFdBQVcsYUFBYSxZQUFZLE9BQU8sQ0FBQyxJQUFJO0dBRWhELE1BQU07R0FFTixPQUFPO0VBQ1Q7RUFDQSxRQUFRLFNBQVMsT0FBTyxVQUFVLEdBQUc7R0FDbkMsRUFBRSxJQUFJLFdBQVcsUUFBUSxRQUFRLE1BQU0sV0FBVyxPQUFPLEdBQUcsQ0FBQyxLQUFLLE1BQU0sS0FBSztFQUMvRTtFQUNZO0NBQ2Q7Q0FDQSxPQUFPO0FBQ1QsRUFBRTtJQUNFLFFBQVEsU0FBUyxRQUFRO0NBQzNCLE9BQU8sQ0FBQyxpQkFBaUIsUUFBUSxLQUFLO0FBQ3hDO0lBUUEsV0FBVyxDQUFDO0lBQ1IsaUJBQWlCO0lBQ2pCLGFBQWE7SUFDYix1QkFBdUIsU0FBUyxxQkFBcUIsT0FBTztDQUU5RCxJQUFJLE1BQU0sQ0FBQyxHQUNQLFFBQVEsTUFBTSxPQUFPLEdBQUcsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxHQUNuRCxNQUFNLE1BQU0sSUFDWixJQUFJLEdBQ0osSUFBSSxNQUFNLFFBQ1YsT0FDQSxLQUNBO0NBRUosT0FBTyxJQUFJLEdBQUcsS0FBSztFQUNqQixNQUFNLE1BQU07RUFDWixRQUFRLE1BQU0sSUFBSSxJQUFJLElBQUksWUFBWSxHQUFHLElBQUksSUFBSTtFQUNqRCxZQUFZLElBQUksT0FBTyxHQUFHLEtBQUs7RUFDL0IsSUFBSSxPQUFPLE1BQU0sU0FBUyxJQUFJLFVBQVUsUUFBUSxZQUFZLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDO0VBQzFFLE1BQU0sSUFBSSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSztDQUNuQztDQUVBLE9BQU87QUFDVDtJQUNJLHNCQUFzQixTQUFTLG9CQUFvQixPQUFPO0NBQzVELElBQUksT0FBTyxNQUFNLFFBQVEsR0FBRyxJQUFJLEdBQzVCLFFBQVEsTUFBTSxRQUFRLEdBQUcsR0FDekIsU0FBUyxNQUFNLFFBQVEsS0FBSyxJQUFJO0NBQ3BDLE9BQU8sTUFBTSxVQUFVLE1BQU0sQ0FBQyxVQUFVLFNBQVMsUUFBUSxNQUFNLFFBQVEsS0FBSyxRQUFRLENBQUMsSUFBSSxLQUFLO0FBQ2hHO0lBQ0ksd0JBQXdCLFNBQVMsc0JBQXNCLE1BQU07Q0FFL0QsSUFBSSxTQUFTLE9BQU8sR0FBQSxDQUFJLE1BQU0sR0FBRyxHQUM3QixPQUFPLFNBQVMsTUFBTTtDQUMxQixPQUFPLFFBQVEsTUFBTSxTQUFTLEtBQUssS0FBSyxTQUFTLEtBQUssT0FBTyxNQUFNLE1BQU0sQ0FBQyxLQUFLLFFBQVEsR0FBRyxJQUFJLENBQUMscUJBQXFCLE1BQU0sRUFBRSxDQUFDLElBQUksb0JBQW9CLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxrQkFBa0IsQ0FBQyxJQUFJLFNBQVMsT0FBTyxlQUFlLEtBQUssSUFBSSxJQUFJLFNBQVMsSUFBSSxJQUFJLElBQUksSUFBSTtBQUN4UTtJQUNJLGNBQWMsU0FBUyxZQUFZLE1BQU07Q0FDM0MsT0FBTyxTQUFVLEdBQUc7RUFDbEIsT0FBTyxJQUFJLEtBQUssSUFBSSxDQUFDO0NBQ3ZCO0FBQ0Y7SUFDSSxhQUFhLFNBQVMsV0FBVyxNQUFNLGFBQWE7Q0FDdEQsT0FBTyxDQUFDLE9BQU8sZUFBZSxZQUFZLElBQUksSUFBSSxPQUFPLFNBQVMsU0FBUyxzQkFBc0IsSUFBSSxNQUFNO0FBQzdHO0lBQ0ksY0FBYyxTQUFTLFlBQVksT0FBTyxRQUFRLFNBQVMsV0FBVztDQUN4RSxJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLFNBQVMsUUFBUSxHQUFHO0VBQzVCLE9BQU8sSUFBSSxPQUFPLElBQUksQ0FBQztDQUN6QjtDQUdGLElBQUksY0FBYyxLQUFLLEdBQ3JCLFlBQVksU0FBUyxVQUFVLEdBQUc7RUFDaEMsT0FBTyxJQUFJLEtBQUssT0FBTyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksUUFBUSxJQUFJLEtBQUssQ0FBQyxJQUFJO0NBQ2hFO0NBR0YsSUFBSSxPQUFPO0VBQ0Q7RUFDQztFQUNFO0NBQ2IsR0FDSTtDQUVKLGFBQWEsT0FBTyxTQUFVLE1BQU07RUFDbEMsU0FBUyxRQUFRLFNBQVMsUUFBUTtFQUNsQyxTQUFTLGdCQUFnQixLQUFLLFlBQVksS0FBSztFQUUvQyxLQUFLLElBQUksS0FBSyxNQUNaLFNBQVMsaUJBQWlCLE1BQU0sV0FBVyxRQUFRLE1BQU0sWUFBWSxTQUFTLGFBQWEsU0FBUyxPQUFPLE1BQU0sS0FBSyxLQUFLO0NBRS9ILENBQUM7Q0FFRCxPQUFPO0FBQ1Q7SUFDSSxvQkFBb0IsU0FBUyxrQkFBa0IsU0FBUztDQUMxRCxPQUFPLFNBQVUsR0FBRztFQUNsQixPQUFPLElBQUksTUFBTSxJQUFJLFFBQVEsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLE1BQU0sQ0FBQyxJQUFJO0NBQzlFO0FBQ0Y7SUFDSSxpQkFBaUIsU0FBUyxlQUFlLE1BQU0sV0FBVyxRQUFRO0NBQ3BFLElBQUksS0FBSyxhQUFhLElBQUksWUFBWSxHQUV0QyxNQUFNLFdBQVcsT0FBTyxLQUFLLFNBQVMsWUFBWSxJQUFJLFlBQVksSUFDOUQsS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLLElBQUksRUFBRSxLQUFLLElBQ3ZDLFVBQVUsU0FBUyxRQUFRLEdBQUc7RUFDaEMsT0FBTyxNQUFNLElBQUksSUFBSSxLQUFLLEtBQUssSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLE1BQU0sSUFBSSxNQUFNLEVBQUUsSUFBSTtDQUN6RSxHQUNJLE9BQU8sU0FBUyxRQUFRLFVBQVUsU0FBUyxPQUFPLFNBQVUsR0FBRztFQUNqRSxPQUFPLElBQUksUUFBUSxJQUFJLENBQUM7Q0FDMUIsSUFBSSxrQkFBa0IsT0FBTztDQUU3QixLQUFLLE9BQU87Q0FFWixLQUFLLFNBQVMsU0FBVSxXQUFXLFFBQVE7RUFDekMsT0FBTyxlQUFlLE1BQU0sV0FBVyxNQUFNO0NBQy9DO0NBRUEsT0FBTztBQUNUO0lBQ0ksY0FBYyxTQUFTLFlBQVksTUFBTSxXQUFXO0NBQ3RELElBQUksY0FBYyxLQUFLLEdBQ3JCLFlBQVk7Q0FHZCxJQUFJLFVBQVUsU0FBUyxRQUFRLEdBQUc7RUFDaEMsT0FBTyxJQUFJLEVBQUUsSUFBSSxNQUFNLFlBQVksS0FBSyxJQUFJLGFBQWEsSUFBSTtDQUMvRCxHQUNJLE9BQU8sU0FBUyxRQUFRLFVBQVUsU0FBUyxPQUFPLFNBQVUsR0FBRztFQUNqRSxPQUFPLElBQUksUUFBUSxJQUFJLENBQUM7Q0FDMUIsSUFBSSxrQkFBa0IsT0FBTztDQUU3QixLQUFLLFNBQVMsU0FBVSxXQUFXO0VBQ2pDLE9BQU8sWUFBWSxNQUFNLFNBQVM7Q0FDcEM7Q0FFQSxPQUFPO0FBQ1Q7QUFlQSxhQUFhLHdDQUF3QyxTQUFVLE1BQU0sR0FBRztDQUN0RSxJQUFJLFFBQVEsSUFBSSxJQUFJLElBQUksSUFBSTtDQUU1QixZQUFZLE9BQU8sWUFBWSxRQUFRLElBQUksSUFBSSxTQUFVLEdBQUc7RUFDMUQsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLO0NBQzFCLElBQUksU0FBVSxHQUFHO0VBQ2YsT0FBTztDQUNULEdBQUcsU0FBVSxHQUFHO0VBQ2QsT0FBTyxJQUFJLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSztDQUNsQyxHQUFHLFNBQVUsR0FBRztFQUNkLE9BQU8sSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxJQUFJO0NBQ2xGLENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyxPQUFPLFdBQVcsU0FBUyxPQUFPLFNBQVMsT0FBTztBQUUzRCxZQUFZLFdBQVcsZUFBZSxJQUFJLEdBQUcsZUFBZSxLQUFLLEdBQUcsZUFBZSxDQUFDO0NBRW5GLFNBQVUsR0FBRyxHQUFHO0NBQ2YsSUFBSSxLQUFLLElBQUksR0FDVCxLQUFLLElBQUksSUFDVCxLQUFLLE1BQU0sSUFDWCxVQUFVLFNBQVMsUUFBUSxHQUFHO0VBQ2hDLE9BQU8sSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sR0FBRyxDQUFDLElBQUksTUFBTSxJQUFJLEtBQUssS0FBSyxLQUFLLE9BQU8sS0FBSyxJQUFJLFFBQVEsSUFBSSxLQUFLLElBQUksSUFBSSxRQUFRLEdBQUcsQ0FBQyxJQUFJO0NBQ3hKO0NBRUEsWUFBWSxVQUFVLFNBQVUsR0FBRztFQUNqQyxPQUFPLElBQUksUUFBUSxJQUFJLENBQUM7Q0FDMUIsR0FBRyxPQUFPO0FBQ1osRUFBQSxDQUFHLFFBQVEsSUFBSTtBQUVmLFlBQVksUUFBUSxTQUFVLEdBQUc7Q0FDL0IsT0FBTyxLQUFLLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSTtBQUN0RSxDQUFDO0FBR0QsWUFBWSxRQUFRLFNBQVUsR0FBRztDQUMvQixPQUFPLEVBQUUsTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJO0FBQzlCLENBQUM7QUFFRCxZQUFZLFFBQVEsU0FBVSxHQUFHO0NBQy9CLE9BQU8sTUFBTSxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksUUFBUSxJQUFJO0FBQzdDLENBQUM7QUFFRCxZQUFZLFFBQVEsWUFBWSxJQUFJLEdBQUcsWUFBWSxLQUFLLEdBQUcsWUFBWSxDQUFDO0FBRXhFLFNBQVMsY0FBYyxTQUFTLFFBQVEsU0FBUyxjQUFjLEVBQzdELFFBQVEsU0FBUyxPQUFPLE9BQU8sZ0JBQWdCO0NBQzdDLElBQUksVUFBVSxLQUFLLEdBQ2pCLFFBQVE7Q0FHVixJQUFJLEtBQUssSUFBSSxPQUNULEtBQUssU0FBUyxpQkFBaUIsSUFBSSxJQUNuQyxLQUFLLGlCQUFpQixJQUFJLEdBQzFCLE1BQU0sSUFBSTtDQUNkLE9BQU8sU0FBVSxHQUFHO0VBQ2xCLFNBQVMsS0FBSyxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNO0NBQy9DO0FBQ0YsRUFDRjtBQUNBLFVBQVUsT0FBTyxTQUFTO0FBRTFCLGFBQWEsc0VBQXNFLFNBQVUsTUFBTTtDQUNqRyxPQUFPLGtCQUFrQixPQUFPLE1BQU0sT0FBTztBQUMvQyxDQUFDO0FBUUQsSUFBVyxVQUFVLFNBQVMsUUFBUSxRQUFRLFNBQVM7Q0FDckQsS0FBSyxLQUFLO0NBQ1YsT0FBTyxRQUFRO0NBQ2YsS0FBSyxTQUFTO0NBQ2QsS0FBSyxVQUFVO0NBQ2YsS0FBSyxNQUFNLFVBQVUsUUFBUSxNQUFNO0NBQ25DLEtBQUssTUFBTSxVQUFVLFFBQVEsWUFBWTtBQUMzQztBQU9BLElBQVcsWUFBeUIseUJBQVk7Q0FDOUMsU0FBUyxVQUFVLE1BQU07RUFDdkIsS0FBSyxPQUFPO0VBQ1osS0FBSyxTQUFTLENBQUMsS0FBSyxTQUFTO0VBRTdCLElBQUksS0FBSyxVQUFVLEtBQUssV0FBVyxXQUFXLEtBQUssS0FBSyxVQUFVLEdBQUc7R0FFbkUsS0FBSyxVQUFVLEtBQUssZUFBZTtHQUNuQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsS0FBSztFQUNyQztFQUVBLEtBQUssTUFBTTtFQUVYLGFBQWEsTUFBTSxDQUFDLEtBQUssVUFBVSxHQUFHLENBQUM7RUFFdkMsS0FBSyxPQUFPLEtBQUs7RUFFakIsSUFBSSxVQUFVO0dBQ1osS0FBSyxPQUFPO0dBRVosU0FBUyxLQUFLLEtBQUssSUFBSTtFQUN6QjtFQUVBLGlCQUFpQixRQUFRLEtBQUs7Q0FDaEM7Q0FFQSxJQUFJLFNBQVMsVUFBVTtDQUV2QixPQUFPLFFBQVEsU0FBUyxNQUFNLE9BQU87RUFDbkMsSUFBSSxTQUFTLFVBQVUsR0FBRztHQUN4QixLQUFLLFVBQVUsS0FBSyxPQUFPLHFCQUFxQixLQUFLLFVBQVUsS0FBSyxTQUFTLFFBQVEsS0FBSyxNQUFNO0dBQ2hHLEtBQUssU0FBUztHQUNkLE9BQU87RUFDVDtFQUVBLE9BQU8sS0FBSztDQUNkO0NBRUEsT0FBTyxXQUFXLFNBQVMsU0FBUyxPQUFPO0VBQ3pDLE9BQU8sVUFBVSxTQUFTLEtBQUssY0FBYyxLQUFLLFVBQVUsSUFBSSxTQUFTLFFBQVEsS0FBSyxXQUFXLEtBQUssVUFBVSxLQUFLLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSztDQUN4SjtDQUVBLE9BQU8sZ0JBQWdCLFNBQVMsY0FBYyxPQUFPO0VBQ25ELElBQUksQ0FBQyxVQUFVLFFBQ2IsT0FBTyxLQUFLO0VBR2QsS0FBSyxTQUFTO0VBQ2QsT0FBTyxhQUFhLE1BQU0sS0FBSyxVQUFVLElBQUksU0FBUyxRQUFRLEtBQUssVUFBVSxLQUFLLFlBQVksS0FBSyxVQUFVLEVBQUU7Q0FDakg7Q0FFQSxPQUFPLFlBQVksU0FBUyxVQUFVLFlBQVksZ0JBQWdCO0VBQ2hFLE1BQU07RUFFTixJQUFJLENBQUMsVUFBVSxRQUNiLE9BQU8sS0FBSztFQUdkLElBQUksU0FBUyxLQUFLO0VBRWxCLElBQUksVUFBVSxPQUFPLHFCQUFxQixLQUFLLEtBQUs7R0FDbEQsZUFBZSxNQUFNLFVBQVU7R0FFL0IsQ0FBQyxPQUFPLE9BQU8sT0FBTyxVQUFVLGVBQWUsUUFBUSxJQUFJO0dBRzNELE9BQU8sVUFBVSxPQUFPLFFBQVE7SUFDOUIsSUFBSSxPQUFPLE9BQU8sVUFBVSxPQUFPLFVBQVUsT0FBTyxPQUFPLElBQUksT0FBTyxTQUFTLE9BQU8sT0FBTyxPQUFPLGNBQWMsSUFBSSxPQUFPLFVBQVUsQ0FBQyxPQUFPLE1BQzdJLE9BQU8sVUFBVSxPQUFPLFFBQVEsSUFBSTtJQUd0QyxTQUFTLE9BQU87R0FDbEI7R0FFQSxJQUFJLENBQUMsS0FBSyxVQUFVLEtBQUssSUFBSSx1QkFBdUIsS0FBSyxNQUFNLEtBQUssYUFBYSxLQUFLLFNBQVMsS0FBSyxNQUFNLEtBQUssYUFBYSxLQUFLLENBQUMsS0FBSyxTQUFTLENBQUMsYUFFL0ksZUFBZSxLQUFLLEtBQUssTUFBTSxLQUFLLFNBQVMsS0FBSyxNQUFNO0VBRTVEO0VBRUEsSUFBSSxLQUFLLFdBQVcsY0FBYyxDQUFDLEtBQUssUUFBUSxDQUFDLGtCQUFrQixLQUFLLFlBQVksS0FBSyxJQUFJLEtBQUssTUFBTSxNQUFNLFlBQVksQ0FBQyxLQUFLLFlBQVksS0FBSyxRQUFRLGNBQWMsQ0FBQyxjQUFjLENBQUMsS0FBSyxhQUFhLEtBQUssT0FBTyxLQUFLLFlBQVk7R0FFcE8sS0FBSyxRQUFRLEtBQUssU0FBUztHQUkzQixnQkFBZ0IsTUFBTSxZQUFZLGNBQWM7RUFHbEQ7RUFFQSxPQUFPO0NBQ1Q7Q0FFQSxPQUFPLE9BQU8sU0FBUyxLQUFLLE9BQU8sZ0JBQWdCO0VBQ2pELE9BQU8sVUFBVSxTQUFTLEtBQUssVUFBVSxLQUFLLElBQUksS0FBSyxjQUFjLEdBQUcsUUFBUSxzQkFBc0IsSUFBSSxDQUFDLEtBQUssS0FBSyxPQUFPLEtBQUssYUFBYSxRQUFRLEtBQUssT0FBTyxJQUFJLGNBQWMsSUFBSSxLQUFLO0NBQy9MO0NBRUEsT0FBTyxnQkFBZ0IsU0FBUyxjQUFjLE9BQU8sZ0JBQWdCO0VBQ25FLE9BQU8sVUFBVSxTQUFTLEtBQUssVUFBVSxLQUFLLGNBQWMsSUFBSSxPQUFPLGNBQWMsSUFBSSxLQUFLLGNBQWMsSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLFNBQVMsS0FBSyxLQUFLLElBQUksS0FBSyxRQUFRLEtBQUssS0FBSyxLQUFLLFdBQVcsSUFBSTtDQUNyTTtDQUVBLE9BQU8sV0FBVyxTQUFTLFNBQVMsT0FBTyxnQkFBZ0I7RUFDekQsT0FBTyxVQUFVLFNBQVMsS0FBSyxVQUFVLEtBQUssU0FBUyxLQUFLLEtBQUssU0FBUyxFQUFFLEtBQUssVUFBVSxJQUFJLEtBQUssSUFBSSxRQUFRLFNBQVMsc0JBQXNCLElBQUksR0FBRyxjQUFjLElBQUksS0FBSyxTQUFTLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxRQUFRLEtBQUssSUFBSSxJQUFJLEtBQUssUUFBUSxJQUFJLElBQUksSUFBSTtDQUMzUDtDQUVBLE9BQU8sWUFBWSxTQUFTLFVBQVUsT0FBTyxnQkFBZ0I7RUFDM0QsSUFBSSxnQkFBZ0IsS0FBSyxTQUFTLElBQUksS0FBSztFQUUzQyxPQUFPLFVBQVUsU0FBUyxLQUFLLFVBQVUsS0FBSyxTQUFTLFFBQVEsS0FBSyxlQUFlLGNBQWMsSUFBSSxLQUFLLFVBQVUsZ0JBQWdCLEtBQUssUUFBUSxhQUFhLElBQUksSUFBSTtDQUN4SztDQVlBLE9BQU8sWUFBWSxTQUFTLFVBQVUsT0FBTyxnQkFBZ0I7RUFDM0QsSUFBSSxDQUFDLFVBQVUsUUFDYixPQUFPLEtBQUssU0FBUyxDQUFDLFdBQVcsSUFBSSxLQUFLO0VBRzVDLElBQUksS0FBSyxTQUFTLE9BQ2hCLE9BQU87RUFHVCxJQUFJLFFBQVEsS0FBSyxVQUFVLEtBQUssTUFBTSx3QkFBd0IsS0FBSyxPQUFPLE9BQU8sSUFBSSxJQUFJLEtBQUs7RUFLOUYsS0FBSyxPQUFPLENBQUMsU0FBUztFQUN0QixLQUFLLE1BQU0sS0FBSyxPQUFPLFVBQVUsQ0FBQyxXQUFXLElBQUksS0FBSztFQUV0RCxLQUFLLFVBQVUsT0FBTyxDQUFDLEtBQUssSUFBSSxLQUFLLE1BQU0sR0FBRyxLQUFLLGNBQWMsR0FBRyxLQUFLLEdBQUcsbUJBQW1CLEtBQUs7RUFFcEcsUUFBUSxJQUFJO0VBR1osT0FBTyxrQkFBa0IsSUFBSTtDQUMvQjtDQUVBLE9BQU8sU0FBUyxTQUFTLE9BQU8sT0FBTztFQUNyQyxJQUFJLENBQUMsVUFBVSxRQUNiLE9BQU8sS0FBSztFQUtkLElBQUksS0FBSyxRQUFRLE9BQU87R0FDdEIsS0FBSyxNQUFNO0dBRVgsSUFBSSxPQUFPO0lBQ1QsS0FBSyxTQUFTLEtBQUssVUFBVSxLQUFLLElBQUksQ0FBQyxLQUFLLFFBQVEsS0FBSyxRQUFRLENBQUM7SUFFbEUsS0FBSyxNQUFNLEtBQUssT0FBTztHQUN6QixPQUFPO0lBQ0wsTUFBTTtJQUVOLEtBQUssTUFBTSxLQUFLO0lBRWhCLEtBQUssVUFBVSxLQUFLLFVBQVUsQ0FBQyxLQUFLLE9BQU8sb0JBQW9CLEtBQUssUUFBUSxJQUFJLEtBQUssVUFBVSxLQUFLLFFBQVEsS0FBSyxTQUFTLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxNQUFNLE1BQU0sYUFBYSxLQUFLLFVBQVUsU0FBUztHQUN0TTtFQUNGO0VBRUEsT0FBTztDQUNUO0NBRUEsT0FBTyxZQUFZLFNBQVMsVUFBVSxPQUFPO0VBQzNDLElBQUksVUFBVSxRQUFRO0dBQ3BCLEtBQUssU0FBUyxjQUFjLEtBQUs7R0FDakMsSUFBSSxTQUFTLEtBQUssVUFBVSxLQUFLO0dBQ2pDLFdBQVcsT0FBTyxTQUFTLENBQUMsS0FBSyxXQUFXLGVBQWUsUUFBUSxNQUFNLEtBQUssU0FBUyxLQUFLLE1BQU07R0FDbEcsT0FBTztFQUNUO0VBRUEsT0FBTyxLQUFLO0NBQ2Q7Q0FFQSxPQUFPLFVBQVUsU0FBUyxRQUFRLGdCQUFnQjtFQUNoRCxPQUFPLEtBQUssVUFBVSxZQUFZLGNBQWMsSUFBSSxLQUFLLGNBQWMsSUFBSSxLQUFLLFNBQVMsS0FBSyxLQUFLLElBQUksS0FBSyxPQUFPLENBQUM7Q0FDdEg7Q0FFQSxPQUFPLFVBQVUsU0FBUyxRQUFRLGFBQWE7RUFDN0MsSUFBSSxTQUFTLEtBQUssVUFBVSxLQUFLO0VBRWpDLE9BQU8sQ0FBQyxTQUFTLEtBQUssU0FBUyxnQkFBZ0IsQ0FBQyxLQUFLLE9BQU8sS0FBSyxXQUFXLEtBQUssU0FBUyxLQUFLLGNBQWMsSUFBSSxLQUFLLEtBQUssVUFBVSxLQUFLLE9BQU8sS0FBSyxXQUFXLENBQUMsS0FBSyxNQUFNLEtBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRLFdBQVcsR0FBRyxJQUFJO0NBQ3RQO0NBRUEsT0FBTyxTQUFTLFNBQVMsT0FBTyxRQUFRO0VBQ3RDLElBQUksV0FBVyxLQUFLLEdBQ2xCLFNBQVM7RUFHWCxJQUFJLGtCQUFrQkg7RUFDdEIsZUFBYTtFQUViLElBQUksZ0JBQWdCLElBQUksR0FBRztHQUN6QixLQUFLLFlBQVksS0FBSyxTQUFTLE9BQU8sTUFBTTtHQUM1QyxLQUFLLFVBQVUsTUFBTyxPQUFPLGNBQWM7RUFDN0M7RUFFQSxLQUFLLFNBQVMsWUFBWSxPQUFPLFNBQVMsU0FBUyxLQUFLLEtBQUs7RUFDN0QsZUFBYTtFQUNiLE9BQU87Q0FDVDtDQUVBLE9BQU8sYUFBYSxTQUFTLFdBQVcsU0FBUztFQUMvQyxJQUFJLFlBQVksTUFDWixPQUFPLFVBQVUsU0FBUyxVQUFVLFVBQVUsUUFBUTtFQUUxRCxPQUFPLFdBQVc7R0FDaEIsT0FBTyxVQUFVLFNBQVMsUUFBUSxLQUFLLElBQUksVUFBVSxHQUFHLEtBQUs7R0FDN0QsWUFBWSxVQUFVO0VBQ3hCO0VBRUEsT0FBTyxDQUFDLEtBQUssVUFBVSxLQUFLLE9BQU8sS0FBSyxLQUFLLFdBQVcsT0FBTyxJQUFJO0NBQ3JFO0NBRUEsT0FBTyxTQUFTLFNBQVMsT0FBTyxPQUFPO0VBQ3JDLElBQUksVUFBVSxRQUFRO0dBQ3BCLEtBQUssVUFBVSxVQUFVLFdBQVcsS0FBSztHQUN6QyxPQUFPLHVCQUF1QixJQUFJO0VBQ3BDO0VBRUEsT0FBTyxLQUFLLFlBQVksS0FBSyxXQUFXLEtBQUs7Q0FDL0M7Q0FFQSxPQUFPLGNBQWMsU0FBUyxZQUFZLE9BQU87RUFDL0MsSUFBSSxVQUFVLFFBQVE7R0FDcEIsSUFBSSxPQUFPLEtBQUs7R0FDaEIsS0FBSyxVQUFVO0dBRWYsdUJBQXVCLElBQUk7R0FFM0IsT0FBTyxPQUFPLEtBQUssS0FBSyxJQUFJLElBQUk7RUFDbEM7RUFFQSxPQUFPLEtBQUs7Q0FDZDtDQUVBLE9BQU8sT0FBTyxTQUFTLEtBQUssT0FBTztFQUNqQyxJQUFJLFVBQVUsUUFBUTtHQUNwQixLQUFLLFFBQVE7R0FDYixPQUFPO0VBQ1Q7RUFFQSxPQUFPLEtBQUs7Q0FDZDtDQUVBLE9BQU8sT0FBTyxTQUFTLEtBQUssVUFBVSxnQkFBZ0I7RUFDcEQsT0FBTyxLQUFLLFVBQVUsZUFBZSxNQUFNLFFBQVEsR0FBRyxZQUFZLGNBQWMsQ0FBQztDQUNuRjtDQUVBLE9BQU8sVUFBVSxTQUFTLFFBQVEsY0FBYyxnQkFBZ0I7RUFDOUQsS0FBSyxLQUFLLENBQUMsQ0FBQyxVQUFVLGVBQWUsQ0FBQyxLQUFLLFNBQVMsR0FBRyxZQUFZLGNBQWMsQ0FBQztFQUNsRixLQUFLLFNBQVMsS0FBSyxTQUFTLENBQUM7RUFFN0IsT0FBTztDQUNUO0NBRUEsT0FBTyxPQUFPLFNBQVMsS0FBSyxNQUFNLGdCQUFnQjtFQUNoRCxRQUFRLFFBQVEsS0FBSyxLQUFLLE1BQU0sY0FBYztFQUM5QyxPQUFPLEtBQUssU0FBUyxLQUFLLENBQUMsQ0FBQyxPQUFPLEtBQUs7Q0FDMUM7Q0FFQSxPQUFPLFVBQVUsU0FBUyxRQUFRLE1BQU0sZ0JBQWdCO0VBQ3RELFFBQVEsUUFBUSxLQUFLLEtBQUssUUFBUSxLQUFLLGNBQWMsR0FBRyxjQUFjO0VBQ3RFLE9BQU8sS0FBSyxTQUFTLElBQUksQ0FBQyxDQUFDLE9BQU8sS0FBSztDQUN6QztDQUVBLE9BQU8sUUFBUSxTQUFTLE1BQU0sUUFBUSxnQkFBZ0I7RUFDcEQsVUFBVSxRQUFRLEtBQUssS0FBSyxRQUFRLGNBQWM7RUFDbEQsT0FBTyxLQUFLLE9BQU8sSUFBSTtDQUN6QjtDQUVBLE9BQU8sU0FBUyxTQUFTLFNBQVM7RUFDaEMsT0FBTyxLQUFLLE9BQU8sS0FBSztDQUMxQjtDQUVBLE9BQU8sV0FBVyxTQUFTLFNBQVMsT0FBTztFQUN6QyxJQUFJLFVBQVUsUUFBUTtHQUNwQixDQUFDLENBQUMsVUFBVSxLQUFLLFNBQVMsS0FBSyxLQUFLLFVBQVUsQ0FBQyxLQUFLLFNBQVMsUUFBUSxDQUFDLFdBQVcsRUFBRTtHQUVuRixPQUFPO0VBQ1Q7RUFFQSxPQUFPLEtBQUssT0FBTztDQUNyQjtDQUVBLE9BQU8sYUFBYSxTQUFTLGFBQWE7RUFDeEMsS0FBSyxXQUFXLEtBQUssT0FBTztFQUM1QixLQUFLLFNBQVMsQ0FBQztFQUNmLE9BQU87Q0FDVDtDQUVBLE9BQU8sV0FBVyxTQUFTLFdBQVc7RUFDcEMsSUFBSSxTQUFTLEtBQUssVUFBVSxLQUFLLEtBQzdCLFFBQVEsS0FBSyxRQUNiO0VBQ0osT0FBTyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEtBQUssT0FBTyxLQUFLLFlBQVksT0FBTyxTQUFTLE1BQU0sVUFBVSxPQUFPLFFBQVEsSUFBSSxNQUFNLFNBQVMsVUFBVSxLQUFLLFFBQVEsSUFBSSxJQUFJO0NBQ3JKO0NBRUEsT0FBTyxnQkFBZ0IsU0FBUyxjQUFjLE1BQU0sVUFBVSxRQUFRO0VBQ3BFLElBQUksT0FBTyxLQUFLO0VBRWhCLElBQUksVUFBVSxTQUFTLEdBQUc7R0FDeEIsSUFBSSxDQUFDLFVBQ0gsT0FBTyxLQUFLO1FBQ1A7SUFDTCxLQUFLLFFBQVE7SUFDYixXQUFXLEtBQUssT0FBTyxZQUFZO0lBQ25DLFNBQVMsZUFBZSxLQUFLLFlBQVk7R0FDM0M7R0FFQSxPQUFPO0VBQ1Q7RUFFQSxPQUFPLEtBQUs7Q0FDZDtDQUVBLE9BQU8sT0FBTyxTQUFTLEtBQUssYUFBYTtFQUN2QyxJQUFJLE9BQU8sTUFDUCxXQUFXLEtBQUs7RUFDcEIsT0FBTyxJQUFJLFFBQVEsU0FBVSxTQUFTO0dBQ3BDLElBQUksSUFBSSxZQUFZLFdBQVcsSUFBSSxjQUFjLGNBQzdDLFdBQVcsU0FBUyxXQUFXO0lBQ2pDLElBQUksUUFBUSxLQUFLO0lBQ2pCLEtBQUssT0FBTztJQUVaLFlBQVksU0FBUztJQUNyQixZQUFZLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxPQUFPLEVBQUUsUUFBUSxNQUFNLFVBQVUsS0FBSyxPQUFPO0lBQzFFLFFBQVEsQ0FBQztJQUNULEtBQUssT0FBTztHQUNkO0dBRUEsSUFBSSxLQUFLLFlBQVksS0FBSyxjQUFjLE1BQU0sS0FBSyxLQUFLLE9BQU8sS0FBSyxDQUFDLEtBQUssVUFBVSxLQUFLLE1BQU0sR0FDN0YsU0FBUztRQUVULEtBQUssUUFBUTtFQUVqQixDQUFDO0NBQ0g7Q0FFQSxPQUFPLE9BQU8sU0FBUyxPQUFPO0VBQzVCLFdBQVcsSUFBSTtDQUNqQjtDQUVBLE9BQU87QUFDVCxFQUFFO0FBRUYsYUFBYSxVQUFVLFdBQVc7Q0FDaEMsT0FBTztDQUNQLFFBQVE7Q0FDUixNQUFNO0NBQ04sUUFBUTtDQUNSLE9BQU87Q0FDUCxRQUFRO0NBQ1IsU0FBUztDQUNULE9BQU87Q0FDUCxRQUFRO0NBQ1IsVUFBVTtDQUNWLFNBQVM7Q0FDVCxLQUFLO0NBQ0wsS0FBSztDQUNMLE9BQU87Q0FDUCxRQUFRLENBQUM7Q0FDVCxPQUFPO0NBQ1AsS0FBSztDQUNMLE1BQU07QUFDUixDQUFDO0FBUUQsSUFBVyxXQUF3Qix1QkFBVSxZQUFZO0NBQ3ZELGVBQWUsVUFBVSxVQUFVO0NBRW5DLFNBQVMsU0FBUyxNQUFNLFVBQVU7RUFDaEMsSUFBSTtFQUVKLElBQUksU0FBUyxLQUFLLEdBQ2hCLE9BQU8sQ0FBQztFQUdWLFFBQVEsV0FBVyxLQUFLLE1BQU0sSUFBSSxLQUFLO0VBQ3ZDLE1BQU0sU0FBUyxDQUFDO0VBQ2hCLE1BQU0sb0JBQW9CLENBQUMsQ0FBQyxLQUFLO0VBQ2pDLE1BQU0scUJBQXFCLENBQUMsQ0FBQyxLQUFLO0VBQ2xDLE1BQU0sUUFBUSxZQUFZLEtBQUssWUFBWTtFQUMzQyxtQkFBbUIsZUFBZSxLQUFLLFVBQVUsaUJBQWlCLHVCQUF1QixLQUFLLEdBQUcsUUFBUTtFQUN6RyxLQUFLLFlBQVksTUFBTSxRQUFRO0VBQy9CLEtBQUssVUFBVSxNQUFNLE9BQU8sSUFBSTtFQUNoQyxLQUFLLGlCQUFpQixlQUFlLHVCQUF1QixLQUFLLEdBQUcsS0FBSyxhQUFhO0VBQ3RGLE9BQU87Q0FDVDtDQUVBLElBQUksVUFBVSxTQUFTO0NBRXZCLFFBQVEsS0FBSyxTQUFTLEdBQUcsU0FBUyxNQUFNLFVBQVU7RUFDaEQsaUJBQWlCLEdBQUcsV0FBVyxJQUFJO0VBRW5DLE9BQU87Q0FDVDtDQUVBLFFBQVEsT0FBTyxTQUFTLEtBQUssU0FBUyxNQUFNLFVBQVU7RUFDcEQsaUJBQWlCLEdBQUcsV0FBVyxJQUFJO0VBRW5DLE9BQU87Q0FDVDtDQUVBLFFBQVEsU0FBUyxTQUFTLE9BQU8sU0FBUyxVQUFVLFFBQVEsVUFBVTtFQUNwRSxpQkFBaUIsR0FBRyxXQUFXLElBQUk7RUFFbkMsT0FBTztDQUNUO0NBRUEsUUFBUSxNQUFNLFNBQVMsSUFBSSxTQUFTLE1BQU0sVUFBVTtFQUNsRCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxTQUFTO0VBQ2QsaUJBQWlCLElBQUksQ0FBQyxDQUFDLGdCQUFnQixLQUFLLFNBQVM7RUFDckQsS0FBSyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUs7RUFDOUIsSUFBSSxNQUFNLFNBQVMsTUFBTSxlQUFlLE1BQU0sUUFBUSxHQUFHLENBQUM7RUFDMUQsT0FBTztDQUNUO0NBRUEsUUFBUSxPQUFPLFNBQVMsS0FBSyxVQUFVLFFBQVEsVUFBVTtFQUN2RCxPQUFPLGVBQWUsTUFBTSxNQUFNLFlBQVksR0FBRyxVQUFVLE1BQU0sR0FBRyxRQUFRO0NBQzlFO0NBR0EsUUFBUSxZQUFZLFNBQVMsVUFBVSxTQUFTLFVBQVUsTUFBTSxTQUFTLFVBQVUsZUFBZSxxQkFBcUI7RUFDckgsS0FBSyxXQUFXO0VBQ2hCLEtBQUssVUFBVSxLQUFLLFdBQVc7RUFDL0IsS0FBSyxhQUFhO0VBQ2xCLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssU0FBUztFQUNkLElBQUksTUFBTSxTQUFTLE1BQU0sZUFBZSxNQUFNLFFBQVEsQ0FBQztFQUN2RCxPQUFPO0NBQ1Q7Q0FFQSxRQUFRLGNBQWMsU0FBUyxZQUFZLFNBQVMsVUFBVSxNQUFNLFNBQVMsVUFBVSxlQUFlLHFCQUFxQjtFQUN6SCxLQUFLLGVBQWU7RUFDcEIsaUJBQWlCLElBQUksQ0FBQyxDQUFDLGtCQUFrQixZQUFZLEtBQUssZUFBZTtFQUN6RSxPQUFPLEtBQUssVUFBVSxTQUFTLFVBQVUsTUFBTSxTQUFTLFVBQVUsZUFBZSxtQkFBbUI7Q0FDdEc7Q0FFQSxRQUFRLGdCQUFnQixTQUFTLGNBQWMsU0FBUyxVQUFVLFVBQVUsUUFBUSxTQUFTLFVBQVUsZUFBZSxxQkFBcUI7RUFDekksT0FBTyxVQUFVO0VBQ2pCLGlCQUFpQixNQUFNLENBQUMsQ0FBQyxrQkFBa0IsWUFBWSxPQUFPLGVBQWU7RUFDN0UsT0FBTyxLQUFLLFVBQVUsU0FBUyxVQUFVLFFBQVEsU0FBUyxVQUFVLGVBQWUsbUJBQW1CO0NBQ3hHO0NBRUEsUUFBUSxTQUFTLFNBQVMsT0FBTyxXQUFXLGdCQUFnQixPQUFPO0VBQ2pFLElBQUksV0FBVyxLQUFLLE9BQ2hCLE9BQU8sS0FBSyxTQUFTLEtBQUssY0FBYyxJQUFJLEtBQUssT0FDakQsTUFBTSxLQUFLLE1BQ1gsUUFBUSxhQUFhLElBQUksSUFBSSxjQUFjLFNBQVMsR0FFeEQsZ0JBQWdCLEtBQUssU0FBUyxNQUFNLFlBQVksTUFBTSxLQUFLLFlBQVksQ0FBQyxNQUNwRSxNQUNBLE9BQ0EsTUFDQSxXQUNBLGVBQ0EsWUFDQSxZQUNBLFdBQ0EsV0FDQSxlQUNBLE1BQ0E7RUFDSixTQUFTLG1CQUFtQixRQUFRLFFBQVEsYUFBYSxNQUFNLFFBQVE7RUFFdkUsSUFBSSxVQUFVLEtBQUssVUFBVSxTQUFTLGVBQWU7R0FDbkQsSUFBSSxhQUFhLEtBQUssU0FBUyxLQUFLO0lBRWxDLFNBQVMsS0FBSyxRQUFRO0lBQ3RCLGFBQWEsS0FBSyxRQUFRO0dBQzVCO0dBRUEsT0FBTztHQUNQLFlBQVksS0FBSztHQUNqQixZQUFZLEtBQUs7R0FDakIsYUFBYSxDQUFDO0dBRWQsSUFBSSxlQUFlO0lBQ2pCLFFBQVEsV0FBVyxLQUFLO0lBRXhCLENBQUMsYUFBYSxDQUFDLG9CQUFvQixLQUFLLFNBQVM7R0FDbkQ7R0FFQSxJQUFJLEtBQUssU0FBUztJQUVoQixPQUFPLEtBQUs7SUFDWixnQkFBZ0IsTUFBTSxLQUFLO0lBRTNCLElBQUksS0FBSyxVQUFVLE1BQU0sWUFBWSxHQUNuQyxPQUFPLEtBQUssVUFBVSxnQkFBZ0IsTUFBTSxXQUFXLGdCQUFnQixLQUFLO0lBRzlFLE9BQU8sY0FBYyxRQUFRLGFBQWE7SUFFMUMsSUFBSSxVQUFVLE1BQU07S0FFbEIsWUFBWSxLQUFLO0tBQ2pCLE9BQU87SUFDVCxPQUFPO0tBQ0wsZ0JBQWdCLGNBQWMsUUFBUSxhQUFhO0tBRW5ELFlBQVksQ0FBQyxDQUFDO0tBRWQsSUFBSSxhQUFhLGNBQWMsZUFBZTtNQUM1QyxPQUFPO01BQ1A7S0FDRjtLQUVBLE9BQU8sUUFBUSxPQUFPO0lBQ3hCO0lBRUEsZ0JBQWdCLGdCQUFnQixLQUFLLFFBQVEsYUFBYTtJQUMxRCxDQUFDLFlBQVksS0FBSyxVQUFVLGtCQUFrQixhQUFhLEtBQUssU0FBUyxnQkFBZ0IsZ0JBQWdCLEtBQUssUUFBUSxNQUFNLGdCQUFnQjtJQUU1SSxJQUFJLFFBQVEsWUFBWSxHQUFHO0tBQ3pCLE9BQU8sTUFBTTtLQUNiLFNBQVM7SUFDWDtJQVdBLElBQUksY0FBYyxpQkFBaUIsQ0FBQyxLQUFLLE9BQU87S0FDOUMsSUFBSSxZQUFZLFFBQVEsZ0JBQWdCLEdBQ3BDLFdBQVcsZUFBZSxRQUFRLFlBQVk7S0FDbEQsWUFBWSxrQkFBa0IsWUFBWSxDQUFDO0tBQzNDLFdBQVcsWUFBWSxJQUFJLFFBQVEsTUFBTSxNQUFNO0tBRS9DLEtBQUssUUFBUTtLQUNiLEtBQUssT0FBTyxhQUFhLFNBQVMsSUFBSSxjQUFjLFlBQVksYUFBYSxJQUFJLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVE7S0FDL0csS0FBSyxTQUFTO0tBRWQsQ0FBQyxrQkFBa0IsS0FBSyxVQUFVLFVBQVUsTUFBTSxVQUFVO0tBRTVELElBQUksS0FBSyxLQUFLLGlCQUFpQixDQUFDLFFBQVE7TUFDdEMsS0FBSyxXQUFXLENBQUMsQ0FBQyxRQUFRO01BQzFCLGdCQUFnQjtLQUNsQjtLQUVBLElBQUksWUFBWSxhQUFhLEtBQUssU0FBUyxlQUFlLENBQUMsS0FBSyxPQUFPLEtBQUssS0FBSyxZQUFZLENBQUMsS0FBSyxVQUFVLENBQUMsS0FBSyxNQUVqSCxPQUFPO0tBR1QsTUFBTSxLQUFLO0tBRVgsT0FBTyxLQUFLO0tBRVosSUFBSSxVQUFVO01BQ1osS0FBSyxRQUFRO01BQ2IsV0FBVyxZQUFZLE1BQU07TUFDN0IsS0FBSyxPQUFPLFVBQVUsSUFBSTtNQUMxQixLQUFLLEtBQUssaUJBQWlCLENBQUMsVUFBVSxLQUFLLFdBQVc7S0FDeEQ7S0FFQSxLQUFLLFFBQVE7S0FFYixJQUFJLENBQUMsS0FBSyxPQUFPLENBQUMsWUFDaEIsT0FBTztJQUVYO0dBQ0Y7R0FFQSxJQUFJLEtBQUssYUFBYSxDQUFDLEtBQUssWUFBWSxLQUFLLFFBQVEsR0FBRztJQUN0RCxhQUFhLG9CQUFvQixNQUFNLGNBQWMsUUFBUSxHQUFHLGNBQWMsSUFBSSxDQUFDO0lBRW5GLElBQUksWUFDRixTQUFTLFFBQVEsT0FBTyxXQUFXO0dBRXZDO0dBRUEsS0FBSyxTQUFTO0dBQ2QsS0FBSyxRQUFRO0dBQ2IsS0FBSyxPQUFPLENBQUMsQ0FBQztHQUVkLElBQUksQ0FBQyxLQUFLLFVBQVU7SUFDbEIsS0FBSyxZQUFZLEtBQUssS0FBSztJQUMzQixLQUFLLFdBQVc7SUFDaEIsS0FBSyxTQUFTO0lBQ2QsV0FBVztHQUNiO0dBRUEsSUFBSSxDQUFDLFlBQVksU0FBUyxPQUFPLENBQUMsa0JBQWtCLENBQUMsZUFBZTtJQUNsRSxVQUFVLE1BQU0sU0FBUztJQUV6QixJQUFJLEtBQUssV0FBVyxPQUVsQixPQUFPO0dBRVg7R0FFQSxJQUFJLFFBQVEsWUFBWSxhQUFhLEdBQUc7SUFDdEMsUUFBUSxLQUFLO0lBRWIsT0FBTyxPQUFPO0tBQ1osT0FBTyxNQUFNO0tBRWIsS0FBSyxNQUFNLFFBQVEsUUFBUSxNQUFNLFdBQVcsTUFBTSxPQUFPLGVBQWUsT0FBTztNQUM3RSxJQUFJLE1BQU0sV0FBVyxNQUVuQixPQUFPLEtBQUssT0FBTyxXQUFXLGdCQUFnQixLQUFLO01BR3JELE1BQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxPQUFPLE1BQU0sVUFBVSxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU0sY0FBYyxJQUFJLE1BQU0sVUFBVSxPQUFPLE1BQU0sVUFBVSxNQUFNLEtBQUssZ0JBQWdCLEtBQUs7TUFFaEwsSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDLEtBQUssT0FBTyxDQUFDLFlBQVk7T0FFbkQsYUFBYTtPQUNiLFNBQVMsU0FBUyxLQUFLLFNBQVMsQ0FBQztPQUVqQztNQUNGO0tBQ0Y7S0FFQSxRQUFRO0lBQ1Y7R0FDRixPQUFPO0lBQ0wsUUFBUSxLQUFLO0lBQ2IsSUFBSSxlQUFlLFlBQVksSUFBSSxZQUFZO0lBRS9DLE9BQU8sT0FBTztLQUNaLE9BQU8sTUFBTTtLQUViLEtBQUssTUFBTSxRQUFRLGdCQUFnQixNQUFNLFNBQVMsTUFBTSxPQUFPLGVBQWUsT0FBTztNQUNuRixJQUFJLE1BQU0sV0FBVyxNQUVuQixPQUFPLEtBQUssT0FBTyxXQUFXLGdCQUFnQixLQUFLO01BR3JELE1BQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxlQUFlLE1BQU0sVUFBVSxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU0sY0FBYyxJQUFJLE1BQU0sVUFBVSxlQUFlLE1BQU0sVUFBVSxNQUFNLEtBQUssZ0JBQWdCLFNBQVNBLGdCQUFjLGdCQUFnQixLQUFLLENBQUM7TUFFeE8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDLEtBQUssT0FBTyxDQUFDLFlBQVk7T0FFbkQsYUFBYTtPQUNiLFNBQVMsU0FBUyxLQUFLLFNBQVMsZUFBZSxDQUFDLFdBQVc7T0FFM0Q7TUFDRjtLQUNGO0tBRUEsUUFBUTtJQUNWO0dBQ0Y7R0FFQSxJQUFJLGNBQWMsQ0FBQyxnQkFBZ0I7SUFDakMsS0FBSyxNQUFNO0lBQ1gsV0FBVyxPQUFPLFFBQVEsV0FBVyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxRQUFRLFdBQVcsSUFBSTtJQUVwRixJQUFJLEtBQUssS0FBSztLQUVaLEtBQUssU0FBUztLQUVkLFFBQVEsSUFBSTtLQUVaLE9BQU8sS0FBSyxPQUFPLFdBQVcsZ0JBQWdCLEtBQUs7SUFDckQ7R0FDRjtHQUVBLEtBQUssYUFBYSxDQUFDLGtCQUFrQixVQUFVLE1BQU0sWUFBWSxJQUFJO0dBQ3JFLElBQUksVUFBVSxRQUFRLEtBQUssVUFBVSxLQUFLLGNBQWMsS0FBSyxDQUFDLFNBQVM7UUFBYyxjQUFjLEtBQUssVUFBVSxLQUFLLElBQUksU0FBUyxNQUFNLEtBQUssSUFBSSxLQUFLLEdBQUc7U0FBTyxDQUFDLEtBQUssT0FBTztNQUU3SyxDQUFDLGFBQWEsQ0FBQyxTQUFTLFVBQVUsUUFBUSxLQUFLLE1BQU0sS0FBSyxDQUFDLFNBQVMsS0FBSyxNQUFNLE1BQU0sa0JBQWtCLE1BQU0sQ0FBQztNQUU5RyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsWUFBWSxLQUFLLENBQUMsY0FBYyxTQUFTLFlBQVksQ0FBQyxPQUFPO09BQ3BGLFVBQVUsTUFBTSxVQUFVLFFBQVEsYUFBYSxJQUFJLGVBQWUscUJBQXFCLElBQUk7T0FFM0YsS0FBSyxTQUFTLEVBQUUsUUFBUSxRQUFRLEtBQUssVUFBVSxJQUFJLE1BQU0sS0FBSyxNQUFNO01BQ3RFO0tBQ0Y7OztFQUNGO0VBRUEsT0FBTztDQUNUO0NBRUEsUUFBUSxNQUFNLFNBQVMsSUFBSSxPQUFPLFVBQVU7RUFDMUMsSUFBSSxTQUFTO0VBRWIsVUFBVSxRQUFRLE1BQU0sV0FBVyxlQUFlLE1BQU0sVUFBVSxLQUFLO0VBRXZFLElBQUksRUFBRSxpQkFBaUIsWUFBWTtHQUNqQyxJQUFJLFNBQVMsS0FBSyxHQUFHO0lBQ25CLE1BQU0sUUFBUSxTQUFVLEtBQUs7S0FDM0IsT0FBTyxPQUFPLElBQUksS0FBSyxRQUFRO0lBQ2pDLENBQUM7SUFDRCxPQUFPO0dBQ1Q7R0FFQSxJQUFJLFVBQVUsS0FBSyxHQUNqQixPQUFPLEtBQUssU0FBUyxPQUFPLFFBQVE7R0FHdEMsSUFBSSxZQUFZLEtBQUssR0FDbkIsUUFBUSxNQUFNLFlBQVksR0FBRyxLQUFLO1FBRWxDLE9BQU87RUFFWDtFQUVBLE9BQU8sU0FBUyxRQUFRLGVBQWUsTUFBTSxPQUFPLFFBQVEsSUFBSTtDQUNsRTtDQUVBLFFBQVEsY0FBYyxTQUFTLFlBQVksUUFBUSxRQUFRLFdBQVcsa0JBQWtCO0VBQ3RGLElBQUksV0FBVyxLQUFLLEdBQ2xCLFNBQVM7RUFHWCxJQUFJLFdBQVcsS0FBSyxHQUNsQixTQUFTO0VBR1gsSUFBSSxjQUFjLEtBQUssR0FDckIsWUFBWTtFQUdkLElBQUkscUJBQXFCLEtBQUssR0FDNUIsbUJBQW1CLENBQUNDO0VBR3RCLElBQUksSUFBSSxDQUFDLEdBQ0wsUUFBUSxLQUFLO0VBRWpCLE9BQU8sT0FBTztHQUNaLElBQUksTUFBTSxVQUFVLGtCQUNsQixJQUFJLGlCQUFpQixPQUNuQixVQUFVLEVBQUUsS0FBSyxLQUFLO1FBQ2pCO0lBQ0wsYUFBYSxFQUFFLEtBQUssS0FBSztJQUN6QixVQUFVLEVBQUUsS0FBSyxNQUFNLEdBQUcsTUFBTSxZQUFZLE1BQU0sUUFBUSxTQUFTLENBQUM7R0FDdEU7R0FHRixRQUFRLE1BQU07RUFDaEI7RUFFQSxPQUFPO0NBQ1Q7Q0FFQSxRQUFRLFVBQVUsU0FBUyxRQUFRLElBQUk7RUFDckMsSUFBSSxhQUFhLEtBQUssWUFBWSxHQUFHLEdBQUcsQ0FBQyxHQUNyQyxJQUFJLFdBQVc7RUFFbkIsT0FBTyxLQUNMLElBQUksV0FBVyxFQUFFLENBQUMsS0FBSyxPQUFPLElBQzVCLE9BQU8sV0FBVztDQUd4QjtDQUVBLFFBQVEsU0FBUyxTQUFTLE9BQU8sT0FBTztFQUN0QyxJQUFJLFVBQVUsS0FBSyxHQUNqQixPQUFPLEtBQUssWUFBWSxLQUFLO0VBRy9CLElBQUksWUFBWSxLQUFLLEdBQ25CLE9BQU8sS0FBSyxhQUFhLEtBQUs7RUFHaEMsTUFBTSxXQUFXLFFBQVEsc0JBQXNCLE1BQU0sS0FBSztFQUUxRCxJQUFJLFVBQVUsS0FBSyxTQUNqQixLQUFLLFVBQVUsS0FBSztFQUd0QixPQUFPLFNBQVMsSUFBSTtDQUN0QjtDQUVBLFFBQVEsWUFBWSxTQUFTLFVBQVUsYUFBYSxnQkFBZ0I7RUFDbEUsSUFBSSxDQUFDLFVBQVUsUUFDYixPQUFPLEtBQUs7RUFHZCxLQUFLLFdBQVc7RUFFaEIsSUFBSSxDQUFDLEtBQUssT0FBTyxLQUFLLEtBRXBCLEtBQUssU0FBUyxjQUFjLFFBQVEsUUFBUSxLQUFLLE1BQU0sSUFBSSxjQUFjLEtBQUssT0FBTyxLQUFLLGNBQWMsSUFBSSxlQUFlLENBQUMsS0FBSyxJQUFJO0VBR3ZJLFdBQVcsVUFBVSxVQUFVLEtBQUssTUFBTSxhQUFhLGNBQWM7RUFFckUsS0FBSyxXQUFXO0VBQ2hCLE9BQU87Q0FDVDtDQUVBLFFBQVEsV0FBVyxTQUFTLFNBQVMsT0FBTyxVQUFVO0VBQ3BELEtBQUssT0FBTyxTQUFTLGVBQWUsTUFBTSxRQUFRO0VBQ2xELE9BQU87Q0FDVDtDQUVBLFFBQVEsY0FBYyxTQUFTLFlBQVksT0FBTztFQUNoRCxPQUFPLEtBQUssT0FBTztFQUNuQixPQUFPO0NBQ1Q7Q0FFQSxRQUFRLFdBQVcsU0FBUyxTQUFTLFVBQVUsVUFBVSxRQUFRO0VBQy9ELElBQUksSUFBSSxNQUFNLFlBQVksR0FBRyxZQUFZLFlBQVksTUFBTTtFQUMzRCxFQUFFLE9BQU87RUFDVCxLQUFLLFlBQVk7RUFDakIsT0FBTyxlQUFlLE1BQU0sR0FBRyxlQUFlLE1BQU0sUUFBUSxDQUFDO0NBQy9EO0NBRUEsUUFBUSxjQUFjLFNBQVMsWUFBWSxVQUFVO0VBQ25ELElBQUksUUFBUSxLQUFLO0VBQ2pCLFdBQVcsZUFBZSxNQUFNLFFBQVE7RUFFeEMsT0FBTyxPQUFPO0dBQ1osSUFBSSxNQUFNLFdBQVcsWUFBWSxNQUFNLFNBQVMsV0FDOUMsa0JBQWtCLEtBQUs7R0FHekIsUUFBUSxNQUFNO0VBQ2hCO0NBQ0Y7Q0FFQSxRQUFRLGVBQWUsU0FBUyxhQUFhLFNBQVMsT0FBTyxZQUFZO0VBQ3ZFLElBQUksU0FBUyxLQUFLLFlBQVksU0FBUyxVQUFVLEdBQzdDLElBQUksT0FBTztFQUVmLE9BQU8sS0FDTCxzQkFBc0IsT0FBTyxNQUFNLE9BQU8sRUFBRSxDQUFDLEtBQUssU0FBUyxLQUFLO0VBR2xFLE9BQU87Q0FDVDtDQUVBLFFBQVEsY0FBYyxTQUFTLFlBQVksU0FBUyxZQUFZO0VBQzlELElBQUksSUFBSSxDQUFDLEdBQ0wsZ0JBQWdCLFFBQVEsT0FBTyxHQUMvQixRQUFRLEtBQUssUUFDYixlQUFlLFVBQVUsVUFBVSxHQUV2QztFQUVBLE9BQU8sT0FBTztHQUNaLElBQUksaUJBQWlCO1FBQ2Ysa0JBQWtCLE1BQU0sVUFBVSxhQUFhLE1BQU0sZ0JBQWdCLENBQUMscUJBQXFCLE1BQU0sWUFBWSxNQUFNLFFBQVEsTUFBTSxXQUFXLENBQUMsS0FBSyxjQUFjLE1BQU0sV0FBVyxNQUFNLGNBQWMsQ0FBQyxJQUFJLGFBQWEsQ0FBQyxjQUFjLE1BQU0sU0FBUyxJQUV2UCxFQUFFLEtBQUssS0FBSztHQUFBLE9BRVQsS0FBSyxXQUFXLE1BQU0sWUFBWSxlQUFlLFVBQVUsRUFBQSxDQUFHLFFBQ25FLEVBQUUsS0FBSyxNQUFNLEdBQUcsUUFBUTtHQUcxQixRQUFRLE1BQU07RUFDaEI7RUFFQSxPQUFPO0NBQ1Q7Q0FRQSxRQUFRLFVBQVUsU0FBUyxRQUFRLFVBQVUsTUFBTTtFQUNqRCxPQUFPLFFBQVEsQ0FBQztFQUVoQixJQUFJLEtBQUssTUFDTCxVQUFVLGVBQWUsSUFBSSxRQUFRLEdBQ3JDLFFBQVEsTUFDUixVQUFVLE1BQU0sU0FDaEIsV0FBVyxNQUFNLFNBQ2pCLGdCQUFnQixNQUFNLGVBQ3RCLGtCQUFrQixNQUFNLGlCQUN4QixTQUNBLFFBQVEsTUFBTSxHQUFHLElBQUksYUFBYTtHQUNwQyxNQUFNLEtBQUssUUFBUTtHQUNuQixNQUFNO0dBQ04saUJBQWlCO0dBQ2pCLE1BQU07R0FDTixXQUFXO0dBQ1gsVUFBVSxLQUFLLFlBQVksS0FBSyxLQUFLLFdBQVcsV0FBVyxVQUFVLFVBQVUsUUFBUSxPQUFPLEdBQUcsVUFBVSxHQUFHLFVBQVUsQ0FBQyxLQUFLO0dBQzlILFNBQVMsU0FBUyxVQUFVO0lBQzFCLEdBQUcsTUFBTTtJQUVULElBQUksQ0FBQyxTQUFTO0tBQ1osSUFBSSxXQUFXLEtBQUssWUFBWSxLQUFLLEtBQUssV0FBVyxXQUFXLFVBQVUsVUFBVSxRQUFRLE9BQU8sR0FBRyxVQUFVLEdBQUcsVUFBVSxDQUFDO0tBQzlILE1BQU0sU0FBUyxZQUFZLGFBQWEsT0FBTyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxNQUFNLE9BQU8sTUFBTSxJQUFJO0tBQzdGLFVBQVU7SUFDWjtJQUVBLFlBQVksU0FBUyxNQUFNLE9BQU8saUJBQWlCLENBQUMsQ0FBQztHQUN2RDtFQUNGLEdBQUcsSUFBSSxDQUFDO0VBRVIsT0FBTyxrQkFBa0IsTUFBTSxPQUFPLENBQUMsSUFBSTtDQUM3QztDQUVBLFFBQVEsY0FBYyxTQUFTLFlBQVksY0FBYyxZQUFZLE1BQU07RUFDekUsT0FBTyxLQUFLLFFBQVEsWUFBWSxhQUFhLEVBQzNDLFNBQVMsRUFDUCxNQUFNLGVBQWUsTUFBTSxZQUFZLEVBQ3pDLEVBQ0YsR0FBRyxJQUFJLENBQUM7Q0FDVjtDQUVBLFFBQVEsU0FBUyxTQUFTLFNBQVM7RUFDakMsT0FBTyxLQUFLO0NBQ2Q7Q0FFQSxRQUFRLFlBQVksU0FBUyxVQUFVLFdBQVc7RUFDaEQsSUFBSSxjQUFjLEtBQUssR0FDckIsWUFBWSxLQUFLO0VBR25CLE9BQU8scUJBQXFCLE1BQU0sZUFBZSxNQUFNLFNBQVMsQ0FBQztDQUNuRTtDQUVBLFFBQVEsZ0JBQWdCLFNBQVMsY0FBYyxZQUFZO0VBQ3pELElBQUksZUFBZSxLQUFLLEdBQ3RCLGFBQWEsS0FBSztFQUdwQixPQUFPLHFCQUFxQixNQUFNLGVBQWUsTUFBTSxVQUFVLEdBQUcsQ0FBQztDQUN2RTtDQUVBLFFBQVEsZUFBZSxTQUFTLGFBQWEsT0FBTztFQUNsRCxPQUFPLFVBQVUsU0FBUyxLQUFLLEtBQUssT0FBTyxJQUFJLElBQUksS0FBSyxjQUFjLEtBQUssUUFBUSxRQUFRO0NBQzdGO0NBRUEsUUFBUSxnQkFBZ0IsU0FBUyxjQUFjLFFBQVEsY0FBYyxrQkFBa0I7RUFDckYsSUFBSSxxQkFBcUIsS0FBSyxHQUM1QixtQkFBbUI7RUFHckIsSUFBSSxRQUFRLEtBQUssUUFDYixTQUFTLEtBQUssUUFDZDtFQUNKLFNBQVMsY0FBYyxNQUFNO0VBRTdCLE9BQU8sT0FBTztHQUNaLElBQUksTUFBTSxVQUFVLGtCQUFrQjtJQUNwQyxNQUFNLFVBQVU7SUFDaEIsTUFBTSxRQUFRO0dBQ2hCO0dBRUEsUUFBUSxNQUFNO0VBQ2hCO0VBRUEsSUFBSTtRQUNHLEtBQUssUUFDUixJQUFJLE9BQU8sTUFBTSxrQkFDZixPQUFPLE1BQU07RUFBQTtFQUtuQixPQUFPLFNBQVMsSUFBSTtDQUN0QjtDQUVBLFFBQVEsYUFBYSxTQUFTLFdBQVcsTUFBTTtFQUM3QyxJQUFJLFFBQVEsS0FBSztFQUNqQixLQUFLLFFBQVE7RUFFYixPQUFPLE9BQU87R0FDWixNQUFNLFdBQVcsSUFBSTtHQUNyQixRQUFRLE1BQU07RUFDaEI7RUFFQSxPQUFPLFdBQVcsVUFBVSxXQUFXLEtBQUssTUFBTSxJQUFJO0NBQ3hEO0NBRUEsUUFBUSxRQUFRLFNBQVMsTUFBTSxlQUFlO0VBQzVDLElBQUksa0JBQWtCLEtBQUssR0FDekIsZ0JBQWdCO0VBR2xCLElBQUksUUFBUSxLQUFLLFFBQ2I7RUFFSixPQUFPLE9BQU87R0FDWixPQUFPLE1BQU07R0FDYixLQUFLLE9BQU8sS0FBSztHQUNqQixRQUFRO0VBQ1Y7RUFFQSxLQUFLLFFBQVEsS0FBSyxRQUFRLEtBQUssU0FBUyxLQUFLLFNBQVM7RUFDdEQsa0JBQWtCLEtBQUssU0FBUyxDQUFDO0VBQ2pDLE9BQU8sU0FBUyxJQUFJO0NBQ3RCO0NBRUEsUUFBUSxnQkFBZ0IsU0FBUyxjQUFjLE9BQU87RUFDcEQsSUFBSSxNQUFNLEdBQ04sT0FBTyxNQUNQLFFBQVEsS0FBSyxPQUNiLFlBQVlBLFdBQ1osTUFDQSxPQUNBO0VBRUosSUFBSSxVQUFVLFFBQ1osT0FBTyxLQUFLLFdBQVcsS0FBSyxVQUFVLElBQUksS0FBSyxTQUFTLElBQUksS0FBSyxjQUFjLE1BQU0sS0FBSyxTQUFTLElBQUksQ0FBQyxRQUFRLE1BQU07RUFHeEgsSUFBSSxLQUFLLFFBQVE7R0FDZixTQUFTLEtBQUs7R0FFZCxPQUFPLE9BQU87SUFDWixPQUFPLE1BQU07SUFFYixNQUFNLFVBQVUsTUFBTSxjQUFjO0lBRXBDLFFBQVEsTUFBTTtJQUVkLElBQUksUUFBUSxhQUFhLEtBQUssU0FBUyxNQUFNLE9BQU8sQ0FBQyxLQUFLLE9BQU87S0FFL0QsS0FBSyxRQUFRO0tBRWIsZUFBZSxNQUFNLE9BQU8sUUFBUSxNQUFNLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUTtJQUMvRCxPQUNFLFlBQVk7SUFHZCxJQUFJLFFBQVEsS0FBSyxNQUFNLEtBQUs7S0FFMUIsT0FBTztLQUVQLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxPQUFPLFVBQVUsT0FBTyxtQkFBbUI7TUFDOUQsS0FBSyxVQUFVLGNBQWMsUUFBUSxLQUFLLEdBQUc7TUFDN0MsS0FBSyxTQUFTO01BQ2QsS0FBSyxVQUFVO0tBQ2pCO0tBRUEsS0FBSyxjQUFjLENBQUMsT0FBTyxPQUFPLFNBQU07S0FDeEMsWUFBWTtJQUNkO0lBRUEsTUFBTSxPQUFPLE9BQU8sTUFBTSxRQUFRLE1BQU0sTUFBTTtJQUM5QyxRQUFRO0dBQ1Y7R0FFQSxhQUFhLE1BQU0sU0FBUyxtQkFBbUIsS0FBSyxRQUFRLE1BQU0sS0FBSyxRQUFRLEtBQUssR0FBRyxDQUFDO0dBRXhGLEtBQUssU0FBUztFQUNoQjtFQUVBLE9BQU8sS0FBSztDQUNkO0NBRUEsU0FBUyxhQUFhLFNBQVMsV0FBVyxNQUFNO0VBQzlDLElBQUksZ0JBQWdCLEtBQUs7R0FDdkIsZ0JBQWdCLGlCQUFpQix3QkFBd0IsTUFBTSxlQUFlLENBQUM7R0FFL0UscUJBQXFCLFFBQVE7RUFDL0I7RUFFQSxJQUFJLFFBQVEsU0FBUyxjQUFjO0dBQ2pDLGdCQUFnQixRQUFRLGFBQWE7R0FDckMsSUFBSSxRQUFRLGdCQUFnQjtHQUM1QixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU07UUFBUyxRQUFRLGFBQWEsUUFBUSxXQUFXLFNBQVMsR0FBRztLQUNoRixPQUFPLFNBQVMsQ0FBQyxNQUFNLEtBQ3JCLFFBQVEsTUFBTTtLQUdoQixTQUFTLFFBQVEsTUFBTTtJQUN6Qjs7RUFDRjtDQUNGO0NBRUEsT0FBTztBQUNULEVBQUUsU0FBUztBQUVYLGFBQWEsU0FBUyxXQUFXO0NBQy9CLE9BQU87Q0FDUCxXQUFXO0NBQ1gsVUFBVTtBQUNaLENBQUM7QUFFRCxJQUFJLDZCQUE2QixTQUFTLDJCQUEyQixRQUFRLE1BQU0sT0FBTyxLQUFLLFFBQVEsY0FBYyxXQUFXO0NBRTlILElBQUksS0FBSyxJQUFJLFVBQVUsS0FBSyxLQUFLLFFBQVEsTUFBTSxHQUFHLEdBQUcsc0JBQXNCLE1BQU0sTUFBTSxHQUNuRixRQUFRLEdBQ1IsYUFBYSxHQUNiLFFBQ0EsV0FDQSxPQUNBLFFBQ0EsT0FDQSxVQUNBLFdBQ0E7Q0FDSixHQUFHLElBQUk7Q0FDUCxHQUFHLElBQUk7Q0FDUCxTQUFTO0NBRVQsT0FBTztDQUVQLElBQUksWUFBWSxDQUFDLElBQUksUUFBUSxTQUFTLEdBQ3BDLE1BQU0sZUFBZSxHQUFHO0NBRzFCLElBQUksY0FBYztFQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHO0VBQ2YsYUFBYSxHQUFHLFFBQVEsSUFBSTtFQUU1QixRQUFRLEVBQUU7RUFDVixNQUFNLEVBQUU7Q0FDVjtDQUVBLFlBQVksTUFBTSxNQUFNLG9CQUFvQixLQUFLLENBQUM7Q0FFbEQsT0FBTyxTQUFTLHFCQUFxQixLQUFLLEdBQUcsR0FBRztFQUM5QyxTQUFTLE9BQU87RUFDaEIsUUFBUSxJQUFJLFVBQVUsT0FBTyxPQUFPLEtBQUs7RUFFekMsSUFBSSxPQUNGLFNBQVMsUUFBUSxLQUFLO09BQ2pCLElBQUksTUFBTSxPQUFPLEVBQUUsTUFBTSxTQUM5QixRQUFRO0VBR1YsSUFBSSxXQUFXLFVBQVUsZUFBZTtHQUN0QyxXQUFXLFdBQVcsVUFBVSxhQUFhLEVBQUUsS0FBSztHQUVwRCxHQUFHLE1BQU07SUFDUCxPQUFPLEdBQUc7SUFDVixHQUFHLFNBQVMsZUFBZSxJQUFJLFFBQVE7SUFFdkMsR0FBRztJQUNILEdBQUcsT0FBTyxPQUFPLENBQUMsTUFBTSxNQUFNLGVBQWUsVUFBVSxNQUFNLElBQUksV0FBVyxXQUFXLE1BQU0sSUFBSTtJQUNqRyxHQUFHLFNBQVMsUUFBUSxJQUFJLEtBQUssUUFBUTtHQUN2QztHQUNBLFFBQVEscUJBQXFCO0VBQy9CO0NBQ0Y7Q0FFQSxHQUFHLElBQUksUUFBUSxJQUFJLFNBQVMsSUFBSSxVQUFVLE9BQU8sSUFBSSxNQUFNLElBQUk7Q0FFL0QsR0FBRyxLQUFLO0NBRVIsSUFBSSxRQUFRLEtBQUssR0FBRyxLQUFLLFdBQ3ZCLEdBQUcsSUFBSTtDQUdULEtBQUssTUFBTTtDQUVYLE9BQU87QUFDVDtJQUNJLGdCQUFnQixTQUFTLGNBQWMsUUFBUSxNQUFNLE9BQU8sS0FBSyxPQUFPLFNBQVMsVUFBVSxjQUFjLFdBQVcsVUFBVTtDQUNoSSxZQUFZLEdBQUcsTUFBTSxNQUFNLElBQUksU0FBUyxHQUFHLFFBQVEsT0FBTztDQUMxRCxJQUFJLGVBQWUsT0FBTyxPQUN0QixjQUFjLFVBQVUsUUFBUSxRQUFRLENBQUMsWUFBWSxZQUFZLElBQUksZUFBZSxZQUFZLE9BQU8sS0FBSyxRQUFRLEtBQUssS0FBSyxDQUFDLFlBQVksT0FBTyxRQUFRLEtBQUssT0FBTyxDQUFDLEVBQUUsSUFBSSxPQUFPLFFBQVEsS0FBSyxPQUFPLENBQUMsRUFBRSxDQUFDLFNBQVMsSUFBSSxPQUFPLEtBQUssQ0FBQyxHQUN0TyxTQUFTLENBQUMsWUFBWSxZQUFZLElBQUksZUFBZSxZQUFZLHVCQUF1QixhQUN4RjtDQUVKLElBQUksVUFBVSxHQUFHLEdBQUc7RUFDbEIsSUFBSSxDQUFDLElBQUksUUFBUSxTQUFTLEdBQ3hCLE1BQU0sZUFBZSxHQUFHO0VBRzFCLElBQUksSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLO0dBQ3pCLEtBQUssZUFBZSxhQUFhLEdBQUcsS0FBSyxRQUFRLFdBQVcsS0FBSztHQUVqRSxJQUFJLE1BQU0sT0FBTyxHQUVmLE1BQU07RUFFVjtDQUNGO0NBRUEsSUFBSSxDQUFDLFlBQVksZ0JBQWdCLE9BQU8scUJBQXFCO0VBQzNELElBQUksQ0FBQyxNQUFNLGNBQWMsR0FBRyxLQUFLLFFBQVEsSUFBSTtHQUUzQyxLQUFLLElBQUksVUFBVSxLQUFLLEtBQUssUUFBUSxNQUFNLENBQUMsZUFBZSxHQUFHLE9BQU8sZUFBZSxJQUFJLE9BQU8saUJBQWlCLFlBQVksaUJBQWlCLGNBQWMsR0FBRyxNQUFNO0dBQ3BLLGNBQWMsR0FBRyxLQUFLO0dBQ3RCLFlBQVksR0FBRyxTQUFTLFVBQVUsTUFBTSxNQUFNO0dBQzlDLE9BQU8sS0FBSyxNQUFNO0VBQ3BCO0VBRUEsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLFdBQVcsZUFBZSxNQUFNLEdBQUc7RUFDOUQsT0FBTywyQkFBMkIsS0FBSyxNQUFNLFFBQVEsTUFBTSxhQUFhLEtBQUssUUFBUSxnQkFBZ0IsUUFBUSxjQUFjLFNBQVM7Q0FDdEk7QUFDRjtJQUVBLGVBQWUsU0FBUyxhQUFhLE1BQU0sT0FBTyxRQUFRLFNBQVMsT0FBTztDQUN4RSxZQUFZLElBQUksTUFBTSxPQUFPLG1CQUFtQixNQUFNLE9BQU8sT0FBTyxRQUFRLE9BQU87Q0FFbkYsSUFBSSxDQUFDLFVBQVUsSUFBSSxLQUFLLEtBQUssU0FBUyxLQUFLLFlBQVksU0FBUyxJQUFJLEtBQUssY0FBYyxJQUFJLEdBQ3pGLE9BQU8sVUFBVSxJQUFJLElBQUksbUJBQW1CLE1BQU0sT0FBTyxPQUFPLFFBQVEsT0FBTyxJQUFJO0NBR3JGLElBQUksT0FBTyxDQUFDLEdBQ1I7Q0FFSixLQUFLLEtBQUssTUFDUixLQUFLLEtBQUssbUJBQW1CLEtBQUssSUFBSSxPQUFPLE9BQU8sUUFBUSxPQUFPO0NBR3JFLE9BQU87QUFDVDtJQUNJLGVBQWUsU0FBUyxhQUFhLFVBQVUsTUFBTSxPQUFPLE9BQU8sUUFBUSxTQUFTO0NBQ3RGLElBQUksUUFBUSxJQUFJLFVBQVU7Q0FFMUIsSUFBSSxTQUFTLGNBQWMsU0FBUyxJQUFJLFNBQVMsVUFBVSxFQUFBLENBQUcsS0FBSyxRQUFRLE9BQU8sVUFBVSxLQUFLLFlBQVksYUFBYSxLQUFLLFdBQVcsT0FBTyxRQUFRLFNBQVMsS0FBSyxHQUFHLE9BQU8sT0FBTyxPQUFPLE1BQU0sT0FBTztFQUMxTSxNQUFNLE1BQU0sS0FBSyxJQUFJLFVBQVUsTUFBTSxLQUFLLFFBQVEsVUFBVSxHQUFHLEdBQUcsT0FBTyxRQUFRLFFBQVEsR0FBRyxPQUFPLFFBQVE7RUFFM0csSUFBSSxVQUFVLGFBQWE7R0FDekIsV0FBVyxNQUFNLFVBQVUsTUFBTSxTQUFTLFFBQVEsTUFBTTtHQUV4RCxJQUFJLE9BQU8sT0FBTztHQUVsQixPQUFPLEtBQ0wsU0FBUyxPQUFPLE9BQU8sTUFBTTtFQUVqQztDQUNGO0NBRUEsT0FBTztBQUNUO0lBQ0k7SUFFSjtJQUNJLGFBQWEsU0FBUyxXQUFXLE9BQU8sTUFBTSxPQUFPO0NBQ3ZELElBQUksT0FBTyxNQUFNLE1BQ2IsT0FBTyxLQUFLLE1BQ1osVUFBVSxLQUFLLFNBQ2Ysa0JBQWtCLEtBQUssaUJBQ3ZCLE9BQU8sS0FBSyxNQUNaLFdBQVcsS0FBSyxVQUNoQixlQUFlLEtBQUssY0FDcEIsV0FBVyxLQUFLLFVBQ2hCLFlBQVksS0FBSyxXQUNqQixhQUFhLEtBQUssWUFDbEIsTUFBTSxNQUFNLE1BQ1osY0FBYyxNQUFNLFVBQ3BCLFVBQVUsTUFBTSxVQUNoQixTQUFTLE1BQU0sUUFDZixjQUFjLFVBQVUsT0FBTyxTQUFTLFdBQVcsT0FBTyxLQUFLLFVBQVUsU0FDekUsZ0JBQWdCLE1BQU0sZUFBZSxVQUFVLENBQUMscUJBQ2hELEtBQUssTUFBTSxVQUNYLGNBQWMsS0FBSyxlQUFlLFVBQ2xDLFdBQ0EsR0FDQSxHQUNBLElBQ0EsUUFDQSxhQUNBLFFBQ0EsU0FDQSxRQUNBLFVBQ0EsT0FDQSxhQUNBO0NBQ0osT0FBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLE9BQU87Q0FDdkMsTUFBTSxRQUFRLFdBQVcsTUFBTSxVQUFVLElBQUk7Q0FDN0MsTUFBTSxTQUFTLGdCQUFnQixXQUFXLFdBQVcsS0FBSyxNQUFNO0NBQ2hFLE1BQU0sUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUs7Q0FFNUIsSUFBSSxNQUFNLE9BQU8sTUFBTSxRQUFRO0NBRS9CLElBQUksQ0FBQyxNQUFNLGFBQWEsQ0FBQyxLQUFLLFNBQVM7RUFFckMsVUFBVSxRQUFRLEtBQUssVUFBVSxRQUFRLEVBQUUsQ0FBQyxDQUFDLFVBQVU7RUFDdkQsY0FBYyxXQUFXLEtBQUssUUFBUTtFQUV0QyxZQUFZLGVBQWUsTUFBTSxjQUFjO0VBRS9DLElBQUksYUFBYTtHQUNmLFlBQVksU0FBUyxLQUFLLFlBQVksU0FBUyxDQUFDO0dBRWhELE9BQU8sS0FBSyxnQkFBZ0IsbUJBQW1CLENBQUMsYUFBYSxZQUFZLE9BQU8sSUFBSSxJQUFJLElBQUksWUFBWSxPQUFPLGdCQUFnQixNQUFNLHNCQUFzQixvQkFBb0I7R0FHL0ssWUFBWSxRQUFRO0VBQ3RCO0VBRUEsSUFBSSxTQUFTO0dBQ1gsa0JBQWtCLE1BQU0sV0FBVyxNQUFNLElBQUksU0FBUyxhQUFhO0lBQ2pFLE1BQU07SUFDTixXQUFXO0lBQ0g7SUFDUixpQkFBaUI7SUFDakIsTUFBTSxDQUFDLGVBQWUsWUFBWSxJQUFJO0lBQ3RDLFNBQVM7SUFDVCxPQUFPO0lBQ1AsVUFBVSxZQUFZLFdBQVk7S0FDaEMsT0FBTyxVQUFVLE9BQU8sVUFBVTtJQUNwQztJQUNBLFNBQVM7R0FDWCxHQUFHLE9BQU8sQ0FBQyxDQUFDO0dBR1osTUFBTSxTQUFTLE1BQU07R0FFckIsTUFBTSxTQUFTLE9BQU87R0FFdEIsT0FBTyxNQUFNRCxnQkFBYyxDQUFDLG1CQUFtQixDQUFDLGVBQWUsTUFBTSxTQUFTLE9BQU8sbUJBQW1CO0dBRXhHLElBQUk7UUFDRSxPQUFPLFFBQVEsS0FBSyxTQUFTLEdBQUc7S0FFbEMsU0FBUyxNQUFNLFNBQVM7S0FDeEI7SUFDRjs7RUFFSixPQUFPLElBQUksZ0JBQWdCO09BRXJCLENBQUMsYUFBYTtJQUNoQixTQUFTLGtCQUFrQjtJQUUzQixJQUFJLGFBQWE7S0FDZixXQUFXO0tBQ1gsTUFBTTtLQUVOLE1BQU0sbUJBQW1CLENBQUMsZUFBZSxZQUFZLElBQUk7S0FDeEM7S0FFakIsU0FBUztLQUNEO0lBRVYsR0FBRyxTQUFTO0lBQ1osZ0JBQWdCLEVBQUUsUUFBUSxRQUFRO0lBRWxDLGtCQUFrQixNQUFNLFdBQVcsTUFBTSxJQUFJLFNBQVMsQ0FBQyxDQUFDO0lBRXhELE1BQU0sU0FBUyxNQUFNO0lBRXJCLE1BQU0sU0FBUyxPQUFPO0lBRXRCLE9BQU8sTUFBTUEsZUFBYSxNQUFNLFNBQVMsT0FBTyxtQkFBbUIsSUFBSSxNQUFNLFNBQVMsT0FBTyxJQUFJLElBQUk7SUFDckcsTUFBTSxTQUFTO0lBRWYsSUFBSSxDQUFDLGlCQUNILFdBQVcsTUFBTSxVQUFVLFVBQVUsUUFBUTtTQUV4QyxJQUFJLENBQUMsTUFDVjtHQUVKOztFQUdGLE1BQU0sTUFBTSxNQUFNLFdBQVc7RUFDN0IsT0FBTyxPQUFPLFlBQVksSUFBSSxLQUFLLFFBQVEsQ0FBQztFQUU1QyxLQUFLLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0dBQ25DLFNBQVMsUUFBUTtHQUNqQixTQUFTLE9BQU8sU0FBUyxTQUFTLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQztHQUM5QyxNQUFNLFVBQVUsS0FBSyxXQUFXLENBQUM7R0FDakMsWUFBWSxPQUFPLE9BQU8sWUFBWSxVQUFVLFlBQVk7R0FFNUQsUUFBUSxnQkFBZ0IsVUFBVSxJQUFJLFlBQVksUUFBUSxNQUFNO0dBRWhFLElBQUksWUFBWSxTQUFTLElBQUksUUFBUSxFQUFBLENBQUcsS0FBSyxRQUFRLGVBQWUsV0FBVyxPQUFPLE9BQU8sV0FBVyxNQUFNLE9BQU87SUFDbkgsTUFBTSxNQUFNLEtBQUssSUFBSSxVQUFVLE1BQU0sS0FBSyxRQUFRLE9BQU8sTUFBTSxHQUFHLEdBQUcsT0FBTyxRQUFRLFFBQVEsR0FBRyxPQUFPLFFBQVE7SUFFOUcsT0FBTyxPQUFPLFFBQVEsU0FBVSxNQUFNO0tBQ3BDLFNBQVMsUUFBUTtJQUNuQixDQUFDO0lBRUQsT0FBTyxhQUFhLGNBQWM7R0FDcEM7R0FFQSxJQUFJLENBQUMsV0FBVyxhQUNkLEtBQUssS0FBSyxXQUNSLElBQUksU0FBUyxPQUFPLFNBQVMsYUFBYSxHQUFHLFdBQVcsT0FBTyxPQUFPLFFBQVEsV0FBVyxJQUN2RixPQUFPLGFBQWEsY0FBYztRQUVsQyxTQUFTLEtBQUssS0FBSyxjQUFjLEtBQUssT0FBTyxRQUFRLEdBQUcsT0FBTyxVQUFVLElBQUksT0FBTyxhQUFhLEdBQUcsS0FBSyxZQUFZO0dBSzNILE1BQU0sT0FBTyxNQUFNLElBQUksTUFBTSxNQUFNLEtBQUssUUFBUSxNQUFNLElBQUksRUFBRTtHQUU1RCxJQUFJLGlCQUFpQixNQUFNLEtBQUs7SUFDOUIsb0JBQW9CO0lBRXBCLGdCQUFnQixhQUFhLFFBQVEsVUFBVSxNQUFNLFdBQVcsSUFBSSxDQUFDO0lBR3JFLGNBQWMsQ0FBQyxNQUFNO0lBQ3JCLG9CQUFvQjtHQUN0QjtHQUVBLE1BQU0sT0FBTyxTQUFTLFlBQVksT0FBTyxNQUFNO0VBQ2pEO0VBRUEsZUFBZSwwQkFBMEIsS0FBSztFQUM5QyxNQUFNLFdBQVcsTUFBTSxRQUFRLEtBQUs7Q0FDdEM7Q0FFQSxNQUFNLFlBQVk7Q0FDbEIsTUFBTSxZQUFZLENBQUMsTUFBTSxPQUFPLE1BQU0sUUFBUSxDQUFDO0NBRS9DLGFBQWEsUUFBUSxLQUFLLEdBQUcsT0FBT0MsV0FBUyxNQUFNLElBQUk7QUFDekQ7SUFDSSxvQkFBb0IsU0FBUyxrQkFBa0IsT0FBTyxVQUFVLE9BQU8sT0FBTyxpQkFBaUIsT0FBTyxNQUFNLGVBQWU7Q0FDN0gsSUFBSSxXQUFXLE1BQU0sT0FBTyxNQUFNLGFBQWEsTUFBTSxXQUFXLENBQUMsR0FBQSxDQUFJLFdBQ2pFLElBQ0EsUUFDQSxRQUNBO0NBRUosSUFBSSxDQUFDLFNBQVM7RUFDWixVQUFVLE1BQU0sU0FBUyxZQUFZLENBQUM7RUFDdEMsU0FBUyxNQUFNO0VBQ2YsSUFBSSxNQUFNLFNBQVM7RUFFbkIsT0FBTyxLQUFLO0dBQ1YsS0FBSyxPQUFPLEVBQUUsQ0FBQztHQUVmLElBQUksTUFBTSxHQUFHLEtBQUssR0FBRyxFQUFFLEtBQUs7SUFFMUIsS0FBSyxHQUFHLEVBQUU7SUFFVixPQUFPLE1BQU0sR0FBRyxNQUFNLFlBQVksR0FBRyxPQUFPLFVBRTFDLEtBQUssR0FBRztHQUVaO0dBRUEsSUFBSSxDQUFDLElBQUk7SUFHUCxzQkFBc0I7SUFFdEIsTUFBTSxLQUFLLFlBQVk7SUFFdkIsV0FBVyxPQUFPLElBQUk7SUFFdEIsc0JBQXNCO0lBQ3RCLE9BQU8sZ0JBQWdCLE1BQU0sV0FBVyxtRUFBbUUsSUFBSTtHQUNqSDtHQUVBLFFBQVEsS0FBSyxFQUFFO0VBQ2pCO0NBQ0Y7Q0FFQSxJQUFJLFFBQVE7Q0FFWixPQUFPLEtBQUs7RUFDVixTQUFTLFFBQVE7RUFDakIsS0FBSyxPQUFPLE9BQU87RUFFbkIsR0FBRyxLQUFLLFNBQVMsVUFBVSxNQUFNLENBQUMsa0JBQWtCLFFBQVEsR0FBRyxLQUFLLFNBQVMsS0FBSyxRQUFRLEdBQUc7RUFDN0YsR0FBRyxJQUFJLFFBQVEsR0FBRztFQUNsQixPQUFPLE1BQU0sT0FBTyxJQUFJLE9BQU8sS0FBSyxJQUFJLFFBQVEsT0FBTyxDQUFDO0VBRXhELE9BQU8sTUFBTSxPQUFPLElBQUksR0FBRyxJQUFJLFFBQVEsT0FBTyxDQUFDO0NBQ2pEO0FBQ0Y7SUFDSSxvQkFBb0IsU0FBUyxrQkFBa0IsU0FBUyxNQUFNO0NBQ2hFLElBQUksVUFBVSxRQUFRLEtBQUssVUFBVSxRQUFRLEVBQUUsQ0FBQyxDQUFDLFVBQVUsR0FDdkQsa0JBQWtCLFdBQVcsUUFBUSxTQUNyQyxNQUNBLEdBQ0EsR0FDQTtDQUVKLElBQUksQ0FBQyxpQkFDSCxPQUFPO0NBR1QsT0FBTyxPQUFPLENBQUMsR0FBRyxJQUFJO0NBRXRCLEtBQUssS0FBSyxpQkFDUixJQUFJLEtBQUssTUFBTTtFQUNiLFVBQVUsZ0JBQWdCLEVBQUUsQ0FBQyxNQUFNLEdBQUc7RUFDdEMsSUFBSSxRQUFRO0VBRVosT0FBTyxLQUNMLEtBQUssUUFBUSxNQUFNLEtBQUs7Q0FFNUI7Q0FHRixPQUFPO0FBQ1Q7SUFFQSxpQkFBaUIsU0FBUyxlQUFlLE1BQU0sS0FBSyxVQUFVLFVBQVU7Q0FDdEUsSUFBSSxPQUFPLElBQUksUUFBUSxZQUFZLGdCQUMvQixHQUNBO0NBRUosSUFBSSxTQUFTLEdBQUcsR0FBRztFQUNqQixJQUFJLFNBQVMsVUFBVSxTQUFTLFFBQVEsQ0FBQztFQUV6QyxJQUFJLFFBQVEsU0FBVSxPQUFPLEdBQUc7R0FDOUIsT0FBTyxFQUFFLEtBQUs7SUFDWixHQUFHLEtBQUssSUFBSSxTQUFTLEtBQUs7SUFDMUIsR0FBRztJQUNILEdBQUc7R0FDTCxDQUFDO0VBQ0gsQ0FBQztDQUNILE9BQ0UsS0FBSyxLQUFLLEtBQUs7RUFDYixJQUFJLFNBQVMsT0FBTyxTQUFTLEtBQUssQ0FBQztFQUNuQyxNQUFNLFVBQVUsRUFBRSxLQUFLO0dBQ3JCLEdBQUcsV0FBVyxJQUFJO0dBQ2xCLEdBQUcsSUFBSTtHQUNQLEdBQUc7RUFDTCxDQUFDO0NBQ0g7QUFFSjtJQUNJLHFCQUFxQixTQUFTLG1CQUFtQixPQUFPLE9BQU8sR0FBRyxRQUFRLFNBQVM7Q0FDckYsT0FBTyxZQUFZLEtBQUssSUFBSSxNQUFNLEtBQUssT0FBTyxHQUFHLFFBQVEsT0FBTyxJQUFJLFVBQVUsS0FBSyxLQUFLLENBQUMsTUFBTSxRQUFRLFNBQVMsSUFBSSxlQUFlLEtBQUssSUFBSTtBQUM5STtJQUNJLHFCQUFxQixpQkFBaUI7SUFDdEMsc0JBQXNCLENBQUM7QUFFM0IsYUFBYSxxQkFBcUIsbURBQW1ELFNBQVUsTUFBTTtDQUNuRyxPQUFPLG9CQUFvQixRQUFRO0FBQ3JDLENBQUM7QUFRRCxJQUFXLFFBQXFCLHVCQUFVLGFBQWE7Q0FDckQsZUFBZSxPQUFPLFdBQVc7Q0FFakMsU0FBUyxNQUFNLFNBQVMsTUFBTSxVQUFVLGFBQWE7RUFDbkQsSUFBSTtFQUVKLElBQUksT0FBTyxTQUFTLFVBQVU7R0FDNUIsU0FBUyxXQUFXO0dBQ3BCLE9BQU87R0FDUCxXQUFXO0VBQ2I7RUFFQSxTQUFTLFlBQVksS0FBSyxNQUFNLGNBQWMsT0FBTyxpQkFBaUIsSUFBSSxDQUFDLEtBQUs7RUFDaEYsSUFBSSxjQUFjLE9BQU8sTUFDckIsV0FBVyxZQUFZLFVBQ3ZCLFFBQVEsWUFBWSxPQUNwQixrQkFBa0IsWUFBWSxpQkFDOUIsVUFBVSxZQUFZLFNBQ3RCLFlBQVksWUFBWSxXQUN4QixZQUFZLFlBQVksV0FDeEIsV0FBVyxZQUFZLFVBQ3ZCLGdCQUFnQixZQUFZLGVBQzVCLFNBQVMsS0FBSyxVQUFVLGlCQUN4QixpQkFBaUIsU0FBUyxPQUFPLEtBQUssY0FBYyxPQUFPLElBQUksVUFBVSxRQUFRLEVBQUUsSUFBSSxZQUFZLFFBQVEsQ0FBQyxPQUFPLElBQUksUUFBUSxPQUFPLEdBQ3RJLElBQ0EsR0FDQSxNQUNBLEdBQ0EsR0FDQSxXQUNBLGFBQ0E7RUFDSixPQUFPLFdBQVcsY0FBYyxTQUFTLFNBQVMsYUFBYSxJQUFJLE1BQU0saUJBQWlCLFVBQVUsZ0NBQWdDLENBQUMsUUFBUSxjQUFjLEtBQUssQ0FBQztFQUNqSyxPQUFPLFlBQVksQ0FBQztFQUVwQixPQUFPLGFBQWE7RUFFcEIsSUFBSSxhQUFhLFdBQVcsZ0JBQWdCLFFBQVEsS0FBSyxnQkFBZ0IsS0FBSyxHQUFHO0dBQy9FLE9BQU8sT0FBTztHQUNkLElBQUksY0FBYyxLQUFLLGVBQWUsS0FBSztHQUMzQyxLQUFLLE9BQU8sV0FBVyxJQUFJLFNBQVM7SUFDbEMsTUFBTTtJQUNOLFVBQVUsWUFBWSxDQUFDO0lBQ3ZCLFNBQVMsVUFBVSxPQUFPLFNBQVMsV0FBVyxPQUFPLEtBQUssVUFBVTtHQUN0RSxDQUFDO0dBRUQsR0FBRyxLQUFLO0dBQ1IsR0FBRyxTQUFTLEdBQUcsTUFBTSx1QkFBdUIsTUFBTTtHQUNsRCxHQUFHLFNBQVM7R0FFWixJQUFJLFdBQVcsZ0JBQWdCLFFBQVEsS0FBSyxnQkFBZ0IsS0FBSyxHQUFHO0lBQ2xFLElBQUksY0FBYztJQUNsQixjQUFjLFdBQVcsV0FBVyxPQUFPO0lBRTNDLElBQUksVUFBVSxPQUFPO1VBRWQsS0FBSyxTQUNSLElBQUksQ0FBQyxtQkFBbUIsUUFBUSxDQUFDLEdBQUc7TUFDbEMsdUJBQXVCLHFCQUFxQixDQUFDO01BQzdDLG1CQUFtQixLQUFLLFFBQVE7S0FDbEM7O0lBSUosS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7S0FDdEIsT0FBTyxlQUFlLE1BQU0sbUJBQW1CO0tBQy9DLEtBQUssVUFBVTtLQUNmLGdCQUFnQixLQUFLLGNBQWM7S0FDbkMsc0JBQXNCLE9BQU8sTUFBTSxrQkFBa0I7S0FDckQsWUFBWSxjQUFjO0tBRTFCLEtBQUssV0FBVyxDQUFDLG1CQUFtQixVQUFVLHVCQUF1QixNQUFNLEdBQUcsR0FBRyxXQUFXLGFBQWE7S0FDekcsS0FBSyxTQUFTLENBQUMsbUJBQW1CLE9BQU8sdUJBQXVCLE1BQU0sR0FBRyxHQUFHLFdBQVcsYUFBYSxLQUFLLEtBQUssT0FBTztLQUVySCxJQUFJLENBQUMsV0FBVyxNQUFNLEtBQUssS0FBSyxPQUFPO01BRXJDLE9BQU8sU0FBUyxRQUFRLEtBQUs7TUFDN0IsT0FBTyxVQUFVO01BQ2pCLEtBQUssUUFBUTtLQUNmO0tBRUEsR0FBRyxHQUFHLFdBQVcsTUFBTSxjQUFjLFlBQVksR0FBRyxXQUFXLGFBQWEsSUFBSSxDQUFDO0tBQ2pGLEdBQUcsUUFBUSxTQUFTO0lBQ3RCO0lBRUEsR0FBRyxTQUFTLElBQUksV0FBVyxRQUFRLElBQUksT0FBTyxXQUFXO0dBQzNELE9BQU8sSUFBSSxXQUFXO0lBQ3BCLGlCQUFpQixhQUFhLEdBQUcsS0FBSyxVQUFVLEVBQzlDLE1BQU0sT0FDUixDQUFDLENBQUM7SUFFRixHQUFHLFFBQVEsV0FBVyxVQUFVLFFBQVEsS0FBSyxRQUFRLE1BQU07SUFDM0QsSUFBSSxPQUFPLEdBQ1AsR0FDQSxJQUNBO0lBRUosSUFBSSxTQUFTLFNBQVMsR0FBRztLQUN2QixVQUFVLFFBQVEsU0FBVSxPQUFPO01BQ2pDLE9BQU8sR0FBRyxHQUFHLGVBQWUsT0FBTyxHQUFHO0tBQ3hDLENBQUM7S0FDRCxHQUFHLFNBQVM7SUFDZCxPQUFPO0tBQ0wsT0FBTyxDQUFDO0tBRVIsS0FBSyxLQUFLLFdBQ1IsTUFBTSxVQUFVLE1BQU0sY0FBYyxlQUFlLEdBQUcsVUFBVSxJQUFJLE1BQU0sVUFBVSxRQUFRO0tBRzlGLEtBQUssS0FBSyxNQUFNO01BQ2QsSUFBSSxLQUFLLEVBQUUsQ0FBQyxLQUFLLFNBQVUsR0FBRyxHQUFHO09BQy9CLE9BQU8sRUFBRSxJQUFJLEVBQUU7TUFDakIsQ0FBQztNQUNELE9BQU87TUFFUCxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO09BQzdCLEtBQUssRUFBRTtPQUNQLElBQUk7UUFDRixNQUFNLEdBQUc7UUFDVCxXQUFXLEdBQUcsS0FBSyxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsSUFBSSxNQUFNLE1BQU07T0FDbEQ7T0FDQSxFQUFFLEtBQUssR0FBRztPQUNWLEdBQUcsR0FBRyxlQUFlLEdBQUcsSUFBSTtPQUM1QixRQUFRLEVBQUU7TUFDWjtLQUNGO0tBRUEsR0FBRyxTQUFTLElBQUksWUFBWSxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQ3BDLFVBQVUsV0FBVyxHQUFHLFNBQVMsRUFDbkMsQ0FBQztJQUNIO0dBQ0Y7R0FFQSxZQUFZLE9BQU8sU0FBUyxXQUFXLEdBQUcsU0FBUyxDQUFDO0VBQ3RELE9BQ0UsT0FBTyxXQUFXO0VBR3BCLElBQUksY0FBYyxRQUFRLENBQUMscUJBQXFCO0dBQzlDLG9CQUFvQix1QkFBdUIsTUFBTTtHQUVqRCxnQkFBZ0IsYUFBYSxhQUFhO0dBRTFDLG9CQUFvQjtFQUN0QjtFQUVBLGVBQWUsUUFBUSx1QkFBdUIsTUFBTSxHQUFHLFFBQVE7RUFFL0QsS0FBSyxZQUFZLE9BQU8sUUFBUTtFQUNoQyxLQUFLLFVBQVUsT0FBTyxPQUFPLElBQUk7RUFFakMsSUFBSSxtQkFBbUIsQ0FBQyxZQUFZLENBQUMsYUFBYSxPQUFPLFdBQVcsY0FBYyxPQUFPLEtBQUssS0FBSyxZQUFZLGVBQWUsS0FBSyxzQkFBc0IsdUJBQXVCLE1BQU0sQ0FBQyxLQUFLLE9BQU8sU0FBUyxVQUFVO0dBQ3BOLE9BQU8sU0FBUyxDQUFDO0dBRWpCLE9BQU8sT0FBTyxLQUFLLElBQUksR0FBRyxDQUFDLEtBQUssS0FBSyxDQUFDO0VBRXhDO0VBRUEsaUJBQWlCLGVBQWUsdUJBQXVCLE1BQU0sR0FBRyxhQUFhO0VBQzdFLE9BQU87Q0FDVDtDQUVBLElBQUksVUFBVSxNQUFNO0NBRXBCLFFBQVEsU0FBUyxTQUFTLE9BQU8sV0FBVyxnQkFBZ0IsT0FBTztFQUNqRSxJQUFJLFdBQVcsS0FBSyxPQUNoQixPQUFPLEtBQUssT0FDWixNQUFNLEtBQUssTUFDWCxhQUFhLFlBQVksR0FDekIsUUFBUSxZQUFZLE9BQU8sWUFBWSxDQUFDLGFBQWEsT0FBTyxZQUFZLFdBQVcsSUFBSSxXQUN2RixNQUNBLElBQ0EsV0FDQSxlQUNBLGVBQ0EsUUFDQSxPQUNBO0VBRUosSUFBSSxDQUFDLEtBQ0gseUJBQXlCLE1BQU0sV0FBVyxnQkFBZ0IsS0FBSztPQUMxRCxJQUFJLFVBQVUsS0FBSyxVQUFVLENBQUMsYUFBYSxTQUFTLENBQUMsS0FBSyxZQUFZLEtBQUssVUFBVSxLQUFLLFlBQVksS0FBSyxTQUFTLE1BQU0sY0FBYyxLQUFLLE9BQU87R0FFekosT0FBTztHQUNQLFdBQVcsS0FBSztHQUVoQixJQUFJLEtBQUssU0FBUztJQUVoQixnQkFBZ0IsTUFBTSxLQUFLO0lBRTNCLElBQUksS0FBSyxVQUFVLE1BQU0sWUFDdkIsT0FBTyxLQUFLLFVBQVUsZ0JBQWdCLE1BQU0sV0FBVyxnQkFBZ0IsS0FBSztJQUc5RSxPQUFPLGNBQWMsUUFBUSxhQUFhO0lBRTFDLElBQUksVUFBVSxNQUFNO0tBRWxCLFlBQVksS0FBSztLQUNqQixPQUFPO0lBQ1QsT0FBTztLQUNMLGdCQUFnQixjQUFjLFFBQVEsYUFBYTtLQUVuRCxZQUFZLENBQUMsQ0FBQztLQUVkLElBQUksYUFBYSxjQUFjLGVBQWU7TUFDNUMsT0FBTztNQUNQO0tBQ0YsT0FBTyxJQUFJLE9BQU8sS0FDaEIsT0FBTztJQUVYO0lBRUEsU0FBUyxLQUFLLFNBQVMsWUFBWTtJQUNuQyxJQUFJLFFBQVEsT0FBTyxNQUFNO0lBQ3pCLGdCQUFnQixnQkFBZ0IsS0FBSyxRQUFRLGFBQWE7SUFFMUQsSUFBSSxTQUFTLFlBQVksQ0FBQyxTQUFTLEtBQUssWUFBWSxjQUFjLGVBQWU7S0FFL0UsS0FBSyxTQUFTO0tBQ2QsT0FBTztJQUNUO0lBRUEsSUFBSSxjQUFjO1NBRVosS0FBSyxLQUFLLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxLQUFLLFNBQVMsU0FBUyxpQkFBaUIsS0FBSyxVQUFVO01BRWhHLEtBQUssUUFBUSxRQUFRO01BRXJCLEtBQUssT0FBTyxjQUFjLGdCQUFnQixTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUTtLQUNuRjs7R0FFSjtHQUVBLElBQUksQ0FBQyxLQUFLLFVBQVU7SUFDbEIsSUFBSSxrQkFBa0IsTUFBTSxhQUFhLFlBQVksTUFBTSxPQUFPLGdCQUFnQixLQUFLLEdBQUc7S0FDeEYsS0FBSyxTQUFTO0tBRWQsT0FBTztJQUNUO0lBRUEsSUFBSSxhQUFhLEtBQUssU0FBUyxFQUFFLFNBQVMsS0FBSyxLQUFLLGlCQUFpQixjQUFjLGdCQUVqRixPQUFPO0lBR1QsSUFBSSxRQUFRLEtBQUssTUFFZixPQUFPLEtBQUssT0FBTyxXQUFXLGdCQUFnQixLQUFLO0dBRXZEO0dBRUEsSUFBSSxLQUFLLFFBQVE7SUFDZixJQUFJLE1BQU0sT0FBTztJQUVqQixJQUFJLFFBQVEsS0FBSyxNQUFNO0tBQ3JCLElBQUksU0FBUyxNQUFNLFdBQVcsTUFBTTtLQUNwQyxLQUFLLE9BQU87S0FDWixJQUFJLEtBQUssT0FBTyxLQUFLLFFBQVEsSUFBSSxLQUFLO0tBQ3RDLEtBQUssWUFBWSxLQUFLO0tBQ3RCLEtBQUssV0FBVztLQUNoQixLQUFLLFlBQVksVUFBVSxNQUFNLEtBQUssS0FBSyxTQUFTO0tBQ3BELEtBQUssWUFBWSxNQUFNLENBQUMsS0FBSyxRQUFRLElBQUksS0FBSztLQUM5QyxLQUFLLFdBQVcsTUFBTSxLQUFLLFNBQVMsS0FBSztJQUMzQztJQUVBLEtBQUssUUFBUSxRQUFRLEtBQUssWUFBWSxLQUFLLFlBQVksS0FBSyxVQUFVLE9BQU8sS0FBSyxZQUFZLEtBQUssU0FBUztHQUM5RyxPQUNFLEtBQUssUUFBUSxRQUFRLEtBQUssTUFBTSxPQUFPLEdBQUc7R0FHNUMsSUFBSSxLQUFLLE9BQU8sS0FBSyxRQUFRLFFBQVEsSUFBSTtHQUN6QyxLQUFLLFNBQVM7R0FDZCxLQUFLLFFBQVE7R0FFYixJQUFJLENBQUMsS0FBSyxRQUFRLEtBQUssS0FBSztJQUMxQixLQUFLLE9BQU87SUFFWixLQUFLLFFBQVE7R0FDZjtHQUVBLElBQUksQ0FBQyxZQUFZLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlO0lBQzNELFVBQVUsTUFBTSxTQUFTO0lBRXpCLElBQUksS0FBSyxXQUFXLE9BRWxCLE9BQU87R0FFWDtHQUVBLEtBQUssS0FBSztHQUVWLE9BQU8sSUFBSTtJQUNULEdBQUcsRUFBRSxPQUFPLEdBQUcsQ0FBQztJQUNoQixLQUFLLEdBQUc7R0FDVjtHQUVBLFlBQVksU0FBUyxPQUFPLFlBQVksSUFBSSxZQUFZLFNBQVMsT0FBTyxTQUFTLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssYUFBYSxLQUFLLFNBQVM7R0FFcEssSUFBSSxLQUFLLGFBQWEsQ0FBQyxnQkFBZ0I7SUFDckMsY0FBYyxlQUFlLE1BQU0sV0FBVyxnQkFBZ0IsS0FBSztJQUVuRSxVQUFVLE1BQU0sVUFBVTtHQUM1QjtHQUVBLEtBQUssV0FBVyxjQUFjLGlCQUFpQixLQUFLLEtBQUssWUFBWSxDQUFDLGtCQUFrQixLQUFLLFVBQVUsVUFBVSxNQUFNLFVBQVU7R0FFakksS0FBSyxVQUFVLEtBQUssU0FBUyxDQUFDLFVBQVUsS0FBSyxXQUFXLE9BQU87SUFDN0QsY0FBYyxDQUFDLEtBQUssYUFBYSxlQUFlLE1BQU0sV0FBVyxNQUFNLElBQUk7SUFDM0UsQ0FBQyxhQUFhLENBQUMsU0FBUyxVQUFVLEtBQUssU0FBUyxLQUFLLE1BQU0sS0FBSyxDQUFDLFNBQVMsS0FBSyxNQUFNLE1BQU0sa0JBQWtCLE1BQU0sQ0FBQztJQUVwSCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsY0FBYyxDQUFDLGNBQWMsU0FBUyxZQUFZLFNBQVM7S0FFbEYsVUFBVSxNQUFNLFVBQVUsT0FBTyxlQUFlLHFCQUFxQixJQUFJO0tBRXpFLEtBQUssU0FBUyxFQUFFLFFBQVEsUUFBUSxLQUFLLFVBQVUsSUFBSSxNQUFNLEtBQUssTUFBTTtJQUN0RTtHQUNGO0VBQ0Y7RUFFQSxPQUFPO0NBQ1Q7Q0FFQSxRQUFRLFVBQVUsU0FBUyxVQUFVO0VBQ25DLE9BQU8sS0FBSztDQUNkO0NBRUEsUUFBUSxhQUFhLFNBQVMsV0FBVyxNQUFNO0VBRTdDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxLQUFLLGtCQUFrQixLQUFLLFdBQVc7RUFDdkQsS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLFlBQVksS0FBSyxRQUFRLEtBQUssUUFBUTtFQUNqRSxLQUFLLFlBQVksQ0FBQztFQUNsQixLQUFLLFlBQVksS0FBSyxTQUFTLFdBQVcsSUFBSTtFQUM5QyxPQUFPLFlBQVksVUFBVSxXQUFXLEtBQUssTUFBTSxJQUFJO0NBQ3pEO0NBRUEsUUFBUSxVQUFVLFNBQVMsUUFBUSxVQUFVLE9BQU8sT0FBTyxpQkFBaUIsZUFBZTtFQUN6RixpQkFBaUIsUUFBUSxLQUFLO0VBQzlCLEtBQUssT0FBTyxLQUFLLEtBQUs7RUFDdEIsSUFBSSxPQUFPLEtBQUssSUFBSSxLQUFLLE9BQU8sS0FBSyxJQUFJLFFBQVEsS0FBSyxVQUFVLEtBQUssR0FBRyxHQUNwRTtFQUNKLEtBQUssWUFBWSxXQUFXLE1BQU0sSUFBSTtFQUN0QyxRQUFRLEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSTtFQVVuQyxJQUFJLGtCQUFrQixNQUFNLFVBQVUsT0FBTyxPQUFPLGlCQUFpQixPQUFPLE1BQU0sYUFBYSxHQUM3RixPQUFPLEtBQUssUUFBUSxVQUFVLE9BQU8sT0FBTyxpQkFBaUIsQ0FBQztFQUloRSxlQUFlLE1BQU0sQ0FBQztFQUV0QixLQUFLLFVBQVUsbUJBQW1CLEtBQUssS0FBSyxNQUFNLFVBQVUsU0FBUyxLQUFLLElBQUksUUFBUSxXQUFXLENBQUM7RUFDbEcsT0FBTyxLQUFLLE9BQU8sQ0FBQztDQUN0QjtDQUVBLFFBQVEsT0FBTyxTQUFTLEtBQUssU0FBUyxNQUFNO0VBQzFDLElBQUksU0FBUyxLQUFLLEdBQ2hCLE9BQU87RUFHVCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsU0FBUyxRQUFRO0dBQ3pDLEtBQUssUUFBUSxLQUFLLE1BQU07R0FDeEIsS0FBSyxTQUFTLFdBQVcsSUFBSSxJQUFJLEtBQUssaUJBQWlCLEtBQUssY0FBYyxLQUFLLENBQUMsQ0FBQ0QsWUFBVTtHQUMzRixPQUFPO0VBQ1Q7RUFFQSxJQUFJLEtBQUssVUFBVTtHQUNqQixJQUFJLE9BQU8sS0FBSyxTQUFTLGNBQWM7R0FDdkMsS0FBSyxTQUFTLGFBQWEsU0FBUyxNQUFNLHFCQUFxQixrQkFBa0IsS0FBSyxjQUFjLElBQUksQ0FBQyxDQUFDLFVBQVUsV0FBVyxJQUFJO0dBRW5JLEtBQUssVUFBVSxTQUFTLEtBQUssU0FBUyxjQUFjLEtBQUssYUFBYSxNQUFNLEtBQUssT0FBTyxLQUFLLFNBQVMsUUFBUSxNQUFNLEdBQUcsQ0FBQztHQUV4SCxPQUFPO0VBQ1Q7RUFFQSxJQUFJLGdCQUFnQixLQUFLLFVBQ3JCLGlCQUFpQixVQUFVLFFBQVEsT0FBTyxJQUFJLGVBQzlDLGtCQUFrQixLQUFLLFdBQ3ZCLFVBQVUsS0FBSyxLQUNmLGtCQUNBLFdBQ0EsbUJBQ0EsT0FDQSxHQUNBLElBQ0E7RUFFSixLQUFLLENBQUMsUUFBUSxTQUFTLFVBQVUsYUFBYSxlQUFlLGNBQWMsR0FBRztHQUM1RSxTQUFTLFVBQVUsS0FBSyxNQUFNO0dBQzlCLE9BQU8sV0FBVyxJQUFJO0VBQ3hCO0VBRUEsbUJBQW1CLEtBQUssTUFBTSxLQUFLLE9BQU8sQ0FBQztFQUUzQyxJQUFJLFNBQVMsT0FBTztHQUVsQixJQUFJLFVBQVUsSUFBSSxHQUFHO0lBQ25CLElBQUksQ0FBQztJQUVMLGFBQWEsTUFBTSxTQUFVLE1BQU07S0FDakMsT0FBTyxFQUFFLFFBQVE7SUFDbkIsQ0FBQztJQUVELE9BQU87R0FDVDtHQUVBLE9BQU8sa0JBQWtCLGVBQWUsSUFBSTtFQUM5QztFQUVBLElBQUksY0FBYztFQUVsQixPQUFPLEtBQ0wsSUFBSSxDQUFDLGVBQWUsUUFBUSxjQUFjLEVBQUUsR0FBRztHQUM3QyxZQUFZLGdCQUFnQjtHQUU1QixJQUFJLFNBQVMsT0FBTztJQUNsQixpQkFBaUIsS0FBSztJQUN0QixRQUFRO0lBQ1Isb0JBQW9CLENBQUM7R0FDdkIsT0FBTztJQUNMLG9CQUFvQixpQkFBaUIsS0FBSyxpQkFBaUIsTUFBTSxDQUFDO0lBQ2xFLFFBQVE7R0FDVjtHQUVBLEtBQUssS0FBSyxPQUFPO0lBQ2YsS0FBSyxhQUFhLFVBQVU7SUFFNUIsSUFBSSxJQUFJO0tBQ04sSUFBSSxFQUFFLFVBQVUsR0FBRyxNQUFNLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxNQUN4QyxzQkFBc0IsTUFBTSxJQUFJLEtBQUs7S0FHdkMsT0FBTyxVQUFVO0lBQ25CO0lBRUEsSUFBSSxzQkFBc0IsT0FDeEIsa0JBQWtCLEtBQUs7R0FFM0I7RUFDRjtFQUdGLEtBQUssWUFBWSxDQUFDLEtBQUssT0FBTyxXQUFXLFdBQVcsSUFBSTtFQUV4RCxPQUFPO0NBQ1Q7Q0FFQSxNQUFNLEtBQUssU0FBUyxHQUFHLFNBQVMsTUFBTTtFQUNwQyxPQUFPLElBQUksTUFBTSxTQUFTLE1BQU0sVUFBVSxFQUFFO0NBQzlDO0NBRUEsTUFBTSxPQUFPLFNBQVMsS0FBSyxTQUFTLE1BQU07RUFDeEMsT0FBTyxpQkFBaUIsR0FBRyxTQUFTO0NBQ3RDO0NBRUEsTUFBTSxjQUFjLFNBQVMsWUFBWSxPQUFPLFVBQVUsUUFBUSxPQUFPO0VBQ3ZFLE9BQU8sSUFBSSxNQUFNLFVBQVUsR0FBRztHQUM1QixpQkFBaUI7R0FDakIsTUFBTTtHQUNOLFdBQVc7R0FDSjtHQUNQLFlBQVk7R0FDWixtQkFBbUI7R0FDbkIsa0JBQWtCO0dBQ2xCLHlCQUF5QjtHQUN6QixlQUFlO0VBQ2pCLENBQUM7Q0FDSDtDQUVBLE1BQU0sU0FBUyxTQUFTLE9BQU8sU0FBUyxVQUFVLFFBQVE7RUFDeEQsT0FBTyxpQkFBaUIsR0FBRyxTQUFTO0NBQ3RDO0NBRUEsTUFBTSxNQUFNLFNBQVMsSUFBSSxTQUFTLE1BQU07RUFDdEMsS0FBSyxXQUFXO0VBQ2hCLEtBQUssZ0JBQWdCLEtBQUssU0FBUztFQUNuQyxPQUFPLElBQUksTUFBTSxTQUFTLElBQUk7Q0FDaEM7Q0FFQSxNQUFNLGVBQWUsU0FBUyxhQUFhLFNBQVMsT0FBTyxZQUFZO0VBQ3JFLE9BQU8sZ0JBQWdCLGFBQWEsU0FBUyxPQUFPLFVBQVU7Q0FDaEU7Q0FFQSxPQUFPO0FBQ1QsRUFBRSxTQUFTO0FBRVgsYUFBYSxNQUFNLFdBQVc7Q0FDNUIsVUFBVSxDQUFDO0NBQ1gsT0FBTztDQUNQLFVBQVU7Q0FDVixLQUFLO0NBQ0wsU0FBUztBQUNYLENBQUM7QUFVRCxhQUFhLHVDQUF1QyxTQUFVLE1BQU07Q0FDbEUsTUFBTSxRQUFRLFdBQVk7RUFDeEIsSUFBSSxLQUFLLElBQUksU0FBUyxHQUNsQixTQUFTLE9BQU8sS0FBSyxXQUFXLENBQUM7RUFFckMsT0FBTyxPQUFPLFNBQVMsa0JBQWtCLElBQUksR0FBRyxHQUFHLENBQUM7RUFDcEQsT0FBTyxHQUFHLEtBQUssQ0FBQyxNQUFNLElBQUksTUFBTTtDQUNsQztBQUNGLENBQUM7QUFRRCxJQUFJLGVBQWUsU0FBUyxhQUFhLFFBQVEsVUFBVSxPQUFPO0NBQ2hFLE9BQU8sT0FBTyxZQUFZO0FBQzVCO0lBQ0ksY0FBYyxTQUFTLFlBQVksUUFBUSxVQUFVLE9BQU87Q0FDOUQsT0FBTyxPQUFPLFNBQVMsQ0FBQyxLQUFLO0FBQy9CO0lBQ0ksdUJBQXVCLFNBQVMscUJBQXFCLFFBQVEsVUFBVSxPQUFPLE1BQU07Q0FDdEYsT0FBTyxPQUFPLFNBQVMsQ0FBQyxLQUFLLElBQUksS0FBSztBQUN4QztJQUNJLG1CQUFtQixTQUFTLGlCQUFpQixRQUFRLFVBQVUsT0FBTztDQUN4RSxPQUFPLE9BQU8sYUFBYSxVQUFVLEtBQUs7QUFDNUM7SUFDSSxhQUFhLFNBQVMsV0FBVyxRQUFRLFVBQVU7Q0FDckQsT0FBTyxZQUFZLE9BQU8sU0FBUyxJQUFJLGNBQWMsYUFBYSxPQUFPLFNBQVMsS0FBSyxPQUFPLGVBQWUsbUJBQW1CO0FBQ2xJO0lBQ0ksZUFBZSxTQUFTLGFBQWEsT0FBTyxNQUFNO0NBQ3BELE9BQU8sS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxHQUFPLElBQUksS0FBUyxJQUFJO0FBQ2pHO0lBQ0ksaUJBQWlCLFNBQVMsZUFBZSxPQUFPLE1BQU07Q0FDeEQsT0FBTyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLEVBQUUsS0FBSyxJQUFJLEtBQUssSUFBSSxRQUFRLElBQUk7QUFDbkU7SUFDSSx1QkFBdUIsU0FBUyxxQkFBcUIsT0FBTyxNQUFNO0NBQ3BFLElBQUksS0FBSyxLQUFLLEtBQ1YsSUFBSTtDQUVSLElBQUksQ0FBQyxTQUFTLEtBQUssR0FFakIsSUFBSSxLQUFLO01BQ0osSUFBSSxVQUFVLEtBQUssS0FBSyxHQUU3QixJQUFJLEtBQUs7TUFDSjtFQUNMLE9BQU8sSUFBSTtHQUNULElBQUksR0FBRyxLQUFLLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FBRyxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksS0FBSyxPQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksU0FBUyxHQUFLLElBQUksT0FBUztHQUVwRyxLQUFLLEdBQUc7RUFDVjtFQUVBLEtBQUssS0FBSztDQUNaO0NBRUEsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLEdBQUcsR0FBRyxJQUFJO0FBQ2xDO0lBQ0ksb0JBQW9CLFNBQVMsa0JBQWtCLE9BQU8sTUFBTTtDQUM5RCxJQUFJLEtBQUssS0FBSztDQUVkLE9BQU8sSUFBSTtFQUNULEdBQUcsRUFBRSxPQUFPLEdBQUcsQ0FBQztFQUNoQixLQUFLLEdBQUc7Q0FDVjtBQUNGO0lBQ0kscUJBQXFCLFNBQVMsbUJBQW1CLFVBQVUsT0FBTyxRQUFRLFVBQVU7Q0FDdEYsSUFBSSxLQUFLLEtBQUssS0FDVjtDQUVKLE9BQU8sSUFBSTtFQUNULE9BQU8sR0FBRztFQUNWLEdBQUcsTUFBTSxZQUFZLEdBQUcsU0FBUyxVQUFVLE9BQU8sTUFBTTtFQUN4RCxLQUFLO0NBQ1A7QUFDRjtJQUNJLG9CQUFvQixTQUFTLGtCQUFrQixVQUFVO0NBQzNELElBQUksS0FBSyxLQUFLLEtBQ1YsMEJBQ0E7Q0FFSixPQUFPLElBQUk7RUFDVCxPQUFPLEdBQUc7RUFFVixJQUFJLEdBQUcsTUFBTSxZQUFZLENBQUMsR0FBRyxNQUFNLEdBQUcsT0FBTyxVQUMzQyxzQkFBc0IsTUFBTSxJQUFJLEtBQUs7T0FDaEMsSUFBSSxDQUFDLEdBQUcsS0FDYiwyQkFBMkI7RUFHN0IsS0FBSztDQUNQO0NBRUEsT0FBTyxDQUFDO0FBQ1Y7SUFDSSxzQkFBc0IsU0FBUyxvQkFBb0IsUUFBUSxVQUFVLE9BQU8sTUFBTTtDQUNwRixLQUFLLEtBQUssUUFBUSxVQUFVLEtBQUssRUFBRSxLQUFLLEtBQUssT0FBTyxPQUFPLEtBQUssRUFBRSxHQUFHLElBQUk7QUFDM0U7SUFDSSw0QkFBNEIsU0FBUywwQkFBMEIsUUFBUTtDQUN6RSxJQUFJLEtBQUssT0FBTyxLQUNaLE1BQ0EsS0FDQSxPQUNBO0NBRUosT0FBTyxJQUFJO0VBQ1QsT0FBTyxHQUFHO0VBQ1YsTUFBTTtFQUVOLE9BQU8sT0FBTyxJQUFJLEtBQUssR0FBRyxJQUN4QixNQUFNLElBQUk7RUFHWixJQUFJLEdBQUcsUUFBUSxNQUFNLElBQUksUUFBUSxNQUMvQixHQUFHLE1BQU0sUUFBUTtPQUVqQixRQUFRO0VBR1YsSUFBSSxHQUFHLFFBQVEsS0FDYixJQUFJLFFBQVE7T0FFWixPQUFPO0VBR1QsS0FBSztDQUNQO0NBRUEsT0FBTyxNQUFNO0FBQ2Y7QUFHQSxJQUFXLFlBQXlCLHlCQUFZO0NBQzlDLFNBQVMsVUFBVSxNQUFNLFFBQVEsTUFBTSxPQUFPLFFBQVEsVUFBVSxNQUFNLFFBQVEsVUFBVTtFQUN0RixLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUksWUFBWTtFQUNyQixLQUFLLElBQUksUUFBUTtFQUNqQixLQUFLLE1BQU0sVUFBVTtFQUNyQixLQUFLLEtBQUssWUFBWTtFQUN0QixLQUFLLFFBQVE7RUFFYixJQUFJLE1BQ0YsS0FBSyxRQUFRO0NBRWpCO0NBRUEsSUFBSSxVQUFVLFVBQVU7Q0FFeEIsUUFBUSxXQUFXLFNBQVMsU0FBUyxNQUFNLE9BQU8sUUFBUTtFQUN4RCxLQUFLLE9BQU8sS0FBSyxRQUFRLEtBQUs7RUFFOUIsS0FBSyxNQUFNO0VBQ1gsS0FBSyxJQUFJO0VBQ1QsS0FBSyxLQUFLO0VBRVYsS0FBSyxRQUFRO0NBQ2Y7Q0FFQSxPQUFPO0FBQ1QsRUFBRTtBQUVGLGFBQWEsaUJBQWlCLG1QQUFtUCxTQUFVLE1BQU07Q0FDL1IsT0FBTyxlQUFlLFFBQVE7QUFDaEMsQ0FBQztBQUVELFNBQVMsV0FBVyxTQUFTLFlBQVk7QUFDekMsU0FBUyxlQUFlLFNBQVMsY0FBYztBQUMvQyxrQkFBa0IsSUFBSSxTQUFTO0NBQzdCLGNBQWM7Q0FDZCxVQUFVO0NBQ1Ysb0JBQW9CO0NBQ3BCLElBQUk7Q0FDSixtQkFBbUI7QUFDckIsQ0FBQztBQUNELFFBQVEsZUFBZTtBQUV2QixJQUFJLFNBQVMsQ0FBQztJQUNWLGFBQWEsQ0FBQztJQUNkLGNBQWMsQ0FBQztJQUNmLGlCQUFpQjtJQUNqQixhQUFhO0lBQ2IsWUFBWSxTQUFTLFVBQVUsTUFBTTtDQUN2QyxRQUFRLFdBQVcsU0FBUyxZQUFBLENBQWEsSUFBSSxTQUFVLEdBQUc7RUFDeEQsT0FBTyxFQUFFO0NBQ1gsQ0FBQztBQUNIO0lBQ0ksaUJBQWlCLFNBQVMsaUJBQWlCO0NBQzdDLElBQUksT0FBTyxLQUFLLElBQUksR0FDaEIsVUFBVSxDQUFDO0NBRWYsSUFBSSxPQUFPLGlCQUFpQixHQUFHO0VBQzdCLFVBQVUsZ0JBQWdCO0VBRTFCLE9BQU8sUUFBUSxTQUFVLEdBQUc7R0FDMUIsSUFBSSxVQUFVLEVBQUUsU0FDWixhQUFhLEVBQUUsWUFDZixPQUNBLEdBQ0EsVUFDQTtHQUVKLEtBQUssS0FBSyxTQUFTO0lBQ2pCLFFBQVFHLE9BQUssV0FBVyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBRXBDLFVBQVUsV0FBVztJQUVyQixJQUFJLFVBQVUsV0FBVyxJQUFJO0tBQzNCLFdBQVcsS0FBSztLQUNoQixVQUFVO0lBQ1o7R0FDRjtHQUVBLElBQUksU0FBUztJQUNYLEVBQUUsT0FBTztJQUNULFlBQVksUUFBUSxLQUFLLENBQUM7R0FDNUI7RUFDRixDQUFDO0VBRUQsVUFBVSxrQkFBa0I7RUFFNUIsUUFBUSxRQUFRLFNBQVUsR0FBRztHQUMzQixPQUFPLEVBQUUsUUFBUSxHQUFHLFNBQVUsTUFBTTtJQUNsQyxPQUFPLEVBQUUsSUFBSSxNQUFNLElBQUk7R0FDekIsQ0FBQztFQUNILENBQUM7RUFDRCxpQkFBaUI7RUFFakIsVUFBVSxZQUFZO0NBQ3hCO0FBQ0Y7QUFFQSxJQUFJLFVBQXVCLHlCQUFZO0NBQ3JDLFNBQVMsUUFBUSxNQUFNLE9BQU87RUFDNUIsS0FBSyxXQUFXLFNBQVMsU0FBUyxLQUFLO0VBQ3ZDLEtBQUssT0FBTyxDQUFDO0VBQ2IsS0FBSyxLQUFLLENBQUM7RUFFWCxLQUFLLGFBQWE7RUFDbEIsS0FBSyxLQUFLO0VBRVYsUUFBUSxLQUFLLElBQUksSUFBSTtDQUN2QjtDQUVBLElBQUksVUFBVSxRQUFRO0NBRXRCLFFBQVEsTUFBTSxTQUFTLElBQUksTUFBTSxNQUFNLE9BQU87RUFNNUMsSUFBSSxZQUFZLElBQUksR0FBRztHQUNyQixRQUFRO0dBQ1IsT0FBTztHQUNQLE9BQU87RUFDVDtFQUVBLElBQUksT0FBTyxNQUNQLElBQUksU0FBUyxJQUFJO0dBQ25CLElBQUksT0FBTyxVQUNQLGVBQWUsS0FBSyxVQUNwQjtHQUNKLFFBQVEsU0FBUyxRQUFRLEtBQUssS0FBSyxLQUFLLElBQUk7R0FDNUMsVUFBVSxLQUFLLFdBQVcsU0FBUyxLQUFLO0dBQ3hDLFdBQVc7R0FDWCxTQUFTLEtBQUssTUFBTSxNQUFNLFNBQVM7R0FDbkMsWUFBWSxNQUFNLEtBQUssS0FBSyxHQUFHLEtBQUssTUFBTTtHQUMxQyxXQUFXO0dBQ1gsS0FBSyxXQUFXO0dBQ2hCLEtBQUssYUFBYTtHQUNsQixPQUFPO0VBQ1Q7RUFFQSxLQUFLLE9BQU87RUFDWixPQUFPLFNBQVMsY0FBYyxFQUFFLE1BQU0sU0FBVSxNQUFNO0dBQ3BELE9BQU8sS0FBSyxJQUFJLE1BQU0sSUFBSTtFQUM1QixDQUFDLElBQUksT0FBTyxLQUFLLFFBQVEsSUFBSTtDQUMvQjtDQUVBLFFBQVEsU0FBUyxTQUFTLE9BQU8sTUFBTTtFQUNyQyxJQUFJLE9BQU87RUFDWCxXQUFXO0VBQ1gsS0FBSyxJQUFJO0VBQ1QsV0FBVztDQUNiO0NBRUEsUUFBUSxZQUFZLFNBQVMsWUFBWTtFQUN2QyxJQUFJLElBQUksQ0FBQztFQUNULEtBQUssS0FBSyxRQUFRLFNBQVUsR0FBRztHQUM3QixPQUFPLGFBQWEsVUFBVSxFQUFFLEtBQUssTUFBTSxHQUFHLEVBQUUsVUFBVSxDQUFDLElBQUksYUFBYSxTQUFTLEVBQUUsRUFBRSxVQUFVLEVBQUUsT0FBTyxTQUFTLGFBQWEsRUFBRSxLQUFLLENBQUM7RUFDNUksQ0FBQztFQUNELE9BQU87Q0FDVDtDQUVBLFFBQVEsUUFBUSxTQUFTLFFBQVE7RUFDL0IsS0FBSyxHQUFHLFNBQVMsS0FBSyxLQUFLLFNBQVM7Q0FDdEM7Q0FFQSxRQUFRLE9BQU8sU0FBUyxLQUFLLFFBQVEsWUFBWTtFQUMvQyxJQUFJLFNBQVM7RUFFYixJQUFJLFFBQ0YsQ0FBQyxXQUFZO0dBQ1gsSUFBSSxTQUFTLE9BQU8sVUFBVSxHQUMxQixJQUFJLE9BQU8sS0FBSyxRQUNoQjtHQUVKLE9BQU8sS0FBSztJQUVWLElBQUksT0FBTyxLQUFLO0lBRWhCLElBQUksRUFBRSxTQUFTLFVBQVU7S0FDdkIsRUFBRSxPQUFPO0tBQ1QsRUFBRSxZQUFZLE1BQU0sTUFBTSxLQUFLLENBQUMsQ0FBQyxRQUFRLFNBQVUsT0FBTztNQUN4RCxPQUFPLE9BQU8sT0FBTyxPQUFPLFFBQVEsS0FBSyxHQUFHLENBQUM7S0FDL0MsQ0FBQztJQUNIO0dBQ0Y7R0FHQSxPQUFPLElBQUksU0FBVSxHQUFHO0lBQ3RCLE9BQU87S0FDTCxHQUFHLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUMsRUFBRSxLQUFLLEtBQUssa0JBQWtCLEVBQUUsV0FBVyxDQUFDLElBQUk7S0FDakY7SUFDTDtHQUNGLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBVSxHQUFHLEdBQUc7SUFDdEIsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO0dBQ3RCLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0lBQ3RCLE9BQU8sRUFBRSxFQUFFLE9BQU8sTUFBTTtHQUMxQixDQUFDO0dBRUQsSUFBSSxPQUFPLEtBQUs7R0FFaEIsT0FBTyxLQUFLO0lBRVYsSUFBSSxPQUFPLEtBQUs7SUFFaEIsSUFBSSxhQUFhO1NBQ1gsRUFBRSxTQUFTLFVBQVU7TUFDdkIsRUFBRSxpQkFBaUIsRUFBRSxjQUFjLE9BQU87TUFDMUMsRUFBRSxLQUFLO0tBQ1Q7V0FFQSxFQUFFLGFBQWEsVUFBVSxFQUFFLFVBQVUsRUFBRSxPQUFPLE1BQU07R0FFeEQ7R0FFQSxPQUFPLEdBQUcsUUFBUSxTQUFVLEdBQUc7SUFDN0IsT0FBTyxFQUFFLFFBQVEsTUFBTTtHQUN6QixDQUFDO0dBRUQsT0FBTyxhQUFhO0VBQ3RCLEVBQUEsQ0FBRztPQUVILEtBQUssS0FBSyxRQUFRLFNBQVUsR0FBRztHQUM3QixPQUFPLEVBQUUsUUFBUSxFQUFFLEtBQUs7RUFDMUIsQ0FBQztFQUdILEtBQUssTUFBTTtFQUVYLElBQUksWUFBWTtHQUNkLElBQUksSUFBSSxPQUFPO0dBRWYsT0FBTyxLQUVMLE9BQU8sRUFBRSxDQUFDLE9BQU8sS0FBSyxNQUFNLE9BQU8sT0FBTyxHQUFHLENBQUM7RUFFbEQ7Q0FDRjtDQU1BLFFBQVEsU0FBUyxTQUFTLE9BQU8sUUFBUTtFQUN2QyxLQUFLLEtBQUssVUFBVSxDQUFDLENBQUM7Q0FDeEI7Q0FFQSxPQUFPO0FBQ1QsRUFBRTtBQUVGLElBQUksYUFBMEIseUJBQVk7Q0FDeEMsU0FBUyxXQUFXLE9BQU87RUFDekIsS0FBSyxXQUFXLENBQUM7RUFDakIsS0FBSyxRQUFRO0VBQ2IsWUFBWSxTQUFTLEtBQUssS0FBSyxJQUFJO0NBQ3JDO0NBRUEsSUFBSSxVQUFVLFdBQVc7Q0FFekIsUUFBUSxNQUFNLFNBQVMsSUFBSSxZQUFZLE1BQU0sT0FBTztFQUNsRCxVQUFVLFVBQVUsTUFBTSxhQUFhLEVBQ3JDLFNBQVMsV0FDWDtFQUNBLElBQUksVUFBVSxJQUFJLFFBQVEsR0FBRyxTQUFTLEtBQUssS0FBSyxHQUM1QyxPQUFPLFFBQVEsYUFBYSxDQUFDLEdBQzdCLElBQ0EsR0FDQTtFQUNKLFlBQVksQ0FBQyxRQUFRLGFBQWEsUUFBUSxXQUFXLFNBQVM7RUFFOUQsS0FBSyxTQUFTLEtBQUssT0FBTztFQUMxQixPQUFPLFFBQVEsSUFBSSxXQUFXLElBQUk7RUFDbEMsUUFBUSxVQUFVO0VBRWxCLEtBQUssS0FBSyxZQUNSLElBQUksTUFBTSxPQUNSLFNBQVM7T0FDSjtHQUNMLEtBQUtBLE9BQUssV0FBVyxXQUFXLEVBQUU7R0FFbEMsSUFBSSxJQUFJO0lBQ04sT0FBTyxRQUFRLE9BQU8sSUFBSSxLQUFLLE9BQU8sS0FBSyxPQUFPO0lBQ2xELENBQUMsS0FBSyxLQUFLLEdBQUcsYUFBYSxTQUFTO0lBQ3BDLEdBQUcsY0FBYyxHQUFHLFlBQVksY0FBYyxJQUFJLEdBQUcsaUJBQWlCLFVBQVUsY0FBYztHQUNoRztFQUNGO0VBR0YsVUFBVSxLQUFLLFNBQVMsU0FBVSxHQUFHO0dBQ25DLE9BQU8sUUFBUSxJQUFJLE1BQU0sQ0FBQztFQUM1QixDQUFDO0VBQ0QsT0FBTztDQUNUO0NBV0EsUUFBUSxTQUFTLFNBQVMsT0FBTyxRQUFRO0VBQ3ZDLEtBQUssS0FBSyxVQUFVLENBQUMsQ0FBQztDQUN4QjtDQUVBLFFBQVEsT0FBTyxTQUFTLEtBQUssUUFBUTtFQUNuQyxLQUFLLFNBQVMsUUFBUSxTQUFVLEdBQUc7R0FDakMsT0FBTyxFQUFFLEtBQUssUUFBUSxJQUFJO0VBQzVCLENBQUM7Q0FDSDtDQUVBLE9BQU87QUFDVCxFQUFFO0FBUUYsSUFBSSxRQUFRO0NBQ1YsZ0JBQWdCLFNBQVMsaUJBQWlCO0VBQ3hDLEtBQUssSUFBSSxRQUFRLFVBQVUsUUFBUSxPQUFPLElBQUksTUFBTSxLQUFLLEdBQUcsUUFBUSxHQUFHLFFBQVEsT0FBTyxTQUNwRixLQUFLLFNBQVMsVUFBVTtFQUcxQixLQUFLLFFBQVEsU0FBVSxRQUFRO0dBQzdCLE9BQU8sY0FBYyxNQUFNO0VBQzdCLENBQUM7Q0FDSDtDQUNBLFVBQVUsU0FBUyxTQUFTLE1BQU07RUFDaEMsT0FBTyxJQUFJLFNBQVMsSUFBSTtDQUMxQjtDQUNBLGFBQWEsU0FBUyxZQUFZLFNBQVMsWUFBWTtFQUNyRCxPQUFPLGdCQUFnQixZQUFZLFNBQVMsVUFBVTtDQUN4RDtDQUNBLGFBQWEsU0FBUyxZQUFZLFFBQVEsVUFBVSxNQUFNLFNBQVM7RUFDakUsVUFBVSxNQUFNLE1BQU0sU0FBUyxRQUFRLE1BQU0sQ0FBQyxDQUFDO0VBRS9DLElBQUksU0FBUyxVQUFVLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUNqQyxTQUFTLE9BQU8sZUFBZTtFQUVuQyxTQUFTLGFBQWEsT0FBTztFQUM3QixPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsV0FBVyxTQUFVLFVBQVUsTUFBTSxTQUFTO0dBQ3ZFLE9BQU8sUUFBUSxTQUFTLGFBQWEsU0FBUyxTQUFTLENBQUMsT0FBTyxPQUFBLENBQVEsUUFBUSxVQUFVLE1BQU0sT0FBTyxDQUFDO0VBQ3pHLElBQUksUUFBUSxTQUFTLGFBQWEsU0FBUyxTQUFTLENBQUMsT0FBTyxPQUFBLENBQVEsUUFBUSxVQUFVLE1BQU0sT0FBTyxDQUFDO0NBQ3RHO0NBQ0EsYUFBYSxTQUFTLFlBQVksUUFBUSxVQUFVLE1BQU07RUFDeEQsU0FBUyxRQUFRLE1BQU07RUFFdkIsSUFBSSxPQUFPLFNBQVMsR0FBRztHQUNyQixJQUFJLFVBQVUsT0FBTyxJQUFJLFNBQVUsR0FBRztJQUNwQyxPQUFPLEtBQUssWUFBWSxHQUFHLFVBQVUsSUFBSTtHQUMzQyxDQUFDLEdBQ0csSUFBSSxRQUFRO0dBQ2hCLE9BQU8sU0FBVSxPQUFPO0lBQ3RCLElBQUksSUFBSTtJQUVSLE9BQU8sS0FDTCxRQUFRLEVBQUUsQ0FBQyxLQUFLO0dBRXBCO0VBQ0Y7RUFFQSxTQUFTLE9BQU8sTUFBTSxDQUFDO0VBRXZCLElBQUksU0FBUyxTQUFTLFdBQ2xCLFFBQVEsVUFBVSxNQUFNLEdBQ3hCLElBQUksTUFBTSxZQUFZLE1BQU0sUUFBUSxXQUFXLENBQUMsRUFBQSxDQUFHLGFBQWEsVUFFcEUsU0FBUyxTQUFTLFNBQVUsT0FBTztHQUNqQyxJQUFJLElBQUksSUFBSSxPQUFPO0dBQ25CLFlBQVksTUFBTTtHQUNsQixFQUFFLEtBQUssUUFBUSxPQUFPLFFBQVEsT0FBTyxPQUFPLGFBQWEsR0FBRyxDQUFDLE1BQU0sQ0FBQztHQUNwRSxFQUFFLE9BQU8sR0FBRyxDQUFDO0dBQ2IsWUFBWSxPQUFPLGtCQUFrQixHQUFHLFdBQVc7RUFDckQsSUFBSSxNQUFNLElBQUksUUFBUSxDQUFDO0VBRXZCLE9BQU8sU0FBUyxTQUFTLFNBQVUsT0FBTztHQUN4QyxPQUFPLE9BQU8sUUFBUSxHQUFHLE9BQU8sUUFBUSxPQUFPLE9BQU8sT0FBTyxDQUFDO0VBQ2hFO0NBQ0Y7Q0FDQSxTQUFTLFNBQVMsUUFBUSxRQUFRLFVBQVUsTUFBTTtFQUNoRCxJQUFJO0VBRUosSUFBSSxRQUFRLEtBQUssR0FBRyxRQUFRLGNBQWMsZ0JBQWdCLENBQUMsR0FBRyxjQUFjLFlBQVksU0FBUyxjQUFjLFNBQVMsTUFBTSxjQUFjLFVBQVUsR0FBRyxnQkFBZ0IsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUNoTCxPQUFPLFNBQVMsS0FBSyxPQUFPLE9BQU8saUJBQWlCO0dBQ3RELE9BQU8sTUFBTSxRQUFRLFVBQVUsT0FBTyxPQUFPLGVBQWU7RUFDOUQ7RUFFQSxLQUFLLFFBQVE7RUFDYixPQUFPO0NBQ1Q7Q0FDQSxZQUFZLFNBQVMsV0FBVyxTQUFTO0VBQ3ZDLE9BQU8sZ0JBQWdCLFlBQVksU0FBUyxJQUFJLENBQUMsQ0FBQyxTQUFTO0NBQzdEO0NBQ0EsVUFBVSxTQUFTLFNBQVMsT0FBTztFQUNqQyxTQUFTLE1BQU0sU0FBUyxNQUFNLE9BQU8sV0FBVyxNQUFNLE1BQU0sVUFBVSxJQUFJO0VBQzFFLE9BQU8sV0FBVyxXQUFXLFNBQVMsQ0FBQyxDQUFDO0NBQzFDO0NBQ0EsUUFBUSxTQUFTLE9BQU8sT0FBTztFQUM3QixPQUFPLFdBQVcsU0FBUyxTQUFTLENBQUMsQ0FBQztDQUN4QztDQUNBLGdCQUFnQixTQUFTLGVBQWUsT0FBTztFQUM3QyxJQUFJLE9BQU8sTUFBTSxNQUNiLFNBQVMsTUFBTSxRQUNmLFVBQVUsTUFBTSxTQUNoQixXQUFXLE1BQU0sVUFDakIsaUJBQWlCLE1BQU07RUFDM0IsQ0FBQyxXQUFXLEdBQUEsQ0FBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLFFBQVEsU0FBVSxZQUFZO0dBQ3ZELE9BQU8sY0FBYyxDQUFDLFNBQVMsZUFBZSxDQUFDLFNBQVMsZUFBZSxNQUFNLE9BQU8sc0JBQXNCLGFBQWEsVUFBVTtFQUNuSSxDQUFDO0VBRUQsU0FBUyxRQUFRLFNBQVUsU0FBUyxNQUFNLElBQUk7R0FDNUMsT0FBTyxPQUFPLFFBQVEsT0FBTyxHQUFHLGFBQWEsUUFBUSxDQUFDLEdBQUcsUUFBUSxHQUFHLEVBQUU7RUFDeEU7RUFFQSxJQUFJLGdCQUNGLFNBQVMsVUFBVSxRQUFRLFNBQVUsU0FBUyxNQUFNLFVBQVU7R0FDNUQsT0FBTyxLQUFLLElBQUksU0FBUyxLQUFLLENBQUMsU0FBUyxVQUFVLElBQUksSUFBSSxRQUFRLFdBQVcsU0FBUyxDQUFDLEdBQUcsSUFBSSxHQUFHLFFBQVE7RUFDM0c7Q0FFSjtDQUNBLGNBQWMsU0FBUyxhQUFhLE1BQU0sTUFBTTtFQUM5QyxTQUFTLFFBQVEsV0FBVyxJQUFJO0NBQ2xDO0NBQ0EsV0FBVyxTQUFTLFVBQVUsTUFBTSxhQUFhO0VBQy9DLE9BQU8sVUFBVSxTQUFTLFdBQVcsTUFBTSxXQUFXLElBQUk7Q0FDNUQ7Q0FDQSxTQUFTLFNBQVMsUUFBUSxJQUFJO0VBQzVCLE9BQU8sZ0JBQWdCLFFBQVEsRUFBRTtDQUNuQztDQUNBLFlBQVksU0FBUyxXQUFXLE1BQU0scUJBQXFCO0VBQ3pELElBQUksU0FBUyxLQUFLLEdBQ2hCLE9BQU8sQ0FBQztFQUdWLElBQUksS0FBSyxJQUFJLFNBQVMsSUFBSSxHQUN0QixPQUNBO0VBQ0osR0FBRyxvQkFBb0IsWUFBWSxLQUFLLGlCQUFpQjtFQUV6RCxnQkFBZ0IsT0FBTyxFQUFFO0VBRXpCLEdBQUcsTUFBTTtFQUVULEdBQUcsUUFBUSxHQUFHLFNBQVMsZ0JBQWdCO0VBQ3ZDLFFBQVEsZ0JBQWdCO0VBRXhCLE9BQU8sT0FBTztHQUNaLE9BQU8sTUFBTTtHQUViLElBQUksdUJBQXVCLEVBQUUsQ0FBQyxNQUFNLFFBQVEsaUJBQWlCLFNBQVMsTUFBTSxLQUFLLGVBQWUsTUFBTSxTQUFTLEtBQzdHLGVBQWUsSUFBSSxPQUFPLE1BQU0sU0FBUyxNQUFNLE1BQU07R0FHdkQsUUFBUTtFQUNWO0VBRUEsZUFBZSxpQkFBaUIsSUFBSSxDQUFDO0VBRXJDLE9BQU87Q0FDVDtDQUNBLFNBQVMsU0FBUyxRQUFRLE1BQU0sT0FBTztFQUNyQyxPQUFPLE9BQU8sSUFBSSxRQUFRLE1BQU0sS0FBSyxJQUFJO0NBQzNDO0NBQ0EsWUFBWSxTQUFTLFdBQVcsT0FBTztFQUNyQyxPQUFPLElBQUksV0FBVyxLQUFLO0NBQzdCO0NBQ0EsbUJBQW1CLFNBQVMsb0JBQW9CO0VBQzlDLE9BQU8sT0FBTyxRQUFRLFNBQVUsR0FBRztHQUNqQyxJQUFJLE9BQU8sRUFBRSxZQUNULE9BQ0E7R0FFSixLQUFLLEtBQUssTUFDUixJQUFJLEtBQUssSUFBSTtJQUNYLEtBQUssS0FBSztJQUNWLFFBQVE7R0FDVjtHQUdGLFNBQVMsRUFBRSxPQUFPO0VBQ3BCLENBQUMsS0FBSyxlQUFlO0NBQ3ZCO0NBQ0Esa0JBQWtCLFNBQVMsaUJBQWlCLE1BQU0sVUFBVTtFQUMxRCxJQUFJLElBQUksV0FBVyxVQUFVLFdBQVcsUUFBUSxDQUFDO0VBQ2pELENBQUMsRUFBRSxRQUFRLFFBQVEsS0FBSyxFQUFFLEtBQUssUUFBUTtDQUN6QztDQUNBLHFCQUFxQixTQUFTLG9CQUFvQixNQUFNLFVBQVU7RUFDaEUsSUFBSSxJQUFJLFdBQVcsT0FDZixJQUFJLEtBQUssRUFBRSxRQUFRLFFBQVE7RUFDL0IsS0FBSyxLQUFLLEVBQUUsT0FBTyxHQUFHLENBQUM7Q0FDekI7Q0FDQSxPQUFPO0VBQ0M7RUFDSTtFQUNFO0VBQ0o7RUFDRjtFQUNLO0VBQ0Y7RUFDRjtFQUNLO0VBQ0g7RUFDQztFQUNBO0VBQ0o7RUFDRztFQUNJO0VBQ0o7Q0FDWDtDQUNBLFNBQVM7Q0FDVCxTQUFTO0NBQ1QsUUFBUTtDQUNSLFlBQVksU0FBUztDQUNyQixTQUFTO0NBQ1QsZ0JBQWdCO0NBQ2hCLE1BQU07RUFDTztFQUNYLFNBQVM7RUFDRjtFQUNHO0VBQ0M7RUFDWCxVQUFVO0VBQ2E7RUFDdkIsV0FBVyxTQUFTLFlBQVk7R0FDOUIsT0FBT0g7RUFDVDtFQUNBLFNBQVMsU0FBUyxRQUFRLE9BQU87R0FDL0IsSUFBSSxTQUFTLFVBQVU7SUFDckIsU0FBUyxLQUFLLEtBQUssS0FBSztJQUV4QixNQUFNLE9BQU87R0FDZjtHQUVBLE9BQU87RUFDVDtFQUNBLG9CQUFvQixTQUFTLG1CQUFtQixPQUFPO0dBQ3JELE9BQU8sc0JBQXNCO0VBQy9CO0NBQ0Y7QUFDRjtBQUVBLGFBQWEsK0NBQStDLFNBQVUsTUFBTTtDQUMxRSxPQUFPLE1BQU0sUUFBUSxNQUFNO0FBQzdCLENBQUM7QUFFRCxRQUFRLElBQUksU0FBUyxVQUFVO0FBRS9CLGNBQWMsTUFBTSxHQUFHLENBQUMsR0FBRyxFQUN6QixVQUFVLEVBQ1osQ0FBQztBQUVELElBQUksc0JBQXNCLFNBQVMsb0JBQW9CLFFBQVEsTUFBTTtDQUNuRSxJQUFJLEtBQUssT0FBTztDQUVoQixPQUFPLE1BQU0sR0FBRyxNQUFNLFFBQVEsR0FBRyxPQUFPLFFBQVEsR0FBRyxPQUFPLE1BQ3hELEtBQUssR0FBRztDQUdWLE9BQU87QUFDVDtJQUNJLGdCQUFnQixTQUFTLGNBQWMsT0FBTyxXQUFXO0NBQzNELElBQUksVUFBVSxNQUFNLFVBQ2hCLEdBQ0EsR0FDQTtDQUVKLEtBQUssS0FBSyxXQUFXO0VBQ25CLElBQUksUUFBUTtFQUVaLE9BQU8sS0FBSztHQUNWLEtBQUssTUFBTSxVQUFVLEVBQUUsQ0FBQztHQUV4QixJQUFJLE9BQU8sS0FBSyxHQUFHLElBQUk7SUFDckIsSUFBSSxHQUFHLEtBRUwsS0FBSyxvQkFBb0IsSUFBSSxDQUFDO0lBR2hDLE1BQU0sR0FBRyxZQUFZLEdBQUcsU0FBUyxVQUFVLElBQUksT0FBTyxRQUFRLElBQUksQ0FBQztHQUNyRTtFQUNGO0NBQ0Y7QUFDRjtJQUNJLHVCQUF1QixTQUFTLHFCQUFxQixNQUFNLFVBQVU7Q0FDdkUsT0FBTztFQUNDO0VBQ04sVUFBVTtFQUNWLFNBQVM7RUFFVCxNQUFNLFNBQVMsS0FBSyxRQUFRLE1BQU0sT0FBTztHQUN2QyxNQUFNLFVBQVUsU0FBVSxPQUFPO0lBQy9CLElBQUksTUFBTTtJQUVWLElBQUksVUFBVSxJQUFJLEdBQUc7S0FDbkIsT0FBTyxDQUFDO0tBRVIsYUFBYSxNQUFNLFNBQVUsTUFBTTtNQUNqQyxPQUFPLEtBQUssUUFBUTtLQUN0QixDQUFDO0tBR0QsT0FBTztJQUNUO0lBRUEsSUFBSSxVQUFVO0tBQ1osT0FBTyxDQUFDO0tBRVIsS0FBSyxLQUFLLE1BQ1IsS0FBSyxLQUFLLFNBQVMsS0FBSyxFQUFFO0tBRzVCLE9BQU87SUFDVDtJQUVBLGNBQWMsT0FBTyxJQUFJO0dBQzNCO0VBQ0Y7Q0FDRjtBQUNGO0FBR0EsSUFBVyxPQUFPLE1BQU0sZUFBZTtDQUNyQyxNQUFNO0NBQ04sTUFBTSxTQUFTLEtBQUssUUFBUSxNQUFNLE9BQU8sT0FBTyxTQUFTO0VBQ3ZELElBQUksR0FBRyxJQUFJO0VBQ1gsS0FBSyxRQUFRO0VBRWIsS0FBSyxLQUFLLE1BQU07R0FDZCxJQUFJLE9BQU8sYUFBYSxDQUFDLEtBQUs7R0FDOUIsS0FBSyxLQUFLLElBQUksUUFBUSxpQkFBaUIsS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sU0FBUyxHQUFHLEdBQUcsQ0FBQztHQUNyRixHQUFHLEtBQUs7R0FDUixHQUFHLElBQUk7R0FFUCxLQUFLLE9BQU8sS0FBSyxDQUFDO0VBQ3BCO0NBQ0Y7Q0FDQSxRQUFRLFNBQVMsT0FBTyxPQUFPLE1BQU07RUFDbkMsSUFBSSxLQUFLLEtBQUs7RUFFZCxPQUFPLElBQUk7R0FDVCxlQUFhLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksR0FBRyxFQUFFLE9BQU8sR0FBRyxDQUFDO0dBRTVELEtBQUssR0FBRztFQUNWO0NBQ0Y7QUFDRixHQUFHO0NBQ0QsTUFBTTtDQUNOLFVBQVU7Q0FDVixNQUFNLFNBQVMsS0FBSyxRQUFRLE9BQU87RUFDakMsSUFBSSxJQUFJLE1BQU07RUFFZCxPQUFPLEtBQ0wsS0FBSyxJQUFJLFFBQVEsR0FBRyxPQUFPLE1BQU0sR0FBRyxNQUFNLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7Q0FFbEU7QUFDRixHQUFHLHFCQUFxQixjQUFjLGNBQWMsR0FBRyxxQkFBcUIsV0FBVyxHQUFHLHFCQUFxQixRQUFRLElBQUksQ0FBQyxLQUFLO0FBRWpJLE1BQU0sVUFBVSxTQUFTLFVBQVUsS0FBSyxVQUFVO0FBQ2xELGFBQWE7QUFDYkUsZ0JBQWMsS0FBSyxNQUFNO0FBQ3pCLElBQUksU0FBUyxTQUFTO0lBQ2xCLFNBQVMsU0FBUztJQUNsQixTQUFTLFNBQVM7SUFDbEIsU0FBUyxTQUFTO0lBQ2xCLFNBQVMsU0FBUztJQUNsQixTQUFTLFNBQVM7SUFDbEIsT0FBTyxTQUFTO0lBQ2hCLFFBQVEsU0FBUztJQUNqQixRQUFRLFNBQVM7SUFDakIsUUFBUSxTQUFTO0lBQ2pCLFNBQVMsU0FBUztJQUNsQixVQUFVLFNBQVM7SUFDbkIsT0FBTyxTQUFTO0lBQ2hCLGNBQWMsU0FBUztJQUN2QixTQUFTLFNBQVM7SUFDbEIsT0FBTyxTQUFTO0lBQ2hCLE9BQU8sU0FBUztJQUNoQixPQUFPLFNBQVM7Ozs7Ozs7Ozs7O0FDLzJJcEIsSUFBSTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBRUE7SUFDQTtJQUNBLGdCQUFnQixTQUFTLGdCQUFnQjtDQUMzQyxPQUFPLE9BQU8sV0FBVztBQUMzQjtJQUNJLGtCQUFrQixDQUFDO0lBQ25CLFdBQVcsTUFBTSxLQUFLO0lBQ3RCLFdBQVcsS0FBSyxLQUFLO0lBQ3JCLFNBQVMsS0FBSztJQUNkLFVBQVU7SUFDVixXQUFXO0lBQ1gsaUJBQWlCO0lBQ2pCLGNBQWM7SUFDZCxtQkFBbUI7Q0FDckIsV0FBVztDQUNYLE9BQU87Q0FDUCxPQUFPO0FBQ1Q7SUFDSSxpQkFBaUIsU0FBUyxlQUFlLE9BQU8sTUFBTTtDQUN4RCxPQUFPLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLFNBQVMsR0FBSyxJQUFJLE1BQVEsS0FBSyxHQUFHLElBQUk7QUFDdEc7SUFDSSxxQkFBcUIsU0FBUyxtQkFBbUIsT0FBTyxNQUFNO0NBQ2hFLE9BQU8sS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLEdBQUcsVUFBVSxJQUFJLEtBQUssSUFBSSxLQUFLLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxTQUFTLEdBQUssSUFBSSxNQUFRLEtBQUssR0FBRyxJQUFJO0FBQzdIO0lBQ0ksOEJBQThCLFNBQVMsNEJBQTRCLE9BQU8sTUFBTTtDQUNsRixPQUFPLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLFFBQVEsS0FBSyxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxHQUFLLElBQUksTUFBUSxLQUFLLElBQUksS0FBSyxHQUFHLElBQUk7QUFDdkg7SUFFQSxvQ0FBb0MsU0FBUyxrQ0FBa0MsT0FBTyxNQUFNO0NBQzFGLE9BQU8sS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLEdBQUcsVUFBVSxJQUFJLEtBQUssSUFBSSxRQUFRLEtBQUssT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLFNBQVMsR0FBSyxJQUFJLE1BQVEsS0FBSyxJQUFJLEtBQUssR0FBRyxJQUFJO0FBQzlJO0lBRUEsd0JBQXdCLFNBQVMsc0JBQXNCLE9BQU8sTUFBTTtDQUNsRSxJQUFJLFFBQVEsS0FBSyxJQUFJLEtBQUssSUFBSTtDQUM5QixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLEVBQUUsU0FBUyxRQUFRLElBQUksTUFBTSxPQUFPLEtBQUssR0FBRyxJQUFJO0FBQzVFO0lBQ0ksMEJBQTBCLFNBQVMsd0JBQXdCLE9BQU8sTUFBTTtDQUMxRSxPQUFPLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLFFBQVEsS0FBSyxJQUFJLEtBQUssR0FBRyxJQUFJO0FBQy9EO0lBQ0ksbUNBQW1DLFNBQVMsaUNBQWlDLE9BQU8sTUFBTTtDQUM1RixPQUFPLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLFVBQVUsSUFBSSxLQUFLLElBQUksS0FBSyxHQUFHLElBQUk7QUFDckU7SUFDSSxrQkFBa0IsU0FBUyxnQkFBZ0IsUUFBUSxVQUFVLE9BQU87Q0FDdEUsT0FBTyxPQUFPLE1BQU0sWUFBWTtBQUNsQztJQUNJLGlCQUFpQixTQUFTLGVBQWUsUUFBUSxVQUFVLE9BQU87Q0FDcEUsT0FBTyxPQUFPLE1BQU0sWUFBWSxVQUFVLEtBQUs7QUFDakQ7SUFDSSxtQkFBbUIsU0FBUyxpQkFBaUIsUUFBUSxVQUFVLE9BQU87Q0FDeEUsT0FBTyxPQUFPLE1BQU0sWUFBWTtBQUNsQztJQUNJLGVBQWUsU0FBUyxhQUFhLFFBQVEsVUFBVSxPQUFPO0NBQ2hFLE9BQU8sT0FBTyxNQUFNLFNBQVMsT0FBTyxNQUFNLFNBQVM7QUFDckQ7SUFDSSx5QkFBeUIsU0FBUyx1QkFBdUIsUUFBUSxVQUFVLE9BQU8sTUFBTSxPQUFPO0NBQ2pHLElBQUksUUFBUSxPQUFPO0NBQ25CLE1BQU0sU0FBUyxNQUFNLFNBQVM7Q0FDOUIsTUFBTSxnQkFBZ0IsT0FBTyxLQUFLO0FBQ3BDO0lBQ0ksNkJBQTZCLFNBQVMsMkJBQTJCLFFBQVEsVUFBVSxPQUFPLE1BQU0sT0FBTztDQUN6RyxJQUFJLFFBQVEsT0FBTztDQUNuQixNQUFNLFlBQVk7Q0FDbEIsTUFBTSxnQkFBZ0IsT0FBTyxLQUFLO0FBQ3BDO0lBQ0ksaUJBQWlCO0lBQ2pCLHVCQUF1QixpQkFBaUI7SUFDeEMsYUFBYSxTQUFTLFdBQVcsVUFBVSxVQUFVO0NBQ3ZELElBQUksUUFBUTtDQUVaLElBQUksU0FBUyxLQUFLLFFBQ2QsUUFBUSxPQUFPLE9BQ2YsUUFBUSxPQUFPO0NBRW5CLElBQUksWUFBWSxtQkFBbUIsT0FBTztFQUN4QyxLQUFLLE1BQU0sS0FBSyxPQUFPLENBQUM7RUFFeEIsSUFBSSxhQUFhLGFBQWE7R0FDNUIsV0FBVyxpQkFBaUIsYUFBYTtHQUN6QyxDQUFDLFNBQVMsUUFBUSxHQUFHLElBQUksU0FBUyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0lBQ2hFLE9BQU8sTUFBTSxJQUFJLEtBQUssS0FBSyxRQUFRLENBQUM7R0FDdEMsQ0FBQyxJQUFJLEtBQUssSUFBSSxZQUFZLE1BQU0sSUFBSSxNQUFNLFlBQVksS0FBSyxRQUFRLFFBQVE7R0FFM0UsYUFBYSx5QkFBeUIsS0FBSyxJQUFJLFVBQVUsTUFBTTtFQUNqRSxPQUNFLE9BQU8saUJBQWlCLFVBQVUsTUFBTSxHQUFHLENBQUMsQ0FBQyxRQUFRLFNBQVUsR0FBRztHQUNoRSxPQUFPLFdBQVcsS0FBSyxPQUFPLEdBQUcsUUFBUTtFQUMzQyxDQUFDO0VBR0gsSUFBSSxLQUFLLE1BQU0sUUFBUSxjQUFjLEtBQUssR0FDeEM7RUFHRixJQUFJLE1BQU0sS0FBSztHQUNiLEtBQUssT0FBTyxPQUFPLGFBQWEsaUJBQWlCO0dBQ2pELEtBQUssTUFBTSxLQUFLLHNCQUFzQixVQUFVLEVBQUU7RUFDcEQ7RUFFQSxXQUFXO0NBQ2I7Q0FFQSxDQUFDLFNBQVMsYUFBYSxLQUFLLE1BQU0sS0FBSyxVQUFVLFVBQVUsTUFBTSxTQUFTO0FBQzVFO0lBQ0ksK0JBQStCLFNBQVMsNkJBQTZCLE9BQU87Q0FDOUUsSUFBSSxNQUFNLFdBQVc7RUFDbkIsTUFBTSxlQUFlLFdBQVc7RUFDaEMsTUFBTSxlQUFlLE9BQU87RUFDNUIsTUFBTSxlQUFlLFFBQVE7Q0FDL0I7QUFDRjtJQUNJLGVBQWUsU0FBUyxlQUFlO0NBQ3pDLElBQUksUUFBUSxLQUFLLE9BQ2IsU0FBUyxLQUFLLFFBQ2QsUUFBUSxPQUFPLE9BQ2YsUUFBUSxPQUFPLE9BQ2YsR0FDQTtDQUVKLEtBQUssSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssR0FFakMsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUNiLE1BQU0sSUFBSSxLQUFLLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSSxLQUFLLE1BQU0sZUFBZSxNQUFNLEVBQUUsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLE9BQU8sTUFBTSxLQUFLLE1BQU0sRUFBRSxDQUFDLFFBQVEsVUFBVSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUM7TUFDM0osSUFBSSxNQUFNLElBQUksT0FBTyxHQUUxQixPQUFPLE1BQU0sR0FBRyxDQUFDLE1BQU0sSUFBSSxFQUFFO01BRzdCLE9BQU8sTUFBTSxNQUFNLE1BQU0sSUFBSTtDQUlqQyxJQUFJLEtBQUssS0FBSztFQUNaLEtBQUssS0FBSyxLQUFLLEtBQ2IsTUFBTSxLQUFLLEtBQUssSUFBSTtFQUd0QixJQUFJLE1BQU0sS0FBSztHQUNiLE1BQU0sZ0JBQWdCO0dBQ3RCLE9BQU8sYUFBYSxtQkFBbUIsS0FBSyxRQUFRLEVBQUU7RUFDeEQ7RUFFQSxJQUFJLFdBQVc7RUFFZixLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUUsWUFBWSxDQUFDLE1BQU0saUJBQWlCO0dBQ2hELDZCQUE2QixLQUFLO0dBRWxDLElBQUksTUFBTSxXQUFXLE1BQU0sdUJBQXVCO0lBQ2hELE1BQU0seUJBQXlCLE1BQU0sTUFBTSxVQUFVO0lBRXJELE1BQU0sVUFBVTtJQUNoQixNQUFNLGdCQUFnQjtHQUN4QjtHQUVBLE1BQU0sVUFBVTtFQUNsQjtDQUNGO0FBQ0Y7SUFDSSxpQkFBaUIsU0FBUyxlQUFlLFFBQVEsWUFBWTtDQUMvRCxJQUFJLFFBQVE7RUFDRjtFQUNSLE9BQU8sQ0FBQztFQUNSLFFBQVE7RUFDUixNQUFNO0NBQ1I7Q0FDQSxPQUFPLFNBQVMsS0FBSyxLQUFLLFNBQVMsTUFBTTtDQUV6QyxjQUFjLE9BQU8sU0FBUyxPQUFPLFlBQVksV0FBVyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0VBQzFGLE9BQU8sTUFBTSxLQUFLLENBQUM7Q0FDckIsQ0FBQztDQUVELE9BQU87QUFDVDtJQUNJO0lBQ0EsaUJBQWlCLFNBQVMsZUFBZSxNQUFNLElBQUk7Q0FDckQsSUFBSSxJQUFJLEtBQUssa0JBQWtCLEtBQUssaUJBQWlCLE1BQU0sK0JBQUEsQ0FBZ0MsUUFBUSxVQUFVLE1BQU0sR0FBRyxJQUFJLElBQUksS0FBSyxjQUFjLElBQUk7Q0FFckosT0FBTyxLQUFLLEVBQUUsUUFBUSxJQUFJLEtBQUssY0FBYyxJQUFJO0FBQ25EO0lBQ0ksdUJBQXVCLFNBQVMscUJBQXFCLFFBQVEsVUFBVSxvQkFBb0I7Q0FDN0YsSUFBSSxLQUFLLGlCQUFpQixNQUFNO0NBQ2hDLE9BQU8sR0FBRyxhQUFhLEdBQUcsaUJBQWlCLFNBQVMsUUFBUSxVQUFVLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsaUJBQWlCLFFBQVEsS0FBSyxDQUFDLHNCQUFzQixxQkFBcUIsUUFBUSxpQkFBaUIsUUFBUSxLQUFLLFVBQVUsQ0FBQyxLQUFLO0FBQ3BPO0lBQ0ksWUFBWSxxQkFBcUIsTUFBTSxHQUFHO0lBQzFDLG1CQUFtQixTQUFTLGlCQUFpQixVQUFVLFNBQVMsY0FBYztDQUNoRixJQUNJLEtBREksV0FBVyxTQUFBLENBQ1QsT0FDTixJQUFJO0NBRVIsSUFBSSxZQUFZLEtBQUssQ0FBQyxjQUNwQixPQUFPO0NBR1QsV0FBVyxTQUFTLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWSxJQUFJLFNBQVMsT0FBTyxDQUFDO0NBRS9ELE9BQU8sT0FBTyxFQUFFLFVBQVUsS0FBSyxZQUFZO0NBRTNDLE9BQU8sSUFBSSxJQUFJLFFBQVEsTUFBTSxJQUFJLE9BQU8sS0FBSyxJQUFJLFVBQVUsS0FBSyxNQUFNO0FBQ3hFO0lBQ0ksWUFBWSxTQUFTLFlBQVk7Q0FDbkMsSUFBSSxjQUFjLEtBQUssT0FBTyxVQUFVO0VBQ3RDLE9BQU87RUFDUCxPQUFPLEtBQUs7RUFDWixjQUFjLEtBQUs7RUFDbkIsV0FBVyxlQUFlLEtBQUssS0FBSyxFQUNsQyxPQUFPLENBQUMsRUFDVjtFQUNBLGVBQWdDLEtBQUs7RUFDckMsaUJBQWlCLGlCQUFpQixjQUFjO0VBQ2hELHVCQUF1QixpQkFBaUI7RUFDeEMsU0FBUyxNQUFNLFVBQVU7RUFFekIsY0FBYyxDQUFDLENBQUMsaUJBQWlCLGFBQWE7RUFDOUMsYUFBYSxLQUFLLEtBQUs7RUFDdkIsaUJBQWlCO0NBQ25CO0FBQ0Y7SUFDSSwwQkFBMEIsU0FBUyx3QkFBd0IsUUFBUTtDQUVyRSxJQUFJLFFBQVEsT0FBTyxpQkFDZixNQUFNLGVBQWUsT0FBTyxTQUFTLE1BQU0sYUFBYSxPQUFPLEtBQUssNEJBQTRCLEdBQ2hHLFFBQVEsT0FBTyxVQUFVLElBQUksR0FDN0I7Q0FFSixNQUFNLE1BQU0sVUFBVTtDQUN0QixJQUFJLFlBQVksS0FBSztDQUVyQixZQUFZLFlBQVksR0FBRztDQUUzQixJQUFJO0VBQ0YsT0FBTyxNQUFNLFFBQVE7Q0FDdkIsU0FBUyxHQUFHLENBQUM7Q0FFYixJQUFJLFlBQVksS0FBSztDQUVyQixZQUFZLFlBQVksR0FBRztDQUUzQixPQUFPO0FBQ1Q7SUFDSSx5QkFBeUIsU0FBUyx1QkFBdUIsUUFBUSxpQkFBaUI7Q0FDcEYsSUFBSSxJQUFJLGdCQUFnQjtDQUV4QixPQUFPLEtBQ0wsSUFBSSxPQUFPLGFBQWEsZ0JBQWdCLEVBQUUsR0FDeEMsT0FBTyxPQUFPLGFBQWEsZ0JBQWdCLEVBQUU7QUFHbkQ7SUFDSSxXQUFXLFNBQVMsU0FBUyxRQUFRO0NBQ3ZDLElBQUksUUFBUTtDQUVaLElBQUk7RUFDRixTQUFTLE9BQU8sUUFBUTtDQUMxQixTQUFTLE9BQU87RUFDZCxTQUFTLHdCQUF3QixNQUFNO0VBQ3ZDLFNBQVM7Q0FDWDtDQUVBLFdBQVcsT0FBTyxTQUFTLE9BQU8sV0FBVyxXQUFXLFNBQVMsd0JBQXdCLE1BQU07Q0FFL0YsT0FBTyxVQUFVLENBQUMsT0FBTyxTQUFTLENBQUMsT0FBTyxLQUFLLENBQUMsT0FBTyxJQUFJO0VBQ3pELEdBQUcsQ0FBQyx1QkFBdUIsUUFBUTtHQUFDO0dBQUs7R0FBTTtFQUFJLENBQUMsS0FBSztFQUN6RCxHQUFHLENBQUMsdUJBQXVCLFFBQVE7R0FBQztHQUFLO0dBQU07RUFBSSxDQUFDLEtBQUs7RUFDekQsT0FBTztFQUNQLFFBQVE7Q0FDVixJQUFJO0FBQ047SUFDSSxTQUFTLFNBQVMsT0FBTyxHQUFHO0NBQzlCLE9BQU8sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLEVBQUUsY0FBYyxFQUFFLG9CQUFvQixTQUFTLENBQUM7QUFDMUU7SUFFQSxrQkFBa0IsU0FBUyxnQkFBZ0IsUUFBUSxVQUFVO0NBQzNELElBQUksVUFBVTtFQUNaLElBQUksUUFBUSxPQUFPLE9BQ2Y7RUFFSixJQUFJLFlBQVksbUJBQW1CLGFBQWEsc0JBQzlDLFdBQVc7RUFHYixJQUFJLE1BQU0sZ0JBQWdCO0dBQ3hCLGNBQWMsU0FBUyxPQUFPLEdBQUcsQ0FBQztHQUVsQyxJQUFJLGdCQUFnQixRQUFRLFNBQVMsT0FBTyxHQUFHLENBQUMsTUFBTSxVQUVwRCxXQUFXLE1BQU07R0FHbkIsTUFBTSxlQUFlLGdCQUFnQixPQUFPLFdBQVcsU0FBUyxRQUFRLFVBQVUsS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDO0VBQ3hHLE9BRUUsTUFBTSxnQkFBZ0IsUUFBUTtDQUVsQztBQUNGO0lBQ0ksb0JBQW9CLFNBQVMsa0JBQWtCLFFBQVEsUUFBUSxVQUFVLFdBQVcsS0FBSyxjQUFjO0NBQ3pHLElBQUksS0FBSyxJQUFJLFVBQVUsT0FBTyxLQUFLLFFBQVEsVUFBVSxHQUFHLEdBQUcsZUFBZSxtQ0FBbUMsdUJBQXVCO0NBQ3BJLE9BQU8sTUFBTTtDQUNiLEdBQUcsSUFBSTtDQUNQLEdBQUcsSUFBSTtDQUVQLE9BQU8sT0FBTyxLQUFLLFFBQVE7Q0FFM0IsT0FBTztBQUNUO0lBQ0ksdUJBQXVCO0NBQ3pCLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsTUFBTTtBQUNSO0lBQ0ksc0JBQXNCO0NBQ3hCLE1BQU07Q0FDTixNQUFNO0FBQ1I7SUFFQSxpQkFBaUIsU0FBUyxlQUFlLFFBQVEsVUFBVSxPQUFPLE1BQU07Q0FDdEUsSUFBSSxXQUFXLFdBQVcsS0FBSyxLQUFLLEdBQ2hDLFdBQVcsUUFBUSxHQUFBLENBQUksS0FBSyxDQUFDLENBQUMsUUFBUSxXQUFXLEdBQUEsQ0FBSSxNQUFNLEtBQUssTUFFcEUsUUFBUSxTQUFTLE9BQ2IsYUFBYSxlQUFlLEtBQUssUUFBUSxHQUN6QyxZQUFZLE9BQU8sUUFBUSxZQUFZLE1BQU0sT0FDN0MsbUJBQW1CLFlBQVksV0FBVyxhQUFhLGFBQWEsVUFBVSxXQUM5RSxTQUFTLEtBQ1QsV0FBVyxTQUFTLE1BQ3BCLFlBQVksU0FBUyxLQUNyQixJQUNBLFFBQ0EsT0FDQTtDQUVKLElBQUksU0FBUyxXQUFXLENBQUMsWUFBWSxxQkFBcUIsU0FBUyxxQkFBcUIsVUFDdEYsT0FBTztDQUdULFlBQVksUUFBUSxDQUFDLGFBQWEsV0FBVyxlQUFlLFFBQVEsVUFBVSxPQUFPLElBQUk7Q0FDekYsUUFBUSxPQUFPLFVBQVUsT0FBTyxNQUFNO0NBRXRDLEtBQUssYUFBYSxZQUFZLFNBQVMsZ0JBQWdCLGFBQWEsQ0FBQyxTQUFTLFFBQVEsT0FBTyxJQUFJO0VBQy9GLEtBQUssUUFBUSxPQUFPLFFBQVEsQ0FBQyxDQUFDLGFBQWEsVUFBVSxZQUFZLE9BQU87RUFDeEUsT0FBTyxPQUFPLFlBQVksV0FBVyxLQUFLLFNBQVMsV0FBVyxNQUFNLEVBQUU7Q0FDeEU7Q0FFQSxNQUFNLGFBQWEsVUFBVSxZQUFZLFVBQVUsV0FBVyxVQUFVO0NBQ3hFLFNBQVMsU0FBUyxTQUFTLENBQUMsU0FBUyxRQUFRLE9BQU8sS0FBSyxTQUFTLFFBQVEsT0FBTyxlQUFlLENBQUMsWUFBWSxTQUFTLE9BQU87Q0FFN0gsSUFBSSxPQUNGLFVBQVUsT0FBTyxtQkFBbUIsQ0FBQyxFQUFBLENBQUc7Q0FHMUMsSUFBSSxDQUFDLFVBQVUsV0FBVyxRQUFRLENBQUMsT0FBTyxhQUN4QyxTQUFTLEtBQUs7Q0FHaEIsUUFBUSxPQUFPO0NBRWYsSUFBSSxTQUFTLGFBQWEsTUFBTSxTQUFTLGNBQWMsTUFBTSxTQUFTLFFBQVEsUUFBUSxDQUFDLE1BQU0sU0FDM0YsT0FBTyxPQUFPLFdBQVcsTUFBTSxRQUFRLE1BQU07TUFDeEM7RUFDTCxJQUFJLGNBQWMsYUFBYSxZQUFZLGFBQWEsVUFBVTtHQUVoRSxJQUFJLElBQUksT0FBTyxNQUFNO0dBQ3JCLE9BQU8sTUFBTSxZQUFZLFNBQVM7R0FDbEMsS0FBSyxPQUFPO0dBQ1osSUFBSSxPQUFPLE1BQU0sWUFBWSxJQUFJLGdCQUFnQixRQUFRLFFBQVE7RUFDbkUsT0FBTztHQUNMLENBQUMsYUFBYSxZQUFZLFFBQVEsQ0FBQyxvQkFBb0IscUJBQXFCLFFBQVEsU0FBUyxPQUFPLE1BQU0sV0FBVyxxQkFBcUIsUUFBUSxVQUFVO0dBQzVKLFdBQVcsV0FBVyxNQUFNLFdBQVc7R0FFdkMsT0FBTyxZQUFZLFFBQVE7R0FDM0IsS0FBSyxTQUFTO0dBQ2QsT0FBTyxZQUFZLFFBQVE7R0FDM0IsTUFBTSxXQUFXO0VBQ25CO0VBRUEsSUFBSSxjQUFjLFdBQVc7R0FDM0IsUUFBUSxVQUFVLE1BQU07R0FDeEIsTUFBTSxPQUFPLFFBQVE7R0FDckIsTUFBTSxRQUFRLE9BQU87RUFDdkI7Q0FDRjtDQUVBLE9BQU8sT0FBTyxXQUFXLEtBQUssV0FBVyxTQUFTLE1BQU0sV0FBVyxTQUFTLEtBQUssV0FBVyxDQUFDO0FBQy9GO0lBQ0ksT0FBTyxTQUFTLEtBQUssUUFBUSxVQUFVLE1BQU0sU0FBUztDQUN4RCxJQUFJO0NBQ0osa0JBQWtCLFVBQVU7Q0FFNUIsSUFBSSxZQUFZLG9CQUFvQixhQUFhLGFBQWE7RUFDNUQsV0FBVyxpQkFBaUI7RUFFNUIsSUFBSSxDQUFDLFNBQVMsUUFBUSxHQUFHLEdBQ3ZCLFdBQVcsU0FBUyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0NBRW5DO0NBRUEsSUFBSSxnQkFBZ0IsYUFBYSxhQUFhLGFBQWE7RUFDekQsUUFBUSxnQkFBZ0IsUUFBUSxPQUFPO0VBQ3ZDLFFBQVEsYUFBYSxvQkFBb0IsTUFBTSxZQUFZLE1BQU0sTUFBTSxNQUFNLFNBQVMsY0FBYyxxQkFBcUIsUUFBUSxvQkFBb0IsQ0FBQyxJQUFJLE1BQU0sTUFBTSxVQUFVO0NBQ2xMLE9BQU87RUFDTCxRQUFRLE9BQU8sTUFBTTtFQUVyQixJQUFJLENBQUMsU0FBUyxVQUFVLFVBQVUsV0FBVyxFQUFFLFFBQVEsR0FBQSxDQUFJLFFBQVEsT0FBTyxHQUN4RSxRQUFRLGNBQWMsYUFBYSxjQUFjLFNBQVMsQ0FBQyxRQUFRLFVBQVUsSUFBSSxLQUFLLHFCQUFxQixRQUFRLFFBQVEsS0FBSyxhQUFhLFFBQVEsUUFBUSxNQUFNLGFBQWEsWUFBWSxJQUFJO0NBRXBNO0NBRUEsT0FBTyxRQUFRLENBQUMsRUFBRSxRQUFRLEdBQUEsQ0FBSSxLQUFLLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxlQUFlLFFBQVEsVUFBVSxPQUFPLElBQUksSUFBSSxPQUFPO0FBQzdHO0lBQ0kseUJBQXlCLFNBQVMsdUJBQXVCLFFBQVEsTUFBTSxPQUFPLEtBQUs7Q0FFckYsSUFBSSxDQUFDLFNBQVMsVUFBVSxRQUFRO0VBRTlCLElBQUksSUFBSSxpQkFBaUIsTUFBTSxRQUFRLENBQUMsR0FDcEMsSUFBSSxLQUFLLHFCQUFxQixRQUFRLEdBQUcsQ0FBQztFQUU5QyxJQUFJLEtBQUssTUFBTSxPQUFPO0dBQ3BCLE9BQU87R0FDUCxRQUFRO0VBQ1YsT0FBTyxJQUFJLFNBQVMsZUFDbEIsUUFBUSxxQkFBcUIsUUFBUSxnQkFBZ0I7Q0FFekQ7Q0FFQSxJQUFJLEtBQUssSUFBSSxVQUFVLEtBQUssS0FBSyxPQUFPLE9BQU8sTUFBTSxHQUFHLEdBQUcsb0JBQW9CLEdBQzNFLFFBQVEsR0FDUixhQUFhLEdBQ2IsR0FDQSxRQUNBLGFBQ0EsVUFDQSxPQUNBLFlBQ0EsVUFDQSxRQUNBLE9BQ0EsU0FDQSxXQUNBO0NBQ0osR0FBRyxJQUFJO0NBQ1AsR0FBRyxJQUFJO0NBQ1AsU0FBUztDQUVULE9BQU87Q0FFUCxJQUFJLElBQUksVUFBVSxHQUFHLENBQUMsTUFBTSxVQUMxQixNQUFNLHFCQUFxQixRQUFRLElBQUksVUFBVSxHQUFHLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztDQUd2RSxJQUFJLFFBQVEsUUFBUTtFQUNsQixhQUFhLE9BQU8sTUFBTTtFQUMxQixPQUFPLE1BQU0sUUFBUTtFQUNyQixNQUFNLHFCQUFxQixRQUFRLElBQUksS0FBSztFQUM1QyxhQUFhLE9BQU8sTUFBTSxRQUFRLGFBQWEsZ0JBQWdCLFFBQVEsSUFBSTtDQUM3RTtDQUVBLElBQUksQ0FBQyxPQUFPLEdBQUc7Q0FFZixtQkFBbUIsQ0FBQztDQUdwQixRQUFRLEVBQUU7Q0FDVixNQUFNLEVBQUU7Q0FDUixjQUFjLE1BQU0sTUFBTSxlQUFlLEtBQUssQ0FBQztDQUMvQyxZQUFZLElBQUksTUFBTSxlQUFlLEtBQUssQ0FBQztDQUUzQyxJQUFJLFVBQVUsUUFBUTtFQUNwQixPQUFPLFNBQVMsZ0JBQWdCLEtBQUssR0FBRyxHQUFHO0dBQ3pDLFdBQVcsT0FBTztHQUNsQixRQUFRLElBQUksVUFBVSxPQUFPLE9BQU8sS0FBSztHQUV6QyxJQUFJLE9BQ0YsU0FBUyxRQUFRLEtBQUs7UUFDakIsSUFBSSxNQUFNLE9BQU8sRUFBRSxNQUFNLFdBQVcsTUFBTSxPQUFPLEVBQUUsTUFBTSxTQUM5RCxRQUFRO0dBR1YsSUFBSSxjQUFjLGFBQWEsWUFBWSxpQkFBaUIsS0FBSztJQUMvRCxXQUFXLFdBQVcsVUFBVSxLQUFLO0lBQ3JDLFlBQVksV0FBVyxRQUFRLFdBQVcsR0FBQSxDQUFJLE1BQU07SUFDcEQsU0FBUyxPQUFPLENBQUMsTUFBTSxRQUFRLFdBQVcsZUFBZSxVQUFVLFFBQVEsSUFBSTtJQUMvRSxTQUFTLFdBQVcsUUFBUTtJQUM1QixVQUFVLFNBQVMsUUFBUSxTQUFTLEdBQUEsQ0FBSSxNQUFNO0lBQzlDLFFBQVEsZ0JBQWdCLFlBQVksUUFBUTtJQUU1QyxJQUFJLENBQUMsU0FBUztLQUVaLFVBQVUsV0FBVyxRQUFRLE1BQU0sU0FBUztLQUU1QyxJQUFJLFVBQVUsSUFBSSxRQUFRO01BQ3hCLE9BQU87TUFDUCxHQUFHLEtBQUs7S0FDVjtJQUNGO0lBRUEsSUFBSSxjQUFjLFNBQ2hCLFdBQVcsZUFBZSxRQUFRLE1BQU0sWUFBWSxPQUFPLEtBQUs7SUFJbEUsR0FBRyxNQUFNO0tBQ1AsT0FBTyxHQUFHO0tBQ1YsR0FBRyxTQUFTLGVBQWUsSUFBSSxRQUFRO0tBRXZDLEdBQUc7S0FDSCxHQUFHLFNBQVM7S0FDWixHQUFHLFNBQVMsUUFBUSxLQUFLLFNBQVMsV0FBVyxLQUFLLFFBQVE7SUFDNUQ7R0FDRjtFQUNGO0VBRUEsR0FBRyxJQUFJLFFBQVEsSUFBSSxTQUFTLElBQUksVUFBVSxPQUFPLElBQUksTUFBTSxJQUFJO0NBQ2pFLE9BQ0UsR0FBRyxJQUFJLFNBQVMsYUFBYSxRQUFRLFNBQVMsbUNBQW1DO0NBR25GLFFBQVEsS0FBSyxHQUFHLE1BQU0sR0FBRyxJQUFJO0NBRTdCLEtBQUssTUFBTTtDQUVYLE9BQU87QUFDVDtJQUNJLG9CQUFvQjtDQUN0QixLQUFLO0NBQ0wsUUFBUTtDQUNSLE1BQU07Q0FDTixPQUFPO0NBQ1AsUUFBUTtBQUNWO0lBQ0ksZ0NBQWdDLFNBQVMsOEJBQThCLE9BQU87Q0FDaEYsSUFBSSxRQUFRLE1BQU0sTUFBTSxHQUFHLEdBQ3ZCLElBQUksTUFBTSxJQUNWLElBQUksTUFBTSxNQUFNO0NBRXBCLElBQUksTUFBTSxTQUFTLE1BQU0sWUFBWSxNQUFNLFVBQVUsTUFBTSxTQUFTO0VBRWxFLFFBQVE7RUFDUixJQUFJO0VBQ0osSUFBSTtDQUNOO0NBRUEsTUFBTSxLQUFLLGtCQUFrQixNQUFNO0NBQ25DLE1BQU0sS0FBSyxrQkFBa0IsTUFBTTtDQUNuQyxPQUFPLE1BQU0sS0FBSyxHQUFHO0FBQ3ZCO0lBQ0ksb0JBQW9CLFNBQVMsa0JBQWtCLE9BQU8sTUFBTTtDQUM5RCxJQUFJLEtBQUssU0FBUyxLQUFLLE1BQU0sVUFBVSxLQUFLLE1BQU0sTUFBTTtFQUN0RCxJQUFJLFNBQVMsS0FBSyxHQUNkLFFBQVEsT0FBTyxPQUNmLFFBQVEsS0FBSyxHQUNiLFFBQVEsT0FBTyxPQUNmLE1BQ0EsaUJBQ0E7RUFFSixJQUFJLFVBQVUsU0FBUyxVQUFVLE1BQU07R0FDckMsTUFBTSxVQUFVO0dBQ2hCLGtCQUFrQjtFQUNwQixPQUFPO0dBQ0wsUUFBUSxNQUFNLE1BQU0sR0FBRztHQUN2QixJQUFJLE1BQU07R0FFVixPQUFPLEVBQUUsSUFBSSxJQUFJO0lBQ2YsT0FBTyxNQUFNO0lBRWIsSUFBSSxnQkFBZ0IsT0FBTztLQUN6QixrQkFBa0I7S0FDbEIsT0FBTyxTQUFTLG9CQUFvQix1QkFBdUI7SUFDN0Q7SUFFQSxnQkFBZ0IsUUFBUSxJQUFJO0dBQzlCO0VBQ0Y7RUFFQSxJQUFJLGlCQUFpQjtHQUNuQixnQkFBZ0IsUUFBUSxjQUFjO0dBRXRDLElBQUksT0FBTztJQUNULE1BQU0sT0FBTyxPQUFPLGdCQUFnQixXQUFXO0lBQy9DLE1BQU0sUUFBUSxNQUFNLFNBQVMsTUFBTSxZQUFZO0lBRS9DLGdCQUFnQixRQUFRLENBQUM7SUFHekIsTUFBTSxVQUFVO0lBRWhCLDZCQUE2QixLQUFLO0dBQ3BDO0VBQ0Y7Q0FDRjtBQUNGO0lBRUEsZ0JBQWdCLEVBQ2QsWUFBWSxTQUFTLFdBQVcsUUFBUSxRQUFRLFVBQVUsVUFBVSxPQUFPO0NBQ3pFLElBQUksTUFBTSxTQUFTLGVBQWU7RUFDaEMsSUFBSSxLQUFLLE9BQU8sTUFBTSxJQUFJLFVBQVUsT0FBTyxLQUFLLFFBQVEsVUFBVSxHQUFHLEdBQUcsaUJBQWlCO0VBQ3pGLEdBQUcsSUFBSTtFQUNQLEdBQUcsS0FBSztFQUNSLEdBQUcsUUFBUTtFQUVYLE9BQU8sT0FBTyxLQUFLLFFBQVE7RUFFM0IsT0FBTztDQUNUO0FBQ0YsRUFpRUY7SUFPQSxvQkFBb0I7Q0FBQztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7QUFBQztJQUNqQyx3QkFBd0IsQ0FBQztJQUN6QixtQkFBbUIsU0FBUyxpQkFBaUIsT0FBTztDQUN0RCxPQUFPLFVBQVUsOEJBQThCLFVBQVUsVUFBVSxDQUFDO0FBQ3RFO0lBQ0kscUNBQXFDLFNBQVMsbUNBQW1DLFFBQVE7Q0FDM0YsSUFBSSxlQUFlLHFCQUFxQixRQUFRLGNBQWM7Q0FFOUQsT0FBTyxpQkFBaUIsWUFBWSxJQUFJLG9CQUFvQixhQUFhLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxPQUFPLENBQUMsQ0FBQyxJQUFJLE1BQU07QUFDOUc7SUFDSSxhQUFhLFNBQVMsV0FBVyxRQUFRLFNBQVM7Q0FDcEQsSUFBSSxRQUFRLE9BQU8sU0FBUyxVQUFVLE1BQU0sR0FDeEMsUUFBUSxPQUFPLE9BQ2YsU0FBUyxtQ0FBbUMsTUFBTSxHQUNsRCxRQUNBLGFBQ0EsTUFDQTtDQUVKLElBQUksTUFBTSxPQUFPLE9BQU8sYUFBYSxXQUFXLEdBQUc7RUFDakQsT0FBTyxPQUFPLFVBQVUsUUFBUSxZQUFZLENBQUMsQ0FBQztFQUU5QyxTQUFTO0dBQUMsS0FBSztHQUFHLEtBQUs7R0FBRyxLQUFLO0dBQUcsS0FBSztHQUFHLEtBQUs7R0FBRyxLQUFLO0VBQUM7RUFDeEQsT0FBTyxPQUFPLEtBQUssR0FBRyxNQUFNLGdCQUFnQixvQkFBb0I7Q0FDbEUsT0FBTyxJQUFJLFdBQVcscUJBQXFCLENBQUMsT0FBTyxnQkFBZ0IsV0FBVyxlQUFlLENBQUMsTUFBTSxLQUFLO0VBR3ZHLE9BQU8sTUFBTTtFQUNiLE1BQU0sVUFBVTtFQUNoQixTQUFTLE9BQU87RUFFaEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLGdCQUFnQixDQUFDLE9BQU8sc0JBQXNCLENBQUMsQ0FBQyxPQUFPO0dBRTVFLGFBQWE7R0FFYixjQUFjLE9BQU87R0FFckIsWUFBWSxZQUFZLE1BQU07RUFFaEM7RUFFQSxTQUFTLG1DQUFtQyxNQUFNO0VBQ2xELE9BQU8sTUFBTSxVQUFVLE9BQU8sZ0JBQWdCLFFBQVEsU0FBUztFQUUvRCxJQUFJLFlBQ0YsY0FBYyxPQUFPLGFBQWEsUUFBUSxXQUFXLElBQUksU0FBUyxPQUFPLFlBQVksTUFBTSxJQUFJLFlBQVksWUFBWSxNQUFNO0NBRWpJO0NBRUEsT0FBTyxXQUFXLE9BQU8sU0FBUyxJQUFJO0VBQUMsT0FBTztFQUFJLE9BQU87RUFBSSxPQUFPO0VBQUksT0FBTztFQUFJLE9BQU87RUFBSyxPQUFPO0NBQUcsSUFBSTtBQUMvRztJQUNJLGtCQUFrQixTQUFTLGdCQUFnQixRQUFRLFFBQVEsa0JBQWtCLFFBQVEsYUFBYSx5QkFBeUI7Q0FDN0gsSUFBSSxRQUFRLE9BQU8sT0FDZixTQUFTLGVBQWUsV0FBVyxRQUFRLElBQUksR0FDL0MsYUFBYSxNQUFNLFdBQVcsR0FDOUIsYUFBYSxNQUFNLFdBQVcsR0FDOUIsYUFBYSxNQUFNLFdBQVcsR0FDOUIsYUFBYSxNQUFNLFdBQVcsR0FDOUIsSUFBSSxPQUFPLElBQ1gsSUFBSSxPQUFPLElBQ1gsSUFBSSxPQUFPLElBQ1gsSUFBSSxPQUFPLElBQ1gsS0FBSyxPQUFPLElBQ1osS0FBSyxPQUFPLElBQ1osY0FBYyxPQUFPLE1BQU0sR0FBRyxHQUM5QixVQUFVLFdBQVcsWUFBWSxFQUFFLEtBQUssR0FDeEMsVUFBVSxXQUFXLFlBQVksRUFBRSxLQUFLLEdBQ3hDLFFBQ0EsYUFDQSxHQUNBO0NBRUosSUFBSSxDQUFDLGtCQUFrQjtFQUNyQixTQUFTLFNBQVMsTUFBTTtFQUN4QixVQUFVLE9BQU8sS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLFFBQVEsR0FBRyxJQUFJLFVBQVUsTUFBTSxPQUFPLFFBQVE7RUFDcEYsVUFBVSxPQUFPLEtBQUssRUFBRSxZQUFZLE1BQU0sWUFBWSxHQUFBLENBQUksUUFBUSxHQUFHLElBQUksVUFBVSxNQUFNLE9BQU8sU0FBUztDQUkzRyxPQUFPLElBQUksV0FBVyxzQkFBc0IsY0FBYyxJQUFJLElBQUksSUFBSSxJQUFJO0VBRXhFLElBQUksV0FBVyxJQUFJLGVBQWUsV0FBVyxDQUFDLElBQUksZ0JBQWdCLElBQUksS0FBSyxJQUFJLE1BQU07RUFDckYsSUFBSSxXQUFXLENBQUMsSUFBSSxlQUFlLFdBQVcsSUFBSSxnQkFBZ0IsSUFBSSxLQUFLLElBQUksTUFBTTtFQUNyRixVQUFVO0VBQ1YsVUFBVTtDQUNaO0NBRUEsSUFBSSxVQUFVLFdBQVcsU0FBUyxNQUFNLFFBQVE7RUFDOUMsS0FBSyxVQUFVO0VBQ2YsS0FBSyxVQUFVO0VBQ2YsTUFBTSxVQUFVLGNBQWMsS0FBSyxJQUFJLEtBQUssS0FBSztFQUNqRCxNQUFNLFVBQVUsY0FBYyxLQUFLLElBQUksS0FBSyxLQUFLO0NBQ25ELE9BQ0UsTUFBTSxVQUFVLE1BQU0sVUFBVTtDQUdsQyxNQUFNLFVBQVU7Q0FDaEIsTUFBTSxVQUFVO0NBQ2hCLE1BQU0sU0FBUyxDQUFDLENBQUM7Q0FDakIsTUFBTSxTQUFTO0NBQ2YsTUFBTSxtQkFBbUIsQ0FBQyxDQUFDO0NBQzNCLE9BQU8sTUFBTSx3QkFBd0I7Q0FFckMsSUFBSSx5QkFBeUI7RUFDM0Isa0JBQWtCLHlCQUF5QixPQUFPLFdBQVcsWUFBWSxPQUFPO0VBRWhGLGtCQUFrQix5QkFBeUIsT0FBTyxXQUFXLFlBQVksT0FBTztFQUVoRixrQkFBa0IseUJBQXlCLE9BQU8sV0FBVyxZQUFZLE1BQU0sT0FBTztFQUV0RixrQkFBa0IseUJBQXlCLE9BQU8sV0FBVyxZQUFZLE1BQU0sT0FBTztDQUN4RjtDQUVBLE9BQU8sYUFBYSxtQkFBbUIsVUFBVSxNQUFNLE9BQU87QUFDaEU7SUFDSSxrQkFBa0IsU0FBUyxnQkFBZ0IsUUFBUSxTQUFTO0NBQzlELElBQUksUUFBUSxPQUFPLFNBQVMsSUFBSSxRQUFRLE1BQU07Q0FFOUMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxXQUFXLENBQUMsTUFBTSxTQUNyQyxPQUFPO0NBR1QsSUFBSSxRQUFRLE9BQU8sT0FDZixpQkFBaUIsTUFBTSxTQUFTLEdBQ2hDLEtBQUssTUFDTCxNQUFNLE9BQ04sS0FBSyxpQkFBaUIsTUFBTSxHQUM1QixTQUFTLHFCQUFxQixRQUFRLG9CQUFvQixLQUFLLEtBQy9ELElBZ0NBLElBQUksSUFBSSxXQUFXLFlBQVksWUFBWSxRQUFRLFFBQVEsY0FBYyxHQS9CekUsR0FDQSxHQUNBLFNBOEJLLFNBQVMsR0E3QmQsUUFDQSxVQUNBLFdBQ0EsV0FDQSxPQUNBLE9BQ0EsYUFDQSxTQUNBLFNBQ0EsUUFDQSxPQUNBLEtBQ0EsS0FDQSxHQUNBLEdBQ0EsR0FDQSxHQUNBLEtBQ0EsS0FDQSxJQUNBLElBQ0EsSUFDQSxLQUNBLEtBQ0EsS0FDQSxLQUNBLEtBQ0E7Q0FHSixNQUFNLE1BQU0sQ0FBQyxFQUFFLE9BQU8sVUFBVSxPQUFPLE1BQU07Q0FFN0MsSUFBSSxHQUFHLFdBQVc7RUFFaEIsSUFBSSxHQUFHLGNBQWMsVUFBVSxHQUFHLFVBQVUsVUFBVSxHQUFHLFdBQVcsUUFDbEUsTUFBTSxtQkFBbUIsR0FBRyxjQUFjLFNBQVMsa0JBQWtCLEdBQUcsWUFBWSxPQUFBLENBQVEsTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUksT0FBTyxPQUFPLEdBQUcsV0FBVyxTQUFTLFlBQVksR0FBRyxTQUFTLE9BQU8sT0FBTyxHQUFHLFVBQVUsU0FBUyxXQUFXLEdBQUcsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLE9BQU8sT0FBTyxHQUFHLG9CQUFvQixTQUFTLEdBQUcsa0JBQWtCO0VBR2pWLE1BQU0sUUFBUSxNQUFNLFNBQVMsTUFBTSxZQUFZO0NBQ2pEO0NBRUEsU0FBUyxXQUFXLFFBQVEsTUFBTSxHQUFHO0NBRXJDLElBQUksTUFBTSxLQUFLO0VBQ2IsSUFBSSxNQUFNLFNBQVM7R0FFakIsS0FBSyxPQUFPLFFBQVE7R0FDcEIsU0FBUyxNQUFNLFVBQVUsR0FBRyxJQUFJLFNBQVMsTUFBTSxVQUFVLEdBQUcsS0FBSztHQUNqRSxLQUFLO0VBQ1AsT0FDRSxLQUFLLENBQUMsV0FBVyxPQUFPLGFBQWEsaUJBQWlCO0VBR3hELGdCQUFnQixRQUFRLE1BQU0sUUFBUSxDQUFDLENBQUMsTUFBTSxNQUFNLGtCQUFrQixNQUFNLFdBQVcsT0FBTyxNQUFNO0NBQ3RHO0NBRUEsVUFBVSxNQUFNLFdBQVc7Q0FDM0IsVUFBVSxNQUFNLFdBQVc7Q0FFM0IsSUFBSSxXQUFXLG1CQUFtQjtFQUNoQyxJQUFJLE9BQU87RUFFWCxJQUFJLE9BQU87RUFFWCxJQUFJLE9BQU87RUFFWCxJQUFJLE9BQU87RUFFWCxJQUFJLE1BQU0sT0FBTztFQUNqQixJQUFJLE1BQU0sT0FBTztFQUVqQixJQUFJLE9BQU8sV0FBVyxHQUFHO0dBQ3ZCLFNBQVMsS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLENBQUM7R0FDaEMsU0FBUyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQztHQUNoQyxXQUFXLEtBQUssSUFBSSxPQUFPLEdBQUcsQ0FBQyxJQUFJLFdBQVc7R0FFOUMsUUFBUSxLQUFLLElBQUksT0FBTyxHQUFHLENBQUMsSUFBSSxXQUFXLFdBQVc7R0FDdEQsVUFBVSxVQUFVLEtBQUssSUFBSSxLQUFLLElBQUksUUFBUSxRQUFRLENBQUM7R0FFdkQsSUFBSSxNQUFNLEtBQUs7SUFDYixLQUFLLFdBQVcsVUFBVSxJQUFJLFVBQVU7SUFDeEMsS0FBSyxXQUFXLFVBQVUsSUFBSSxVQUFVO0dBQzFDO0VBRUYsT0FBTztHQUNMLE1BQU0sT0FBTztHQUNiLE1BQU0sT0FBTztHQUNiLE1BQU0sT0FBTztHQUNiLE1BQU0sT0FBTztHQUNiLE1BQU0sT0FBTztHQUNiLE1BQU0sT0FBTztHQUNiLElBQUksT0FBTztHQUNYLElBQUksT0FBTztHQUNYLElBQUksT0FBTztHQUNYLFFBQVEsT0FBTyxLQUFLLEdBQUc7R0FDdkIsWUFBWSxRQUFRO0dBRXBCLElBQUksT0FBTztJQUNULE1BQU0sS0FBSyxJQUFJLENBQUMsS0FBSztJQUNyQixNQUFNLEtBQUssSUFBSSxDQUFDLEtBQUs7SUFDckIsS0FBSyxNQUFNLE1BQU0sTUFBTTtJQUN2QixLQUFLLE1BQU0sTUFBTSxNQUFNO0lBQ3ZCLEtBQUssTUFBTSxNQUFNLE1BQU07SUFDdkIsTUFBTSxNQUFNLENBQUMsTUFBTSxNQUFNO0lBQ3pCLE1BQU0sTUFBTSxDQUFDLE1BQU0sTUFBTTtJQUN6QixNQUFNLE1BQU0sQ0FBQyxNQUFNLE1BQU07SUFDekIsTUFBTSxNQUFNLENBQUMsTUFBTSxNQUFNO0lBQ3pCLE1BQU07SUFDTixNQUFNO0lBQ04sTUFBTTtHQUNSO0dBR0EsUUFBUSxPQUFPLENBQUMsR0FBRyxHQUFHO0dBQ3RCLFlBQVksUUFBUTtHQUVwQixJQUFJLE9BQU87SUFDVCxNQUFNLEtBQUssSUFBSSxDQUFDLEtBQUs7SUFDckIsTUFBTSxLQUFLLElBQUksQ0FBQyxLQUFLO0lBQ3JCLEtBQUssSUFBSSxNQUFNLE1BQU07SUFDckIsS0FBSyxJQUFJLE1BQU0sTUFBTTtJQUNyQixLQUFLLElBQUksTUFBTSxNQUFNO0lBQ3JCLE1BQU0sSUFBSSxNQUFNLE1BQU07SUFDdEIsSUFBSTtJQUNKLElBQUk7SUFDSixJQUFJO0dBQ047R0FHQSxRQUFRLE9BQU8sR0FBRyxDQUFDO0dBQ25CLFdBQVcsUUFBUTtHQUVuQixJQUFJLE9BQU87SUFDVCxNQUFNLEtBQUssSUFBSSxLQUFLO0lBQ3BCLE1BQU0sS0FBSyxJQUFJLEtBQUs7SUFDcEIsS0FBSyxJQUFJLE1BQU0sSUFBSTtJQUNuQixLQUFLLE1BQU0sTUFBTSxNQUFNO0lBQ3ZCLElBQUksSUFBSSxNQUFNLElBQUk7SUFDbEIsTUFBTSxNQUFNLE1BQU0sTUFBTTtJQUN4QixJQUFJO0lBQ0osTUFBTTtHQUNSO0dBRUEsSUFBSSxhQUFhLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLFFBQVEsSUFBSSxPQUFPO0lBRWpFLFlBQVksV0FBVztJQUN2QixZQUFZLE1BQU07R0FDcEI7R0FFQSxTQUFTLE9BQU8sS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLENBQUM7R0FDaEQsU0FBUyxPQUFPLEtBQUssS0FBSyxNQUFNLE1BQU0sTUFBTSxHQUFHLENBQUM7R0FDaEQsUUFBUSxPQUFPLEtBQUssR0FBRztHQUN2QixRQUFRLEtBQUssSUFBSSxLQUFLLElBQUksT0FBUyxRQUFRLFdBQVc7R0FDdEQsY0FBYyxNQUFNLEtBQUssTUFBTSxJQUFJLENBQUMsTUFBTSxPQUFPO0VBQ25EO0VBRUEsSUFBSSxNQUFNLEtBQUs7R0FFYixLQUFLLE9BQU8sYUFBYSxXQUFXO0dBQ3BDLE1BQU0sV0FBVyxPQUFPLGFBQWEsYUFBYSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIscUJBQXFCLFFBQVEsY0FBYyxDQUFDO0dBQ3ZILE1BQU0sT0FBTyxhQUFhLGFBQWEsRUFBRTtFQUMzQztDQUNGO0NBRUEsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUssSUFBSSxLQUM1QyxJQUFJLGdCQUFnQjtFQUNsQixVQUFVO0VBQ1YsU0FBUyxZQUFZLElBQUksTUFBTTtFQUMvQixZQUFZLFlBQVksSUFBSSxNQUFNO0NBQ3BDLE9BQU87RUFDTCxVQUFVO0VBQ1YsU0FBUyxTQUFTLElBQUksTUFBTTtDQUM5QjtDQUdGLFVBQVUsV0FBVyxNQUFNO0NBQzNCLE1BQU0sSUFBSSxNQUFNLE1BQU0sV0FBVyxNQUFNLENBQUMsV0FBVyxNQUFNLGFBQWEsS0FBSyxNQUFNLE9BQU8sY0FBYyxDQUFDLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQyxJQUFJLE1BQU0sT0FBTyxPQUFPLGNBQWMsTUFBTSxXQUFXLE1BQU0sS0FBSztDQUM1TCxNQUFNLElBQUksTUFBTSxNQUFNLFdBQVcsTUFBTSxDQUFDLFdBQVcsTUFBTSxhQUFhLEtBQUssTUFBTSxPQUFPLGVBQWUsQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDLENBQUMsSUFBSSxNQUFNLE9BQU8sT0FBTyxlQUFlLE1BQU0sV0FBVyxNQUFNLEtBQUs7Q0FDOUwsTUFBTSxJQUFJLElBQUk7Q0FDZCxNQUFNLFNBQVMsT0FBTyxNQUFNO0NBQzVCLE1BQU0sU0FBUyxPQUFPLE1BQU07Q0FDNUIsTUFBTSxXQUFXLE9BQU8sUUFBUSxJQUFJO0NBQ3BDLE1BQU0sWUFBWSxPQUFPLFNBQVMsSUFBSTtDQUN0QyxNQUFNLFlBQVksT0FBTyxTQUFTLElBQUk7Q0FDdEMsTUFBTSxRQUFRLFFBQVE7Q0FDdEIsTUFBTSxRQUFRLFFBQVE7Q0FDdEIsTUFBTSx1QkFBdUIsY0FBYztDQUUzQyxJQUFJLE1BQU0sVUFBVSxXQUFXLE9BQU8sTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxXQUFXLE1BQU0sV0FBVyxHQUNuRixNQUFNLHdCQUF3QixjQUFjLE1BQU07Q0FHcEQsTUFBTSxVQUFVLE1BQU0sVUFBVTtDQUNoQyxNQUFNLFVBQVUsUUFBUTtDQUN4QixNQUFNLGtCQUFrQixNQUFNLE1BQU0sdUJBQXVCLGNBQWMsdUJBQXVCO0NBQ2hHLE1BQU0sVUFBVTtDQUNoQixPQUFPO0FBQ1Q7SUFDSSxnQkFBZ0IsU0FBUyxjQUFjLE9BQU87Q0FDaEQsUUFBUSxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUEsQ0FBRyxLQUFLLE1BQU0sTUFBTTtBQUNyRDtJQUVBLGtCQUFrQixTQUFTLGdCQUFnQixRQUFRLE9BQU8sT0FBTztDQUMvRCxJQUFJLE9BQU8sUUFBUSxLQUFLO0NBQ3hCLE9BQU8sT0FBTyxXQUFXLEtBQUssSUFBSSxXQUFXLGVBQWUsUUFBUSxLQUFLLFFBQVEsTUFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJO0FBQ25HO0lBQ0kseUJBQXlCLFNBQVMsdUJBQXVCLE9BQU8sT0FBTztDQUN6RSxNQUFNLElBQUk7Q0FDVixNQUFNLFlBQVksTUFBTSxZQUFZO0NBQ3BDLE1BQU0sVUFBVTtDQUVoQixxQkFBcUIsT0FBTyxLQUFLO0FBQ25DO0lBQ0ksV0FBVztJQUNYLFVBQVU7SUFDVixrQkFBa0I7SUFDbEIsdUJBQXVCLFNBQVMscUJBQXFCLE9BQU8sT0FBTztDQUNyRSxJQUFJLE9BQU8sU0FBUyxNQUNoQixXQUFXLEtBQUssVUFDaEIsV0FBVyxLQUFLLFVBQ2hCLElBQUksS0FBSyxHQUNULElBQUksS0FBSyxHQUNULElBQUksS0FBSyxHQUNULFdBQVcsS0FBSyxVQUNoQixZQUFZLEtBQUssV0FDakIsWUFBWSxLQUFLLFdBQ2pCLFFBQVEsS0FBSyxPQUNiLFFBQVEsS0FBSyxPQUNiLFNBQVMsS0FBSyxRQUNkLFNBQVMsS0FBSyxRQUNkLHVCQUF1QixLQUFLLHNCQUM1QixVQUFVLEtBQUssU0FDZixTQUFTLEtBQUssUUFDZCxVQUFVLEtBQUssU0FDZixhQUFhLElBQ2IsUUFBUSxZQUFZLFVBQVUsU0FBUyxVQUFVLEtBQUssWUFBWTtDQUd0RSxJQUFJLFlBQVksY0FBYyxZQUFZLGNBQWMsV0FBVztFQUNqRSxJQUFJLFFBQVEsV0FBVyxTQUFTLElBQUksVUFDaEMsTUFBTSxLQUFLLElBQUksS0FBSyxHQUNwQixNQUFNLEtBQUssSUFBSSxLQUFLLEdBQ3BCO0VBRUosUUFBUSxXQUFXLFNBQVMsSUFBSTtFQUNoQyxNQUFNLEtBQUssSUFBSSxLQUFLO0VBQ3BCLElBQUksZ0JBQWdCLFFBQVEsR0FBRyxNQUFNLE1BQU0sQ0FBQyxPQUFPO0VBQ25ELElBQUksZ0JBQWdCLFFBQVEsR0FBRyxDQUFDLEtBQUssSUFBSSxLQUFLLElBQUksQ0FBQyxPQUFPO0VBQzFELElBQUksZ0JBQWdCLFFBQVEsR0FBRyxNQUFNLE1BQU0sQ0FBQyxVQUFVLE9BQU87Q0FDL0Q7Q0FFQSxJQUFJLHlCQUF5QixTQUMzQixjQUFjLGlCQUFpQix1QkFBdUI7Q0FHeEQsSUFBSSxZQUFZLFVBQ2QsY0FBYyxlQUFlLFdBQVcsUUFBUSxXQUFXO0NBRzdELElBQUksU0FBUyxNQUFNLFdBQVcsTUFBTSxXQUFXLE1BQU0sU0FDbkQsY0FBYyxNQUFNLFdBQVcsUUFBUSxpQkFBaUIsSUFBSSxPQUFPLElBQUksT0FBTyxJQUFJLE9BQU8sZUFBZSxJQUFJLE9BQU8sSUFBSTtDQUd6SCxJQUFJLGFBQWEsVUFDZixjQUFjLFlBQVksV0FBVztDQUd2QyxJQUFJLGNBQWMsVUFDaEIsY0FBYyxhQUFhLFlBQVk7Q0FHekMsSUFBSSxjQUFjLFVBQ2hCLGNBQWMsYUFBYSxZQUFZO0NBR3pDLElBQUksVUFBVSxZQUFZLFVBQVUsVUFDbEMsY0FBYyxVQUFVLFFBQVEsT0FBTyxRQUFRO0NBR2pELElBQUksV0FBVyxLQUFLLFdBQVcsR0FDN0IsY0FBYyxXQUFXLFNBQVMsT0FBTyxTQUFTO0NBR3BELE9BQU8sTUFBTSxrQkFBa0IsY0FBYztBQUMvQztJQUNJLHVCQUF1QixTQUFTLHFCQUFxQixPQUFPLE9BQU87Q0FDckUsSUFBSSxRQUFRLFNBQVMsTUFDakIsV0FBVyxNQUFNLFVBQ2pCLFdBQVcsTUFBTSxVQUNqQixJQUFJLE1BQU0sR0FDVixJQUFJLE1BQU0sR0FDVixXQUFXLE1BQU0sVUFDakIsUUFBUSxNQUFNLE9BQ2QsUUFBUSxNQUFNLE9BQ2QsU0FBUyxNQUFNLFFBQ2YsU0FBUyxNQUFNLFFBQ2YsU0FBUyxNQUFNLFFBQ2YsVUFBVSxNQUFNLFNBQ2hCLFVBQVUsTUFBTSxTQUNoQixVQUFVLE1BQU0sU0FDaEIsVUFBVSxNQUFNLFNBQ2hCLFdBQVcsTUFBTSxVQUNqQixLQUFLLFdBQVcsQ0FBQyxHQUNqQixLQUFLLFdBQVcsQ0FBQyxHQUNqQixLQUNBLEtBQ0EsS0FDQSxLQUNBO0NBRUosV0FBVyxXQUFXLFFBQVE7Q0FDOUIsUUFBUSxXQUFXLEtBQUs7Q0FDeEIsUUFBUSxXQUFXLEtBQUs7Q0FFeEIsSUFBSSxPQUFPO0VBRVQsUUFBUSxXQUFXLEtBQUs7RUFDeEIsU0FBUztFQUNULFlBQVk7Q0FDZDtDQUVBLElBQUksWUFBWSxPQUFPO0VBQ3JCLFlBQVk7RUFDWixTQUFTO0VBQ1QsTUFBTSxLQUFLLElBQUksUUFBUSxJQUFJO0VBQzNCLE1BQU0sS0FBSyxJQUFJLFFBQVEsSUFBSTtFQUMzQixNQUFNLEtBQUssSUFBSSxXQUFXLEtBQUssSUFBSSxDQUFDO0VBQ3BDLE1BQU0sS0FBSyxJQUFJLFdBQVcsS0FBSyxJQUFJO0VBRW5DLElBQUksT0FBTztHQUNULFNBQVM7R0FDVCxPQUFPLEtBQUssSUFBSSxRQUFRLEtBQUs7R0FDN0IsT0FBTyxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUk7R0FDaEMsT0FBTztHQUNQLE9BQU87R0FFUCxJQUFJLE9BQU87SUFDVCxPQUFPLEtBQUssSUFBSSxLQUFLO0lBQ3JCLE9BQU8sS0FBSyxLQUFLLElBQUksT0FBTyxJQUFJO0lBQ2hDLE9BQU87SUFDUCxPQUFPO0dBQ1Q7RUFDRjtFQUVBLE1BQU0sT0FBTyxHQUFHO0VBQ2hCLE1BQU0sT0FBTyxHQUFHO0VBQ2hCLE1BQU0sT0FBTyxHQUFHO0VBQ2hCLE1BQU0sT0FBTyxHQUFHO0NBQ2xCLE9BQU87RUFDTCxNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU0sTUFBTTtDQUNkO0NBRUEsSUFBSSxNQUFNLENBQUMsRUFBRSxJQUFJLEdBQUEsQ0FBSSxRQUFRLElBQUksS0FBSyxNQUFNLENBQUMsRUFBRSxJQUFJLEdBQUEsQ0FBSSxRQUFRLElBQUksR0FBRztFQUNwRSxLQUFLLGVBQWUsUUFBUSxLQUFLLEdBQUcsSUFBSTtFQUN4QyxLQUFLLGVBQWUsUUFBUSxLQUFLLEdBQUcsSUFBSTtDQUMxQztDQUVBLElBQUksV0FBVyxXQUFXLFdBQVcsU0FBUztFQUM1QyxLQUFLLE9BQU8sS0FBSyxXQUFXLFVBQVUsTUFBTSxVQUFVLE9BQU8sT0FBTztFQUNwRSxLQUFLLE9BQU8sS0FBSyxXQUFXLFVBQVUsTUFBTSxVQUFVLE9BQU8sT0FBTztDQUN0RTtDQUVBLElBQUksWUFBWSxVQUFVO0VBRXhCLE9BQU8sT0FBTyxRQUFRO0VBQ3RCLEtBQUssT0FBTyxLQUFLLFdBQVcsTUFBTSxLQUFLLEtBQUs7RUFDNUMsS0FBSyxPQUFPLEtBQUssV0FBVyxNQUFNLEtBQUssTUFBTTtDQUMvQztDQUVBLE9BQU8sWUFBWSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUs7Q0FDbkYsT0FBTyxhQUFhLGFBQWEsSUFBSTtDQUNyQyxhQUFhLE9BQU8sTUFBTSxrQkFBa0I7QUFDOUM7SUFDSSwwQkFBMEIsU0FBUyx3QkFBd0IsUUFBUSxRQUFRLFVBQVUsVUFBVSxVQUFVO0NBQzNHLElBQUksTUFBTSxLQUNOLFdBQVcsVUFBVSxRQUFRLEdBRTdCLFNBRFMsV0FBVyxRQUFRLEtBQUssWUFBWSxDQUFDLFNBQVMsUUFBUSxLQUFLLElBQUksV0FBVyxLQUNqRSxVQUNsQixhQUFhLFdBQVcsU0FBUyxPQUNqQyxXQUNBO0NBRUosSUFBSSxVQUFVO0VBQ1osWUFBWSxTQUFTLE1BQU0sR0FBRyxDQUFDLENBQUM7RUFFaEMsSUFBSSxjQUFjLFNBQVM7R0FDekIsVUFBVTtHQUVWLElBQUksV0FBVyxVQUFVLE1BQU0sSUFDN0IsVUFBVSxTQUFTLElBQUksTUFBTSxDQUFDO0VBRWxDO0VBRUEsSUFBSSxjQUFjLFFBQVEsU0FBUyxHQUNqQyxVQUFVLFNBQVMsTUFBTSxXQUFXLE1BQU0sQ0FBQyxFQUFFLFNBQVMsT0FBTztPQUN4RCxJQUFJLGNBQWMsU0FBUyxTQUFTLEdBQ3pDLFVBQVUsU0FBUyxNQUFNLFdBQVcsTUFBTSxDQUFDLEVBQUUsU0FBUyxPQUFPO0NBRWpFO0NBRUEsT0FBTyxNQUFNLEtBQUssSUFBSSxVQUFVLE9BQU8sS0FBSyxRQUFRLFVBQVUsVUFBVSxRQUFRLGtCQUFrQjtDQUNsRyxHQUFHLElBQUk7Q0FDUCxHQUFHLElBQUk7Q0FFUCxPQUFPLE9BQU8sS0FBSyxRQUFRO0NBRTNCLE9BQU87QUFDVDtJQUNJLFVBQVUsU0FBUyxRQUFRLFFBQVEsUUFBUTtDQUU3QyxLQUFLLElBQUksS0FBSyxRQUNaLE9BQU8sS0FBSyxPQUFPO0NBR3JCLE9BQU87QUFDVDtJQUNJLHNCQUFzQixTQUFTLG9CQUFvQixRQUFRLFlBQVksUUFBUTtDQUVqRixJQUFJLGFBQWEsUUFBUSxDQUFDLEdBQUcsT0FBTyxLQUFLLEdBQ3JDLFVBQVUsaURBQ1YsUUFBUSxPQUFPLE9BQ2YsVUFDQSxHQUNBLFlBQ0EsVUFDQSxVQUNBLFFBQ0EsV0FDQTtDQUVKLElBQUksV0FBVyxLQUFLO0VBQ2xCLGFBQWEsT0FBTyxhQUFhLFdBQVc7RUFDNUMsT0FBTyxhQUFhLGFBQWEsRUFBRTtFQUNuQyxNQUFNLGtCQUFrQjtFQUN4QixXQUFXLGdCQUFnQixRQUFRLENBQUM7RUFFcEMsZ0JBQWdCLFFBQVEsY0FBYztFQUV0QyxPQUFPLGFBQWEsYUFBYSxVQUFVO0NBQzdDLE9BQU87RUFDTCxhQUFhLGlCQUFpQixNQUFNLENBQUMsQ0FBQztFQUN0QyxNQUFNLGtCQUFrQjtFQUN4QixXQUFXLGdCQUFnQixRQUFRLENBQUM7RUFDcEMsTUFBTSxrQkFBa0I7Q0FDMUI7Q0FFQSxLQUFLLEtBQUssaUJBQWlCO0VBQ3pCLGFBQWEsV0FBVztFQUN4QixXQUFXLFNBQVM7RUFFcEIsSUFBSSxlQUFlLFlBQVksUUFBUSxRQUFRLENBQUMsSUFBSSxHQUFHO0dBRXJELFlBQVksUUFBUSxVQUFVO0dBQzlCLFVBQVUsUUFBUSxRQUFRO0dBQzFCLFdBQVcsY0FBYyxVQUFVLGVBQWUsUUFBUSxHQUFHLFlBQVksT0FBTyxJQUFJLFdBQVcsVUFBVTtHQUN6RyxTQUFTLFdBQVcsUUFBUTtHQUM1QixPQUFPLE1BQU0sSUFBSSxVQUFVLE9BQU8sS0FBSyxVQUFVLEdBQUcsVUFBVSxTQUFTLFVBQVUsY0FBYztHQUMvRixPQUFPLElBQUksSUFBSSxXQUFXO0dBRTFCLE9BQU8sT0FBTyxLQUFLLENBQUM7RUFDdEI7Q0FDRjtDQUVBLFFBQVEsVUFBVSxVQUFVO0FBQzlCO0FBR0EsYUFBYSwrQkFBK0IsU0FBVSxNQUFNLE9BQU87Q0FDakUsSUFBSSxJQUFJLE9BQ0osSUFBSSxTQUNKLElBQUksVUFDSixJQUFJLFFBQ0osU0FBUyxRQUFRLElBQUk7RUFBQztFQUFHO0VBQUc7RUFBRztDQUFDLElBQUk7RUFBQyxJQUFJO0VBQUcsSUFBSTtFQUFHLElBQUk7RUFBRyxJQUFJO0NBQUMsRUFBQSxDQUFHLElBQUksU0FBVSxNQUFNO0VBQ3hGLE9BQU8sUUFBUSxJQUFJLE9BQU8sT0FBTyxXQUFXLE9BQU87Q0FDckQsQ0FBQztDQUVELGNBQWMsUUFBUSxJQUFJLFdBQVcsT0FBTyxRQUFRLFNBQVUsUUFBUSxRQUFRLFVBQVUsVUFBVSxPQUFPO0VBQ3ZHLElBQUksR0FBRztFQUVQLElBQUksVUFBVSxTQUFTLEdBQUc7R0FFeEIsSUFBSSxNQUFNLElBQUksU0FBVSxNQUFNO0lBQzVCLE9BQU8sS0FBSyxRQUFRLE1BQU0sUUFBUTtHQUNwQyxDQUFDO0dBQ0QsT0FBTyxFQUFFLEtBQUssR0FBRztHQUNqQixPQUFPLEtBQUssTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFdBQVcsSUFBSSxFQUFFLEtBQUs7RUFDaEQ7RUFFQSxLQUFLLFdBQVcsR0FBQSxDQUFJLE1BQU0sR0FBRztFQUM3QixPQUFPLENBQUM7RUFDUixNQUFNLFFBQVEsU0FBVSxNQUFNLEdBQUc7R0FDL0IsT0FBTyxLQUFLLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxHQUFHLElBQUksS0FBSyxJQUFJO0VBQ3JELENBQUM7RUFDRCxPQUFPLEtBQUssUUFBUSxNQUFNLEtBQUs7Q0FDakM7QUFDRixDQUFDO0FBRUQsSUFBVyxZQUFZO0NBQ3JCLE1BQU07Q0FDTixVQUFVO0NBQ1YsWUFBWSxTQUFTLFdBQVcsUUFBUTtFQUN0QyxPQUFPLE9BQU8sU0FBUyxPQUFPO0NBQ2hDO0NBQ0EsTUFBTSxTQUFTLEtBQUssUUFBUSxNQUFNLE9BQU8sT0FBTyxTQUFTO0VBQ3ZELElBQUksUUFBUSxLQUFLLFFBQ2IsUUFBUSxPQUFPLE9BQ2YsVUFBVSxNQUFNLEtBQUssU0FDckIsWUFDQSxVQUNBLFFBQ0EsVUFDQSxNQUNBLGFBQ0EsR0FDQSxXQUNBLFNBQ0EsVUFDQSxvQkFDQSxvQkFDQSxPQUNBLFFBQ0EsYUFDQSxhQUNBO0VBQ0osa0JBQWtCLFVBQVU7RUFFNUIsS0FBSyxTQUFTLEtBQUssVUFBVSxlQUFlLE1BQU07RUFDbEQsY0FBYyxLQUFLLE9BQU87RUFDMUIsS0FBSyxRQUFRO0VBRWIsS0FBSyxLQUFLLE1BQU07R0FDZCxJQUFJLE1BQU0sYUFDUjtHQUdGLFdBQVcsS0FBSztHQUVoQixJQUFJLFNBQVMsTUFBTSxhQUFhLEdBQUcsTUFBTSxPQUFPLE9BQU8sUUFBUSxPQUFPLEdBRXBFO0dBR0YsT0FBTyxPQUFPO0dBQ2QsY0FBYyxjQUFjO0dBRTVCLElBQUksU0FBUyxZQUFZO0lBQ3ZCLFdBQVcsU0FBUyxLQUFLLE9BQU8sT0FBTyxRQUFRLE9BQU87SUFDdEQsT0FBTyxPQUFPO0dBQ2hCO0dBRUEsSUFBSSxTQUFTLFlBQVksQ0FBQyxTQUFTLFFBQVEsU0FBUyxHQUNsRCxXQUFXLGVBQWUsUUFBUTtHQUdwQyxJQUFJLGFBQ0YsWUFBWSxNQUFNLFFBQVEsR0FBRyxVQUFVLEtBQUssTUFBTSxjQUFjO1FBQzNELElBQUksRUFBRSxPQUFPLEdBQUcsQ0FBQyxNQUFNLE1BQU07SUFFbEMsY0FBYyxpQkFBaUIsTUFBTSxDQUFDLENBQUMsaUJBQWlCLENBQUMsSUFBSSxHQUFBLENBQUksS0FBSztJQUN0RSxZQUFZO0lBQ1osVUFBVSxZQUFZO0lBRXRCLElBQUksQ0FBQyxVQUFVLEtBQUssVUFBVSxHQUFHO0tBRS9CLFlBQVksUUFBUSxVQUFVO0tBQzlCLFVBQVUsUUFBUSxRQUFRO0tBQzFCLFVBQVUsY0FBYyxZQUFZLGFBQWEsZUFBZSxRQUFRLEdBQUcsWUFBWSxPQUFPLElBQUksV0FBVyxjQUFjLFlBQVk7SUFDekk7SUFFQSxLQUFLLElBQUksT0FBTyxlQUFlLFlBQVksVUFBVSxPQUFPLFNBQVMsR0FBRyxHQUFHLENBQUM7SUFDNUUsTUFBTSxLQUFLLENBQUM7SUFDWixZQUFZLEtBQUssR0FBRyxHQUFHLE1BQU0sRUFBRTtHQUNqQyxPQUFPLElBQUksU0FBUyxhQUFhO0lBQy9CLElBQUksV0FBVyxLQUFLLFNBQVM7S0FFM0IsYUFBYSxPQUFPLFFBQVEsT0FBTyxhQUFhLFFBQVEsRUFBRSxDQUFDLEtBQUssT0FBTyxPQUFPLFFBQVEsT0FBTyxJQUFJLFFBQVE7S0FDekcsVUFBVSxVQUFVLEtBQUssQ0FBQyxXQUFXLFFBQVEsU0FBUyxNQUFNLGFBQWEsZUFBZSxVQUFVO0tBQ2xHLFFBQVEsYUFBYSxFQUFFLEtBQUssZUFBZSxXQUFXLGNBQWMsUUFBUSxNQUFNLE1BQU0sUUFBUSxLQUFLLFFBQVEsQ0FBQyxDQUFDLEtBQUs7S0FFcEgsQ0FBQyxhQUFhLEdBQUEsQ0FBSSxPQUFPLENBQUMsTUFBTSxRQUFRLGFBQWEsS0FBSyxRQUFRLENBQUM7SUFDckUsT0FDRSxhQUFhLEtBQUssUUFBUSxDQUFDO0lBRzdCLFdBQVcsV0FBVyxVQUFVO0lBQ2hDLFdBQVcsU0FBUyxZQUFZLFNBQVMsT0FBTyxDQUFDLE1BQU0sT0FBTyxTQUFTLE9BQU8sR0FBRyxDQUFDO0lBQ2xGLGFBQWEsV0FBVyxTQUFTLE9BQU8sQ0FBQztJQUN6QyxTQUFTLFdBQVcsUUFBUTtJQUU1QixJQUFJLEtBQUssa0JBQWtCO0tBQ3pCLElBQUksTUFBTSxhQUFhO01BRXJCLElBQUksYUFBYSxLQUFLLEtBQUssUUFBUSxZQUFZLE1BQU0sWUFBWSxRQUUvRCxXQUFXO01BR2IsWUFBWSxLQUFLLGNBQWMsR0FBRyxNQUFNLFVBQVU7TUFFbEQsa0JBQWtCLE1BQU0sT0FBTyxjQUFjLFdBQVcsWUFBWSxVQUFVLFNBQVMsWUFBWSxVQUFVLENBQUMsTUFBTTtLQUN0SDtLQUVBLElBQUksTUFBTSxXQUFXLE1BQU0sYUFBYTtNQUN0QyxJQUFJLGlCQUFpQjtNQUNyQixDQUFDLEVBQUUsUUFBUSxHQUFHLE1BQU0sSUFBSSxFQUFFLE1BQU0sR0FBRyxDQUFDLENBQUM7S0FDdkM7SUFDRjtJQUVBLHFCQUFxQixLQUFLO0lBRTFCLElBQUksb0JBQW9CO0tBQ3RCLEtBQUssT0FBTyxLQUFLLENBQUM7S0FDbEIsc0JBQXNCO0tBRXRCLElBQUksU0FBUyxZQUFZLFNBQVMsVUFBVSxHQUFHLENBQUMsTUFBTSxVQUFVO01BQzlELFdBQVcscUJBQXFCLFFBQVEsU0FBUyxVQUFVLEdBQUcsU0FBUyxRQUFRLEdBQUcsQ0FBQyxDQUFDO01BRXBGLElBQUksU0FBUyxVQUFVLEdBQUcsQ0FBQyxNQUFNLFNBQVM7T0FDeEMsSUFBSSxrQkFBa0IsT0FBTyxNQUFNO09BQ25DLE9BQU8sTUFBTSxjQUFjO09BQzNCLFdBQVcscUJBQXFCLFFBQVEsYUFBYTtPQUNyRCxrQkFBa0IsT0FBTyxNQUFNLGNBQWMsa0JBQWtCLGdCQUFnQixRQUFRLGFBQWE7TUFDdEc7TUFFQSxTQUFTLFdBQVcsUUFBUTtLQUM5QjtLQUVBLElBQUksQ0FBQyxvQkFBb0I7TUFDdkIsUUFBUSxPQUFPO01BQ2YsTUFBTSxtQkFBbUIsQ0FBQyxLQUFLLGtCQUFrQixnQkFBZ0IsUUFBUSxLQUFLLGNBQWM7TUFFNUYsU0FBUyxLQUFLLGlCQUFpQixTQUFTLE1BQU07TUFDOUMscUJBQXFCLEtBQUssTUFBTSxJQUFJLFVBQVUsS0FBSyxLQUFLLE9BQU8sZ0JBQWdCLEdBQUcsR0FBRyxNQUFNLGlCQUFpQixPQUFPLEdBQUcsRUFBRTtNQUV4SCxtQkFBbUIsTUFBTTtLQUMzQjtLQUVBLElBQUksTUFBTSxTQUFTO01BQ2pCLEtBQUssTUFBTSxJQUFJLFVBQVUsS0FBSyxLQUFLLE9BQU8sVUFBVSxNQUFNLFNBQVMsV0FBVyxlQUFlLE1BQU0sUUFBUSxXQUFXLE1BQU0sSUFBSSxVQUFVLE1BQU0sVUFBVSxHQUFHLGNBQWM7TUFDM0ssS0FBSyxJQUFJLElBQUk7TUFDYixNQUFNLEtBQUssVUFBVSxDQUFDO01BQ3RCLEtBQUs7S0FDUCxPQUFPLElBQUksTUFBTSxtQkFBbUI7TUFDbEMsWUFBWSxLQUFLLHNCQUFzQixHQUFHLE1BQU0scUJBQXFCO01BQ3JFLFdBQVcsOEJBQThCLFFBQVE7TUFFakQsSUFBSSxNQUFNLEtBQ1IsZ0JBQWdCLFFBQVEsVUFBVSxHQUFHLFFBQVEsR0FBRyxJQUFJO1dBQy9DO09BQ0wsVUFBVSxXQUFXLFNBQVMsTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFLEtBQUs7T0FFaEQsWUFBWSxNQUFNLFdBQVcsa0JBQWtCLE1BQU0sT0FBTyxXQUFXLE1BQU0sU0FBUyxPQUFPO09BRTdGLGtCQUFrQixNQUFNLE9BQU8sR0FBRyxjQUFjLFVBQVUsR0FBRyxjQUFjLFFBQVEsQ0FBQztNQUN0RjtNQUVBO0tBQ0YsT0FBTyxJQUFJLE1BQU0sYUFBYTtNQUM1QixnQkFBZ0IsUUFBUSxVQUFVLEdBQUcsUUFBUSxHQUFHLElBQUk7TUFFcEQ7S0FDRixPQUFPLElBQUksS0FBSyx1QkFBdUI7TUFDckMsd0JBQXdCLE1BQU0sT0FBTyxHQUFHLFVBQVUsV0FBVyxlQUFlLFVBQVUsV0FBVyxRQUFRLElBQUksUUFBUTtNQUVySDtLQUNGLE9BQU8sSUFBSSxNQUFNLGdCQUFnQjtNQUMvQixrQkFBa0IsTUFBTSxPQUFPLFVBQVUsTUFBTSxRQUFRLFFBQVE7TUFFL0Q7S0FDRixPQUFPLElBQUksTUFBTSxXQUFXO01BQzFCLE1BQU0sS0FBSztNQUNYO0tBQ0YsT0FBTyxJQUFJLE1BQU0sYUFBYTtNQUM1QixvQkFBb0IsTUFBTSxVQUFVLE1BQU07TUFFMUM7S0FDRjtJQUNGLE9BQU8sSUFBSSxFQUFFLEtBQUssUUFDaEIsSUFBSSxpQkFBaUIsQ0FBQyxLQUFLO0lBRzdCLElBQUksdUJBQXVCLFVBQVUsV0FBVyxPQUFPLFlBQVksYUFBYSxNQUFNLENBQUMsWUFBWSxLQUFLLFFBQVEsS0FBSyxLQUFLLE9BQU87S0FDL0gsYUFBYSxhQUFhLEdBQUEsQ0FBSSxRQUFRLFdBQVcsR0FBQSxDQUFJLE1BQU07S0FDM0QsV0FBVyxTQUFTO0tBRXBCLFVBQVUsUUFBUSxRQUFRLE1BQU0sS0FBSyxRQUFRLFFBQVEsUUFBUSxNQUFNLEtBQUs7S0FDeEUsY0FBYyxZQUFZLFdBQVcsZUFBZSxRQUFRLEdBQUcsWUFBWSxPQUFPO0tBQ2xGLEtBQUssTUFBTSxJQUFJLFVBQVUsS0FBSyxLQUFLLHFCQUFxQixRQUFRLE9BQU8sR0FBRyxXQUFXLFdBQVcsZUFBZSxVQUFVLFdBQVcsTUFBTSxJQUFJLFVBQVUsVUFBVSxDQUFDLHVCQUF1QixZQUFZLFFBQVEsTUFBTSxhQUFhLEtBQUssY0FBYyxRQUFRLHdCQUF3QixjQUFjO0tBQ2xTLEtBQUssSUFBSSxJQUFJLFdBQVc7S0FFeEIsSUFBSSxzQkFBc0Isd0JBQXdCLFVBQVU7TUFDMUQsS0FBSyxJQUFJLElBQUk7TUFDYixLQUFLLElBQUksSUFBSTtNQUNiLEtBQUssSUFBSSxJQUFJO0tBQ2YsT0FBTyxJQUFJLGNBQWMsV0FBVyxZQUFZLEtBQUs7TUFFbkQsS0FBSyxJQUFJLElBQUk7TUFDYixLQUFLLElBQUksSUFBSTtLQUNmO0lBQ0YsT0FBTyxJQUFJLEVBQUUsS0FBSztTQUNaLEtBQUssUUFFUCxLQUFLLElBQUksUUFBUSxHQUFHLGNBQWMsT0FBTyxJQUFJLFdBQVcsV0FBVyxXQUFXLFVBQVUsT0FBTyxPQUFPO1VBQ2pHLElBQUksTUFBTSxrQkFBa0I7TUFDakMsZUFBZSxHQUFHLFFBQVE7TUFFMUI7S0FDRjtXQUVBLHVCQUF1QixLQUFLLE1BQU0sUUFBUSxHQUFHLFlBQVksV0FBVyxXQUFXLFdBQVcsUUFBUTtJQUdwRyx1QkFBdUIsS0FBSyxRQUFRLFlBQVksS0FBSyxHQUFHLEdBQUcsTUFBTSxFQUFFLElBQUksT0FBTyxPQUFPLE9BQU8sYUFBYSxZQUFZLEtBQUssR0FBRyxHQUFHLE9BQU8sRUFBRSxDQUFDLENBQUMsSUFBSSxZQUFZLEtBQUssR0FBRyxHQUFHLGNBQWMsT0FBTyxFQUFFO0lBQzdMLE1BQU0sS0FBSyxDQUFDO0dBQ2Q7RUFDRjtFQUVBLGVBQWUsMEJBQTBCLElBQUk7Q0FDL0M7Q0FDQSxRQUFRLFNBQVMsT0FBTyxPQUFPLE1BQU07RUFDbkMsSUFBSSxLQUFLLE1BQU0sU0FBUyxDQUFDLFdBQVcsR0FBRztHQUNyQyxJQUFJLEtBQUssS0FBSztHQUVkLE9BQU8sSUFBSTtJQUNULEdBQUcsRUFBRSxPQUFPLEdBQUcsQ0FBQztJQUNoQixLQUFLLEdBQUc7R0FDVjtFQUNGLE9BQ0UsS0FBSyxPQUFPLE9BQU87Q0FFdkI7Q0FDQSxLQUFLO0NBQ0wsU0FBUztDQUNULFdBQVcsU0FBUyxVQUFVLFFBQVEsVUFBVSxRQUFRO0VBRXRELElBQUksSUFBSSxpQkFBaUI7RUFDekIsS0FBSyxFQUFFLFFBQVEsR0FBRyxJQUFJLE1BQU0sV0FBVztFQUN2QyxPQUFPLFlBQVksbUJBQW1CLGFBQWEseUJBQXlCLE9BQU8sTUFBTSxLQUFLLEtBQUssUUFBUSxHQUFHLEtBQUssVUFBVSx3QkFBd0IsU0FBUyxhQUFhLFVBQVUsZUFBZSxvQkFBb0Isc0JBQXNCLFVBQVUsQ0FBQyxPQUFPLGFBQWEsVUFBVSx5QkFBeUIsOEJBQThCLE9BQU8sU0FBUyxDQUFDLGFBQWEsT0FBTyxNQUFNLFNBQVMsSUFBSSxrQkFBa0IsQ0FBQyxTQUFTLFFBQVEsR0FBRyxJQUFJLGlCQUFpQixXQUFXLFFBQVEsUUFBUTtDQUMvZDtDQUNBLE1BQU07RUFDYTtFQUNMO0NBQ2Q7QUFDRjtBQUNBLEtBQUssTUFBTSxjQUFjO0FBQ3pCLEtBQUssS0FBSyxnQkFBZ0I7Q0FFekIsU0FBVSxrQkFBa0IsVUFBVSxRQUFRLFNBQVM7Q0FDdEQsSUFBSSxNQUFNLGFBQWEsbUJBQW1CLE1BQU0sV0FBVyxNQUFNLFFBQVEsU0FBVSxNQUFNO0VBQ3ZGLGdCQUFnQixRQUFRO0NBQzFCLENBQUM7Q0FFRCxhQUFhLFVBQVUsU0FBVSxNQUFNO0VBQ3JDLFFBQVEsTUFBTSxRQUFRO0VBQ3RCLHNCQUFzQixRQUFRO0NBQ2hDLENBQUM7Q0FFRCxpQkFBaUIsSUFBSSxPQUFPLG1CQUFtQixNQUFNO0NBRXJELGFBQWEsU0FBUyxTQUFVLE1BQU07RUFDcEMsSUFBSSxRQUFRLEtBQUssTUFBTSxHQUFHO0VBQzFCLGlCQUFpQixNQUFNLE1BQU0sSUFBSSxNQUFNO0NBQ3pDLENBQUM7QUFDSCxFQUFBLENBQUcsK0NBQStDLDRDQUE0QyxpRkFBaUYsNEZBQTRGO0FBRTNRLGFBQWEsZ0ZBQWdGLFNBQVUsTUFBTTtDQUMzRyxRQUFRLE1BQU0sUUFBUTtBQUN4QixDQUFDO0FBRUQsS0FBSyxlQUFlLFNBQVM7OztBQzNqRDdCLElBQUksY0FBYyxLQUFLLGVBQWUsU0FBUyxLQUFLO0lBRXBELGtCQUFrQixZQUFZLEtBQUsiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDJdfQ==