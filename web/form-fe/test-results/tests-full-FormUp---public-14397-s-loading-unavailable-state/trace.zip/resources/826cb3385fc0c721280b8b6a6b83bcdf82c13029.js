import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/form-runner/FormResultPage.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useParams, useNavigate, useLocation, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { CheckCircle2, Award, Home, RotateCcw, AlertTriangle, Send, Loader2, MessageSquare, Check, X, BookOpen, Lightbulb, HelpCircle, CheckCircle, ArrowRight, RefreshCw, Key, ExternalLink, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import { getPublicResponseResult, getPublicFormByLink, submitFeedback, getLocalUser } from "/src/services/apiService.js";
import { generateRemedialExplanation, getGeminiApiKeys } from "/src/services/aiService.js";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-runner/FormResultPage.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const OWNER_FEEDBACK_REASONS = [
	{
		value: "PERTANYAAN_TIDAK_JELAS",
		label: "Pertanyaan tidak jelas atau membingungkan"
	},
	{
		value: "KUNCI_JAWABAN_SALAH",
		label: "Kunci jawaban dinilai salah"
	},
	{
		value: "KENDALA_TEKNIS",
		label: "Kendala teknis saat pengisian"
	},
	{
		value: "LAINNYA",
		label: "Masukan lainnya untuk pemilik formulir"
	}
];
const ADMIN_REPORT_REASONS = [
	{
		value: "ADMIN_KONTEN_TIDAK_PANTAS",
		label: "Konten formulir tidak pantas / melanggar aturan"
	},
	{
		value: "ADMIN_SPAM_PENYALAHGUNAAN",
		label: "Formulir terindikasi spam atau disalahgunakan"
	},
	{
		value: "ADMIN_DATA_PRIBADI",
		label: "Formulir meminta data pribadi secara mencurigakan"
	},
	{
		value: "ADMIN_LAINNYA",
		label: "Pelanggaran lainnya (laporkan ke Admin FormUp)"
	}
];
export default function FormResultPage() {
	_s();
	const { formLink, responseId } = useParams();
	const navigate = useNavigate();
	const location = useLocation();
	const [form, setForm] = useState(null);
	const [result, setResult] = useState(null);
	const [loading, setLoading] = useState(true);
	// Feedback State
	const [feedbackOpen, setFeedbackOpen] = useState(false);
	const [feedbackTarget, setFeedbackTarget] = useState("owner");
	const [reason, setReason] = useState("PERTANYAAN_TIDAK_JELAS");
	const [description, setDescription] = useState("");
	const [sendingFeedback, setSendingFeedback] = useState(false);
	const [feedbackSuccess, setFeedbackSuccess] = useState(false);
	const [feedbackError, setFeedbackError] = useState("");
	// Remedial / Practice Assistant State
	const [remedialModalOpen, setRemedialModalOpen] = useState(false);
	const [activeRemedialQuestion, setActiveRemedialQuestion] = useState(null);
	const [remedialLoading, setRemedialLoading] = useState(false);
	const [remedialData, setRemedialData] = useState(null);
	const [remedialError, setRemedialError] = useState("");
	const [practiceSelectedOption, setPracticeSelectedOption] = useState(null);
	const [practiceSubmitted, setPracticeSubmitted] = useState(false);
	const [remedialKeyPromptOpen, setRemedialKeyPromptOpen] = useState(false);
	const user = getLocalUser();
	const currentReasonOptions = feedbackTarget === "admin" ? ADMIN_REPORT_REASONS : OWNER_FEEDBACK_REASONS;
	const handleChangeFeedbackTarget = (target) => {
		setFeedbackTarget(target);
		const options = target === "admin" ? ADMIN_REPORT_REASONS : OWNER_FEEDBACK_REASONS;
		setReason(options[0].value);
		setFeedbackError("");
	};
	useEffect(() => {
		const load = async () => {
			setLoading(true);
			// Fetch form info always (needed for title, showScore, feedback, etc.)
			const formRes = await getPublicFormByLink(formLink);
			if (formRes.ok) setForm(formRes.data);
			// guestToken passed from submit via router state
			const guestToken = location.state?.guestToken || null;
			// Fetch result — guestToken allows guest users to see their result
			const detailRes = await getPublicResponseResult(formLink, responseId, guestToken);
			if (detailRes.ok && detailRes.data) {
				setResult(detailRes.data);
			}
			setLoading(false);
		};
		load();
	}, [formLink, responseId]);
	const handleSendFeedback = async (e) => {
		e.preventDefault();
		setFeedbackError("");
		setSendingFeedback(true);
		const formId = form?.id || result?.formId;
		const res = await submitFeedback(formId, {
			reason,
			description: description.trim(),
			responseId: parseInt(responseId, 10) || null
		});
		setSendingFeedback(false);
		if (res.ok) {
			setFeedbackSuccess(true);
			setDescription("");
		} else {
			setFeedbackError(res.message || "Gagal mengirimkan masukan.");
		}
	};
	const handleOpenRemedial = async (answerItem) => {
		setActiveRemedialQuestion(answerItem);
		setRemedialModalOpen(true);
		setRemedialLoading(true);
		setRemedialError("");
		setRemedialData(null);
		setPracticeSelectedOption(null);
		setPracticeSubmitted(false);
		const keys = getGeminiApiKeys();
		if (keys.length === 0) {
			setRemedialLoading(false);
			setRemedialKeyPromptOpen(true);
			return;
		}
		try {
			const res = await generateRemedialExplanation({
				questionText: answerItem.question,
				questionType: answerItem.typeId || 2,
				userAnswer: answerItem.optionText || answerItem.answerText || "",
				correctAnswer: answerItem.correctAnswer || "",
				options: answerItem.options || []
			});
			if (res.ok && res.data) {
				setRemedialData(res.data);
			} else {
				setRemedialError(res.message || "Gagal memuat pembahasan materi.");
			}
		} catch (err) {
			setRemedialError(err.message || "Terjadi kesalahan saat memuat pembahasan.");
		} finally {
			setRemedialLoading(false);
		}
	};
	if (loading) return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center justify-center min-h-screen bg-[#F4F8F7] dark:bg-slate-950",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center space-y-2",
			children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin mx-auto text-[#00897B] dark:text-teal-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 154,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-slate-400 dark:text-slate-500 text-sm font-medium",
				children: "Memuat hasil formulir..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 153,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 152,
		columnNumber: 9
	}, this);
	const showScore = form?.showScore || form?.settings?.showScore || result?.showScore;
	const score = result?.score;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-[#F4F8F7] dark:bg-slate-950 font-sans antialiased text-slate-800 dark:text-slate-100 py-12 px-4 flex justify-center transition-colors",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-2xl w-full space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-8 sm:p-10 text-center shadow-xl space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-16 h-16 bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400 rounded-3xl flex items-center justify-center mx-auto shadow-xs",
								children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 36 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 25
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h1", {
									className: "text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight",
									children: "Respons Anda Telah Terkirim!"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 174,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium",
									children: [
										"Terima kasih telah meluangkan waktu untuk mengisi ",
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-800 dark:text-slate-200",
											children: form?.title || "formulir ini"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 178,
											columnNumber: 79
										}, this),
										"."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 177,
									columnNumber: 25
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 173,
								columnNumber: 21
							}, this),
							showScore && score != null && /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-linear-to-br from-teal-50/60 to-emerald-50/60 dark:from-teal-950/40 dark:to-slate-800 border border-teal-100 dark:border-teal-900/50 rounded-2xl p-6 space-y-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "inline-flex items-center gap-1 text-[11px] font-extrabold text-[#00897B] dark:text-teal-400 uppercase tracking-wider",
										children: [/* @__PURE__ */ _jsxDEV(Award, { size: 15 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 186,
											columnNumber: 33
										}, this), " Skor Akhir Anda"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-4xl sm:text-5xl font-black text-slate-900 dark:text-white tracking-tight",
										children: [score, "%"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-500 dark:text-slate-400 font-medium",
										children: "Penilaian otomatis berdasarkan kunci jawaban."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 191,
										columnNumber: 29
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row gap-3 pt-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => navigate(`/f/${formLink}`),
									className: "flex-1 py-3 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 203,
										columnNumber: 29
									}, this), " Isi Lagi"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 199,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => navigate(user ? "/dashboard" : "/login"),
									className: "flex-1 py-3 px-4 rounded-xl bg-[#00897B] hover:bg-[#00796B] text-white text-xs font-bold shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV(Home, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 210,
											columnNumber: 29
										}, this),
										" ",
										user ? "Ke Dashboard" : "Masuk FormUp"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 25
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 border-t border-slate-100 dark:border-slate-800",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setFeedbackOpen(!feedbackOpen),
									className: "inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 transition-colors cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(MessageSquare, { size: 13 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 220,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Kirim Laporan / Masukan untuk Formulir Ini" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 221,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 216,
									columnNumber: 25
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 215,
								columnNumber: 21
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 168,
						columnNumber: 17
					}, this),
					feedbackOpen && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-lg space-y-4 animate-in fade-in zoom-in-95 duration-200",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, {
								size: 18,
								className: "text-amber-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 230,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-slate-900 dark:text-white",
								children: "Formulir Laporan & Masukan"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 231,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 25
						}, this), feedbackSuccess ? /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-xs font-bold text-emerald-600 dark:text-emerald-400",
							children: feedbackTarget === "admin" ? "Laporan Anda telah berhasil dikirimkan ke Admin FormUp untuk ditinjau. Terima kasih!" : "Masukan Anda telah berhasil dikirimkan ke pembuat formulir. Terima kasih!"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 235,
							columnNumber: 29
						}, this) : /* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleSendFeedback,
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5",
										children: "Tujuan Kirim"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 244,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => handleChangeFeedbackTarget("owner"),
											className: `p-2.5 rounded-xl border text-xs font-bold text-center cursor-pointer transition-all ${feedbackTarget === "owner" ? "bg-teal-50 dark:bg-teal-950/60 border-[#00897B] text-[#00897B] dark:text-teal-400" : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"}`,
											children: "Pemilik Formulir"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 246,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => handleChangeFeedbackTarget("admin"),
											className: `p-2.5 rounded-xl border text-xs font-bold text-center cursor-pointer transition-all ${feedbackTarget === "admin" ? "bg-red-50 dark:bg-red-950/60 border-red-400 text-red-600 dark:text-red-400" : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"}`,
											children: "Laporkan ke Admin"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 257,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 245,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] text-slate-400 dark:text-slate-500 mt-1.5",
										children: feedbackTarget === "admin" ? "Untuk pelanggaran serius (konten tidak pantas, spam, penyalahgunaan). Ditinjau langsung oleh tim Admin FormUp." : "Untuk kendala teknis, pertanyaan membingungkan, atau kunci jawaban yang salah. Dikirim langsung ke pembuat formulir."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 269,
										columnNumber: 37
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 243,
									columnNumber: 33
								}, this),
								feedbackError && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-xl text-xs font-bold text-red-600 dark:text-red-400",
									children: feedbackError
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 277,
									columnNumber: 37
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
									children: feedbackTarget === "admin" ? "Kategori Laporan" : "Alasan Masukan"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 283,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: reason,
									onChange: (e) => setReason(e.target.value),
									className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-bold bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]",
									children: currentReasonOptions.map((opt) => /* @__PURE__ */ _jsxDEV("option", {
										value: opt.value,
										children: opt.label
									}, opt.value, false, {
										fileName: _jsxFileName,
										lineNumber: 292,
										columnNumber: 45
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 282,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
									children: "Deskripsi Tambahan (Opsional)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 298,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("textarea", {
									rows: 3,
									value: description,
									onChange: (e) => setDescription(e.target.value),
									placeholder: feedbackTarget === "admin" ? "Jelaskan pelanggaran yang Anda temukan..." : "Jelaskan kendala atau masukan Anda...",
									className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 302,
									columnNumber: 33
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 297,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-end gap-2",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setFeedbackOpen(false),
										className: "px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300",
										children: "Batal"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 316,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										disabled: sendingFeedback,
										className: "px-5 py-2 bg-[#00897B] hover:bg-[#00796B] text-white rounded-xl text-xs font-bold disabled:opacity-60",
										children: sendingFeedback ? "Mengirim..." : "Kirim"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 315,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 228,
						columnNumber: 21
					}, this),
					result?.answers && result.answers.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-base font-extrabold text-slate-900 dark:text-white",
								children: "Rincian Jawaban & Review Soal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 dark:text-slate-500",
								children: "Tinjauan jawaban yang telah Anda kirimkan"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 344,
								columnNumber: 33
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 29
							}, this), showScore && result.correctCount != null && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-extrabold px-3 py-1 bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400 rounded-full border border-teal-200 dark:border-teal-800",
								children: [
									"Benar ",
									result.correctCount,
									" / ",
									result.scorableQuestions || result.totalQuestions
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 347,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 341,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 pt-2",
							children: result.answers.map((a, i) => {
								const isCorrect = showScore && a.isCorrect === true;
								const isWrong = showScore && a.isCorrect === false;
								return /* @__PURE__ */ _jsxDEV("div", {
									className: `p-4 rounded-2xl border transition-all ${isCorrect ? "bg-emerald-50/50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60" : isWrong ? "bg-red-50/50 dark:bg-red-950/30 border-red-200 dark:border-red-800/60" : "bg-slate-50 dark:bg-slate-800/50 border-slate-200/80 dark:border-slate-700"}`,
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start justify-between gap-3 mb-2",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-2 flex-1",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-extrabold text-slate-400 dark:text-slate-500 text-xs shrink-0",
												children: [i + 1, "."]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 362,
												columnNumber: 49
											}, this), /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
												content: a.question,
												format: a.questionFormat,
												className: "text-xs font-bold text-slate-800 dark:text-slate-100"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 363,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 361,
											columnNumber: 45
										}, this), showScore && a.isCorrect != null && /* @__PURE__ */ _jsxDEV("span", {
											className: `text-[10px] font-extrabold px-2.5 py-0.5 rounded-full shrink-0 flex items-center gap-1 ${isCorrect ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300" : "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300"}`,
											children: isCorrect ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { size: 11 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 368,
												columnNumber: 68
											}, this), " Benar"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 368,
												columnNumber: 66
											}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(X, { size: 11 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 368,
												columnNumber: 101
											}, this), " Salah"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 368,
												columnNumber: 99
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 367,
											columnNumber: 49
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 360,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "pl-5 space-y-1 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-baseline gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-400 dark:text-slate-500 font-bold shrink-0",
												children: "Jawaban Anda:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 375,
												columnNumber: 49
											}, this), /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
												content: a.optionText || a.answerText || "—",
												format: "text",
												className: "font-bold text-slate-800 dark:text-slate-200"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 376,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 374,
											columnNumber: 45
										}, this), showScore && isWrong && a.correctAnswer && /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-baseline gap-2 text-emerald-600 dark:text-emerald-400 pt-0.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold shrink-0",
												children: "Jawaban Benar:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 381,
												columnNumber: 53
											}, this), /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
												content: a.correctAnswer,
												format: "text",
												className: "font-bold"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 382,
												columnNumber: 53
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 380,
											columnNumber: 49
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 373,
										columnNumber: 41
									}, this)]
								}, i, true, {
									fileName: _jsxFileName,
									lineNumber: 359,
									columnNumber: 37
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 353,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 340,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 165,
				columnNumber: 13
			}, this),
			remedialModalOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xs",
					onClick: () => !remedialLoading && setRemedialModalOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 399,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl space-y-5 z-10 max-h-[90vh] flex flex-col",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400",
									children: /* @__PURE__ */ _jsxDEV(BookOpen, { size: 20 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 405,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 404,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm sm:text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2",
									children: "Pembahasan Konsep & Latihan Soal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 408,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: "Bimbingan terstruktur untuk memahami konsep dasar dan latihan mandiri."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 411,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 407,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 403,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setRemedialModalOpen(false),
								className: "p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 421,
									columnNumber: 33
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 416,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 402,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 overflow-y-auto space-y-5 pr-1",
							children: [
								remedialLoading && /* @__PURE__ */ _jsxDEV("div", {
									className: "py-16 text-center space-y-3",
									children: [/* @__PURE__ */ _jsxDEV(Loader2, {
										size: 32,
										className: "animate-spin mx-auto text-teal-600 dark:text-teal-400"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 429,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs font-bold text-slate-600 dark:text-slate-300",
										children: "Sedang menganalisis soal dan menyusun latihan pemahaman..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 430,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 428,
									columnNumber: 33
								}, this),
								remedialError && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-xs text-red-600 dark:text-red-400 space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("p", {
											className: "font-bold",
											children: "⚠️ Terjadi Kendala:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 438,
											columnNumber: 37
										}, this),
										/* @__PURE__ */ _jsxDEV("p", { children: remedialError }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 439,
											columnNumber: 37
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => activeRemedialQuestion && handleOpenRemedial(activeRemedialQuestion),
											className: "px-3 py-1.5 bg-red-600 text-white rounded-xl text-xs font-bold cursor-pointer hover:bg-red-700 inline-flex items-center gap-1",
											children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { size: 12 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 445,
												columnNumber: 41
											}, this), " Coba Lagi"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 440,
											columnNumber: 37
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 437,
									columnNumber: 33
								}, this),
								remedialData && /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-5",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 rounded-2xl space-y-1.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] uppercase tracking-wider font-extrabold text-slate-400",
												children: "Soal yang dipelajari:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 454,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold text-slate-800 dark:text-slate-200",
												children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: activeRemedialQuestion?.question || "" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 456,
													columnNumber: 45
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 455,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 453,
											columnNumber: 37
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 bg-teal-50/50 dark:bg-teal-950/30 border border-teal-200/80 dark:border-teal-800/60 rounded-2xl space-y-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 text-xs font-bold text-teal-800 dark:text-teal-300",
												children: [/* @__PURE__ */ _jsxDEV(Lightbulb, {
													size: 16,
													className: "text-teal-600"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 463,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Penjelasan & Pembahasan Konsep" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 464,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 462,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs text-slate-700 dark:text-slate-200 leading-relaxed prose dark:prose-invert max-w-none",
												children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: remedialData.explanation }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 467,
													columnNumber: 45
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 466,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 461,
											columnNumber: 37
										}, this),
										remedialData.keyTakeaways && remedialData.keyTakeaways.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 bg-amber-50/50 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-800/60 rounded-2xl space-y-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300",
												children: [/* @__PURE__ */ _jsxDEV(BookOpen, {
													size: 16,
													className: "text-amber-600"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 475,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Poin Kunci & Rumus yang Perlu Diingat" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 476,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 474,
												columnNumber: 45
											}, this), /* @__PURE__ */ _jsxDEV("ul", {
												className: "list-disc list-inside text-xs text-slate-700 dark:text-slate-200 space-y-1 pl-1",
												children: remedialData.keyTakeaways.map((item, kIdx) => /* @__PURE__ */ _jsxDEV("li", {
													className: "leading-relaxed",
													children: item
												}, kIdx, false, {
													fileName: _jsxFileName,
													lineNumber: 480,
													columnNumber: 53
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 478,
												columnNumber: 45
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 473,
											columnNumber: 41
										}, this),
										remedialData.practiceQuestion && /* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 bg-white dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-3 shadow-xs",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-between",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5",
														children: [/* @__PURE__ */ _jsxDEV(CheckCircle, {
															size: 15,
															className: "text-teal-600"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 491,
															columnNumber: 53
														}, this), " Latihan Uji Pemahaman Mandiri"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 490,
														columnNumber: 49
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold",
														children: "1 Soal Cepat"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 493,
														columnNumber: 49
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 489,
													columnNumber: 45
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs font-semibold text-slate-800 dark:text-slate-100",
													children: remedialData.practiceQuestion.question
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 498,
													columnNumber: 45
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-1.5",
													children: remedialData.practiceQuestion.options?.map((opt, oIdx) => {
														const isSelected = practiceSelectedOption === oIdx;
														let btnStyle = "bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-teal-500";
														if (practiceSubmitted) {
															if (opt.isCorrect) {
																btnStyle = "bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-800 dark:text-emerald-200 font-bold";
															} else if (isSelected && !opt.isCorrect) {
																btnStyle = "bg-red-50 dark:bg-red-950/60 border-red-500 text-red-800 dark:text-red-200 font-bold";
															}
														} else if (isSelected) {
															btnStyle = "bg-teal-50 dark:bg-teal-950/60 border-teal-500 text-teal-900 dark:text-teal-200 font-bold";
														}
														return /* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															disabled: practiceSubmitted,
															onClick: () => setPracticeSelectedOption(oIdx),
															className: `w-full p-2.5 rounded-xl border text-xs text-left transition-all cursor-pointer flex items-center justify-between ${btnStyle}`,
															children: [/* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center gap-2",
																children: [/* @__PURE__ */ _jsxDEV("span", {
																	className: "w-5 h-5 rounded-lg bg-black/5 dark:bg-white/10 flex items-center justify-center font-bold text-[10px] shrink-0",
																	children: String.fromCharCode(65 + oIdx)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 526,
																	columnNumber: 65
																}, this), /* @__PURE__ */ _jsxDEV("span", { children: opt.optionText }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 529,
																	columnNumber: 65
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 525,
																columnNumber: 61
															}, this), practiceSubmitted && opt.isCorrect && /* @__PURE__ */ _jsxDEV(Check, {
																size: 14,
																className: "text-emerald-600 shrink-0"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 532,
																columnNumber: 65
															}, this)]
														}, oIdx, true, {
															fileName: _jsxFileName,
															lineNumber: 518,
															columnNumber: 57
														}, this);
													})
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 502,
													columnNumber: 45
												}, this),
												!practiceSubmitted ? /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													disabled: practiceSelectedOption === null,
													onClick: () => setPracticeSubmitted(true),
													className: "w-full py-2 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold cursor-pointer transition-all shadow-xs",
													children: "Periksa Jawaban"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 540,
													columnNumber: 49
												}, this) : /* @__PURE__ */ _jsxDEV("div", {
													className: "p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl space-y-1.5",
													children: [/* @__PURE__ */ _jsxDEV("p", {
														className: "text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5",
														children: remedialData.practiceQuestion.options[practiceSelectedOption]?.isCorrect ? /* @__PURE__ */ _jsxDEV("span", {
															className: "text-emerald-600",
															children: "🎉 Benar sekali! Pemahaman Anda sudah sangat baik."
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 552,
															columnNumber: 61
														}, this) : /* @__PURE__ */ _jsxDEV("span", {
															className: "text-red-500",
															children: "💡 Belum tepat. Simak pembahasan berikut:"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 554,
															columnNumber: 61
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 550,
														columnNumber: 53
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-slate-500 dark:text-slate-400",
														children: remedialData.practiceQuestion.explanation
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 557,
														columnNumber: 53
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 549,
													columnNumber: 49
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 488,
											columnNumber: 41
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 451,
									columnNumber: 33
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 426,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end",
							children: /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setRemedialModalOpen(false),
								className: "px-5 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 text-white rounded-xl text-xs font-bold cursor-pointer",
								children: "Tutup Pembahasan"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 570,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 569,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 400,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 398,
				columnNumber: 17
			}, this),
			remedialKeyPromptOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xs",
					onClick: () => setRemedialKeyPromptOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 585,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-sm w-full shadow-2xl space-y-4 z-10",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
									size: 16,
									className: "text-emerald-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 589,
									columnNumber: 33
								}, this), " API Key Gemini Belum Diatur"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 588,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setRemedialKeyPromptOpen(false),
								className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 15 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 596,
									columnNumber: 33
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 591,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 587,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400",
							children: "Fitur pembahasan materi memerlukan Google Gemini API Key. Silakan atur API Key Anda di halaman AI Assistant Chat."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 599,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setRemedialKeyPromptOpen(false),
								className: "flex-1 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer",
								children: "Tutup"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 603,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: "/ai-chat",
								className: "flex-1 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold text-center transition-colors inline-flex items-center justify-center gap-1",
								children: ["Atur di AI Chat ", /* @__PURE__ */ _jsxDEV(ExternalLink, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 614,
									columnNumber: 49
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 610,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 602,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 586,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 584,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 164,
		columnNumber: 9
	}, this);
}
_s(FormResultPage, "XnYimGvIctHWrcIMyTX1MSFdoO8=", false, function() {
	return [
		useParams,
		useNavigate,
		useLocation
	];
});
_c = FormResultPage;
var _c;
$RefreshReg$(_c, "FormResultPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/form-runner/FormResultPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-runner/FormResultPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-runner/FormResultPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-runner/FormResultPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLFdBQVcsYUFBYSxhQUFhLFlBQVk7QUFDMUQsU0FDSSxjQUFjLE9BQU8sTUFBTSxXQUFXLGVBQ3RDLE1BQU0sU0FBUyxlQUFlLE9BQU8sR0FDckMsVUFBVSxXQUFXLFlBQVksYUFDakMsWUFBWSxXQUFXLEtBQUssY0FBYyxtQkFDdkM7QUFDUCxTQUNJLHlCQUF5QixxQkFBcUIsZ0JBQzlDLG9CQUNHO0FBQ1AsU0FDSSw2QkFBNkIsd0JBQzFCO0FBQ1AsT0FBTyx5QkFBeUI7Ozs7QUFFaEMsTUFBTSx5QkFBeUI7Q0FDM0I7RUFBRSxPQUFPO0VBQTBCLE9BQU87Q0FBNEM7Q0FDdEY7RUFBRSxPQUFPO0VBQXVCLE9BQU87Q0FBOEI7Q0FDckU7RUFBRSxPQUFPO0VBQWtCLE9BQU87Q0FBZ0M7Q0FDbEU7RUFBRSxPQUFPO0VBQVcsT0FBTztDQUF5QztBQUN4RTtBQUVBLE1BQU0sdUJBQXVCO0NBQ3pCO0VBQUUsT0FBTztFQUE2QixPQUFPO0NBQWtEO0NBQy9GO0VBQUUsT0FBTztFQUE2QixPQUFPO0NBQWdEO0NBQzdGO0VBQUUsT0FBTztFQUFzQixPQUFPO0NBQW9EO0NBQzFGO0VBQUUsT0FBTztFQUFpQixPQUFPO0NBQWlEO0FBQ3RGO0FBRUEsZUFBZSxTQUFTLGlCQUFpQjs7Q0FDckMsTUFBTSxFQUFFLFVBQVUsZUFBZSxVQUFVO0NBQzNDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sV0FBVyxZQUFZO0NBRTdCLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxJQUFJO0NBQ3JDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxJQUFJO0NBQ3pDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJOztDQUczQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsT0FBTztDQUM1RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsd0JBQXdCO0NBQzdELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBQzVELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsS0FBSztDQUM1RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFOztDQUdyRCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FDaEUsTUFBTSxDQUFDLHdCQUF3Qiw2QkFBNkIsU0FBUyxJQUFJO0NBQ3pFLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsS0FBSztDQUM1RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxJQUFJO0NBQ3JELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEVBQUU7Q0FDckQsTUFBTSxDQUFDLHdCQUF3Qiw2QkFBNkIsU0FBUyxJQUFJO0NBQ3pFLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsS0FBSztDQUNoRSxNQUFNLENBQUMsdUJBQXVCLDRCQUE0QixTQUFTLEtBQUs7Q0FFeEUsTUFBTSxPQUFPLGFBQWE7Q0FFMUIsTUFBTSx1QkFBdUIsbUJBQW1CLFVBQVUsdUJBQXVCO0NBRWpGLE1BQU0sOEJBQThCLFdBQVc7RUFDM0Msa0JBQWtCLE1BQU07RUFDeEIsTUFBTSxVQUFVLFdBQVcsVUFBVSx1QkFBdUI7RUFDNUQsVUFBVSxRQUFRLEVBQUUsQ0FBQyxLQUFLO0VBQzFCLGlCQUFpQixFQUFFO0NBQ3ZCO0NBRUEsZ0JBQWdCO0VBQ1osTUFBTSxPQUFPLFlBQVk7R0FDckIsV0FBVyxJQUFJOztHQUdmLE1BQU0sVUFBVSxNQUFNLG9CQUFvQixRQUFRO0dBQ2xELElBQUksUUFBUSxJQUFJLFFBQVEsUUFBUSxJQUFJOztHQUdwQyxNQUFNLGFBQWEsU0FBUyxPQUFPLGNBQWM7O0dBR2pELE1BQU0sWUFBWSxNQUFNLHdCQUF3QixVQUFVLFlBQVksVUFBVTtHQUNoRixJQUFJLFVBQVUsTUFBTSxVQUFVLE1BQU07SUFDaEMsVUFBVSxVQUFVLElBQUk7R0FDNUI7R0FDQSxXQUFXLEtBQUs7RUFDcEI7RUFFQSxLQUFLO0NBQ1QsR0FBRyxDQUFDLFVBQVUsVUFBVSxDQUFDO0NBRXpCLE1BQU0scUJBQXFCLE9BQU8sTUFBTTtFQUNwQyxFQUFFLGVBQWU7RUFDakIsaUJBQWlCLEVBQUU7RUFDbkIsbUJBQW1CLElBQUk7RUFFdkIsTUFBTSxTQUFTLE1BQU0sTUFBTSxRQUFRO0VBQ25DLE1BQU0sTUFBTSxNQUFNLGVBQWUsUUFBUTtHQUNyQztHQUNBLGFBQWEsWUFBWSxLQUFLO0dBQzlCLFlBQVksU0FBUyxZQUFZLEVBQUUsS0FBSztFQUM1QyxDQUFDO0VBQ0QsbUJBQW1CLEtBQUs7RUFFeEIsSUFBSSxJQUFJLElBQUk7R0FDUixtQkFBbUIsSUFBSTtHQUN2QixlQUFlLEVBQUU7RUFDckIsT0FBTztHQUNILGlCQUFpQixJQUFJLFdBQVcsNEJBQTRCO0VBQ2hFO0NBQ0o7Q0FFQSxNQUFNLHFCQUFxQixPQUFPLGVBQWU7RUFDN0MsMEJBQTBCLFVBQVU7RUFDcEMscUJBQXFCLElBQUk7RUFDekIsbUJBQW1CLElBQUk7RUFDdkIsaUJBQWlCLEVBQUU7RUFDbkIsZ0JBQWdCLElBQUk7RUFDcEIsMEJBQTBCLElBQUk7RUFDOUIscUJBQXFCLEtBQUs7RUFFMUIsTUFBTSxPQUFPLGlCQUFpQjtFQUM5QixJQUFJLEtBQUssV0FBVyxHQUFHO0dBQ25CLG1CQUFtQixLQUFLO0dBQ3hCLHlCQUF5QixJQUFJO0dBQzdCO0VBQ0o7RUFFQSxJQUFJO0dBQ0EsTUFBTSxNQUFNLE1BQU0sNEJBQTRCO0lBQzFDLGNBQWMsV0FBVztJQUN6QixjQUFjLFdBQVcsVUFBVTtJQUNuQyxZQUFZLFdBQVcsY0FBYyxXQUFXLGNBQWM7SUFDOUQsZUFBZSxXQUFXLGlCQUFpQjtJQUMzQyxTQUFTLFdBQVcsV0FBVyxDQUFDO0dBQ3BDLENBQUM7R0FFRCxJQUFJLElBQUksTUFBTSxJQUFJLE1BQU07SUFDcEIsZ0JBQWdCLElBQUksSUFBSTtHQUM1QixPQUFPO0lBQ0gsaUJBQWlCLElBQUksV0FBVyxpQ0FBaUM7R0FDckU7RUFDSixTQUFTLEtBQUs7R0FDVixpQkFBaUIsSUFBSSxXQUFXLDJDQUEyQztFQUMvRSxVQUFVO0dBQ04sbUJBQW1CLEtBQUs7RUFDNUI7Q0FDSjtDQUVBLElBQUksU0FBUyxPQUNULHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1gsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNJLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGlFQUFrRTs7OzthQUNyRix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF5RDtHQUEyQjs7OztXQUNoRzs7Ozs7O0NBQ0o7Ozs7O0NBR1QsTUFBTSxZQUFZLE1BQU0sYUFBYSxNQUFNLFVBQVUsYUFBYSxRQUFRO0NBQzFFLE1BQU0sUUFBUSxRQUFRO0NBRXRCLE9BQ0ksd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FHSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNYLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O09BQ3hCOzs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXdFO1FBRWxGOzs7O2tCQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQWlGO1VBQzNCLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFnRCxNQUFNLFNBQVM7VUFBcUI7Ozs7O1VBQUM7U0FDeEo7Ozs7O2dCQUNGOzs7Ozs7T0FHSixhQUFhLFNBQVMsUUFDbkIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7b0JBQUMsa0JBQ2xCOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNLLE9BQU0sR0FDTjs7Ozs7O1NBQ0wsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXlEO1NBRW5FOzs7OztRQUNGOzs7Ozs7T0FJVCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLFVBQUQ7U0FDSSxlQUFlLFNBQVMsTUFBTSxVQUFVO1NBQ3hDLFdBQVU7bUJBRmQsQ0FJSSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O21CQUFDLFdBQ25COzs7OztrQkFFUix3QkFBQyxVQUFEO1NBQ0ksZUFBZSxTQUFTLE9BQU8sZUFBZSxRQUFRO1NBQ3RELFdBQVU7bUJBRmQ7VUFJSSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztVQUFDO1VBQUUsT0FBTyxpQkFBaUI7U0FDeEM7Ozs7O2dCQUNQOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWCx3QkFBQyxVQUFEO1NBQ0ksZUFBZSxnQkFBZ0IsQ0FBQyxZQUFZO1NBQzVDLFdBQVU7bUJBRmQsQ0FJSSx3QkFBQyxlQUFELEVBQWUsTUFBTSxHQUFLOzs7O21CQUMxQix3QkFBQyxRQUFELFlBQU0sNkNBQWdEOzs7O2lCQUNsRDs7Ozs7O09BQ1A7Ozs7O01BQ0o7Ozs7OztLQUdILGdCQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxlQUFEO1FBQWUsTUFBTTtRQUFJLFdBQVU7T0FBa0I7Ozs7aUJBQ3JELHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFtRDtPQUE4Qjs7OztlQUM5Rjs7Ozs7Z0JBRUosa0JBQ0csd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1YsbUJBQW1CLFVBQ2QseUZBQ0E7TUFDTDs7OztpQkFFTCx3QkFBQyxRQUFEO09BQU0sVUFBVTtPQUFvQixXQUFVO2lCQUE5QztRQUVJLHdCQUFDLE9BQUQ7U0FDSSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBb0U7U0FBbUI7Ozs7O1NBQ3hHLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsVUFBRDtXQUNJLE1BQUs7V0FDTCxlQUFlLDJCQUEyQixPQUFPO1dBQ2pELFdBQVcsdUZBQ1AsbUJBQW1CLFVBQ2Isc0ZBQ0E7cUJBRWI7VUFFTzs7OztvQkFDUix3QkFBQyxVQUFEO1dBQ0ksTUFBSztXQUNMLGVBQWUsMkJBQTJCLE9BQU87V0FDakQsV0FBVyx1RkFDUCxtQkFBbUIsVUFDYiwrRUFDQTtxQkFFYjtVQUVPOzs7O2tCQUNQOzs7Ozs7U0FDTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDUixtQkFBbUIsVUFDZCxtSEFDQTtTQUNQOzs7OztRQUNGOzs7OztRQUVKLGlCQUNHLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNWO1FBQ0E7Ozs7O1FBR1Qsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUNaLG1CQUFtQixVQUFVLHFCQUFxQjtRQUNoRDs7OztrQkFDUCx3QkFBQyxVQUFEO1NBQ0ksT0FBTztTQUNQLFdBQVUsTUFBSyxVQUFVLEVBQUUsT0FBTyxLQUFLO1NBQ3ZDLFdBQVU7bUJBRVQscUJBQXFCLEtBQUksUUFDdEIsd0JBQUMsVUFBRDtVQUF3QixPQUFPLElBQUk7b0JBQVEsSUFBSTtTQUFjLEdBQWhELElBQUk7Ozs7Z0JBQTRDLENBQ2hFO1FBQ0c7Ozs7Z0JBQ1A7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNBLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFrRTtRQUU1RTs7OztrQkFFUCx3QkFBQyxZQUFEO1NBQ0ksTUFBTTtTQUNOLE9BQU87U0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztTQUM5QyxhQUNJLG1CQUFtQixVQUNiLDhDQUNBO1NBRVYsV0FBVTtRQUNiOzs7O2dCQUNBOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixLQUFLO1VBQ3BDLFdBQVU7b0JBQ2I7U0FFTzs7OzttQkFFUix3QkFBQyxVQUFEO1VBQ0ksTUFBSztVQUNMLFVBQVU7VUFDVixXQUFVO29CQUVULGtCQUFrQixnQkFBZ0I7U0FDL0I7Ozs7aUJBQ1A7Ozs7OztPQUVDOzs7OztjQUVEOzs7Ozs7S0FJaEIsUUFBUSxXQUFXLE9BQU8sUUFBUSxTQUFTLEtBQ3hDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQTBEO09BQWlDOzs7O2lCQUN6Ryx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBNkM7T0FBNEM7Ozs7ZUFDckc7Ozs7aUJBQ0osYUFBYSxPQUFPLGdCQUFnQixRQUNqQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FBNks7U0FDbEssT0FBTztTQUFhO1NBQUksT0FBTyxxQkFBcUIsT0FBTztRQUNoRTs7Ozs7ZUFFVDs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1YsT0FBTyxRQUFRLEtBQUssR0FBRyxNQUFNO1FBQzFCLE1BQU0sWUFBWSxhQUFhLEVBQUUsY0FBYztRQUMvQyxNQUFNLFVBQVUsYUFBYSxFQUFFLGNBQWM7UUFFN0MsT0FDSSx3QkFBQyxPQUFEO1NBQWEsV0FBVyx5Q0FBeUMsWUFBWSwwRkFBMEYsVUFBVSwwRUFBMEU7bUJBQTNQLENBQ0ksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUFzRixJQUFJLEdBQUUsR0FBTzs7Ozs7cUJBQ25HLHdCQUFDLHFCQUFEO1lBQXFCLFNBQVMsRUFBRTtZQUFVLFFBQVEsRUFBRTtZQUFnQixXQUFVO1dBQXdEOzs7O21CQUNySTs7Ozs7b0JBRUosYUFBYSxFQUFFLGFBQWEsUUFDekIsd0JBQUMsUUFBRDtXQUFNLFdBQVcsMEZBQTBGLFlBQVksOEVBQThFO3FCQUNoTSxZQUFZLGdEQUFFLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7cUJBQUMsUUFBUTs7OztzQkFBSSxnREFBRSx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7O3FCQUFDLFFBQVE7Ozs7O1VBQ3JFOzs7O2tCQUVUOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXdEO1dBQW1COzs7O3FCQUMzRix3QkFBQyxxQkFBRDtZQUFxQixTQUFTLEVBQUUsY0FBYyxFQUFFLGNBQWM7WUFBSyxRQUFPO1lBQU8sV0FBVTtXQUFnRDs7OzttQkFDMUk7Ozs7O29CQUVKLGFBQWEsV0FBVyxFQUFFLGlCQUN2Qix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFxQjtXQUFvQjs7OztxQkFDekQsd0JBQUMscUJBQUQ7WUFBcUIsU0FBUyxFQUFFO1lBQWUsUUFBTztZQUFPLFdBQVU7V0FBYTs7OzttQkFDbkY7Ozs7O2tCQUdSOzs7OztpQkFDSjtXQTVCSzs7OztlQTRCTDtPQUViLENBQUM7TUFDQTs7OztjQUNKOzs7Ozs7SUFHUjs7Ozs7O0dBR0oscUJBQ0csd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWtFLGVBQWUsQ0FBQyxtQkFBbUIscUJBQXFCLEtBQUs7SUFBSTs7OztjQUNsSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNYLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O1FBQ3BCOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBNkY7UUFFdkc7Ozs7a0JBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlCO1FBRW5DOzs7O2dCQUNGOzs7O2dCQUNKOzs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLGVBQWUscUJBQXFCLEtBQUs7UUFDekMsV0FBVTtrQkFFVix3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztPQUNWOzs7O2VBQ1A7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0ssbUJBQ0csd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxTQUFEO1VBQVMsTUFBTTtVQUFJLFdBQVU7U0FBeUQ7Ozs7bUJBQ3RGLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF1RDtTQUVqRTs7OztpQkFDRjs7Ozs7O1FBR1IsaUJBQ0csd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDSSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBWTtVQUFzQjs7Ozs7VUFDL0Msd0JBQUMsS0FBRCxZQUFJLGNBQWlCOzs7OztVQUNyQix3QkFBQyxVQUFEO1dBQ0ksTUFBSztXQUNMLGVBQWUsMEJBQTBCLG1CQUFtQixzQkFBc0I7V0FDbEYsV0FBVTtxQkFIZCxDQUtJLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7cUJBQUMsWUFDbkI7Ozs7OztTQUNQOzs7Ozs7UUFHUixnQkFDRyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUVJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXFFO1dBQTJCOzs7O3FCQUNoSCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDWCx3QkFBQyxxQkFBRCxFQUFxQixTQUFTLHdCQUF3QixZQUFZLEdBQUs7Ozs7O1dBQ3RFOzs7O21CQUNKOzs7Ozs7VUFHTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0ksd0JBQUMsV0FBRDthQUFXLE1BQU07YUFBSSxXQUFVO1lBQWlCOzs7O3NCQUNoRCx3QkFBQyxRQUFELFlBQU0saUNBQW9DOzs7O29CQUN6Qzs7Ozs7cUJBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ1gsd0JBQUMscUJBQUQsRUFBcUIsU0FBUyxhQUFhLFlBQWM7Ozs7O1dBQ3hEOzs7O21CQUNKOzs7Ozs7VUFHSixhQUFhLGdCQUFnQixhQUFhLGFBQWEsU0FBUyxLQUM3RCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0ksd0JBQUMsVUFBRDthQUFVLE1BQU07YUFBSSxXQUFVO1lBQWtCOzs7O3NCQUNoRCx3QkFBQyxRQUFELFlBQU0sd0NBQTJDOzs7O29CQUNoRDs7Ozs7cUJBQ0wsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1QsYUFBYSxhQUFhLEtBQUssTUFBTSxTQUNsQyx3QkFBQyxNQUFEO2FBQWUsV0FBVTt1QkFBbUI7WUFBUyxHQUE1Qzs7OzttQkFBNEMsQ0FDeEQ7V0FDRDs7OzttQkFDSDs7Ozs7O1VBSVIsYUFBYSxvQkFDVix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNJLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWhCLENBQ0ksd0JBQUMsYUFBRDtlQUFhLE1BQU07ZUFBSSxXQUFVO2NBQWlCOzs7O3dCQUFDLGdDQUNqRDs7Ozs7dUJBQ04sd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQW1IO2FBRTdIOzs7O3FCQUNMOzs7Ozs7WUFFTCx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFDUixhQUFhLGlCQUFpQjtZQUNoQzs7Ozs7WUFFSCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFDVixhQUFhLGlCQUFpQixTQUFTLEtBQUssS0FBSyxTQUFTO2NBQ3ZELE1BQU0sYUFBYSwyQkFBMkI7Y0FDOUMsSUFBSSxXQUFXO2NBRWYsSUFBSSxtQkFBbUI7ZUFDbkIsSUFBSSxJQUFJLFdBQVc7Z0JBQ2YsV0FBVztlQUNmLE9BQU8sSUFBSSxjQUFjLENBQUMsSUFBSSxXQUFXO2dCQUNyQyxXQUFXO2VBQ2Y7Y0FDSixPQUFPLElBQUksWUFBWTtlQUNuQixXQUFXO2NBQ2Y7Y0FFQSxPQUNJLHdCQUFDLFVBQUQ7ZUFFSSxNQUFLO2VBQ0wsVUFBVTtlQUNWLGVBQWUsMEJBQTBCLElBQUk7ZUFDN0MsV0FBVyxvSEFBb0g7eUJBTG5JLENBT0ksd0JBQUMsT0FBRDtnQkFBSyxXQUFVOzBCQUFmLENBQ0ksd0JBQUMsUUFBRDtpQkFBTSxXQUFVOzJCQUNYLE9BQU8sYUFBYSxLQUFLLElBQUk7Z0JBQzVCOzs7OzBCQUNOLHdCQUFDLFFBQUQsWUFBTyxJQUFJLFdBQWlCOzs7O3dCQUMzQjs7Ozs7eUJBQ0oscUJBQXFCLElBQUksYUFDdEIsd0JBQUMsT0FBRDtnQkFBTyxNQUFNO2dCQUFJLFdBQVU7ZUFBNkI7Ozs7dUJBRXhEO2lCQWZDOzs7O3FCQWVEO2FBRWhCLENBQUM7WUFDQTs7Ozs7WUFFSixDQUFDLG9CQUNFLHdCQUFDLFVBQUQ7YUFDSSxNQUFLO2FBQ0wsVUFBVSwyQkFBMkI7YUFDckMsZUFBZSxxQkFBcUIsSUFBSTthQUN4QyxXQUFVO3VCQUNiO1lBRU87Ozs7dUJBRVIsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDSSx3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFDUixhQUFhLGlCQUFpQixRQUFRLHVCQUF1QixFQUFFLFlBQzVELHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUFtQjtjQUF3RDs7Ozt5QkFFM0Ysd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQWU7Y0FBK0M7Ozs7O2FBRW5GOzs7O3VCQUNILHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUNSLGFBQWEsaUJBQWlCO2FBQ2hDOzs7O3FCQUNGOzs7Ozs7V0FFUjs7Ozs7O1NBRVI7Ozs7OztPQUVSOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCx3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLGVBQWUscUJBQXFCLEtBQUs7UUFDekMsV0FBVTtrQkFDYjtPQUVPOzs7OztNQUNQOzs7OztLQUNKOzs7OztZQUNKOzs7Ozs7R0FJUix5QkFDRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBa0UsZUFBZSx5QkFBeUIsS0FBSztJQUFJOzs7O2NBQ2xJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNJLHdCQUFDLGFBQUQ7U0FBYSxNQUFNO1NBQUksV0FBVTtRQUFvQjs7OztrQkFBQyw4QkFDcEQ7Ozs7O2lCQUNOLHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsZUFBZSx5QkFBeUIsS0FBSztRQUM3QyxXQUFVO2tCQUVWLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O09BQ1Y7Ozs7ZUFDUDs7Ozs7O01BQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZDO01BRXZEOzs7OztNQUNILHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsVUFBRDtRQUNJLE1BQUs7UUFDTCxlQUFlLHlCQUF5QixLQUFLO1FBQzdDLFdBQVU7a0JBQ2I7T0FFTzs7OztpQkFDUix3QkFBQyxNQUFEO1FBQ0ksSUFBRztRQUNILFdBQVU7a0JBRmQsQ0FHQyxvQkFDbUIsd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztnQkFDdkM7Ozs7O2VBQ0w7Ozs7OztLQUNKOzs7OztZQUNKOzs7Ozs7RUFFUjs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRm9ybVJlc3VsdFBhZ2UuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlLCB1c2VMb2NhdGlvbiwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHtcbiAgICBDaGVja0NpcmNsZTIsIEF3YXJkLCBIb21lLCBSb3RhdGVDY3csIEFsZXJ0VHJpYW5nbGUsXG4gICAgU2VuZCwgTG9hZGVyMiwgTWVzc2FnZVNxdWFyZSwgQ2hlY2ssIFgsXG4gICAgQm9va09wZW4sIExpZ2h0YnVsYiwgSGVscENpcmNsZSwgQ2hlY2tDaXJjbGUsXG4gICAgQXJyb3dSaWdodCwgUmVmcmVzaEN3LCBLZXksIEV4dGVybmFsTGluaywgU2hpZWxkQ2hlY2tcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7XG4gICAgZ2V0UHVibGljUmVzcG9uc2VSZXN1bHQsIGdldFB1YmxpY0Zvcm1CeUxpbmssIHN1Ym1pdEZlZWRiYWNrLFxuICAgIGdldExvY2FsVXNlclxufSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7XG4gICAgZ2VuZXJhdGVSZW1lZGlhbEV4cGxhbmF0aW9uLCBnZXRHZW1pbmlBcGlLZXlzXG59IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FpU2VydmljZSc7XG5pbXBvcnQgUmljaENvbnRlbnRSZW5kZXJlciBmcm9tICcuLi8uLi91dGlscy9SaWNoQ29udGVudFJlbmRlcmVyJztcblxuY29uc3QgT1dORVJfRkVFREJBQ0tfUkVBU09OUyA9IFtcbiAgICB7IHZhbHVlOiAnUEVSVEFOWUFBTl9USURBS19KRUxBUycsIGxhYmVsOiAnUGVydGFueWFhbiB0aWRhayBqZWxhcyBhdGF1IG1lbWJpbmd1bmdrYW4nIH0sXG4gICAgeyB2YWx1ZTogJ0tVTkNJX0pBV0FCQU5fU0FMQUgnLCBsYWJlbDogJ0t1bmNpIGphd2FiYW4gZGluaWxhaSBzYWxhaCcgfSxcbiAgICB7IHZhbHVlOiAnS0VOREFMQV9URUtOSVMnLCBsYWJlbDogJ0tlbmRhbGEgdGVrbmlzIHNhYXQgcGVuZ2lzaWFuJyB9LFxuICAgIHsgdmFsdWU6ICdMQUlOTllBJywgbGFiZWw6ICdNYXN1a2FuIGxhaW5ueWEgdW50dWsgcGVtaWxpayBmb3JtdWxpcicgfSxcbl07XG5cbmNvbnN0IEFETUlOX1JFUE9SVF9SRUFTT05TID0gW1xuICAgIHsgdmFsdWU6ICdBRE1JTl9LT05URU5fVElEQUtfUEFOVEFTJywgbGFiZWw6ICdLb250ZW4gZm9ybXVsaXIgdGlkYWsgcGFudGFzIC8gbWVsYW5nZ2FyIGF0dXJhbicgfSxcbiAgICB7IHZhbHVlOiAnQURNSU5fU1BBTV9QRU5ZQUxBSEdVTkFBTicsIGxhYmVsOiAnRm9ybXVsaXIgdGVyaW5kaWthc2kgc3BhbSBhdGF1IGRpc2FsYWhndW5ha2FuJyB9LFxuICAgIHsgdmFsdWU6ICdBRE1JTl9EQVRBX1BSSUJBREknLCBsYWJlbDogJ0Zvcm11bGlyIG1lbWludGEgZGF0YSBwcmliYWRpIHNlY2FyYSBtZW5jdXJpZ2FrYW4nIH0sXG4gICAgeyB2YWx1ZTogJ0FETUlOX0xBSU5OWUEnLCBsYWJlbDogJ1BlbGFuZ2dhcmFuIGxhaW5ueWEgKGxhcG9ya2FuIGtlIEFkbWluIEZvcm1VcCknIH0sXG5dO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBGb3JtUmVzdWx0UGFnZSgpIHtcbiAgICBjb25zdCB7IGZvcm1MaW5rLCByZXNwb25zZUlkIH0gPSB1c2VQYXJhbXMoKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuXG4gICAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW3Jlc3VsdCwgc2V0UmVzdWx0XSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuXG4gICAgLy8gRmVlZGJhY2sgU3RhdGVcbiAgICBjb25zdCBbZmVlZGJhY2tPcGVuLCBzZXRGZWVkYmFja09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtmZWVkYmFja1RhcmdldCwgc2V0RmVlZGJhY2tUYXJnZXRdID0gdXNlU3RhdGUoJ293bmVyJyk7IFxuICAgIGNvbnN0IFtyZWFzb24sIHNldFJlYXNvbl0gPSB1c2VTdGF0ZSgnUEVSVEFOWUFBTl9USURBS19KRUxBUycpO1xuICAgIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtzZW5kaW5nRmVlZGJhY2ssIHNldFNlbmRpbmdGZWVkYmFja10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2ZlZWRiYWNrU3VjY2Vzcywgc2V0RmVlZGJhY2tTdWNjZXNzXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZmVlZGJhY2tFcnJvciwgc2V0RmVlZGJhY2tFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgICAvLyBSZW1lZGlhbCAvIFByYWN0aWNlIEFzc2lzdGFudCBTdGF0ZVxuICAgIGNvbnN0IFtyZW1lZGlhbE1vZGFsT3Blbiwgc2V0UmVtZWRpYWxNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFthY3RpdmVSZW1lZGlhbFF1ZXN0aW9uLCBzZXRBY3RpdmVSZW1lZGlhbFF1ZXN0aW9uXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtyZW1lZGlhbExvYWRpbmcsIHNldFJlbWVkaWFsTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3JlbWVkaWFsRGF0YSwgc2V0UmVtZWRpYWxEYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtyZW1lZGlhbEVycm9yLCBzZXRSZW1lZGlhbEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbcHJhY3RpY2VTZWxlY3RlZE9wdGlvbiwgc2V0UHJhY3RpY2VTZWxlY3RlZE9wdGlvbl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbcHJhY3RpY2VTdWJtaXR0ZWQsIHNldFByYWN0aWNlU3VibWl0dGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbcmVtZWRpYWxLZXlQcm9tcHRPcGVuLCBzZXRSZW1lZGlhbEtleVByb21wdE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgdXNlciA9IGdldExvY2FsVXNlcigpO1xuXG4gICAgY29uc3QgY3VycmVudFJlYXNvbk9wdGlvbnMgPSBmZWVkYmFja1RhcmdldCA9PT0gJ2FkbWluJyA/IEFETUlOX1JFUE9SVF9SRUFTT05TIDogT1dORVJfRkVFREJBQ0tfUkVBU09OUztcblxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZUZlZWRiYWNrVGFyZ2V0ID0gKHRhcmdldCkgPT4ge1xuICAgICAgICBzZXRGZWVkYmFja1RhcmdldCh0YXJnZXQpO1xuICAgICAgICBjb25zdCBvcHRpb25zID0gdGFyZ2V0ID09PSAnYWRtaW4nID8gQURNSU5fUkVQT1JUX1JFQVNPTlMgOiBPV05FUl9GRUVEQkFDS19SRUFTT05TO1xuICAgICAgICBzZXRSZWFzb24ob3B0aW9uc1swXS52YWx1ZSk7XG4gICAgICAgIHNldEZlZWRiYWNrRXJyb3IoJycpO1xuICAgIH07XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBsb2FkID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcblxuICAgICAgICAgICAgLy8gRmV0Y2ggZm9ybSBpbmZvIGFsd2F5cyAobmVlZGVkIGZvciB0aXRsZSwgc2hvd1Njb3JlLCBmZWVkYmFjaywgZXRjLilcbiAgICAgICAgICAgIGNvbnN0IGZvcm1SZXMgPSBhd2FpdCBnZXRQdWJsaWNGb3JtQnlMaW5rKGZvcm1MaW5rKTtcbiAgICAgICAgICAgIGlmIChmb3JtUmVzLm9rKSBzZXRGb3JtKGZvcm1SZXMuZGF0YSk7XG5cbiAgICAgICAgICAgIC8vIGd1ZXN0VG9rZW4gcGFzc2VkIGZyb20gc3VibWl0IHZpYSByb3V0ZXIgc3RhdGVcbiAgICAgICAgICAgIGNvbnN0IGd1ZXN0VG9rZW4gPSBsb2NhdGlvbi5zdGF0ZT8uZ3Vlc3RUb2tlbiB8fCBudWxsO1xuXG4gICAgICAgICAgICAvLyBGZXRjaCByZXN1bHQg4oCUIGd1ZXN0VG9rZW4gYWxsb3dzIGd1ZXN0IHVzZXJzIHRvIHNlZSB0aGVpciByZXN1bHRcbiAgICAgICAgICAgIGNvbnN0IGRldGFpbFJlcyA9IGF3YWl0IGdldFB1YmxpY1Jlc3BvbnNlUmVzdWx0KGZvcm1MaW5rLCByZXNwb25zZUlkLCBndWVzdFRva2VuKTtcbiAgICAgICAgICAgIGlmIChkZXRhaWxSZXMub2sgJiYgZGV0YWlsUmVzLmRhdGEpIHtcbiAgICAgICAgICAgICAgICBzZXRSZXN1bHQoZGV0YWlsUmVzLmRhdGEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgbG9hZCgpO1xuICAgIH0sIFtmb3JtTGluaywgcmVzcG9uc2VJZF0pO1xuXG4gICAgY29uc3QgaGFuZGxlU2VuZEZlZWRiYWNrID0gYXN5bmMgKGUpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzZXRGZWVkYmFja0Vycm9yKCcnKTtcbiAgICAgICAgc2V0U2VuZGluZ0ZlZWRiYWNrKHRydWUpO1xuXG4gICAgICAgIGNvbnN0IGZvcm1JZCA9IGZvcm0/LmlkIHx8IHJlc3VsdD8uZm9ybUlkO1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBzdWJtaXRGZWVkYmFjayhmb3JtSWQsIHtcbiAgICAgICAgICAgIHJlYXNvbixcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbi50cmltKCksXG4gICAgICAgICAgICByZXNwb25zZUlkOiBwYXJzZUludChyZXNwb25zZUlkLCAxMCkgfHwgbnVsbCxcbiAgICAgICAgfSk7XG4gICAgICAgIHNldFNlbmRpbmdGZWVkYmFjayhmYWxzZSk7XG5cbiAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgc2V0RmVlZGJhY2tTdWNjZXNzKHRydWUpO1xuICAgICAgICAgICAgc2V0RGVzY3JpcHRpb24oJycpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0RmVlZGJhY2tFcnJvcihyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVuZ2lyaW1rYW4gbWFzdWthbi4nKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVPcGVuUmVtZWRpYWwgPSBhc3luYyAoYW5zd2VySXRlbSkgPT4ge1xuICAgICAgICBzZXRBY3RpdmVSZW1lZGlhbFF1ZXN0aW9uKGFuc3dlckl0ZW0pO1xuICAgICAgICBzZXRSZW1lZGlhbE1vZGFsT3Blbih0cnVlKTtcbiAgICAgICAgc2V0UmVtZWRpYWxMb2FkaW5nKHRydWUpO1xuICAgICAgICBzZXRSZW1lZGlhbEVycm9yKCcnKTtcbiAgICAgICAgc2V0UmVtZWRpYWxEYXRhKG51bGwpO1xuICAgICAgICBzZXRQcmFjdGljZVNlbGVjdGVkT3B0aW9uKG51bGwpO1xuICAgICAgICBzZXRQcmFjdGljZVN1Ym1pdHRlZChmYWxzZSk7XG5cbiAgICAgICAgY29uc3Qga2V5cyA9IGdldEdlbWluaUFwaUtleXMoKTtcbiAgICAgICAgaWYgKGtleXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICBzZXRSZW1lZGlhbExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgc2V0UmVtZWRpYWxLZXlQcm9tcHRPcGVuKHRydWUpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdlbmVyYXRlUmVtZWRpYWxFeHBsYW5hdGlvbih7XG4gICAgICAgICAgICAgICAgcXVlc3Rpb25UZXh0OiBhbnN3ZXJJdGVtLnF1ZXN0aW9uLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uVHlwZTogYW5zd2VySXRlbS50eXBlSWQgfHwgMixcbiAgICAgICAgICAgICAgICB1c2VyQW5zd2VyOiBhbnN3ZXJJdGVtLm9wdGlvblRleHQgfHwgYW5zd2VySXRlbS5hbnN3ZXJUZXh0IHx8ICcnLFxuICAgICAgICAgICAgICAgIGNvcnJlY3RBbnN3ZXI6IGFuc3dlckl0ZW0uY29ycmVjdEFuc3dlciB8fCAnJyxcbiAgICAgICAgICAgICAgICBvcHRpb25zOiBhbnN3ZXJJdGVtLm9wdGlvbnMgfHwgW10sXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgaWYgKHJlcy5vayAmJiByZXMuZGF0YSkge1xuICAgICAgICAgICAgICAgIHNldFJlbWVkaWFsRGF0YShyZXMuZGF0YSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHNldFJlbWVkaWFsRXJyb3IocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbXVhdCBwZW1iYWhhc2FuIG1hdGVyaS4nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBzZXRSZW1lZGlhbEVycm9yKGVyci5tZXNzYWdlIHx8ICdUZXJqYWRpIGtlc2FsYWhhbiBzYWF0IG1lbXVhdCBwZW1iYWhhc2FuLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0UmVtZWRpYWxMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1zY3JlZW4gYmctWyNGNEY4RjddIGRhcms6Ymctc2xhdGUtOTUwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctOCBoLTggYW5pbWF0ZS1zcGluIG14LWF1dG8gdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIHRleHQtc20gZm9udC1tZWRpdW1cIj5NZW11YXQgaGFzaWwgZm9ybXVsaXIuLi48L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcblxuICAgIGNvbnN0IHNob3dTY29yZSA9IGZvcm0/LnNob3dTY29yZSB8fCBmb3JtPy5zZXR0aW5ncz8uc2hvd1Njb3JlIHx8IHJlc3VsdD8uc2hvd1Njb3JlO1xuICAgIGNvbnN0IHNjb3JlID0gcmVzdWx0Py5zY29yZTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLVsjRjRGOEY3XSBkYXJrOmJnLXNsYXRlLTk1MCBmb250LXNhbnMgYW50aWFsaWFzZWQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBweS0xMiBweC00IGZsZXgganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctMnhsIHctZnVsbCBzcGFjZS15LTZcIj5cblxuICAgICAgICAgICAgICAgIHsvKiBNYWluIFN1Y2Nlc3MgQ2FyZCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTggc206cC0xMCB0ZXh0LWNlbnRlciBzaGFkb3cteGwgc3BhY2UteS02XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgcm91bmRlZC0zeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MzZ9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVzcG9ucyBBbmRhIFRlbGFoIFRlcmtpcmltIVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVyaW1hIGthc2loIHRlbGFoIG1lbHVhbmdrYW4gd2FrdHUgdW50dWsgbWVuZ2lzaSA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPntmb3JtPy50aXRsZSB8fCAnZm9ybXVsaXIgaW5pJ308L3NwYW4+LlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogU2NvcmUgRGlzcGxheSBpZiBlbmFibGVkICovfVxuICAgICAgICAgICAgICAgICAgICB7c2hvd1Njb3JlICYmIHNjb3JlICE9IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1saW5lYXItdG8tYnIgZnJvbS10ZWFsLTUwLzYwIHRvLWVtZXJhbGQtNTAvNjAgZGFyazpmcm9tLXRlYWwtOTUwLzQwIGRhcms6dG8tc2xhdGUtODAwIGJvcmRlciBib3JkZXItdGVhbC0xMDAgZGFyazpib3JkZXItdGVhbC05MDAvNTAgcm91bmRlZC0yeGwgcC02IHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtWzExcHhdIGZvbnQtZXh0cmFib2xkIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEF3YXJkIHNpemU9ezE1fSAvPiBTa29yIEFraGlyIEFuZGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtNHhsIHNtOnRleHQtNXhsIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzY29yZX0lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlbmlsYWlhbiBvdG9tYXRpcyBiZXJkYXNhcmthbiBrdW5jaSBqYXdhYmFuLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC0zIHB0LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2YvJHtmb3JtTGlua31gKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMyBweC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IHNpemU9ezE0fSAvPiBJc2kgTGFnaVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSh1c2VyID8gJy9kYXNoYm9hcmQnIDogJy9sb2dpbicpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0zIHB4LTQgcm91bmRlZC14bCBiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SG9tZSBzaXplPXsxNH0gLz4ge3VzZXIgPyAnS2UgRGFzaGJvYXJkJyA6ICdNYXN1ayBGb3JtVXAnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBGZWVkYmFjayBUcmlnZ2VyICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGZWVkYmFja09wZW4oIWZlZWRiYWNrT3Blbil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTMwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+S2lyaW0gTGFwb3JhbiAvIE1hc3VrYW4gdW50dWsgRm9ybXVsaXIgSW5pPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEZlZWRiYWNrIE1vZGFsIC8gQm94ICovfVxuICAgICAgICAgICAgICAgICB7ZmVlZGJhY2tPcGVuICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IHNtOnAtOCBzaGFkb3ctbGcgc3BhY2UteS00IGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPkZvcm11bGlyIExhcG9yYW4gJiBNYXN1a2FuPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmVlZGJhY2tTdWNjZXNzID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC81MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwIHJvdW5kZWQtMnhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmZWVkYmFja1RhcmdldCA9PT0gJ2FkbWluJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnTGFwb3JhbiBBbmRhIHRlbGFoIGJlcmhhc2lsIGRpa2lyaW1rYW4ga2UgQWRtaW4gRm9ybVVwIHVudHVrIGRpdGluamF1LiBUZXJpbWEga2FzaWghJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnTWFzdWthbiBBbmRhIHRlbGFoIGJlcmhhc2lsIGRpa2lyaW1rYW4ga2UgcGVtYnVhdCBmb3JtdWxpci4gVGVyaW1hIGthc2loISd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTZW5kRmVlZGJhY2t9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVGFyZ2V0IFBlbWlsaWhhbjogUGVtaWxpayBGb3JtdWxpciB2cyBBZG1pbiBGb3JtVXAgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xLjVcIj5UdWp1YW4gS2lyaW08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2hhbmdlRmVlZGJhY2tUYXJnZXQoJ293bmVyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIHRleHQteHMgZm9udC1ib2xkIHRleHQtY2VudGVyIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmZWVkYmFja1RhcmdldCA9PT0gJ293bmVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCBib3JkZXItWyMwMDg5N0JdIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlbWlsaWsgRm9ybXVsaXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDaGFuZ2VGZWVkYmFja1RhcmdldCgnYWRtaW4nKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrVGFyZ2V0ID09PSAnYWRtaW4nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC82MCBib3JkZXItcmVkLTQwMCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMYXBvcmthbiBrZSBBZG1pblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIG10LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmZWVkYmFja1RhcmdldCA9PT0gJ2FkbWluJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdVbnR1ayBwZWxhbmdnYXJhbiBzZXJpdXMgKGtvbnRlbiB0aWRhayBwYW50YXMsIHNwYW0sIHBlbnlhbGFoZ3VuYWFuKS4gRGl0aW5qYXUgbGFuZ3N1bmcgb2xlaCB0aW0gQWRtaW4gRm9ybVVwLidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnVW50dWsga2VuZGFsYSB0ZWtuaXMsIHBlcnRhbnlhYW4gbWVtYmluZ3VuZ2thbiwgYXRhdSBrdW5jaSBqYXdhYmFuIHlhbmcgc2FsYWguIERpa2lyaW0gbGFuZ3N1bmcga2UgcGVtYnVhdCBmb3JtdWxpci4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmVlZGJhY2tFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTUwLzUwIGJvcmRlciBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZlZWRiYWNrRXJyb3J9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmZWVkYmFja1RhcmdldCA9PT0gJ2FkbWluJyA/ICdLYXRlZ29yaSBMYXBvcmFuJyA6ICdBbGFzYW4gTWFzdWthbid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZWFzb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0UmVhc29uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LWJvbGQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50UmVhc29uT3B0aW9ucy5tYXAob3B0ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e29wdC52YWx1ZX0gdmFsdWU9e29wdC52YWx1ZX0+e29wdC5sYWJlbH08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZXNrcmlwc2kgVGFtYmFoYW4gKE9wc2lvbmFsKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGVzY3JpcHRpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrVGFyZ2V0ID09PSAnYWRtaW4nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ0plbGFza2FuIHBlbGFuZ2dhcmFuIHlhbmcgQW5kYSB0ZW11a2FuLi4uJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdKZWxhc2thbiBrZW5kYWxhIGF0YXUgbWFzdWthbiBBbmRhLi4uJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHAtMyB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZlZWRiYWNrT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhdGFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NlbmRpbmdGZWVkYmFja31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiBiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbmRpbmdGZWVkYmFjayA/ICdNZW5naXJpbS4uLicgOiAnS2lyaW0nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7LyogRGV0YWlsZWQgQW5zd2VyIFJldmlldyBTZWN0aW9uICovfVxuICAgICAgICAgICAgICAgIHtyZXN1bHQ/LmFuc3dlcnMgJiYgcmVzdWx0LmFuc3dlcnMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHAtNiBzbTpwLTggc2hhZG93LXhsIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+UmluY2lhbiBKYXdhYmFuICYgUmV2aWV3IFNvYWw8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5UaW5qYXVhbiBqYXdhYmFuIHlhbmcgdGVsYWggQW5kYSBraXJpbWthbjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd1Njb3JlICYmIHJlc3VsdC5jb3JyZWN0Q291bnQgIT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgcHgtMyBweS0xIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJlbmFyIHtyZXN1bHQuY29ycmVjdENvdW50fSAvIHtyZXN1bHQuc2NvcmFibGVRdWVzdGlvbnMgfHwgcmVzdWx0LnRvdGFsUXVlc3Rpb25zfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3VsdC5hbnN3ZXJzLm1hcCgoYSwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0NvcnJlY3QgPSBzaG93U2NvcmUgJiYgYS5pc0NvcnJlY3QgPT09IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzV3JvbmcgPSBzaG93U2NvcmUgJiYgYS5pc0NvcnJlY3QgPT09IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPXtgcC00IHJvdW5kZWQtMnhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke2lzQ29ycmVjdCA/ICdiZy1lbWVyYWxkLTUwLzUwIGRhcms6YmctZW1lcmFsZC05NTAvMzAgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwLzYwJyA6IGlzV3JvbmcgPyAnYmctcmVkLTUwLzUwIGRhcms6YmctcmVkLTk1MC8zMCBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwLzYwJyA6ICdiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMyBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC14cyBzaHJpbmstMFwiPntpICsgMX0uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17YS5xdWVzdGlvbn0gZm9ybWF0PXthLnF1ZXN0aW9uRm9ybWF0fSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dTY29yZSAmJiBhLmlzQ29ycmVjdCAhPSBudWxsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtWzEwcHhdIGZvbnQtZXh0cmFib2xkIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHNocmluay0wIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xICR7aXNDb3JyZWN0ID8gJ2JnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC03MDAgZGFyazpiZy1lbWVyYWxkLTkwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAnIDogJ2JnLXJlZC0xMDAgdGV4dC1yZWQtNzAwIGRhcms6YmctcmVkLTkwMCBkYXJrOnRleHQtcmVkLTMwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzQ29ycmVjdCA/IDw+PENoZWNrIHNpemU9ezExfSAvPiBCZW5hcjwvPiA6IDw+PFggc2l6ZT17MTF9IC8+IFNhbGFoPC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC01IHNwYWNlLXktMSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGQgc2hyaW5rLTBcIj5KYXdhYmFuIEFuZGE6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17YS5vcHRpb25UZXh0IHx8IGEuYW5zd2VyVGV4dCB8fCAn4oCUJ30gZm9ybWF0PVwidGV4dFwiIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dTY29yZSAmJiBpc1dyb25nICYmIGEuY29ycmVjdEFuc3dlciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTIgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgcHQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHNocmluay0wXCI+SmF3YWJhbiBCZW5hcjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17YS5jb3JyZWN0QW5zd2VyfSBmb3JtYXQ9XCJ0ZXh0XCIgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFJlbWVkaWFsIC8gUHJhY3RpY2UgQXNzaXN0YW50IE1vZGFsICovfVxuICAgICAgICAgICAge3JlbWVkaWFsTW9kYWxPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLXNsYXRlLTkwMC82MCBkYXJrOmJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXIteHNcIiBvbkNsaWNrPXsoKSA9PiAhcmVtZWRpYWxMb2FkaW5nICYmIHNldFJlbWVkaWFsTW9kYWxPcGVuKGZhbHNlKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IHNtOnAtOCBtYXgtdy0yeGwgdy1mdWxsIHNoYWRvdy0yeGwgc3BhY2UteS01IHotMTAgbWF4LWgtWzkwdmhdIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm9va09wZW4gc2l6ZT17MjB9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gc206dGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlbWJhaGFzYW4gS29uc2VwICYgTGF0aWhhbiBTb2FsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJpbWJpbmdhbiB0ZXJzdHJ1a3R1ciB1bnR1ayBtZW1haGFtaSBrb25zZXAgZGFzYXIgZGFuIGxhdGloYW4gbWFuZGlyaS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVtZWRpYWxNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIENvbnRlbnQgQXJlYSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTUgcHItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW1lZGlhbExvYWRpbmcgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTE2IHRleHQtY2VudGVyIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgc2l6ZT17MzJ9IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiBteC1hdXRvIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZWRhbmcgbWVuZ2FuYWxpc2lzIHNvYWwgZGFuIG1lbnl1c3VuIGxhdGloYW4gcGVtYWhhbWFuLi4uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVtZWRpYWxFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNDAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIGRhcms6Ym9yZGVyLXJlZC04MDAgdGV4dC14cyB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGRcIj7imqDvuI8gVGVyamFkaSBLZW5kYWxhOjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPntyZW1lZGlhbEVycm9yfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhY3RpdmVSZW1lZGlhbFF1ZXN0aW9uICYmIGhhbmRsZU9wZW5SZW1lZGlhbChhY3RpdmVSZW1lZGlhbFF1ZXN0aW9uKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy1yZWQtNjAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1yZWQtNzAwIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlZnJlc2hDdyBzaXplPXsxMn0gLz4gQ29iYSBMYWdpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW1lZGlhbERhdGEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFF1ZXN0aW9uIFJlZmVyZW5jZSBCb3ggKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTQwMFwiPlNvYWwgeWFuZyBkaXBlbGFqYXJpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17YWN0aXZlUmVtZWRpYWxRdWVzdGlvbj8ucXVlc3Rpb24gfHwgJyd9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDEuIENvbmNlcHQgQnJlYWtkb3duICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctdGVhbC01MC81MCBkYXJrOmJnLXRlYWwtOTUwLzMwIGJvcmRlciBib3JkZXItdGVhbC0yMDAvODAgZGFyazpib3JkZXItdGVhbC04MDAvNjAgcm91bmRlZC0yeGwgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXRlYWwtODAwIGRhcms6dGV4dC10ZWFsLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlnaHRidWxiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UGVuamVsYXNhbiAmIFBlbWJhaGFzYW4gS29uc2VwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGxlYWRpbmctcmVsYXhlZCBwcm9zZSBkYXJrOnByb3NlLWludmVydCBtYXgtdy1ub25lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e3JlbWVkaWFsRGF0YS5leHBsYW5hdGlvbn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogMi4gS2V5IFRha2Vhd2F5cyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW1lZGlhbERhdGEua2V5VGFrZWF3YXlzICYmIHJlbWVkaWFsRGF0YS5rZXlUYWtlYXdheXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctYW1iZXItNTAvNTAgZGFyazpiZy1hbWJlci05NTAvMzAgYm9yZGVyIGJvcmRlci1hbWJlci0yMDAvODAgZGFyazpib3JkZXItYW1iZXItODAwLzYwIHJvdW5kZWQtMnhsIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtYW1iZXItODAwIGRhcms6dGV4dC1hbWJlci0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb29rT3BlbiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1hbWJlci02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UG9pbiBLdW5jaSAmIFJ1bXVzIHlhbmcgUGVybHUgRGlpbmdhdDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LWRpc2MgbGlzdC1pbnNpZGUgdGV4dC14cyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHNwYWNlLXktMSBwbC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVtZWRpYWxEYXRhLmtleVRha2Vhd2F5cy5tYXAoKGl0ZW0sIGtJZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtrSWR4fSBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWRcIj57aXRlbX08L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogMy4gSW50ZXJhY3RpdmUgUHJhY3RpY2UgUXVlc3Rpb24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVtZWRpYWxEYXRhLnByYWN0aWNlUXVlc3Rpb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwLzcwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBzcGFjZS15LTMgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUgc2l6ZT17MTV9IGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDBcIiAvPiBMYXRpaGFuIFVqaSBQZW1haGFtYW4gTWFuZGlyaVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDEgU29hbCBDZXBhdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbWVkaWFsRGF0YS5wcmFjdGljZVF1ZXN0aW9uLnF1ZXN0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbWVkaWFsRGF0YS5wcmFjdGljZVF1ZXN0aW9uLm9wdGlvbnM/Lm1hcCgob3B0LCBvSWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHByYWN0aWNlU2VsZWN0ZWRPcHRpb24gPT09IG9JZHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJ0blN0eWxlID0gJ2JnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ym9yZGVyLXRlYWwtNTAwJztcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmFjdGljZVN1Ym1pdHRlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAob3B0LmlzQ29ycmVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnRuU3R5bGUgPSAnYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGJvcmRlci1lbWVyYWxkLTUwMCB0ZXh0LWVtZXJhbGQtODAwIGRhcms6dGV4dC1lbWVyYWxkLTIwMCBmb250LWJvbGQnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGlzU2VsZWN0ZWQgJiYgIW9wdC5pc0NvcnJlY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ0blN0eWxlID0gJ2JnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNjAgYm9yZGVyLXJlZC01MDAgdGV4dC1yZWQtODAwIGRhcms6dGV4dC1yZWQtMjAwIGZvbnQtYm9sZCc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGlzU2VsZWN0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnRuU3R5bGUgPSAnYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIGJvcmRlci10ZWFsLTUwMCB0ZXh0LXRlYWwtOTAwIGRhcms6dGV4dC10ZWFsLTIwMCBmb250LWJvbGQnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17b0lkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3ByYWN0aWNlU3VibWl0dGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UHJhY3RpY2VTZWxlY3RlZE9wdGlvbihvSWR4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciB0ZXh0LXhzIHRleHQtbGVmdCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gJHtidG5TdHlsZX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtNSByb3VuZGVkLWxnIGJnLWJsYWNrLzUgZGFyazpiZy13aGl0ZS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGQgdGV4dC1bMTBweF0gc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1N0cmluZy5mcm9tQ2hhckNvZGUoNjUgKyBvSWR4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e29wdC5vcHRpb25UZXh0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ByYWN0aWNlU3VibWl0dGVkICYmIG9wdC5pc0NvcnJlY3QgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshcHJhY3RpY2VTdWJtaXR0ZWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3ByYWN0aWNlU2VsZWN0ZWRPcHRpb24gPT09IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UHJhY3RpY2VTdWJtaXR0ZWQodHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgZGlzYWJsZWQ6b3BhY2l0eS01MCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZXJpa3NhIEphd2FiYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbWVkaWFsRGF0YS5wcmFjdGljZVF1ZXN0aW9uLm9wdGlvbnNbcHJhY3RpY2VTZWxlY3RlZE9wdGlvbl0/LmlzQ29ycmVjdCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDBcIj7wn46JIEJlbmFyIHNla2FsaSEgUGVtYWhhbWFuIEFuZGEgc3VkYWggc2FuZ2F0IGJhaWsuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+8J+SoSBCZWx1bSB0ZXBhdC4gU2ltYWsgcGVtYmFoYXNhbiBiZXJpa3V0Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVtZWRpYWxEYXRhLnByYWN0aWNlUXVlc3Rpb24uZXhwbGFuYXRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGb290ZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlbWVkaWFsTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCBkYXJrOmJnLXNsYXRlLTcwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHV0dXAgUGVtYmFoYXNhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIEFQSSBLZXkgTW9kYWwgaWYgbm90IHNldCAqL31cbiAgICAgICAgICAgIHtyZW1lZGlhbEtleVByb21wdE9wZW4gJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctc2xhdGUtOTAwLzYwIGRhcms6YmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci14c1wiIG9uQ2xpY2s9eygpID0+IHNldFJlbWVkaWFsS2V5UHJvbXB0T3BlbihmYWxzZSl9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHAtNiBtYXgtdy1zbSB3LWZ1bGwgc2hhZG93LTJ4bCBzcGFjZS15LTQgei0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNTAwXCIgLz4gQVBJIEtleSBHZW1pbmkgQmVsdW0gRGlhdHVyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlbWVkaWFsS2V5UHJvbXB0T3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZpdHVyIHBlbWJhaGFzYW4gbWF0ZXJpIG1lbWVybHVrYW4gR29vZ2xlIEdlbWluaSBBUEkgS2V5LiBTaWxha2FuIGF0dXIgQVBJIEtleSBBbmRhIGRpIGhhbGFtYW4gQUkgQXNzaXN0YW50IENoYXQuXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB0LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZW1lZGlhbEtleVByb21wdE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMiBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFR1dHVwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvYWktY2hhdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQXR1ciBkaSBBSSBDaGF0IDxFeHRlcm5hbExpbmsgc2l6ZT17MTJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==