import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/OnboardingTour.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { X, ChevronRight, ChevronLeft, Check, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/OnboardingTour.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
/**
* OnboardingTour - Komponen Guided Onboarding Tour dengan Spotlight Pattern
* Pola Duolingo & Anthropic yang disempurnakan:
* - Overlay gelap fokus (rgba(0, 0, 0, 0.72))
* - Cutout spotlight target yang presisi dengan dynamic bounding rect
* - Border glowing elegan: teal-400 dengan glow halus
* - Card penjelasan menempel di dekat target dengan pointer penunjuk
* - Safe clamping agar card tidak pernah terpotong di atas viewport (search bar / browser bar)
* - Navigasi Kembali & Lanjut/Selesai, keyboard shortcuts, dan auto-scroll
*/
export default function OnboardingTour({ steps = [], isOpen = false, onClose = () => {}, onComplete = () => {} }) {
	_s();
	const [currentStep, setCurrentStep] = useState(0);
	const [targetRect, setTargetRect] = useState(null);
	const [cardPlacement, setCardPlacement] = useState("bottom");
	const [showWelcome, setShowWelcome] = useState(true);
	const step = steps[currentStep] || null;
	// Hitung posisi elemen target
	const updateTargetPosition = useCallback(() => {
		if (!isOpen || showWelcome || !step) {
			setTargetRect(null);
			return;
		}
		const selector = step.selector;
		const targetElement = typeof selector === "string" ? document.querySelector(selector) : selector?.current;
		if (!targetElement) {
			// Jangan tampilkan card di area kosong. Lewati langkah yang targetnya
			// sudah tidak ada (misalnya tombol yang berubah karena state UI).
			setTargetRect(null);
			const nextAvailable = steps.findIndex((candidate, index) => index > currentStep && document.querySelector(candidate.selector));
			if (nextAvailable >= 0) setCurrentStep(nextAvailable);
			else if (currentStep < steps.length - 1) setCurrentStep(currentStep + 1);
			else {
				onComplete();
				onClose();
			}
			return;
		}
		// Auto-scroll ke target jika di luar viewport atau terlalu mepet ke atas
		const rect = targetElement.getBoundingClientRect();
		const minTopMargin = 80;
		const isInViewport = rect.top >= minTopMargin && rect.left >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) - 40 && rect.right <= (window.innerWidth || document.documentElement.clientWidth);
		if (!isInViewport) {
			targetElement.scrollIntoView({
				behavior: "smooth",
				block: "center",
				inline: "nearest"
			});
		}
		// Ambil koordinat terbaru setelah scroll/posisi
		const updatedRect = targetElement.getBoundingClientRect();
		setTargetRect({
			top: updatedRect.top,
			left: updatedRect.left,
			width: updatedRect.width,
			height: updatedRect.height,
			bottom: updatedRect.bottom,
			right: updatedRect.right
		});
		// BUG FIX: Tentukan penempatan card penjelasan
		// Jika target berada di bagian atas layar (seperti sidebar menu atau topbar), pastikan card tidak pernah terpotong di atas viewport
		const spaceBelow = window.innerHeight - updatedRect.bottom;
		const spaceAbove = updatedRect.top;
		const neededCardHeight = 260;
		if (step.placement) {
			setCardPlacement(step.placement);
		} else if (window.innerWidth >= 1024 && updatedRect.left < 320 && updatedRect.right <= 360) {
			// Jika elemen berada di sidebar kiri (desktop), posisikan card di sebelah kanan elemen
			setCardPlacement("right");
		} else if (spaceAbove > neededCardHeight + 100 && spaceBelow < 220) {
			// Hanya gunakan 'top' jika space di atas benar-benar lega dan tidak mepet browser bar
			setCardPlacement("top");
		} else {
			setCardPlacement("bottom");
		}
	}, [
		isOpen,
		showWelcome,
		step,
		steps,
		currentStep
	]);
	useEffect(() => {
		if (!isOpen) {
			setCurrentStep(0);
			setShowWelcome(true);
			return;
		}
		// Beri sedikit jeda agar DOM render sempurna
		const timer = setTimeout(() => {
			updateTargetPosition();
		}, 100);
		const handleResizeOrScroll = () => {
			updateTargetPosition();
		};
		window.addEventListener("resize", handleResizeOrScroll);
		window.addEventListener("scroll", handleResizeOrScroll, true);
		return () => {
			clearTimeout(timer);
			window.removeEventListener("resize", handleResizeOrScroll);
			window.removeEventListener("scroll", handleResizeOrScroll, true);
		};
	}, [
		isOpen,
		currentStep,
		updateTargetPosition
	]);
	// Keyboard navigation (ArrowRight/Enter untuk lanjut, Escape untuk lewati)
	useEffect(() => {
		if (!isOpen) return;
		const handleKeyDown = (e) => {
			if (e.key === "Escape") {
				e.preventDefault();
				handleSkip();
			} else if (e.key === "ArrowRight" || e.key === "Enter") {
				e.preventDefault();
				handleNext();
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [
		isOpen,
		currentStep,
		steps.length
	]);
	if (!isOpen) return null;
	if (showWelcome) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 z-[99990] flex items-center justify-center bg-slate-950/45 p-4",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 text-slate-800 shadow-xl dark:border-slate-700 dark:bg-slate-900 dark:text-white",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-[10px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400",
							children: "Halo, selamat datang!"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-lg font-extrabold",
							children: "Siap membuat formulir pertamamu?"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs leading-relaxed text-slate-500 dark:text-slate-400",
							children: "Kami akan menemani kamu mengenal fitur-fitur penting FormUp, dari membuat soal sampai membagikan formulir. Cuma sebentar kok."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => {
							onComplete();
							onClose();
						},
						className: "rounded-xl px-3 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800",
						children: "Nanti dulu"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setShowWelcome(false),
						className: "rounded-xl bg-teal-600 px-4 py-2 text-xs font-bold text-white hover:bg-teal-700",
						children: "Yuk, mulai"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 143,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 142,
			columnNumber: 13
		}, this);
	}
	if (!step) return null;
	const isLastStep = currentStep === steps.length - 1;
	const isFirstStep = currentStep === 0;
	const handleNext = () => {
		if (isLastStep) {
			onComplete();
			onClose();
		} else {
			const nextIdx = currentStep + 1;
			const nextStep = steps[nextIdx];
			if (step?.onLeaveStep) {
				step.onLeaveStep();
			}
			if (nextStep?.action) {
				nextStep.action();
			}
			setCurrentStep(nextIdx);
		}
	};
	const handlePrev = () => {
		if (currentStep > 0) {
			setCurrentStep((prev) => prev - 1);
		}
	};
	const handleSkip = () => {
		onComplete();
		onClose();
	};
	// Hitung posisi card tooltip secara responsif
	const getCardStyle = () => {
		if (!targetRect) {
			// Jika target tidak ditemukan, tempatkan card di tengah layar
			return {
				position: "fixed",
				top: "50%",
				left: "50%",
				transform: "translate(-50%, -50%)",
				maxWidth: "92vw",
				width: "440px",
				zIndex: 99999
			};
		}
		const padding = 16;
		const cardWidth = Math.min(440, window.innerWidth - 32);
		// Horizontal alignment: tengahkan card terhadap target namun tetap di dalam viewport
		let cardLeft = targetRect.left + targetRect.width / 2 - cardWidth / 2;
		if (cardLeft < 16) cardLeft = 16;
		if (cardLeft + cardWidth > window.innerWidth - 16) {
			cardLeft = window.innerWidth - cardWidth - 16;
		}
		if (cardPlacement === "right") {
			const rightPos = Math.min(window.innerWidth - cardWidth - 16, targetRect.right + padding);
			let topPos = Math.max(80, targetRect.top);
			if (topPos + 300 > window.innerHeight) {
				topPos = Math.max(80, window.innerHeight - 320);
			}
			return {
				position: "fixed",
				top: `${topPos}px`,
				left: `${rightPos}px`,
				width: `${cardWidth}px`,
				zIndex: 99999
			};
		}
		if (cardPlacement === "top") {
			const bottomPos = Math.max(16, window.innerHeight - targetRect.top + padding);
			return {
				position: "fixed",
				bottom: `${bottomPos}px`,
				left: `${cardLeft}px`,
				width: `${cardWidth}px`,
				zIndex: 99999
			};
		}
		const topPos = Math.max(80, targetRect.bottom + padding);
		return {
			position: "fixed",
			top: `${topPos}px`,
			left: `${cardLeft}px`,
			width: `${cardWidth}px`,
			zIndex: 99999
		};
	};
	// Posisi ekor pointer segitiga
	const getPointerLeft = () => {
		if (!targetRect || cardPlacement === "right") return "50%";
		const cardWidth = Math.min(440, window.innerWidth - 32);
		let cardLeft = targetRect.left + targetRect.width / 2 - cardWidth / 2;
		if (cardLeft < 16) cardLeft = 16;
		if (cardLeft + cardWidth > window.innerWidth - 16) {
			cardLeft = window.innerWidth - cardWidth - 16;
		}
		const targetCenter = targetRect.left + targetRect.width / 2;
		const relativePointer = targetCenter - cardLeft;
		// Clamp agar tidak keluar dari sudut rounded card
		return `${Math.max(24, Math.min(cardWidth - 24, relativePointer))}px`;
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-[99990] select-none",
		children: [targetRect ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "fixed transition-all duration-300 ease-out pointer-events-none rounded-2xl ring-4 ring-teal-400/90 shadow-[0_0_35px_rgba(20,184,166,0.65)]",
			style: {
				top: `${Math.max(8, targetRect.top - 6)}px`,
				left: `${Math.max(8, targetRect.left - 6)}px`,
				width: `${targetRect.width + 12}px`,
				height: `${targetRect.height + 12}px`,
				boxShadow: "0 0 0 9999px rgba(3, 7, 18, 0.72)",
				zIndex: 99991
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 273,
			columnNumber: 21
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 z-[99992] cursor-default",
			onClick: (e) => e.stopPropagation()
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 285,
			columnNumber: 21
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 271,
			columnNumber: 17
		}, this) : /* @__PURE__ */ _jsxDEV("div", { className: "fixed inset-0 bg-slate-950/75 backdrop-blur-xs z-[99991]" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 291,
			columnNumber: 17
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			style: getCardStyle(),
			className: "animate-in fade-in zoom-in-95 duration-200",
			children: [
				targetRect && cardPlacement !== "right" && /* @__PURE__ */ _jsxDEV("div", {
					className: "absolute w-4 h-4 bg-slate-900 border-teal-500/60 transform rotate-45",
					style: {
						left: getPointerLeft(),
						marginLeft: "-8px",
						...cardPlacement === "top" ? {
							bottom: "-8px",
							borderRightWidth: "1px",
							borderBottomWidth: "1px"
						} : {
							top: "-8px",
							borderLeftWidth: "1px",
							borderTopWidth: "1px"
						},
						zIndex: 1e5
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 301,
					columnNumber: 21
				}, this),
				targetRect && cardPlacement === "right" && /* @__PURE__ */ _jsxDEV("div", {
					className: "absolute w-4 h-4 bg-slate-900 border-teal-500/60 transform rotate-45",
					style: {
						left: "-8px",
						top: "28px",
						borderLeftWidth: "1px",
						borderBottomWidth: "1px",
						zIndex: 1e5
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 text-slate-800 dark:text-white p-4 sm:p-5 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 overflow-hidden",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between gap-2 mb-2.5",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/50 text-black dark:text-white font-extrabold text-[11px] border border-teal-200 dark:border-teal-800 flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ _jsxDEV(Sparkles, {
											size: 12,
											className: "text-teal-600 dark:text-teal-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 334,
											columnNumber: 33
										}, this),
										currentStep + 1,
										"/",
										steps.length
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 333,
									columnNumber: 29
								}, this), step.badge && /* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 font-bold text-[10px] border border-slate-200 dark:border-slate-700",
									children: step.badge
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 338,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: handleSkip,
								className: "text-xs font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white px-2.5 py-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Lewati" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 348,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV(X, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 331,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1.5 mb-3",
							children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2 tracking-tight",
								children: [step.icon && /* @__PURE__ */ _jsxDEV("div", {
									className: "w-7 h-7 rounded-lg bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-800 flex items-center justify-center text-teal-600 dark:text-teal-300 shrink-0",
									children: step.icon
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 357,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: step.title }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 361,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 355,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-normal",
								children: step.description
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 363,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 354,
							columnNumber: 21
						}, this),
						step.actionButton && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-4 pt-1",
							children: /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									if (step.actionButton.onClick) {
										step.actionButton.onClick();
									}
								},
								className: "w-full py-2.5 px-4 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer",
								children: [
									step.actionButton.icon,
									/* @__PURE__ */ _jsxDEV("span", { children: step.actionButton.text }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 381,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV(ChevronRight, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 382,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 371,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 370,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pt-2.5 border-t border-slate-200 dark:border-slate-800 gap-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5",
								children: steps.map((_, idx) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setCurrentStep(idx),
									className: `h-1.5 rounded-full transition-all cursor-pointer ${idx === currentStep ? "w-6 bg-teal-500" : idx < currentStep ? "w-2 bg-teal-600" : "w-2 bg-slate-300 dark:bg-slate-700"}`,
									title: `Ke langkah ${idx + 1}`
								}, idx, false, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 33
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 390,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [!isFirstStep && /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: handlePrev,
									className: "inline-flex items-center gap-1 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs rounded-xl transition-all cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(ChevronLeft, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 416,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Kembali" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 417,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 411,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: handleNext,
									className: "inline-flex items-center gap-1.5 px-4 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold text-xs rounded-xl shadow-sm transition-colors cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: isLastStep ? "Selesai" : step.nextBtnText || "Lanjut" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 426,
										columnNumber: 37
									}, this), isLastStep ? /* @__PURE__ */ _jsxDEV(Check, { size: 15 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 427,
										columnNumber: 47
									}, this) : /* @__PURE__ */ _jsxDEV(ChevronRight, { size: 15 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 427,
										columnNumber: 69
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 421,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 409,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 388,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 329,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 295,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 268,
		columnNumber: 9
	}, this);
}
_s(OnboardingTour, "MKAkLAECsJ8BMXlOLdfWcFYK2pU=");
_c = OnboardingTour;
var _c;
$RefreshReg$(_c, "OnboardingTour");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/OnboardingTour.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/OnboardingTour.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/OnboardingTour.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/OnboardingTour.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsUUFBUSxtQkFBbUI7QUFDekQsU0FBUyxHQUFHLGNBQWMsYUFBYSxPQUFPLGdCQUFnQjs7Ozs7Ozs7Ozs7Ozs7QUFZOUQsZUFBZSxTQUFTLGVBQWUsRUFDbkMsUUFBUSxDQUFDLEdBQ1QsU0FBUyxPQUNULGdCQUFnQixDQUFDLEdBQ2pCLG1CQUFtQixDQUFDLEtBQ3JCOztDQUNDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLENBQUM7Q0FDaEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsSUFBSTtDQUNqRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxRQUFRO0NBQzNELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLElBQUk7Q0FFbkQsTUFBTSxPQUFPLE1BQU0sZ0JBQWdCOztDQUduQyxNQUFNLHVCQUF1QixrQkFBa0I7RUFDM0MsSUFBSSxDQUFDLFVBQVUsZUFBZSxDQUFDLE1BQU07R0FDakMsY0FBYyxJQUFJO0dBQ2xCO0VBQ0o7RUFFQSxNQUFNLFdBQVcsS0FBSztFQUN0QixNQUFNLGdCQUFnQixPQUFPLGFBQWEsV0FDcEMsU0FBUyxjQUFjLFFBQVEsSUFDL0IsVUFBVTtFQUVoQixJQUFJLENBQUMsZUFBZTs7O0dBR2hCLGNBQWMsSUFBSTtHQUNsQixNQUFNLGdCQUFnQixNQUFNLFdBQVcsV0FBVyxVQUFVLFFBQVEsZUFBZSxTQUFTLGNBQWMsVUFBVSxRQUFRLENBQUM7R0FDN0gsSUFBSSxpQkFBaUIsR0FBRyxlQUFlLGFBQWE7UUFDL0MsSUFBSSxjQUFjLE1BQU0sU0FBUyxHQUFHLGVBQWUsY0FBYyxDQUFDO1FBQ2xFO0lBQUUsV0FBVztJQUFHLFFBQVE7R0FBRztHQUNoQztFQUNKOztFQUdBLE1BQU0sT0FBTyxjQUFjLHNCQUFzQjtFQUNqRCxNQUFNLGVBQWU7RUFDckIsTUFBTSxlQUNGLEtBQUssT0FBTyxnQkFDWixLQUFLLFFBQVEsS0FDYixLQUFLLFdBQVcsT0FBTyxlQUFlLFNBQVMsZ0JBQWdCLGdCQUFnQixNQUMvRSxLQUFLLFVBQVUsT0FBTyxjQUFjLFNBQVMsZ0JBQWdCO0VBR2pFLElBQUksQ0FBQyxjQUFjO0dBQ2YsY0FBYyxlQUFlO0lBQUUsVUFBVTtJQUFVLE9BQU87SUFBVSxRQUFRO0dBQVUsQ0FBQztFQUMzRjs7RUFHQSxNQUFNLGNBQWMsY0FBYyxzQkFBc0I7RUFDeEQsY0FBYztHQUNWLEtBQUssWUFBWTtHQUNqQixNQUFNLFlBQVk7R0FDbEIsT0FBTyxZQUFZO0dBQ25CLFFBQVEsWUFBWTtHQUNwQixRQUFRLFlBQVk7R0FDcEIsT0FBTyxZQUFZO0VBQ3ZCLENBQUM7OztFQUlELE1BQU0sYUFBYSxPQUFPLGNBQWMsWUFBWTtFQUNwRCxNQUFNLGFBQWEsWUFBWTtFQUMvQixNQUFNLG1CQUFtQjtFQUV6QixJQUFJLEtBQUssV0FBVztHQUNoQixpQkFBaUIsS0FBSyxTQUFTO0VBQ25DLE9BQU8sSUFBSSxPQUFPLGNBQWMsUUFBUSxZQUFZLE9BQU8sT0FBTyxZQUFZLFNBQVMsS0FBSzs7R0FFeEYsaUJBQWlCLE9BQU87RUFDNUIsT0FBTyxJQUFJLGFBQWEsbUJBQW1CLE9BQU8sYUFBYSxLQUFLOztHQUVoRSxpQkFBaUIsS0FBSztFQUMxQixPQUFPO0dBQ0gsaUJBQWlCLFFBQVE7RUFDN0I7Q0FDSixHQUFHO0VBQUM7RUFBUTtFQUFhO0VBQU07RUFBTztDQUFXLENBQUM7Q0FFbEQsZ0JBQWdCO0VBQ1osSUFBSSxDQUFDLFFBQVE7R0FDVCxlQUFlLENBQUM7R0FDaEIsZUFBZSxJQUFJO0dBQ25CO0VBQ0o7O0VBR0EsTUFBTSxRQUFRLGlCQUFpQjtHQUMzQixxQkFBcUI7RUFDekIsR0FBRyxHQUFHO0VBRU4sTUFBTSw2QkFBNkI7R0FDL0IscUJBQXFCO0VBQ3pCO0VBRUEsT0FBTyxpQkFBaUIsVUFBVSxvQkFBb0I7RUFDdEQsT0FBTyxpQkFBaUIsVUFBVSxzQkFBc0IsSUFBSTtFQUU1RCxhQUFhO0dBQ1QsYUFBYSxLQUFLO0dBQ2xCLE9BQU8sb0JBQW9CLFVBQVUsb0JBQW9CO0dBQ3pELE9BQU8sb0JBQW9CLFVBQVUsc0JBQXNCLElBQUk7RUFDbkU7Q0FDSixHQUFHO0VBQUM7RUFBUTtFQUFhO0NBQW9CLENBQUM7O0NBRzlDLGdCQUFnQjtFQUNaLElBQUksQ0FBQyxRQUFRO0VBRWIsTUFBTSxpQkFBaUIsTUFBTTtHQUN6QixJQUFJLEVBQUUsUUFBUSxVQUFVO0lBQ3BCLEVBQUUsZUFBZTtJQUNqQixXQUFXO0dBQ2YsT0FBTyxJQUFJLEVBQUUsUUFBUSxnQkFBZ0IsRUFBRSxRQUFRLFNBQVM7SUFDcEQsRUFBRSxlQUFlO0lBQ2pCLFdBQVc7R0FDZjtFQUNKO0VBRUEsT0FBTyxpQkFBaUIsV0FBVyxhQUFhO0VBQ2hELGFBQWEsT0FBTyxvQkFBb0IsV0FBVyxhQUFhO0NBQ3BFLEdBQUc7RUFBQztFQUFRO0VBQWEsTUFBTTtDQUFNLENBQUM7Q0FFdEMsSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixJQUFJLGFBQWE7RUFDYixPQUNJLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1gsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDSSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBa0Y7TUFBd0I7Ozs7O01BQ3ZILHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUF5QjtNQUFvQzs7Ozs7TUFDM0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZEO01BQWdJOzs7OztLQUN6TTs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsVUFBRDtNQUFRLE1BQUs7TUFBUyxlQUFlO09BQUUsV0FBVztPQUFHLFFBQVE7TUFBRztNQUFHLFdBQVU7Z0JBQXVIO0tBQWtCOzs7O2VBQ3ROLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsZUFBZSxlQUFlLEtBQUs7TUFBRyxXQUFVO2dCQUFrRjtLQUFrQjs7OzthQUN6Szs7Ozs7WUFDSjs7Ozs7O0VBQ0o7Ozs7O0NBRWI7Q0FFQSxJQUFJLENBQUMsTUFBTSxPQUFPO0NBRWxCLE1BQU0sYUFBYSxnQkFBZ0IsTUFBTSxTQUFTO0NBQ2xELE1BQU0sY0FBYyxnQkFBZ0I7Q0FFcEMsTUFBTSxtQkFBbUI7RUFDckIsSUFBSSxZQUFZO0dBQ1osV0FBVztHQUNYLFFBQVE7RUFDWixPQUFPO0dBQ0gsTUFBTSxVQUFVLGNBQWM7R0FDOUIsTUFBTSxXQUFXLE1BQU07R0FDdkIsSUFBSSxNQUFNLGFBQWE7SUFDbkIsS0FBSyxZQUFZO0dBQ3JCO0dBQ0EsSUFBSSxVQUFVLFFBQVE7SUFDbEIsU0FBUyxPQUFPO0dBQ3BCO0dBQ0EsZUFBZSxPQUFPO0VBQzFCO0NBQ0o7Q0FFQSxNQUFNLG1CQUFtQjtFQUNyQixJQUFJLGNBQWMsR0FBRztHQUNqQixnQkFBZSxTQUFRLE9BQU8sQ0FBQztFQUNuQztDQUNKO0NBRUEsTUFBTSxtQkFBbUI7RUFDckIsV0FBVztFQUNYLFFBQVE7Q0FDWjs7Q0FHQSxNQUFNLHFCQUFxQjtFQUN2QixJQUFJLENBQUMsWUFBWTs7R0FFYixPQUFPO0lBQ0gsVUFBVTtJQUNWLEtBQUs7SUFDTCxNQUFNO0lBQ04sV0FBVztJQUNYLFVBQVU7SUFDVixPQUFPO0lBQ1AsUUFBUTtHQUNaO0VBQ0o7RUFFQSxNQUFNLFVBQVU7RUFDaEIsTUFBTSxZQUFZLEtBQUssSUFBSSxLQUFLLE9BQU8sYUFBYSxFQUFFOztFQUd0RCxJQUFJLFdBQVcsV0FBVyxPQUFRLFdBQVcsUUFBUSxJQUFNLFlBQVk7RUFDdkUsSUFBSSxXQUFXLElBQUksV0FBVztFQUM5QixJQUFJLFdBQVcsWUFBWSxPQUFPLGFBQWEsSUFBSTtHQUMvQyxXQUFXLE9BQU8sYUFBYSxZQUFZO0VBQy9DO0VBRUEsSUFBSSxrQkFBa0IsU0FBUztHQUMzQixNQUFNLFdBQVcsS0FBSyxJQUFJLE9BQU8sYUFBYSxZQUFZLElBQUksV0FBVyxRQUFRLE9BQU87R0FDeEYsSUFBSSxTQUFTLEtBQUssSUFBSSxJQUFJLFdBQVcsR0FBRztHQUN4QyxJQUFJLFNBQVMsTUFBTSxPQUFPLGFBQWE7SUFDbkMsU0FBUyxLQUFLLElBQUksSUFBSSxPQUFPLGNBQWMsR0FBRztHQUNsRDtHQUNBLE9BQU87SUFDSCxVQUFVO0lBQ1YsS0FBSyxHQUFHLE9BQU87SUFDZixNQUFNLEdBQUcsU0FBUztJQUNsQixPQUFPLEdBQUcsVUFBVTtJQUNwQixRQUFRO0dBQ1o7RUFDSjtFQUVBLElBQUksa0JBQWtCLE9BQU87R0FDekIsTUFBTSxZQUFZLEtBQUssSUFBSSxJQUFJLE9BQU8sY0FBYyxXQUFXLE1BQU0sT0FBTztHQUM1RSxPQUFPO0lBQ0gsVUFBVTtJQUNWLFFBQVEsR0FBRyxVQUFVO0lBQ3JCLE1BQU0sR0FBRyxTQUFTO0lBQ2xCLE9BQU8sR0FBRyxVQUFVO0lBQ3BCLFFBQVE7R0FDWjtFQUNKO0VBRUEsTUFBTSxTQUFTLEtBQUssSUFBSSxJQUFJLFdBQVcsU0FBUyxPQUFPO0VBQ3ZELE9BQU87R0FDSCxVQUFVO0dBQ1YsS0FBSyxHQUFHLE9BQU87R0FDZixNQUFNLEdBQUcsU0FBUztHQUNsQixPQUFPLEdBQUcsVUFBVTtHQUNwQixRQUFRO0VBQ1o7Q0FDSjs7Q0FHQSxNQUFNLHVCQUF1QjtFQUN6QixJQUFJLENBQUMsY0FBYyxrQkFBa0IsU0FBUyxPQUFPO0VBQ3JELE1BQU0sWUFBWSxLQUFLLElBQUksS0FBSyxPQUFPLGFBQWEsRUFBRTtFQUN0RCxJQUFJLFdBQVcsV0FBVyxPQUFRLFdBQVcsUUFBUSxJQUFNLFlBQVk7RUFDdkUsSUFBSSxXQUFXLElBQUksV0FBVztFQUM5QixJQUFJLFdBQVcsWUFBWSxPQUFPLGFBQWEsSUFBSTtHQUMvQyxXQUFXLE9BQU8sYUFBYSxZQUFZO0VBQy9DO0VBQ0EsTUFBTSxlQUFlLFdBQVcsT0FBUSxXQUFXLFFBQVE7RUFDM0QsTUFBTSxrQkFBa0IsZUFBZTs7RUFFdkMsT0FBTyxHQUFHLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxZQUFZLElBQUksZUFBZSxDQUFDLEVBQUU7Q0FDdEU7Q0FFQSxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFSyxhQUNHLGdEQUVJLHdCQUFDLE9BQUQ7R0FDSSxXQUFVO0dBQ1YsT0FBTztJQUNILEtBQUssR0FBRyxLQUFLLElBQUksR0FBRyxXQUFXLE1BQU0sQ0FBQyxFQUFFO0lBQ3hDLE1BQU0sR0FBRyxLQUFLLElBQUksR0FBRyxXQUFXLE9BQU8sQ0FBQyxFQUFFO0lBQzFDLE9BQU8sR0FBRyxXQUFXLFFBQVEsR0FBRztJQUNoQyxRQUFRLEdBQUcsV0FBVyxTQUFTLEdBQUc7SUFDbEMsV0FBVztJQUNYLFFBQVE7R0FDWjtFQUNIOzs7O1lBRUQsd0JBQUMsT0FBRDtHQUNJLFdBQVU7R0FDVixVQUFVLE1BQU0sRUFBRSxnQkFBZ0I7RUFDckM7Ozs7VUFDSDs7OzthQUVGLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDJEQUE0RDs7OztZQUkvRSx3QkFBQyxPQUFEO0dBQ0ksT0FBTyxhQUFhO0dBQ3BCLFdBQVU7YUFGZDtJQUtLLGNBQWMsa0JBQWtCLFdBQzdCLHdCQUFDLE9BQUQ7S0FDSSxXQUFVO0tBQ1YsT0FBTztNQUNILE1BQU0sZUFBZTtNQUNyQixZQUFZO01BQ1osR0FBSSxrQkFBa0IsUUFDaEI7T0FBRSxRQUFRO09BQVEsa0JBQWtCO09BQU8sbUJBQW1CO01BQU0sSUFDcEU7T0FBRSxLQUFLO09BQVEsaUJBQWlCO09BQU8sZ0JBQWdCO01BQU07TUFDbkUsUUFBUTtLQUNaO0lBQ0g7Ozs7O0lBSUosY0FBYyxrQkFBa0IsV0FDN0Isd0JBQUMsT0FBRDtLQUNJLFdBQVU7S0FDVixPQUFPO01BQ0gsTUFBTTtNQUNOLEtBQUs7TUFDTCxpQkFBaUI7TUFDakIsbUJBQW1CO01BQ25CLFFBQVE7S0FDWjtJQUNIOzs7OztJQUlMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCO1VBQ0ksd0JBQUMsVUFBRDtXQUFVLE1BQU07V0FBSSxXQUFVO1VBQW9DOzs7OztVQUNqRSxjQUFjO1VBQUU7VUFBRSxNQUFNO1NBQ3ZCOzs7OztrQkFDTCxLQUFLLFNBQ0Ysd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ1gsS0FBSztRQUNKOzs7O2dCQUVUOzs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLFNBQVM7UUFDVCxXQUFVO2tCQUhkLENBS0ksd0JBQUMsUUFBRCxZQUFNLFNBQVk7Ozs7a0JBQ2xCLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7Z0JBQ1Y7Ozs7O2VBQ1A7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDSyxLQUFLLFFBQ0Ysd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1YsS0FBSztRQUNMOzs7O2tCQUVULHdCQUFDLFFBQUQsWUFBTyxLQUFLLE1BQVk7Ozs7Z0JBQ3hCOzs7OztpQkFDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDUixLQUFLO09BQ1A7Ozs7ZUFDRjs7Ozs7O01BR0osS0FBSyxnQkFDRix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCx3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLGVBQWU7U0FDWCxJQUFJLEtBQUssYUFBYSxTQUFTO1VBQzNCLEtBQUssYUFBYSxRQUFRO1NBQzlCO1FBQ0o7UUFDQSxXQUFVO2tCQVBkO1NBU0ssS0FBSyxhQUFhO1NBQ25CLHdCQUFDLFFBQUQsWUFBTyxLQUFLLGFBQWEsS0FBVzs7Ozs7U0FDcEMsd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7Ozs7UUFDckI7Ozs7OztNQUNQOzs7OztNQUlULHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBRUksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1YsTUFBTSxLQUFLLEdBQUcsUUFDWCx3QkFBQyxVQUFEO1NBRUksTUFBSztTQUNMLGVBQWUsZUFBZSxHQUFHO1NBQ2pDLFdBQVcsb0RBQ1AsUUFBUSxjQUNGLG9CQUNBLE1BQU0sY0FDTixvQkFDQTtTQUVWLE9BQU8sY0FBYyxNQUFNO1FBQzlCLEdBWFE7Ozs7ZUFXUixDQUNKO09BQ0E7Ozs7aUJBR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSyxDQUFDLGVBQ0Usd0JBQUMsVUFBRDtTQUNJLE1BQUs7U0FDTCxTQUFTO1NBQ1QsV0FBVTttQkFIZCxDQUtJLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7bUJBQ3hCLHdCQUFDLFFBQUQsWUFBTSxVQUFhOzs7O2lCQUNmOzs7OztrQkFHWix3QkFBQyxVQUFEO1NBQ0ksTUFBSztTQUNMLFNBQVM7U0FDVCxXQUFVO21CQUhkLENBS1Esd0JBQUMsUUFBRCxZQUFPLGFBQWEsWUFBYSxLQUFLLGVBQWUsU0FBZ0I7Ozs7bUJBQ3hFLGFBQWEsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7OztvQkFBSSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O2lCQUN6RDs7Ozs7Z0JBQ1A7Ozs7O2VBQ0o7Ozs7OztLQUNKOzs7Ozs7R0FDSjs7Ozs7VUFDSjs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiT25ib2FyZGluZ1RvdXIuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBYLCBDaGV2cm9uUmlnaHQsIENoZXZyb25MZWZ0LCBDaGVjaywgU3BhcmtsZXMgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG4vKipcbiAqIE9uYm9hcmRpbmdUb3VyIC0gS29tcG9uZW4gR3VpZGVkIE9uYm9hcmRpbmcgVG91ciBkZW5nYW4gU3BvdGxpZ2h0IFBhdHRlcm5cbiAqIFBvbGEgRHVvbGluZ28gJiBBbnRocm9waWMgeWFuZyBkaXNlbXB1cm5ha2FuOlxuICogLSBPdmVybGF5IGdlbGFwIGZva3VzIChyZ2JhKDAsIDAsIDAsIDAuNzIpKVxuICogLSBDdXRvdXQgc3BvdGxpZ2h0IHRhcmdldCB5YW5nIHByZXNpc2kgZGVuZ2FuIGR5bmFtaWMgYm91bmRpbmcgcmVjdFxuICogLSBCb3JkZXIgZ2xvd2luZyBlbGVnYW46IHRlYWwtNDAwIGRlbmdhbiBnbG93IGhhbHVzXG4gKiAtIENhcmQgcGVuamVsYXNhbiBtZW5lbXBlbCBkaSBkZWthdCB0YXJnZXQgZGVuZ2FuIHBvaW50ZXIgcGVudW5qdWtcbiAqIC0gU2FmZSBjbGFtcGluZyBhZ2FyIGNhcmQgdGlkYWsgcGVybmFoIHRlcnBvdG9uZyBkaSBhdGFzIHZpZXdwb3J0IChzZWFyY2ggYmFyIC8gYnJvd3NlciBiYXIpXG4gKiAtIE5hdmlnYXNpIEtlbWJhbGkgJiBMYW5qdXQvU2VsZXNhaSwga2V5Ym9hcmQgc2hvcnRjdXRzLCBkYW4gYXV0by1zY3JvbGxcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gT25ib2FyZGluZ1RvdXIoe1xuICAgIHN0ZXBzID0gW10sXG4gICAgaXNPcGVuID0gZmFsc2UsXG4gICAgb25DbG9zZSA9ICgpID0+IHt9LFxuICAgIG9uQ29tcGxldGUgPSAoKSA9PiB7fSxcbn0pIHtcbiAgICBjb25zdCBbY3VycmVudFN0ZXAsIHNldEN1cnJlbnRTdGVwXSA9IHVzZVN0YXRlKDApO1xuICAgIGNvbnN0IFt0YXJnZXRSZWN0LCBzZXRUYXJnZXRSZWN0XSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtjYXJkUGxhY2VtZW50LCBzZXRDYXJkUGxhY2VtZW50XSA9IHVzZVN0YXRlKCdib3R0b20nKTtcbiAgICBjb25zdCBbc2hvd1dlbGNvbWUsIHNldFNob3dXZWxjb21lXSA9IHVzZVN0YXRlKHRydWUpO1xuXG4gICAgY29uc3Qgc3RlcCA9IHN0ZXBzW2N1cnJlbnRTdGVwXSB8fCBudWxsO1xuXG4gICAgLy8gSGl0dW5nIHBvc2lzaSBlbGVtZW4gdGFyZ2V0XG4gICAgY29uc3QgdXBkYXRlVGFyZ2V0UG9zaXRpb24gPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIGlmICghaXNPcGVuIHx8IHNob3dXZWxjb21lIHx8ICFzdGVwKSB7XG4gICAgICAgICAgICBzZXRUYXJnZXRSZWN0KG51bGwpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3Qgc2VsZWN0b3IgPSBzdGVwLnNlbGVjdG9yO1xuICAgICAgICBjb25zdCB0YXJnZXRFbGVtZW50ID0gdHlwZW9mIHNlbGVjdG9yID09PSAnc3RyaW5nJyBcbiAgICAgICAgICAgID8gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3RvcikgXG4gICAgICAgICAgICA6IHNlbGVjdG9yPy5jdXJyZW50O1xuXG4gICAgICAgIGlmICghdGFyZ2V0RWxlbWVudCkge1xuICAgICAgICAgICAgLy8gSmFuZ2FuIHRhbXBpbGthbiBjYXJkIGRpIGFyZWEga29zb25nLiBMZXdhdGkgbGFuZ2thaCB5YW5nIHRhcmdldG55YVxuICAgICAgICAgICAgLy8gc3VkYWggdGlkYWsgYWRhIChtaXNhbG55YSB0b21ib2wgeWFuZyBiZXJ1YmFoIGthcmVuYSBzdGF0ZSBVSSkuXG4gICAgICAgICAgICBzZXRUYXJnZXRSZWN0KG51bGwpO1xuICAgICAgICAgICAgY29uc3QgbmV4dEF2YWlsYWJsZSA9IHN0ZXBzLmZpbmRJbmRleCgoY2FuZGlkYXRlLCBpbmRleCkgPT4gaW5kZXggPiBjdXJyZW50U3RlcCAmJiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGNhbmRpZGF0ZS5zZWxlY3RvcikpO1xuICAgICAgICAgICAgaWYgKG5leHRBdmFpbGFibGUgPj0gMCkgc2V0Q3VycmVudFN0ZXAobmV4dEF2YWlsYWJsZSk7XG4gICAgICAgICAgICBlbHNlIGlmIChjdXJyZW50U3RlcCA8IHN0ZXBzLmxlbmd0aCAtIDEpIHNldEN1cnJlbnRTdGVwKGN1cnJlbnRTdGVwICsgMSk7XG4gICAgICAgICAgICBlbHNlIHsgb25Db21wbGV0ZSgpOyBvbkNsb3NlKCk7IH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEF1dG8tc2Nyb2xsIGtlIHRhcmdldCBqaWthIGRpIGx1YXIgdmlld3BvcnQgYXRhdSB0ZXJsYWx1IG1lcGV0IGtlIGF0YXNcbiAgICAgICAgY29uc3QgcmVjdCA9IHRhcmdldEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIGNvbnN0IG1pblRvcE1hcmdpbiA9IDgwO1xuICAgICAgICBjb25zdCBpc0luVmlld3BvcnQgPSAoXG4gICAgICAgICAgICByZWN0LnRvcCA+PSBtaW5Ub3BNYXJnaW4gJiZcbiAgICAgICAgICAgIHJlY3QubGVmdCA+PSAwICYmXG4gICAgICAgICAgICByZWN0LmJvdHRvbSA8PSAod2luZG93LmlubmVySGVpZ2h0IHx8IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRIZWlnaHQpIC0gNDAgJiZcbiAgICAgICAgICAgIHJlY3QucmlnaHQgPD0gKHdpbmRvdy5pbm5lcldpZHRoIHx8IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aClcbiAgICAgICAgKTtcblxuICAgICAgICBpZiAoIWlzSW5WaWV3cG9ydCkge1xuICAgICAgICAgICAgdGFyZ2V0RWxlbWVudC5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJywgYmxvY2s6ICdjZW50ZXInLCBpbmxpbmU6ICduZWFyZXN0JyB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEFtYmlsIGtvb3JkaW5hdCB0ZXJiYXJ1IHNldGVsYWggc2Nyb2xsL3Bvc2lzaVxuICAgICAgICBjb25zdCB1cGRhdGVkUmVjdCA9IHRhcmdldEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIHNldFRhcmdldFJlY3Qoe1xuICAgICAgICAgICAgdG9wOiB1cGRhdGVkUmVjdC50b3AsXG4gICAgICAgICAgICBsZWZ0OiB1cGRhdGVkUmVjdC5sZWZ0LFxuICAgICAgICAgICAgd2lkdGg6IHVwZGF0ZWRSZWN0LndpZHRoLFxuICAgICAgICAgICAgaGVpZ2h0OiB1cGRhdGVkUmVjdC5oZWlnaHQsXG4gICAgICAgICAgICBib3R0b206IHVwZGF0ZWRSZWN0LmJvdHRvbSxcbiAgICAgICAgICAgIHJpZ2h0OiB1cGRhdGVkUmVjdC5yaWdodCxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gQlVHIEZJWDogVGVudHVrYW4gcGVuZW1wYXRhbiBjYXJkIHBlbmplbGFzYW5cbiAgICAgICAgLy8gSmlrYSB0YXJnZXQgYmVyYWRhIGRpIGJhZ2lhbiBhdGFzIGxheWFyIChzZXBlcnRpIHNpZGViYXIgbWVudSBhdGF1IHRvcGJhciksIHBhc3Rpa2FuIGNhcmQgdGlkYWsgcGVybmFoIHRlcnBvdG9uZyBkaSBhdGFzIHZpZXdwb3J0XG4gICAgICAgIGNvbnN0IHNwYWNlQmVsb3cgPSB3aW5kb3cuaW5uZXJIZWlnaHQgLSB1cGRhdGVkUmVjdC5ib3R0b207XG4gICAgICAgIGNvbnN0IHNwYWNlQWJvdmUgPSB1cGRhdGVkUmVjdC50b3A7XG4gICAgICAgIGNvbnN0IG5lZWRlZENhcmRIZWlnaHQgPSAyNjA7XG5cbiAgICAgICAgaWYgKHN0ZXAucGxhY2VtZW50KSB7XG4gICAgICAgICAgICBzZXRDYXJkUGxhY2VtZW50KHN0ZXAucGxhY2VtZW50KTtcbiAgICAgICAgfSBlbHNlIGlmICh3aW5kb3cuaW5uZXJXaWR0aCA+PSAxMDI0ICYmIHVwZGF0ZWRSZWN0LmxlZnQgPCAzMjAgJiYgdXBkYXRlZFJlY3QucmlnaHQgPD0gMzYwKSB7XG4gICAgICAgICAgICAvLyBKaWthIGVsZW1lbiBiZXJhZGEgZGkgc2lkZWJhciBraXJpIChkZXNrdG9wKSwgcG9zaXNpa2FuIGNhcmQgZGkgc2ViZWxhaCBrYW5hbiBlbGVtZW5cbiAgICAgICAgICAgIHNldENhcmRQbGFjZW1lbnQoJ3JpZ2h0Jyk7XG4gICAgICAgIH0gZWxzZSBpZiAoc3BhY2VBYm92ZSA+IG5lZWRlZENhcmRIZWlnaHQgKyAxMDAgJiYgc3BhY2VCZWxvdyA8IDIyMCkge1xuICAgICAgICAgICAgLy8gSGFueWEgZ3VuYWthbiAndG9wJyBqaWthIHNwYWNlIGRpIGF0YXMgYmVuYXItYmVuYXIgbGVnYSBkYW4gdGlkYWsgbWVwZXQgYnJvd3NlciBiYXJcbiAgICAgICAgICAgIHNldENhcmRQbGFjZW1lbnQoJ3RvcCcpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0Q2FyZFBsYWNlbWVudCgnYm90dG9tJyk7XG4gICAgICAgIH1cbiAgICB9LCBbaXNPcGVuLCBzaG93V2VsY29tZSwgc3RlcCwgc3RlcHMsIGN1cnJlbnRTdGVwXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWlzT3Blbikge1xuICAgICAgICAgICAgc2V0Q3VycmVudFN0ZXAoMCk7XG4gICAgICAgICAgICBzZXRTaG93V2VsY29tZSh0cnVlKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEJlcmkgc2VkaWtpdCBqZWRhIGFnYXIgRE9NIHJlbmRlciBzZW1wdXJuYVxuICAgICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdXBkYXRlVGFyZ2V0UG9zaXRpb24oKTtcbiAgICAgICAgfSwgMTAwKTtcblxuICAgICAgICBjb25zdCBoYW5kbGVSZXNpemVPclNjcm9sbCA9ICgpID0+IHtcbiAgICAgICAgICAgIHVwZGF0ZVRhcmdldFBvc2l0aW9uKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIGhhbmRsZVJlc2l6ZU9yU2Nyb2xsKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGhhbmRsZVJlc2l6ZU9yU2Nyb2xsLCB0cnVlKTtcblxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdyZXNpemUnLCBoYW5kbGVSZXNpemVPclNjcm9sbCk7XG4gICAgICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgaGFuZGxlUmVzaXplT3JTY3JvbGwsIHRydWUpO1xuICAgICAgICB9O1xuICAgIH0sIFtpc09wZW4sIGN1cnJlbnRTdGVwLCB1cGRhdGVUYXJnZXRQb3NpdGlvbl0pO1xuXG4gICAgLy8gS2V5Ym9hcmQgbmF2aWdhdGlvbiAoQXJyb3dSaWdodC9FbnRlciB1bnR1ayBsYW5qdXQsIEVzY2FwZSB1bnR1ayBsZXdhdGkpXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFpc09wZW4pIHJldHVybjtcblxuICAgICAgICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGUpID0+IHtcbiAgICAgICAgICAgIGlmIChlLmtleSA9PT0gJ0VzY2FwZScpIHtcbiAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICAgICAgaGFuZGxlU2tpcCgpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChlLmtleSA9PT0gJ0Fycm93UmlnaHQnIHx8IGUua2V5ID09PSAnRW50ZXInKSB7XG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgIGhhbmRsZU5leHQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICAgICAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKTtcbiAgICB9LCBbaXNPcGVuLCBjdXJyZW50U3RlcCwgc3RlcHMubGVuZ3RoXSk7XG5cbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgICBpZiAoc2hvd1dlbGNvbWUpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5MF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwLzQ1IHAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXNtIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHAtNSB0ZXh0LXNsYXRlLTgwMCBzaGFkb3cteGwgZGFyazpib3JkZXItc2xhdGUtNzAwIGRhcms6Ymctc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiPkhhbG8sIHNlbGFtYXQgZGF0YW5nITwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkXCI+U2lhcCBtZW1idWF0IGZvcm11bGlyIHBlcnRhbWFtdT88L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPkthbWkgYWthbiBtZW5lbWFuaSBrYW11IG1lbmdlbmFsIGZpdHVyLWZpdHVyIHBlbnRpbmcgRm9ybVVwLCBkYXJpIG1lbWJ1YXQgc29hbCBzYW1wYWkgbWVtYmFnaWthbiBmb3JtdWxpci4gQ3VtYSBzZWJlbnRhciBrb2suPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IGZsZXgganVzdGlmeS1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgb25Db21wbGV0ZSgpOyBvbkNsb3NlKCk7IH19IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwXCI+TmFudGkgZHVsdTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd1dlbGNvbWUoZmFsc2UpfSBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLXRlYWwtNjAwIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGhvdmVyOmJnLXRlYWwtNzAwXCI+WXVrLCBtdWxhaTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApO1xuICAgIH1cblxuICAgIGlmICghc3RlcCkgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBpc0xhc3RTdGVwID0gY3VycmVudFN0ZXAgPT09IHN0ZXBzLmxlbmd0aCAtIDE7XG4gICAgY29uc3QgaXNGaXJzdFN0ZXAgPSBjdXJyZW50U3RlcCA9PT0gMDtcblxuICAgIGNvbnN0IGhhbmRsZU5leHQgPSAoKSA9PiB7XG4gICAgICAgIGlmIChpc0xhc3RTdGVwKSB7XG4gICAgICAgICAgICBvbkNvbXBsZXRlKCk7XG4gICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0SWR4ID0gY3VycmVudFN0ZXAgKyAxO1xuICAgICAgICAgICAgY29uc3QgbmV4dFN0ZXAgPSBzdGVwc1tuZXh0SWR4XTtcbiAgICAgICAgICAgIGlmIChzdGVwPy5vbkxlYXZlU3RlcCkge1xuICAgICAgICAgICAgICAgIHN0ZXAub25MZWF2ZVN0ZXAoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChuZXh0U3RlcD8uYWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgbmV4dFN0ZXAuYWN0aW9uKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXRDdXJyZW50U3RlcChuZXh0SWR4KTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVQcmV2ID0gKCkgPT4ge1xuICAgICAgICBpZiAoY3VycmVudFN0ZXAgPiAwKSB7XG4gICAgICAgICAgICBzZXRDdXJyZW50U3RlcChwcmV2ID0+IHByZXYgLSAxKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTa2lwID0gKCkgPT4ge1xuICAgICAgICBvbkNvbXBsZXRlKCk7IC8vIFRldGFwIHRhbmRhaSBzZWxlc2FpIGFnYXIgdGlkYWsgbWVuZ2dhbmdndSBsYWdpXG4gICAgICAgIG9uQ2xvc2UoKTtcbiAgICB9O1xuXG4gICAgLy8gSGl0dW5nIHBvc2lzaSBjYXJkIHRvb2x0aXAgc2VjYXJhIHJlc3BvbnNpZlxuICAgIGNvbnN0IGdldENhcmRTdHlsZSA9ICgpID0+IHtcbiAgICAgICAgaWYgKCF0YXJnZXRSZWN0KSB7XG4gICAgICAgICAgICAvLyBKaWthIHRhcmdldCB0aWRhayBkaXRlbXVrYW4sIHRlbXBhdGthbiBjYXJkIGRpIHRlbmdhaCBsYXlhclxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogJ2ZpeGVkJyxcbiAgICAgICAgICAgICAgICB0b3A6ICc1MCUnLFxuICAgICAgICAgICAgICAgIGxlZnQ6ICc1MCUnLFxuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZSgtNTAlLCAtNTAlKScsXG4gICAgICAgICAgICAgICAgbWF4V2lkdGg6ICc5MnZ3JyxcbiAgICAgICAgICAgICAgICB3aWR0aDogJzQ0MHB4JyxcbiAgICAgICAgICAgICAgICB6SW5kZXg6IDk5OTk5LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHBhZGRpbmcgPSAxNjtcbiAgICAgICAgY29uc3QgY2FyZFdpZHRoID0gTWF0aC5taW4oNDQwLCB3aW5kb3cuaW5uZXJXaWR0aCAtIDMyKTtcblxuICAgICAgICAvLyBIb3Jpem9udGFsIGFsaWdubWVudDogdGVuZ2Foa2FuIGNhcmQgdGVyaGFkYXAgdGFyZ2V0IG5hbXVuIHRldGFwIGRpIGRhbGFtIHZpZXdwb3J0XG4gICAgICAgIGxldCBjYXJkTGVmdCA9IHRhcmdldFJlY3QubGVmdCArICh0YXJnZXRSZWN0LndpZHRoIC8gMikgLSAoY2FyZFdpZHRoIC8gMik7XG4gICAgICAgIGlmIChjYXJkTGVmdCA8IDE2KSBjYXJkTGVmdCA9IDE2O1xuICAgICAgICBpZiAoY2FyZExlZnQgKyBjYXJkV2lkdGggPiB3aW5kb3cuaW5uZXJXaWR0aCAtIDE2KSB7XG4gICAgICAgICAgICBjYXJkTGVmdCA9IHdpbmRvdy5pbm5lcldpZHRoIC0gY2FyZFdpZHRoIC0gMTY7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY2FyZFBsYWNlbWVudCA9PT0gJ3JpZ2h0Jykge1xuICAgICAgICAgICAgY29uc3QgcmlnaHRQb3MgPSBNYXRoLm1pbih3aW5kb3cuaW5uZXJXaWR0aCAtIGNhcmRXaWR0aCAtIDE2LCB0YXJnZXRSZWN0LnJpZ2h0ICsgcGFkZGluZyk7XG4gICAgICAgICAgICBsZXQgdG9wUG9zID0gTWF0aC5tYXgoODAsIHRhcmdldFJlY3QudG9wKTtcbiAgICAgICAgICAgIGlmICh0b3BQb3MgKyAzMDAgPiB3aW5kb3cuaW5uZXJIZWlnaHQpIHtcbiAgICAgICAgICAgICAgICB0b3BQb3MgPSBNYXRoLm1heCg4MCwgd2luZG93LmlubmVySGVpZ2h0IC0gMzIwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246ICdmaXhlZCcsXG4gICAgICAgICAgICAgICAgdG9wOiBgJHt0b3BQb3N9cHhgLFxuICAgICAgICAgICAgICAgIGxlZnQ6IGAke3JpZ2h0UG9zfXB4YCxcbiAgICAgICAgICAgICAgICB3aWR0aDogYCR7Y2FyZFdpZHRofXB4YCxcbiAgICAgICAgICAgICAgICB6SW5kZXg6IDk5OTk5LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjYXJkUGxhY2VtZW50ID09PSAndG9wJykge1xuICAgICAgICAgICAgY29uc3QgYm90dG9tUG9zID0gTWF0aC5tYXgoMTYsIHdpbmRvdy5pbm5lckhlaWdodCAtIHRhcmdldFJlY3QudG9wICsgcGFkZGluZyk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgICAgICAgICAgIGJvdHRvbTogYCR7Ym90dG9tUG9zfXB4YCxcbiAgICAgICAgICAgICAgICBsZWZ0OiBgJHtjYXJkTGVmdH1weGAsXG4gICAgICAgICAgICAgICAgd2lkdGg6IGAke2NhcmRXaWR0aH1weGAsXG4gICAgICAgICAgICAgICAgekluZGV4OiA5OTk5OSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB0b3BQb3MgPSBNYXRoLm1heCg4MCwgdGFyZ2V0UmVjdC5ib3R0b20gKyBwYWRkaW5nKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgICAgICAgdG9wOiBgJHt0b3BQb3N9cHhgLFxuICAgICAgICAgICAgbGVmdDogYCR7Y2FyZExlZnR9cHhgLFxuICAgICAgICAgICAgd2lkdGg6IGAke2NhcmRXaWR0aH1weGAsXG4gICAgICAgICAgICB6SW5kZXg6IDk5OTk5LFxuICAgICAgICB9O1xuICAgIH07XG5cbiAgICAvLyBQb3Npc2kgZWtvciBwb2ludGVyIHNlZ2l0aWdhXG4gICAgY29uc3QgZ2V0UG9pbnRlckxlZnQgPSAoKSA9PiB7XG4gICAgICAgIGlmICghdGFyZ2V0UmVjdCB8fCBjYXJkUGxhY2VtZW50ID09PSAncmlnaHQnKSByZXR1cm4gJzUwJSc7XG4gICAgICAgIGNvbnN0IGNhcmRXaWR0aCA9IE1hdGgubWluKDQ0MCwgd2luZG93LmlubmVyV2lkdGggLSAzMik7XG4gICAgICAgIGxldCBjYXJkTGVmdCA9IHRhcmdldFJlY3QubGVmdCArICh0YXJnZXRSZWN0LndpZHRoIC8gMikgLSAoY2FyZFdpZHRoIC8gMik7XG4gICAgICAgIGlmIChjYXJkTGVmdCA8IDE2KSBjYXJkTGVmdCA9IDE2O1xuICAgICAgICBpZiAoY2FyZExlZnQgKyBjYXJkV2lkdGggPiB3aW5kb3cuaW5uZXJXaWR0aCAtIDE2KSB7XG4gICAgICAgICAgICBjYXJkTGVmdCA9IHdpbmRvdy5pbm5lcldpZHRoIC0gY2FyZFdpZHRoIC0gMTY7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdGFyZ2V0Q2VudGVyID0gdGFyZ2V0UmVjdC5sZWZ0ICsgKHRhcmdldFJlY3Qud2lkdGggLyAyKTtcbiAgICAgICAgY29uc3QgcmVsYXRpdmVQb2ludGVyID0gdGFyZ2V0Q2VudGVyIC0gY2FyZExlZnQ7XG4gICAgICAgIC8vIENsYW1wIGFnYXIgdGlkYWsga2VsdWFyIGRhcmkgc3VkdXQgcm91bmRlZCBjYXJkXG4gICAgICAgIHJldHVybiBgJHtNYXRoLm1heCgyNCwgTWF0aC5taW4oY2FyZFdpZHRoIC0gMjQsIHJlbGF0aXZlUG9pbnRlcikpfXB4YDtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTkwXSBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgey8qIExhdGFyIEJlbGFrYW5nICYgU3BvdGxpZ2h0IEN1dG91dCAqL31cbiAgICAgICAgICAgIHt0YXJnZXRSZWN0ID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBFbGVtZW4gc3BvdGxpZ2h0IGN1dG91dCBkZW5nYW4gYm94LXNoYWRvdyByYWtzYXNhIGRhbiBib3JkZXIgdGVhbCBnbG93ICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1vdXQgcG9pbnRlci1ldmVudHMtbm9uZSByb3VuZGVkLTJ4bCByaW5nLTQgcmluZy10ZWFsLTQwMC85MCBzaGFkb3ctWzBfMF8zNXB4X3JnYmEoMjAsMTg0LDE2NiwwLjY1KV1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IGAke01hdGgubWF4KDgsIHRhcmdldFJlY3QudG9wIC0gNil9cHhgLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IGAke01hdGgubWF4KDgsIHRhcmdldFJlY3QubGVmdCAtIDYpfXB4YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogYCR7dGFyZ2V0UmVjdC53aWR0aCArIDEyfXB4YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGAke3RhcmdldFJlY3QuaGVpZ2h0ICsgMTJ9cHhgLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogJzAgMCAwIDk5OTlweCByZ2JhKDMsIDcsIDE4LCAwLjcyKScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgekluZGV4OiA5OTk5MSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBMYXllciB0cmFuc3BhcmFuIGRpIGF0YXMgdGFyZ2V0IHVudHVrIG1lbmNlZ2FoIGtsaWsgc2VtYmFyYW5nYW4gc2VsYW1hIHRvdXIgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTkyXSBjdXJzb3ItZGVmYXVsdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLXNsYXRlLTk1MC83NSBiYWNrZHJvcC1ibHVyLXhzIHotWzk5OTkxXVwiIC8+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogQ2FyZCBQZW5qZWxhc2FuIFNwb3RsaWdodCAqL31cbiAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgc3R5bGU9e2dldENhcmRTdHlsZSgpfSBcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHsvKiBFa29yIHBvaW50ZXIgKEFycm93KSAqL31cbiAgICAgICAgICAgICAgICB7dGFyZ2V0UmVjdCAmJiBjYXJkUGxhY2VtZW50ICE9PSAncmlnaHQnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdy00IGgtNCBiZy1zbGF0ZS05MDAgYm9yZGVyLXRlYWwtNTAwLzYwIHRyYW5zZm9ybSByb3RhdGUtNDVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiBnZXRQb2ludGVyTGVmdCgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbkxlZnQ6ICctOHB4JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oY2FyZFBsYWNlbWVudCA9PT0gJ3RvcCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB7IGJvdHRvbTogJy04cHgnLCBib3JkZXJSaWdodFdpZHRoOiAnMXB4JywgYm9yZGVyQm90dG9tV2lkdGg6ICcxcHgnIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB7IHRvcDogJy04cHgnLCBib3JkZXJMZWZ0V2lkdGg6ICcxcHgnLCBib3JkZXJUb3BXaWR0aDogJzFweCcgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgekluZGV4OiAxMDAwMDAsXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7LyogRWtvciBwb2ludGVyIGRpIHNhbXBpbmcgamlrYSBjYXJkUGxhY2VtZW50IHJpZ2h0ICovfVxuICAgICAgICAgICAgICAgIHt0YXJnZXRSZWN0ICYmIGNhcmRQbGFjZW1lbnQgPT09ICdyaWdodCcgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB3LTQgaC00IGJnLXNsYXRlLTkwMCBib3JkZXItdGVhbC01MDAvNjAgdHJhbnNmb3JtIHJvdGF0ZS00NVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6ICctOHB4JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6ICcyOHB4JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJMZWZ0V2lkdGg6ICcxcHgnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlckJvdHRvbVdpZHRoOiAnMXB4JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB6SW5kZXg6IDEwMDAwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBCb2R5IENhcmQgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgcC00IHNtOnAtNSByb3VuZGVkLTJ4bCBzaGFkb3cteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICB7LyogSGVhZGVyIENhcmQ6IFByb2dyZXNzICYgVG9tYm9sIExld2F0aSAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgbWItMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgcm91bmRlZC1sZyBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNTAgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC1bMTFweF0gYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsxMn0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFN0ZXAgKyAxfS97c3RlcHMubGVuZ3RofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RlcC5iYWRnZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQtbWQgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHRleHQtWzEwcHhdIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAuYmFkZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2tpcH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBweC0yLjUgcHktMSByb3VuZGVkLXhsIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+TGV3YXRpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBLb250ZW4gVXRhbWEgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAuaWNvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy03IGgtNyByb3VuZGVkLWxnIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC81MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtMzAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RlcC5pY29ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntzdGVwLnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBzbTp0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkIGZvbnQtbm9ybWFsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAuZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBPcHRpb25hbCBIaWdobGlnaHQgQWN0aW9uIEJ1dHRvbiBpbnNpZGUgY2FyZCAqL31cbiAgICAgICAgICAgICAgICAgICAge3N0ZXAuYWN0aW9uQnV0dG9uICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHN0ZXAuYWN0aW9uQnV0dG9uLm9uQ2xpY2spIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwLmFjdGlvbkJ1dHRvbi5vbkNsaWNrKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgcHgtNCByb3VuZGVkLXhsIGJnLXRlYWwtNTAwIGhvdmVyOmJnLXRlYWwtNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtZXh0cmFib2xkIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGVwLmFjdGlvbkJ1dHRvbi5pY29ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57c3RlcC5hY3Rpb25CdXR0b24udGV4dH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7LyogRm9vdGVyIE5hdmlnYXNpOiBTdGVwIGRvdHMsIFRvbWJvbCBLZW1iYWxpICYgTGFuanV0ICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC0yLjUgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdGVwIERvdHMgSW5kaWNhdG9yICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXBzLm1hcCgoXywgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aWR4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50U3RlcChpZHgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaC0xLjUgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWR4ID09PSBjdXJyZW50U3RlcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICd3LTYgYmctdGVhbC01MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaWR4IDwgY3VycmVudFN0ZXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAndy0yIGJnLXRlYWwtNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd3LTIgYmctc2xhdGUtMzAwIGRhcms6Ymctc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YEtlIGxhbmdrYWggJHtpZHggKyAxfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE5hdmlnYXRpb24gQnV0dG9uczogS2VtYmFsaSAmIExhbmp1dCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzRmlyc3RTdGVwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcmV2fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTMgcHktMiBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uTGVmdCBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPktlbWJhbGk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVOZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgYmctdGVhbC01MDAgaG92ZXI6YmctdGVhbC00MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1leHRyYWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2lzTGFzdFN0ZXAgPyAnU2VsZXNhaScgOiAoc3RlcC5uZXh0QnRuVGV4dCB8fCAnTGFuanV0Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNMYXN0U3RlcCA/IDxDaGVjayBzaXplPXsxNX0gLz4gOiA8Q2hldnJvblJpZ2h0IHNpemU9ezE1fSAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuIl19