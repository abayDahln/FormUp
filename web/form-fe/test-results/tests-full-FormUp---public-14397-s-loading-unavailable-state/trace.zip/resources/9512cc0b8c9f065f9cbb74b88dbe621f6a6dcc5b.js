import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/ErrorBoundary.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { AlertTriangle, RefreshCw, Home } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ErrorBoundary.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
export default class ErrorBoundary extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			hasError: false,
			error: null,
			errorInfo: null
		};
	}
	static getDerivedStateFromError(error) {
		return {
			hasError: true,
			error
		};
	}
	componentDidCatch(error, errorInfo) {
		this.setState({ errorInfo });
		console.error("[ErrorBoundary caught error]:", error, errorInfo);
	}
	handleReload = () => {
		window.location.reload();
	};
	handleReset = () => {
		this.setState({
			hasError: false,
			error: null,
			errorInfo: null
		});
	};
	render() {
		if (this.state.hasError) {
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "min-h-[400px] w-full p-6 flex flex-col items-center justify-center text-center bg-slate-50 dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm my-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-14 h-14 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4",
						children: /* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 28 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-extrabold text-slate-900 dark:text-white mb-2",
						children: "Terjadi Kendala pada Tampilan"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 max-w-md mb-6 leading-relaxed",
						children: this.state.error?.message || "Aplikasi mengalami kesalahan tak terduga saat memuat komponen ini."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3 flex-wrap justify-center",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: this.handleReset,
							className: "px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 29
							}, this), " Coba Lagi"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("a", {
							href: "/dashboard",
							className: "px-4 py-2.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Home, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 52,
								columnNumber: 29
							}, this), " Kembali ke Dashboard"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 17
			}, this);
		}
		return this.props.children;
	}
}
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/ErrorBoundary.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ErrorBoundary.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ErrorBoundary.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZSxXQUFXLFlBQVk7OztBQUUvQyxlQUFlLE1BQU0sc0JBQXNCLE1BQU0sVUFBVTtDQUN2RCxZQUFZLE9BQU87RUFDZixNQUFNLEtBQUs7RUFDWCxLQUFLLFFBQVE7R0FBRSxVQUFVO0dBQU8sT0FBTztHQUFNLFdBQVc7RUFBSztDQUNqRTtDQUVBLE9BQU8seUJBQXlCLE9BQU87RUFDbkMsT0FBTztHQUFFLFVBQVU7R0FBTTtFQUFNO0NBQ25DO0NBRUEsa0JBQWtCLE9BQU8sV0FBVztFQUNoQyxLQUFLLFNBQVMsRUFBRSxVQUFVLENBQUM7RUFDM0IsUUFBUSxNQUFNLGlDQUFpQyxPQUFPLFNBQVM7Q0FDbkU7Q0FFQSxxQkFBcUI7RUFDakIsT0FBTyxTQUFTLE9BQU87Q0FDM0I7Q0FFQSxvQkFBb0I7RUFDaEIsS0FBSyxTQUFTO0dBQUUsVUFBVTtHQUFPLE9BQU87R0FBTSxXQUFXO0VBQUssQ0FBQztDQUNuRTtDQUVBLFNBQVM7RUFDTCxJQUFJLEtBQUssTUFBTSxVQUFVO0dBQ3JCLE9BQ0ksd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNYLHdCQUFDLGVBQUQsRUFBZSxNQUFNLEdBQUs7Ozs7O0tBQ3pCOzs7OztLQUNMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUE2RDtLQUV2RTs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDUixLQUFLLE1BQU0sT0FBTyxXQUFXO0tBQy9COzs7OztLQUNILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsVUFBRDtPQUNJLE1BQUs7T0FDTCxTQUFTLEtBQUs7T0FDZCxXQUFVO2lCQUhkLENBS0ksd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OztpQkFBQyxZQUNuQjs7Ozs7Z0JBQ1Isd0JBQUMsS0FBRDtPQUNJLE1BQUs7T0FDTCxXQUFVO2lCQUZkLENBSUksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OztpQkFBQyx1QkFDbkI7Ozs7O2NBQ0Y7Ozs7OztJQUNKOzs7Ozs7RUFFYjtFQUVBLE9BQU8sS0FBSyxNQUFNO0NBQ3RCO0FBQ0oiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRXJyb3JCb3VuZGFyeS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEFsZXJ0VHJpYW5nbGUsIFJlZnJlc2hDdywgSG9tZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEVycm9yQm91bmRhcnkgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKHByb3BzKSB7XG4gICAgICAgIHN1cGVyKHByb3BzKTtcbiAgICAgICAgdGhpcy5zdGF0ZSA9IHsgaGFzRXJyb3I6IGZhbHNlLCBlcnJvcjogbnVsbCwgZXJyb3JJbmZvOiBudWxsIH07XG4gICAgfVxuXG4gICAgc3RhdGljIGdldERlcml2ZWRTdGF0ZUZyb21FcnJvcihlcnJvcikge1xuICAgICAgICByZXR1cm4geyBoYXNFcnJvcjogdHJ1ZSwgZXJyb3IgfTtcbiAgICB9XG5cbiAgICBjb21wb25lbnREaWRDYXRjaChlcnJvciwgZXJyb3JJbmZvKSB7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBlcnJvckluZm8gfSk7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tFcnJvckJvdW5kYXJ5IGNhdWdodCBlcnJvcl06JywgZXJyb3IsIGVycm9ySW5mbyk7XG4gICAgfVxuXG4gICAgaGFuZGxlUmVsb2FkID0gKCkgPT4ge1xuICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG4gICAgfTtcblxuICAgIGhhbmRsZVJlc2V0ID0gKCkgPT4ge1xuICAgICAgICB0aGlzLnNldFN0YXRlKHsgaGFzRXJyb3I6IGZhbHNlLCBlcnJvcjogbnVsbCwgZXJyb3JJbmZvOiBudWxsIH0pO1xuICAgIH07XG5cbiAgICByZW5kZXIoKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlLmhhc0Vycm9yKSB7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtWzQwMHB4XSB3LWZ1bGwgcC02IGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtY2VudGVyIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtM3hsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctc20gbXktNlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLTJ4bCBiZy1hbWJlci0xMDAgZGFyazpiZy1hbWJlci05NTAvNjAgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBzaXplPXsyOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBUZXJqYWRpIEtlbmRhbGEgcGFkYSBUYW1waWxhblxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbWF4LXctbWQgbWItNiBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0aGlzLnN0YXRlLmVycm9yPy5tZXNzYWdlIHx8ICdBcGxpa2FzaSBtZW5nYWxhbWkga2VzYWxhaGFuIHRhayB0ZXJkdWdhIHNhYXQgbWVtdWF0IGtvbXBvbmVuIGluaS4nfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC13cmFwIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17dGhpcy5oYW5kbGVSZXNldH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgc2l6ZT17MTR9IC8+IENvYmEgTGFnaVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9XCIvZGFzaGJvYXJkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMzAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEhvbWUgc2l6ZT17MTR9IC8+IEtlbWJhbGkga2UgRGFzaGJvYXJkXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLnByb3BzLmNoaWxkcmVuO1xuICAgIH1cbn1cbiJdfQ==