import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/ConfirmModal.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { AlertTriangle, HelpCircle, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ConfirmModal.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
const ConfirmModal = ({ isOpen, onClose, onConfirm, title, message, confirmText = "Ya, Lanjutkan", cancelText = "Batal", variant = "danger", isLoading = false }) => {
	if (!isOpen) return null;
	const variantStyles = {
		danger: {
			bgIcon: "bg-red-100 dark:bg-red-950/50 text-red-600 dark:text-red-400",
			btn: "bg-red-600 hover:bg-red-700 text-white",
			icon: /* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-6 h-6" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 13
			}, this)
		},
		primary: {
			bgIcon: "bg-teal-100 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400",
			btn: "bg-[#00897B] hover:bg-[#00796B] text-white",
			icon: /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-6 h-6" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 13
			}, this)
		},
		warning: {
			bgIcon: "bg-amber-100 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400",
			btn: "bg-amber-600 hover:bg-amber-700 text-white",
			icon: /* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-6 h-6" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 13
			}, this)
		}
	};
	const currentVariant = variantStyles[variant] || variantStyles.primary;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl space-y-4",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: `p-2.5 rounded-full ${currentVariant.bgIcon}`,
						children: currentVariant.icon
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("h3", {
						className: "text-base font-bold text-slate-900 dark:text-white",
						children: title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 13
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-slate-500 dark:text-slate-400 font-medium",
					children: message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 pt-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						disabled: isLoading,
						onClick: onClose,
						className: "flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl transition-colors cursor-pointer disabled:opacity-50",
						children: cancelText
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						disabled: isLoading,
						onClick: onConfirm,
						className: `flex-1 px-4 py-2 text-xs font-bold rounded-xl transition-colors cursor-pointer disabled:opacity-50 ${currentVariant.btn}`,
						children: isLoading ? "Memproses..." : confirmText
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
};
_c = ConfirmModal;
export default ConfirmModal;
var _c;
$RefreshReg$(_c, "ConfirmModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/ConfirmModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ConfirmModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ConfirmModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ConfirmModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZSxZQUFZLG9CQUFvQjs7O0FBRXhELE1BQU0sZ0JBQWdCLEVBQ3BCLFFBQ0EsU0FDQSxXQUNBLE9BQ0EsU0FDQSxjQUFjLGlCQUNkLGFBQWEsU0FDYixVQUFVLFVBQ1YsWUFBWSxZQUNSO0NBQ0osSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixNQUFNLGdCQUFnQjtFQUNwQixRQUFRO0dBQ04sUUFBUTtHQUNSLEtBQUs7R0FDTCxNQUFNLHdCQUFDLGVBQUQsRUFBZSxXQUFVLFVBQVc7Ozs7O0VBQzVDO0VBQ0EsU0FBUztHQUNQLFFBQVE7R0FDUixLQUFLO0dBQ0wsTUFBTSx3QkFBQyxjQUFELEVBQWMsV0FBVSxVQUFXOzs7OztFQUMzQztFQUNBLFNBQVM7R0FDUCxRQUFRO0dBQ1IsS0FBSztHQUNMLE1BQU0sd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7Ozs7RUFDekM7Q0FDRjtDQUVBLE1BQU0saUJBQWlCLGNBQWMsWUFBWSxjQUFjO0NBRS9ELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQ0UsV0FBVTtHQUNWLFVBQVUsTUFBTSxFQUFFLGdCQUFnQjthQUZwQztJQUlFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVyxzQkFBc0IsZUFBZTtnQkFDbEQsZUFBZTtLQUNiOzs7O2VBQ0wsd0JBQUMsT0FBRCxZQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNYO0tBQ0M7Ozs7Y0FDRDs7OzthQUNGOzs7Ozs7SUFFTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUNWO0lBQ0E7Ozs7O0lBRUgsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsVUFBVTtNQUNWLFNBQVM7TUFDVCxXQUFVO2dCQUVUO0tBQ0s7Ozs7ZUFDUix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFVBQVU7TUFDVixTQUFTO01BQ1QsV0FBVyxzR0FBc0csZUFBZTtnQkFFL0gsWUFBWSxpQkFBaUI7S0FDeEI7Ozs7YUFDTDs7Ozs7O0dBQ0Y7Ozs7OztDQUNGOzs7OztBQUVUOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ29uZmlybU1vZGFsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQWxlcnRUcmlhbmdsZSwgSGVscENpcmNsZSwgQ2hlY2tDaXJjbGUyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuY29uc3QgQ29uZmlybU1vZGFsID0gKHsgXG4gIGlzT3BlbiwgXG4gIG9uQ2xvc2UsIFxuICBvbkNvbmZpcm0sIFxuICB0aXRsZSwgXG4gIG1lc3NhZ2UsIFxuICBjb25maXJtVGV4dCA9ICdZYSwgTGFuanV0a2FuJywgXG4gIGNhbmNlbFRleHQgPSAnQmF0YWwnLFxuICB2YXJpYW50ID0gJ2RhbmdlcicsIFxuICBpc0xvYWRpbmcgPSBmYWxzZSBcbn0pID0+IHtcbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHZhcmlhbnRTdHlsZXMgPSB7XG4gICAgZGFuZ2VyOiB7XG4gICAgICBiZ0ljb246ICdiZy1yZWQtMTAwIGRhcms6YmctcmVkLTk1MC81MCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAnLFxuICAgICAgYnRuOiAnYmctcmVkLTYwMCBob3ZlcjpiZy1yZWQtNzAwIHRleHQtd2hpdGUnLFxuICAgICAgaWNvbjogPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgfSxcbiAgICBwcmltYXJ5OiB7XG4gICAgICBiZ0ljb246ICdiZy10ZWFsLTEwMCBkYXJrOmJnLXRlYWwtOTUwLzUwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwJyxcbiAgICAgIGJ0bjogJ2JnLVsjMDA4OTdCXSBob3ZlcjpiZy1bIzAwNzk2Ql0gdGV4dC13aGl0ZScsXG4gICAgICBpY29uOiA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgIH0sXG4gICAgd2FybmluZzoge1xuICAgICAgYmdJY29uOiAnYmctYW1iZXItMTAwIGRhcms6YmctYW1iZXItOTUwLzUwIHRleHQtYW1iZXItNjAwIGRhcms6dGV4dC1hbWJlci00MDAnLFxuICAgICAgYnRuOiAnYmctYW1iZXItNjAwIGhvdmVyOmJnLWFtYmVyLTcwMCB0ZXh0LXdoaXRlJyxcbiAgICAgIGljb246IDxIZWxwQ2lyY2xlIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgIH1cbiAgfTtcblxuICBjb25zdCBjdXJyZW50VmFyaWFudCA9IHZhcmlhbnRTdHlsZXNbdmFyaWFudF0gfHwgdmFyaWFudFN0eWxlcy5wcmltYXJ5O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLXNsYXRlLTkwMC81MCBiYWNrZHJvcC1ibHVyLXhzIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cbiAgICAgIDxkaXYgXG4gICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgbWF4LXctc20gdy1mdWxsIHNoYWRvdy0yeGwgc3BhY2UteS00XCJcbiAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHAtMi41IHJvdW5kZWQtZnVsbCAke2N1cnJlbnRWYXJpYW50LmJnSWNvbn1gfT5cbiAgICAgICAgICAgIHtjdXJyZW50VmFyaWFudC5pY29ufVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAge3RpdGxlfVxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAge21lc3NhZ2V9XG4gICAgICAgIDwvcD5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB0LTJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTQgcHktMiBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7Y2FuY2VsVGV4dH1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNvbmZpcm19XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcHgtNCBweS0yIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MCAke2N1cnJlbnRWYXJpYW50LmJ0bn1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAnTWVtcHJvc2VzLi4uJyA6IGNvbmZpcm1UZXh0fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQ29uZmlybU1vZGFsOyJdfQ==