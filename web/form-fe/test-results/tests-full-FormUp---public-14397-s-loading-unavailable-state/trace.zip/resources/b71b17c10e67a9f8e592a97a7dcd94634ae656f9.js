import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/ForgotPasswordPage.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { ArrowLeft, Mail, KeyRound, RefreshCw, CheckCircle, Loader2, Eye, EyeOff } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import { forgotPassword, resetPassword } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/ForgotPasswordPage.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function ForgotPasswordPage() {
	_s();
	const navigate = useNavigate();
	// Step 1: Email input | Step 2: OTP + new password
	const [step, setStep] = useState(1);
	const [email, setEmail] = useState("");
	const [otp, setOtp] = useState("");
	const [newPassword, setNewPassword] = useState("");
	const [confirmPassword, setConfirmPassword] = useState("");
	// State toggle mata password
	const [showPassword, setShowPassword] = useState(false);
	const [showConfirmPassword, setShowConfirmPassword] = useState(false);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState("");
	const [success, setSuccess] = useState(false);
	const handleSendOtp = async (e) => {
		e.preventDefault();
		setError("");
		setLoading(true);
		const res = await forgotPassword(email);
		setLoading(false);
		if (res.ok) {
			setStep(2);
		} else {
			setError(res.message || "Email tidak ditemukan.");
		}
	};
	const handleResetPassword = async (e) => {
		e.preventDefault();
		setError("");
		if (newPassword !== confirmPassword) {
			setError("Password baru dan konfirmasi tidak cocok.");
			return;
		}
		if (newPassword.length < 8) {
			setError("Password minimal 8 karakter.");
			return;
		}
		setLoading(true);
		const res = await resetPassword(email, otp, newPassword);
		setLoading(false);
		if (res.ok) {
			setSuccess(true);
		} else {
			setError(res.message || "OTP salah atau kadaluarsa.");
		}
	};
	// ── Success State ──
	if (success) return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen w-full bg-gradient-to-br from-[#E1F9F4] via-[#a8e8e0] to-[#004D4E] flex items-center justify-center p-4 font-sans py-8",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white/80 dark:bg-slate-900/90 backdrop-blur-xl border border-white/60 dark:border-slate-800 rounded-3xl p-8 sm:p-10 max-w-sm w-full text-center shadow-2xl space-y-5",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "w-14 h-14 bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 rounded-full flex items-center justify-center mx-auto",
					children: /* @__PURE__ */ _jsxDEV(CheckCircle, { size: 28 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-xl font-extrabold text-slate-900 dark:text-white",
					children: "Password Berhasil Diubah!"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1",
					children: "Silakan login dengan password baru Anda."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 21
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => navigate("/login"),
					className: "w-full py-3 bg-[#00897B] hover:bg-[#00796B] text-white font-bold rounded-2xl transition-all cursor-pointer shadow-md",
					children: "Kembali ke Login"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 9
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "h-screen max-h-screen w-full bg-[#004D4E] flex items-center justify-center p-4 sm:p-6 lg:p-12 relative overflow-hidden select-none touch-none",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute inset-0 pointer-events-none",
				style: { background: "linear-gradient(200deg, #2ED8C3 0%, #0FA89E 35%, #018081 75%, #004D4E 100%)" }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute pointer-events-none rounded-full",
				style: {
					width: "clamp(350px, 45vw, 750px)",
					height: "clamp(350px, 45vw, 750px)",
					top: "-10%",
					left: "-10%",
					background: "linear-gradient(-143deg, #2ED8C3 0%, rgba(10, 95, 110, 0.7) 100%)",
					opacity: .6,
					zIndex: 1
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute pointer-events-none rounded-full",
				style: {
					width: "clamp(350px, 45vw, 750px)",
					height: "clamp(350px, 45vw, 750px)",
					bottom: "-10%",
					right: "-10%",
					background: "linear-gradient(135deg, #2ED8C3 0%, rgba(10, 29, 93, 0.7) 100%)",
					opacity: .8,
					zIndex: 1
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative z-10 w-full max-w-md my-auto",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "w-full bg-black/40 backdrop-blur-[20px] border border-white/10 rounded-[28px] p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/login",
								className: "inline-flex items-center gap-1.5 text-xs font-semibold text-[#2ED8C3] hover:underline mb-4 transition-all",
								children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 29
								}, this), " Kembali ke Login"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 mb-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 bg-white/10 border border-white/20 rounded-xl flex items-center justify-center text-[#2ED8C3] shrink-0",
									children: /* @__PURE__ */ _jsxDEV(KeyRound, { size: 20 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 33
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("h1", {
									className: "text-2xl font-bold text-white tracking-tight",
									children: "Lupa Password"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-medium text-white/70",
								children: step === 1 ? "Masukkan email Anda dan kami akan mengirimkan kode OTP." : `Kode OTP telah dikirim ke ${email}. Berlaku 15 menit.`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 25
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [[1, 2].map((s) => /* @__PURE__ */ _jsxDEV("div", { className: `flex-1 h-1.5 rounded-full transition-all ${s <= step ? "bg-[#2ED8C3]" : "bg-white/20"}` }, s, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 29
							}, this)), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-white/50 shrink-0",
								children: [step, "/2"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 21
						}, this),
						error && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-red-500/20 border border-red-500/30 rounded-xl",
							children: /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold text-red-300 text-center",
								children: error
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 25
						}, this),
						step === 1 && /* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleSendOtp,
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-white/90 mb-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Mail, {
									size: 12,
									className: "inline mr-1 text-[#2ED8C3]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 37
								}, this), "Email Terdaftar"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "email",
								required: true,
								value: email,
								onChange: (e) => setEmail(e.target.value),
								placeholder: "nama@email.com",
								className: "w-full px-3.5 py-3 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 33
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								disabled: loading,
								className: "w-full mt-2 py-3.5 bg-[#0FA89E] hover:bg-[#0d968d] active:scale-[0.98] text-white font-bold rounded-full shadow-[0_6px_20px_rgba(15,168,158,0.4)] transition-all duration-200 text-xs sm:text-sm tracking-wide disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center gap-2",
								children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
									size: 16,
									className: "animate-spin"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 177,
									columnNumber: 41
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Mengirim OTP..." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 178,
									columnNumber: 41
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 37
								}, this) : /* @__PURE__ */ _jsxDEV("span", { children: "Kirim Kode OTP" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 37
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 25
						}, this),
						step === 2 && /* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleResetPassword,
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-white/90 mb-1.5",
									children: "Kode OTP (6 digit)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 191,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									maxLength: 6,
									value: otp,
									onChange: (e) => setOtp(e.target.value.replace(/\D/g, "")),
									placeholder: "123456",
									className: "w-full px-3.5 py-3 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-mono tracking-widest text-center focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-sm transition-all shadow-inner"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 192,
									columnNumber: 33
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-white/90 mb-1.5",
									children: "Password Baru"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 205,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative flex items-center",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: showPassword ? "text" : "password",
										required: true,
										value: newPassword,
										onChange: (e) => setNewPassword(e.target.value),
										placeholder: "Minimal 8 karakter",
										className: "w-full px-3.5 py-3 pr-10 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 207,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowPassword(!showPassword),
										className: "absolute right-3 text-white/50 hover:text-white transition-colors cursor-pointer",
										children: showPassword ? /* @__PURE__ */ _jsxDEV(EyeOff, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 220,
											columnNumber: 57
										}, this) : /* @__PURE__ */ _jsxDEV(Eye, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 220,
											columnNumber: 80
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 215,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 33
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-white/90 mb-1.5",
									children: "Konfirmasi Password Baru"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative flex items-center",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: showConfirmPassword ? "text" : "password",
										required: true,
										value: confirmPassword,
										onChange: (e) => setConfirmPassword(e.target.value),
										placeholder: "Ulangi password baru",
										className: `w-full px-3.5 py-3 pr-10 rounded-xl border bg-black/30 text-white placeholder:text-white/40 font-medium focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] text-xs sm:text-sm transition-all shadow-inner ${confirmPassword && confirmPassword !== newPassword ? "border-red-500/50 bg-red-500/10" : "border-white/10"}`
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 229,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowConfirmPassword(!showConfirmPassword),
										className: "absolute right-3 text-white/50 hover:text-white transition-colors cursor-pointer",
										children: showConfirmPassword ? /* @__PURE__ */ _jsxDEV(EyeOff, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 242,
											columnNumber: 64
										}, this) : /* @__PURE__ */ _jsxDEV(Eye, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 242,
											columnNumber: 87
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 237,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 228,
									columnNumber: 33
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: loading,
									className: "w-full py-3.5 bg-[#0FA89E] hover:bg-[#0d968d] active:scale-[0.98] text-white font-bold rounded-full shadow-[0_6px_20px_rgba(15,168,158,0.4)] transition-all duration-200 text-xs sm:text-sm tracking-wide disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center gap-2",
									children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
										size: 16,
										className: "animate-spin"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 254,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Menyimpan..." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 255,
										columnNumber: 41
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 253,
										columnNumber: 37
									}, this) : /* @__PURE__ */ _jsxDEV("span", { children: "Reset Password" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 258,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 247,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setStep(1);
										setOtp("");
										setNewPassword("");
										setConfirmPassword("");
										setError("");
									},
									className: "w-full flex items-center justify-center gap-1.5 text-xs font-semibold text-[#2ED8C3] hover:underline pt-1 transition-colors cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { size: 12 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 266,
										columnNumber: 33
									}, this), " Kirim Ulang OTP"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 261,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 80,
		columnNumber: 13
	}, this);
}
_s(ForgotPasswordPage, "HkBw5T2XJsyzK9zMO6x/oYef0GA=", false, function() {
	return [useNavigate];
});
_c = ForgotPasswordPage;
var _c;
$RefreshReg$(_c, "ForgotPasswordPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/ForgotPasswordPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/ForgotPasswordPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/ForgotPasswordPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/ForgotPasswordPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLFdBQVcsTUFBTSxVQUFVLFdBQVcsYUFBYSxTQUFTLEtBQUssY0FBYztBQUN4RixTQUFTLGdCQUFnQixxQkFBcUI7Ozs7QUFFOUMsZUFBZSxTQUFTLHFCQUFxQjs7Q0FDekMsTUFBTSxXQUFXLFlBQVk7O0NBRzdCLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDO0NBQ2xDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBUyxFQUFFO0NBQ2pDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFOztDQUd6RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQVMsS0FBSztDQUVwRSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUU1QyxNQUFNLGdCQUFnQixPQUFPLE1BQU07RUFDL0IsRUFBRSxlQUFlO0VBQ2pCLFNBQVMsRUFBRTtFQUNYLFdBQVcsSUFBSTtFQUNmLE1BQU0sTUFBTSxNQUFNLGVBQWUsS0FBSztFQUN0QyxXQUFXLEtBQUs7RUFDaEIsSUFBSSxJQUFJLElBQUk7R0FDUixRQUFRLENBQUM7RUFDYixPQUFPO0dBQ0gsU0FBUyxJQUFJLFdBQVcsd0JBQXdCO0VBQ3BEO0NBQ0o7Q0FFQSxNQUFNLHNCQUFzQixPQUFPLE1BQU07RUFDckMsRUFBRSxlQUFlO0VBQ2pCLFNBQVMsRUFBRTtFQUNYLElBQUksZ0JBQWdCLGlCQUFpQjtHQUNqQyxTQUFTLDJDQUEyQztHQUNwRDtFQUNKO0VBQ0EsSUFBSSxZQUFZLFNBQVMsR0FBRztHQUN4QixTQUFTLDhCQUE4QjtHQUN2QztFQUNKO0VBQ0EsV0FBVyxJQUFJO0VBQ2YsTUFBTSxNQUFNLE1BQU0sY0FBYyxPQUFPLEtBQUssV0FBVztFQUN2RCxXQUFXLEtBQUs7RUFDaEIsSUFBSSxJQUFJLElBQUk7R0FDUixXQUFXLElBQUk7RUFDbkIsT0FBTztHQUNILFNBQVMsSUFBSSxXQUFXLDRCQUE0QjtFQUN4RDtDQUNKOztDQUdBLElBQUksU0FBUyxPQUNULHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1gsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1gsd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7Ozs7SUFDdkI7Ozs7O0lBQ0wsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQXdEO0lBQTZCOzs7O2NBQ25HLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTZEO0lBQTJDOzs7O1lBQ3BIOzs7OztJQUNMLHdCQUFDLFVBQUQ7S0FDSSxlQUFlLFNBQVMsUUFBUTtLQUNoQyxXQUFVO2VBQ2I7SUFFTzs7Ozs7R0FDUDs7Ozs7O0NBQ0o7Ozs7O0NBR1QsT0FDUSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUEsd0JBQUMsT0FBRDtJQUNJLFdBQVU7SUFDVixPQUFPLEVBQ0gsWUFBWSw4RUFDaEI7R0FDSDs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQ0ksV0FBVTtJQUNWLE9BQU87S0FDSCxPQUFPO0tBQ1AsUUFBUTtLQUNSLEtBQUs7S0FDTCxNQUFNO0tBQ04sWUFBWTtLQUNaLFNBQVM7S0FDVCxRQUFRO0lBQ1o7R0FDSDs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQ0ksV0FBVTtJQUNWLE9BQU87S0FDSCxPQUFPO0tBQ1AsUUFBUTtLQUNSLFFBQVE7S0FDUixPQUFPO0tBQ1AsWUFBWTtLQUNaLFNBQVM7S0FDVCxRQUFRO0lBQ1o7R0FDSDs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNYLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFHSSx3QkFBQyxPQUFEO09BQ0ksd0JBQUMsTUFBRDtRQUFNLElBQUc7UUFBUyxXQUFVO2tCQUE1QixDQUNJLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7a0JBQUMsbUJBQ3JCOzs7Ozs7T0FDTix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNYLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O1FBQ3BCOzs7O2tCQUNMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUErQztRQUFpQjs7OztnQkFDN0U7Ozs7OztPQUNMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNSLFNBQVMsSUFDSiw0REFDQSw2QkFBNkIsTUFBTTtPQUUxQzs7Ozs7TUFDRjs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFJLE1BQ1Isd0JBQUMsT0FBRCxFQUFhLFdBQVcsNENBQTRDLEtBQUssT0FBTyxpQkFBaUIsZ0JBQWtCLEdBQXpHOzs7O2NBQXlHLENBQ3RILEdBQ0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQTRELE1BQUssSUFBUTs7Ozs7ZUFDeEU7Ozs7OztNQUVKLFNBQ0csd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1gsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQThDO09BQVM7Ozs7O01BQ25FOzs7OztNQUlSLFNBQVMsS0FDTix3QkFBQyxRQUFEO09BQU0sVUFBVTtPQUFlLFdBQVU7aUJBQXpDLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUNJLHdCQUFDLE1BQUQ7U0FBTSxNQUFNO1NBQUksV0FBVTtRQUE4Qjs7OztrQkFBQyxpQkFDdEQ7Ozs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDSSxNQUFLO1FBQ0w7UUFDQSxPQUFPO1FBQ1AsV0FBVSxNQUFLLFNBQVMsRUFBRSxPQUFPLEtBQUs7UUFDdEMsYUFBWTtRQUNaLFdBQVU7T0FDYjs7OztlQUNBOzs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsVUFBVTtRQUNWLFdBQVU7a0JBRVQsVUFDRyxnREFDSSx3QkFBQyxTQUFEO1NBQVMsTUFBTTtTQUFJLFdBQVU7UUFBZ0I7Ozs7a0JBQzdDLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7Z0JBQzdCOzs7O21CQUVGLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7O09BRTFCOzs7O2VBQ047Ozs7OztNQUlULFNBQVMsS0FDTix3QkFBQyxRQUFEO09BQU0sVUFBVTtPQUFxQixXQUFVO2lCQUEvQztRQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBbUQ7UUFBeUI7Ozs7a0JBQzdGLHdCQUFDLFNBQUQ7U0FDSSxNQUFLO1NBQ0w7U0FDQSxXQUFXO1NBQ1gsT0FBTztTQUNQLFdBQVUsTUFBSyxPQUFPLEVBQUUsT0FBTyxNQUFNLFFBQVEsT0FBTyxFQUFFLENBQUM7U0FDdkQsYUFBWTtTQUNaLFdBQVU7UUFDYjs7OztnQkFDQTs7Ozs7UUFHTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQW1EO1FBQW9COzs7O2tCQUN4Rix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLFNBQUQ7VUFDSSxNQUFNLGVBQWUsU0FBUztVQUM5QjtVQUNBLE9BQU87VUFDUCxXQUFVLE1BQUssZUFBZSxFQUFFLE9BQU8sS0FBSztVQUM1QyxhQUFZO1VBQ1osV0FBVTtTQUNiOzs7O21CQUNELHdCQUFDLFVBQUQ7VUFDSSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsQ0FBQyxZQUFZO1VBQzVDLFdBQVU7b0JBRVQsZUFBZSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7O3FCQUFJLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7O1NBQ25EOzs7O2lCQUNQOzs7OztnQkFDSjs7Ozs7UUFHTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQW1EO1FBQStCOzs7O2tCQUNuRyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLFNBQUQ7VUFDSSxNQUFNLHNCQUFzQixTQUFTO1VBQ3JDO1VBQ0EsT0FBTztVQUNQLFdBQVUsTUFBSyxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7VUFDaEQsYUFBWTtVQUNaLFdBQVcsd1BBQXdQLG1CQUFtQixvQkFBb0IsY0FBYyxvQ0FBb0M7U0FDL1Y7Ozs7bUJBQ0Qsd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLHVCQUF1QixDQUFDLG1CQUFtQjtVQUMxRCxXQUFVO29CQUVULHNCQUFzQix3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7O3FCQUFJLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7O1NBQzFEOzs7O2lCQUNQOzs7OztnQkFDSjs7Ozs7UUFFTCx3QkFBQyxVQUFEO1NBQ0ksTUFBSztTQUNMLFVBQVU7U0FDVixXQUFVO21CQUVULFVBQ0csZ0RBQ0ksd0JBQUMsU0FBRDtVQUFTLE1BQU07VUFBSSxXQUFVO1NBQWdCOzs7O21CQUM3Qyx3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7aUJBQzFCOzs7O29CQUVGLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7O1FBRTFCOzs7OztRQUNSLHdCQUFDLFVBQUQ7U0FDSSxNQUFLO1NBQ0wsZUFBZTtVQUFFLFFBQVEsQ0FBQztVQUFHLE9BQU8sRUFBRTtVQUFHLGVBQWUsRUFBRTtVQUFHLG1CQUFtQixFQUFFO1VBQUcsU0FBUyxFQUFFO1NBQUc7U0FDbkcsV0FBVTttQkFIZCxDQUtJLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7bUJBQUMsa0JBQ25COzs7Ozs7T0FDTjs7Ozs7O0tBRVQ7Ozs7OztHQUNKOzs7OztFQUNKOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJGb3Jnb3RQYXNzd29yZFBhZ2UuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEFycm93TGVmdCwgTWFpbCwgS2V5Um91bmQsIFJlZnJlc2hDdywgQ2hlY2tDaXJjbGUsIExvYWRlcjIsIEV5ZSwgRXllT2ZmIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IGZvcmdvdFBhc3N3b3JkLCByZXNldFBhc3N3b3JkIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZvcmdvdFBhc3N3b3JkUGFnZSgpIHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgICAvLyBTdGVwIDE6IEVtYWlsIGlucHV0IHwgU3RlcCAyOiBPVFAgKyBuZXcgcGFzc3dvcmRcbiAgICBjb25zdCBbc3RlcCwgc2V0U3RlcF0gPSB1c2VTdGF0ZSgxKTtcbiAgICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbb3RwLCBzZXRPdHBdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtuZXdQYXNzd29yZCwgc2V0TmV3UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtjb25maXJtUGFzc3dvcmQsIHNldENvbmZpcm1QYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgXG4gICAgLy8gU3RhdGUgdG9nZ2xlIG1hdGEgcGFzc3dvcmRcbiAgICBjb25zdCBbc2hvd1Bhc3N3b3JkLCBzZXRTaG93UGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtzaG93Q29uZmlybVBhc3N3b3JkLCBzZXRTaG93Q29uZmlybVBhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbc3VjY2Vzcywgc2V0U3VjY2Vzc10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICBjb25zdCBoYW5kbGVTZW5kT3RwID0gYXN5bmMgKGUpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzZXRFcnJvcignJyk7XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZvcmdvdFBhc3N3b3JkKGVtYWlsKTtcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIHNldFN0ZXAoMik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRFcnJvcihyZXMubWVzc2FnZSB8fCAnRW1haWwgdGlkYWsgZGl0ZW11a2FuLicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlc2V0UGFzc3dvcmQgPSBhc3luYyAoZSkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHNldEVycm9yKCcnKTtcbiAgICAgICAgaWYgKG5ld1Bhc3N3b3JkICE9PSBjb25maXJtUGFzc3dvcmQpIHtcbiAgICAgICAgICAgIHNldEVycm9yKCdQYXNzd29yZCBiYXJ1IGRhbiBrb25maXJtYXNpIHRpZGFrIGNvY29rLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChuZXdQYXNzd29yZC5sZW5ndGggPCA4KSB7XG4gICAgICAgICAgICBzZXRFcnJvcignUGFzc3dvcmQgbWluaW1hbCA4IGthcmFrdGVyLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHJlc2V0UGFzc3dvcmQoZW1haWwsIG90cCwgbmV3UGFzc3dvcmQpO1xuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgc2V0U3VjY2Vzcyh0cnVlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldEVycm9yKHJlcy5tZXNzYWdlIHx8ICdPVFAgc2FsYWggYXRhdSBrYWRhbHVhcnNhLicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIOKUgOKUgCBTdWNjZXNzIFN0YXRlIOKUgOKUgFxuICAgIGlmIChzdWNjZXNzKSByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1bI0UxRjlGNF0gdmlhLVsjYThlOGUwXSB0by1bIzAwNEQ0RV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGZvbnQtc2FucyBweS04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlLzgwIGRhcms6Ymctc2xhdGUtOTAwLzkwIGJhY2tkcm9wLWJsdXIteGwgYm9yZGVyIGJvcmRlci13aGl0ZS82MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC04IHNtOnAtMTAgbWF4LXctc20gdy1mdWxsIHRleHQtY2VudGVyIHNoYWRvdy0yeGwgc3BhY2UteS01XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgYmctdGVhbC0xMDAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUgc2l6ZT17Mjh9IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+UGFzc3dvcmQgQmVyaGFzaWwgRGl1YmFoITwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5TaWxha2FuIGxvZ2luIGRlbmdhbiBwYXNzd29yZCBiYXJ1IEFuZGEuPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9sb2dpbicpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMyBiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQtMnhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHNoYWRvdy1tZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBLZW1iYWxpIGtlIExvZ2luXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtc2NyZWVuIG1heC1oLXNjcmVlbiB3LWZ1bGwgYmctWyMwMDRENEVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBzbTpwLTYgbGc6cC0xMiByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gc2VsZWN0LW5vbmUgdG91Y2gtbm9uZVwiPiBcbiAgICAgICAgICAgIHsvKiBCYWNrZ3JvdW5kIEdyYWRpZW4gVXRhbWEgKi99XG4gICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgcG9pbnRlci1ldmVudHMtbm9uZVwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCgyMDBkZWcsICMyRUQ4QzMgMCUsICMwRkE4OUUgMzUlLCAjMDE4MDgxIDc1JSwgIzAwNEQ0RSAxMDAlKSdcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgey8qIEJ1bGF0YW4gR3JhZGllbiBLaXJpIEF0YXMgKi99XG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcG9pbnRlci1ldmVudHMtbm9uZSByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAnY2xhbXAoMzUwcHgsIDQ1dncsIDc1MHB4KScsXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogJ2NsYW1wKDM1MHB4LCA0NXZ3LCA3NTBweCknLFxuICAgICAgICAgICAgICAgICAgICB0b3A6ICctMTAlJyxcbiAgICAgICAgICAgICAgICAgICAgbGVmdDogJy0xMCUnLFxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KC0xNDNkZWcsICMyRUQ4QzMgMCUsIHJnYmEoMTAsIDk1LCAxMTAsIDAuNykgMTAwJSknLFxuICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjYsXG4gICAgICAgICAgICAgICAgICAgIHpJbmRleDogMVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICB7LyogQnVsYXRhbiBHcmFkaWVuIEthbmFuIEJhd2FoICovfVxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHBvaW50ZXItZXZlbnRzLW5vbmUgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogJ2NsYW1wKDM1MHB4LCA0NXZ3LCA3NTBweCknLFxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6ICdjbGFtcCgzNTBweCwgNDV2dywgNzUwcHgpJyxcbiAgICAgICAgICAgICAgICAgICAgYm90dG9tOiAnLTEwJScsXG4gICAgICAgICAgICAgICAgICAgIHJpZ2h0OiAnLTEwJScsXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjMkVEOEMzIDAlLCByZ2JhKDEwLCAyOSwgOTMsIDAuNykgMTAwJSknLFxuICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjgsXG4gICAgICAgICAgICAgICAgICAgIHpJbmRleDogMVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICB7LyogQ29udGFpbmVyIFV0YW1hICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIHctZnVsbCBtYXgtdy1tZCBteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctYmxhY2svNDAgYmFja2Ryb3AtYmx1ci1bMjBweF0gYm9yZGVyIGJvcmRlci13aGl0ZS8xMCByb3VuZGVkLVsyOHB4XSBwLTYgc206cC04IHNoYWRvdy1bMF84cHhfMzJweF8wX3JnYmEoMCwwLDAsMC4zNyldIHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCIgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyMyRUQ4QzNdIGhvdmVyOnVuZGVybGluZSBtYi00IHRyYW5zaXRpb24tYWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFycm93TGVmdCBzaXplPXsxNH0gLz4gS2VtYmFsaSBrZSBMb2dpblxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgYmctd2hpdGUvMTAgYm9yZGVyIGJvcmRlci13aGl0ZS8yMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtWyMyRUQ4QzNdIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxLZXlSb3VuZCBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5MdXBhIFBhc3N3b3JkPC9oMT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlLzcwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAgPT09IDFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnTWFzdWtrYW4gZW1haWwgQW5kYSBkYW4ga2FtaSBha2FuIG1lbmdpcmlta2FuIGtvZGUgT1RQLidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBgS29kZSBPVFAgdGVsYWggZGlraXJpbSBrZSAke2VtYWlsfS4gQmVybGFrdSAxNSBtZW5pdC5gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogU3RlcCBJbmRpY2F0b3IgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtbMSwgMl0ubWFwKHMgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtzfSBjbGFzc05hbWU9e2BmbGV4LTEgaC0xLjUgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsICR7cyA8PSBzdGVwID8gJ2JnLVsjMkVEOEMzXScgOiAnYmctd2hpdGUvMjAnfWB9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUvNTAgc2hyaW5rLTBcIj57c3RlcH0vMjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctcmVkLTUwMC8yMCBib3JkZXIgYm9yZGVyLXJlZC01MDAvMzAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtcmVkLTMwMCB0ZXh0LWNlbnRlclwiPntlcnJvcn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7LyogU3RlcCAxOiBFbWFpbCAqL31cbiAgICAgICAgICAgICAgICAgICAge3N0ZXAgPT09IDEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVNlbmRPdHB9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZS85MCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNYWlsIHNpemU9ezEyfSBjbGFzc05hbWU9XCJpbmxpbmUgbXItMSB0ZXh0LVsjMkVEOEMzXVwiIC8+RW1haWwgVGVyZGFmdGFyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIm5hbWFAZW1haWwuY29tXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItd2hpdGUvMTAgYmctYmxhY2svMzAgdGV4dC13aGl0ZSBwbGFjZWhvbGRlcjp0ZXh0LXdoaXRlLzQwIGZvbnQtbWVkaXVtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy1ibGFjay81MCBmb2N1czpib3JkZXItWyMyRUQ4QzNdIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLVsjMkVEOEMzXSB0ZXh0LXhzIHNtOnRleHQtc20gdHJhbnNpdGlvbi1hbGwgc2hhZG93LWlubmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG10LTIgcHktMy41IGJnLVsjMEZBODlFXSBob3ZlcjpiZy1bIzBkOTY4ZF0gYWN0aXZlOnNjYWxlLVswLjk4XSB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLWZ1bGwgc2hhZG93LVswXzZweF8yMHB4X3JnYmEoMTUsMTY4LDE1OCwwLjQpXSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgdGV4dC14cyBzbTp0ZXh0LXNtIHRyYWNraW5nLXdpZGUgZGlzYWJsZWQ6b3BhY2l0eS02MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIHNpemU9ezE2fSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk1lbmdpcmltIE9UUC4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+S2lyaW0gS29kZSBPVFA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFN0ZXAgMjogT1RQICsgTmV3IFBhc3N3b3JkICovfVxuICAgICAgICAgICAgICAgICAgICB7c3RlcCA9PT0gMiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlUmVzZXRQYXNzd29yZH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlLzkwIG1iLTEuNVwiPktvZGUgT1RQICg2IGRpZ2l0KTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17Nn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvdHB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRPdHAoZS50YXJnZXQudmFsdWUucmVwbGFjZSgvXFxEL2csICcnKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjEyMzQ1NlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIGJnLWJsYWNrLzMwIHRleHQtd2hpdGUgcGxhY2Vob2xkZXI6dGV4dC13aGl0ZS80MCBmb250LW1vbm8gdHJhY2tpbmctd2lkZXN0IHRleHQtY2VudGVyIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy1ibGFjay81MCBmb2N1czpib3JkZXItWyMyRUQ4QzNdIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLVsjMkVEOEMzXSB0ZXh0LXNtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1pbm5lclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogSW5wdXQgUGFzc3dvcmQgQmFydSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUvOTAgbWItMS41XCI+UGFzc3dvcmQgQmFydTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/IFwidGV4dFwiIDogXCJwYXNzd29yZFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldE5ld1Bhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1pbmltYWwgOCBrYXJha3RlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0zIHByLTEwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCBiZy1ibGFjay8zMCB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyOnRleHQtd2hpdGUvNDAgZm9udC1tZWRpdW0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJnLWJsYWNrLzUwIGZvY3VzOmJvcmRlci1bIzJFRDhDM10gZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctWyMyRUQ4QzNdIHRleHQteHMgc206dGV4dC1zbSB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctaW5uZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGFzc3dvcmQoIXNob3dQYXNzd29yZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMyB0ZXh0LXdoaXRlLzUwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93UGFzc3dvcmQgPyA8RXllT2ZmIHNpemU9ezE2fSAvPiA6IDxFeWUgc2l6ZT17MTZ9IC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIElucHV0IEtvbmZpcm1hc2kgUGFzc3dvcmQgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlLzkwIG1iLTEuNVwiPktvbmZpcm1hc2kgUGFzc3dvcmQgQmFydTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dDb25maXJtUGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maXJtUGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Q29uZmlybVBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlVsYW5naSBwYXNzd29yZCBiYXJ1XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMy41IHB5LTMgcHItMTAgcm91bmRlZC14bCBib3JkZXIgYmctYmxhY2svMzAgdGV4dC13aGl0ZSBwbGFjZWhvbGRlcjp0ZXh0LXdoaXRlLzQwIGZvbnQtbWVkaXVtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy1ibGFjay81MCBmb2N1czpib3JkZXItWyMyRUQ4QzNdIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLVsjMkVEOEMzXSB0ZXh0LXhzIHNtOnRleHQtc20gdHJhbnNpdGlvbi1hbGwgc2hhZG93LWlubmVyICR7Y29uZmlybVBhc3N3b3JkICYmIGNvbmZpcm1QYXNzd29yZCAhPT0gbmV3UGFzc3dvcmQgPyAnYm9yZGVyLXJlZC01MDAvNTAgYmctcmVkLTUwMC8xMCcgOiAnYm9yZGVyLXdoaXRlLzEwJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q29uZmlybVBhc3N3b3JkKCFzaG93Q29uZmlybVBhc3N3b3JkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0zIHRleHQtd2hpdGUvNTAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dDb25maXJtUGFzc3dvcmQgPyA8RXllT2ZmIHNpemU9ezE2fSAvPiA6IDxFeWUgc2l6ZT17MTZ9IC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zLjUgYmctWyMwRkE4OUVdIGhvdmVyOmJnLVsjMGQ5NjhkXSBhY3RpdmU6c2NhbGUtWzAuOThdIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQtZnVsbCBzaGFkb3ctWzBfNnB4XzIwcHhfcmdiYSgxNSwxNjgsMTU4LDAuNCldIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCB0ZXh0LXhzIHNtOnRleHQtc20gdHJhY2tpbmctd2lkZSBkaXNhYmxlZDpvcGFjaXR5LTYwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+TWVueWltcGFuLi4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SZXNldCBQYXNzd29yZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFN0ZXAoMSk7IHNldE90cCgnJyk7IHNldE5ld1Bhc3N3b3JkKCcnKTsgc2V0Q29uZmlybVBhc3N3b3JkKCcnKTsgc2V0RXJyb3IoJycpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzJFRDhDM10gaG92ZXI6dW5kZXJsaW5lIHB0LTEgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlZnJlc2hDdyBzaXplPXsxMn0gLz4gS2lyaW0gVWxhbmcgT1RQXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn0iXX0=