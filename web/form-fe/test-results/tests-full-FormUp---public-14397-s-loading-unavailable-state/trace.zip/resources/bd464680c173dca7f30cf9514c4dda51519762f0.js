//#region node_modules/gsap/Observer.js
function _defineProperties(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, descriptor.key, descriptor);
	}
}
function _createClass(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties(Constructor, staticProps);
	return Constructor;
}
/*!
* Observer 3.15.0
* https://gsap.com
*
* @license Copyright 2008-2026, GreenSock. All rights reserved.
* Subject to the terms at https://gsap.com/standard-license
* @author: Jack Doyle, jack@greensock.com
*/
var gsap$1;
var _coreInitted$1;
var _win$1;
var _doc$1;
var _docEl$1;
var _body$1;
var _isTouch;
var _pointerType;
var ScrollTrigger$1;
var _root$1;
var _normalizer$1;
var _eventTypes;
var _context$1;
var _getGSAP$1 = function _getGSAP() {
	return gsap$1 || typeof window !== "undefined" && (gsap$1 = window.gsap) && gsap$1.registerPlugin && gsap$1;
};
var _startup$1 = 1;
var _observers = [];
var _scrollers = [];
var _proxies = [];
var _getTime$1 = Date.now;
var _bridge = function _bridge(name, value) {
	return value;
};
var _integrate = function _integrate() {
	var core = ScrollTrigger$1.core, data = core.bridge || {}, scrollers = core._scrollers, proxies = core._proxies;
	scrollers.push.apply(scrollers, _scrollers);
	proxies.push.apply(proxies, _proxies);
	_scrollers = scrollers;
	_proxies = proxies;
	_bridge = function _bridge(name, value) {
		return data[name](value);
	};
};
var _getProxyProp = function _getProxyProp(element, property) {
	return ~_proxies.indexOf(element) && _proxies[_proxies.indexOf(element) + 1][property];
};
var _isViewport$1 = function _isViewport(el) {
	return !!~_root$1.indexOf(el);
};
var _addListener$1 = function _addListener(element, type, func, passive, capture) {
	return element.addEventListener(type, func, {
		passive: passive !== false,
		capture: !!capture
	});
};
var _removeListener$1 = function _removeListener(element, type, func, capture) {
	return element.removeEventListener(type, func, !!capture);
};
var _scrollLeft = "scrollLeft";
var _scrollTop = "scrollTop";
var _onScroll$1 = function _onScroll() {
	return _normalizer$1 && _normalizer$1.isPressed || _scrollers.cache++;
};
var _scrollCacheFunc = function _scrollCacheFunc(f, doNotCache) {
	var cachingFunc = function cachingFunc(value) {
		if (value || value === 0) {
			_startup$1 && (_win$1.history.scrollRestoration = "manual");
			var isNormalizing = _normalizer$1 && _normalizer$1.isPressed;
			value = cachingFunc.v = Math.round(value) || (_normalizer$1 && _normalizer$1.iOS ? 1 : 0);
			f(value);
			cachingFunc.cacheID = _scrollers.cache;
			isNormalizing && _bridge("ss", value);
		} else if (doNotCache || _scrollers.cache !== cachingFunc.cacheID || _bridge("ref")) {
			cachingFunc.cacheID = _scrollers.cache;
			cachingFunc.v = f();
		}
		return cachingFunc.v + cachingFunc.offset;
	};
	cachingFunc.offset = 0;
	return f && cachingFunc;
};
var _horizontal = {
	s: _scrollLeft,
	p: "left",
	p2: "Left",
	os: "right",
	os2: "Right",
	d: "width",
	d2: "Width",
	a: "x",
	sc: _scrollCacheFunc(function(value) {
		return arguments.length ? _win$1.scrollTo(value, _vertical.sc()) : _win$1.pageXOffset || _doc$1[_scrollLeft] || _docEl$1[_scrollLeft] || _body$1[_scrollLeft] || 0;
	})
};
var _vertical = {
	s: _scrollTop,
	p: "top",
	p2: "Top",
	os: "bottom",
	os2: "Bottom",
	d: "height",
	d2: "Height",
	a: "y",
	op: _horizontal,
	sc: _scrollCacheFunc(function(value) {
		return arguments.length ? _win$1.scrollTo(_horizontal.sc(), value) : _win$1.pageYOffset || _doc$1[_scrollTop] || _docEl$1[_scrollTop] || _body$1[_scrollTop] || 0;
	})
};
var _getTarget = function _getTarget(t, self) {
	return (self && self._ctx && self._ctx.selector || gsap$1.utils.toArray)(t)[0] || (typeof t === "string" && gsap$1.config().nullTargetWarn !== false ? console.warn("Element not found:", t) : null);
};
var _isWithin = function _isWithin(element, list) {
	var i = list.length;
	while (i--) if (list[i] === element || list[i].contains(element)) return true;
	return false;
};
var _getScrollFunc = function _getScrollFunc(element, _ref) {
	var s = _ref.s, sc = _ref.sc;
	_isViewport$1(element) && (element = _doc$1.scrollingElement || _docEl$1);
	var i = _scrollers.indexOf(element), offset = sc === _vertical.sc ? 1 : 2;
	!~i && (i = _scrollers.push(element) - 1);
	_scrollers[i + offset] || _addListener$1(element, "scroll", _onScroll$1);
	var prev = _scrollers[i + offset], func = prev || (_scrollers[i + offset] = _scrollCacheFunc(_getProxyProp(element, s), true) || (_isViewport$1(element) ? sc : _scrollCacheFunc(function(value) {
		return arguments.length ? element[s] = value : element[s];
	})));
	func.target = element;
	prev || (func.smooth = gsap$1.getProperty(element, "scrollBehavior") === "smooth");
	return func;
};
var _getVelocityProp = function _getVelocityProp(value, minTimeRefresh, useDelta) {
	var v1 = value, v2 = value, t1 = _getTime$1(), t2 = t1, min = minTimeRefresh || 50, dropToZeroTime = Math.max(500, min * 3), update = function update(value, force) {
		var t = _getTime$1();
		if (force || t - t1 > min) {
			v2 = v1;
			v1 = value;
			t2 = t1;
			t1 = t;
		} else if (useDelta) v1 += value;
		else v1 = v2 + (value - v2) / (t - t2) * (t1 - t2);
	};
	return {
		update,
		reset: function reset() {
			v2 = v1 = useDelta ? 0 : v1;
			t2 = t1 = 0;
		},
		getVelocity: function getVelocity(latestValue) {
			var tOld = t2, vOld = v2, t = _getTime$1();
			(latestValue || latestValue === 0) && latestValue !== v1 && update(latestValue);
			return t1 === t2 || t - t2 > dropToZeroTime ? 0 : (v1 + (useDelta ? vOld : -vOld)) / ((useDelta ? t : t1) - tOld) * 1e3;
		}
	};
};
var _getEvent = function _getEvent(e, preventDefault) {
	preventDefault && !e._gsapAllow && e.cancelable !== false && e.preventDefault();
	return e.changedTouches ? e.changedTouches[0] : e;
};
var _getAbsoluteMax = function _getAbsoluteMax(a) {
	var max = Math.max.apply(Math, a), min = Math.min.apply(Math, a);
	return Math.abs(max) >= Math.abs(min) ? max : min;
};
var _setScrollTrigger = function _setScrollTrigger() {
	ScrollTrigger$1 = gsap$1.core.globals().ScrollTrigger;
	ScrollTrigger$1 && ScrollTrigger$1.core && _integrate();
};
var _initCore = function _initCore(core) {
	gsap$1 = core || _getGSAP$1();
	if (!_coreInitted$1 && gsap$1 && typeof document !== "undefined" && document.body) {
		_win$1 = window;
		_doc$1 = document;
		_docEl$1 = _doc$1.documentElement;
		_body$1 = _doc$1.body;
		_root$1 = [
			_win$1,
			_doc$1,
			_docEl$1,
			_body$1
		];
		gsap$1.utils.clamp;
		_context$1 = gsap$1.core.context || function() {};
		_pointerType = "onpointerenter" in _body$1 ? "pointer" : "mouse";
		_isTouch = Observer.isTouch = _win$1.matchMedia && _win$1.matchMedia("(hover: none), (pointer: coarse)").matches ? 1 : "ontouchstart" in _win$1 || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0 ? 2 : 0;
		_eventTypes = Observer.eventTypes = ("ontouchstart" in _docEl$1 ? "touchstart,touchmove,touchcancel,touchend" : !("onpointerdown" in _docEl$1) ? "mousedown,mousemove,mouseup,mouseup" : "pointerdown,pointermove,pointercancel,pointerup").split(",");
		setTimeout(function() {
			return _startup$1 = 0;
		}, 500);
		_coreInitted$1 = 1;
	}
	ScrollTrigger$1 || _setScrollTrigger();
	return _coreInitted$1;
};
_horizontal.op = _vertical;
_scrollers.cache = 0;
var Observer = /*#__PURE__*/ function() {
	function Observer(vars) {
		this.init(vars);
	}
	var _proto = Observer.prototype;
	_proto.init = function init(vars) {
		_coreInitted$1 || _initCore(gsap$1) || console.warn("Please gsap.registerPlugin(Observer)");
		ScrollTrigger$1 || _setScrollTrigger();
		var tolerance = vars.tolerance, dragMinimum = vars.dragMinimum, type = vars.type, target = vars.target, lineHeight = vars.lineHeight, debounce = vars.debounce, preventDefault = vars.preventDefault, onStop = vars.onStop, onStopDelay = vars.onStopDelay, ignore = vars.ignore, wheelSpeed = vars.wheelSpeed, event = vars.event, onDragStart = vars.onDragStart, onDragEnd = vars.onDragEnd, onDrag = vars.onDrag, onPress = vars.onPress, onRelease = vars.onRelease, onRight = vars.onRight, onLeft = vars.onLeft, onUp = vars.onUp, onDown = vars.onDown, onChangeX = vars.onChangeX, onChangeY = vars.onChangeY, onChange = vars.onChange, onToggleX = vars.onToggleX, onToggleY = vars.onToggleY, onHover = vars.onHover, onHoverEnd = vars.onHoverEnd, onMove = vars.onMove, ignoreCheck = vars.ignoreCheck, isNormalizer = vars.isNormalizer, onGestureStart = vars.onGestureStart, onGestureEnd = vars.onGestureEnd, onWheel = vars.onWheel, onEnable = vars.onEnable, onDisable = vars.onDisable, onClick = vars.onClick, scrollSpeed = vars.scrollSpeed, capture = vars.capture, allowClicks = vars.allowClicks, lockAxis = vars.lockAxis, onLockAxis = vars.onLockAxis;
		this.target = target = _getTarget(target) || _docEl$1;
		this.vars = vars;
		ignore && (ignore = gsap$1.utils.toArray(ignore));
		tolerance = tolerance || 1e-9;
		dragMinimum = dragMinimum || 0;
		wheelSpeed = wheelSpeed || 1;
		scrollSpeed = scrollSpeed || 1;
		type = type || "wheel,touch,pointer";
		debounce = debounce !== false;
		lineHeight || (lineHeight = parseFloat(_win$1.getComputedStyle(_body$1).lineHeight) || 22);
		var id, onStopDelayedCall, dragged, moved, wheeled, locked, axis, self = this, prevDeltaX = 0, prevDeltaY = 0, passive = vars.passive || !preventDefault && vars.passive !== false, scrollFuncX = _getScrollFunc(target, _horizontal), scrollFuncY = _getScrollFunc(target, _vertical), scrollX = scrollFuncX(), scrollY = scrollFuncY(), limitToTouch = ~type.indexOf("touch") && !~type.indexOf("pointer") && _eventTypes[0] === "pointerdown", isViewport = _isViewport$1(target), ownerDoc = target.ownerDocument || _doc$1, deltaX = [
			0,
			0,
			0
		], deltaY = [
			0,
			0,
			0
		], onClickTime = 0, clickCapture = function clickCapture() {
			return onClickTime = _getTime$1();
		}, _ignoreCheck = function _ignoreCheck(e, isPointerOrTouch) {
			return (self.event = e) && ignore && _isWithin(e.target, ignore) || isPointerOrTouch && limitToTouch && e.pointerType !== "touch" || ignoreCheck && ignoreCheck(e, isPointerOrTouch);
		}, onStopFunc = function onStopFunc() {
			self._vx.reset();
			self._vy.reset();
			onStopDelayedCall.pause();
			onStop && onStop(self);
		}, update = function update() {
			var dx = self.deltaX = _getAbsoluteMax(deltaX), dy = self.deltaY = _getAbsoluteMax(deltaY), changedX = Math.abs(dx) >= tolerance, changedY = Math.abs(dy) >= tolerance;
			onChange && (changedX || changedY) && onChange(self, dx, dy, deltaX, deltaY);
			if (changedX) {
				onRight && self.deltaX > 0 && onRight(self);
				onLeft && self.deltaX < 0 && onLeft(self);
				onChangeX && onChangeX(self);
				onToggleX && self.deltaX < 0 !== prevDeltaX < 0 && onToggleX(self);
				prevDeltaX = self.deltaX;
				deltaX[0] = deltaX[1] = deltaX[2] = 0;
			}
			if (changedY) {
				onDown && self.deltaY > 0 && onDown(self);
				onUp && self.deltaY < 0 && onUp(self);
				onChangeY && onChangeY(self);
				onToggleY && self.deltaY < 0 !== prevDeltaY < 0 && onToggleY(self);
				prevDeltaY = self.deltaY;
				deltaY[0] = deltaY[1] = deltaY[2] = 0;
			}
			if (moved || dragged) {
				onMove && onMove(self);
				if (dragged) {
					onDragStart && dragged === 1 && onDragStart(self);
					onDrag && onDrag(self);
					dragged = 0;
				}
				moved = false;
			}
			locked && !(locked = false) && onLockAxis && onLockAxis(self);
			if (wheeled) {
				onWheel(self);
				wheeled = false;
			}
			id = 0;
		}, onDelta = function onDelta(x, y, index) {
			deltaX[index] += x;
			deltaY[index] += y;
			self._vx.update(x);
			self._vy.update(y);
			debounce ? id || (id = requestAnimationFrame(update)) : update();
		}, onTouchOrPointerDelta = function onTouchOrPointerDelta(x, y) {
			if (lockAxis && !axis) {
				self.axis = axis = Math.abs(x) > Math.abs(y) ? "x" : "y";
				locked = true;
			}
			if (axis !== "y") {
				deltaX[2] += x;
				self._vx.update(x, true);
			}
			if (axis !== "x") {
				deltaY[2] += y;
				self._vy.update(y, true);
			}
			debounce ? id || (id = requestAnimationFrame(update)) : update();
		}, _onDrag = function _onDrag(e) {
			if (_ignoreCheck(e, 1)) return;
			e = _getEvent(e, preventDefault);
			var x = e.clientX, y = e.clientY, dx = x - self.x, dy = y - self.y, isDragging = self.isDragging;
			self.x = x;
			self.y = y;
			if (isDragging || (dx || dy) && (Math.abs(self.startX - x) >= dragMinimum || Math.abs(self.startY - y) >= dragMinimum)) {
				dragged || (dragged = isDragging ? 2 : 1);
				isDragging || (self.isDragging = true);
				onTouchOrPointerDelta(dx, dy);
			}
		}, _onPress = self.onPress = function(e) {
			if (_ignoreCheck(e, 1) || e && e.button) return;
			self.axis = axis = null;
			onStopDelayedCall.pause();
			self.isPressed = true;
			e = _getEvent(e);
			prevDeltaX = prevDeltaY = 0;
			self.startX = self.x = e.clientX;
			self.startY = self.y = e.clientY;
			self._vx.reset();
			self._vy.reset();
			_addListener$1(isNormalizer ? target : ownerDoc, _eventTypes[1], _onDrag, passive, true);
			self.deltaX = self.deltaY = 0;
			onPress && onPress(self);
		}, _onRelease = self.onRelease = function(e) {
			if (_ignoreCheck(e, 1)) return;
			_removeListener$1(isNormalizer ? target : ownerDoc, _eventTypes[1], _onDrag, true);
			var isTrackingDrag = !isNaN(self.y - self.startY), wasDragging = self.isDragging, isDragNotClick = wasDragging && (Math.abs(self.x - self.startX) > 3 || Math.abs(self.y - self.startY) > 3), eventData = _getEvent(e);
			if (!isDragNotClick && isTrackingDrag) {
				self._vx.reset();
				self._vy.reset();
				if (preventDefault && allowClicks) gsap$1.delayedCall(.08, function() {
					if (_getTime$1() - onClickTime > 300 && !e.defaultPrevented) {
						if (e.target.click) e.target.click();
						else if (ownerDoc.createEvent) {
							var syntheticEvent = ownerDoc.createEvent("MouseEvents");
							syntheticEvent.initMouseEvent("click", true, true, _win$1, 1, eventData.screenX, eventData.screenY, eventData.clientX, eventData.clientY, false, false, false, false, 0, null);
							e.target.dispatchEvent(syntheticEvent);
						}
					}
				});
			}
			self.isDragging = self.isGesturing = self.isPressed = false;
			onStop && wasDragging && !isNormalizer && onStopDelayedCall.restart(true);
			dragged && update();
			onDragEnd && wasDragging && onDragEnd(self);
			onRelease && onRelease(self, isDragNotClick);
		}, _onGestureStart = function _onGestureStart(e) {
			return e.touches && e.touches.length > 1 && (self.isGesturing = true) && onGestureStart(e, self.isDragging);
		}, _onGestureEnd = function _onGestureEnd() {
			return (self.isGesturing = false) || onGestureEnd(self);
		}, onScroll = function onScroll(e) {
			if (_ignoreCheck(e)) return;
			var x = scrollFuncX(), y = scrollFuncY();
			onDelta((x - scrollX) * scrollSpeed, (y - scrollY) * scrollSpeed, 1);
			scrollX = x;
			scrollY = y;
			onStop && onStopDelayedCall.restart(true);
		}, _onWheel = function _onWheel(e) {
			if (_ignoreCheck(e)) return;
			e = _getEvent(e, preventDefault);
			onWheel && (wheeled = true);
			var multiplier = (e.deltaMode === 1 ? lineHeight : e.deltaMode === 2 ? _win$1.innerHeight : 1) * wheelSpeed;
			onDelta(e.deltaX * multiplier, e.deltaY * multiplier, 0);
			onStop && !isNormalizer && onStopDelayedCall.restart(true);
		}, _onMove = function _onMove(e) {
			if (_ignoreCheck(e)) return;
			var x = e.clientX, y = e.clientY, dx = x - self.x, dy = y - self.y;
			self.x = x;
			self.y = y;
			moved = true;
			onStop && onStopDelayedCall.restart(true);
			(dx || dy) && onTouchOrPointerDelta(dx, dy);
		}, _onHover = function _onHover(e) {
			self.event = e;
			onHover(self);
		}, _onHoverEnd = function _onHoverEnd(e) {
			self.event = e;
			onHoverEnd(self);
		}, _onClick = function _onClick(e) {
			return _ignoreCheck(e) || _getEvent(e, preventDefault) && onClick(self);
		};
		onStopDelayedCall = self._dc = gsap$1.delayedCall(onStopDelay || .25, onStopFunc).pause();
		self.deltaX = self.deltaY = 0;
		self._vx = _getVelocityProp(0, 50, true);
		self._vy = _getVelocityProp(0, 50, true);
		self.scrollX = scrollFuncX;
		self.scrollY = scrollFuncY;
		self.isDragging = self.isGesturing = self.isPressed = false;
		_context$1(this);
		self.enable = function(e) {
			if (!self.isEnabled) {
				_addListener$1(isViewport ? ownerDoc : target, "scroll", _onScroll$1);
				type.indexOf("scroll") >= 0 && _addListener$1(isViewport ? ownerDoc : target, "scroll", onScroll, passive, capture);
				type.indexOf("wheel") >= 0 && _addListener$1(target, "wheel", _onWheel, passive, capture);
				if (type.indexOf("touch") >= 0 && _isTouch || type.indexOf("pointer") >= 0) {
					_addListener$1(target, _eventTypes[0], _onPress, passive, capture);
					_addListener$1(ownerDoc, _eventTypes[2], _onRelease);
					_addListener$1(ownerDoc, _eventTypes[3], _onRelease);
					allowClicks && _addListener$1(target, "click", clickCapture, true, true);
					onClick && _addListener$1(target, "click", _onClick);
					onGestureStart && _addListener$1(ownerDoc, "gesturestart", _onGestureStart);
					onGestureEnd && _addListener$1(ownerDoc, "gestureend", _onGestureEnd);
					onHover && _addListener$1(target, _pointerType + "enter", _onHover);
					onHoverEnd && _addListener$1(target, _pointerType + "leave", _onHoverEnd);
					onMove && _addListener$1(target, _pointerType + "move", _onMove);
				}
				self.isEnabled = true;
				self.isDragging = self.isGesturing = self.isPressed = moved = dragged = false;
				self._vx.reset();
				self._vy.reset();
				scrollX = scrollFuncX();
				scrollY = scrollFuncY();
				e && e.type && _onPress(e);
				onEnable && onEnable(self);
			}
			return self;
		};
		self.disable = function() {
			if (self.isEnabled) {
				_observers.filter(function(o) {
					return o !== self && _isViewport$1(o.target);
				}).length || _removeListener$1(isViewport ? ownerDoc : target, "scroll", _onScroll$1);
				if (self.isPressed) {
					self._vx.reset();
					self._vy.reset();
					_removeListener$1(isNormalizer ? target : ownerDoc, _eventTypes[1], _onDrag, true);
				}
				_removeListener$1(isViewport ? ownerDoc : target, "scroll", onScroll, capture);
				_removeListener$1(target, "wheel", _onWheel, capture);
				_removeListener$1(target, _eventTypes[0], _onPress, capture);
				_removeListener$1(ownerDoc, _eventTypes[2], _onRelease);
				_removeListener$1(ownerDoc, _eventTypes[3], _onRelease);
				_removeListener$1(target, "click", clickCapture, true);
				_removeListener$1(target, "click", _onClick);
				_removeListener$1(ownerDoc, "gesturestart", _onGestureStart);
				_removeListener$1(ownerDoc, "gestureend", _onGestureEnd);
				_removeListener$1(target, _pointerType + "enter", _onHover);
				_removeListener$1(target, _pointerType + "leave", _onHoverEnd);
				_removeListener$1(target, _pointerType + "move", _onMove);
				self.isEnabled = self.isPressed = self.isDragging = false;
				onDisable && onDisable(self);
			}
		};
		self.kill = self.revert = function() {
			self.disable();
			var i = _observers.indexOf(self);
			i >= 0 && _observers.splice(i, 1);
			_normalizer$1 === self && (_normalizer$1 = 0);
		};
		_observers.push(self);
		isNormalizer && _isViewport$1(target) && (_normalizer$1 = self);
		self.enable(event);
	};
	_createClass(Observer, [{
		key: "velocityX",
		get: function get() {
			return this._vx.getVelocity();
		}
	}, {
		key: "velocityY",
		get: function get() {
			return this._vy.getVelocity();
		}
	}]);
	return Observer;
}();
Observer.version = "3.15.0";
Observer.create = function(vars) {
	return new Observer(vars);
};
Observer.register = _initCore;
Observer.getAll = function() {
	return _observers.slice();
};
Observer.getById = function(id) {
	return _observers.filter(function(o) {
		return o.vars.id === id;
	})[0];
};
_getGSAP$1() && gsap$1.registerPlugin(Observer);
//#endregion
//#region node_modules/gsap/ScrollTrigger.js
/*!
* ScrollTrigger 3.15.0
* https://gsap.com
*
* @license Copyright 2008-2026, GreenSock. All rights reserved.
* Subject to the terms at https://gsap.com/standard-license
* @author: Jack Doyle, jack@greensock.com
*/
var gsap;
var _coreInitted;
var _win;
var _doc;
var _docEl;
var _body;
var _root;
var _resizeDelay;
var _toArray;
var _clamp;
var _time2;
var _syncInterval;
var _refreshing;
var _pointerIsDown;
var _transformProp;
var _i;
var _prevWidth;
var _prevHeight;
var _autoRefresh;
var _sort;
var _suppressOverwrites;
var _ignoreResize;
var _normalizer;
var _ignoreMobileResize;
var _baseScreenHeight;
var _baseScreenWidth;
var _fixIOSBug;
var _context;
var _scrollRestoration;
var _div100vh;
var _100vh;
var _isReverted;
var _clampingMax;
var _limitCallbacks;
var _startup = 1;
var _getTime = Date.now;
var _time1 = _getTime();
var _lastScrollTime = 0;
var _enabled = 0;
var _parseClamp = function _parseClamp(value, type, self) {
	var clamp = _isString(value) && (value.substr(0, 6) === "clamp(" || value.indexOf("max") > -1);
	self["_" + type + "Clamp"] = clamp;
	return clamp ? value.substr(6, value.length - 7) : value;
};
var _keepClamp = function _keepClamp(value, clamp) {
	return clamp && (!_isString(value) || value.substr(0, 6) !== "clamp(") ? "clamp(" + value + ")" : value;
};
var _rafBugFix = function _rafBugFix() {
	return _enabled && requestAnimationFrame(_rafBugFix);
};
var _pointerDownHandler = function _pointerDownHandler() {
	return _pointerIsDown = 1;
};
var _pointerUpHandler = function _pointerUpHandler() {
	return _pointerIsDown = 0;
};
var _passThrough = function _passThrough(v) {
	return v;
};
var _round = function _round(value) {
	return Math.round(value * 1e5) / 1e5 || 0;
};
var _windowExists = function _windowExists() {
	return typeof window !== "undefined";
};
var _getGSAP = function _getGSAP() {
	return gsap || _windowExists() && (gsap = window.gsap) && gsap.registerPlugin && gsap;
};
var _isViewport = function _isViewport(e) {
	return !!~_root.indexOf(e);
};
var _getViewportDimension = function _getViewportDimension(dimensionProperty) {
	return (dimensionProperty === "Height" ? _100vh : _win["inner" + dimensionProperty]) || _docEl["client" + dimensionProperty] || _body["client" + dimensionProperty];
};
var _getBoundsFunc = function _getBoundsFunc(element) {
	return _getProxyProp(element, "getBoundingClientRect") || (_isViewport(element) ? function() {
		_winOffsets.width = _win.innerWidth;
		_winOffsets.height = _100vh;
		return _winOffsets;
	} : function() {
		return _getBounds(element);
	});
};
var _getSizeFunc = function _getSizeFunc(scroller, isViewport, _ref) {
	var d = _ref.d, d2 = _ref.d2, a = _ref.a;
	return (a = _getProxyProp(scroller, "getBoundingClientRect")) ? function() {
		return a()[d];
	} : function() {
		return (isViewport ? _getViewportDimension(d2) : scroller["client" + d2]) || 0;
	};
};
var _getOffsetsFunc = function _getOffsetsFunc(element, isViewport) {
	return !isViewport || ~_proxies.indexOf(element) ? _getBoundsFunc(element) : function() {
		return _winOffsets;
	};
};
var _maxScroll = function _maxScroll(element, _ref2) {
	var s = _ref2.s, d2 = _ref2.d2, d = _ref2.d, a = _ref2.a;
	return Math.max(0, (s = "scroll" + d2) && (a = _getProxyProp(element, s)) ? a() - _getBoundsFunc(element)()[d] : _isViewport(element) ? (_docEl[s] || _body[s]) - _getViewportDimension(d2) : element[s] - element["offset" + d2]);
};
var _iterateAutoRefresh = function _iterateAutoRefresh(func, events) {
	for (var i = 0; i < _autoRefresh.length; i += 3) (!events || ~events.indexOf(_autoRefresh[i + 1])) && func(_autoRefresh[i], _autoRefresh[i + 1], _autoRefresh[i + 2]);
};
var _isString = function _isString(value) {
	return typeof value === "string";
};
var _isFunction = function _isFunction(value) {
	return typeof value === "function";
};
var _isNumber = function _isNumber(value) {
	return typeof value === "number";
};
var _isObject = function _isObject(value) {
	return typeof value === "object";
};
var _endAnimation = function _endAnimation(animation, reversed, pause) {
	return animation && animation.progress(reversed ? 0 : 1) && pause && animation.pause();
};
var _callback = function _callback(self, func, extraParam) {
	if (self.enabled) {
		var result = self._ctx ? self._ctx.add(function() {
			return func(self, extraParam);
		}) : func(self, extraParam);
		result && result.totalTime && (self.callbackAnimation = result);
	}
};
var _abs = Math.abs;
var _left = "left";
var _top = "top";
var _right = "right";
var _bottom = "bottom";
var _width = "width";
var _height = "height";
var _Right = "Right";
var _Left = "Left";
var _Top = "Top";
var _Bottom = "Bottom";
var _padding = "padding";
var _margin = "margin";
var _Width = "Width";
var _Height = "Height";
var _px = "px";
var _getComputedStyle = function _getComputedStyle(element) {
	return _win.getComputedStyle(element.nodeType === Node.DOCUMENT_NODE ? element.scrollingElement : element);
};
var _makePositionable = function _makePositionable(element) {
	var position = _getComputedStyle(element).position;
	element.style.position = position === "absolute" || position === "fixed" ? position : "relative";
};
var _setDefaults = function _setDefaults(obj, defaults) {
	for (var p in defaults) p in obj || (obj[p] = defaults[p]);
	return obj;
};
var _getBounds = function _getBounds(element, withoutTransforms) {
	var tween = withoutTransforms && _getComputedStyle(element)[_transformProp] !== "matrix(1, 0, 0, 1, 0, 0)" && gsap.to(element, {
		x: 0,
		y: 0,
		xPercent: 0,
		yPercent: 0,
		rotation: 0,
		rotationX: 0,
		rotationY: 0,
		scale: 1,
		skewX: 0,
		skewY: 0
	}).progress(1), bounds = element.getBoundingClientRect ? element.getBoundingClientRect() : element.scrollingElement.getBoundingClientRect();
	tween && tween.progress(0).kill();
	return bounds;
};
var _getSize = function _getSize(element, _ref3) {
	var d2 = _ref3.d2;
	return element["offset" + d2] || element["client" + d2] || 0;
};
var _getLabelRatioArray = function _getLabelRatioArray(timeline) {
	var a = [], labels = timeline.labels, duration = timeline.duration(), p;
	for (p in labels) a.push(labels[p] / duration);
	return a;
};
var _getClosestLabel = function _getClosestLabel(animation) {
	return function(value) {
		return gsap.utils.snap(_getLabelRatioArray(animation), value);
	};
};
var _snapDirectional = function _snapDirectional(snapIncrementOrArray) {
	var snap = gsap.utils.snap(snapIncrementOrArray), a = Array.isArray(snapIncrementOrArray) && snapIncrementOrArray.slice(0).sort(function(a, b) {
		return a - b;
	});
	return a ? function(value, direction, threshold) {
		if (threshold === void 0) threshold = .001;
		var i;
		if (!direction) return snap(value);
		if (direction > 0) {
			value -= threshold;
			for (i = 0; i < a.length; i++) if (a[i] >= value) return a[i];
			return a[i - 1];
		} else {
			i = a.length;
			value += threshold;
			while (i--) if (a[i] <= value) return a[i];
		}
		return a[0];
	} : function(value, direction, threshold) {
		if (threshold === void 0) threshold = .001;
		var snapped = snap(value);
		return !direction || Math.abs(snapped - value) < threshold || snapped - value < 0 === direction < 0 ? snapped : snap(direction < 0 ? value - snapIncrementOrArray : value + snapIncrementOrArray);
	};
};
var _getLabelAtDirection = function _getLabelAtDirection(timeline) {
	return function(value, st) {
		return _snapDirectional(_getLabelRatioArray(timeline))(value, st.direction);
	};
};
var _multiListener = function _multiListener(func, element, types, callback) {
	return types.split(",").forEach(function(type) {
		return func(element, type, callback);
	});
};
var _addListener = function _addListener(element, type, func, nonPassive, capture) {
	return element.addEventListener(type, func, {
		passive: !nonPassive,
		capture: !!capture
	});
};
var _removeListener = function _removeListener(element, type, func, capture) {
	return element.removeEventListener(type, func, !!capture);
};
var _wheelListener = function _wheelListener(func, el, scrollFunc) {
	scrollFunc = scrollFunc && scrollFunc.wheelHandler;
	if (scrollFunc) {
		func(el, "wheel", scrollFunc);
		func(el, "touchmove", scrollFunc);
	}
};
var _markerDefaults = {
	startColor: "green",
	endColor: "red",
	indent: 0,
	fontSize: "16px",
	fontWeight: "normal"
};
var _defaults = {
	toggleActions: "play",
	anticipatePin: 0
};
var _keywords = {
	top: 0,
	left: 0,
	center: .5,
	bottom: 1,
	right: 1
};
var _offsetToPx = function _offsetToPx(value, size) {
	if (_isString(value)) {
		var eqIndex = value.indexOf("="), relative = ~eqIndex ? +(value.charAt(eqIndex - 1) + 1) * parseFloat(value.substr(eqIndex + 1)) : 0;
		if (~eqIndex) {
			value.indexOf("%") > eqIndex && (relative *= size / 100);
			value = value.substr(0, eqIndex - 1);
		}
		value = relative + (value in _keywords ? _keywords[value] * size : ~value.indexOf("%") ? parseFloat(value) * size / 100 : parseFloat(value) || 0);
	}
	return value;
};
var _createMarker = function _createMarker(type, name, container, direction, _ref4, offset, matchWidthEl, containerAnimation) {
	var startColor = _ref4.startColor, endColor = _ref4.endColor, fontSize = _ref4.fontSize, indent = _ref4.indent, fontWeight = _ref4.fontWeight;
	var e = _doc.createElement("div"), useFixedPosition = _isViewport(container) || _getProxyProp(container, "pinType") === "fixed", isScroller = type.indexOf("scroller") !== -1, parent = useFixedPosition ? _body : container.tagName === "IFRAME" ? container.contentDocument.body : container, isStart = type.indexOf("start") !== -1, color = isStart ? startColor : endColor, css = "border-color:" + color + ";font-size:" + fontSize + ";color:" + color + ";font-weight:" + fontWeight + ";pointer-events:none;white-space:nowrap;font-family:sans-serif,Arial;z-index:1000;padding:4px 8px;border-width:0;border-style:solid;";
	css += "position:" + ((isScroller || containerAnimation) && useFixedPosition ? "fixed;" : "absolute;");
	(isScroller || containerAnimation || !useFixedPosition) && (css += (direction === _vertical ? _right : _bottom) + ":" + (offset + parseFloat(indent)) + "px;");
	matchWidthEl && (css += "box-sizing:border-box;text-align:left;width:" + matchWidthEl.offsetWidth + "px;");
	e._isStart = isStart;
	e.setAttribute("class", "gsap-marker-" + type + (name ? " marker-" + name : ""));
	e.style.cssText = css;
	e.innerText = name || name === 0 ? type + "-" + name : type;
	parent.children[0] ? parent.insertBefore(e, parent.children[0]) : parent.appendChild(e);
	e._offset = e["offset" + direction.op.d2];
	_positionMarker(e, 0, direction, isStart);
	return e;
};
var _positionMarker = function _positionMarker(marker, start, direction, flipped) {
	var vars = { display: "block" }, side = direction[flipped ? "os2" : "p2"], oppositeSide = direction[flipped ? "p2" : "os2"];
	marker._isFlipped = flipped;
	vars[direction.a + "Percent"] = flipped ? -100 : 0;
	vars[direction.a] = flipped ? "1px" : 0;
	vars["border" + side + _Width] = 1;
	vars["border" + oppositeSide + _Width] = 0;
	vars[direction.p] = start + "px";
	gsap.set(marker, vars);
};
var _triggers = [];
var _ids = {};
var _rafID;
var _sync = function _sync() {
	return _getTime() - _lastScrollTime > 34 && (_rafID || (_rafID = requestAnimationFrame(_updateAll)));
};
var _onScroll = function _onScroll() {
	if (!_normalizer || !_normalizer.isPressed || _normalizer.startX > _body.clientWidth) {
		_scrollers.cache++;
		if (_normalizer) _rafID || (_rafID = requestAnimationFrame(_updateAll));
		else _updateAll();
		_lastScrollTime || _dispatch("scrollStart");
		_lastScrollTime = _getTime();
	}
};
var _setBaseDimensions = function _setBaseDimensions() {
	_baseScreenWidth = _win.innerWidth;
	_baseScreenHeight = _win.innerHeight;
};
var _onResize = function _onResize(force) {
	_scrollers.cache++;
	(force === true || !_refreshing && !_ignoreResize && !_doc.fullscreenElement && !_doc.webkitFullscreenElement && (!_ignoreMobileResize || _baseScreenWidth !== _win.innerWidth || Math.abs(_win.innerHeight - _baseScreenHeight) > _win.innerHeight * .25)) && _resizeDelay.restart(true);
};
var _listeners = {};
var _emptyArray = [];
var _softRefresh = function _softRefresh() {
	return _removeListener(ScrollTrigger, "scrollEnd", _softRefresh) || _refreshAll(true);
};
var _dispatch = function _dispatch(type) {
	return _listeners[type] && _listeners[type].map(function(f) {
		return f();
	}) || _emptyArray;
};
var _savedStyles = [];
var _revertRecorded = function _revertRecorded(media) {
	for (var i = 0; i < _savedStyles.length; i += 5) if (!media || _savedStyles[i + 4] && _savedStyles[i + 4].query === media) {
		_savedStyles[i].style.cssText = _savedStyles[i + 1];
		_savedStyles[i].getBBox && _savedStyles[i].setAttribute("transform", _savedStyles[i + 2] || "");
		_savedStyles[i + 3].uncache = 1;
	}
};
var _recordScrollPositions = function _recordScrollPositions() {
	return _scrollers.forEach(function(obj) {
		return _isFunction(obj) && ++obj.cacheID && (obj.rec = obj());
	});
};
var _revertAll = function _revertAll(kill, media) {
	var trigger;
	for (_i = 0; _i < _triggers.length; _i++) {
		trigger = _triggers[_i];
		if (trigger && (!media || trigger._ctx === media)) if (kill) trigger.kill(1);
		else trigger.revert(true, true);
	}
	_isReverted = true;
	media && _revertRecorded(media);
	media || _dispatch("revert");
};
var _clearScrollMemory = function _clearScrollMemory(scrollRestoration, force) {
	_scrollers.cache++;
	(force || !_refreshingAll) && _scrollers.forEach(function(obj) {
		return _isFunction(obj) && obj.cacheID++ && (obj.rec = 0);
	});
	_isString(scrollRestoration) && (_win.history.scrollRestoration = _scrollRestoration = scrollRestoration);
};
var _refreshingAll;
var _refreshID = 0;
var _queueRefreshID;
var _queueRefreshAll = function _queueRefreshAll() {
	if (_queueRefreshID !== _refreshID) {
		var id = _queueRefreshID = _refreshID;
		requestAnimationFrame(function() {
			return id === _refreshID && _refreshAll(true);
		});
	}
};
var _refresh100vh = function _refresh100vh() {
	_body.appendChild(_div100vh);
	_100vh = !_normalizer && _div100vh.offsetHeight || _win.innerHeight;
	_body.removeChild(_div100vh);
};
var _hideAllMarkers = function _hideAllMarkers(hide) {
	return _toArray(".gsap-marker-start, .gsap-marker-end, .gsap-marker-scroller-start, .gsap-marker-scroller-end").forEach(function(el) {
		return el.style.display = hide ? "none" : "block";
	});
};
var _refreshAll = function _refreshAll(force, skipRevert) {
	_docEl = _doc.documentElement;
	_body = _doc.body;
	_root = [
		_win,
		_doc,
		_docEl,
		_body
	];
	if (_lastScrollTime && !force && !_isReverted) {
		_addListener(ScrollTrigger, "scrollEnd", _softRefresh);
		return;
	}
	_refresh100vh();
	_refreshingAll = ScrollTrigger.isRefreshing = true;
	_isReverted || _recordScrollPositions();
	var refreshInits = _dispatch("refreshInit");
	_sort && ScrollTrigger.sort();
	skipRevert || _revertAll();
	_scrollers.forEach(function(obj) {
		if (_isFunction(obj)) {
			obj.smooth && (obj.target.style.scrollBehavior = "auto");
			obj(0);
		}
	});
	_triggers.slice(0).forEach(function(t) {
		return t.refresh();
	});
	_isReverted = false;
	_triggers.forEach(function(t) {
		if (t._subPinOffset && t.pin) {
			var prop = t.vars.horizontal ? "offsetWidth" : "offsetHeight", original = t.pin[prop];
			t.revert(true, 1);
			t.adjustPinSpacing(t.pin[prop] - original);
			t.refresh();
		}
	});
	_clampingMax = 1;
	_hideAllMarkers(true);
	_triggers.forEach(function(t) {
		var max = _maxScroll(t.scroller, t._dir), endClamp = t.vars.end === "max" || t._endClamp && t.end > max, startClamp = t._startClamp && t.start >= max;
		(endClamp || startClamp) && t.setPositions(startClamp ? max - 1 : t.start, endClamp ? Math.max(startClamp ? max : t.start + 1, max) : t.end, true);
	});
	_hideAllMarkers(false);
	_clampingMax = 0;
	refreshInits.forEach(function(result) {
		return result && result.render && result.render(-1);
	});
	_scrollers.forEach(function(obj) {
		if (_isFunction(obj)) {
			obj.smooth && requestAnimationFrame(function() {
				return obj.target.style.scrollBehavior = "smooth";
			});
			obj.rec && obj(obj.rec);
		}
	});
	_clearScrollMemory(_scrollRestoration, 1);
	_resizeDelay.pause();
	_refreshID++;
	_refreshingAll = 2;
	_updateAll(2);
	_triggers.forEach(function(t) {
		return _isFunction(t.vars.onRefresh) && t.vars.onRefresh(t);
	});
	_refreshingAll = ScrollTrigger.isRefreshing = false;
	_dispatch("refresh");
};
var _lastScroll = 0;
var _direction = 1;
var _primary;
var _updateAll = function _updateAll(force) {
	if (force === 2 || !_refreshingAll && !_isReverted) {
		ScrollTrigger.isUpdating = true;
		_primary && _primary.update(0);
		var l = _triggers.length, time = _getTime(), recordVelocity = time - _time1 >= 50, scroll = l && _triggers[0].scroll();
		_direction = _lastScroll > scroll ? -1 : 1;
		_refreshingAll || (_lastScroll = scroll);
		if (recordVelocity) {
			if (_lastScrollTime && !_pointerIsDown && time - _lastScrollTime > 200) {
				_lastScrollTime = 0;
				_dispatch("scrollEnd");
			}
			_time2 = _time1;
			_time1 = time;
		}
		if (_direction < 0) {
			_i = l;
			while (_i-- > 0) _triggers[_i] && _triggers[_i].update(0, recordVelocity);
			_direction = 1;
		} else for (_i = 0; _i < l; _i++) _triggers[_i] && _triggers[_i].update(0, recordVelocity);
		ScrollTrigger.isUpdating = false;
	}
	_rafID = 0;
};
var _propNamesToCopy = [
	_left,
	_top,
	_bottom,
	_right,
	_margin + _Bottom,
	_margin + _Right,
	_margin + _Top,
	_margin + _Left,
	"display",
	"flexShrink",
	"float",
	"zIndex",
	"gridColumnStart",
	"gridColumnEnd",
	"gridRowStart",
	"gridRowEnd",
	"gridArea",
	"justifySelf",
	"alignSelf",
	"placeSelf",
	"order"
];
var _stateProps = _propNamesToCopy.concat([
	_width,
	_height,
	"boxSizing",
	"max" + _Width,
	"max" + _Height,
	"position",
	_margin,
	_padding,
	_padding + _Top,
	_padding + _Right,
	_padding + _Bottom,
	_padding + _Left
]);
var _swapPinOut = function _swapPinOut(pin, spacer, state) {
	_setState(state);
	var cache = pin._gsap;
	if (cache.spacerIsNative) _setState(cache.spacerState);
	else if (pin._gsap.swappedIn) {
		var parent = spacer.parentNode;
		if (parent) {
			parent.insertBefore(pin, spacer);
			parent.removeChild(spacer);
		}
	}
	pin._gsap.swappedIn = false;
};
var _swapPinIn = function _swapPinIn(pin, spacer, cs, spacerState) {
	if (!pin._gsap.swappedIn) {
		var i = _propNamesToCopy.length, spacerStyle = spacer.style, pinStyle = pin.style, p;
		while (i--) {
			p = _propNamesToCopy[i];
			spacerStyle[p] = cs[p];
		}
		spacerStyle.position = cs.position === "absolute" ? "absolute" : "relative";
		cs.display === "inline" && (spacerStyle.display = "inline-block");
		pinStyle[_bottom] = pinStyle[_right] = "auto";
		spacerStyle.flexBasis = cs.flexBasis || "auto";
		spacerStyle.overflow = "visible";
		spacerStyle.boxSizing = "border-box";
		spacerStyle[_width] = _getSize(pin, _horizontal) + _px;
		spacerStyle[_height] = _getSize(pin, _vertical) + _px;
		spacerStyle[_padding] = pinStyle[_margin] = pinStyle[_top] = pinStyle[_left] = "0";
		_setState(spacerState);
		pinStyle[_width] = pinStyle["max" + _Width] = cs[_width];
		pinStyle[_height] = pinStyle["max" + _Height] = cs[_height];
		pinStyle[_padding] = cs[_padding];
		if (pin.parentNode !== spacer) {
			pin.parentNode.insertBefore(spacer, pin);
			spacer.appendChild(pin);
		}
		pin._gsap.swappedIn = true;
	}
};
var _capsExp = /([A-Z])/g;
var _setState = function _setState(state) {
	if (state) {
		var style = state.t.style, l = state.length, i = 0, p, value;
		(state.t._gsap || gsap.core.getCache(state.t)).uncache = 1;
		for (; i < l; i += 2) {
			value = state[i + 1];
			p = state[i];
			if (value) style[p] = value;
			else if (style[p]) style.removeProperty(p.replace(_capsExp, "-$1").toLowerCase());
		}
	}
};
var _getState = function _getState(element) {
	var l = _stateProps.length, style = element.style, state = [], i = 0;
	for (; i < l; i++) state.push(_stateProps[i], style[_stateProps[i]]);
	state.t = element;
	return state;
};
var _copyState = function _copyState(state, override, omitOffsets) {
	var result = [], l = state.length, i = omitOffsets ? 8 : 0, p;
	for (; i < l; i += 2) {
		p = state[i];
		result.push(p, p in override ? override[p] : state[i + 1]);
	}
	result.t = state.t;
	return result;
};
var _winOffsets = {
	left: 0,
	top: 0
};
var _parsePosition = function _parsePosition(value, trigger, scrollerSize, direction, scroll, marker, markerScroller, self, scrollerBounds, borderWidth, useFixedPosition, scrollerMax, containerAnimation, clampZeroProp) {
	_isFunction(value) && (value = value(self));
	if (_isString(value) && value.substr(0, 3) === "max") value = scrollerMax + (value.charAt(4) === "=" ? _offsetToPx("0" + value.substr(3), scrollerSize) : 0);
	var time = containerAnimation ? containerAnimation.time() : 0, p1, p2, element;
	containerAnimation && containerAnimation.seek(0);
	isNaN(value) || (value = +value);
	if (!_isNumber(value)) {
		_isFunction(trigger) && (trigger = trigger(self));
		var offsets = (value || "0").split(" "), bounds, localOffset, globalOffset, display;
		element = _getTarget(trigger, self) || _body;
		bounds = _getBounds(element) || {};
		if ((!bounds || !bounds.left && !bounds.top) && _getComputedStyle(element).display === "none") {
			display = element.style.display;
			element.style.display = "block";
			bounds = _getBounds(element);
			display ? element.style.display = display : element.style.removeProperty("display");
		}
		localOffset = _offsetToPx(offsets[0], bounds[direction.d]);
		globalOffset = _offsetToPx(offsets[1] || "0", scrollerSize);
		value = bounds[direction.p] - scrollerBounds[direction.p] - borderWidth + localOffset + scroll - globalOffset;
		markerScroller && _positionMarker(markerScroller, globalOffset, direction, scrollerSize - globalOffset < 20 || markerScroller._isStart && globalOffset > 20);
		scrollerSize -= scrollerSize - globalOffset;
	} else {
		containerAnimation && (value = gsap.utils.mapRange(containerAnimation.scrollTrigger.start, containerAnimation.scrollTrigger.end, 0, scrollerMax, value));
		markerScroller && _positionMarker(markerScroller, scrollerSize, direction, true);
	}
	if (clampZeroProp) {
		self[clampZeroProp] = value || -.001;
		value < 0 && (value = 0);
	}
	if (marker) {
		var position = value + scrollerSize, isStart = marker._isStart;
		p1 = "scroll" + direction.d2;
		_positionMarker(marker, position, direction, isStart && position > 20 || !isStart && (useFixedPosition ? Math.max(_body[p1], _docEl[p1]) : marker.parentNode[p1]) <= position + 1);
		if (useFixedPosition) {
			scrollerBounds = _getBounds(markerScroller);
			useFixedPosition && (marker.style[direction.op.p] = scrollerBounds[direction.op.p] - direction.op.m - marker._offset + _px);
		}
	}
	if (containerAnimation && element) {
		p1 = _getBounds(element);
		containerAnimation.seek(scrollerMax);
		p2 = _getBounds(element);
		containerAnimation._caScrollDist = p1[direction.p] - p2[direction.p];
		value = value / containerAnimation._caScrollDist * scrollerMax;
	}
	containerAnimation && containerAnimation.seek(time);
	return containerAnimation ? value : Math.round(value);
};
var _prefixExp = /(webkit|moz|length|cssText|inset)/i;
var _reparent = function _reparent(element, parent, top, left) {
	if (element.parentNode !== parent) {
		var style = element.style, p, cs;
		if (parent === _body) {
			element._stOrig = style.cssText;
			cs = _getComputedStyle(element);
			for (p in cs) if (!+p && !_prefixExp.test(p) && cs[p] && typeof style[p] === "string" && p !== "0") style[p] = cs[p];
			style.top = top;
			style.left = left;
		} else style.cssText = element._stOrig;
		gsap.core.getCache(element).uncache = 1;
		parent.appendChild(element);
	}
};
var _interruptionTracker = function _interruptionTracker(getValueFunc, initialValue, onInterrupt) {
	var last1 = initialValue, last2 = last1;
	return function(value) {
		var current = Math.round(getValueFunc());
		if (current !== last1 && current !== last2 && Math.abs(current - last1) > 3 && Math.abs(current - last2) > 3) {
			value = current;
			onInterrupt && onInterrupt();
		}
		last2 = last1;
		last1 = Math.round(value);
		return last1;
	};
};
var _shiftMarker = function _shiftMarker(marker, direction, value) {
	var vars = {};
	vars[direction.p] = "+=" + value;
	gsap.set(marker, vars);
};
var _getTweenCreator = function _getTweenCreator(scroller, direction) {
	var getScroll = _getScrollFunc(scroller, direction), prop = "_scroll" + direction.p2, getTween = function getTween(scrollTo, vars, initialValue, change1, change2) {
		var tween = getTween.tween, onComplete = vars.onComplete, modifiers = {};
		initialValue = initialValue || getScroll();
		var checkForInterruption = _interruptionTracker(getScroll, initialValue, function() {
			tween.kill();
			getTween.tween = 0;
		});
		change2 = change1 && change2 || 0;
		change1 = change1 || scrollTo - initialValue;
		tween && tween.kill();
		vars[prop] = scrollTo;
		vars.inherit = false;
		vars.modifiers = modifiers;
		modifiers[prop] = function() {
			return checkForInterruption(initialValue + change1 * tween.ratio + change2 * tween.ratio * tween.ratio);
		};
		vars.onUpdate = function() {
			_scrollers.cache++;
			getTween.tween && _updateAll();
		};
		vars.onComplete = function() {
			getTween.tween = 0;
			onComplete && onComplete.call(tween);
		};
		tween = getTween.tween = gsap.to(scroller, vars);
		return tween;
	};
	scroller[prop] = getScroll;
	getScroll.wheelHandler = function() {
		return getTween.tween && getTween.tween.kill() && (getTween.tween = 0);
	};
	_addListener(scroller, "wheel", getScroll.wheelHandler);
	ScrollTrigger.isTouch && _addListener(scroller, "touchmove", getScroll.wheelHandler);
	return getTween;
};
var ScrollTrigger = /*#__PURE__*/ function() {
	function ScrollTrigger(vars, animation) {
		_coreInitted || ScrollTrigger.register(gsap) || console.warn("Please gsap.registerPlugin(ScrollTrigger)");
		_context(this);
		this.init(vars, animation);
	}
	var _proto = ScrollTrigger.prototype;
	_proto.init = function init(vars, animation) {
		this.progress = this.start = 0;
		this.vars && this.kill(true, true);
		if (!_enabled) {
			this.update = this.refresh = this.kill = _passThrough;
			return;
		}
		vars = _setDefaults(_isString(vars) || _isNumber(vars) || vars.nodeType ? { trigger: vars } : vars, _defaults);
		var _vars = vars, onUpdate = _vars.onUpdate, toggleClass = _vars.toggleClass, id = _vars.id, onToggle = _vars.onToggle, onRefresh = _vars.onRefresh, scrub = _vars.scrub, trigger = _vars.trigger, pin = _vars.pin, pinSpacing = _vars.pinSpacing, invalidateOnRefresh = _vars.invalidateOnRefresh, anticipatePin = _vars.anticipatePin, onScrubComplete = _vars.onScrubComplete, onSnapComplete = _vars.onSnapComplete, once = _vars.once, snap = _vars.snap, pinReparent = _vars.pinReparent, pinSpacer = _vars.pinSpacer, containerAnimation = _vars.containerAnimation, fastScrollEnd = _vars.fastScrollEnd, preventOverlaps = _vars.preventOverlaps, direction = vars.horizontal || vars.containerAnimation && vars.horizontal !== false ? _horizontal : _vertical, isToggle = !scrub && scrub !== 0, scroller = _getTarget(vars.scroller || _win), scrollerCache = gsap.core.getCache(scroller), isViewport = _isViewport(scroller), useFixedPosition = ("pinType" in vars ? vars.pinType : _getProxyProp(scroller, "pinType") || isViewport && "fixed") === "fixed", callbacks = [
			vars.onEnter,
			vars.onLeave,
			vars.onEnterBack,
			vars.onLeaveBack
		], toggleActions = isToggle && vars.toggleActions.split(" "), markers = "markers" in vars ? vars.markers : _defaults.markers, borderWidth = isViewport ? 0 : parseFloat(_getComputedStyle(scroller)["border" + direction.p2 + _Width]) || 0, self = this, onRefreshInit = vars.onRefreshInit && function() {
			return vars.onRefreshInit(self);
		}, getScrollerSize = _getSizeFunc(scroller, isViewport, direction), getScrollerOffsets = _getOffsetsFunc(scroller, isViewport), lastSnap = 0, lastRefresh = 0, prevProgress = 0, scrollFunc = _getScrollFunc(scroller, direction), tweenTo, pinCache, snapFunc, scroll1, scroll2, start, end, markerStart, markerEnd, markerStartTrigger, markerEndTrigger, markerVars, executingOnRefresh, change, pinOriginalState, pinActiveState, pinState, spacer, offset, pinGetter, pinSetter, pinStart, pinChange, spacingStart, spacerState, markerStartSetter, pinMoves, markerEndSetter, cs, snap1, snap2, scrubTween, scrubSmooth, snapDurClamp, snapDelayedCall, prevScroll, prevAnimProgress, caMarkerSetter, customRevertReturn;
		self._startClamp = self._endClamp = false;
		self._dir = direction;
		anticipatePin *= 45;
		self.scroller = scroller;
		self.scroll = containerAnimation ? containerAnimation.time.bind(containerAnimation) : scrollFunc;
		scroll1 = scrollFunc();
		self.vars = vars;
		animation = animation || vars.animation;
		if ("refreshPriority" in vars) {
			_sort = 1;
			vars.refreshPriority === -9999 && (_primary = self);
		}
		scrollerCache.tweenScroll = scrollerCache.tweenScroll || {
			top: _getTweenCreator(scroller, _vertical),
			left: _getTweenCreator(scroller, _horizontal)
		};
		self.tweenTo = tweenTo = scrollerCache.tweenScroll[direction.p];
		self.scrubDuration = function(value) {
			scrubSmooth = _isNumber(value) && value;
			if (!scrubSmooth) {
				scrubTween && scrubTween.progress(1).kill();
				scrubTween = 0;
			} else scrubTween ? scrubTween.duration(value) : scrubTween = gsap.to(animation, {
				ease: "expo",
				totalProgress: "+=0",
				inherit: false,
				duration: scrubSmooth,
				paused: true,
				onComplete: function onComplete() {
					return onScrubComplete && onScrubComplete(self);
				}
			});
		};
		if (animation) {
			animation.vars.lazy = false;
			animation._initted && !self.isReverted || animation.vars.immediateRender !== false && vars.immediateRender !== false && animation.duration() && animation.render(0, true, true);
			self.animation = animation.pause();
			animation.scrollTrigger = self;
			self.scrubDuration(scrub);
			snap1 = 0;
			id || (id = animation.vars.id);
		}
		if (snap) {
			if (!_isObject(snap) || snap.push) snap = { snapTo: snap };
			"scrollBehavior" in _body.style && gsap.set(isViewport ? [_body, _docEl] : scroller, { scrollBehavior: "auto" });
			_scrollers.forEach(function(o) {
				return _isFunction(o) && o.target === (isViewport ? _doc.scrollingElement || _docEl : scroller) && (o.smooth = false);
			});
			snapFunc = _isFunction(snap.snapTo) ? snap.snapTo : snap.snapTo === "labels" ? _getClosestLabel(animation) : snap.snapTo === "labelsDirectional" ? _getLabelAtDirection(animation) : snap.directional !== false ? function(value, st) {
				return _snapDirectional(snap.snapTo)(value, _getTime() - lastRefresh < 500 ? 0 : st.direction);
			} : gsap.utils.snap(snap.snapTo);
			snapDurClamp = snap.duration || {
				min: .1,
				max: 2
			};
			snapDurClamp = _isObject(snapDurClamp) ? _clamp(snapDurClamp.min, snapDurClamp.max) : _clamp(snapDurClamp, snapDurClamp);
			snapDelayedCall = gsap.delayedCall(snap.delay || scrubSmooth / 2 || .1, function() {
				var scroll = scrollFunc(), refreshedRecently = _getTime() - lastRefresh < 500, tween = tweenTo.tween;
				if ((refreshedRecently || Math.abs(self.getVelocity()) < 10) && !tween && !_pointerIsDown && lastSnap !== scroll) {
					var progress = (scroll - start) / change, totalProgress = animation && !isToggle ? animation.totalProgress() : progress, velocity = refreshedRecently ? 0 : (totalProgress - snap2) / (_getTime() - _time2) * 1e3 || 0, change1 = gsap.utils.clamp(-progress, 1 - progress, _abs(velocity / 2) * velocity / .185), naturalEnd = progress + (snap.inertia === false ? 0 : change1), endValue, endScroll, _snap = snap, onStart = _snap.onStart, _onInterrupt = _snap.onInterrupt, _onComplete = _snap.onComplete;
					endValue = snapFunc(naturalEnd, self);
					_isNumber(endValue) || (endValue = naturalEnd);
					endScroll = Math.max(0, Math.round(start + endValue * change));
					if (scroll <= end && scroll >= start && endScroll !== scroll) {
						if (tween && !tween._initted && tween.data <= _abs(endScroll - scroll)) return;
						if (snap.inertia === false) change1 = endValue - progress;
						tweenTo(endScroll, {
							duration: snapDurClamp(_abs(Math.max(_abs(naturalEnd - totalProgress), _abs(endValue - totalProgress)) * .185 / velocity / .05 || 0)),
							ease: snap.ease || "power3",
							data: _abs(endScroll - scroll),
							onInterrupt: function onInterrupt() {
								return snapDelayedCall.restart(true) && _onInterrupt && _callback(self, _onInterrupt);
							},
							onComplete: function onComplete() {
								self.update();
								lastSnap = scrollFunc();
								if (animation && !isToggle) scrubTween ? scrubTween.resetTo("totalProgress", endValue, animation._tTime / animation._tDur) : animation.progress(endValue);
								snap1 = snap2 = animation && !isToggle ? animation.totalProgress() : self.progress;
								onSnapComplete && onSnapComplete(self);
								_onComplete && _callback(self, _onComplete);
							}
						}, scroll, change1 * change, endScroll - scroll - change1 * change);
						onStart && _callback(self, onStart, tweenTo.tween);
					}
				} else if (self.isActive && lastSnap !== scroll) snapDelayedCall.restart(true);
			}).pause();
		}
		id && (_ids[id] = self);
		trigger = self.trigger = _getTarget(trigger || pin !== true && pin);
		customRevertReturn = trigger && trigger._gsap && trigger._gsap.stRevert;
		customRevertReturn && (customRevertReturn = customRevertReturn(self));
		pin = pin === true ? trigger : _getTarget(pin);
		_isString(toggleClass) && (toggleClass = {
			targets: trigger,
			className: toggleClass
		});
		if (pin) {
			pinSpacing === false || pinSpacing === _margin || (pinSpacing = !pinSpacing && pin.parentNode && pin.parentNode.style && _getComputedStyle(pin.parentNode).display === "flex" ? false : _padding);
			self.pin = pin;
			pinCache = gsap.core.getCache(pin);
			if (!pinCache.spacer) {
				if (pinSpacer) {
					pinSpacer = _getTarget(pinSpacer);
					pinSpacer && !pinSpacer.nodeType && (pinSpacer = pinSpacer.current || pinSpacer.nativeElement);
					pinCache.spacerIsNative = !!pinSpacer;
					pinSpacer && (pinCache.spacerState = _getState(pinSpacer));
				}
				pinCache.spacer = spacer = pinSpacer || _doc.createElement("div");
				spacer.classList.add("pin-spacer");
				id && spacer.classList.add("pin-spacer-" + id);
				pinCache.pinState = pinOriginalState = _getState(pin);
			} else pinOriginalState = pinCache.pinState;
			vars.force3D !== false && gsap.set(pin, { force3D: true });
			self.spacer = spacer = pinCache.spacer;
			cs = _getComputedStyle(pin);
			spacingStart = cs[pinSpacing + direction.os2];
			pinGetter = gsap.getProperty(pin);
			pinSetter = gsap.quickSetter(pin, direction.a, _px);
			_swapPinIn(pin, spacer, cs);
			pinState = _getState(pin);
		}
		if (markers) {
			markerVars = _isObject(markers) ? _setDefaults(markers, _markerDefaults) : _markerDefaults;
			markerStartTrigger = _createMarker("scroller-start", id, scroller, direction, markerVars, 0);
			markerEndTrigger = _createMarker("scroller-end", id, scroller, direction, markerVars, 0, markerStartTrigger);
			offset = markerStartTrigger["offset" + direction.op.d2];
			var content = _getTarget(_getProxyProp(scroller, "content") || scroller);
			markerStart = this.markerStart = _createMarker("start", id, content, direction, markerVars, offset, 0, containerAnimation);
			markerEnd = this.markerEnd = _createMarker("end", id, content, direction, markerVars, offset, 0, containerAnimation);
			containerAnimation && (caMarkerSetter = gsap.quickSetter([markerStart, markerEnd], direction.a, _px));
			if (!useFixedPosition && !(_proxies.length && _getProxyProp(scroller, "fixedMarkers") === true)) {
				_makePositionable(isViewport ? _body : scroller);
				gsap.set([markerStartTrigger, markerEndTrigger], { force3D: true });
				markerStartSetter = gsap.quickSetter(markerStartTrigger, direction.a, _px);
				markerEndSetter = gsap.quickSetter(markerEndTrigger, direction.a, _px);
			}
		}
		if (containerAnimation) {
			var oldOnUpdate = containerAnimation.vars.onUpdate, oldParams = containerAnimation.vars.onUpdateParams;
			containerAnimation.eventCallback("onUpdate", function() {
				self.update(0, 0, 1);
				oldOnUpdate && oldOnUpdate.apply(containerAnimation, oldParams || []);
			});
		}
		self.previous = function() {
			return _triggers[_triggers.indexOf(self) - 1];
		};
		self.next = function() {
			return _triggers[_triggers.indexOf(self) + 1];
		};
		self.revert = function(revert, temp) {
			if (!temp) return self.kill(true);
			var r = revert !== false || !self.enabled, prevRefreshing = _refreshing;
			if (r !== self.isReverted) {
				if (r) {
					prevScroll = Math.max(scrollFunc(), self.scroll.rec || 0);
					prevProgress = self.progress;
					prevAnimProgress = animation && animation.progress();
				}
				markerStart && [
					markerStart,
					markerEnd,
					markerStartTrigger,
					markerEndTrigger
				].forEach(function(m) {
					return m.style.display = r ? "none" : "block";
				});
				if (r) {
					_refreshing = self;
					self.update(r);
				}
				if (pin && (!pinReparent || !self.isActive)) if (r) _swapPinOut(pin, spacer, pinOriginalState);
				else _swapPinIn(pin, spacer, _getComputedStyle(pin), spacerState);
				r || self.update(r);
				_refreshing = prevRefreshing;
				self.isReverted = r;
			}
		};
		self.refresh = function(soft, force, position, pinOffset) {
			if ((_refreshing || !self.enabled) && !force) return;
			if (pin && soft && _lastScrollTime) {
				_addListener(ScrollTrigger, "scrollEnd", _softRefresh);
				return;
			}
			!_refreshingAll && onRefreshInit && onRefreshInit(self);
			_refreshing = self;
			if (tweenTo.tween && !position) {
				tweenTo.tween.kill();
				tweenTo.tween = 0;
			}
			scrubTween && scrubTween.pause();
			if (invalidateOnRefresh && animation) {
				animation.revert({ kill: false }).invalidate();
				animation.getChildren ? animation.getChildren(true, true, false).forEach(function(t) {
					return t.vars.immediateRender && t.render(0, true, true);
				}) : animation.vars.immediateRender && animation.render(0, true, true);
			}
			self.isReverted || self.revert(true, true);
			self._subPinOffset = false;
			var size = getScrollerSize(), scrollerBounds = getScrollerOffsets(), max = containerAnimation ? containerAnimation.duration() : _maxScroll(scroller, direction), isFirstRefresh = change <= .01 || !change, offset = 0, otherPinOffset = pinOffset || 0, parsedEnd = _isObject(position) ? position.end : vars.end, parsedEndTrigger = vars.endTrigger || trigger, parsedStart = _isObject(position) ? position.start : vars.start || (vars.start === 0 || !trigger ? 0 : pin ? "0 0" : "0 100%"), pinnedContainer = self.pinnedContainer = vars.pinnedContainer && _getTarget(vars.pinnedContainer, self), triggerIndex = trigger && Math.max(0, _triggers.indexOf(self)) || 0, i = triggerIndex, cs, bounds, scroll, isVertical, override, curTrigger, curPin, oppositeScroll, initted, revertedPins, forcedOverflow, markerStartOffset, markerEndOffset;
			if (markers && _isObject(position)) {
				markerStartOffset = gsap.getProperty(markerStartTrigger, direction.p);
				markerEndOffset = gsap.getProperty(markerEndTrigger, direction.p);
			}
			while (i-- > 0) {
				curTrigger = _triggers[i];
				curTrigger.end || curTrigger.refresh(0, 1) || (_refreshing = self);
				curPin = curTrigger.pin;
				if (curPin && (curPin === trigger || curPin === pin || curPin === pinnedContainer) && !curTrigger.isReverted) {
					revertedPins || (revertedPins = []);
					revertedPins.unshift(curTrigger);
					curTrigger.revert(true, true);
				}
				if (curTrigger !== _triggers[i]) {
					triggerIndex--;
					i--;
				}
			}
			_isFunction(parsedStart) && (parsedStart = parsedStart(self));
			parsedStart = _parseClamp(parsedStart, "start", self);
			start = _parsePosition(parsedStart, trigger, size, direction, scrollFunc(), markerStart, markerStartTrigger, self, scrollerBounds, borderWidth, useFixedPosition, max, containerAnimation, self._startClamp && "_startClamp") || (pin ? -.001 : 0);
			_isFunction(parsedEnd) && (parsedEnd = parsedEnd(self));
			if (_isString(parsedEnd) && !parsedEnd.indexOf("+=")) if (~parsedEnd.indexOf(" ")) parsedEnd = (_isString(parsedStart) ? parsedStart.split(" ")[0] : "") + parsedEnd;
			else {
				offset = _offsetToPx(parsedEnd.substr(2), size);
				parsedEnd = _isString(parsedStart) ? parsedStart : (containerAnimation ? gsap.utils.mapRange(0, containerAnimation.duration(), containerAnimation.scrollTrigger.start, containerAnimation.scrollTrigger.end, start) : start) + offset;
				parsedEndTrigger = trigger;
			}
			parsedEnd = _parseClamp(parsedEnd, "end", self);
			end = Math.max(start, _parsePosition(parsedEnd || (parsedEndTrigger ? "100% 0" : max), parsedEndTrigger, size, direction, scrollFunc() + offset, markerEnd, markerEndTrigger, self, scrollerBounds, borderWidth, useFixedPosition, max, containerAnimation, self._endClamp && "_endClamp")) || -.001;
			offset = 0;
			i = triggerIndex;
			while (i--) {
				curTrigger = _triggers[i] || {};
				curPin = curTrigger.pin;
				if (curPin && curTrigger.start - curTrigger._pinPush <= start && !containerAnimation && curTrigger.end > 0) {
					cs = curTrigger.end - (self._startClamp ? Math.max(0, curTrigger.start) : curTrigger.start);
					if ((curPin === trigger && curTrigger.start - curTrigger._pinPush < start || curPin === pinnedContainer) && isNaN(parsedStart)) offset += cs * (1 - curTrigger.progress);
					curPin === pin && (otherPinOffset += cs);
				}
			}
			start += offset;
			end += offset;
			self._startClamp && (self._startClamp += offset);
			if (self._endClamp && !_refreshingAll) {
				self._endClamp = end || -.001;
				end = Math.min(end, _maxScroll(scroller, direction));
			}
			change = end - start || (start -= .01) && .001;
			if (isFirstRefresh) prevProgress = gsap.utils.clamp(0, 1, gsap.utils.normalize(start, end, prevScroll));
			self._pinPush = otherPinOffset;
			if (markerStart && offset) {
				cs = {};
				cs[direction.a] = "+=" + offset;
				pinnedContainer && (cs[direction.p] = "-=" + scrollFunc());
				gsap.set([markerStart, markerEnd], cs);
			}
			if (pin && !(_clampingMax && self.end >= _maxScroll(scroller, direction))) {
				cs = _getComputedStyle(pin);
				isVertical = direction === _vertical;
				scroll = scrollFunc();
				pinStart = parseFloat(pinGetter(direction.a)) + otherPinOffset;
				if (!max && end > 1) {
					forcedOverflow = (isViewport ? _doc.scrollingElement || _docEl : scroller).style;
					forcedOverflow = {
						style: forcedOverflow,
						value: forcedOverflow["overflow" + direction.a.toUpperCase()]
					};
					if (isViewport && _getComputedStyle(_body)["overflow" + direction.a.toUpperCase()] !== "scroll") forcedOverflow.style["overflow" + direction.a.toUpperCase()] = "scroll";
				}
				_swapPinIn(pin, spacer, cs);
				pinState = _getState(pin);
				bounds = _getBounds(pin, true);
				oppositeScroll = useFixedPosition && _getScrollFunc(scroller, isVertical ? _horizontal : _vertical)();
				if (pinSpacing) {
					spacerState = [pinSpacing + direction.os2, change + otherPinOffset + _px];
					spacerState.t = spacer;
					i = pinSpacing === _padding ? _getSize(pin, direction) + change + otherPinOffset : 0;
					if (i) {
						spacerState.push(direction.d, i + _px);
						spacer.style.flexBasis !== "auto" && (spacer.style.flexBasis = i + _px);
					}
					_setState(spacerState);
					if (pinnedContainer) _triggers.forEach(function(t) {
						if (t.pin === pinnedContainer && t.vars.pinSpacing !== false) t._subPinOffset = true;
					});
					useFixedPosition && scrollFunc(prevScroll);
				} else {
					i = _getSize(pin, direction);
					i && spacer.style.flexBasis !== "auto" && (spacer.style.flexBasis = i + _px);
				}
				if (useFixedPosition) {
					override = {
						top: bounds.top + (isVertical ? scroll - start : oppositeScroll) + _px,
						left: bounds.left + (isVertical ? oppositeScroll : scroll - start) + _px,
						boxSizing: "border-box",
						position: "fixed"
					};
					override[_width] = override["max" + _Width] = Math.ceil(bounds.width) + _px;
					override[_height] = override["max" + _Height] = Math.ceil(bounds.height) + _px;
					override[_margin] = override[_margin + _Top] = override[_margin + _Right] = override[_margin + _Bottom] = override[_margin + _Left] = "0";
					override[_padding] = cs[_padding];
					override[_padding + _Top] = cs[_padding + _Top];
					override[_padding + _Right] = cs[_padding + _Right];
					override[_padding + _Bottom] = cs[_padding + _Bottom];
					override[_padding + _Left] = cs[_padding + _Left];
					pinActiveState = _copyState(pinOriginalState, override, pinReparent);
					_refreshingAll && scrollFunc(0);
				}
				if (animation) {
					initted = animation._initted;
					_suppressOverwrites(1);
					animation.render(animation.duration(), true, true);
					pinChange = pinGetter(direction.a) - pinStart + change + otherPinOffset;
					pinMoves = Math.abs(change - pinChange) > 1;
					useFixedPosition && pinMoves && pinActiveState.splice(pinActiveState.length - 2, 2);
					animation.render(0, true, true);
					initted || animation.invalidate(true);
					animation.parent || animation.totalTime(animation.totalTime());
					_suppressOverwrites(0);
				} else pinChange = change;
				forcedOverflow && (forcedOverflow.value ? forcedOverflow.style["overflow" + direction.a.toUpperCase()] = forcedOverflow.value : forcedOverflow.style.removeProperty("overflow-" + direction.a));
			} else if (trigger && scrollFunc() && !containerAnimation) {
				bounds = trigger.parentNode;
				while (bounds && bounds !== _body) {
					if (bounds._pinOffset) {
						start -= bounds._pinOffset;
						end -= bounds._pinOffset;
					}
					bounds = bounds.parentNode;
				}
			}
			revertedPins && revertedPins.forEach(function(t) {
				return t.revert(false, true);
			});
			self.start = start;
			self.end = end;
			scroll1 = scroll2 = _refreshingAll ? prevScroll : scrollFunc();
			if (!containerAnimation && !_refreshingAll) {
				scroll1 < prevScroll && scrollFunc(prevScroll);
				self.scroll.rec = 0;
			}
			self.revert(false, true);
			lastRefresh = _getTime();
			if (snapDelayedCall) {
				lastSnap = -1;
				snapDelayedCall.restart(true);
			}
			_refreshing = 0;
			animation && isToggle && (animation._initted || prevAnimProgress) && animation.progress() !== prevAnimProgress && animation.progress(prevAnimProgress || 0, true).render(animation.time(), true, true);
			if (isFirstRefresh || prevProgress !== self.progress || containerAnimation || invalidateOnRefresh || animation && !animation._initted) {
				animation && !isToggle && (animation._initted || prevProgress || animation.vars.immediateRender !== false) && animation.totalProgress(containerAnimation && start < -.001 && !prevProgress ? gsap.utils.normalize(start, end, 0) : prevProgress, true);
				self.progress = isFirstRefresh || (scroll1 - start) / change === prevProgress ? 0 : prevProgress;
			}
			pin && pinSpacing && (spacer._pinOffset = Math.round(self.progress * pinChange));
			scrubTween && scrubTween.invalidate();
			if (!isNaN(markerStartOffset)) {
				markerStartOffset -= gsap.getProperty(markerStartTrigger, direction.p);
				markerEndOffset -= gsap.getProperty(markerEndTrigger, direction.p);
				_shiftMarker(markerStartTrigger, direction, markerStartOffset);
				_shiftMarker(markerStart, direction, markerStartOffset - (pinOffset || 0));
				_shiftMarker(markerEndTrigger, direction, markerEndOffset);
				_shiftMarker(markerEnd, direction, markerEndOffset - (pinOffset || 0));
			}
			isFirstRefresh && !_refreshingAll && self.update();
			if (onRefresh && !_refreshingAll && !executingOnRefresh) {
				executingOnRefresh = true;
				onRefresh(self);
				executingOnRefresh = false;
			}
		};
		self.getVelocity = function() {
			return (scrollFunc() - scroll2) / (_getTime() - _time2) * 1e3 || 0;
		};
		self.endAnimation = function() {
			_endAnimation(self.callbackAnimation);
			if (animation) scrubTween ? scrubTween.progress(1) : !animation.paused() ? _endAnimation(animation, animation.reversed()) : isToggle || _endAnimation(animation, self.direction < 0, 1);
		};
		self.labelToScroll = function(label) {
			return animation && animation.labels && (start || self.refresh() || start) + animation.labels[label] / animation.duration() * change || 0;
		};
		self.getTrailing = function(name) {
			var i = _triggers.indexOf(self), a = self.direction > 0 ? _triggers.slice(0, i).reverse() : _triggers.slice(i + 1);
			return (_isString(name) ? a.filter(function(t) {
				return t.vars.preventOverlaps === name;
			}) : a).filter(function(t) {
				return self.direction > 0 ? t.end <= start : t.start >= end;
			});
		};
		self.update = function(reset, recordVelocity, forceFake) {
			if (containerAnimation && !forceFake && !reset) return;
			var scroll = _refreshingAll === true ? prevScroll : self.scroll(), p = reset ? 0 : (scroll - start) / change, clipped = p < 0 ? 0 : p > 1 ? 1 : p || 0, prevProgress = self.progress, isActive, wasActive, toggleState, action, stateChanged, toggled, isAtMax, isTakingAction;
			if (recordVelocity) {
				scroll2 = scroll1;
				scroll1 = containerAnimation ? scrollFunc() : scroll;
				if (snap) {
					snap2 = snap1;
					snap1 = animation && !isToggle ? animation.totalProgress() : clipped;
				}
			}
			if (anticipatePin && pin && !_refreshing && !_startup && _lastScrollTime) {
				if (!clipped && start < scroll + (scroll - scroll2) / (_getTime() - _time2) * anticipatePin) clipped = 1e-4;
				else if (clipped === 1 && end > scroll + (scroll - scroll2) / (_getTime() - _time2) * anticipatePin) clipped = .9999;
			}
			if (clipped !== prevProgress && self.enabled) {
				isActive = self.isActive = !!clipped && clipped < 1;
				wasActive = !!prevProgress && prevProgress < 1;
				toggled = isActive !== wasActive;
				stateChanged = toggled || !!clipped !== !!prevProgress;
				self.direction = clipped > prevProgress ? 1 : -1;
				self.progress = clipped;
				if (stateChanged && !_refreshing) {
					toggleState = clipped && !prevProgress ? 0 : clipped === 1 ? 1 : prevProgress === 1 ? 2 : 3;
					if (isToggle) {
						action = !toggled && toggleActions[toggleState + 1] !== "none" && toggleActions[toggleState + 1] || toggleActions[toggleState];
						isTakingAction = animation && (action === "complete" || action === "reset" || action in animation);
					}
				}
				preventOverlaps && (toggled || isTakingAction) && (isTakingAction || scrub || !animation) && (_isFunction(preventOverlaps) ? preventOverlaps(self) : self.getTrailing(preventOverlaps).forEach(function(t) {
					return t.endAnimation();
				}));
				if (!isToggle) {
					if (scrubTween && !_refreshing && !_startup) {
						scrubTween._dp._time - scrubTween._start !== scrubTween._time && scrubTween.render(scrubTween._dp._time - scrubTween._start);
						if (scrubTween.resetTo) scrubTween.resetTo("totalProgress", clipped, animation._tTime / animation._tDur);
						else {
							scrubTween.vars.totalProgress = clipped;
							scrubTween.invalidate().restart();
						}
					} else if (animation) animation.totalProgress(clipped, !!(_refreshing && (lastRefresh || reset)));
				}
				if (pin) {
					reset && pinSpacing && (spacer.style[pinSpacing + direction.os2] = spacingStart);
					if (!useFixedPosition) pinSetter(_round(pinStart + pinChange * clipped));
					else if (stateChanged) {
						isAtMax = !reset && clipped > prevProgress && end + 1 > scroll && scroll + 1 >= _maxScroll(scroller, direction);
						if (pinReparent) if (!reset && (isActive || isAtMax)) {
							var bounds = _getBounds(pin, true), _offset = scroll - start;
							_reparent(pin, _body, bounds.top + (direction === _vertical ? _offset : 0) + _px, bounds.left + (direction === _vertical ? 0 : _offset) + _px);
						} else _reparent(pin, spacer);
						_setState(isActive || isAtMax ? pinActiveState : pinState);
						pinMoves && clipped < 1 && isActive || pinSetter(pinStart + (clipped === 1 && !isAtMax ? pinChange : 0));
					}
				}
				snap && !tweenTo.tween && !_refreshing && !_startup && snapDelayedCall.restart(true);
				toggleClass && (toggled || once && clipped && (clipped < 1 || !_limitCallbacks)) && _toArray(toggleClass.targets).forEach(function(el) {
					return el.classList[isActive || once ? "add" : "remove"](toggleClass.className);
				});
				onUpdate && !isToggle && !reset && onUpdate(self);
				if (stateChanged && !_refreshing) {
					if (isToggle) {
						if (isTakingAction) if (action === "complete") animation.pause().totalProgress(1);
						else if (action === "reset") animation.restart(true).pause();
						else if (action === "restart") animation.restart(true);
						else animation[action]();
						onUpdate && onUpdate(self);
					}
					if (toggled || !_limitCallbacks) {
						onToggle && toggled && _callback(self, onToggle);
						callbacks[toggleState] && _callback(self, callbacks[toggleState]);
						once && (clipped === 1 ? self.kill(false, 1) : callbacks[toggleState] = 0);
						if (!toggled) {
							toggleState = clipped === 1 ? 1 : 3;
							callbacks[toggleState] && _callback(self, callbacks[toggleState]);
						}
					}
					if (fastScrollEnd && !isActive && Math.abs(self.getVelocity()) > (_isNumber(fastScrollEnd) ? fastScrollEnd : 2500)) {
						_endAnimation(self.callbackAnimation);
						scrubTween ? scrubTween.progress(1) : _endAnimation(animation, action === "reverse" ? 1 : !clipped, 1);
					}
				} else if (isToggle && onUpdate && !_refreshing) onUpdate(self);
			}
			if (markerEndSetter) {
				var n = containerAnimation ? scroll / containerAnimation.duration() * (containerAnimation._caScrollDist || 0) : scroll;
				markerStartSetter(n + (markerStartTrigger._isFlipped ? 1 : 0));
				markerEndSetter(n);
			}
			caMarkerSetter && caMarkerSetter(-scroll / containerAnimation.duration() * (containerAnimation._caScrollDist || 0));
		};
		self.enable = function(reset, refresh) {
			if (!self.enabled) {
				self.enabled = true;
				_addListener(scroller, "resize", _onResize);
				isViewport || _addListener(scroller, "scroll", _onScroll);
				onRefreshInit && _addListener(ScrollTrigger, "refreshInit", onRefreshInit);
				if (reset !== false) {
					self.progress = prevProgress = 0;
					scroll1 = scroll2 = lastSnap = scrollFunc();
				}
				refresh !== false && self.refresh();
			}
		};
		self.getTween = function(snap) {
			return snap && tweenTo ? tweenTo.tween : scrubTween;
		};
		self.setPositions = function(newStart, newEnd, keepClamp, pinOffset) {
			if (containerAnimation) {
				var st = containerAnimation.scrollTrigger, duration = containerAnimation.duration(), _change = st.end - st.start;
				newStart = st.start + _change * newStart / duration;
				newEnd = st.start + _change * newEnd / duration;
			}
			self.refresh(false, false, {
				start: _keepClamp(newStart, keepClamp && !!self._startClamp),
				end: _keepClamp(newEnd, keepClamp && !!self._endClamp)
			}, pinOffset);
			self.update();
		};
		self.adjustPinSpacing = function(amount) {
			if (spacerState && amount) {
				var i = spacerState.indexOf(direction.d) + 1;
				spacerState[i] = parseFloat(spacerState[i]) + amount + _px;
				spacerState[1] = parseFloat(spacerState[1]) + amount + _px;
				_setState(spacerState);
			}
		};
		self.disable = function(reset, allowAnimation) {
			reset !== false && self.revert(true, true);
			if (self.enabled) {
				self.enabled = self.isActive = false;
				allowAnimation || scrubTween && scrubTween.pause();
				prevScroll = 0;
				pinCache && (pinCache.uncache = 1);
				onRefreshInit && _removeListener(ScrollTrigger, "refreshInit", onRefreshInit);
				if (snapDelayedCall) {
					snapDelayedCall.pause();
					tweenTo.tween && tweenTo.tween.kill() && (tweenTo.tween = 0);
				}
				if (!isViewport) {
					var i = _triggers.length;
					while (i--) if (_triggers[i].scroller === scroller && _triggers[i] !== self) return;
					_removeListener(scroller, "resize", _onResize);
					isViewport || _removeListener(scroller, "scroll", _onScroll);
				}
			}
		};
		self.kill = function(revert, allowAnimation) {
			self.disable(revert, allowAnimation);
			scrubTween && !allowAnimation && scrubTween.kill();
			id && delete _ids[id];
			var i = _triggers.indexOf(self);
			i >= 0 && _triggers.splice(i, 1);
			i === _i && _direction > 0 && _i--;
			i = 0;
			_triggers.forEach(function(t) {
				return t.scroller === self.scroller && (i = 1);
			});
			i || _refreshingAll || (self.scroll.rec = 0);
			if (animation) {
				animation.scrollTrigger = null;
				revert && animation.revert({ kill: false });
				allowAnimation || animation.kill();
			}
			markerStart && [
				markerStart,
				markerEnd,
				markerStartTrigger,
				markerEndTrigger
			].forEach(function(m) {
				return m.parentNode && m.parentNode.removeChild(m);
			});
			_primary === self && (_primary = 0);
			if (pin) {
				pinCache && (pinCache.uncache = 1);
				i = 0;
				_triggers.forEach(function(t) {
					return t.pin === pin && i++;
				});
				i || (pinCache.spacer = 0);
			}
			vars.onKill && vars.onKill(self);
		};
		_triggers.push(self);
		self.enable(false, false);
		customRevertReturn && customRevertReturn(self);
		if (animation && animation.add && !change) {
			var updateFunc = self.update;
			self.update = function() {
				self.update = updateFunc;
				_scrollers.cache++;
				start || end || self.refresh();
			};
			gsap.delayedCall(.01, self.update);
			change = .01;
			start = end = 0;
		} else self.refresh();
		pin && _queueRefreshAll();
	};
	ScrollTrigger.register = function register(core) {
		if (!_coreInitted) {
			gsap = core || _getGSAP();
			_windowExists() && window.document && ScrollTrigger.enable();
			_coreInitted = _enabled;
		}
		return _coreInitted;
	};
	ScrollTrigger.defaults = function defaults(config) {
		if (config) for (var p in config) _defaults[p] = config[p];
		return _defaults;
	};
	ScrollTrigger.disable = function disable(reset, kill) {
		_enabled = 0;
		_triggers.forEach(function(trigger) {
			return trigger[kill ? "kill" : "disable"](reset);
		});
		_removeListener(_win, "wheel", _onScroll);
		_removeListener(_doc, "scroll", _onScroll);
		clearInterval(_syncInterval);
		_removeListener(_doc, "touchcancel", _passThrough);
		_removeListener(_body, "touchstart", _passThrough);
		_multiListener(_removeListener, _doc, "pointerdown,touchstart,mousedown", _pointerDownHandler);
		_multiListener(_removeListener, _doc, "pointerup,touchend,mouseup", _pointerUpHandler);
		_resizeDelay.kill();
		_iterateAutoRefresh(_removeListener);
		for (var i = 0; i < _scrollers.length; i += 3) {
			_wheelListener(_removeListener, _scrollers[i], _scrollers[i + 1]);
			_wheelListener(_removeListener, _scrollers[i], _scrollers[i + 2]);
		}
	};
	ScrollTrigger.enable = function enable() {
		_win = window;
		_doc = document;
		_docEl = _doc.documentElement;
		_body = _doc.body;
		if (gsap) {
			_toArray = gsap.utils.toArray;
			_clamp = gsap.utils.clamp;
			_context = gsap.core.context || _passThrough;
			_suppressOverwrites = gsap.core.suppressOverwrites || _passThrough;
			_scrollRestoration = _win.history.scrollRestoration || "auto";
			_lastScroll = _win.pageYOffset || 0;
			gsap.core.globals("ScrollTrigger", ScrollTrigger);
			if (_body) {
				_enabled = 1;
				_div100vh = document.createElement("div");
				_div100vh.style.height = "100vh";
				_div100vh.style.position = "absolute";
				_refresh100vh();
				_rafBugFix();
				Observer.register(gsap);
				ScrollTrigger.isTouch = Observer.isTouch;
				_fixIOSBug = Observer.isTouch && /(iPad|iPhone|iPod|Mac)/g.test(navigator.userAgent);
				_ignoreMobileResize = Observer.isTouch === 1;
				_addListener(_win, "wheel", _onScroll);
				_root = [
					_win,
					_doc,
					_docEl,
					_body
				];
				if (gsap.matchMedia) {
					ScrollTrigger.matchMedia = function(vars) {
						var mm = gsap.matchMedia(), p;
						for (p in vars) mm.add(p, vars[p]);
						return mm;
					};
					gsap.addEventListener("matchMediaInit", function() {
						_recordScrollPositions();
						_revertAll();
					});
					gsap.addEventListener("matchMediaRevert", function() {
						return _revertRecorded();
					});
					gsap.addEventListener("matchMedia", function() {
						_refreshAll(0, 1);
						_dispatch("matchMedia");
					});
					gsap.matchMedia().add("(orientation: portrait)", function() {
						_setBaseDimensions();
						return _setBaseDimensions;
					});
				} else console.warn("Requires GSAP 3.11.0 or later");
				_setBaseDimensions();
				_addListener(_doc, "scroll", _onScroll);
				var bodyHasStyle = _body.hasAttribute("style"), bodyStyle = _body.style, border = bodyStyle.borderTopStyle, AnimationProto = gsap.core.Animation.prototype, bounds, i;
				AnimationProto.revert || Object.defineProperty(AnimationProto, "revert", { value: function value() {
					return this.time(-.01, true);
				} });
				bodyStyle.borderTopStyle = "solid";
				bounds = _getBounds(_body);
				_vertical.m = Math.round(bounds.top + _vertical.sc()) || 0;
				_horizontal.m = Math.round(bounds.left + _horizontal.sc()) || 0;
				border ? bodyStyle.borderTopStyle = border : bodyStyle.removeProperty("border-top-style");
				if (!bodyHasStyle) {
					_body.setAttribute("style", "");
					_body.removeAttribute("style");
				}
				_syncInterval = setInterval(_sync, 250);
				gsap.delayedCall(.5, function() {
					return _startup = 0;
				});
				_addListener(_doc, "touchcancel", _passThrough);
				_addListener(_body, "touchstart", _passThrough);
				_multiListener(_addListener, _doc, "pointerdown,touchstart,mousedown", _pointerDownHandler);
				_multiListener(_addListener, _doc, "pointerup,touchend,mouseup", _pointerUpHandler);
				_transformProp = gsap.utils.checkPrefix("transform");
				_stateProps.push(_transformProp);
				_coreInitted = _getTime();
				_resizeDelay = gsap.delayedCall(.2, _refreshAll).pause();
				_autoRefresh = [
					_doc,
					"visibilitychange",
					function() {
						var w = _win.innerWidth, h = _win.innerHeight;
						if (_doc.hidden) {
							_prevWidth = w;
							_prevHeight = h;
						} else if (_prevWidth !== w || _prevHeight !== h) _onResize();
					},
					_doc,
					"DOMContentLoaded",
					_refreshAll,
					_win,
					"load",
					_refreshAll,
					_win,
					"resize",
					_onResize
				];
				_iterateAutoRefresh(_addListener);
				_triggers.forEach(function(trigger) {
					return trigger.enable(0, 1);
				});
				for (i = 0; i < _scrollers.length; i += 3) {
					_wheelListener(_removeListener, _scrollers[i], _scrollers[i + 1]);
					_wheelListener(_removeListener, _scrollers[i], _scrollers[i + 2]);
				}
			} else if (_doc) _doc.addEventListener("DOMContentLoaded", function onLoad() {
				ScrollTrigger.enable();
				_doc.removeEventListener("DOMContentLoaded", onLoad);
			});
		}
	};
	ScrollTrigger.config = function config(vars) {
		"limitCallbacks" in vars && (_limitCallbacks = !!vars.limitCallbacks);
		var ms = vars.syncInterval;
		ms && clearInterval(_syncInterval) || (_syncInterval = ms) && setInterval(_sync, ms);
		"ignoreMobileResize" in vars && (_ignoreMobileResize = ScrollTrigger.isTouch === 1 && vars.ignoreMobileResize);
		if ("autoRefreshEvents" in vars) {
			_iterateAutoRefresh(_removeListener) || _iterateAutoRefresh(_addListener, vars.autoRefreshEvents || "none");
			_ignoreResize = (vars.autoRefreshEvents + "").indexOf("resize") === -1;
		}
	};
	ScrollTrigger.scrollerProxy = function scrollerProxy(target, vars) {
		var t = _getTarget(target), i = _scrollers.indexOf(t), isViewport = _isViewport(t);
		if (~i) _scrollers.splice(i, isViewport ? 6 : 2);
		if (vars) isViewport ? _proxies.unshift(_win, vars, _body, vars, _docEl, vars) : _proxies.unshift(t, vars);
	};
	ScrollTrigger.clearMatchMedia = function clearMatchMedia(query) {
		_triggers.forEach(function(t) {
			return t._ctx && t._ctx.query === query && t._ctx.kill(true, true);
		});
	};
	ScrollTrigger.isInViewport = function isInViewport(element, ratio, horizontal) {
		var bounds = (_isString(element) ? _getTarget(element) : element).getBoundingClientRect(), offset = bounds[horizontal ? _width : _height] * ratio || 0;
		return horizontal ? bounds.right - offset > 0 && bounds.left + offset < _win.innerWidth : bounds.bottom - offset > 0 && bounds.top + offset < _win.innerHeight;
	};
	ScrollTrigger.positionInViewport = function positionInViewport(element, referencePoint, horizontal) {
		_isString(element) && (element = _getTarget(element));
		var bounds = element.getBoundingClientRect(), size = bounds[horizontal ? _width : _height], offset = referencePoint == null ? size / 2 : referencePoint in _keywords ? _keywords[referencePoint] * size : ~referencePoint.indexOf("%") ? parseFloat(referencePoint) * size / 100 : parseFloat(referencePoint) || 0;
		return horizontal ? (bounds.left + offset) / _win.innerWidth : (bounds.top + offset) / _win.innerHeight;
	};
	ScrollTrigger.killAll = function killAll(allowListeners) {
		_triggers.slice(0).forEach(function(t) {
			return t.vars.id !== "ScrollSmoother" && t.kill();
		});
		if (allowListeners !== true) {
			var listeners = _listeners.killAll || [];
			_listeners = {};
			listeners.forEach(function(f) {
				return f();
			});
		}
	};
	return ScrollTrigger;
}();
ScrollTrigger.version = "3.15.0";
ScrollTrigger.saveStyles = function(targets) {
	return targets ? _toArray(targets).forEach(function(target) {
		if (target && target.style) {
			var i = _savedStyles.indexOf(target);
			i >= 0 && _savedStyles.splice(i, 5);
			_savedStyles.push(target, target.style.cssText, target.getBBox && target.getAttribute("transform"), gsap.core.getCache(target), _context());
		}
	}) : _savedStyles;
};
ScrollTrigger.revert = function(soft, media) {
	return _revertAll(!soft, media);
};
ScrollTrigger.create = function(vars, animation) {
	return new ScrollTrigger(vars, animation);
};
ScrollTrigger.refresh = function(safe) {
	return safe ? _onResize(true) : (_coreInitted || ScrollTrigger.register()) && _refreshAll(true);
};
ScrollTrigger.update = function(force) {
	return ++_scrollers.cache && _updateAll(force === true ? 2 : 0);
};
ScrollTrigger.clearScrollMemory = _clearScrollMemory;
ScrollTrigger.maxScroll = function(element, horizontal) {
	return _maxScroll(element, horizontal ? _horizontal : _vertical);
};
ScrollTrigger.getScrollFunc = function(element, horizontal) {
	return _getScrollFunc(_getTarget(element), horizontal ? _horizontal : _vertical);
};
ScrollTrigger.getById = function(id) {
	return _ids[id];
};
ScrollTrigger.getAll = function() {
	return _triggers.filter(function(t) {
		return t.vars.id !== "ScrollSmoother";
	});
};
ScrollTrigger.isScrolling = function() {
	return !!_lastScrollTime;
};
ScrollTrigger.snapDirectional = _snapDirectional;
ScrollTrigger.addEventListener = function(type, callback) {
	var a = _listeners[type] || (_listeners[type] = []);
	~a.indexOf(callback) || a.push(callback);
};
ScrollTrigger.removeEventListener = function(type, callback) {
	var a = _listeners[type], i = a && a.indexOf(callback);
	i >= 0 && a.splice(i, 1);
};
ScrollTrigger.batch = function(targets, vars) {
	var result = [], varsCopy = {}, interval = vars.interval || .016, batchMax = vars.batchMax || 1e9, proxyCallback = function proxyCallback(type, callback) {
		var elements = [], triggers = [], delay = gsap.delayedCall(interval, function() {
			callback(elements, triggers);
			elements = [];
			triggers = [];
		}).pause();
		return function(self) {
			elements.length || delay.restart(true);
			elements.push(self.trigger);
			triggers.push(self);
			batchMax <= elements.length && delay.progress(1);
		};
	}, p;
	for (p in vars) varsCopy[p] = p.substr(0, 2) === "on" && _isFunction(vars[p]) && p !== "onRefreshInit" ? proxyCallback(p, vars[p]) : vars[p];
	if (_isFunction(batchMax)) {
		batchMax = batchMax();
		_addListener(ScrollTrigger, "refresh", function() {
			return batchMax = vars.batchMax();
		});
	}
	_toArray(targets).forEach(function(target) {
		var config = {};
		for (p in varsCopy) config[p] = varsCopy[p];
		config.trigger = target;
		result.push(ScrollTrigger.create(config));
	});
	return result;
};
var _clampScrollAndGetDurationMultiplier = function _clampScrollAndGetDurationMultiplier(scrollFunc, current, end, max) {
	current > max ? scrollFunc(max) : current < 0 && scrollFunc(0);
	return end > max ? (max - current) / (end - current) : end < 0 ? current / (current - end) : 1;
};
var _allowNativePanning = function _allowNativePanning(target, direction) {
	if (direction === true) target.style.removeProperty("touch-action");
	else target.style.touchAction = direction === true ? "auto" : direction ? "pan-" + direction + (Observer.isTouch ? " pinch-zoom" : "") : "none";
	target === _docEl && _allowNativePanning(_body, direction);
};
var _overflow = {
	auto: 1,
	scroll: 1
};
var _nestedScroll = function _nestedScroll(_ref5) {
	var event = _ref5.event, target = _ref5.target, axis = _ref5.axis;
	var node = (event.changedTouches ? event.changedTouches[0] : event).target, cache = node._gsap || gsap.core.getCache(node), time = _getTime(), cs;
	if (!cache._isScrollT || time - cache._isScrollT > 2e3) {
		while (node && node !== _body && (node.scrollHeight <= node.clientHeight && node.scrollWidth <= node.clientWidth || !(_overflow[(cs = _getComputedStyle(node)).overflowY] || _overflow[cs.overflowX]))) node = node.parentNode;
		cache._isScroll = node && node !== target && !_isViewport(node) && (_overflow[(cs = _getComputedStyle(node)).overflowY] || _overflow[cs.overflowX]);
		cache._isScrollT = time;
	}
	if (cache._isScroll || axis === "x") {
		event.stopPropagation();
		event._gsapAllow = true;
	}
};
var _inputObserver = function _inputObserver(target, type, inputs, nested) {
	return Observer.create({
		target,
		capture: true,
		debounce: false,
		lockAxis: true,
		type,
		onWheel: nested = nested && _nestedScroll,
		onPress: nested,
		onDrag: nested,
		onScroll: nested,
		onEnable: function onEnable() {
			return inputs && _addListener(_doc, Observer.eventTypes[0], _captureInputs, false, true);
		},
		onDisable: function onDisable() {
			return _removeListener(_doc, Observer.eventTypes[0], _captureInputs, true);
		}
	});
};
var _inputExp = /(input|label|select|textarea)/i;
var _inputIsFocused;
var _captureInputs = function _captureInputs(e) {
	var isInput = _inputExp.test(e.target.tagName);
	if (isInput || _inputIsFocused) {
		e._gsapAllow = true;
		_inputIsFocused = isInput;
	}
};
var _getScrollNormalizer = function _getScrollNormalizer(vars) {
	_isObject(vars) || (vars = {});
	vars.preventDefault = vars.isNormalizer = vars.allowClicks = true;
	vars.type || (vars.type = "wheel,touch");
	vars.debounce = !!vars.debounce;
	vars.id = vars.id || "normalizer";
	var _vars2 = vars, normalizeScrollX = _vars2.normalizeScrollX, momentum = _vars2.momentum, allowNestedScroll = _vars2.allowNestedScroll, onRelease = _vars2.onRelease, self, maxY, target = _getTarget(vars.target) || _docEl, smoother = gsap.core.globals().ScrollSmoother, smootherInstance = smoother && smoother.get(), content = _fixIOSBug && (vars.content && _getTarget(vars.content) || smootherInstance && vars.content !== false && !smootherInstance.smooth() && smootherInstance.content()), scrollFuncY = _getScrollFunc(target, _vertical), scrollFuncX = _getScrollFunc(target, _horizontal), scale = 1, initialScale = (Observer.isTouch && _win.visualViewport ? _win.visualViewport.scale * _win.visualViewport.width : _win.outerWidth) / _win.innerWidth, wheelRefresh = 0, resolveMomentumDuration = _isFunction(momentum) ? function() {
		return momentum(self);
	} : function() {
		return momentum || 2.8;
	}, lastRefreshID, skipTouchMove, inputObserver = _inputObserver(target, vars.type, true, allowNestedScroll), resumeTouchMove = function resumeTouchMove() {
		return skipTouchMove = false;
	}, scrollClampX = _passThrough, scrollClampY = _passThrough, updateClamps = function updateClamps() {
		maxY = _maxScroll(target, _vertical);
		scrollClampY = _clamp(_fixIOSBug ? 1 : 0, maxY);
		normalizeScrollX && (scrollClampX = _clamp(0, _maxScroll(target, _horizontal)));
		lastRefreshID = _refreshID;
	}, removeContentOffset = function removeContentOffset() {
		content._gsap.y = _round(parseFloat(content._gsap.y) + scrollFuncY.offset) + "px";
		content.style.transform = "matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, " + parseFloat(content._gsap.y) + ", 0, 1)";
		scrollFuncY.offset = scrollFuncY.cacheID = 0;
	}, ignoreDrag = function ignoreDrag() {
		if (skipTouchMove) {
			requestAnimationFrame(resumeTouchMove);
			var offset = _round(self.deltaY / 2), scroll = scrollClampY(scrollFuncY.v - offset);
			if (content && scroll !== scrollFuncY.v + scrollFuncY.offset) {
				scrollFuncY.offset = scroll - scrollFuncY.v;
				var y = _round((parseFloat(content && content._gsap.y) || 0) - scrollFuncY.offset);
				content.style.transform = "matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, " + y + ", 0, 1)";
				content._gsap.y = y + "px";
				scrollFuncY.cacheID = _scrollers.cache;
				_updateAll();
			}
			return true;
		}
		scrollFuncY.offset && removeContentOffset();
		skipTouchMove = true;
	}, tween, startScrollX, startScrollY, onStopDelayedCall, onResize = function onResize() {
		updateClamps();
		if (tween.isActive() && tween.vars.scrollY > maxY) scrollFuncY() > maxY ? tween.progress(1) && scrollFuncY(maxY) : tween.resetTo("scrollY", maxY);
	};
	content && gsap.set(content, { y: "+=0" });
	vars.ignoreCheck = function(e) {
		return _fixIOSBug && e.type === "touchmove" && ignoreDrag(e) || scale > 1.05 && e.type !== "touchstart" || self.isGesturing || e.touches && e.touches.length > 1;
	};
	vars.onPress = function() {
		skipTouchMove = false;
		var prevScale = scale;
		scale = _round((_win.visualViewport && _win.visualViewport.scale || 1) / initialScale);
		tween.pause();
		prevScale !== scale && _allowNativePanning(target, scale > 1.01 ? true : normalizeScrollX ? false : "x");
		startScrollX = scrollFuncX();
		startScrollY = scrollFuncY();
		updateClamps();
		lastRefreshID = _refreshID;
	};
	vars.onRelease = vars.onGestureStart = function(self, wasDragging) {
		scrollFuncY.offset && removeContentOffset();
		if (!wasDragging) onStopDelayedCall.restart(true);
		else {
			_scrollers.cache++;
			var dur = resolveMomentumDuration(), currentScroll, endScroll;
			if (normalizeScrollX) {
				currentScroll = scrollFuncX();
				endScroll = currentScroll + dur * .05 * -self.velocityX / .227;
				dur *= _clampScrollAndGetDurationMultiplier(scrollFuncX, currentScroll, endScroll, _maxScroll(target, _horizontal));
				tween.vars.scrollX = scrollClampX(endScroll);
			}
			currentScroll = scrollFuncY();
			endScroll = currentScroll + dur * .05 * -self.velocityY / .227;
			dur *= _clampScrollAndGetDurationMultiplier(scrollFuncY, currentScroll, endScroll, _maxScroll(target, _vertical));
			tween.vars.scrollY = scrollClampY(endScroll);
			tween.invalidate().duration(dur).play(.01);
			if (_fixIOSBug && tween.vars.scrollY >= maxY || currentScroll >= maxY - 1) gsap.to({}, {
				onUpdate: onResize,
				duration: dur
			});
		}
		onRelease && onRelease(self);
	};
	vars.onWheel = function() {
		tween._ts && tween.pause();
		if (_getTime() - wheelRefresh > 1e3) {
			lastRefreshID = 0;
			wheelRefresh = _getTime();
		}
	};
	vars.onChange = function(self, dx, dy, xArray, yArray) {
		_refreshID !== lastRefreshID && updateClamps();
		dx && normalizeScrollX && scrollFuncX(scrollClampX(xArray[2] === dx ? startScrollX + (self.startX - self.x) : scrollFuncX() + dx - xArray[1]));
		if (dy) {
			scrollFuncY.offset && removeContentOffset();
			var isTouch = yArray[2] === dy, y = isTouch ? startScrollY + self.startY - self.y : scrollFuncY() + dy - yArray[1], yClamped = scrollClampY(y);
			isTouch && y !== yClamped && (startScrollY += yClamped - y);
			scrollFuncY(yClamped);
		}
		(dy || dx) && _updateAll();
	};
	vars.onEnable = function() {
		_allowNativePanning(target, normalizeScrollX ? false : "x");
		ScrollTrigger.addEventListener("refresh", onResize);
		_addListener(_win, "resize", onResize);
		if (scrollFuncY.smooth) {
			scrollFuncY.target.style.scrollBehavior = "auto";
			scrollFuncY.smooth = scrollFuncX.smooth = false;
		}
		inputObserver.enable();
	};
	vars.onDisable = function() {
		_allowNativePanning(target, true);
		_removeListener(_win, "resize", onResize);
		ScrollTrigger.removeEventListener("refresh", onResize);
		inputObserver.kill();
	};
	vars.lockAxis = vars.lockAxis !== false;
	self = new Observer(vars);
	self.iOS = _fixIOSBug;
	_fixIOSBug && !scrollFuncY() && scrollFuncY(1);
	_fixIOSBug && gsap.ticker.add(_passThrough);
	onStopDelayedCall = self._dc;
	tween = gsap.to(self, {
		ease: "power4",
		paused: true,
		inherit: false,
		scrollX: normalizeScrollX ? "+=0.1" : "+=0",
		scrollY: "+=0.1",
		modifiers: { scrollY: _interruptionTracker(scrollFuncY, scrollFuncY(), function() {
			return tween.pause();
		}) },
		onUpdate: _updateAll,
		onComplete: onStopDelayedCall.vars.onComplete
	});
	return self;
};
ScrollTrigger.sort = function(func) {
	if (_isFunction(func)) return _triggers.sort(func);
	var scroll = _win.pageYOffset || 0;
	ScrollTrigger.getAll().forEach(function(t) {
		return t._sortY = t.trigger ? scroll + t.trigger.getBoundingClientRect().top : t.start + _win.innerHeight;
	});
	return _triggers.sort(func || function(a, b) {
		return (a.vars.refreshPriority || 0) * -1e6 + (a.vars.containerAnimation ? 1e6 : a._sortY) - ((b.vars.containerAnimation ? 1e6 : b._sortY) + (b.vars.refreshPriority || 0) * -1e6);
	});
};
ScrollTrigger.observe = function(vars) {
	return new Observer(vars);
};
ScrollTrigger.normalizeScroll = function(vars) {
	if (typeof vars === "undefined") return _normalizer;
	if (vars === true && _normalizer) return _normalizer.enable();
	if (vars === false) {
		_normalizer && _normalizer.kill();
		_normalizer = vars;
		return;
	}
	var normalizer = vars instanceof Observer ? vars : _getScrollNormalizer(vars);
	_normalizer && _normalizer.target === normalizer.target && _normalizer.kill();
	_isViewport(normalizer.target) && (_normalizer = normalizer);
	return normalizer;
};
ScrollTrigger.core = {
	_getVelocityProp,
	_inputObserver,
	_scrollers,
	_proxies,
	bridge: {
		ss: function ss() {
			_lastScrollTime || _dispatch("scrollStart");
			_lastScrollTime = _getTime();
		},
		ref: function ref() {
			return _refreshing;
		}
	}
};
_getGSAP() && gsap.registerPlugin(ScrollTrigger);
//#endregion
export { ScrollTrigger, ScrollTrigger as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3NhcF9TY3JvbGxUcmlnZ2VyLmpzIiwibmFtZXMiOlsiZ3NhcCIsIl9jb3JlSW5pdHRlZCIsIl93aW4iLCJfZG9jIiwiX2RvY0VsIiwiX2JvZHkiLCJTY3JvbGxUcmlnZ2VyIiwiX3Jvb3QiLCJfbm9ybWFsaXplciIsIl9jb250ZXh0IiwiX2dldEdTQVAiLCJfc3RhcnR1cCIsIl9nZXRUaW1lIiwiX2lzVmlld3BvcnQiLCJfYWRkTGlzdGVuZXIiLCJfcmVtb3ZlTGlzdGVuZXIiLCJfb25TY3JvbGwiXSwic291cmNlcyI6WyIuLi8uLi9nc2FwL09ic2VydmVyLmpzIiwiLi4vLi4vZ3NhcC9TY3JvbGxUcmlnZ2VyLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgcHJvcHMpIHsgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykgeyB2YXIgZGVzY3JpcHRvciA9IHByb3BzW2ldOyBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGUgfHwgZmFsc2U7IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTsgaWYgKFwidmFsdWVcIiBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH1cblxuZnVuY3Rpb24gX2NyZWF0ZUNsYXNzKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgX2RlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBfZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH1cblxuLyohXG4gKiBPYnNlcnZlciAzLjE1LjBcbiAqIGh0dHBzOi8vZ3NhcC5jb21cbiAqXG4gKiBAbGljZW5zZSBDb3B5cmlnaHQgMjAwOC0yMDI2LCBHcmVlblNvY2suIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKiBTdWJqZWN0IHRvIHRoZSB0ZXJtcyBhdCBodHRwczovL2dzYXAuY29tL3N0YW5kYXJkLWxpY2Vuc2VcbiAqIEBhdXRob3I6IEphY2sgRG95bGUsIGphY2tAZ3JlZW5zb2NrLmNvbVxuKi9cblxuLyogZXNsaW50LWRpc2FibGUgKi9cbnZhciBnc2FwLFxuICAgIF9jb3JlSW5pdHRlZCxcbiAgICBfY2xhbXAsXG4gICAgX3dpbixcbiAgICBfZG9jLFxuICAgIF9kb2NFbCxcbiAgICBfYm9keSxcbiAgICBfaXNUb3VjaCxcbiAgICBfcG9pbnRlclR5cGUsXG4gICAgU2Nyb2xsVHJpZ2dlcixcbiAgICBfcm9vdCxcbiAgICBfbm9ybWFsaXplcixcbiAgICBfZXZlbnRUeXBlcyxcbiAgICBfY29udGV4dCxcbiAgICBfZ2V0R1NBUCA9IGZ1bmN0aW9uIF9nZXRHU0FQKCkge1xuICByZXR1cm4gZ3NhcCB8fCB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIChnc2FwID0gd2luZG93LmdzYXApICYmIGdzYXAucmVnaXN0ZXJQbHVnaW4gJiYgZ3NhcDtcbn0sXG4gICAgX3N0YXJ0dXAgPSAxLFxuICAgIF9vYnNlcnZlcnMgPSBbXSxcbiAgICBfc2Nyb2xsZXJzID0gW10sXG4gICAgX3Byb3hpZXMgPSBbXSxcbiAgICBfZ2V0VGltZSA9IERhdGUubm93LFxuICAgIF9icmlkZ2UgPSBmdW5jdGlvbiBfYnJpZGdlKG5hbWUsIHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZTtcbn0sXG4gICAgX2ludGVncmF0ZSA9IGZ1bmN0aW9uIF9pbnRlZ3JhdGUoKSB7XG4gIHZhciBjb3JlID0gU2Nyb2xsVHJpZ2dlci5jb3JlLFxuICAgICAgZGF0YSA9IGNvcmUuYnJpZGdlIHx8IHt9LFxuICAgICAgc2Nyb2xsZXJzID0gY29yZS5fc2Nyb2xsZXJzLFxuICAgICAgcHJveGllcyA9IGNvcmUuX3Byb3hpZXM7XG4gIHNjcm9sbGVycy5wdXNoLmFwcGx5KHNjcm9sbGVycywgX3Njcm9sbGVycyk7XG4gIHByb3hpZXMucHVzaC5hcHBseShwcm94aWVzLCBfcHJveGllcyk7XG4gIF9zY3JvbGxlcnMgPSBzY3JvbGxlcnM7XG4gIF9wcm94aWVzID0gcHJveGllcztcblxuICBfYnJpZGdlID0gZnVuY3Rpb24gX2JyaWRnZShuYW1lLCB2YWx1ZSkge1xuICAgIHJldHVybiBkYXRhW25hbWVdKHZhbHVlKTtcbiAgfTtcbn0sXG4gICAgX2dldFByb3h5UHJvcCA9IGZ1bmN0aW9uIF9nZXRQcm94eVByb3AoZWxlbWVudCwgcHJvcGVydHkpIHtcbiAgcmV0dXJuIH5fcHJveGllcy5pbmRleE9mKGVsZW1lbnQpICYmIF9wcm94aWVzW19wcm94aWVzLmluZGV4T2YoZWxlbWVudCkgKyAxXVtwcm9wZXJ0eV07XG59LFxuICAgIF9pc1ZpZXdwb3J0ID0gZnVuY3Rpb24gX2lzVmlld3BvcnQoZWwpIHtcbiAgcmV0dXJuICEhfl9yb290LmluZGV4T2YoZWwpO1xufSxcbiAgICBfYWRkTGlzdGVuZXIgPSBmdW5jdGlvbiBfYWRkTGlzdGVuZXIoZWxlbWVudCwgdHlwZSwgZnVuYywgcGFzc2l2ZSwgY2FwdHVyZSkge1xuICByZXR1cm4gZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGZ1bmMsIHtcbiAgICBwYXNzaXZlOiBwYXNzaXZlICE9PSBmYWxzZSxcbiAgICBjYXB0dXJlOiAhIWNhcHR1cmVcbiAgfSk7XG59LFxuICAgIF9yZW1vdmVMaXN0ZW5lciA9IGZ1bmN0aW9uIF9yZW1vdmVMaXN0ZW5lcihlbGVtZW50LCB0eXBlLCBmdW5jLCBjYXB0dXJlKSB7XG4gIHJldHVybiBlbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIodHlwZSwgZnVuYywgISFjYXB0dXJlKTtcbn0sXG4gICAgX3Njcm9sbExlZnQgPSBcInNjcm9sbExlZnRcIixcbiAgICBfc2Nyb2xsVG9wID0gXCJzY3JvbGxUb3BcIixcbiAgICBfb25TY3JvbGwgPSBmdW5jdGlvbiBfb25TY3JvbGwoKSB7XG4gIHJldHVybiBfbm9ybWFsaXplciAmJiBfbm9ybWFsaXplci5pc1ByZXNzZWQgfHwgX3Njcm9sbGVycy5jYWNoZSsrO1xufSxcbiAgICBfc2Nyb2xsQ2FjaGVGdW5jID0gZnVuY3Rpb24gX3Njcm9sbENhY2hlRnVuYyhmLCBkb05vdENhY2hlKSB7XG4gIHZhciBjYWNoaW5nRnVuYyA9IGZ1bmN0aW9uIGNhY2hpbmdGdW5jKHZhbHVlKSB7XG4gICAgLy8gc2luY2UgcmVhZGluZyB0aGUgc2Nyb2xsVG9wL3Njcm9sbExlZnQvcGFnZU9mZnNldFkvcGFnZU9mZnNldFggY2FuIHRyaWdnZXIgYSBsYXlvdXQsIHRoaXMgZnVuY3Rpb24gYWxsb3dzIHVzIHRvIGNhY2hlIHRoZSB2YWx1ZSBzbyBpdCBvbmx5IGdldHMgcmVhZCBmcmVzaCBhZnRlciBhIFwic2Nyb2xsXCIgZXZlbnQgZmlyZXMgKG9yIHdoaWxlIHdlJ3JlIHJlZnJlc2hpbmcgYmVjYXVzZSB0aGF0IGNhbiBsZW5ndGhlbiB0aGUgcGFnZSBhbmQgYWx0ZXIgdGhlIHNjcm9sbCBwb3NpdGlvbikuIHdoZW4gXCJzb2Z0XCIgaXMgdHJ1ZSwgdGhhdCBtZWFucyBkb24ndCBhY3R1YWxseSBzZXQgdGhlIHNjcm9sbCwgYnV0IGNhY2hlIHRoZSBuZXcgdmFsdWUgaW5zdGVhZCAodXNlZnVsIGluIFNjcm9sbFNtb290aGVyKVxuICAgIGlmICh2YWx1ZSB8fCB2YWx1ZSA9PT0gMCkge1xuICAgICAgX3N0YXJ0dXAgJiYgKF93aW4uaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IFwibWFudWFsXCIpOyAvLyBvdGhlcndpc2UgdGhlIG5ldyBwb3NpdGlvbiB3aWxsIGdldCBvdmVyd3JpdHRlbiBieSB0aGUgYnJvd3NlciBvbmxvYWQuXG5cbiAgICAgIHZhciBpc05vcm1hbGl6aW5nID0gX25vcm1hbGl6ZXIgJiYgX25vcm1hbGl6ZXIuaXNQcmVzc2VkO1xuICAgICAgdmFsdWUgPSBjYWNoaW5nRnVuYy52ID0gTWF0aC5yb3VuZCh2YWx1ZSkgfHwgKF9ub3JtYWxpemVyICYmIF9ub3JtYWxpemVyLmlPUyA/IDEgOiAwKTsgLy9UT0RPOiBpT1MgQnVnOiBpZiB5b3UgYWxsb3cgaXQgdG8gZ28gdG8gMCwgU2FmYXJpIGNhbiBzdGFydCB0byByZXBvcnQgc3VwZXIgc3RyYW5nZSAod2lsZGx5IGluYWNjdXJhdGUpIHRvdWNoIHBvc2l0aW9ucyFcblxuICAgICAgZih2YWx1ZSk7XG4gICAgICBjYWNoaW5nRnVuYy5jYWNoZUlEID0gX3Njcm9sbGVycy5jYWNoZTtcbiAgICAgIGlzTm9ybWFsaXppbmcgJiYgX2JyaWRnZShcInNzXCIsIHZhbHVlKTsgLy8gc2V0IHNjcm9sbCAobm90aWZ5IFNjcm9sbFRyaWdnZXIgc28gaXQgY2FuIGRpc3BhdGNoIGEgXCJzY3JvbGxTdGFydFwiIGV2ZW50IGlmIG5lY2Vzc2FyeVxuICAgIH0gZWxzZSBpZiAoZG9Ob3RDYWNoZSB8fCBfc2Nyb2xsZXJzLmNhY2hlICE9PSBjYWNoaW5nRnVuYy5jYWNoZUlEIHx8IF9icmlkZ2UoXCJyZWZcIikpIHtcbiAgICAgIGNhY2hpbmdGdW5jLmNhY2hlSUQgPSBfc2Nyb2xsZXJzLmNhY2hlO1xuICAgICAgY2FjaGluZ0Z1bmMudiA9IGYoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gY2FjaGluZ0Z1bmMudiArIGNhY2hpbmdGdW5jLm9mZnNldDtcbiAgfTtcblxuICBjYWNoaW5nRnVuYy5vZmZzZXQgPSAwO1xuICByZXR1cm4gZiAmJiBjYWNoaW5nRnVuYztcbn0sXG4gICAgX2hvcml6b250YWwgPSB7XG4gIHM6IF9zY3JvbGxMZWZ0LFxuICBwOiBcImxlZnRcIixcbiAgcDI6IFwiTGVmdFwiLFxuICBvczogXCJyaWdodFwiLFxuICBvczI6IFwiUmlnaHRcIixcbiAgZDogXCJ3aWR0aFwiLFxuICBkMjogXCJXaWR0aFwiLFxuICBhOiBcInhcIixcbiAgc2M6IF9zY3JvbGxDYWNoZUZ1bmMoZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyBfd2luLnNjcm9sbFRvKHZhbHVlLCBfdmVydGljYWwuc2MoKSkgOiBfd2luLnBhZ2VYT2Zmc2V0IHx8IF9kb2NbX3Njcm9sbExlZnRdIHx8IF9kb2NFbFtfc2Nyb2xsTGVmdF0gfHwgX2JvZHlbX3Njcm9sbExlZnRdIHx8IDA7XG4gIH0pXG59LFxuICAgIF92ZXJ0aWNhbCA9IHtcbiAgczogX3Njcm9sbFRvcCxcbiAgcDogXCJ0b3BcIixcbiAgcDI6IFwiVG9wXCIsXG4gIG9zOiBcImJvdHRvbVwiLFxuICBvczI6IFwiQm90dG9tXCIsXG4gIGQ6IFwiaGVpZ2h0XCIsXG4gIGQyOiBcIkhlaWdodFwiLFxuICBhOiBcInlcIixcbiAgb3A6IF9ob3Jpem9udGFsLFxuICBzYzogX3Njcm9sbENhY2hlRnVuYyhmdW5jdGlvbiAodmFsdWUpIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/IF93aW4uc2Nyb2xsVG8oX2hvcml6b250YWwuc2MoKSwgdmFsdWUpIDogX3dpbi5wYWdlWU9mZnNldCB8fCBfZG9jW19zY3JvbGxUb3BdIHx8IF9kb2NFbFtfc2Nyb2xsVG9wXSB8fCBfYm9keVtfc2Nyb2xsVG9wXSB8fCAwO1xuICB9KVxufSxcbiAgICBfZ2V0VGFyZ2V0ID0gZnVuY3Rpb24gX2dldFRhcmdldCh0LCBzZWxmKSB7XG4gIHJldHVybiAoc2VsZiAmJiBzZWxmLl9jdHggJiYgc2VsZi5fY3R4LnNlbGVjdG9yIHx8IGdzYXAudXRpbHMudG9BcnJheSkodClbMF0gfHwgKHR5cGVvZiB0ID09PSBcInN0cmluZ1wiICYmIGdzYXAuY29uZmlnKCkubnVsbFRhcmdldFdhcm4gIT09IGZhbHNlID8gY29uc29sZS53YXJuKFwiRWxlbWVudCBub3QgZm91bmQ6XCIsIHQpIDogbnVsbCk7XG59LFxuICAgIF9pc1dpdGhpbiA9IGZ1bmN0aW9uIF9pc1dpdGhpbihlbGVtZW50LCBsaXN0KSB7XG4gIC8vIGNoZWNrIGlmIHRoZSBlbGVtZW50IGlzIGluIHRoZSBsaXN0IG9yIGlzIGEgZGVzY2VuZGFudCBvZiBhbiBlbGVtZW50IGluIHRoZSBsaXN0LlxuICB2YXIgaSA9IGxpc3QubGVuZ3RoO1xuXG4gIHdoaWxlIChpLS0pIHtcbiAgICBpZiAobGlzdFtpXSA9PT0gZWxlbWVudCB8fCBsaXN0W2ldLmNvbnRhaW5zKGVsZW1lbnQpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZmFsc2U7XG59LFxuICAgIF9nZXRTY3JvbGxGdW5jID0gZnVuY3Rpb24gX2dldFNjcm9sbEZ1bmMoZWxlbWVudCwgX3JlZikge1xuICB2YXIgcyA9IF9yZWYucyxcbiAgICAgIHNjID0gX3JlZi5zYztcbiAgLy8gd2Ugc3RvcmUgdGhlIHNjcm9sbGVyIGZ1bmN0aW9ucyBpbiBhbiBhbHRlcm5hdGluZyBzZXF1ZW5jZWQgQXJyYXkgbGlrZSBbZWxlbWVudCwgdmVydGljYWxTY3JvbGxGdW5jLCBob3Jpem9udGFsU2Nyb2xsRnVuYywgLi4uXSBzbyB0aGF0IHdlIGNhbiBtaW5pbWl6ZSBtZW1vcnksIG1heGltaXplIHBlcmZvcm1hbmNlLCBhbmQgd2UgYWxzbyByZWNvcmQgdGhlIGxhc3QgcG9zaXRpb24gYXMgYSBcIi5yZWNcIiBwcm9wZXJ0eSBpbiBvcmRlciB0byByZXZlcnQgdG8gdGhhdCBhZnRlciByZWZyZXNoaW5nIHRvIGVuc3VyZSB0aGluZ3MgZG9uJ3Qgc2hpZnQgYXJvdW5kLlxuICBfaXNWaWV3cG9ydChlbGVtZW50KSAmJiAoZWxlbWVudCA9IF9kb2Muc2Nyb2xsaW5nRWxlbWVudCB8fCBfZG9jRWwpO1xuXG4gIHZhciBpID0gX3Njcm9sbGVycy5pbmRleE9mKGVsZW1lbnQpLFxuICAgICAgb2Zmc2V0ID0gc2MgPT09IF92ZXJ0aWNhbC5zYyA/IDEgOiAyO1xuXG4gICF+aSAmJiAoaSA9IF9zY3JvbGxlcnMucHVzaChlbGVtZW50KSAtIDEpO1xuICBfc2Nyb2xsZXJzW2kgKyBvZmZzZXRdIHx8IF9hZGRMaXN0ZW5lcihlbGVtZW50LCBcInNjcm9sbFwiLCBfb25TY3JvbGwpOyAvLyBjbGVhciB0aGUgY2FjaGUgd2hlbiBhIHNjcm9sbCBvY2N1cnNcblxuICB2YXIgcHJldiA9IF9zY3JvbGxlcnNbaSArIG9mZnNldF0sXG4gICAgICBmdW5jID0gcHJldiB8fCAoX3Njcm9sbGVyc1tpICsgb2Zmc2V0XSA9IF9zY3JvbGxDYWNoZUZ1bmMoX2dldFByb3h5UHJvcChlbGVtZW50LCBzKSwgdHJ1ZSkgfHwgKF9pc1ZpZXdwb3J0KGVsZW1lbnQpID8gc2MgOiBfc2Nyb2xsQ2FjaGVGdW5jKGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gZWxlbWVudFtzXSA9IHZhbHVlIDogZWxlbWVudFtzXTtcbiAgfSkpKTtcbiAgZnVuYy50YXJnZXQgPSBlbGVtZW50O1xuICBwcmV2IHx8IChmdW5jLnNtb290aCA9IGdzYXAuZ2V0UHJvcGVydHkoZWxlbWVudCwgXCJzY3JvbGxCZWhhdmlvclwiKSA9PT0gXCJzbW9vdGhcIik7IC8vIG9ubHkgc2V0IGl0IHRoZSBmaXJzdCB0aW1lIChkb24ndCByZXNldCBldmVyeSB0aW1lIGEgc2Nyb2xsRnVuYyBpcyByZXF1ZXN0ZWQgYmVjYXVzZSBwZXJoYXBzIGl0IGhhcHBlbnMgZHVyaW5nIGEgcmVmcmVzaCgpIHdoZW4gaXQncyBkaXNhYmxlZCBpbiBTY3JvbGxUcmlnZ2VyLlxuXG4gIHJldHVybiBmdW5jO1xufSxcbiAgICBfZ2V0VmVsb2NpdHlQcm9wID0gZnVuY3Rpb24gX2dldFZlbG9jaXR5UHJvcCh2YWx1ZSwgbWluVGltZVJlZnJlc2gsIHVzZURlbHRhKSB7XG4gIHZhciB2MSA9IHZhbHVlLFxuICAgICAgdjIgPSB2YWx1ZSxcbiAgICAgIHQxID0gX2dldFRpbWUoKSxcbiAgICAgIHQyID0gdDEsXG4gICAgICBtaW4gPSBtaW5UaW1lUmVmcmVzaCB8fCA1MCxcbiAgICAgIGRyb3BUb1plcm9UaW1lID0gTWF0aC5tYXgoNTAwLCBtaW4gKiAzKSxcbiAgICAgIHVwZGF0ZSA9IGZ1bmN0aW9uIHVwZGF0ZSh2YWx1ZSwgZm9yY2UpIHtcbiAgICB2YXIgdCA9IF9nZXRUaW1lKCk7XG5cbiAgICBpZiAoZm9yY2UgfHwgdCAtIHQxID4gbWluKSB7XG4gICAgICB2MiA9IHYxO1xuICAgICAgdjEgPSB2YWx1ZTtcbiAgICAgIHQyID0gdDE7XG4gICAgICB0MSA9IHQ7XG4gICAgfSBlbHNlIGlmICh1c2VEZWx0YSkge1xuICAgICAgdjEgKz0gdmFsdWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIG5vdCB0b3RhbGx5IG5lY2Vzc2FyeSwgYnV0IG1ha2VzIGl0IGEgYml0IG1vcmUgYWNjdXJhdGUgYnkgYWRqdXN0aW5nIHRoZSB2MSB2YWx1ZSBhY2NvcmRpbmcgdG8gdGhlIG5ldyBzbG9wZS4gVGhpcyB3YXkgd2UncmUgbm90IGp1c3QgaWdub3JpbmcgdGhlIGluY29taW5nIGRhdGEuIFJlbW92aW5nIGZvciBub3cgYmVjYXVzZSBpdCBkb2Vzbid0IHNlZW0gdG8gbWFrZSBtdWNoIHByYWN0aWNhbCBkaWZmZXJlbmNlIGFuZCBpdCdzIHByb2JhYmx5IG5vdCB3b3J0aCB0aGUga2IuXG4gICAgICB2MSA9IHYyICsgKHZhbHVlIC0gdjIpIC8gKHQgLSB0MikgKiAodDEgLSB0Mik7XG4gICAgfVxuICB9LFxuICAgICAgcmVzZXQgPSBmdW5jdGlvbiByZXNldCgpIHtcbiAgICB2MiA9IHYxID0gdXNlRGVsdGEgPyAwIDogdjE7XG4gICAgdDIgPSB0MSA9IDA7XG4gIH0sXG4gICAgICBnZXRWZWxvY2l0eSA9IGZ1bmN0aW9uIGdldFZlbG9jaXR5KGxhdGVzdFZhbHVlKSB7XG4gICAgdmFyIHRPbGQgPSB0MixcbiAgICAgICAgdk9sZCA9IHYyLFxuICAgICAgICB0ID0gX2dldFRpbWUoKTtcblxuICAgIChsYXRlc3RWYWx1ZSB8fCBsYXRlc3RWYWx1ZSA9PT0gMCkgJiYgbGF0ZXN0VmFsdWUgIT09IHYxICYmIHVwZGF0ZShsYXRlc3RWYWx1ZSk7XG4gICAgcmV0dXJuIHQxID09PSB0MiB8fCB0IC0gdDIgPiBkcm9wVG9aZXJvVGltZSA/IDAgOiAodjEgKyAodXNlRGVsdGEgPyB2T2xkIDogLXZPbGQpKSAvICgodXNlRGVsdGEgPyB0IDogdDEpIC0gdE9sZCkgKiAxMDAwO1xuICB9O1xuXG4gIHJldHVybiB7XG4gICAgdXBkYXRlOiB1cGRhdGUsXG4gICAgcmVzZXQ6IHJlc2V0LFxuICAgIGdldFZlbG9jaXR5OiBnZXRWZWxvY2l0eVxuICB9O1xufSxcbiAgICBfZ2V0RXZlbnQgPSBmdW5jdGlvbiBfZ2V0RXZlbnQoZSwgcHJldmVudERlZmF1bHQpIHtcbiAgcHJldmVudERlZmF1bHQgJiYgIWUuX2dzYXBBbGxvdyAmJiBlLmNhbmNlbGFibGUgIT09IGZhbHNlICYmIGUucHJldmVudERlZmF1bHQoKTtcbiAgcmV0dXJuIGUuY2hhbmdlZFRvdWNoZXMgPyBlLmNoYW5nZWRUb3VjaGVzWzBdIDogZTtcbn0sXG4gICAgX2dldEFic29sdXRlTWF4ID0gZnVuY3Rpb24gX2dldEFic29sdXRlTWF4KGEpIHtcbiAgdmFyIG1heCA9IE1hdGgubWF4LmFwcGx5KE1hdGgsIGEpLFxuICAgICAgbWluID0gTWF0aC5taW4uYXBwbHkoTWF0aCwgYSk7XG4gIHJldHVybiBNYXRoLmFicyhtYXgpID49IE1hdGguYWJzKG1pbikgPyBtYXggOiBtaW47XG59LFxuICAgIF9zZXRTY3JvbGxUcmlnZ2VyID0gZnVuY3Rpb24gX3NldFNjcm9sbFRyaWdnZXIoKSB7XG4gIFNjcm9sbFRyaWdnZXIgPSBnc2FwLmNvcmUuZ2xvYmFscygpLlNjcm9sbFRyaWdnZXI7XG4gIFNjcm9sbFRyaWdnZXIgJiYgU2Nyb2xsVHJpZ2dlci5jb3JlICYmIF9pbnRlZ3JhdGUoKTtcbn0sXG4gICAgX2luaXRDb3JlID0gZnVuY3Rpb24gX2luaXRDb3JlKGNvcmUpIHtcbiAgZ3NhcCA9IGNvcmUgfHwgX2dldEdTQVAoKTtcblxuICBpZiAoIV9jb3JlSW5pdHRlZCAmJiBnc2FwICYmIHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIiAmJiBkb2N1bWVudC5ib2R5KSB7XG4gICAgX3dpbiA9IHdpbmRvdztcbiAgICBfZG9jID0gZG9jdW1lbnQ7XG4gICAgX2RvY0VsID0gX2RvYy5kb2N1bWVudEVsZW1lbnQ7XG4gICAgX2JvZHkgPSBfZG9jLmJvZHk7XG4gICAgX3Jvb3QgPSBbX3dpbiwgX2RvYywgX2RvY0VsLCBfYm9keV07XG4gICAgX2NsYW1wID0gZ3NhcC51dGlscy5jbGFtcDtcblxuICAgIF9jb250ZXh0ID0gZ3NhcC5jb3JlLmNvbnRleHQgfHwgZnVuY3Rpb24gKCkge307XG5cbiAgICBfcG9pbnRlclR5cGUgPSBcIm9ucG9pbnRlcmVudGVyXCIgaW4gX2JvZHkgPyBcInBvaW50ZXJcIiA6IFwibW91c2VcIjsgLy8gaXNUb3VjaCBpcyAwIGlmIG5vIHRvdWNoLCAxIGlmIE9OTFkgdG91Y2gsIGFuZCAyIGlmIGl0IGNhbiBhY2NvbW1vZGF0ZSB0b3VjaCBidXQgYWxzbyBvdGhlciB0eXBlcyBsaWtlIG1vdXNlL3BvaW50ZXIuXG5cbiAgICBfaXNUb3VjaCA9IE9ic2VydmVyLmlzVG91Y2ggPSBfd2luLm1hdGNoTWVkaWEgJiYgX3dpbi5tYXRjaE1lZGlhKFwiKGhvdmVyOiBub25lKSwgKHBvaW50ZXI6IGNvYXJzZSlcIikubWF0Y2hlcyA/IDEgOiBcIm9udG91Y2hzdGFydFwiIGluIF93aW4gfHwgbmF2aWdhdG9yLm1heFRvdWNoUG9pbnRzID4gMCB8fCBuYXZpZ2F0b3IubXNNYXhUb3VjaFBvaW50cyA+IDAgPyAyIDogMDtcbiAgICBfZXZlbnRUeXBlcyA9IE9ic2VydmVyLmV2ZW50VHlwZXMgPSAoXCJvbnRvdWNoc3RhcnRcIiBpbiBfZG9jRWwgPyBcInRvdWNoc3RhcnQsdG91Y2htb3ZlLHRvdWNoY2FuY2VsLHRvdWNoZW5kXCIgOiAhKFwib25wb2ludGVyZG93blwiIGluIF9kb2NFbCkgPyBcIm1vdXNlZG93bixtb3VzZW1vdmUsbW91c2V1cCxtb3VzZXVwXCIgOiBcInBvaW50ZXJkb3duLHBvaW50ZXJtb3ZlLHBvaW50ZXJjYW5jZWwscG9pbnRlcnVwXCIpLnNwbGl0KFwiLFwiKTtcbiAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiBfc3RhcnR1cCA9IDA7XG4gICAgfSwgNTAwKTtcbiAgICBfY29yZUluaXR0ZWQgPSAxO1xuICB9XG5cbiAgU2Nyb2xsVHJpZ2dlciB8fCBfc2V0U2Nyb2xsVHJpZ2dlcigpOyAvLyBPYnNlcnZlciBtaWdodCBiZSBpbml0dGVkIEJFRk9SRSBTY3JvbGxUcmlnZ2VyLCBzbyBkb24ndCBwdXQgdGhpcyB3aXRoIHRoZSBpbml0dGluZyBjb2RlLiBTY3JvbGxUcmlnZ2VyIHdpbGwgY2FsbCBPYnNlcnZlci5yZWdpc3RlcigpIHdoZW4gaXQgaW5pdHMuXG5cbiAgcmV0dXJuIF9jb3JlSW5pdHRlZDtcbn07XG5cbl9ob3Jpem9udGFsLm9wID0gX3ZlcnRpY2FsO1xuX3Njcm9sbGVycy5jYWNoZSA9IDA7XG5leHBvcnQgdmFyIE9ic2VydmVyID0gLyojX19QVVJFX18qL2Z1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gT2JzZXJ2ZXIodmFycykge1xuICAgIHRoaXMuaW5pdCh2YXJzKTtcbiAgfVxuXG4gIHZhciBfcHJvdG8gPSBPYnNlcnZlci5wcm90b3R5cGU7XG5cbiAgX3Byb3RvLmluaXQgPSBmdW5jdGlvbiBpbml0KHZhcnMpIHtcbiAgICBfY29yZUluaXR0ZWQgfHwgX2luaXRDb3JlKGdzYXApIHx8IGNvbnNvbGUud2FybihcIlBsZWFzZSBnc2FwLnJlZ2lzdGVyUGx1Z2luKE9ic2VydmVyKVwiKTtcbiAgICBTY3JvbGxUcmlnZ2VyIHx8IF9zZXRTY3JvbGxUcmlnZ2VyKCk7XG4gICAgdmFyIHRvbGVyYW5jZSA9IHZhcnMudG9sZXJhbmNlLFxuICAgICAgICBkcmFnTWluaW11bSA9IHZhcnMuZHJhZ01pbmltdW0sXG4gICAgICAgIHR5cGUgPSB2YXJzLnR5cGUsXG4gICAgICAgIHRhcmdldCA9IHZhcnMudGFyZ2V0LFxuICAgICAgICBsaW5lSGVpZ2h0ID0gdmFycy5saW5lSGVpZ2h0LFxuICAgICAgICBkZWJvdW5jZSA9IHZhcnMuZGVib3VuY2UsXG4gICAgICAgIHByZXZlbnREZWZhdWx0ID0gdmFycy5wcmV2ZW50RGVmYXVsdCxcbiAgICAgICAgb25TdG9wID0gdmFycy5vblN0b3AsXG4gICAgICAgIG9uU3RvcERlbGF5ID0gdmFycy5vblN0b3BEZWxheSxcbiAgICAgICAgaWdub3JlID0gdmFycy5pZ25vcmUsXG4gICAgICAgIHdoZWVsU3BlZWQgPSB2YXJzLndoZWVsU3BlZWQsXG4gICAgICAgIGV2ZW50ID0gdmFycy5ldmVudCxcbiAgICAgICAgb25EcmFnU3RhcnQgPSB2YXJzLm9uRHJhZ1N0YXJ0LFxuICAgICAgICBvbkRyYWdFbmQgPSB2YXJzLm9uRHJhZ0VuZCxcbiAgICAgICAgb25EcmFnID0gdmFycy5vbkRyYWcsXG4gICAgICAgIG9uUHJlc3MgPSB2YXJzLm9uUHJlc3MsXG4gICAgICAgIG9uUmVsZWFzZSA9IHZhcnMub25SZWxlYXNlLFxuICAgICAgICBvblJpZ2h0ID0gdmFycy5vblJpZ2h0LFxuICAgICAgICBvbkxlZnQgPSB2YXJzLm9uTGVmdCxcbiAgICAgICAgb25VcCA9IHZhcnMub25VcCxcbiAgICAgICAgb25Eb3duID0gdmFycy5vbkRvd24sXG4gICAgICAgIG9uQ2hhbmdlWCA9IHZhcnMub25DaGFuZ2VYLFxuICAgICAgICBvbkNoYW5nZVkgPSB2YXJzLm9uQ2hhbmdlWSxcbiAgICAgICAgb25DaGFuZ2UgPSB2YXJzLm9uQ2hhbmdlLFxuICAgICAgICBvblRvZ2dsZVggPSB2YXJzLm9uVG9nZ2xlWCxcbiAgICAgICAgb25Ub2dnbGVZID0gdmFycy5vblRvZ2dsZVksXG4gICAgICAgIG9uSG92ZXIgPSB2YXJzLm9uSG92ZXIsXG4gICAgICAgIG9uSG92ZXJFbmQgPSB2YXJzLm9uSG92ZXJFbmQsXG4gICAgICAgIG9uTW92ZSA9IHZhcnMub25Nb3ZlLFxuICAgICAgICBpZ25vcmVDaGVjayA9IHZhcnMuaWdub3JlQ2hlY2ssXG4gICAgICAgIGlzTm9ybWFsaXplciA9IHZhcnMuaXNOb3JtYWxpemVyLFxuICAgICAgICBvbkdlc3R1cmVTdGFydCA9IHZhcnMub25HZXN0dXJlU3RhcnQsXG4gICAgICAgIG9uR2VzdHVyZUVuZCA9IHZhcnMub25HZXN0dXJlRW5kLFxuICAgICAgICBvbldoZWVsID0gdmFycy5vbldoZWVsLFxuICAgICAgICBvbkVuYWJsZSA9IHZhcnMub25FbmFibGUsXG4gICAgICAgIG9uRGlzYWJsZSA9IHZhcnMub25EaXNhYmxlLFxuICAgICAgICBvbkNsaWNrID0gdmFycy5vbkNsaWNrLFxuICAgICAgICBzY3JvbGxTcGVlZCA9IHZhcnMuc2Nyb2xsU3BlZWQsXG4gICAgICAgIGNhcHR1cmUgPSB2YXJzLmNhcHR1cmUsXG4gICAgICAgIGFsbG93Q2xpY2tzID0gdmFycy5hbGxvd0NsaWNrcyxcbiAgICAgICAgbG9ja0F4aXMgPSB2YXJzLmxvY2tBeGlzLFxuICAgICAgICBvbkxvY2tBeGlzID0gdmFycy5vbkxvY2tBeGlzO1xuICAgIHRoaXMudGFyZ2V0ID0gdGFyZ2V0ID0gX2dldFRhcmdldCh0YXJnZXQpIHx8IF9kb2NFbDtcbiAgICB0aGlzLnZhcnMgPSB2YXJzO1xuICAgIGlnbm9yZSAmJiAoaWdub3JlID0gZ3NhcC51dGlscy50b0FycmF5KGlnbm9yZSkpO1xuICAgIHRvbGVyYW5jZSA9IHRvbGVyYW5jZSB8fCAxZS05O1xuICAgIGRyYWdNaW5pbXVtID0gZHJhZ01pbmltdW0gfHwgMDtcbiAgICB3aGVlbFNwZWVkID0gd2hlZWxTcGVlZCB8fCAxO1xuICAgIHNjcm9sbFNwZWVkID0gc2Nyb2xsU3BlZWQgfHwgMTtcbiAgICB0eXBlID0gdHlwZSB8fCBcIndoZWVsLHRvdWNoLHBvaW50ZXJcIjtcbiAgICBkZWJvdW5jZSA9IGRlYm91bmNlICE9PSBmYWxzZTtcbiAgICBsaW5lSGVpZ2h0IHx8IChsaW5lSGVpZ2h0ID0gcGFyc2VGbG9hdChfd2luLmdldENvbXB1dGVkU3R5bGUoX2JvZHkpLmxpbmVIZWlnaHQpIHx8IDIyKTsgLy8gbm90ZTogYnJvd3NlciBtYXkgcmVwb3J0IFwibm9ybWFsXCIsIHNvIGRlZmF1bHQgdG8gMjIuXG5cbiAgICB2YXIgaWQsXG4gICAgICAgIG9uU3RvcERlbGF5ZWRDYWxsLFxuICAgICAgICBkcmFnZ2VkLFxuICAgICAgICBtb3ZlZCxcbiAgICAgICAgd2hlZWxlZCxcbiAgICAgICAgbG9ja2VkLFxuICAgICAgICBheGlzLFxuICAgICAgICBzZWxmID0gdGhpcyxcbiAgICAgICAgcHJldkRlbHRhWCA9IDAsXG4gICAgICAgIHByZXZEZWx0YVkgPSAwLFxuICAgICAgICBwYXNzaXZlID0gdmFycy5wYXNzaXZlIHx8ICFwcmV2ZW50RGVmYXVsdCAmJiB2YXJzLnBhc3NpdmUgIT09IGZhbHNlLFxuICAgICAgICBzY3JvbGxGdW5jWCA9IF9nZXRTY3JvbGxGdW5jKHRhcmdldCwgX2hvcml6b250YWwpLFxuICAgICAgICBzY3JvbGxGdW5jWSA9IF9nZXRTY3JvbGxGdW5jKHRhcmdldCwgX3ZlcnRpY2FsKSxcbiAgICAgICAgc2Nyb2xsWCA9IHNjcm9sbEZ1bmNYKCksXG4gICAgICAgIHNjcm9sbFkgPSBzY3JvbGxGdW5jWSgpLFxuICAgICAgICBsaW1pdFRvVG91Y2ggPSB+dHlwZS5pbmRleE9mKFwidG91Y2hcIikgJiYgIX50eXBlLmluZGV4T2YoXCJwb2ludGVyXCIpICYmIF9ldmVudFR5cGVzWzBdID09PSBcInBvaW50ZXJkb3duXCIsXG4gICAgICAgIC8vIGZvciBkZXZpY2VzIHRoYXQgYWNjb21tb2RhdGUgbW91c2UgZXZlbnRzIGFuZCB0b3VjaCBldmVudHMsIHdlIG5lZWQgdG8gZGlzdGluZ3Vpc2guXG4gICAgaXNWaWV3cG9ydCA9IF9pc1ZpZXdwb3J0KHRhcmdldCksXG4gICAgICAgIG93bmVyRG9jID0gdGFyZ2V0Lm93bmVyRG9jdW1lbnQgfHwgX2RvYyxcbiAgICAgICAgZGVsdGFYID0gWzAsIDAsIDBdLFxuICAgICAgICAvLyB3aGVlbCwgc2Nyb2xsLCBwb2ludGVyL3RvdWNoXG4gICAgZGVsdGFZID0gWzAsIDAsIDBdLFxuICAgICAgICBvbkNsaWNrVGltZSA9IDAsXG4gICAgICAgIGNsaWNrQ2FwdHVyZSA9IGZ1bmN0aW9uIGNsaWNrQ2FwdHVyZSgpIHtcbiAgICAgIHJldHVybiBvbkNsaWNrVGltZSA9IF9nZXRUaW1lKCk7XG4gICAgfSxcbiAgICAgICAgX2lnbm9yZUNoZWNrID0gZnVuY3Rpb24gX2lnbm9yZUNoZWNrKGUsIGlzUG9pbnRlck9yVG91Y2gpIHtcbiAgICAgIHJldHVybiAoc2VsZi5ldmVudCA9IGUpICYmIGlnbm9yZSAmJiBfaXNXaXRoaW4oZS50YXJnZXQsIGlnbm9yZSkgfHwgaXNQb2ludGVyT3JUb3VjaCAmJiBsaW1pdFRvVG91Y2ggJiYgZS5wb2ludGVyVHlwZSAhPT0gXCJ0b3VjaFwiIHx8IGlnbm9yZUNoZWNrICYmIGlnbm9yZUNoZWNrKGUsIGlzUG9pbnRlck9yVG91Y2gpO1xuICAgIH0sXG4gICAgICAgIG9uU3RvcEZ1bmMgPSBmdW5jdGlvbiBvblN0b3BGdW5jKCkge1xuICAgICAgc2VsZi5fdngucmVzZXQoKTtcblxuICAgICAgc2VsZi5fdnkucmVzZXQoKTtcblxuICAgICAgb25TdG9wRGVsYXllZENhbGwucGF1c2UoKTtcbiAgICAgIG9uU3RvcCAmJiBvblN0b3Aoc2VsZik7XG4gICAgfSxcbiAgICAgICAgdXBkYXRlID0gZnVuY3Rpb24gdXBkYXRlKCkge1xuICAgICAgdmFyIGR4ID0gc2VsZi5kZWx0YVggPSBfZ2V0QWJzb2x1dGVNYXgoZGVsdGFYKSxcbiAgICAgICAgICBkeSA9IHNlbGYuZGVsdGFZID0gX2dldEFic29sdXRlTWF4KGRlbHRhWSksXG4gICAgICAgICAgY2hhbmdlZFggPSBNYXRoLmFicyhkeCkgPj0gdG9sZXJhbmNlLFxuICAgICAgICAgIGNoYW5nZWRZID0gTWF0aC5hYnMoZHkpID49IHRvbGVyYW5jZTtcblxuICAgICAgb25DaGFuZ2UgJiYgKGNoYW5nZWRYIHx8IGNoYW5nZWRZKSAmJiBvbkNoYW5nZShzZWxmLCBkeCwgZHksIGRlbHRhWCwgZGVsdGFZKTsgLy8gaW4gU2Nyb2xsVHJpZ2dlci5ub3JtYWxpemVTY3JvbGwoKSwgd2UgbmVlZCB0byBrbm93IGlmIGl0IHdhcyB0b3VjaC9wb2ludGVyIHNvIHdlIG5lZWQgYWNjZXNzIHRvIHRoZSBkZWx0YVgvZGVsdGFZIEFycmF5cyBiZWZvcmUgd2UgY2xlYXIgdGhlbSBvdXQuXG5cbiAgICAgIGlmIChjaGFuZ2VkWCkge1xuICAgICAgICBvblJpZ2h0ICYmIHNlbGYuZGVsdGFYID4gMCAmJiBvblJpZ2h0KHNlbGYpO1xuICAgICAgICBvbkxlZnQgJiYgc2VsZi5kZWx0YVggPCAwICYmIG9uTGVmdChzZWxmKTtcbiAgICAgICAgb25DaGFuZ2VYICYmIG9uQ2hhbmdlWChzZWxmKTtcbiAgICAgICAgb25Ub2dnbGVYICYmIHNlbGYuZGVsdGFYIDwgMCAhPT0gcHJldkRlbHRhWCA8IDAgJiYgb25Ub2dnbGVYKHNlbGYpO1xuICAgICAgICBwcmV2RGVsdGFYID0gc2VsZi5kZWx0YVg7XG4gICAgICAgIGRlbHRhWFswXSA9IGRlbHRhWFsxXSA9IGRlbHRhWFsyXSA9IDA7XG4gICAgICB9XG5cbiAgICAgIGlmIChjaGFuZ2VkWSkge1xuICAgICAgICBvbkRvd24gJiYgc2VsZi5kZWx0YVkgPiAwICYmIG9uRG93bihzZWxmKTtcbiAgICAgICAgb25VcCAmJiBzZWxmLmRlbHRhWSA8IDAgJiYgb25VcChzZWxmKTtcbiAgICAgICAgb25DaGFuZ2VZICYmIG9uQ2hhbmdlWShzZWxmKTtcbiAgICAgICAgb25Ub2dnbGVZICYmIHNlbGYuZGVsdGFZIDwgMCAhPT0gcHJldkRlbHRhWSA8IDAgJiYgb25Ub2dnbGVZKHNlbGYpO1xuICAgICAgICBwcmV2RGVsdGFZID0gc2VsZi5kZWx0YVk7XG4gICAgICAgIGRlbHRhWVswXSA9IGRlbHRhWVsxXSA9IGRlbHRhWVsyXSA9IDA7XG4gICAgICB9XG5cbiAgICAgIGlmIChtb3ZlZCB8fCBkcmFnZ2VkKSB7XG4gICAgICAgIG9uTW92ZSAmJiBvbk1vdmUoc2VsZik7XG5cbiAgICAgICAgaWYgKGRyYWdnZWQpIHtcbiAgICAgICAgICBvbkRyYWdTdGFydCAmJiBkcmFnZ2VkID09PSAxICYmIG9uRHJhZ1N0YXJ0KHNlbGYpO1xuICAgICAgICAgIG9uRHJhZyAmJiBvbkRyYWcoc2VsZik7XG4gICAgICAgICAgZHJhZ2dlZCA9IDA7XG4gICAgICAgIH1cblxuICAgICAgICBtb3ZlZCA9IGZhbHNlO1xuICAgICAgfVxuXG4gICAgICBsb2NrZWQgJiYgIShsb2NrZWQgPSBmYWxzZSkgJiYgb25Mb2NrQXhpcyAmJiBvbkxvY2tBeGlzKHNlbGYpO1xuXG4gICAgICBpZiAod2hlZWxlZCkge1xuICAgICAgICBvbldoZWVsKHNlbGYpO1xuICAgICAgICB3aGVlbGVkID0gZmFsc2U7XG4gICAgICB9XG5cbiAgICAgIGlkID0gMDtcbiAgICB9LFxuICAgICAgICBvbkRlbHRhID0gZnVuY3Rpb24gb25EZWx0YSh4LCB5LCBpbmRleCkge1xuICAgICAgZGVsdGFYW2luZGV4XSArPSB4O1xuICAgICAgZGVsdGFZW2luZGV4XSArPSB5O1xuXG4gICAgICBzZWxmLl92eC51cGRhdGUoeCk7XG5cbiAgICAgIHNlbGYuX3Z5LnVwZGF0ZSh5KTtcblxuICAgICAgZGVib3VuY2UgPyBpZCB8fCAoaWQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodXBkYXRlKSkgOiB1cGRhdGUoKTtcbiAgICB9LFxuICAgICAgICBvblRvdWNoT3JQb2ludGVyRGVsdGEgPSBmdW5jdGlvbiBvblRvdWNoT3JQb2ludGVyRGVsdGEoeCwgeSkge1xuICAgICAgaWYgKGxvY2tBeGlzICYmICFheGlzKSB7XG4gICAgICAgIHNlbGYuYXhpcyA9IGF4aXMgPSBNYXRoLmFicyh4KSA+IE1hdGguYWJzKHkpID8gXCJ4XCIgOiBcInlcIjtcbiAgICAgICAgbG9ja2VkID0gdHJ1ZTtcbiAgICAgIH1cblxuICAgICAgaWYgKGF4aXMgIT09IFwieVwiKSB7XG4gICAgICAgIGRlbHRhWFsyXSArPSB4O1xuXG4gICAgICAgIHNlbGYuX3Z4LnVwZGF0ZSh4LCB0cnVlKTsgLy8gdXBkYXRlIHRoZSB2ZWxvY2l0eSBhcyBmcmVxdWVudGx5IGFzIHBvc3NpYmxlIGluc3RlYWQgb2YgaW4gdGhlIGRlYm91bmNlZCBmdW5jdGlvbiBzbyB0aGF0IHZlcnkgcXVpY2sgdG91Y2gtc2Nyb2xscyAoZmxpY2tzKSBmZWVsIG5hdHVyYWwuIElmIGl0J3MgdGhlIG1vdXNlL3RvdWNoL3BvaW50ZXIsIGZvcmNlIGl0IHNvIHRoYXQgd2UgZ2V0IHNuYXBweS9hY2N1cmF0ZSBtb21lbnR1bSBzY3JvbGwuXG5cbiAgICAgIH1cblxuICAgICAgaWYgKGF4aXMgIT09IFwieFwiKSB7XG4gICAgICAgIGRlbHRhWVsyXSArPSB5O1xuXG4gICAgICAgIHNlbGYuX3Z5LnVwZGF0ZSh5LCB0cnVlKTtcbiAgICAgIH1cblxuICAgICAgZGVib3VuY2UgPyBpZCB8fCAoaWQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodXBkYXRlKSkgOiB1cGRhdGUoKTtcbiAgICB9LFxuICAgICAgICBfb25EcmFnID0gZnVuY3Rpb24gX29uRHJhZyhlKSB7XG4gICAgICBpZiAoX2lnbm9yZUNoZWNrKGUsIDEpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgZSA9IF9nZXRFdmVudChlLCBwcmV2ZW50RGVmYXVsdCk7XG4gICAgICB2YXIgeCA9IGUuY2xpZW50WCxcbiAgICAgICAgICB5ID0gZS5jbGllbnRZLFxuICAgICAgICAgIGR4ID0geCAtIHNlbGYueCxcbiAgICAgICAgICBkeSA9IHkgLSBzZWxmLnksXG4gICAgICAgICAgaXNEcmFnZ2luZyA9IHNlbGYuaXNEcmFnZ2luZztcbiAgICAgIHNlbGYueCA9IHg7XG4gICAgICBzZWxmLnkgPSB5O1xuXG4gICAgICBpZiAoaXNEcmFnZ2luZyB8fCAoZHggfHwgZHkpICYmIChNYXRoLmFicyhzZWxmLnN0YXJ0WCAtIHgpID49IGRyYWdNaW5pbXVtIHx8IE1hdGguYWJzKHNlbGYuc3RhcnRZIC0geSkgPj0gZHJhZ01pbmltdW0pKSB7XG4gICAgICAgIGRyYWdnZWQgfHwgKGRyYWdnZWQgPSBpc0RyYWdnaW5nID8gMiA6IDEpOyAvLyBkcmFnZ2VkOiAwID0gbm90IGRyYWdnaW5nLCAxID0gZmlyc3QgZHJhZywgMiA9IG5vcm1hbCBkcmFnXG5cbiAgICAgICAgaXNEcmFnZ2luZyB8fCAoc2VsZi5pc0RyYWdnaW5nID0gdHJ1ZSk7XG4gICAgICAgIG9uVG91Y2hPclBvaW50ZXJEZWx0YShkeCwgZHkpO1xuICAgICAgfVxuICAgIH0sXG4gICAgICAgIF9vblByZXNzID0gc2VsZi5vblByZXNzID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgIGlmIChfaWdub3JlQ2hlY2soZSwgMSkgfHwgZSAmJiBlLmJ1dHRvbikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIHNlbGYuYXhpcyA9IGF4aXMgPSBudWxsO1xuICAgICAgb25TdG9wRGVsYXllZENhbGwucGF1c2UoKTtcbiAgICAgIHNlbGYuaXNQcmVzc2VkID0gdHJ1ZTtcbiAgICAgIGUgPSBfZ2V0RXZlbnQoZSk7IC8vIG5vdGU6IG1heSBuZWVkIHRvIHByZXZlbnREZWZhdWx0KD8pIFdvbid0IHNpZGUtc2Nyb2xsIG9uIGlPUyBTYWZhcmkgaWYgd2UgZG8sIHRob3VnaC5cblxuICAgICAgcHJldkRlbHRhWCA9IHByZXZEZWx0YVkgPSAwO1xuICAgICAgc2VsZi5zdGFydFggPSBzZWxmLnggPSBlLmNsaWVudFg7XG4gICAgICBzZWxmLnN0YXJ0WSA9IHNlbGYueSA9IGUuY2xpZW50WTtcblxuICAgICAgc2VsZi5fdngucmVzZXQoKTsgLy8gb3RoZXJ3aXNlIHRoZSB0MiBtYXkgYmUgc3RhbGUgaWYgdGhlIHVzZXIgdG91Y2hlcyBhbmQgZmxpY2tzIHN1cGVyIGZhc3QgYW5kIHJlbGVhc2VzIGluIGxlc3MgdGhhbiAyIHJlcXVlc3RBbmltYXRpb25GcmFtZSB0aWNrcywgY2F1c2luZyB2ZWxvY2l0eSB0byBiZSAwLlxuXG5cbiAgICAgIHNlbGYuX3Z5LnJlc2V0KCk7XG5cbiAgICAgIF9hZGRMaXN0ZW5lcihpc05vcm1hbGl6ZXIgPyB0YXJnZXQgOiBvd25lckRvYywgX2V2ZW50VHlwZXNbMV0sIF9vbkRyYWcsIHBhc3NpdmUsIHRydWUpO1xuXG4gICAgICBzZWxmLmRlbHRhWCA9IHNlbGYuZGVsdGFZID0gMDtcbiAgICAgIG9uUHJlc3MgJiYgb25QcmVzcyhzZWxmKTtcbiAgICB9LFxuICAgICAgICBfb25SZWxlYXNlID0gc2VsZi5vblJlbGVhc2UgPSBmdW5jdGlvbiAoZSkge1xuICAgICAgaWYgKF9pZ25vcmVDaGVjayhlLCAxKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIF9yZW1vdmVMaXN0ZW5lcihpc05vcm1hbGl6ZXIgPyB0YXJnZXQgOiBvd25lckRvYywgX2V2ZW50VHlwZXNbMV0sIF9vbkRyYWcsIHRydWUpO1xuXG4gICAgICB2YXIgaXNUcmFja2luZ0RyYWcgPSAhaXNOYU4oc2VsZi55IC0gc2VsZi5zdGFydFkpLFxuICAgICAgICAgIHdhc0RyYWdnaW5nID0gc2VsZi5pc0RyYWdnaW5nLFxuICAgICAgICAgIGlzRHJhZ05vdENsaWNrID0gd2FzRHJhZ2dpbmcgJiYgKE1hdGguYWJzKHNlbGYueCAtIHNlbGYuc3RhcnRYKSA+IDMgfHwgTWF0aC5hYnMoc2VsZi55IC0gc2VsZi5zdGFydFkpID4gMyksXG4gICAgICAgICAgLy8gc29tZSB0b3VjaCBkZXZpY2VzIG5lZWQgc29tZSB3aWdnbGUgcm9vbSBpbiB0ZXJtcyBvZiBzZW5zaW5nIGNsaWNrcyAtIHRoZSBmaW5nZXIgbWF5IG1vdmUgYSBmZXcgcGl4ZWxzLlxuICAgICAgZXZlbnREYXRhID0gX2dldEV2ZW50KGUpO1xuXG4gICAgICBpZiAoIWlzRHJhZ05vdENsaWNrICYmIGlzVHJhY2tpbmdEcmFnKSB7XG4gICAgICAgIHNlbGYuX3Z4LnJlc2V0KCk7XG5cbiAgICAgICAgc2VsZi5fdnkucmVzZXQoKTsgLy9pZiAocHJldmVudERlZmF1bHQgJiYgYWxsb3dDbGlja3MgJiYgc2VsZi5pc1ByZXNzZWQpIHsgLy8gY2hlY2sgaXNQcmVzc2VkIGJlY2F1c2UgaW4gYSByYXJlIGVkZ2UgY2FzZSwgdGhlIGlucHV0T2JzZXJ2ZXIgaW4gU2Nyb2xsVHJpZ2dlciBtYXkgc3RvcFByb3BhZ2F0aW9uKCkgb24gdGhlIHByZXNzL2RyYWcsIHNvIHRoZSBvblJlbGVhc2UgbWF5IGdldCBmaXJlZCB3aXRob3V0IHRoZSBvblByZXNzL29uRHJhZyBldmVyIGdldHRpbmcgY2FsbGVkLCB0aHVzIGl0IGNvdWxkIHRyaWdnZXIgYSBjbGljayB0byBvY2N1ciBvbiBhIGxpbmsgYWZ0ZXIgc2Nyb2xsLWRyYWdnaW5nIGl0LlxuXG5cbiAgICAgICAgaWYgKHByZXZlbnREZWZhdWx0ICYmIGFsbG93Q2xpY2tzKSB7XG4gICAgICAgICAgZ3NhcC5kZWxheWVkQ2FsbCgwLjA4LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAvLyBzb21lIGJyb3dzZXJzIChsaWtlIEZpcmVmb3gpIHdvbid0IHRydXN0IHNjcmlwdC1nZW5lcmF0ZWQgY2xpY2tzLCBzbyBpZiB0aGUgdXNlciB0cmllcyB0byBjbGljayBvbiBhIHZpZGVvIHRvIHBsYXkgaXQsIGZvciBleGFtcGxlLCBpdCBzaW1wbHkgd29uJ3Qgd29yay4gU2luY2UgYSByZWd1bGFyIFwiY2xpY2tcIiBldmVudCB3aWxsIG1vc3QgbGlrZWx5IGJlIGdlbmVyYXRlZCBhbnl3YXkgKG9uZSB0aGF0IGhhcyBpdHMgaXNUcnVzdGVkIGZsYWcgc2V0IHRvIHRydWUpLCB3ZSBtdXN0IHNsaWdodGx5IGRlbGF5IG91ciBzY3JpcHQtZ2VuZXJhdGVkIGNsaWNrIHNvIHRoYXQgdGhlIFwicmVhbFwiL3RydXN0ZWQgb25lIGlzIHByaW9yaXRpemVkLiBSZW1lbWJlciwgd2hlbiB0aGVyZSBhcmUgZHVwbGljYXRlIGV2ZW50cyBpbiBxdWljayBzdWNjZXNzaW9uLCB3ZSBzdXBwcmVzcyBhbGwgYnV0IHRoZSBmaXJzdCBvbmUuIFNvbWUgYnJvd3NlcnMgZG9uJ3QgZXZlbiB0cmlnZ2VyIHRoZSBcInJlYWxcIiBvbmUgYXQgYWxsLCBzbyBvdXIgc3ludGhldGljIG9uZSBpcyBhIHNhZmV0eSB2YWx2ZSB0aGF0IGVuc3VyZXMgdGhhdCBubyBtYXR0ZXIgd2hhdCwgYSBjbGljayBldmVudCBkb2VzIGdldCBkaXNwYXRjaGVkLlxuICAgICAgICAgICAgaWYgKF9nZXRUaW1lKCkgLSBvbkNsaWNrVGltZSA+IDMwMCAmJiAhZS5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgICAgIGlmIChlLnRhcmdldC5jbGljaykge1xuICAgICAgICAgICAgICAgIC8vc29tZSBicm93c2VycyAobGlrZSBtb2JpbGUgU2FmYXJpKSBkb24ndCBwcm9wZXJseSB0cmlnZ2VyIHRoZSBjbGljayBldmVudFxuICAgICAgICAgICAgICAgIGUudGFyZ2V0LmNsaWNrKCk7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAob3duZXJEb2MuY3JlYXRlRXZlbnQpIHtcbiAgICAgICAgICAgICAgICB2YXIgc3ludGhldGljRXZlbnQgPSBvd25lckRvYy5jcmVhdGVFdmVudChcIk1vdXNlRXZlbnRzXCIpO1xuICAgICAgICAgICAgICAgIHN5bnRoZXRpY0V2ZW50LmluaXRNb3VzZUV2ZW50KFwiY2xpY2tcIiwgdHJ1ZSwgdHJ1ZSwgX3dpbiwgMSwgZXZlbnREYXRhLnNjcmVlblgsIGV2ZW50RGF0YS5zY3JlZW5ZLCBldmVudERhdGEuY2xpZW50WCwgZXZlbnREYXRhLmNsaWVudFksIGZhbHNlLCBmYWxzZSwgZmFsc2UsIGZhbHNlLCAwLCBudWxsKTtcbiAgICAgICAgICAgICAgICBlLnRhcmdldC5kaXNwYXRjaEV2ZW50KHN5bnRoZXRpY0V2ZW50KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHNlbGYuaXNEcmFnZ2luZyA9IHNlbGYuaXNHZXN0dXJpbmcgPSBzZWxmLmlzUHJlc3NlZCA9IGZhbHNlO1xuICAgICAgb25TdG9wICYmIHdhc0RyYWdnaW5nICYmICFpc05vcm1hbGl6ZXIgJiYgb25TdG9wRGVsYXllZENhbGwucmVzdGFydCh0cnVlKTtcbiAgICAgIGRyYWdnZWQgJiYgdXBkYXRlKCk7IC8vIGluIGNhc2UgZGVib3VuY2luZywgd2UgZG9uJ3Qgd2FudCBvbkRyYWcgdG8gZmlyZSBBRlRFUiBvbkRyYWdFbmQoKS5cblxuICAgICAgb25EcmFnRW5kICYmIHdhc0RyYWdnaW5nICYmIG9uRHJhZ0VuZChzZWxmKTtcbiAgICAgIG9uUmVsZWFzZSAmJiBvblJlbGVhc2Uoc2VsZiwgaXNEcmFnTm90Q2xpY2spO1xuICAgIH0sXG4gICAgICAgIF9vbkdlc3R1cmVTdGFydCA9IGZ1bmN0aW9uIF9vbkdlc3R1cmVTdGFydChlKSB7XG4gICAgICByZXR1cm4gZS50b3VjaGVzICYmIGUudG91Y2hlcy5sZW5ndGggPiAxICYmIChzZWxmLmlzR2VzdHVyaW5nID0gdHJ1ZSkgJiYgb25HZXN0dXJlU3RhcnQoZSwgc2VsZi5pc0RyYWdnaW5nKTtcbiAgICB9LFxuICAgICAgICBfb25HZXN0dXJlRW5kID0gZnVuY3Rpb24gX29uR2VzdHVyZUVuZCgpIHtcbiAgICAgIHJldHVybiAoc2VsZi5pc0dlc3R1cmluZyA9IGZhbHNlKSB8fCBvbkdlc3R1cmVFbmQoc2VsZik7XG4gICAgfSxcbiAgICAgICAgb25TY3JvbGwgPSBmdW5jdGlvbiBvblNjcm9sbChlKSB7XG4gICAgICBpZiAoX2lnbm9yZUNoZWNrKGUpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgdmFyIHggPSBzY3JvbGxGdW5jWCgpLFxuICAgICAgICAgIHkgPSBzY3JvbGxGdW5jWSgpO1xuICAgICAgb25EZWx0YSgoeCAtIHNjcm9sbFgpICogc2Nyb2xsU3BlZWQsICh5IC0gc2Nyb2xsWSkgKiBzY3JvbGxTcGVlZCwgMSk7XG4gICAgICBzY3JvbGxYID0geDtcbiAgICAgIHNjcm9sbFkgPSB5O1xuICAgICAgb25TdG9wICYmIG9uU3RvcERlbGF5ZWRDYWxsLnJlc3RhcnQodHJ1ZSk7XG4gICAgfSxcbiAgICAgICAgX29uV2hlZWwgPSBmdW5jdGlvbiBfb25XaGVlbChlKSB7XG4gICAgICBpZiAoX2lnbm9yZUNoZWNrKGUpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgZSA9IF9nZXRFdmVudChlLCBwcmV2ZW50RGVmYXVsdCk7XG4gICAgICBvbldoZWVsICYmICh3aGVlbGVkID0gdHJ1ZSk7XG4gICAgICB2YXIgbXVsdGlwbGllciA9IChlLmRlbHRhTW9kZSA9PT0gMSA/IGxpbmVIZWlnaHQgOiBlLmRlbHRhTW9kZSA9PT0gMiA/IF93aW4uaW5uZXJIZWlnaHQgOiAxKSAqIHdoZWVsU3BlZWQ7XG4gICAgICBvbkRlbHRhKGUuZGVsdGFYICogbXVsdGlwbGllciwgZS5kZWx0YVkgKiBtdWx0aXBsaWVyLCAwKTtcbiAgICAgIG9uU3RvcCAmJiAhaXNOb3JtYWxpemVyICYmIG9uU3RvcERlbGF5ZWRDYWxsLnJlc3RhcnQodHJ1ZSk7XG4gICAgfSxcbiAgICAgICAgX29uTW92ZSA9IGZ1bmN0aW9uIF9vbk1vdmUoZSkge1xuICAgICAgaWYgKF9pZ25vcmVDaGVjayhlKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIHZhciB4ID0gZS5jbGllbnRYLFxuICAgICAgICAgIHkgPSBlLmNsaWVudFksXG4gICAgICAgICAgZHggPSB4IC0gc2VsZi54LFxuICAgICAgICAgIGR5ID0geSAtIHNlbGYueTtcbiAgICAgIHNlbGYueCA9IHg7XG4gICAgICBzZWxmLnkgPSB5O1xuICAgICAgbW92ZWQgPSB0cnVlO1xuICAgICAgb25TdG9wICYmIG9uU3RvcERlbGF5ZWRDYWxsLnJlc3RhcnQodHJ1ZSk7XG4gICAgICAoZHggfHwgZHkpICYmIG9uVG91Y2hPclBvaW50ZXJEZWx0YShkeCwgZHkpO1xuICAgIH0sXG4gICAgICAgIF9vbkhvdmVyID0gZnVuY3Rpb24gX29uSG92ZXIoZSkge1xuICAgICAgc2VsZi5ldmVudCA9IGU7XG4gICAgICBvbkhvdmVyKHNlbGYpO1xuICAgIH0sXG4gICAgICAgIF9vbkhvdmVyRW5kID0gZnVuY3Rpb24gX29uSG92ZXJFbmQoZSkge1xuICAgICAgc2VsZi5ldmVudCA9IGU7XG4gICAgICBvbkhvdmVyRW5kKHNlbGYpO1xuICAgIH0sXG4gICAgICAgIF9vbkNsaWNrID0gZnVuY3Rpb24gX29uQ2xpY2soZSkge1xuICAgICAgcmV0dXJuIF9pZ25vcmVDaGVjayhlKSB8fCBfZ2V0RXZlbnQoZSwgcHJldmVudERlZmF1bHQpICYmIG9uQ2xpY2soc2VsZik7XG4gICAgfTtcblxuICAgIG9uU3RvcERlbGF5ZWRDYWxsID0gc2VsZi5fZGMgPSBnc2FwLmRlbGF5ZWRDYWxsKG9uU3RvcERlbGF5IHx8IDAuMjUsIG9uU3RvcEZ1bmMpLnBhdXNlKCk7XG4gICAgc2VsZi5kZWx0YVggPSBzZWxmLmRlbHRhWSA9IDA7XG4gICAgc2VsZi5fdnggPSBfZ2V0VmVsb2NpdHlQcm9wKDAsIDUwLCB0cnVlKTtcbiAgICBzZWxmLl92eSA9IF9nZXRWZWxvY2l0eVByb3AoMCwgNTAsIHRydWUpO1xuICAgIHNlbGYuc2Nyb2xsWCA9IHNjcm9sbEZ1bmNYO1xuICAgIHNlbGYuc2Nyb2xsWSA9IHNjcm9sbEZ1bmNZO1xuICAgIHNlbGYuaXNEcmFnZ2luZyA9IHNlbGYuaXNHZXN0dXJpbmcgPSBzZWxmLmlzUHJlc3NlZCA9IGZhbHNlO1xuXG4gICAgX2NvbnRleHQodGhpcyk7XG5cbiAgICBzZWxmLmVuYWJsZSA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICBpZiAoIXNlbGYuaXNFbmFibGVkKSB7XG4gICAgICAgIF9hZGRMaXN0ZW5lcihpc1ZpZXdwb3J0ID8gb3duZXJEb2MgOiB0YXJnZXQsIFwic2Nyb2xsXCIsIF9vblNjcm9sbCk7XG5cbiAgICAgICAgdHlwZS5pbmRleE9mKFwic2Nyb2xsXCIpID49IDAgJiYgX2FkZExpc3RlbmVyKGlzVmlld3BvcnQgPyBvd25lckRvYyA6IHRhcmdldCwgXCJzY3JvbGxcIiwgb25TY3JvbGwsIHBhc3NpdmUsIGNhcHR1cmUpO1xuICAgICAgICB0eXBlLmluZGV4T2YoXCJ3aGVlbFwiKSA+PSAwICYmIF9hZGRMaXN0ZW5lcih0YXJnZXQsIFwid2hlZWxcIiwgX29uV2hlZWwsIHBhc3NpdmUsIGNhcHR1cmUpO1xuXG4gICAgICAgIGlmICh0eXBlLmluZGV4T2YoXCJ0b3VjaFwiKSA+PSAwICYmIF9pc1RvdWNoIHx8IHR5cGUuaW5kZXhPZihcInBvaW50ZXJcIikgPj0gMCkge1xuICAgICAgICAgIF9hZGRMaXN0ZW5lcih0YXJnZXQsIF9ldmVudFR5cGVzWzBdLCBfb25QcmVzcywgcGFzc2l2ZSwgY2FwdHVyZSk7XG5cbiAgICAgICAgICBfYWRkTGlzdGVuZXIob3duZXJEb2MsIF9ldmVudFR5cGVzWzJdLCBfb25SZWxlYXNlKTtcblxuICAgICAgICAgIF9hZGRMaXN0ZW5lcihvd25lckRvYywgX2V2ZW50VHlwZXNbM10sIF9vblJlbGVhc2UpO1xuXG4gICAgICAgICAgYWxsb3dDbGlja3MgJiYgX2FkZExpc3RlbmVyKHRhcmdldCwgXCJjbGlja1wiLCBjbGlja0NhcHR1cmUsIHRydWUsIHRydWUpO1xuICAgICAgICAgIG9uQ2xpY2sgJiYgX2FkZExpc3RlbmVyKHRhcmdldCwgXCJjbGlja1wiLCBfb25DbGljayk7XG4gICAgICAgICAgb25HZXN0dXJlU3RhcnQgJiYgX2FkZExpc3RlbmVyKG93bmVyRG9jLCBcImdlc3R1cmVzdGFydFwiLCBfb25HZXN0dXJlU3RhcnQpO1xuICAgICAgICAgIG9uR2VzdHVyZUVuZCAmJiBfYWRkTGlzdGVuZXIob3duZXJEb2MsIFwiZ2VzdHVyZWVuZFwiLCBfb25HZXN0dXJlRW5kKTtcbiAgICAgICAgICBvbkhvdmVyICYmIF9hZGRMaXN0ZW5lcih0YXJnZXQsIF9wb2ludGVyVHlwZSArIFwiZW50ZXJcIiwgX29uSG92ZXIpO1xuICAgICAgICAgIG9uSG92ZXJFbmQgJiYgX2FkZExpc3RlbmVyKHRhcmdldCwgX3BvaW50ZXJUeXBlICsgXCJsZWF2ZVwiLCBfb25Ib3ZlckVuZCk7XG4gICAgICAgICAgb25Nb3ZlICYmIF9hZGRMaXN0ZW5lcih0YXJnZXQsIF9wb2ludGVyVHlwZSArIFwibW92ZVwiLCBfb25Nb3ZlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHNlbGYuaXNFbmFibGVkID0gdHJ1ZTtcbiAgICAgICAgc2VsZi5pc0RyYWdnaW5nID0gc2VsZi5pc0dlc3R1cmluZyA9IHNlbGYuaXNQcmVzc2VkID0gbW92ZWQgPSBkcmFnZ2VkID0gZmFsc2U7XG5cbiAgICAgICAgc2VsZi5fdngucmVzZXQoKTtcblxuICAgICAgICBzZWxmLl92eS5yZXNldCgpO1xuXG4gICAgICAgIHNjcm9sbFggPSBzY3JvbGxGdW5jWCgpO1xuICAgICAgICBzY3JvbGxZID0gc2Nyb2xsRnVuY1koKTtcbiAgICAgICAgZSAmJiBlLnR5cGUgJiYgX29uUHJlc3MoZSk7XG4gICAgICAgIG9uRW5hYmxlICYmIG9uRW5hYmxlKHNlbGYpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gc2VsZjtcbiAgICB9O1xuXG4gICAgc2VsZi5kaXNhYmxlID0gZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKHNlbGYuaXNFbmFibGVkKSB7XG4gICAgICAgIC8vIG9ubHkgcmVtb3ZlIHRoZSBfb25TY3JvbGwgbGlzdGVuZXIgaWYgdGhlcmUgYXJlbid0IGFueSBvdGhlcnMgdGhhdCByZWx5IG9uIHRoZSBmdW5jdGlvbmFsaXR5LlxuICAgICAgICBfb2JzZXJ2ZXJzLmZpbHRlcihmdW5jdGlvbiAobykge1xuICAgICAgICAgIHJldHVybiBvICE9PSBzZWxmICYmIF9pc1ZpZXdwb3J0KG8udGFyZ2V0KTtcbiAgICAgICAgfSkubGVuZ3RoIHx8IF9yZW1vdmVMaXN0ZW5lcihpc1ZpZXdwb3J0ID8gb3duZXJEb2MgOiB0YXJnZXQsIFwic2Nyb2xsXCIsIF9vblNjcm9sbCk7XG5cbiAgICAgICAgaWYgKHNlbGYuaXNQcmVzc2VkKSB7XG4gICAgICAgICAgc2VsZi5fdngucmVzZXQoKTtcblxuICAgICAgICAgIHNlbGYuX3Z5LnJlc2V0KCk7XG5cbiAgICAgICAgICBfcmVtb3ZlTGlzdGVuZXIoaXNOb3JtYWxpemVyID8gdGFyZ2V0IDogb3duZXJEb2MsIF9ldmVudFR5cGVzWzFdLCBfb25EcmFnLCB0cnVlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIF9yZW1vdmVMaXN0ZW5lcihpc1ZpZXdwb3J0ID8gb3duZXJEb2MgOiB0YXJnZXQsIFwic2Nyb2xsXCIsIG9uU2Nyb2xsLCBjYXB0dXJlKTtcblxuICAgICAgICBfcmVtb3ZlTGlzdGVuZXIodGFyZ2V0LCBcIndoZWVsXCIsIF9vbldoZWVsLCBjYXB0dXJlKTtcblxuICAgICAgICBfcmVtb3ZlTGlzdGVuZXIodGFyZ2V0LCBfZXZlbnRUeXBlc1swXSwgX29uUHJlc3MsIGNhcHR1cmUpO1xuXG4gICAgICAgIF9yZW1vdmVMaXN0ZW5lcihvd25lckRvYywgX2V2ZW50VHlwZXNbMl0sIF9vblJlbGVhc2UpO1xuXG4gICAgICAgIF9yZW1vdmVMaXN0ZW5lcihvd25lckRvYywgX2V2ZW50VHlwZXNbM10sIF9vblJlbGVhc2UpO1xuXG4gICAgICAgIF9yZW1vdmVMaXN0ZW5lcih0YXJnZXQsIFwiY2xpY2tcIiwgY2xpY2tDYXB0dXJlLCB0cnVlKTtcblxuICAgICAgICBfcmVtb3ZlTGlzdGVuZXIodGFyZ2V0LCBcImNsaWNrXCIsIF9vbkNsaWNrKTtcblxuICAgICAgICBfcmVtb3ZlTGlzdGVuZXIob3duZXJEb2MsIFwiZ2VzdHVyZXN0YXJ0XCIsIF9vbkdlc3R1cmVTdGFydCk7XG5cbiAgICAgICAgX3JlbW92ZUxpc3RlbmVyKG93bmVyRG9jLCBcImdlc3R1cmVlbmRcIiwgX29uR2VzdHVyZUVuZCk7XG5cbiAgICAgICAgX3JlbW92ZUxpc3RlbmVyKHRhcmdldCwgX3BvaW50ZXJUeXBlICsgXCJlbnRlclwiLCBfb25Ib3Zlcik7XG5cbiAgICAgICAgX3JlbW92ZUxpc3RlbmVyKHRhcmdldCwgX3BvaW50ZXJUeXBlICsgXCJsZWF2ZVwiLCBfb25Ib3ZlckVuZCk7XG5cbiAgICAgICAgX3JlbW92ZUxpc3RlbmVyKHRhcmdldCwgX3BvaW50ZXJUeXBlICsgXCJtb3ZlXCIsIF9vbk1vdmUpO1xuXG4gICAgICAgIHNlbGYuaXNFbmFibGVkID0gc2VsZi5pc1ByZXNzZWQgPSBzZWxmLmlzRHJhZ2dpbmcgPSBmYWxzZTtcbiAgICAgICAgb25EaXNhYmxlICYmIG9uRGlzYWJsZShzZWxmKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgc2VsZi5raWxsID0gc2VsZi5yZXZlcnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLmRpc2FibGUoKTtcblxuICAgICAgdmFyIGkgPSBfb2JzZXJ2ZXJzLmluZGV4T2Yoc2VsZik7XG5cbiAgICAgIGkgPj0gMCAmJiBfb2JzZXJ2ZXJzLnNwbGljZShpLCAxKTtcbiAgICAgIF9ub3JtYWxpemVyID09PSBzZWxmICYmIChfbm9ybWFsaXplciA9IDApO1xuICAgIH07XG5cbiAgICBfb2JzZXJ2ZXJzLnB1c2goc2VsZik7XG5cbiAgICBpc05vcm1hbGl6ZXIgJiYgX2lzVmlld3BvcnQodGFyZ2V0KSAmJiAoX25vcm1hbGl6ZXIgPSBzZWxmKTtcbiAgICBzZWxmLmVuYWJsZShldmVudCk7XG4gIH07XG5cbiAgX2NyZWF0ZUNsYXNzKE9ic2VydmVyLCBbe1xuICAgIGtleTogXCJ2ZWxvY2l0eVhcIixcbiAgICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICAgIHJldHVybiB0aGlzLl92eC5nZXRWZWxvY2l0eSgpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJ2ZWxvY2l0eVlcIixcbiAgICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICAgIHJldHVybiB0aGlzLl92eS5nZXRWZWxvY2l0eSgpO1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBPYnNlcnZlcjtcbn0oKTtcbk9ic2VydmVyLnZlcnNpb24gPSBcIjMuMTUuMFwiO1xuXG5PYnNlcnZlci5jcmVhdGUgPSBmdW5jdGlvbiAodmFycykge1xuICByZXR1cm4gbmV3IE9ic2VydmVyKHZhcnMpO1xufTtcblxuT2JzZXJ2ZXIucmVnaXN0ZXIgPSBfaW5pdENvcmU7XG5cbk9ic2VydmVyLmdldEFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIF9vYnNlcnZlcnMuc2xpY2UoKTtcbn07XG5cbk9ic2VydmVyLmdldEJ5SWQgPSBmdW5jdGlvbiAoaWQpIHtcbiAgcmV0dXJuIF9vYnNlcnZlcnMuZmlsdGVyKGZ1bmN0aW9uIChvKSB7XG4gICAgcmV0dXJuIG8udmFycy5pZCA9PT0gaWQ7XG4gIH0pWzBdO1xufTtcblxuX2dldEdTQVAoKSAmJiBnc2FwLnJlZ2lzdGVyUGx1Z2luKE9ic2VydmVyKTtcbmV4cG9ydCB7IE9ic2VydmVyIGFzIGRlZmF1bHQsIF9pc1ZpZXdwb3J0LCBfc2Nyb2xsZXJzLCBfZ2V0U2Nyb2xsRnVuYywgX2dldFByb3h5UHJvcCwgX3Byb3hpZXMsIF9nZXRWZWxvY2l0eVByb3AsIF92ZXJ0aWNhbCwgX2hvcml6b250YWwsIF9nZXRUYXJnZXQgfTsiLCIvKiFcbiAqIFNjcm9sbFRyaWdnZXIgMy4xNS4wXG4gKiBodHRwczovL2dzYXAuY29tXG4gKlxuICogQGxpY2Vuc2UgQ29weXJpZ2h0IDIwMDgtMjAyNiwgR3JlZW5Tb2NrLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICogU3ViamVjdCB0byB0aGUgdGVybXMgYXQgaHR0cHM6Ly9nc2FwLmNvbS9zdGFuZGFyZC1saWNlbnNlXG4gKiBAYXV0aG9yOiBKYWNrIERveWxlLCBqYWNrQGdyZWVuc29jay5jb21cbiovXG5cbi8qIGVzbGludC1kaXNhYmxlICovXG5pbXBvcnQgeyBPYnNlcnZlciwgX2dldFRhcmdldCwgX3ZlcnRpY2FsLCBfaG9yaXpvbnRhbCwgX3Njcm9sbGVycywgX3Byb3hpZXMsIF9nZXRTY3JvbGxGdW5jLCBfZ2V0UHJveHlQcm9wLCBfZ2V0VmVsb2NpdHlQcm9wIH0gZnJvbSBcIi4vT2JzZXJ2ZXIuanNcIjtcblxudmFyIGdzYXAsXG4gICAgX2NvcmVJbml0dGVkLFxuICAgIF93aW4sXG4gICAgX2RvYyxcbiAgICBfZG9jRWwsXG4gICAgX2JvZHksXG4gICAgX3Jvb3QsXG4gICAgX3Jlc2l6ZURlbGF5LFxuICAgIF90b0FycmF5LFxuICAgIF9jbGFtcCxcbiAgICBfdGltZTIsXG4gICAgX3N5bmNJbnRlcnZhbCxcbiAgICBfcmVmcmVzaGluZyxcbiAgICBfcG9pbnRlcklzRG93bixcbiAgICBfdHJhbnNmb3JtUHJvcCxcbiAgICBfaSxcbiAgICBfcHJldldpZHRoLFxuICAgIF9wcmV2SGVpZ2h0LFxuICAgIF9hdXRvUmVmcmVzaCxcbiAgICBfc29ydCxcbiAgICBfc3VwcHJlc3NPdmVyd3JpdGVzLFxuICAgIF9pZ25vcmVSZXNpemUsXG4gICAgX25vcm1hbGl6ZXIsXG4gICAgX2lnbm9yZU1vYmlsZVJlc2l6ZSxcbiAgICBfYmFzZVNjcmVlbkhlaWdodCxcbiAgICBfYmFzZVNjcmVlbldpZHRoLFxuICAgIF9maXhJT1NCdWcsXG4gICAgX2NvbnRleHQsXG4gICAgX3Njcm9sbFJlc3RvcmF0aW9uLFxuICAgIF9kaXYxMDB2aCxcbiAgICBfMTAwdmgsXG4gICAgX2lzUmV2ZXJ0ZWQsXG4gICAgX2NsYW1waW5nTWF4LFxuICAgIF9saW1pdENhbGxiYWNrcyxcbiAgICAvLyBpZiB0cnVlLCB3ZSdsbCBvbmx5IHRyaWdnZXIgY2FsbGJhY2tzIGlmIHRoZSBhY3RpdmUgc3RhdGUgdG9nZ2xlcywgc28gaWYgeW91IHNjcm9sbCBpbW1lZGlhdGVseSBwYXN0IGJvdGggdGhlIHN0YXJ0IGFuZCBlbmQgcG9zaXRpb25zIG9mIGEgU2Nyb2xsVHJpZ2dlciAodGh1cyBpbmFjdGl2ZSB0byBpbmFjdGl2ZSksIG5laXRoZXIgaXRzIG9uRW50ZXIgbm9yIG9uTGVhdmUgd2lsbCBiZSBjYWxsZWQuIFRoaXMgaXMgdXNlZnVsIGR1cmluZyBzdGFydHVwLlxuX3N0YXJ0dXAgPSAxLFxuICAgIF9nZXRUaW1lID0gRGF0ZS5ub3csXG4gICAgX3RpbWUxID0gX2dldFRpbWUoKSxcbiAgICBfbGFzdFNjcm9sbFRpbWUgPSAwLFxuICAgIF9lbmFibGVkID0gMCxcbiAgICBfcGFyc2VDbGFtcCA9IGZ1bmN0aW9uIF9wYXJzZUNsYW1wKHZhbHVlLCB0eXBlLCBzZWxmKSB7XG4gIHZhciBjbGFtcCA9IF9pc1N0cmluZyh2YWx1ZSkgJiYgKHZhbHVlLnN1YnN0cigwLCA2KSA9PT0gXCJjbGFtcChcIiB8fCB2YWx1ZS5pbmRleE9mKFwibWF4XCIpID4gLTEpO1xuICBzZWxmW1wiX1wiICsgdHlwZSArIFwiQ2xhbXBcIl0gPSBjbGFtcDtcbiAgcmV0dXJuIGNsYW1wID8gdmFsdWUuc3Vic3RyKDYsIHZhbHVlLmxlbmd0aCAtIDcpIDogdmFsdWU7XG59LFxuICAgIF9rZWVwQ2xhbXAgPSBmdW5jdGlvbiBfa2VlcENsYW1wKHZhbHVlLCBjbGFtcCkge1xuICByZXR1cm4gY2xhbXAgJiYgKCFfaXNTdHJpbmcodmFsdWUpIHx8IHZhbHVlLnN1YnN0cigwLCA2KSAhPT0gXCJjbGFtcChcIikgPyBcImNsYW1wKFwiICsgdmFsdWUgKyBcIilcIiA6IHZhbHVlO1xufSxcbiAgICBfcmFmQnVnRml4ID0gZnVuY3Rpb24gX3JhZkJ1Z0ZpeCgpIHtcbiAgcmV0dXJuIF9lbmFibGVkICYmIHJlcXVlc3RBbmltYXRpb25GcmFtZShfcmFmQnVnRml4KTtcbn0sXG4gICAgLy8gaW4gc29tZSBicm93c2VycyAobGlrZSBGaXJlZm94KSwgc2NyZWVuIHJlcGFpbnRzIHdlcmVuJ3QgY29uc2lzdGVudCB1bmxlc3Mgd2UgaGFkIFNPTUVUSElORyBxdWV1ZWQgdXAgaW4gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCkhIFNvIHRoaXMganVzdCBjcmVhdGVzIGEgc3VwZXIgc2ltcGxlIGxvb3AgdG8ga2VlcCBpdCBhbGl2ZSBhbmQgc21vb3RoIG91dCByZXBhaW50cy5cbl9wb2ludGVyRG93bkhhbmRsZXIgPSBmdW5jdGlvbiBfcG9pbnRlckRvd25IYW5kbGVyKCkge1xuICByZXR1cm4gX3BvaW50ZXJJc0Rvd24gPSAxO1xufSxcbiAgICBfcG9pbnRlclVwSGFuZGxlciA9IGZ1bmN0aW9uIF9wb2ludGVyVXBIYW5kbGVyKCkge1xuICByZXR1cm4gX3BvaW50ZXJJc0Rvd24gPSAwO1xufSxcbiAgICBfcGFzc1Rocm91Z2ggPSBmdW5jdGlvbiBfcGFzc1Rocm91Z2godikge1xuICByZXR1cm4gdjtcbn0sXG4gICAgX3JvdW5kID0gZnVuY3Rpb24gX3JvdW5kKHZhbHVlKSB7XG4gIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlICogMTAwMDAwKSAvIDEwMDAwMCB8fCAwO1xufSxcbiAgICBfd2luZG93RXhpc3RzID0gZnVuY3Rpb24gX3dpbmRvd0V4aXN0cygpIHtcbiAgcmV0dXJuIHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCI7XG59LFxuICAgIF9nZXRHU0FQID0gZnVuY3Rpb24gX2dldEdTQVAoKSB7XG4gIHJldHVybiBnc2FwIHx8IF93aW5kb3dFeGlzdHMoKSAmJiAoZ3NhcCA9IHdpbmRvdy5nc2FwKSAmJiBnc2FwLnJlZ2lzdGVyUGx1Z2luICYmIGdzYXA7XG59LFxuICAgIF9pc1ZpZXdwb3J0ID0gZnVuY3Rpb24gX2lzVmlld3BvcnQoZSkge1xuICByZXR1cm4gISF+X3Jvb3QuaW5kZXhPZihlKTtcbn0sXG4gICAgX2dldFZpZXdwb3J0RGltZW5zaW9uID0gZnVuY3Rpb24gX2dldFZpZXdwb3J0RGltZW5zaW9uKGRpbWVuc2lvblByb3BlcnR5KSB7XG4gIHJldHVybiAoZGltZW5zaW9uUHJvcGVydHkgPT09IFwiSGVpZ2h0XCIgPyBfMTAwdmggOiBfd2luW1wiaW5uZXJcIiArIGRpbWVuc2lvblByb3BlcnR5XSkgfHwgX2RvY0VsW1wiY2xpZW50XCIgKyBkaW1lbnNpb25Qcm9wZXJ0eV0gfHwgX2JvZHlbXCJjbGllbnRcIiArIGRpbWVuc2lvblByb3BlcnR5XTtcbn0sXG4gICAgX2dldEJvdW5kc0Z1bmMgPSBmdW5jdGlvbiBfZ2V0Qm91bmRzRnVuYyhlbGVtZW50KSB7XG4gIHJldHVybiBfZ2V0UHJveHlQcm9wKGVsZW1lbnQsIFwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0XCIpIHx8IChfaXNWaWV3cG9ydChlbGVtZW50KSA/IGZ1bmN0aW9uICgpIHtcbiAgICBfd2luT2Zmc2V0cy53aWR0aCA9IF93aW4uaW5uZXJXaWR0aDtcbiAgICBfd2luT2Zmc2V0cy5oZWlnaHQgPSBfMTAwdmg7XG4gICAgcmV0dXJuIF93aW5PZmZzZXRzO1xuICB9IDogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBfZ2V0Qm91bmRzKGVsZW1lbnQpO1xuICB9KTtcbn0sXG4gICAgX2dldFNpemVGdW5jID0gZnVuY3Rpb24gX2dldFNpemVGdW5jKHNjcm9sbGVyLCBpc1ZpZXdwb3J0LCBfcmVmKSB7XG4gIHZhciBkID0gX3JlZi5kLFxuICAgICAgZDIgPSBfcmVmLmQyLFxuICAgICAgYSA9IF9yZWYuYTtcbiAgcmV0dXJuIChhID0gX2dldFByb3h5UHJvcChzY3JvbGxlciwgXCJnZXRCb3VuZGluZ0NsaWVudFJlY3RcIikpID8gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBhKClbZF07XG4gIH0gOiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIChpc1ZpZXdwb3J0ID8gX2dldFZpZXdwb3J0RGltZW5zaW9uKGQyKSA6IHNjcm9sbGVyW1wiY2xpZW50XCIgKyBkMl0pIHx8IDA7XG4gIH07XG59LFxuICAgIF9nZXRPZmZzZXRzRnVuYyA9IGZ1bmN0aW9uIF9nZXRPZmZzZXRzRnVuYyhlbGVtZW50LCBpc1ZpZXdwb3J0KSB7XG4gIHJldHVybiAhaXNWaWV3cG9ydCB8fCB+X3Byb3hpZXMuaW5kZXhPZihlbGVtZW50KSA/IF9nZXRCb3VuZHNGdW5jKGVsZW1lbnQpIDogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBfd2luT2Zmc2V0cztcbiAgfTtcbn0sXG4gICAgX21heFNjcm9sbCA9IGZ1bmN0aW9uIF9tYXhTY3JvbGwoZWxlbWVudCwgX3JlZjIpIHtcbiAgdmFyIHMgPSBfcmVmMi5zLFxuICAgICAgZDIgPSBfcmVmMi5kMixcbiAgICAgIGQgPSBfcmVmMi5kLFxuICAgICAgYSA9IF9yZWYyLmE7XG4gIHJldHVybiBNYXRoLm1heCgwLCAocyA9IFwic2Nyb2xsXCIgKyBkMikgJiYgKGEgPSBfZ2V0UHJveHlQcm9wKGVsZW1lbnQsIHMpKSA/IGEoKSAtIF9nZXRCb3VuZHNGdW5jKGVsZW1lbnQpKClbZF0gOiBfaXNWaWV3cG9ydChlbGVtZW50KSA/IChfZG9jRWxbc10gfHwgX2JvZHlbc10pIC0gX2dldFZpZXdwb3J0RGltZW5zaW9uKGQyKSA6IGVsZW1lbnRbc10gLSBlbGVtZW50W1wib2Zmc2V0XCIgKyBkMl0pO1xufSxcbiAgICBfaXRlcmF0ZUF1dG9SZWZyZXNoID0gZnVuY3Rpb24gX2l0ZXJhdGVBdXRvUmVmcmVzaChmdW5jLCBldmVudHMpIHtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBfYXV0b1JlZnJlc2gubGVuZ3RoOyBpICs9IDMpIHtcbiAgICAoIWV2ZW50cyB8fCB+ZXZlbnRzLmluZGV4T2YoX2F1dG9SZWZyZXNoW2kgKyAxXSkpICYmIGZ1bmMoX2F1dG9SZWZyZXNoW2ldLCBfYXV0b1JlZnJlc2hbaSArIDFdLCBfYXV0b1JlZnJlc2hbaSArIDJdKTtcbiAgfVxufSxcbiAgICBfaXNTdHJpbmcgPSBmdW5jdGlvbiBfaXNTdHJpbmcodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIjtcbn0sXG4gICAgX2lzRnVuY3Rpb24gPSBmdW5jdGlvbiBfaXNGdW5jdGlvbih2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCI7XG59LFxuICAgIF9pc051bWJlciA9IGZ1bmN0aW9uIF9pc051bWJlcih2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiO1xufSxcbiAgICBfaXNPYmplY3QgPSBmdW5jdGlvbiBfaXNPYmplY3QodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIjtcbn0sXG4gICAgX2VuZEFuaW1hdGlvbiA9IGZ1bmN0aW9uIF9lbmRBbmltYXRpb24oYW5pbWF0aW9uLCByZXZlcnNlZCwgcGF1c2UpIHtcbiAgcmV0dXJuIGFuaW1hdGlvbiAmJiBhbmltYXRpb24ucHJvZ3Jlc3MocmV2ZXJzZWQgPyAwIDogMSkgJiYgcGF1c2UgJiYgYW5pbWF0aW9uLnBhdXNlKCk7XG59LFxuICAgIF9jYWxsYmFjayA9IGZ1bmN0aW9uIF9jYWxsYmFjayhzZWxmLCBmdW5jLCBleHRyYVBhcmFtKSB7XG4gIGlmIChzZWxmLmVuYWJsZWQpIHtcbiAgICB2YXIgcmVzdWx0ID0gc2VsZi5fY3R4ID8gc2VsZi5fY3R4LmFkZChmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gZnVuYyhzZWxmLCBleHRyYVBhcmFtKTtcbiAgICB9KSA6IGZ1bmMoc2VsZiwgZXh0cmFQYXJhbSk7XG4gICAgcmVzdWx0ICYmIHJlc3VsdC50b3RhbFRpbWUgJiYgKHNlbGYuY2FsbGJhY2tBbmltYXRpb24gPSByZXN1bHQpO1xuICB9XG59LFxuICAgIF9hYnMgPSBNYXRoLmFicyxcbiAgICBfbGVmdCA9IFwibGVmdFwiLFxuICAgIF90b3AgPSBcInRvcFwiLFxuICAgIF9yaWdodCA9IFwicmlnaHRcIixcbiAgICBfYm90dG9tID0gXCJib3R0b21cIixcbiAgICBfd2lkdGggPSBcIndpZHRoXCIsXG4gICAgX2hlaWdodCA9IFwiaGVpZ2h0XCIsXG4gICAgX1JpZ2h0ID0gXCJSaWdodFwiLFxuICAgIF9MZWZ0ID0gXCJMZWZ0XCIsXG4gICAgX1RvcCA9IFwiVG9wXCIsXG4gICAgX0JvdHRvbSA9IFwiQm90dG9tXCIsXG4gICAgX3BhZGRpbmcgPSBcInBhZGRpbmdcIixcbiAgICBfbWFyZ2luID0gXCJtYXJnaW5cIixcbiAgICBfV2lkdGggPSBcIldpZHRoXCIsXG4gICAgX0hlaWdodCA9IFwiSGVpZ2h0XCIsXG4gICAgX3B4ID0gXCJweFwiLFxuICAgIF9nZXRDb21wdXRlZFN0eWxlID0gZnVuY3Rpb24gX2dldENvbXB1dGVkU3R5bGUoZWxlbWVudCkge1xuICByZXR1cm4gX3dpbi5nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQubm9kZVR5cGUgPT09IE5vZGUuRE9DVU1FTlRfTk9ERSA/IGVsZW1lbnQuc2Nyb2xsaW5nRWxlbWVudCA6IGVsZW1lbnQpO1xufSxcbiAgICBfbWFrZVBvc2l0aW9uYWJsZSA9IGZ1bmN0aW9uIF9tYWtlUG9zaXRpb25hYmxlKGVsZW1lbnQpIHtcbiAgLy8gaWYgdGhlIGVsZW1lbnQgYWxyZWFkeSBoYXMgcG9zaXRpb246IGFic29sdXRlIG9yIGZpeGVkLCBsZWF2ZSB0aGF0LCBvdGhlcndpc2UgbWFrZSBpdCBwb3NpdGlvbjogcmVsYXRpdmVcbiAgdmFyIHBvc2l0aW9uID0gX2dldENvbXB1dGVkU3R5bGUoZWxlbWVudCkucG9zaXRpb247XG5cbiAgZWxlbWVudC5zdHlsZS5wb3NpdGlvbiA9IHBvc2l0aW9uID09PSBcImFic29sdXRlXCIgfHwgcG9zaXRpb24gPT09IFwiZml4ZWRcIiA/IHBvc2l0aW9uIDogXCJyZWxhdGl2ZVwiO1xufSxcbiAgICBfc2V0RGVmYXVsdHMgPSBmdW5jdGlvbiBfc2V0RGVmYXVsdHMob2JqLCBkZWZhdWx0cykge1xuICBmb3IgKHZhciBwIGluIGRlZmF1bHRzKSB7XG4gICAgcCBpbiBvYmogfHwgKG9ialtwXSA9IGRlZmF1bHRzW3BdKTtcbiAgfVxuXG4gIHJldHVybiBvYmo7XG59LFxuICAgIF9nZXRCb3VuZHMgPSBmdW5jdGlvbiBfZ2V0Qm91bmRzKGVsZW1lbnQsIHdpdGhvdXRUcmFuc2Zvcm1zKSB7XG4gIHZhciB0d2VlbiA9IHdpdGhvdXRUcmFuc2Zvcm1zICYmIF9nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpW190cmFuc2Zvcm1Qcm9wXSAhPT0gXCJtYXRyaXgoMSwgMCwgMCwgMSwgMCwgMClcIiAmJiBnc2FwLnRvKGVsZW1lbnQsIHtcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgeFBlcmNlbnQ6IDAsXG4gICAgeVBlcmNlbnQ6IDAsXG4gICAgcm90YXRpb246IDAsXG4gICAgcm90YXRpb25YOiAwLFxuICAgIHJvdGF0aW9uWTogMCxcbiAgICBzY2FsZTogMSxcbiAgICBza2V3WDogMCxcbiAgICBza2V3WTogMFxuICB9KS5wcm9ncmVzcygxKSxcbiAgICAgIGJvdW5kcyA9IGVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0ID8gZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSA6IGVsZW1lbnQuc2Nyb2xsaW5nRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgdHdlZW4gJiYgdHdlZW4ucHJvZ3Jlc3MoMCkua2lsbCgpO1xuICByZXR1cm4gYm91bmRzO1xufSxcbiAgICBfZ2V0U2l6ZSA9IGZ1bmN0aW9uIF9nZXRTaXplKGVsZW1lbnQsIF9yZWYzKSB7XG4gIHZhciBkMiA9IF9yZWYzLmQyO1xuICByZXR1cm4gZWxlbWVudFtcIm9mZnNldFwiICsgZDJdIHx8IGVsZW1lbnRbXCJjbGllbnRcIiArIGQyXSB8fCAwO1xufSxcbiAgICBfZ2V0TGFiZWxSYXRpb0FycmF5ID0gZnVuY3Rpb24gX2dldExhYmVsUmF0aW9BcnJheSh0aW1lbGluZSkge1xuICB2YXIgYSA9IFtdLFxuICAgICAgbGFiZWxzID0gdGltZWxpbmUubGFiZWxzLFxuICAgICAgZHVyYXRpb24gPSB0aW1lbGluZS5kdXJhdGlvbigpLFxuICAgICAgcDtcblxuICBmb3IgKHAgaW4gbGFiZWxzKSB7XG4gICAgYS5wdXNoKGxhYmVsc1twXSAvIGR1cmF0aW9uKTtcbiAgfVxuXG4gIHJldHVybiBhO1xufSxcbiAgICBfZ2V0Q2xvc2VzdExhYmVsID0gZnVuY3Rpb24gX2dldENsb3Nlc3RMYWJlbChhbmltYXRpb24pIHtcbiAgcmV0dXJuIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIHJldHVybiBnc2FwLnV0aWxzLnNuYXAoX2dldExhYmVsUmF0aW9BcnJheShhbmltYXRpb24pLCB2YWx1ZSk7XG4gIH07XG59LFxuICAgIF9zbmFwRGlyZWN0aW9uYWwgPSBmdW5jdGlvbiBfc25hcERpcmVjdGlvbmFsKHNuYXBJbmNyZW1lbnRPckFycmF5KSB7XG4gIHZhciBzbmFwID0gZ3NhcC51dGlscy5zbmFwKHNuYXBJbmNyZW1lbnRPckFycmF5KSxcbiAgICAgIGEgPSBBcnJheS5pc0FycmF5KHNuYXBJbmNyZW1lbnRPckFycmF5KSAmJiBzbmFwSW5jcmVtZW50T3JBcnJheS5zbGljZSgwKS5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgcmV0dXJuIGEgLSBiO1xuICB9KTtcbiAgcmV0dXJuIGEgPyBmdW5jdGlvbiAodmFsdWUsIGRpcmVjdGlvbiwgdGhyZXNob2xkKSB7XG4gICAgaWYgKHRocmVzaG9sZCA9PT0gdm9pZCAwKSB7XG4gICAgICB0aHJlc2hvbGQgPSAxZS0zO1xuICAgIH1cblxuICAgIHZhciBpO1xuXG4gICAgaWYgKCFkaXJlY3Rpb24pIHtcbiAgICAgIHJldHVybiBzbmFwKHZhbHVlKTtcbiAgICB9XG5cbiAgICBpZiAoZGlyZWN0aW9uID4gMCkge1xuICAgICAgdmFsdWUgLT0gdGhyZXNob2xkOyAvLyB0byBhdm9pZCByb3VuZGluZyBlcnJvcnMuIElmIHdlJ3JlIHRvbyBzdHJpY3QsIGl0IG1pZ2h0IHNuYXAgZm9yd2FyZCwgdGhlbiBpbW1lZGlhdGVseSBhZ2FpbiwgYW5kIGFnYWluLlxuXG4gICAgICBmb3IgKGkgPSAwOyBpIDwgYS5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAoYVtpXSA+PSB2YWx1ZSkge1xuICAgICAgICAgIHJldHVybiBhW2ldO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBhW2kgLSAxXTtcbiAgICB9IGVsc2Uge1xuICAgICAgaSA9IGEubGVuZ3RoO1xuICAgICAgdmFsdWUgKz0gdGhyZXNob2xkO1xuXG4gICAgICB3aGlsZSAoaS0tKSB7XG4gICAgICAgIGlmIChhW2ldIDw9IHZhbHVlKSB7XG4gICAgICAgICAgcmV0dXJuIGFbaV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gYVswXTtcbiAgfSA6IGZ1bmN0aW9uICh2YWx1ZSwgZGlyZWN0aW9uLCB0aHJlc2hvbGQpIHtcbiAgICBpZiAodGhyZXNob2xkID09PSB2b2lkIDApIHtcbiAgICAgIHRocmVzaG9sZCA9IDFlLTM7XG4gICAgfVxuXG4gICAgdmFyIHNuYXBwZWQgPSBzbmFwKHZhbHVlKTtcbiAgICByZXR1cm4gIWRpcmVjdGlvbiB8fCBNYXRoLmFicyhzbmFwcGVkIC0gdmFsdWUpIDwgdGhyZXNob2xkIHx8IHNuYXBwZWQgLSB2YWx1ZSA8IDAgPT09IGRpcmVjdGlvbiA8IDAgPyBzbmFwcGVkIDogc25hcChkaXJlY3Rpb24gPCAwID8gdmFsdWUgLSBzbmFwSW5jcmVtZW50T3JBcnJheSA6IHZhbHVlICsgc25hcEluY3JlbWVudE9yQXJyYXkpO1xuICB9O1xufSxcbiAgICBfZ2V0TGFiZWxBdERpcmVjdGlvbiA9IGZ1bmN0aW9uIF9nZXRMYWJlbEF0RGlyZWN0aW9uKHRpbWVsaW5lKSB7XG4gIHJldHVybiBmdW5jdGlvbiAodmFsdWUsIHN0KSB7XG4gICAgcmV0dXJuIF9zbmFwRGlyZWN0aW9uYWwoX2dldExhYmVsUmF0aW9BcnJheSh0aW1lbGluZSkpKHZhbHVlLCBzdC5kaXJlY3Rpb24pO1xuICB9O1xufSxcbiAgICBfbXVsdGlMaXN0ZW5lciA9IGZ1bmN0aW9uIF9tdWx0aUxpc3RlbmVyKGZ1bmMsIGVsZW1lbnQsIHR5cGVzLCBjYWxsYmFjaykge1xuICByZXR1cm4gdHlwZXMuc3BsaXQoXCIsXCIpLmZvckVhY2goZnVuY3Rpb24gKHR5cGUpIHtcbiAgICByZXR1cm4gZnVuYyhlbGVtZW50LCB0eXBlLCBjYWxsYmFjayk7XG4gIH0pO1xufSxcbiAgICBfYWRkTGlzdGVuZXIgPSBmdW5jdGlvbiBfYWRkTGlzdGVuZXIoZWxlbWVudCwgdHlwZSwgZnVuYywgbm9uUGFzc2l2ZSwgY2FwdHVyZSkge1xuICByZXR1cm4gZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGZ1bmMsIHtcbiAgICBwYXNzaXZlOiAhbm9uUGFzc2l2ZSxcbiAgICBjYXB0dXJlOiAhIWNhcHR1cmVcbiAgfSk7XG59LFxuICAgIF9yZW1vdmVMaXN0ZW5lciA9IGZ1bmN0aW9uIF9yZW1vdmVMaXN0ZW5lcihlbGVtZW50LCB0eXBlLCBmdW5jLCBjYXB0dXJlKSB7XG4gIHJldHVybiBlbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIodHlwZSwgZnVuYywgISFjYXB0dXJlKTtcbn0sXG4gICAgX3doZWVsTGlzdGVuZXIgPSBmdW5jdGlvbiBfd2hlZWxMaXN0ZW5lcihmdW5jLCBlbCwgc2Nyb2xsRnVuYykge1xuICBzY3JvbGxGdW5jID0gc2Nyb2xsRnVuYyAmJiBzY3JvbGxGdW5jLndoZWVsSGFuZGxlcjtcblxuICBpZiAoc2Nyb2xsRnVuYykge1xuICAgIGZ1bmMoZWwsIFwid2hlZWxcIiwgc2Nyb2xsRnVuYyk7XG4gICAgZnVuYyhlbCwgXCJ0b3VjaG1vdmVcIiwgc2Nyb2xsRnVuYyk7XG4gIH1cbn0sXG4gICAgX21hcmtlckRlZmF1bHRzID0ge1xuICBzdGFydENvbG9yOiBcImdyZWVuXCIsXG4gIGVuZENvbG9yOiBcInJlZFwiLFxuICBpbmRlbnQ6IDAsXG4gIGZvbnRTaXplOiBcIjE2cHhcIixcbiAgZm9udFdlaWdodDogXCJub3JtYWxcIlxufSxcbiAgICBfZGVmYXVsdHMgPSB7XG4gIHRvZ2dsZUFjdGlvbnM6IFwicGxheVwiLFxuICBhbnRpY2lwYXRlUGluOiAwXG59LFxuICAgIF9rZXl3b3JkcyA9IHtcbiAgdG9wOiAwLFxuICBsZWZ0OiAwLFxuICBjZW50ZXI6IDAuNSxcbiAgYm90dG9tOiAxLFxuICByaWdodDogMVxufSxcbiAgICBfb2Zmc2V0VG9QeCA9IGZ1bmN0aW9uIF9vZmZzZXRUb1B4KHZhbHVlLCBzaXplKSB7XG4gIGlmIChfaXNTdHJpbmcodmFsdWUpKSB7XG4gICAgdmFyIGVxSW5kZXggPSB2YWx1ZS5pbmRleE9mKFwiPVwiKSxcbiAgICAgICAgcmVsYXRpdmUgPSB+ZXFJbmRleCA/ICsodmFsdWUuY2hhckF0KGVxSW5kZXggLSAxKSArIDEpICogcGFyc2VGbG9hdCh2YWx1ZS5zdWJzdHIoZXFJbmRleCArIDEpKSA6IDA7XG5cbiAgICBpZiAofmVxSW5kZXgpIHtcbiAgICAgIHZhbHVlLmluZGV4T2YoXCIlXCIpID4gZXFJbmRleCAmJiAocmVsYXRpdmUgKj0gc2l6ZSAvIDEwMCk7XG4gICAgICB2YWx1ZSA9IHZhbHVlLnN1YnN0cigwLCBlcUluZGV4IC0gMSk7XG4gICAgfVxuXG4gICAgdmFsdWUgPSByZWxhdGl2ZSArICh2YWx1ZSBpbiBfa2V5d29yZHMgPyBfa2V5d29yZHNbdmFsdWVdICogc2l6ZSA6IH52YWx1ZS5pbmRleE9mKFwiJVwiKSA/IHBhcnNlRmxvYXQodmFsdWUpICogc2l6ZSAvIDEwMCA6IHBhcnNlRmxvYXQodmFsdWUpIHx8IDApO1xuICB9XG5cbiAgcmV0dXJuIHZhbHVlO1xufSxcbiAgICBfY3JlYXRlTWFya2VyID0gZnVuY3Rpb24gX2NyZWF0ZU1hcmtlcih0eXBlLCBuYW1lLCBjb250YWluZXIsIGRpcmVjdGlvbiwgX3JlZjQsIG9mZnNldCwgbWF0Y2hXaWR0aEVsLCBjb250YWluZXJBbmltYXRpb24pIHtcbiAgdmFyIHN0YXJ0Q29sb3IgPSBfcmVmNC5zdGFydENvbG9yLFxuICAgICAgZW5kQ29sb3IgPSBfcmVmNC5lbmRDb2xvcixcbiAgICAgIGZvbnRTaXplID0gX3JlZjQuZm9udFNpemUsXG4gICAgICBpbmRlbnQgPSBfcmVmNC5pbmRlbnQsXG4gICAgICBmb250V2VpZ2h0ID0gX3JlZjQuZm9udFdlaWdodDtcblxuICB2YXIgZSA9IF9kb2MuY3JlYXRlRWxlbWVudChcImRpdlwiKSxcbiAgICAgIHVzZUZpeGVkUG9zaXRpb24gPSBfaXNWaWV3cG9ydChjb250YWluZXIpIHx8IF9nZXRQcm94eVByb3AoY29udGFpbmVyLCBcInBpblR5cGVcIikgPT09IFwiZml4ZWRcIixcbiAgICAgIGlzU2Nyb2xsZXIgPSB0eXBlLmluZGV4T2YoXCJzY3JvbGxlclwiKSAhPT0gLTEsXG4gICAgICBwYXJlbnQgPSB1c2VGaXhlZFBvc2l0aW9uID8gX2JvZHkgOiBjb250YWluZXIudGFnTmFtZSA9PT0gXCJJRlJBTUVcIiA/IGNvbnRhaW5lci5jb250ZW50RG9jdW1lbnQuYm9keSA6IGNvbnRhaW5lcixcbiAgICAgIGlzU3RhcnQgPSB0eXBlLmluZGV4T2YoXCJzdGFydFwiKSAhPT0gLTEsXG4gICAgICBjb2xvciA9IGlzU3RhcnQgPyBzdGFydENvbG9yIDogZW5kQ29sb3IsXG4gICAgICBjc3MgPSBcImJvcmRlci1jb2xvcjpcIiArIGNvbG9yICsgXCI7Zm9udC1zaXplOlwiICsgZm9udFNpemUgKyBcIjtjb2xvcjpcIiArIGNvbG9yICsgXCI7Zm9udC13ZWlnaHQ6XCIgKyBmb250V2VpZ2h0ICsgXCI7cG9pbnRlci1ldmVudHM6bm9uZTt3aGl0ZS1zcGFjZTpub3dyYXA7Zm9udC1mYW1pbHk6c2Fucy1zZXJpZixBcmlhbDt6LWluZGV4OjEwMDA7cGFkZGluZzo0cHggOHB4O2JvcmRlci13aWR0aDowO2JvcmRlci1zdHlsZTpzb2xpZDtcIjtcblxuICBjc3MgKz0gXCJwb3NpdGlvbjpcIiArICgoaXNTY3JvbGxlciB8fCBjb250YWluZXJBbmltYXRpb24pICYmIHVzZUZpeGVkUG9zaXRpb24gPyBcImZpeGVkO1wiIDogXCJhYnNvbHV0ZTtcIik7XG4gIChpc1Njcm9sbGVyIHx8IGNvbnRhaW5lckFuaW1hdGlvbiB8fCAhdXNlRml4ZWRQb3NpdGlvbikgJiYgKGNzcyArPSAoZGlyZWN0aW9uID09PSBfdmVydGljYWwgPyBfcmlnaHQgOiBfYm90dG9tKSArIFwiOlwiICsgKG9mZnNldCArIHBhcnNlRmxvYXQoaW5kZW50KSkgKyBcInB4O1wiKTtcbiAgbWF0Y2hXaWR0aEVsICYmIChjc3MgKz0gXCJib3gtc2l6aW5nOmJvcmRlci1ib3g7dGV4dC1hbGlnbjpsZWZ0O3dpZHRoOlwiICsgbWF0Y2hXaWR0aEVsLm9mZnNldFdpZHRoICsgXCJweDtcIik7XG4gIGUuX2lzU3RhcnQgPSBpc1N0YXJ0O1xuICBlLnNldEF0dHJpYnV0ZShcImNsYXNzXCIsIFwiZ3NhcC1tYXJrZXItXCIgKyB0eXBlICsgKG5hbWUgPyBcIiBtYXJrZXItXCIgKyBuYW1lIDogXCJcIikpO1xuICBlLnN0eWxlLmNzc1RleHQgPSBjc3M7XG4gIGUuaW5uZXJUZXh0ID0gbmFtZSB8fCBuYW1lID09PSAwID8gdHlwZSArIFwiLVwiICsgbmFtZSA6IHR5cGU7XG4gIHBhcmVudC5jaGlsZHJlblswXSA/IHBhcmVudC5pbnNlcnRCZWZvcmUoZSwgcGFyZW50LmNoaWxkcmVuWzBdKSA6IHBhcmVudC5hcHBlbmRDaGlsZChlKTtcbiAgZS5fb2Zmc2V0ID0gZVtcIm9mZnNldFwiICsgZGlyZWN0aW9uLm9wLmQyXTtcblxuICBfcG9zaXRpb25NYXJrZXIoZSwgMCwgZGlyZWN0aW9uLCBpc1N0YXJ0KTtcblxuICByZXR1cm4gZTtcbn0sXG4gICAgX3Bvc2l0aW9uTWFya2VyID0gZnVuY3Rpb24gX3Bvc2l0aW9uTWFya2VyKG1hcmtlciwgc3RhcnQsIGRpcmVjdGlvbiwgZmxpcHBlZCkge1xuICB2YXIgdmFycyA9IHtcbiAgICBkaXNwbGF5OiBcImJsb2NrXCJcbiAgfSxcbiAgICAgIHNpZGUgPSBkaXJlY3Rpb25bZmxpcHBlZCA/IFwib3MyXCIgOiBcInAyXCJdLFxuICAgICAgb3Bwb3NpdGVTaWRlID0gZGlyZWN0aW9uW2ZsaXBwZWQgPyBcInAyXCIgOiBcIm9zMlwiXTtcbiAgbWFya2VyLl9pc0ZsaXBwZWQgPSBmbGlwcGVkO1xuICB2YXJzW2RpcmVjdGlvbi5hICsgXCJQZXJjZW50XCJdID0gZmxpcHBlZCA/IC0xMDAgOiAwO1xuICB2YXJzW2RpcmVjdGlvbi5hXSA9IGZsaXBwZWQgPyBcIjFweFwiIDogMDtcbiAgdmFyc1tcImJvcmRlclwiICsgc2lkZSArIF9XaWR0aF0gPSAxO1xuICB2YXJzW1wiYm9yZGVyXCIgKyBvcHBvc2l0ZVNpZGUgKyBfV2lkdGhdID0gMDtcbiAgdmFyc1tkaXJlY3Rpb24ucF0gPSBzdGFydCArIFwicHhcIjtcbiAgZ3NhcC5zZXQobWFya2VyLCB2YXJzKTtcbn0sXG4gICAgX3RyaWdnZXJzID0gW10sXG4gICAgX2lkcyA9IHt9LFxuICAgIF9yYWZJRCxcbiAgICBfc3luYyA9IGZ1bmN0aW9uIF9zeW5jKCkge1xuICByZXR1cm4gX2dldFRpbWUoKSAtIF9sYXN0U2Nyb2xsVGltZSA+IDM0ICYmIChfcmFmSUQgfHwgKF9yYWZJRCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShfdXBkYXRlQWxsKSkpO1xufSxcbiAgICBfb25TY3JvbGwgPSBmdW5jdGlvbiBfb25TY3JvbGwoKSB7XG4gIC8vIHByZXZpb3VzbHksIHdlIHRyaWVkIHRvIG9wdGltaXplIHBlcmZvcm1hbmNlIGJ5IGJhdGNoaW5nL2RlZmVycmluZyB0byB0aGUgbmV4dCByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKSwgYnV0IGRpc2NvdmVyZWQgdGhhdCBTYWZhcmkgaGFzIGEgZmV3IGJ1Z3MgdGhhdCBtYWtlIHRoaXMgdW53b3JrYWJsZSAoZXNwZWNpYWxseSBvbiBpT1MpLiBTZWUgaHR0cHM6Ly9jb2RlcGVuLmlvL0dyZWVuU29jay9wZW4vMTZjNDM1YjEyZWYwOWMzODEyNTIwNDgxOGU3YjQ1ZmM/ZWRpdG9ycz0wMDEwIGFuZCBodHRwczovL2NvZGVwZW4uaW8vR3JlZW5Tb2NrL3Blbi9Kak94WXBRLzNkZDY1Y2NlYzVhNjBmMWQ4NjJjMzU1ZDg0ZDE0NTYyP2VkaXRvcnM9MDAxMCBhbmQgaHR0cHM6Ly9jb2RlcGVuLmlvL0dyZWVuU29jay9wZW4vRXhiclBOYS8wODdjZWYxOTdkYzM1NDQ1YTA5NTFlODkzNWM0MTUwMz9lZGl0b3JzPTAwMTBcbiAgaWYgKCFfbm9ybWFsaXplciB8fCAhX25vcm1hbGl6ZXIuaXNQcmVzc2VkIHx8IF9ub3JtYWxpemVyLnN0YXJ0WCA+IF9ib2R5LmNsaWVudFdpZHRoKSB7XG4gICAgLy8gaWYgdGhlIHVzZXIgaXMgZHJhZ2dpbmcgdGhlIHNjcm9sbGJhciwgYWxsb3cgaXQuXG4gICAgX3Njcm9sbGVycy5jYWNoZSsrO1xuXG4gICAgaWYgKF9ub3JtYWxpemVyKSB7XG4gICAgICBfcmFmSUQgfHwgKF9yYWZJRCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShfdXBkYXRlQWxsKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIF91cGRhdGVBbGwoKTsgLy8gU2FmYXJpIGluIHBhcnRpY3VsYXIgKG9uIGRlc2t0b3ApIE5FRURTIHRoZSBpbW1lZGlhdGUgdXBkYXRlIHJhdGhlciB0aGFuIHdhaXRpbmcgZm9yIGEgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCkgd2hlcmVhcyBpT1Mgc2VlbXMgdG8gYmVuZWZpdCBmcm9tIHdhaXRpbmcgZm9yIHRoZSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKSB0aWNrLCBhdCBsZWFzdCB3aGVuIG5vcm1hbGl6aW5nLiBTZWUgaHR0cHM6Ly9jb2RlcGVuLmlvL0dyZWVuU29jay9wZW4vcUJZb3pxTz9lZGl0b3JzPTAxMTBcblxuICAgIH1cblxuICAgIF9sYXN0U2Nyb2xsVGltZSB8fCBfZGlzcGF0Y2goXCJzY3JvbGxTdGFydFwiKTtcbiAgICBfbGFzdFNjcm9sbFRpbWUgPSBfZ2V0VGltZSgpO1xuICB9XG59LFxuICAgIF9zZXRCYXNlRGltZW5zaW9ucyA9IGZ1bmN0aW9uIF9zZXRCYXNlRGltZW5zaW9ucygpIHtcbiAgX2Jhc2VTY3JlZW5XaWR0aCA9IF93aW4uaW5uZXJXaWR0aDtcbiAgX2Jhc2VTY3JlZW5IZWlnaHQgPSBfd2luLmlubmVySGVpZ2h0O1xufSxcbiAgICBfb25SZXNpemUgPSBmdW5jdGlvbiBfb25SZXNpemUoZm9yY2UpIHtcbiAgX3Njcm9sbGVycy5jYWNoZSsrO1xuICAoZm9yY2UgPT09IHRydWUgfHwgIV9yZWZyZXNoaW5nICYmICFfaWdub3JlUmVzaXplICYmICFfZG9jLmZ1bGxzY3JlZW5FbGVtZW50ICYmICFfZG9jLndlYmtpdEZ1bGxzY3JlZW5FbGVtZW50ICYmICghX2lnbm9yZU1vYmlsZVJlc2l6ZSB8fCBfYmFzZVNjcmVlbldpZHRoICE9PSBfd2luLmlubmVyV2lkdGggfHwgTWF0aC5hYnMoX3dpbi5pbm5lckhlaWdodCAtIF9iYXNlU2NyZWVuSGVpZ2h0KSA+IF93aW4uaW5uZXJIZWlnaHQgKiAwLjI1KSkgJiYgX3Jlc2l6ZURlbGF5LnJlc3RhcnQodHJ1ZSk7XG59LFxuICAgIC8vIGlnbm9yZSByZXNpemVzIHRyaWdnZXJlZCBieSByZWZyZXNoKClcbl9saXN0ZW5lcnMgPSB7fSxcbiAgICBfZW1wdHlBcnJheSA9IFtdLFxuICAgIF9zb2Z0UmVmcmVzaCA9IGZ1bmN0aW9uIF9zb2Z0UmVmcmVzaCgpIHtcbiAgcmV0dXJuIF9yZW1vdmVMaXN0ZW5lcihTY3JvbGxUcmlnZ2VyLCBcInNjcm9sbEVuZFwiLCBfc29mdFJlZnJlc2gpIHx8IF9yZWZyZXNoQWxsKHRydWUpO1xufSxcbiAgICBfZGlzcGF0Y2ggPSBmdW5jdGlvbiBfZGlzcGF0Y2godHlwZSkge1xuICByZXR1cm4gX2xpc3RlbmVyc1t0eXBlXSAmJiBfbGlzdGVuZXJzW3R5cGVdLm1hcChmdW5jdGlvbiAoZikge1xuICAgIHJldHVybiBmKCk7XG4gIH0pIHx8IF9lbXB0eUFycmF5O1xufSxcbiAgICBfc2F2ZWRTdHlsZXMgPSBbXSxcbiAgICAvLyB3aGVuIFNjcm9sbFRyaWdnZXIuc2F2ZVN0eWxlcygpIGlzIGNhbGxlZCwgdGhlIGlubGluZSBzdHlsZXMgYXJlIHJlY29yZGVkIGluIHRoaXMgQXJyYXkgaW4gYSBzZXF1ZW50aWFsIGZvcm1hdCBsaWtlIFtlbGVtZW50LCBjc3NUZXh0LCBnc0NhY2hlLCBtZWRpYV0uIFRoaXMga2VlcHMgaXQgdmVyeSBtZW1vcnktZWZmaWNpZW50IGFuZCBmYXN0IHRvIGl0ZXJhdGUgdGhyb3VnaC5cbl9yZXZlcnRSZWNvcmRlZCA9IGZ1bmN0aW9uIF9yZXZlcnRSZWNvcmRlZChtZWRpYSkge1xuICBmb3IgKHZhciBpID0gMDsgaSA8IF9zYXZlZFN0eWxlcy5sZW5ndGg7IGkgKz0gNSkge1xuICAgIGlmICghbWVkaWEgfHwgX3NhdmVkU3R5bGVzW2kgKyA0XSAmJiBfc2F2ZWRTdHlsZXNbaSArIDRdLnF1ZXJ5ID09PSBtZWRpYSkge1xuICAgICAgX3NhdmVkU3R5bGVzW2ldLnN0eWxlLmNzc1RleHQgPSBfc2F2ZWRTdHlsZXNbaSArIDFdO1xuICAgICAgX3NhdmVkU3R5bGVzW2ldLmdldEJCb3ggJiYgX3NhdmVkU3R5bGVzW2ldLnNldEF0dHJpYnV0ZShcInRyYW5zZm9ybVwiLCBfc2F2ZWRTdHlsZXNbaSArIDJdIHx8IFwiXCIpO1xuICAgICAgX3NhdmVkU3R5bGVzW2kgKyAzXS51bmNhY2hlID0gMTtcbiAgICB9XG4gIH1cbn0sXG4gICAgX3JlY29yZFNjcm9sbFBvc2l0aW9ucyA9IGZ1bmN0aW9uIF9yZWNvcmRTY3JvbGxQb3NpdGlvbnMoKSB7XG4gIHJldHVybiBfc2Nyb2xsZXJzLmZvckVhY2goZnVuY3Rpb24gKG9iaikge1xuICAgIHJldHVybiBfaXNGdW5jdGlvbihvYmopICYmICsrb2JqLmNhY2hlSUQgJiYgKG9iai5yZWMgPSBvYmooKSk7XG4gIH0pO1xufSxcbiAgICAvLyByZWNvcmQgdGhlIGN1cnJlbnQgc2Nyb2xsIHBvc2l0aW9uLiBBbHNvIGZvcmNlIHRoZSBjbGVhcmluZyBvZiB0aGUgY2FjaGUgYmVjYXVzZSBzb21lIGJyb3dzZXJzIHRha2UgYSBsaXR0bGUgd2hpbGUgdG8gZGlzcGF0Y2ggdGhlIFwic2Nyb2xsXCIgZXZlbnQgYW5kIHRoZSB1c2VyIG1heSBoYXZlIGNoYW5nZWQgdGhlIHNjcm9sbCBwb3NpdGlvbiBhbmQgdGhlbiBjYWxsZWQgU2Nyb2xsVHJpZ2dlci5yZWZyZXNoKCkgcmlnaHQgYXdheVxuX3JldmVydEFsbCA9IGZ1bmN0aW9uIF9yZXZlcnRBbGwoa2lsbCwgbWVkaWEpIHtcbiAgdmFyIHRyaWdnZXI7XG5cbiAgZm9yIChfaSA9IDA7IF9pIDwgX3RyaWdnZXJzLmxlbmd0aDsgX2krKykge1xuICAgIHRyaWdnZXIgPSBfdHJpZ2dlcnNbX2ldO1xuXG4gICAgaWYgKHRyaWdnZXIgJiYgKCFtZWRpYSB8fCB0cmlnZ2VyLl9jdHggPT09IG1lZGlhKSkge1xuICAgICAgaWYgKGtpbGwpIHtcbiAgICAgICAgdHJpZ2dlci5raWxsKDEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdHJpZ2dlci5yZXZlcnQodHJ1ZSwgdHJ1ZSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgX2lzUmV2ZXJ0ZWQgPSB0cnVlO1xuICBtZWRpYSAmJiBfcmV2ZXJ0UmVjb3JkZWQobWVkaWEpO1xuICBtZWRpYSB8fCBfZGlzcGF0Y2goXCJyZXZlcnRcIik7XG59LFxuICAgIF9jbGVhclNjcm9sbE1lbW9yeSA9IGZ1bmN0aW9uIF9jbGVhclNjcm9sbE1lbW9yeShzY3JvbGxSZXN0b3JhdGlvbiwgZm9yY2UpIHtcbiAgLy8gemVyby1vdXQgYWxsIHRoZSByZWNvcmRlZCBzY3JvbGwgcG9zaXRpb25zLiBEb24ndCB1c2UgX3RyaWdnZXJzIGJlY2F1c2UgaWYsIGZvciBleGFtcGxlLCAubWF0Y2hNZWRpYSgpIGlzIHVzZWQgdG8gY3JlYXRlIHNvbWUgU2Nyb2xsVHJpZ2dlcnMgYW5kIHRoZW4gdGhlIHVzZXIgcmVzaXplcyBhbmQgaXQgcmVtb3ZlcyBBTEwgU2Nyb2xsVHJpZ2dlcnMsIGFuZCB0aGVuIGdvIGJhY2sgdG8gYSBzaXplIHdoZXJlIHRoZXJlIGFyZSBTY3JvbGxUcmlnZ2VycywgaXQgd291bGQgaGF2ZSBrZXB0IHRoZSBwb3NpdGlvbihzKSBzYXZlZCBmcm9tIHRoZSBpbml0aWFsIHN0YXRlLlxuICBfc2Nyb2xsZXJzLmNhY2hlKys7XG4gIChmb3JjZSB8fCAhX3JlZnJlc2hpbmdBbGwpICYmIF9zY3JvbGxlcnMuZm9yRWFjaChmdW5jdGlvbiAob2JqKSB7XG4gICAgcmV0dXJuIF9pc0Z1bmN0aW9uKG9iaikgJiYgb2JqLmNhY2hlSUQrKyAmJiAob2JqLnJlYyA9IDApO1xuICB9KTtcbiAgX2lzU3RyaW5nKHNjcm9sbFJlc3RvcmF0aW9uKSAmJiAoX3dpbi5oaXN0b3J5LnNjcm9sbFJlc3RvcmF0aW9uID0gX3Njcm9sbFJlc3RvcmF0aW9uID0gc2Nyb2xsUmVzdG9yYXRpb24pO1xufSxcbiAgICBfcmVmcmVzaGluZ0FsbCxcbiAgICBfcmVmcmVzaElEID0gMCxcbiAgICBfcXVldWVSZWZyZXNoSUQsXG4gICAgX3F1ZXVlUmVmcmVzaEFsbCA9IGZ1bmN0aW9uIF9xdWV1ZVJlZnJlc2hBbGwoKSB7XG4gIC8vIHdlIGRvbid0IHdhbnQgdG8gY2FsbCBfcmVmcmVzaEFsbCgpIGV2ZXJ5IHRpbWUgd2UgY3JlYXRlIGEgbmV3IFNjcm9sbFRyaWdnZXIgKGZvciBwZXJmb3JtYW5jZSByZWFzb25zKSAtIGl0J3MgYmV0dGVyIHRvIGJhdGNoIHRoZW0uIFNvbWUgZnJhbWV3b3JrcyBkeW5hbWljYWxseSBsb2FkIGNvbnRlbnQgYW5kIHdlIGNhbid0IHJlbHkgb24gdGhlIHdpbmRvdydzIFwibG9hZFwiIG9yIFwiRE9NQ29udGVudExvYWRlZFwiIGV2ZW50cyB0byB0cmlnZ2VyIGl0LlxuICBpZiAoX3F1ZXVlUmVmcmVzaElEICE9PSBfcmVmcmVzaElEKSB7XG4gICAgdmFyIGlkID0gX3F1ZXVlUmVmcmVzaElEID0gX3JlZnJlc2hJRDtcbiAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZnVuY3Rpb24gKCkge1xuICAgICAgcmV0dXJuIGlkID09PSBfcmVmcmVzaElEICYmIF9yZWZyZXNoQWxsKHRydWUpO1xuICAgIH0pO1xuICB9XG59LFxuICAgIF9yZWZyZXNoMTAwdmggPSBmdW5jdGlvbiBfcmVmcmVzaDEwMHZoKCkge1xuICBfYm9keS5hcHBlbmRDaGlsZChfZGl2MTAwdmgpO1xuXG4gIF8xMDB2aCA9ICFfbm9ybWFsaXplciAmJiBfZGl2MTAwdmgub2Zmc2V0SGVpZ2h0IHx8IF93aW4uaW5uZXJIZWlnaHQ7XG5cbiAgX2JvZHkucmVtb3ZlQ2hpbGQoX2RpdjEwMHZoKTtcbn0sXG4gICAgX2hpZGVBbGxNYXJrZXJzID0gZnVuY3Rpb24gX2hpZGVBbGxNYXJrZXJzKGhpZGUpIHtcbiAgcmV0dXJuIF90b0FycmF5KFwiLmdzYXAtbWFya2VyLXN0YXJ0LCAuZ3NhcC1tYXJrZXItZW5kLCAuZ3NhcC1tYXJrZXItc2Nyb2xsZXItc3RhcnQsIC5nc2FwLW1hcmtlci1zY3JvbGxlci1lbmRcIikuZm9yRWFjaChmdW5jdGlvbiAoZWwpIHtcbiAgICByZXR1cm4gZWwuc3R5bGUuZGlzcGxheSA9IGhpZGUgPyBcIm5vbmVcIiA6IFwiYmxvY2tcIjtcbiAgfSk7XG59LFxuICAgIF9yZWZyZXNoQWxsID0gZnVuY3Rpb24gX3JlZnJlc2hBbGwoZm9yY2UsIHNraXBSZXZlcnQpIHtcbiAgX2RvY0VsID0gX2RvYy5kb2N1bWVudEVsZW1lbnQ7IC8vIHNvbWUgZnJhbWV3b3JrcyBsaWtlIEFzdHJvIG1heSBjYWNoZSB0aGUgPGJvZHk+IGFuZCByZXBsYWNlIGl0IGR1cmluZyByb3V0aW5nLCBzbyB3ZSdsbCBqdXN0IHJlLXJlY29yZCB0aGUgX2RvY0VsIGFuZCBfYm9keSBmb3Igc2FmZXR5IChvdGhlcndpc2UsIHRoZSBtYXJrZXJzIG1heSBub3QgZ2V0IGFkZGVkIHByb3Blcmx5KS5cblxuICBfYm9keSA9IF9kb2MuYm9keTtcbiAgX3Jvb3QgPSBbX3dpbiwgX2RvYywgX2RvY0VsLCBfYm9keV07XG5cbiAgaWYgKF9sYXN0U2Nyb2xsVGltZSAmJiAhZm9yY2UgJiYgIV9pc1JldmVydGVkKSB7XG4gICAgX2FkZExpc3RlbmVyKFNjcm9sbFRyaWdnZXIsIFwic2Nyb2xsRW5kXCIsIF9zb2Z0UmVmcmVzaCk7XG5cbiAgICByZXR1cm47XG4gIH1cblxuICBfcmVmcmVzaDEwMHZoKCk7XG5cbiAgX3JlZnJlc2hpbmdBbGwgPSBTY3JvbGxUcmlnZ2VyLmlzUmVmcmVzaGluZyA9IHRydWU7XG4gIF9pc1JldmVydGVkIHx8IF9yZWNvcmRTY3JvbGxQb3NpdGlvbnMoKTtcblxuICB2YXIgcmVmcmVzaEluaXRzID0gX2Rpc3BhdGNoKFwicmVmcmVzaEluaXRcIik7XG5cbiAgX3NvcnQgJiYgU2Nyb2xsVHJpZ2dlci5zb3J0KCk7XG4gIHNraXBSZXZlcnQgfHwgX3JldmVydEFsbCgpO1xuXG4gIF9zY3JvbGxlcnMuZm9yRWFjaChmdW5jdGlvbiAob2JqKSB7XG4gICAgaWYgKF9pc0Z1bmN0aW9uKG9iaikpIHtcbiAgICAgIG9iai5zbW9vdGggJiYgKG9iai50YXJnZXQuc3R5bGUuc2Nyb2xsQmVoYXZpb3IgPSBcImF1dG9cIik7IC8vIHNtb290aCBzY3JvbGxpbmcgaW50ZXJmZXJlc1xuXG4gICAgICBvYmooMCk7XG4gICAgfVxuICB9KTtcblxuICBfdHJpZ2dlcnMuc2xpY2UoMCkuZm9yRWFjaChmdW5jdGlvbiAodCkge1xuICAgIHJldHVybiB0LnJlZnJlc2goKTtcbiAgfSk7IC8vIGRvbid0IGxvb3Agd2l0aCBfaSBiZWNhdXNlIGR1cmluZyBhIHJlZnJlc2goKSBzb21lb25lIGNvdWxkIGNhbGwgU2Nyb2xsVHJpZ2dlci51cGRhdGUoKSB3aGljaCB3b3VsZCBpdGVyYXRlIHRocm91Z2ggX2kgcmVzdWx0aW5nIGluIGEgc2tpcC5cblxuXG4gIF9pc1JldmVydGVkID0gZmFsc2U7XG5cbiAgX3RyaWdnZXJzLmZvckVhY2goZnVuY3Rpb24gKHQpIHtcbiAgICAvLyBuZXN0ZWQgcGlucyAocGlubmVkQ29udGFpbmVyKSB3aXRoIHBpblNwYWNpbmcgbWF5IGV4cGFuZCB0aGUgY29udGFpbmVyLCBzbyB3ZSBtdXN0IGFjY29tbW9kYXRlIHRoYXQgaGVyZS5cbiAgICBpZiAodC5fc3ViUGluT2Zmc2V0ICYmIHQucGluKSB7XG4gICAgICB2YXIgcHJvcCA9IHQudmFycy5ob3Jpem9udGFsID8gXCJvZmZzZXRXaWR0aFwiIDogXCJvZmZzZXRIZWlnaHRcIixcbiAgICAgICAgICBvcmlnaW5hbCA9IHQucGluW3Byb3BdO1xuICAgICAgdC5yZXZlcnQodHJ1ZSwgMSk7XG4gICAgICB0LmFkanVzdFBpblNwYWNpbmcodC5waW5bcHJvcF0gLSBvcmlnaW5hbCk7XG4gICAgICB0LnJlZnJlc2goKTtcbiAgICB9XG4gIH0pO1xuXG4gIF9jbGFtcGluZ01heCA9IDE7IC8vIHBpblNwYWNpbmcgbWlnaHQgYmUgcHJvcHBpbmcgYSBwYWdlIG9wZW4sIHRodXMgd2hlbiB3ZSAuc2V0UG9zaXRpb25zKCkgdG8gY2xhbXAgYSBTY3JvbGxUcmlnZ2VyJ3MgZW5kIHdlIHNob3VsZCBsZWF2ZSB0aGUgcGluU3BhY2luZyBhbG9uZS4gVGhhdCdzIHdoYXQgdGhpcyBmbGFnIGlzIGZvci5cblxuICBfaGlkZUFsbE1hcmtlcnModHJ1ZSk7XG5cbiAgX3RyaWdnZXJzLmZvckVhY2goZnVuY3Rpb24gKHQpIHtcbiAgICAvLyB0aGUgc2Nyb2xsZXIncyBtYXggc2Nyb2xsIHBvc2l0aW9uIG1heSBjaGFuZ2UgYWZ0ZXIgYWxsIHRoZSBTY3JvbGxUcmlnZ2VycyByZWZyZXNoZWQgKGxpa2UgcGlubmluZyBjb3VsZCBwdXNoIGl0IGRvd24pLCBzbyB3ZSBuZWVkIHRvIGxvb3AgYmFjayBhbmQgY29ycmVjdCBhbnkgd2l0aCBlbmQ6IFwibWF4XCIuIFNhbWUgZm9yIGFueXRoaW5nIHdpdGggYSBjbGFtcGVkIGVuZFxuICAgIHZhciBtYXggPSBfbWF4U2Nyb2xsKHQuc2Nyb2xsZXIsIHQuX2RpciksXG4gICAgICAgIGVuZENsYW1wID0gdC52YXJzLmVuZCA9PT0gXCJtYXhcIiB8fCB0Ll9lbmRDbGFtcCAmJiB0LmVuZCA+IG1heCxcbiAgICAgICAgc3RhcnRDbGFtcCA9IHQuX3N0YXJ0Q2xhbXAgJiYgdC5zdGFydCA+PSBtYXg7XG5cbiAgICAoZW5kQ2xhbXAgfHwgc3RhcnRDbGFtcCkgJiYgdC5zZXRQb3NpdGlvbnMoc3RhcnRDbGFtcCA/IG1heCAtIDEgOiB0LnN0YXJ0LCBlbmRDbGFtcCA/IE1hdGgubWF4KHN0YXJ0Q2xhbXAgPyBtYXggOiB0LnN0YXJ0ICsgMSwgbWF4KSA6IHQuZW5kLCB0cnVlKTtcbiAgfSk7XG5cbiAgX2hpZGVBbGxNYXJrZXJzKGZhbHNlKTtcblxuICBfY2xhbXBpbmdNYXggPSAwO1xuICByZWZyZXNoSW5pdHMuZm9yRWFjaChmdW5jdGlvbiAocmVzdWx0KSB7XG4gICAgcmV0dXJuIHJlc3VsdCAmJiByZXN1bHQucmVuZGVyICYmIHJlc3VsdC5yZW5kZXIoLTEpO1xuICB9KTsgLy8gaWYgdGhlIG9uUmVmcmVzaEluaXQoKSByZXR1cm5zIGFuIGFuaW1hdGlvbiAodHlwaWNhbGx5IGEgZ3NhcC5zZXQoKSksIHJldmVydCBpdC4gVGhpcyBtYWtlcyBpdCBlYXN5IHRvIHB1dCB0aGluZ3MgaW4gYSBjZXJ0YWluIHNwb3QgYmVmb3JlIHJlZnJlc2hpbmcgZm9yIG1lYXN1cmVtZW50IHB1cnBvc2VzLCBhbmQgdGhlbiBwdXQgdGhpbmdzIGJhY2suXG5cbiAgX3Njcm9sbGVycy5mb3JFYWNoKGZ1bmN0aW9uIChvYmopIHtcbiAgICBpZiAoX2lzRnVuY3Rpb24ob2JqKSkge1xuICAgICAgb2JqLnNtb290aCAmJiByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gb2JqLnRhcmdldC5zdHlsZS5zY3JvbGxCZWhhdmlvciA9IFwic21vb3RoXCI7XG4gICAgICB9KTtcbiAgICAgIG9iai5yZWMgJiYgb2JqKG9iai5yZWMpO1xuICAgIH1cbiAgfSk7XG5cbiAgX2NsZWFyU2Nyb2xsTWVtb3J5KF9zY3JvbGxSZXN0b3JhdGlvbiwgMSk7XG5cbiAgX3Jlc2l6ZURlbGF5LnBhdXNlKCk7XG5cbiAgX3JlZnJlc2hJRCsrO1xuICBfcmVmcmVzaGluZ0FsbCA9IDI7XG5cbiAgX3VwZGF0ZUFsbCgyKTtcblxuICBfdHJpZ2dlcnMuZm9yRWFjaChmdW5jdGlvbiAodCkge1xuICAgIHJldHVybiBfaXNGdW5jdGlvbih0LnZhcnMub25SZWZyZXNoKSAmJiB0LnZhcnMub25SZWZyZXNoKHQpO1xuICB9KTtcblxuICBfcmVmcmVzaGluZ0FsbCA9IFNjcm9sbFRyaWdnZXIuaXNSZWZyZXNoaW5nID0gZmFsc2U7XG5cbiAgX2Rpc3BhdGNoKFwicmVmcmVzaFwiKTtcbn0sXG4gICAgX2xhc3RTY3JvbGwgPSAwLFxuICAgIF9kaXJlY3Rpb24gPSAxLFxuICAgIF9wcmltYXJ5LFxuICAgIF91cGRhdGVBbGwgPSBmdW5jdGlvbiBfdXBkYXRlQWxsKGZvcmNlKSB7XG4gIGlmIChmb3JjZSA9PT0gMiB8fCAhX3JlZnJlc2hpbmdBbGwgJiYgIV9pc1JldmVydGVkKSB7XG4gICAgLy8gX2lzUmV2ZXJ0ZWQgY291bGQgYmUgdHJ1ZSBpZiwgZm9yIGV4YW1wbGUsIGEgbWF0Y2hNZWRpYSgpIGlzIGluIHRoZSBwcm9jZXNzIG9mIGV4ZWN1dGluZy4gV2UgZG9uJ3Qgd2FudCB0byB1cGRhdGUgZHVyaW5nIHRoZSB0aW1lIGV2ZXJ5dGhpbmcgaXMgcmV2ZXJ0ZWQuXG4gICAgU2Nyb2xsVHJpZ2dlci5pc1VwZGF0aW5nID0gdHJ1ZTtcbiAgICBfcHJpbWFyeSAmJiBfcHJpbWFyeS51cGRhdGUoMCk7IC8vIFNjcm9sbFNtb290aGVyIHVzZXMgcmVmcmVzaFByaW9yaXR5IC05OTk5IHRvIGJlY29tZSB0aGUgcHJpbWFyeSB0aGF0IGdldHMgdXBkYXRlZCBiZWZvcmUgYWxsIG90aGVycyBiZWNhdXNlIGl0IGFmZmVjdHMgdGhlIHNjcm9sbCBwb3NpdGlvbi5cblxuICAgIHZhciBsID0gX3RyaWdnZXJzLmxlbmd0aCxcbiAgICAgICAgdGltZSA9IF9nZXRUaW1lKCksXG4gICAgICAgIHJlY29yZFZlbG9jaXR5ID0gdGltZSAtIF90aW1lMSA+PSA1MCxcbiAgICAgICAgc2Nyb2xsID0gbCAmJiBfdHJpZ2dlcnNbMF0uc2Nyb2xsKCk7XG5cbiAgICBfZGlyZWN0aW9uID0gX2xhc3RTY3JvbGwgPiBzY3JvbGwgPyAtMSA6IDE7XG4gICAgX3JlZnJlc2hpbmdBbGwgfHwgKF9sYXN0U2Nyb2xsID0gc2Nyb2xsKTtcblxuICAgIGlmIChyZWNvcmRWZWxvY2l0eSkge1xuICAgICAgaWYgKF9sYXN0U2Nyb2xsVGltZSAmJiAhX3BvaW50ZXJJc0Rvd24gJiYgdGltZSAtIF9sYXN0U2Nyb2xsVGltZSA+IDIwMCkge1xuICAgICAgICBfbGFzdFNjcm9sbFRpbWUgPSAwO1xuXG4gICAgICAgIF9kaXNwYXRjaChcInNjcm9sbEVuZFwiKTtcbiAgICAgIH1cblxuICAgICAgX3RpbWUyID0gX3RpbWUxO1xuICAgICAgX3RpbWUxID0gdGltZTtcbiAgICB9XG5cbiAgICBpZiAoX2RpcmVjdGlvbiA8IDApIHtcbiAgICAgIF9pID0gbDtcblxuICAgICAgd2hpbGUgKF9pLS0gPiAwKSB7XG4gICAgICAgIF90cmlnZ2Vyc1tfaV0gJiYgX3RyaWdnZXJzW19pXS51cGRhdGUoMCwgcmVjb3JkVmVsb2NpdHkpO1xuICAgICAgfVxuXG4gICAgICBfZGlyZWN0aW9uID0gMTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChfaSA9IDA7IF9pIDwgbDsgX2krKykge1xuICAgICAgICBfdHJpZ2dlcnNbX2ldICYmIF90cmlnZ2Vyc1tfaV0udXBkYXRlKDAsIHJlY29yZFZlbG9jaXR5KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBTY3JvbGxUcmlnZ2VyLmlzVXBkYXRpbmcgPSBmYWxzZTtcbiAgfVxuXG4gIF9yYWZJRCA9IDA7XG59LFxuICAgIF9wcm9wTmFtZXNUb0NvcHkgPSBbX2xlZnQsIF90b3AsIF9ib3R0b20sIF9yaWdodCwgX21hcmdpbiArIF9Cb3R0b20sIF9tYXJnaW4gKyBfUmlnaHQsIF9tYXJnaW4gKyBfVG9wLCBfbWFyZ2luICsgX0xlZnQsIFwiZGlzcGxheVwiLCBcImZsZXhTaHJpbmtcIiwgXCJmbG9hdFwiLCBcInpJbmRleFwiLCBcImdyaWRDb2x1bW5TdGFydFwiLCBcImdyaWRDb2x1bW5FbmRcIiwgXCJncmlkUm93U3RhcnRcIiwgXCJncmlkUm93RW5kXCIsIFwiZ3JpZEFyZWFcIiwgXCJqdXN0aWZ5U2VsZlwiLCBcImFsaWduU2VsZlwiLCBcInBsYWNlU2VsZlwiLCBcIm9yZGVyXCJdLFxuICAgIF9zdGF0ZVByb3BzID0gX3Byb3BOYW1lc1RvQ29weS5jb25jYXQoW193aWR0aCwgX2hlaWdodCwgXCJib3hTaXppbmdcIiwgXCJtYXhcIiArIF9XaWR0aCwgXCJtYXhcIiArIF9IZWlnaHQsIFwicG9zaXRpb25cIiwgX21hcmdpbiwgX3BhZGRpbmcsIF9wYWRkaW5nICsgX1RvcCwgX3BhZGRpbmcgKyBfUmlnaHQsIF9wYWRkaW5nICsgX0JvdHRvbSwgX3BhZGRpbmcgKyBfTGVmdF0pLFxuICAgIF9zd2FwUGluT3V0ID0gZnVuY3Rpb24gX3N3YXBQaW5PdXQocGluLCBzcGFjZXIsIHN0YXRlKSB7XG4gIF9zZXRTdGF0ZShzdGF0ZSk7XG5cbiAgdmFyIGNhY2hlID0gcGluLl9nc2FwO1xuXG4gIGlmIChjYWNoZS5zcGFjZXJJc05hdGl2ZSkge1xuICAgIF9zZXRTdGF0ZShjYWNoZS5zcGFjZXJTdGF0ZSk7XG4gIH0gZWxzZSBpZiAocGluLl9nc2FwLnN3YXBwZWRJbikge1xuICAgIHZhciBwYXJlbnQgPSBzcGFjZXIucGFyZW50Tm9kZTtcblxuICAgIGlmIChwYXJlbnQpIHtcbiAgICAgIHBhcmVudC5pbnNlcnRCZWZvcmUocGluLCBzcGFjZXIpO1xuICAgICAgcGFyZW50LnJlbW92ZUNoaWxkKHNwYWNlcik7XG4gICAgfVxuICB9XG5cbiAgcGluLl9nc2FwLnN3YXBwZWRJbiA9IGZhbHNlO1xufSxcbiAgICBfc3dhcFBpbkluID0gZnVuY3Rpb24gX3N3YXBQaW5JbihwaW4sIHNwYWNlciwgY3MsIHNwYWNlclN0YXRlKSB7XG4gIGlmICghcGluLl9nc2FwLnN3YXBwZWRJbikge1xuICAgIHZhciBpID0gX3Byb3BOYW1lc1RvQ29weS5sZW5ndGgsXG4gICAgICAgIHNwYWNlclN0eWxlID0gc3BhY2VyLnN0eWxlLFxuICAgICAgICBwaW5TdHlsZSA9IHBpbi5zdHlsZSxcbiAgICAgICAgcDtcblxuICAgIHdoaWxlIChpLS0pIHtcbiAgICAgIHAgPSBfcHJvcE5hbWVzVG9Db3B5W2ldO1xuICAgICAgc3BhY2VyU3R5bGVbcF0gPSBjc1twXTtcbiAgICB9XG5cbiAgICBzcGFjZXJTdHlsZS5wb3NpdGlvbiA9IGNzLnBvc2l0aW9uID09PSBcImFic29sdXRlXCIgPyBcImFic29sdXRlXCIgOiBcInJlbGF0aXZlXCI7XG4gICAgY3MuZGlzcGxheSA9PT0gXCJpbmxpbmVcIiAmJiAoc3BhY2VyU3R5bGUuZGlzcGxheSA9IFwiaW5saW5lLWJsb2NrXCIpO1xuICAgIHBpblN0eWxlW19ib3R0b21dID0gcGluU3R5bGVbX3JpZ2h0XSA9IFwiYXV0b1wiO1xuICAgIHNwYWNlclN0eWxlLmZsZXhCYXNpcyA9IGNzLmZsZXhCYXNpcyB8fCBcImF1dG9cIjtcbiAgICBzcGFjZXJTdHlsZS5vdmVyZmxvdyA9IFwidmlzaWJsZVwiO1xuICAgIHNwYWNlclN0eWxlLmJveFNpemluZyA9IFwiYm9yZGVyLWJveFwiO1xuICAgIHNwYWNlclN0eWxlW193aWR0aF0gPSBfZ2V0U2l6ZShwaW4sIF9ob3Jpem9udGFsKSArIF9weDtcbiAgICBzcGFjZXJTdHlsZVtfaGVpZ2h0XSA9IF9nZXRTaXplKHBpbiwgX3ZlcnRpY2FsKSArIF9weDtcbiAgICBzcGFjZXJTdHlsZVtfcGFkZGluZ10gPSBwaW5TdHlsZVtfbWFyZ2luXSA9IHBpblN0eWxlW190b3BdID0gcGluU3R5bGVbX2xlZnRdID0gXCIwXCI7XG5cbiAgICBfc2V0U3RhdGUoc3BhY2VyU3RhdGUpO1xuXG4gICAgcGluU3R5bGVbX3dpZHRoXSA9IHBpblN0eWxlW1wibWF4XCIgKyBfV2lkdGhdID0gY3NbX3dpZHRoXTtcbiAgICBwaW5TdHlsZVtfaGVpZ2h0XSA9IHBpblN0eWxlW1wibWF4XCIgKyBfSGVpZ2h0XSA9IGNzW19oZWlnaHRdO1xuICAgIHBpblN0eWxlW19wYWRkaW5nXSA9IGNzW19wYWRkaW5nXTtcblxuICAgIGlmIChwaW4ucGFyZW50Tm9kZSAhPT0gc3BhY2VyKSB7XG4gICAgICBwaW4ucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoc3BhY2VyLCBwaW4pO1xuICAgICAgc3BhY2VyLmFwcGVuZENoaWxkKHBpbik7XG4gICAgfVxuXG4gICAgcGluLl9nc2FwLnN3YXBwZWRJbiA9IHRydWU7XG4gIH1cbn0sXG4gICAgX2NhcHNFeHAgPSAvKFtBLVpdKS9nLFxuICAgIF9zZXRTdGF0ZSA9IGZ1bmN0aW9uIF9zZXRTdGF0ZShzdGF0ZSkge1xuICBpZiAoc3RhdGUpIHtcbiAgICB2YXIgc3R5bGUgPSBzdGF0ZS50LnN0eWxlLFxuICAgICAgICBsID0gc3RhdGUubGVuZ3RoLFxuICAgICAgICBpID0gMCxcbiAgICAgICAgcCxcbiAgICAgICAgdmFsdWU7XG4gICAgKHN0YXRlLnQuX2dzYXAgfHwgZ3NhcC5jb3JlLmdldENhY2hlKHN0YXRlLnQpKS51bmNhY2hlID0gMTsgLy8gb3RoZXJ3aXNlIHRyYW5zZm9ybXMgbWF5IGJlIG9mZlxuXG4gICAgZm9yICg7IGkgPCBsOyBpICs9IDIpIHtcbiAgICAgIHZhbHVlID0gc3RhdGVbaSArIDFdO1xuICAgICAgcCA9IHN0YXRlW2ldO1xuXG4gICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgc3R5bGVbcF0gPSB2YWx1ZTtcbiAgICAgIH0gZWxzZSBpZiAoc3R5bGVbcF0pIHtcbiAgICAgICAgc3R5bGUucmVtb3ZlUHJvcGVydHkocC5yZXBsYWNlKF9jYXBzRXhwLCBcIi0kMVwiKS50b0xvd2VyQ2FzZSgpKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn0sXG4gICAgX2dldFN0YXRlID0gZnVuY3Rpb24gX2dldFN0YXRlKGVsZW1lbnQpIHtcbiAgLy8gcmV0dXJucyBhbiBBcnJheSB3aXRoIGFsdGVybmF0aW5nIHZhbHVlcyBsaWtlIFtwcm9wZXJ0eSwgdmFsdWUsIHByb3BlcnR5LCB2YWx1ZV0gYW5kIGEgXCJ0XCIgcHJvcGVydHkgcG9pbnRpbmcgdG8gdGhlIHRhcmdldCAoZWxlbWVudCkuIE1ha2VzIGl0IGZhc3QgYW5kIGNoZWFwLlxuICB2YXIgbCA9IF9zdGF0ZVByb3BzLmxlbmd0aCxcbiAgICAgIHN0eWxlID0gZWxlbWVudC5zdHlsZSxcbiAgICAgIHN0YXRlID0gW10sXG4gICAgICBpID0gMDtcblxuICBmb3IgKDsgaSA8IGw7IGkrKykge1xuICAgIHN0YXRlLnB1c2goX3N0YXRlUHJvcHNbaV0sIHN0eWxlW19zdGF0ZVByb3BzW2ldXSk7XG4gIH1cblxuICBzdGF0ZS50ID0gZWxlbWVudDtcbiAgcmV0dXJuIHN0YXRlO1xufSxcbiAgICBfY29weVN0YXRlID0gZnVuY3Rpb24gX2NvcHlTdGF0ZShzdGF0ZSwgb3ZlcnJpZGUsIG9taXRPZmZzZXRzKSB7XG4gIHZhciByZXN1bHQgPSBbXSxcbiAgICAgIGwgPSBzdGF0ZS5sZW5ndGgsXG4gICAgICBpID0gb21pdE9mZnNldHMgPyA4IDogMCxcbiAgICAgIC8vIHNraXAgdG9wLCBsZWZ0LCByaWdodCwgYm90dG9tIGlmIG9taXRPZmZzZXRzIGlzIHRydWVcbiAgcDtcblxuICBmb3IgKDsgaSA8IGw7IGkgKz0gMikge1xuICAgIHAgPSBzdGF0ZVtpXTtcbiAgICByZXN1bHQucHVzaChwLCBwIGluIG92ZXJyaWRlID8gb3ZlcnJpZGVbcF0gOiBzdGF0ZVtpICsgMV0pO1xuICB9XG5cbiAgcmVzdWx0LnQgPSBzdGF0ZS50O1xuICByZXR1cm4gcmVzdWx0O1xufSxcbiAgICBfd2luT2Zmc2V0cyA9IHtcbiAgbGVmdDogMCxcbiAgdG9wOiAwXG59LFxuICAgIC8vIC8vIHBvdGVudGlhbCBmdXR1cmUgZmVhdHVyZSAoPykgQWxsb3cgdXNlcnMgdG8gY2FsY3VsYXRlIHdoZXJlIGEgdHJpZ2dlciBoaXRzIChzY3JvbGwgcG9zaXRpb24pIGxpa2UgZ2V0U2Nyb2xsUG9zaXRpb24oXCIjaWRcIiwgXCJ0b3AgYm90dG9tXCIpXG4vLyBfZ2V0U2Nyb2xsUG9zaXRpb24gPSAodHJpZ2dlciwgcG9zaXRpb24sIHtzY3JvbGxlciwgY29udGFpbmVyQW5pbWF0aW9uLCBob3Jpem9udGFsfSkgPT4ge1xuLy8gXHRzY3JvbGxlciA9IF9nZXRUYXJnZXQoc2Nyb2xsZXIgfHwgX3dpbik7XG4vLyBcdGxldCBkaXJlY3Rpb24gPSBob3Jpem9udGFsID8gX2hvcml6b250YWwgOiBfdmVydGljYWwsXG4vLyBcdFx0aXNWaWV3cG9ydCA9IF9pc1ZpZXdwb3J0KHNjcm9sbGVyKTtcbi8vIFx0X2dldFNpemVGdW5jKHNjcm9sbGVyLCBpc1ZpZXdwb3J0LCBkaXJlY3Rpb24pO1xuLy8gXHRyZXR1cm4gX3BhcnNlUG9zaXRpb24ocG9zaXRpb24sIF9nZXRUYXJnZXQodHJpZ2dlciksIF9nZXRTaXplRnVuYyhzY3JvbGxlciwgaXNWaWV3cG9ydCwgZGlyZWN0aW9uKSgpLCBkaXJlY3Rpb24sIF9nZXRTY3JvbGxGdW5jKHNjcm9sbGVyLCBkaXJlY3Rpb24pKCksIDAsIDAsIDAsIF9nZXRPZmZzZXRzRnVuYyhzY3JvbGxlciwgaXNWaWV3cG9ydCkoKSwgaXNWaWV3cG9ydCA/IDAgOiBwYXJzZUZsb2F0KF9nZXRDb21wdXRlZFN0eWxlKHNjcm9sbGVyKVtcImJvcmRlclwiICsgZGlyZWN0aW9uLnAyICsgX1dpZHRoXSkgfHwgMCwgMCwgY29udGFpbmVyQW5pbWF0aW9uID8gY29udGFpbmVyQW5pbWF0aW9uLmR1cmF0aW9uKCkgOiBfbWF4U2Nyb2xsKHNjcm9sbGVyKSwgY29udGFpbmVyQW5pbWF0aW9uKTtcbi8vIH0sXG5fcGFyc2VQb3NpdGlvbiA9IGZ1bmN0aW9uIF9wYXJzZVBvc2l0aW9uKHZhbHVlLCB0cmlnZ2VyLCBzY3JvbGxlclNpemUsIGRpcmVjdGlvbiwgc2Nyb2xsLCBtYXJrZXIsIG1hcmtlclNjcm9sbGVyLCBzZWxmLCBzY3JvbGxlckJvdW5kcywgYm9yZGVyV2lkdGgsIHVzZUZpeGVkUG9zaXRpb24sIHNjcm9sbGVyTWF4LCBjb250YWluZXJBbmltYXRpb24sIGNsYW1wWmVyb1Byb3ApIHtcbiAgX2lzRnVuY3Rpb24odmFsdWUpICYmICh2YWx1ZSA9IHZhbHVlKHNlbGYpKTtcblxuICBpZiAoX2lzU3RyaW5nKHZhbHVlKSAmJiB2YWx1ZS5zdWJzdHIoMCwgMykgPT09IFwibWF4XCIpIHtcbiAgICB2YWx1ZSA9IHNjcm9sbGVyTWF4ICsgKHZhbHVlLmNoYXJBdCg0KSA9PT0gXCI9XCIgPyBfb2Zmc2V0VG9QeChcIjBcIiArIHZhbHVlLnN1YnN0cigzKSwgc2Nyb2xsZXJTaXplKSA6IDApO1xuICB9XG5cbiAgdmFyIHRpbWUgPSBjb250YWluZXJBbmltYXRpb24gPyBjb250YWluZXJBbmltYXRpb24udGltZSgpIDogMCxcbiAgICAgIHAxLFxuICAgICAgcDIsXG4gICAgICBlbGVtZW50O1xuICBjb250YWluZXJBbmltYXRpb24gJiYgY29udGFpbmVyQW5pbWF0aW9uLnNlZWsoMCk7XG4gIGlzTmFOKHZhbHVlKSB8fCAodmFsdWUgPSArdmFsdWUpOyAvLyBjb252ZXJ0IGEgc3RyaW5nIG51bWJlciBsaWtlIFwiNDVcIiB0byBhbiBhY3R1YWwgbnVtYmVyXG5cbiAgaWYgKCFfaXNOdW1iZXIodmFsdWUpKSB7XG4gICAgX2lzRnVuY3Rpb24odHJpZ2dlcikgJiYgKHRyaWdnZXIgPSB0cmlnZ2VyKHNlbGYpKTtcbiAgICB2YXIgb2Zmc2V0cyA9ICh2YWx1ZSB8fCBcIjBcIikuc3BsaXQoXCIgXCIpLFxuICAgICAgICBib3VuZHMsXG4gICAgICAgIGxvY2FsT2Zmc2V0LFxuICAgICAgICBnbG9iYWxPZmZzZXQsXG4gICAgICAgIGRpc3BsYXk7XG4gICAgZWxlbWVudCA9IF9nZXRUYXJnZXQodHJpZ2dlciwgc2VsZikgfHwgX2JvZHk7XG4gICAgYm91bmRzID0gX2dldEJvdW5kcyhlbGVtZW50KSB8fCB7fTtcblxuICAgIGlmICgoIWJvdW5kcyB8fCAhYm91bmRzLmxlZnQgJiYgIWJvdW5kcy50b3ApICYmIF9nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpLmRpc3BsYXkgPT09IFwibm9uZVwiKSB7XG4gICAgICAvLyBpZiBkaXNwbGF5IGlzIFwibm9uZVwiLCBpdCB3b24ndCByZXBvcnQgZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkgcHJvcGVybHlcbiAgICAgIGRpc3BsYXkgPSBlbGVtZW50LnN0eWxlLmRpc3BsYXk7XG4gICAgICBlbGVtZW50LnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgICBib3VuZHMgPSBfZ2V0Qm91bmRzKGVsZW1lbnQpO1xuICAgICAgZGlzcGxheSA/IGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IGRpc3BsYXkgOiBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwiZGlzcGxheVwiKTtcbiAgICB9XG5cbiAgICBsb2NhbE9mZnNldCA9IF9vZmZzZXRUb1B4KG9mZnNldHNbMF0sIGJvdW5kc1tkaXJlY3Rpb24uZF0pO1xuICAgIGdsb2JhbE9mZnNldCA9IF9vZmZzZXRUb1B4KG9mZnNldHNbMV0gfHwgXCIwXCIsIHNjcm9sbGVyU2l6ZSk7XG4gICAgdmFsdWUgPSBib3VuZHNbZGlyZWN0aW9uLnBdIC0gc2Nyb2xsZXJCb3VuZHNbZGlyZWN0aW9uLnBdIC0gYm9yZGVyV2lkdGggKyBsb2NhbE9mZnNldCArIHNjcm9sbCAtIGdsb2JhbE9mZnNldDtcbiAgICBtYXJrZXJTY3JvbGxlciAmJiBfcG9zaXRpb25NYXJrZXIobWFya2VyU2Nyb2xsZXIsIGdsb2JhbE9mZnNldCwgZGlyZWN0aW9uLCBzY3JvbGxlclNpemUgLSBnbG9iYWxPZmZzZXQgPCAyMCB8fCBtYXJrZXJTY3JvbGxlci5faXNTdGFydCAmJiBnbG9iYWxPZmZzZXQgPiAyMCk7XG4gICAgc2Nyb2xsZXJTaXplIC09IHNjcm9sbGVyU2l6ZSAtIGdsb2JhbE9mZnNldDsgLy8gYWRqdXN0IGZvciB0aGUgbWFya2VyXG4gIH0gZWxzZSB7XG4gICAgY29udGFpbmVyQW5pbWF0aW9uICYmICh2YWx1ZSA9IGdzYXAudXRpbHMubWFwUmFuZ2UoY29udGFpbmVyQW5pbWF0aW9uLnNjcm9sbFRyaWdnZXIuc3RhcnQsIGNvbnRhaW5lckFuaW1hdGlvbi5zY3JvbGxUcmlnZ2VyLmVuZCwgMCwgc2Nyb2xsZXJNYXgsIHZhbHVlKSk7XG4gICAgbWFya2VyU2Nyb2xsZXIgJiYgX3Bvc2l0aW9uTWFya2VyKG1hcmtlclNjcm9sbGVyLCBzY3JvbGxlclNpemUsIGRpcmVjdGlvbiwgdHJ1ZSk7XG4gIH1cblxuICBpZiAoY2xhbXBaZXJvUHJvcCkge1xuICAgIHNlbGZbY2xhbXBaZXJvUHJvcF0gPSB2YWx1ZSB8fCAtMC4wMDE7XG4gICAgdmFsdWUgPCAwICYmICh2YWx1ZSA9IDApO1xuICB9XG5cbiAgaWYgKG1hcmtlcikge1xuICAgIHZhciBwb3NpdGlvbiA9IHZhbHVlICsgc2Nyb2xsZXJTaXplLFxuICAgICAgICBpc1N0YXJ0ID0gbWFya2VyLl9pc1N0YXJ0O1xuICAgIHAxID0gXCJzY3JvbGxcIiArIGRpcmVjdGlvbi5kMjtcblxuICAgIF9wb3NpdGlvbk1hcmtlcihtYXJrZXIsIHBvc2l0aW9uLCBkaXJlY3Rpb24sIGlzU3RhcnQgJiYgcG9zaXRpb24gPiAyMCB8fCAhaXNTdGFydCAmJiAodXNlRml4ZWRQb3NpdGlvbiA/IE1hdGgubWF4KF9ib2R5W3AxXSwgX2RvY0VsW3AxXSkgOiBtYXJrZXIucGFyZW50Tm9kZVtwMV0pIDw9IHBvc2l0aW9uICsgMSk7XG5cbiAgICBpZiAodXNlRml4ZWRQb3NpdGlvbikge1xuICAgICAgc2Nyb2xsZXJCb3VuZHMgPSBfZ2V0Qm91bmRzKG1hcmtlclNjcm9sbGVyKTtcbiAgICAgIHVzZUZpeGVkUG9zaXRpb24gJiYgKG1hcmtlci5zdHlsZVtkaXJlY3Rpb24ub3AucF0gPSBzY3JvbGxlckJvdW5kc1tkaXJlY3Rpb24ub3AucF0gLSBkaXJlY3Rpb24ub3AubSAtIG1hcmtlci5fb2Zmc2V0ICsgX3B4KTtcbiAgICB9XG4gIH1cblxuICBpZiAoY29udGFpbmVyQW5pbWF0aW9uICYmIGVsZW1lbnQpIHtcbiAgICBwMSA9IF9nZXRCb3VuZHMoZWxlbWVudCk7XG4gICAgY29udGFpbmVyQW5pbWF0aW9uLnNlZWsoc2Nyb2xsZXJNYXgpO1xuICAgIHAyID0gX2dldEJvdW5kcyhlbGVtZW50KTtcbiAgICBjb250YWluZXJBbmltYXRpb24uX2NhU2Nyb2xsRGlzdCA9IHAxW2RpcmVjdGlvbi5wXSAtIHAyW2RpcmVjdGlvbi5wXTtcbiAgICB2YWx1ZSA9IHZhbHVlIC8gY29udGFpbmVyQW5pbWF0aW9uLl9jYVNjcm9sbERpc3QgKiBzY3JvbGxlck1heDtcbiAgfVxuXG4gIGNvbnRhaW5lckFuaW1hdGlvbiAmJiBjb250YWluZXJBbmltYXRpb24uc2Vlayh0aW1lKTtcbiAgcmV0dXJuIGNvbnRhaW5lckFuaW1hdGlvbiA/IHZhbHVlIDogTWF0aC5yb3VuZCh2YWx1ZSk7XG59LFxuICAgIF9wcmVmaXhFeHAgPSAvKHdlYmtpdHxtb3p8bGVuZ3RofGNzc1RleHR8aW5zZXQpL2ksXG4gICAgX3JlcGFyZW50ID0gZnVuY3Rpb24gX3JlcGFyZW50KGVsZW1lbnQsIHBhcmVudCwgdG9wLCBsZWZ0KSB7XG4gIGlmIChlbGVtZW50LnBhcmVudE5vZGUgIT09IHBhcmVudCkge1xuICAgIHZhciBzdHlsZSA9IGVsZW1lbnQuc3R5bGUsXG4gICAgICAgIHAsXG4gICAgICAgIGNzO1xuXG4gICAgaWYgKHBhcmVudCA9PT0gX2JvZHkpIHtcbiAgICAgIGVsZW1lbnQuX3N0T3JpZyA9IHN0eWxlLmNzc1RleHQ7IC8vIHJlY29yZCBvcmlnaW5hbCBpbmxpbmUgc3R5bGVzIHNvIHdlIGNhbiByZXZlcnQgdGhlbSBsYXRlclxuXG4gICAgICBjcyA9IF9nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpO1xuXG4gICAgICBmb3IgKHAgaW4gY3MpIHtcbiAgICAgICAgLy8gbXVzdCBjb3B5IGFsbCByZWxldmFudCBzdHlsZXMgdG8gZW5zdXJlIHRoYXQgbm90aGluZyBjaGFuZ2VzIHZpc3VhbGx5IHdoZW4gd2UgcmVwYXJlbnQgdG8gdGhlIDxib2R5Pi4gU2tpcCB0aGUgdmVuZG9yIHByZWZpeGVkIG9uZXMuXG4gICAgICAgIGlmICghK3AgJiYgIV9wcmVmaXhFeHAudGVzdChwKSAmJiBjc1twXSAmJiB0eXBlb2Ygc3R5bGVbcF0gPT09IFwic3RyaW5nXCIgJiYgcCAhPT0gXCIwXCIpIHtcbiAgICAgICAgICBzdHlsZVtwXSA9IGNzW3BdO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHN0eWxlLnRvcCA9IHRvcDtcbiAgICAgIHN0eWxlLmxlZnQgPSBsZWZ0O1xuICAgIH0gZWxzZSB7XG4gICAgICBzdHlsZS5jc3NUZXh0ID0gZWxlbWVudC5fc3RPcmlnO1xuICAgIH1cblxuICAgIGdzYXAuY29yZS5nZXRDYWNoZShlbGVtZW50KS51bmNhY2hlID0gMTtcbiAgICBwYXJlbnQuYXBwZW5kQ2hpbGQoZWxlbWVudCk7XG4gIH1cbn0sXG4gICAgX2ludGVycnVwdGlvblRyYWNrZXIgPSBmdW5jdGlvbiBfaW50ZXJydXB0aW9uVHJhY2tlcihnZXRWYWx1ZUZ1bmMsIGluaXRpYWxWYWx1ZSwgb25JbnRlcnJ1cHQpIHtcbiAgdmFyIGxhc3QxID0gaW5pdGlhbFZhbHVlLFxuICAgICAgbGFzdDIgPSBsYXN0MTtcbiAgcmV0dXJuIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIHZhciBjdXJyZW50ID0gTWF0aC5yb3VuZChnZXRWYWx1ZUZ1bmMoKSk7IC8vIHJvdW5kIGJlY2F1c2UgaW4gc29tZSBbdmVyeSB1bmNvbW1vbl0gV2luZG93cyBlbnZpcm9ubWVudHMsIHNjcm9sbCBjYW4gZ2V0IHJlcG9ydGVkIHdpdGggZGVjaW1hbHMgZXZlbiB0aG91Z2ggaXQgd2FzIHNldCB3aXRob3V0LlxuXG4gICAgaWYgKGN1cnJlbnQgIT09IGxhc3QxICYmIGN1cnJlbnQgIT09IGxhc3QyICYmIE1hdGguYWJzKGN1cnJlbnQgLSBsYXN0MSkgPiAzICYmIE1hdGguYWJzKGN1cnJlbnQgLSBsYXN0MikgPiAzKSB7XG4gICAgICAvLyBpZiB0aGUgdXNlciBzY3JvbGxzLCBraWxsIHRoZSB0d2Vlbi4gaU9TIFNhZmFyaSBpbnRlcm1pdHRlbnRseSBtaXNyZXBvcnRzIHRoZSBzY3JvbGwgcG9zaXRpb24sIGl0IG1heSBiZSB0aGUgbW9zdCByZWNlbnRseS1zZXQgb25lIG9yIHRoZSBvbmUgYmVmb3JlIHRoYXQhIFdoZW4gU2FmYXJpIGlzIHpvb21lZCAoQ01ELSspLCBpdCBvZnRlbiBtaXNyZXBvcnRzIGFzIDEgcGl4ZWwgb2ZmIHRvbyEgU28gaWYgd2Ugc2V0IHRoZSBzY3JvbGwgcG9zaXRpb24gdG8gMTI1LCBmb3IgZXhhbXBsZSwgaXQnbGwgYWN0dWFsbHkgcmVwb3J0IGl0IGFzIDEyNC5cbiAgICAgIHZhbHVlID0gY3VycmVudDtcbiAgICAgIG9uSW50ZXJydXB0ICYmIG9uSW50ZXJydXB0KCk7XG4gICAgfVxuXG4gICAgbGFzdDIgPSBsYXN0MTtcbiAgICBsYXN0MSA9IE1hdGgucm91bmQodmFsdWUpO1xuICAgIHJldHVybiBsYXN0MTtcbiAgfTtcbn0sXG4gICAgX3NoaWZ0TWFya2VyID0gZnVuY3Rpb24gX3NoaWZ0TWFya2VyKG1hcmtlciwgZGlyZWN0aW9uLCB2YWx1ZSkge1xuICB2YXIgdmFycyA9IHt9O1xuICB2YXJzW2RpcmVjdGlvbi5wXSA9IFwiKz1cIiArIHZhbHVlO1xuICBnc2FwLnNldChtYXJrZXIsIHZhcnMpO1xufSxcbiAgICAvLyBfbWVyZ2VBbmltYXRpb25zID0gYW5pbWF0aW9ucyA9PiB7XG4vLyBcdGxldCB0bCA9IGdzYXAudGltZWxpbmUoe3Ntb290aENoaWxkVGltaW5nOiB0cnVlfSkuc3RhcnRUaW1lKE1hdGgubWluKC4uLmFuaW1hdGlvbnMubWFwKGEgPT4gYS5nbG9iYWxUaW1lKDApKSkpO1xuLy8gXHRhbmltYXRpb25zLmZvckVhY2goYSA9PiB7bGV0IHRpbWUgPSBhLnRvdGFsVGltZSgpOyB0bC5hZGQoYSk7IGEudG90YWxUaW1lKHRpbWUpOyB9KTtcbi8vIFx0dGwuc21vb3RoQ2hpbGRUaW1pbmcgPSBmYWxzZTtcbi8vIFx0cmV0dXJuIHRsO1xuLy8gfSxcbi8vIHJldHVybnMgYSBmdW5jdGlvbiB0aGF0IGNhbiBiZSB1c2VkIHRvIHR3ZWVuIHRoZSBzY3JvbGwgcG9zaXRpb24gaW4gdGhlIGRpcmVjdGlvbiBwcm92aWRlZCwgYW5kIHdoZW4gZG9pbmcgc28gaXQnbGwgYWRkIGEgLnR3ZWVuIHByb3BlcnR5IHRvIHRoZSBGVU5DVElPTiBpdHNlbGYsIGFuZCByZW1vdmUgaXQgd2hlbiB0aGUgdHdlZW4gY29tcGxldGVzIG9yIGdldHMga2lsbGVkLiBUaGlzIGdpdmVzIHVzIGEgd2F5IHRvIGhhdmUgbXVsdGlwbGUgU2Nyb2xsVHJpZ2dlcnMgdXNlIGEgY2VudHJhbCBmdW5jdGlvbiBmb3IgYW55IGdpdmVuIHNjcm9sbGVyIGFuZCBzZWUgaWYgdGhlcmUncyBhIHNjcm9sbCB0d2VlbiBydW5uaW5nICh3aGljaCB3b3VsZCBhZmZlY3QgaWYvaG93IHRoaW5ncyBnZXQgdXBkYXRlZClcbl9nZXRUd2VlbkNyZWF0b3IgPSBmdW5jdGlvbiBfZ2V0VHdlZW5DcmVhdG9yKHNjcm9sbGVyLCBkaXJlY3Rpb24pIHtcbiAgdmFyIGdldFNjcm9sbCA9IF9nZXRTY3JvbGxGdW5jKHNjcm9sbGVyLCBkaXJlY3Rpb24pLFxuICAgICAgcHJvcCA9IFwiX3Njcm9sbFwiICsgZGlyZWN0aW9uLnAyLFxuICAgICAgLy8gYWRkIGEgdHdlZW5hYmxlIHByb3BlcnR5IHRvIHRoZSBzY3JvbGxlciB0aGF0J3MgYSBnZXR0ZXIvc2V0dGVyIGZ1bmN0aW9uLCBsaWtlIF9zY3JvbGxUb3Agb3IgX3Njcm9sbExlZnQuIFRoaXMgd2F5LCBpZiBzb21lb25lIGRvZXMgZ3NhcC5raWxsVHdlZW5zT2Yoc2Nyb2xsZXIpIGl0J2xsIGtpbGwgdGhlIHNjcm9sbCB0d2Vlbi5cbiAgZ2V0VHdlZW4gPSBmdW5jdGlvbiBnZXRUd2VlbihzY3JvbGxUbywgdmFycywgaW5pdGlhbFZhbHVlLCBjaGFuZ2UxLCBjaGFuZ2UyKSB7XG4gICAgdmFyIHR3ZWVuID0gZ2V0VHdlZW4udHdlZW4sXG4gICAgICAgIG9uQ29tcGxldGUgPSB2YXJzLm9uQ29tcGxldGUsXG4gICAgICAgIG1vZGlmaWVycyA9IHt9O1xuICAgIGluaXRpYWxWYWx1ZSA9IGluaXRpYWxWYWx1ZSB8fCBnZXRTY3JvbGwoKTtcblxuICAgIHZhciBjaGVja0ZvckludGVycnVwdGlvbiA9IF9pbnRlcnJ1cHRpb25UcmFja2VyKGdldFNjcm9sbCwgaW5pdGlhbFZhbHVlLCBmdW5jdGlvbiAoKSB7XG4gICAgICB0d2Vlbi5raWxsKCk7XG4gICAgICBnZXRUd2Vlbi50d2VlbiA9IDA7XG4gICAgfSk7XG5cbiAgICBjaGFuZ2UyID0gY2hhbmdlMSAmJiBjaGFuZ2UyIHx8IDA7IC8vIGlmIGNoYW5nZTEgaXMgMCwgd2Ugc2V0IHRoYXQgdG8gdGhlIGRpZmZlcmVuY2UgYW5kIGlnbm9yZSBjaGFuZ2UyLiBPdGhlcndpc2UsIHRoZXJlIHdvdWxkIGJlIGEgY29tcG91bmQgZWZmZWN0LlxuXG4gICAgY2hhbmdlMSA9IGNoYW5nZTEgfHwgc2Nyb2xsVG8gLSBpbml0aWFsVmFsdWU7XG4gICAgdHdlZW4gJiYgdHdlZW4ua2lsbCgpO1xuICAgIHZhcnNbcHJvcF0gPSBzY3JvbGxUbztcbiAgICB2YXJzLmluaGVyaXQgPSBmYWxzZTtcbiAgICB2YXJzLm1vZGlmaWVycyA9IG1vZGlmaWVycztcblxuICAgIG1vZGlmaWVyc1twcm9wXSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiBjaGVja0ZvckludGVycnVwdGlvbihpbml0aWFsVmFsdWUgKyBjaGFuZ2UxICogdHdlZW4ucmF0aW8gKyBjaGFuZ2UyICogdHdlZW4ucmF0aW8gKiB0d2Vlbi5yYXRpbyk7XG4gICAgfTtcblxuICAgIHZhcnMub25VcGRhdGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICBfc2Nyb2xsZXJzLmNhY2hlKys7XG4gICAgICBnZXRUd2Vlbi50d2VlbiAmJiBfdXBkYXRlQWxsKCk7IC8vIGlmIGl0IHdhcyBpbnRlcnJ1cHRlZC9raWxsZWQsIGxpa2UgaW4gYSBjb250ZXh0LnJldmVydCgpLCBkb24ndCBmb3JjZSBhbiB1cGRhdGVBbGwoKVxuICAgIH07XG5cbiAgICB2YXJzLm9uQ29tcGxldGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICBnZXRUd2Vlbi50d2VlbiA9IDA7XG4gICAgICBvbkNvbXBsZXRlICYmIG9uQ29tcGxldGUuY2FsbCh0d2Vlbik7XG4gICAgfTtcblxuICAgIHR3ZWVuID0gZ2V0VHdlZW4udHdlZW4gPSBnc2FwLnRvKHNjcm9sbGVyLCB2YXJzKTtcbiAgICByZXR1cm4gdHdlZW47XG4gIH07XG5cbiAgc2Nyb2xsZXJbcHJvcF0gPSBnZXRTY3JvbGw7XG5cbiAgZ2V0U2Nyb2xsLndoZWVsSGFuZGxlciA9IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gZ2V0VHdlZW4udHdlZW4gJiYgZ2V0VHdlZW4udHdlZW4ua2lsbCgpICYmIChnZXRUd2Vlbi50d2VlbiA9IDApO1xuICB9O1xuXG4gIF9hZGRMaXN0ZW5lcihzY3JvbGxlciwgXCJ3aGVlbFwiLCBnZXRTY3JvbGwud2hlZWxIYW5kbGVyKTsgLy8gV2luZG93cyBtYWNoaW5lcyBoYW5kbGUgbW91c2V3aGVlbCBzY3JvbGxpbmcgaW4gY2h1bmtzIChsaWtlIFwiMyBsaW5lcyBwZXIgc2Nyb2xsXCIpIG1lYW5pbmcgdGhlIHR5cGljYWwgc3RyYXRlZ3kgZm9yIGNhbmNlbGxpbmcgdGhlIHNjcm9sbCBpc24ndCBhcyBzZW5zaXRpdmUuIEl0J3MgbXVjaCBtb3JlIGxpa2VseSB0byBtYXRjaCBvbmUgb2YgdGhlIHByZXZpb3VzIDIgc2Nyb2xsIGV2ZW50IHBvc2l0aW9ucy4gU28gd2Uga2lsbCBhbnkgc25hcHBpbmcgYXMgc29vbiBhcyB0aGVyZSdzIGEgd2hlZWwgZXZlbnQuXG5cblxuICBTY3JvbGxUcmlnZ2VyLmlzVG91Y2ggJiYgX2FkZExpc3RlbmVyKHNjcm9sbGVyLCBcInRvdWNobW92ZVwiLCBnZXRTY3JvbGwud2hlZWxIYW5kbGVyKTtcbiAgcmV0dXJuIGdldFR3ZWVuO1xufTtcblxuZXhwb3J0IHZhciBTY3JvbGxUcmlnZ2VyID0gLyojX19QVVJFX18qL2Z1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gU2Nyb2xsVHJpZ2dlcih2YXJzLCBhbmltYXRpb24pIHtcbiAgICBfY29yZUluaXR0ZWQgfHwgU2Nyb2xsVHJpZ2dlci5yZWdpc3Rlcihnc2FwKSB8fCBjb25zb2xlLndhcm4oXCJQbGVhc2UgZ3NhcC5yZWdpc3RlclBsdWdpbihTY3JvbGxUcmlnZ2VyKVwiKTtcblxuICAgIF9jb250ZXh0KHRoaXMpO1xuXG4gICAgdGhpcy5pbml0KHZhcnMsIGFuaW1hdGlvbik7XG4gIH1cblxuICB2YXIgX3Byb3RvID0gU2Nyb2xsVHJpZ2dlci5wcm90b3R5cGU7XG5cbiAgX3Byb3RvLmluaXQgPSBmdW5jdGlvbiBpbml0KHZhcnMsIGFuaW1hdGlvbikge1xuICAgIHRoaXMucHJvZ3Jlc3MgPSB0aGlzLnN0YXJ0ID0gMDtcbiAgICB0aGlzLnZhcnMgJiYgdGhpcy5raWxsKHRydWUsIHRydWUpOyAvLyBpbiBjYXNlIGl0J3MgYmVpbmcgaW5pdHRlZCBhZ2FpblxuXG4gICAgaWYgKCFfZW5hYmxlZCkge1xuICAgICAgdGhpcy51cGRhdGUgPSB0aGlzLnJlZnJlc2ggPSB0aGlzLmtpbGwgPSBfcGFzc1Rocm91Z2g7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdmFycyA9IF9zZXREZWZhdWx0cyhfaXNTdHJpbmcodmFycykgfHwgX2lzTnVtYmVyKHZhcnMpIHx8IHZhcnMubm9kZVR5cGUgPyB7XG4gICAgICB0cmlnZ2VyOiB2YXJzXG4gICAgfSA6IHZhcnMsIF9kZWZhdWx0cyk7XG5cbiAgICB2YXIgX3ZhcnMgPSB2YXJzLFxuICAgICAgICBvblVwZGF0ZSA9IF92YXJzLm9uVXBkYXRlLFxuICAgICAgICB0b2dnbGVDbGFzcyA9IF92YXJzLnRvZ2dsZUNsYXNzLFxuICAgICAgICBpZCA9IF92YXJzLmlkLFxuICAgICAgICBvblRvZ2dsZSA9IF92YXJzLm9uVG9nZ2xlLFxuICAgICAgICBvblJlZnJlc2ggPSBfdmFycy5vblJlZnJlc2gsXG4gICAgICAgIHNjcnViID0gX3ZhcnMuc2NydWIsXG4gICAgICAgIHRyaWdnZXIgPSBfdmFycy50cmlnZ2VyLFxuICAgICAgICBwaW4gPSBfdmFycy5waW4sXG4gICAgICAgIHBpblNwYWNpbmcgPSBfdmFycy5waW5TcGFjaW5nLFxuICAgICAgICBpbnZhbGlkYXRlT25SZWZyZXNoID0gX3ZhcnMuaW52YWxpZGF0ZU9uUmVmcmVzaCxcbiAgICAgICAgYW50aWNpcGF0ZVBpbiA9IF92YXJzLmFudGljaXBhdGVQaW4sXG4gICAgICAgIG9uU2NydWJDb21wbGV0ZSA9IF92YXJzLm9uU2NydWJDb21wbGV0ZSxcbiAgICAgICAgb25TbmFwQ29tcGxldGUgPSBfdmFycy5vblNuYXBDb21wbGV0ZSxcbiAgICAgICAgb25jZSA9IF92YXJzLm9uY2UsXG4gICAgICAgIHNuYXAgPSBfdmFycy5zbmFwLFxuICAgICAgICBwaW5SZXBhcmVudCA9IF92YXJzLnBpblJlcGFyZW50LFxuICAgICAgICBwaW5TcGFjZXIgPSBfdmFycy5waW5TcGFjZXIsXG4gICAgICAgIGNvbnRhaW5lckFuaW1hdGlvbiA9IF92YXJzLmNvbnRhaW5lckFuaW1hdGlvbixcbiAgICAgICAgZmFzdFNjcm9sbEVuZCA9IF92YXJzLmZhc3RTY3JvbGxFbmQsXG4gICAgICAgIHByZXZlbnRPdmVybGFwcyA9IF92YXJzLnByZXZlbnRPdmVybGFwcyxcbiAgICAgICAgZGlyZWN0aW9uID0gdmFycy5ob3Jpem9udGFsIHx8IHZhcnMuY29udGFpbmVyQW5pbWF0aW9uICYmIHZhcnMuaG9yaXpvbnRhbCAhPT0gZmFsc2UgPyBfaG9yaXpvbnRhbCA6IF92ZXJ0aWNhbCxcbiAgICAgICAgaXNUb2dnbGUgPSAhc2NydWIgJiYgc2NydWIgIT09IDAsXG4gICAgICAgIHNjcm9sbGVyID0gX2dldFRhcmdldCh2YXJzLnNjcm9sbGVyIHx8IF93aW4pLFxuICAgICAgICBzY3JvbGxlckNhY2hlID0gZ3NhcC5jb3JlLmdldENhY2hlKHNjcm9sbGVyKSxcbiAgICAgICAgaXNWaWV3cG9ydCA9IF9pc1ZpZXdwb3J0KHNjcm9sbGVyKSxcbiAgICAgICAgdXNlRml4ZWRQb3NpdGlvbiA9IChcInBpblR5cGVcIiBpbiB2YXJzID8gdmFycy5waW5UeXBlIDogX2dldFByb3h5UHJvcChzY3JvbGxlciwgXCJwaW5UeXBlXCIpIHx8IGlzVmlld3BvcnQgJiYgXCJmaXhlZFwiKSA9PT0gXCJmaXhlZFwiLFxuICAgICAgICBjYWxsYmFja3MgPSBbdmFycy5vbkVudGVyLCB2YXJzLm9uTGVhdmUsIHZhcnMub25FbnRlckJhY2ssIHZhcnMub25MZWF2ZUJhY2tdLFxuICAgICAgICB0b2dnbGVBY3Rpb25zID0gaXNUb2dnbGUgJiYgdmFycy50b2dnbGVBY3Rpb25zLnNwbGl0KFwiIFwiKSxcbiAgICAgICAgbWFya2VycyA9IFwibWFya2Vyc1wiIGluIHZhcnMgPyB2YXJzLm1hcmtlcnMgOiBfZGVmYXVsdHMubWFya2VycyxcbiAgICAgICAgYm9yZGVyV2lkdGggPSBpc1ZpZXdwb3J0ID8gMCA6IHBhcnNlRmxvYXQoX2dldENvbXB1dGVkU3R5bGUoc2Nyb2xsZXIpW1wiYm9yZGVyXCIgKyBkaXJlY3Rpb24ucDIgKyBfV2lkdGhdKSB8fCAwLFxuICAgICAgICBzZWxmID0gdGhpcyxcbiAgICAgICAgb25SZWZyZXNoSW5pdCA9IHZhcnMub25SZWZyZXNoSW5pdCAmJiBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gdmFycy5vblJlZnJlc2hJbml0KHNlbGYpO1xuICAgIH0sXG4gICAgICAgIGdldFNjcm9sbGVyU2l6ZSA9IF9nZXRTaXplRnVuYyhzY3JvbGxlciwgaXNWaWV3cG9ydCwgZGlyZWN0aW9uKSxcbiAgICAgICAgZ2V0U2Nyb2xsZXJPZmZzZXRzID0gX2dldE9mZnNldHNGdW5jKHNjcm9sbGVyLCBpc1ZpZXdwb3J0KSxcbiAgICAgICAgbGFzdFNuYXAgPSAwLFxuICAgICAgICBsYXN0UmVmcmVzaCA9IDAsXG4gICAgICAgIHByZXZQcm9ncmVzcyA9IDAsXG4gICAgICAgIHNjcm9sbEZ1bmMgPSBfZ2V0U2Nyb2xsRnVuYyhzY3JvbGxlciwgZGlyZWN0aW9uKSxcbiAgICAgICAgdHdlZW5UbyxcbiAgICAgICAgcGluQ2FjaGUsXG4gICAgICAgIHNuYXBGdW5jLFxuICAgICAgICBzY3JvbGwxLFxuICAgICAgICBzY3JvbGwyLFxuICAgICAgICBzdGFydCxcbiAgICAgICAgZW5kLFxuICAgICAgICBtYXJrZXJTdGFydCxcbiAgICAgICAgbWFya2VyRW5kLFxuICAgICAgICBtYXJrZXJTdGFydFRyaWdnZXIsXG4gICAgICAgIG1hcmtlckVuZFRyaWdnZXIsXG4gICAgICAgIG1hcmtlclZhcnMsXG4gICAgICAgIGV4ZWN1dGluZ09uUmVmcmVzaCxcbiAgICAgICAgY2hhbmdlLFxuICAgICAgICBwaW5PcmlnaW5hbFN0YXRlLFxuICAgICAgICBwaW5BY3RpdmVTdGF0ZSxcbiAgICAgICAgcGluU3RhdGUsXG4gICAgICAgIHNwYWNlcixcbiAgICAgICAgb2Zmc2V0LFxuICAgICAgICBwaW5HZXR0ZXIsXG4gICAgICAgIHBpblNldHRlcixcbiAgICAgICAgcGluU3RhcnQsXG4gICAgICAgIHBpbkNoYW5nZSxcbiAgICAgICAgc3BhY2luZ1N0YXJ0LFxuICAgICAgICBzcGFjZXJTdGF0ZSxcbiAgICAgICAgbWFya2VyU3RhcnRTZXR0ZXIsXG4gICAgICAgIHBpbk1vdmVzLFxuICAgICAgICBtYXJrZXJFbmRTZXR0ZXIsXG4gICAgICAgIGNzLFxuICAgICAgICBzbmFwMSxcbiAgICAgICAgc25hcDIsXG4gICAgICAgIHNjcnViVHdlZW4sXG4gICAgICAgIHNjcnViU21vb3RoLFxuICAgICAgICBzbmFwRHVyQ2xhbXAsXG4gICAgICAgIHNuYXBEZWxheWVkQ2FsbCxcbiAgICAgICAgcHJldlNjcm9sbCxcbiAgICAgICAgcHJldkFuaW1Qcm9ncmVzcyxcbiAgICAgICAgY2FNYXJrZXJTZXR0ZXIsXG4gICAgICAgIGN1c3RvbVJldmVydFJldHVybjsgLy8gZm9yIHRoZSBzYWtlIG9mIGVmZmljaWVuY3ksIF9zdGFydENsYW1wL19lbmRDbGFtcCBzZXJ2ZSBsaWtlIGEgdHJ1dGh5IHZhbHVlIGluZGljYXRpbmcgdGhhdCBjbGFtcGluZyB3YXMgZW5hYmxlZCBvbiB0aGUgc3RhcnQvZW5kLCBhbmQgQUxTTyBzdG9yZSB0aGUgYWN0dWFsIHByZS1jbGFtcGVkIG51bWVyaWMgdmFsdWUuIFdlIHRhcCBpbnRvIHRoYXQgaW4gU2Nyb2xsU21vb3RoZXIgZm9yIHNwZWVkIGVmZmVjdHMuIFNvIGZvciBleGFtcGxlLCBpZiBzdGFydD1cImNsYW1wKHRvcCBib3R0b20pXCIgcmVzdWx0cyBpbiBhIHN0YXJ0IG9mIC0xMDAgbmF0dXJhbGx5LCBpdCB3b3VsZCBnZXQgY2xhbXBlZCB0byAwIGJ1dCAtMTAwIHdvdWxkIGJlIHN0b3JlZCBpbiBfc3RhcnRDbGFtcC5cblxuXG4gICAgc2VsZi5fc3RhcnRDbGFtcCA9IHNlbGYuX2VuZENsYW1wID0gZmFsc2U7XG4gICAgc2VsZi5fZGlyID0gZGlyZWN0aW9uO1xuICAgIGFudGljaXBhdGVQaW4gKj0gNDU7XG4gICAgc2VsZi5zY3JvbGxlciA9IHNjcm9sbGVyO1xuICAgIHNlbGYuc2Nyb2xsID0gY29udGFpbmVyQW5pbWF0aW9uID8gY29udGFpbmVyQW5pbWF0aW9uLnRpbWUuYmluZChjb250YWluZXJBbmltYXRpb24pIDogc2Nyb2xsRnVuYztcbiAgICBzY3JvbGwxID0gc2Nyb2xsRnVuYygpO1xuICAgIHNlbGYudmFycyA9IHZhcnM7XG4gICAgYW5pbWF0aW9uID0gYW5pbWF0aW9uIHx8IHZhcnMuYW5pbWF0aW9uO1xuXG4gICAgaWYgKFwicmVmcmVzaFByaW9yaXR5XCIgaW4gdmFycykge1xuICAgICAgX3NvcnQgPSAxO1xuICAgICAgdmFycy5yZWZyZXNoUHJpb3JpdHkgPT09IC05OTk5ICYmIChfcHJpbWFyeSA9IHNlbGYpOyAvLyB1c2VkIGJ5IFNjcm9sbFNtb290aGVyXG4gICAgfVxuXG4gICAgc2Nyb2xsZXJDYWNoZS50d2VlblNjcm9sbCA9IHNjcm9sbGVyQ2FjaGUudHdlZW5TY3JvbGwgfHwge1xuICAgICAgdG9wOiBfZ2V0VHdlZW5DcmVhdG9yKHNjcm9sbGVyLCBfdmVydGljYWwpLFxuICAgICAgbGVmdDogX2dldFR3ZWVuQ3JlYXRvcihzY3JvbGxlciwgX2hvcml6b250YWwpXG4gICAgfTtcbiAgICBzZWxmLnR3ZWVuVG8gPSB0d2VlblRvID0gc2Nyb2xsZXJDYWNoZS50d2VlblNjcm9sbFtkaXJlY3Rpb24ucF07XG5cbiAgICBzZWxmLnNjcnViRHVyYXRpb24gPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgIHNjcnViU21vb3RoID0gX2lzTnVtYmVyKHZhbHVlKSAmJiB2YWx1ZTtcblxuICAgICAgaWYgKCFzY3J1YlNtb290aCkge1xuICAgICAgICBzY3J1YlR3ZWVuICYmIHNjcnViVHdlZW4ucHJvZ3Jlc3MoMSkua2lsbCgpO1xuICAgICAgICBzY3J1YlR3ZWVuID0gMDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNjcnViVHdlZW4gPyBzY3J1YlR3ZWVuLmR1cmF0aW9uKHZhbHVlKSA6IHNjcnViVHdlZW4gPSBnc2FwLnRvKGFuaW1hdGlvbiwge1xuICAgICAgICAgIGVhc2U6IFwiZXhwb1wiLFxuICAgICAgICAgIHRvdGFsUHJvZ3Jlc3M6IFwiKz0wXCIsXG4gICAgICAgICAgaW5oZXJpdDogZmFsc2UsXG4gICAgICAgICAgZHVyYXRpb246IHNjcnViU21vb3RoLFxuICAgICAgICAgIHBhdXNlZDogdHJ1ZSxcbiAgICAgICAgICBvbkNvbXBsZXRlOiBmdW5jdGlvbiBvbkNvbXBsZXRlKCkge1xuICAgICAgICAgICAgcmV0dXJuIG9uU2NydWJDb21wbGV0ZSAmJiBvblNjcnViQ29tcGxldGUoc2VsZik7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGFuaW1hdGlvbikge1xuICAgICAgYW5pbWF0aW9uLnZhcnMubGF6eSA9IGZhbHNlO1xuICAgICAgYW5pbWF0aW9uLl9pbml0dGVkICYmICFzZWxmLmlzUmV2ZXJ0ZWQgfHwgYW5pbWF0aW9uLnZhcnMuaW1tZWRpYXRlUmVuZGVyICE9PSBmYWxzZSAmJiB2YXJzLmltbWVkaWF0ZVJlbmRlciAhPT0gZmFsc2UgJiYgYW5pbWF0aW9uLmR1cmF0aW9uKCkgJiYgYW5pbWF0aW9uLnJlbmRlcigwLCB0cnVlLCB0cnVlKTsgLy8gc3BlY2lhbCBjYXNlOiBpZiB0aGlzIFNjcm9sbFRyaWdnZXIgZ2V0cyByZS1pbml0dGVkLCBhIGZyb20oKSB0d2VlbiB3aXRoIGEgc3RhZ2dlciBjb3VsZCBnZXQgaW5pdHRlZCBpbml0aWFsbHkgYW5kIHRoZW4gcmV2ZXJ0ZWQgb24gdGhlIHJlLWluaXQgd2hpY2ggbWVhbnMgaXQnbGwgbmVlZCB0byBnZXQgcmVuZGVyZWQgYWdhaW4gaGVyZSB0byBwcm9wZXJseSBkaXNwbGF5IHRoaW5ncy4gT3RoZXJ3aXNlLCBTZWUgaHR0cHM6Ly9nc2FwLmNvbS9mb3J1bXMvdG9waWMvMzY3Nzctc2Nyb2xsc21vb3RoZXItc3BsaXR0ZXh0LW5leHRqcy8gYW5kIGh0dHBzOi8vY29kZXBlbi5pby9HcmVlblNvY2svcGVuL2VZUHlQcGQ/ZWRpdG9ycz0wMDEwXG5cbiAgICAgIHNlbGYuYW5pbWF0aW9uID0gYW5pbWF0aW9uLnBhdXNlKCk7XG4gICAgICBhbmltYXRpb24uc2Nyb2xsVHJpZ2dlciA9IHNlbGY7XG4gICAgICBzZWxmLnNjcnViRHVyYXRpb24oc2NydWIpO1xuICAgICAgc25hcDEgPSAwO1xuICAgICAgaWQgfHwgKGlkID0gYW5pbWF0aW9uLnZhcnMuaWQpO1xuICAgIH1cblxuICAgIGlmIChzbmFwKSB7XG4gICAgICAvLyBUT0RPOiBwb3RlbnRpYWwgaWRlYTogdXNlIGxlZ2l0aW1hdGUgQ1NTIHNjcm9sbCBzbmFwcGluZyBieSBwdXNoaW5nIGludmlzaWJsZSBlbGVtZW50cyBpbnRvIHRoZSBET00gdGhhdCBzZXJ2ZSBhcyBzbmFwIHBvc2l0aW9ucywgYW5kIHRvZ2dsZSB0aGUgZG9jdW1lbnQuc2Nyb2xsaW5nRWxlbWVudC5zdHlsZS5zY3JvbGxTbmFwVHlwZSBvblRvZ2dsZS4gU2VlIGh0dHBzOi8vY29kZXBlbi5pby9HcmVlblNvY2svcGVuL0pqTHJnV00gZm9yIGEgcXVpY2sgcHJvb2Ygb2YgY29uY2VwdC5cbiAgICAgIGlmICghX2lzT2JqZWN0KHNuYXApIHx8IHNuYXAucHVzaCkge1xuICAgICAgICBzbmFwID0ge1xuICAgICAgICAgIHNuYXBUbzogc25hcFxuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICBcInNjcm9sbEJlaGF2aW9yXCIgaW4gX2JvZHkuc3R5bGUgJiYgZ3NhcC5zZXQoaXNWaWV3cG9ydCA/IFtfYm9keSwgX2RvY0VsXSA6IHNjcm9sbGVyLCB7XG4gICAgICAgIHNjcm9sbEJlaGF2aW9yOiBcImF1dG9cIlxuICAgICAgfSk7IC8vIHNtb290aCBzY3JvbGxpbmcgZG9lc24ndCB3b3JrIHdpdGggc25hcC5cblxuICAgICAgX3Njcm9sbGVycy5mb3JFYWNoKGZ1bmN0aW9uIChvKSB7XG4gICAgICAgIHJldHVybiBfaXNGdW5jdGlvbihvKSAmJiBvLnRhcmdldCA9PT0gKGlzVmlld3BvcnQgPyBfZG9jLnNjcm9sbGluZ0VsZW1lbnQgfHwgX2RvY0VsIDogc2Nyb2xsZXIpICYmIChvLnNtb290aCA9IGZhbHNlKTtcbiAgICAgIH0pOyAvLyBub3RlOiBzZXQgc21vb3RoIHRvIGZhbHNlIG9uIGJvdGggdGhlIHZlcnRpY2FsIGFuZCBob3Jpem9udGFsIHNjcm9sbCBnZXR0ZXJzL3NldHRlcnNcblxuXG4gICAgICBzbmFwRnVuYyA9IF9pc0Z1bmN0aW9uKHNuYXAuc25hcFRvKSA/IHNuYXAuc25hcFRvIDogc25hcC5zbmFwVG8gPT09IFwibGFiZWxzXCIgPyBfZ2V0Q2xvc2VzdExhYmVsKGFuaW1hdGlvbikgOiBzbmFwLnNuYXBUbyA9PT0gXCJsYWJlbHNEaXJlY3Rpb25hbFwiID8gX2dldExhYmVsQXREaXJlY3Rpb24oYW5pbWF0aW9uKSA6IHNuYXAuZGlyZWN0aW9uYWwgIT09IGZhbHNlID8gZnVuY3Rpb24gKHZhbHVlLCBzdCkge1xuICAgICAgICByZXR1cm4gX3NuYXBEaXJlY3Rpb25hbChzbmFwLnNuYXBUbykodmFsdWUsIF9nZXRUaW1lKCkgLSBsYXN0UmVmcmVzaCA8IDUwMCA/IDAgOiBzdC5kaXJlY3Rpb24pO1xuICAgICAgfSA6IGdzYXAudXRpbHMuc25hcChzbmFwLnNuYXBUbyk7XG4gICAgICBzbmFwRHVyQ2xhbXAgPSBzbmFwLmR1cmF0aW9uIHx8IHtcbiAgICAgICAgbWluOiAwLjEsXG4gICAgICAgIG1heDogMlxuICAgICAgfTtcbiAgICAgIHNuYXBEdXJDbGFtcCA9IF9pc09iamVjdChzbmFwRHVyQ2xhbXApID8gX2NsYW1wKHNuYXBEdXJDbGFtcC5taW4sIHNuYXBEdXJDbGFtcC5tYXgpIDogX2NsYW1wKHNuYXBEdXJDbGFtcCwgc25hcER1ckNsYW1wKTtcbiAgICAgIHNuYXBEZWxheWVkQ2FsbCA9IGdzYXAuZGVsYXllZENhbGwoc25hcC5kZWxheSB8fCBzY3J1YlNtb290aCAvIDIgfHwgMC4xLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBzY3JvbGwgPSBzY3JvbGxGdW5jKCksXG4gICAgICAgICAgICByZWZyZXNoZWRSZWNlbnRseSA9IF9nZXRUaW1lKCkgLSBsYXN0UmVmcmVzaCA8IDUwMCxcbiAgICAgICAgICAgIHR3ZWVuID0gdHdlZW5Uby50d2VlbjtcblxuICAgICAgICBpZiAoKHJlZnJlc2hlZFJlY2VudGx5IHx8IE1hdGguYWJzKHNlbGYuZ2V0VmVsb2NpdHkoKSkgPCAxMCkgJiYgIXR3ZWVuICYmICFfcG9pbnRlcklzRG93biAmJiBsYXN0U25hcCAhPT0gc2Nyb2xsKSB7XG4gICAgICAgICAgdmFyIHByb2dyZXNzID0gKHNjcm9sbCAtIHN0YXJ0KSAvIGNoYW5nZSxcbiAgICAgICAgICAgICAgdG90YWxQcm9ncmVzcyA9IGFuaW1hdGlvbiAmJiAhaXNUb2dnbGUgPyBhbmltYXRpb24udG90YWxQcm9ncmVzcygpIDogcHJvZ3Jlc3MsXG4gICAgICAgICAgICAgIHZlbG9jaXR5ID0gcmVmcmVzaGVkUmVjZW50bHkgPyAwIDogKHRvdGFsUHJvZ3Jlc3MgLSBzbmFwMikgLyAoX2dldFRpbWUoKSAtIF90aW1lMikgKiAxMDAwIHx8IDAsXG4gICAgICAgICAgICAgIGNoYW5nZTEgPSBnc2FwLnV0aWxzLmNsYW1wKC1wcm9ncmVzcywgMSAtIHByb2dyZXNzLCBfYWJzKHZlbG9jaXR5IC8gMikgKiB2ZWxvY2l0eSAvIDAuMTg1KSxcbiAgICAgICAgICAgICAgbmF0dXJhbEVuZCA9IHByb2dyZXNzICsgKHNuYXAuaW5lcnRpYSA9PT0gZmFsc2UgPyAwIDogY2hhbmdlMSksXG4gICAgICAgICAgICAgIGVuZFZhbHVlLFxuICAgICAgICAgICAgICBlbmRTY3JvbGwsXG4gICAgICAgICAgICAgIF9zbmFwID0gc25hcCxcbiAgICAgICAgICAgICAgb25TdGFydCA9IF9zbmFwLm9uU3RhcnQsXG4gICAgICAgICAgICAgIF9vbkludGVycnVwdCA9IF9zbmFwLm9uSW50ZXJydXB0LFxuICAgICAgICAgICAgICBfb25Db21wbGV0ZSA9IF9zbmFwLm9uQ29tcGxldGU7XG4gICAgICAgICAgZW5kVmFsdWUgPSBzbmFwRnVuYyhuYXR1cmFsRW5kLCBzZWxmKTtcbiAgICAgICAgICBfaXNOdW1iZXIoZW5kVmFsdWUpIHx8IChlbmRWYWx1ZSA9IG5hdHVyYWxFbmQpOyAvLyBpbiBjYXNlIHRoZSBmdW5jdGlvbiBkaWRuJ3QgcmV0dXJuIGEgbnVtYmVyLCBmYWxsIGJhY2sgdG8gdXNpbmcgdGhlIG5hdHVyYWxFbmRcblxuICAgICAgICAgIGVuZFNjcm9sbCA9IE1hdGgubWF4KDAsIE1hdGgucm91bmQoc3RhcnQgKyBlbmRWYWx1ZSAqIGNoYW5nZSkpO1xuXG4gICAgICAgICAgaWYgKHNjcm9sbCA8PSBlbmQgJiYgc2Nyb2xsID49IHN0YXJ0ICYmIGVuZFNjcm9sbCAhPT0gc2Nyb2xsKSB7XG4gICAgICAgICAgICBpZiAodHdlZW4gJiYgIXR3ZWVuLl9pbml0dGVkICYmIHR3ZWVuLmRhdGEgPD0gX2FicyhlbmRTY3JvbGwgLSBzY3JvbGwpKSB7XG4gICAgICAgICAgICAgIC8vIHRoZXJlJ3MgYW4gb3ZlcmxhcHBpbmcgc25hcCEgU28gd2UgbXVzdCBmaWd1cmUgb3V0IHdoaWNoIG9uZSBpcyBjbG9zZXIgYW5kIGxldCB0aGF0IHR3ZWVuIGxpdmUuXG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHNuYXAuaW5lcnRpYSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgY2hhbmdlMSA9IGVuZFZhbHVlIC0gcHJvZ3Jlc3M7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHR3ZWVuVG8oZW5kU2Nyb2xsLCB7XG4gICAgICAgICAgICAgIGR1cmF0aW9uOiBzbmFwRHVyQ2xhbXAoX2FicyhNYXRoLm1heChfYWJzKG5hdHVyYWxFbmQgLSB0b3RhbFByb2dyZXNzKSwgX2FicyhlbmRWYWx1ZSAtIHRvdGFsUHJvZ3Jlc3MpKSAqIDAuMTg1IC8gdmVsb2NpdHkgLyAwLjA1IHx8IDApKSxcbiAgICAgICAgICAgICAgZWFzZTogc25hcC5lYXNlIHx8IFwicG93ZXIzXCIsXG4gICAgICAgICAgICAgIGRhdGE6IF9hYnMoZW5kU2Nyb2xsIC0gc2Nyb2xsKSxcbiAgICAgICAgICAgICAgLy8gcmVjb3JkIHRoZSBkaXN0YW5jZSBzbyB0aGF0IGlmIGFub3RoZXIgc25hcCB0d2VlbiBvY2N1cnMgKGNvbmZsaWN0KSB3ZSBjYW4gcHJpb3JpdGl6ZSB0aGUgY2xvc2VzdCBzbmFwLlxuICAgICAgICAgICAgICBvbkludGVycnVwdDogZnVuY3Rpb24gb25JbnRlcnJ1cHQoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHNuYXBEZWxheWVkQ2FsbC5yZXN0YXJ0KHRydWUpICYmIF9vbkludGVycnVwdCAmJiBfY2FsbGJhY2soc2VsZiwgX29uSW50ZXJydXB0KTtcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgb25Db21wbGV0ZTogZnVuY3Rpb24gb25Db21wbGV0ZSgpIHtcbiAgICAgICAgICAgICAgICBzZWxmLnVwZGF0ZSgpO1xuICAgICAgICAgICAgICAgIGxhc3RTbmFwID0gc2Nyb2xsRnVuYygpO1xuXG4gICAgICAgICAgICAgICAgaWYgKGFuaW1hdGlvbiAmJiAhaXNUb2dnbGUpIHtcbiAgICAgICAgICAgICAgICAgIC8vIHRoZSByZXNvbHV0aW9uIG9mIHRoZSBzY3JvbGxiYXIgaXMgbGltaXRlZCwgc28gd2Ugc2hvdWxkIGNvcnJlY3QgdGhlIHNjcnViYmVkIGFuaW1hdGlvbidzIHBsYXloZWFkIGF0IHRoZSBlbmQgdG8gbWF0Y2ggRVhBQ1RMWSB3aGVyZSBpdCB3YXMgc3VwcG9zZWQgdG8gc25hcFxuICAgICAgICAgICAgICAgICAgc2NydWJUd2VlbiA/IHNjcnViVHdlZW4ucmVzZXRUbyhcInRvdGFsUHJvZ3Jlc3NcIiwgZW5kVmFsdWUsIGFuaW1hdGlvbi5fdFRpbWUgLyBhbmltYXRpb24uX3REdXIpIDogYW5pbWF0aW9uLnByb2dyZXNzKGVuZFZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBzbmFwMSA9IHNuYXAyID0gYW5pbWF0aW9uICYmICFpc1RvZ2dsZSA/IGFuaW1hdGlvbi50b3RhbFByb2dyZXNzKCkgOiBzZWxmLnByb2dyZXNzO1xuICAgICAgICAgICAgICAgIG9uU25hcENvbXBsZXRlICYmIG9uU25hcENvbXBsZXRlKHNlbGYpO1xuICAgICAgICAgICAgICAgIF9vbkNvbXBsZXRlICYmIF9jYWxsYmFjayhzZWxmLCBfb25Db21wbGV0ZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sIHNjcm9sbCwgY2hhbmdlMSAqIGNoYW5nZSwgZW5kU2Nyb2xsIC0gc2Nyb2xsIC0gY2hhbmdlMSAqIGNoYW5nZSk7XG4gICAgICAgICAgICBvblN0YXJ0ICYmIF9jYWxsYmFjayhzZWxmLCBvblN0YXJ0LCB0d2VlblRvLnR3ZWVuKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoc2VsZi5pc0FjdGl2ZSAmJiBsYXN0U25hcCAhPT0gc2Nyb2xsKSB7XG4gICAgICAgICAgc25hcERlbGF5ZWRDYWxsLnJlc3RhcnQodHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgIH0pLnBhdXNlKCk7XG4gICAgfVxuXG4gICAgaWQgJiYgKF9pZHNbaWRdID0gc2VsZik7XG4gICAgdHJpZ2dlciA9IHNlbGYudHJpZ2dlciA9IF9nZXRUYXJnZXQodHJpZ2dlciB8fCBwaW4gIT09IHRydWUgJiYgcGluKTsgLy8gaWYgYSB0cmlnZ2VyIGhhcyBzb21lIGtpbmQgb2Ygc2Nyb2xsLXJlbGF0ZWQgZWZmZWN0IGFwcGxpZWQgdGhhdCBjb3VsZCBjb250YW1pbmF0ZSB0aGUgXCJ5XCIgb3IgXCJ4XCIgcG9zaXRpb24gKGxpa2UgYSBTY3JvbGxTbW9vdGhlciBlZmZlY3QpLCB3ZSBuZWVkZWQgYSB3YXkgdG8gdGVtcG9yYXJpbHkgcmV2ZXJ0IGl0LCBzbyB3ZSB1c2UgdGhlIHN0UmV2ZXJ0IHByb3BlcnR5IG9mIHRoZSBnc0NhY2hlLiBJdCBjYW4gcmV0dXJuIGFub3RoZXIgZnVuY3Rpb24gdGhhdCB3ZSdsbCBjYWxsIGF0IHRoZSBlbmQgc28gaXQgY2FuIHJldHVybiB0byBpdHMgbm9ybWFsIHN0YXRlLlxuXG4gICAgY3VzdG9tUmV2ZXJ0UmV0dXJuID0gdHJpZ2dlciAmJiB0cmlnZ2VyLl9nc2FwICYmIHRyaWdnZXIuX2dzYXAuc3RSZXZlcnQ7XG4gICAgY3VzdG9tUmV2ZXJ0UmV0dXJuICYmIChjdXN0b21SZXZlcnRSZXR1cm4gPSBjdXN0b21SZXZlcnRSZXR1cm4oc2VsZikpO1xuICAgIHBpbiA9IHBpbiA9PT0gdHJ1ZSA/IHRyaWdnZXIgOiBfZ2V0VGFyZ2V0KHBpbik7XG4gICAgX2lzU3RyaW5nKHRvZ2dsZUNsYXNzKSAmJiAodG9nZ2xlQ2xhc3MgPSB7XG4gICAgICB0YXJnZXRzOiB0cmlnZ2VyLFxuICAgICAgY2xhc3NOYW1lOiB0b2dnbGVDbGFzc1xuICAgIH0pO1xuXG4gICAgaWYgKHBpbikge1xuICAgICAgcGluU3BhY2luZyA9PT0gZmFsc2UgfHwgcGluU3BhY2luZyA9PT0gX21hcmdpbiB8fCAocGluU3BhY2luZyA9ICFwaW5TcGFjaW5nICYmIHBpbi5wYXJlbnROb2RlICYmIHBpbi5wYXJlbnROb2RlLnN0eWxlICYmIF9nZXRDb21wdXRlZFN0eWxlKHBpbi5wYXJlbnROb2RlKS5kaXNwbGF5ID09PSBcImZsZXhcIiA/IGZhbHNlIDogX3BhZGRpbmcpOyAvLyBpZiB0aGUgcGFyZW50IGlzIGRpc3BsYXk6IGZsZXgsIGRvbid0IGFwcGx5IHBpblNwYWNpbmcgYnkgZGVmYXVsdC4gV2Ugc2hvdWxkIGNoZWNrIHRoYXQgcGluLnBhcmVudE5vZGUgaXMgYW4gZWxlbWVudCAobm90IHNoYWRvdyBkb20gd2luZG93KVxuXG4gICAgICBzZWxmLnBpbiA9IHBpbjtcbiAgICAgIHBpbkNhY2hlID0gZ3NhcC5jb3JlLmdldENhY2hlKHBpbik7XG5cbiAgICAgIGlmICghcGluQ2FjaGUuc3BhY2VyKSB7XG4gICAgICAgIC8vIHJlY29yZCB0aGUgc3BhY2VyIGFuZCBwaW5PcmlnaW5hbFN0YXRlIG9uIHRoZSBjYWNoZSBpbiBjYXNlIHNvbWVvbmUgdHJpZXMgcGlubmluZyB0aGUgc2FtZSBlbGVtZW50IHdpdGggTVVMVElQTEUgU2Nyb2xsVHJpZ2dlcnMgLSB3ZSBkb24ndCB3YW50IHRvIGhhdmUgbXVsdGlwbGUgc3BhY2VycyBvciByZWNvcmQgdGhlIFwib3JpZ2luYWxcIiBwaW4gc3RhdGUgYWZ0ZXIgaXQgaGFzIGFscmVhZHkgYmVlbiBhZmZlY3RlZCBieSBhbm90aGVyIFNjcm9sbFRyaWdnZXIuXG4gICAgICAgIGlmIChwaW5TcGFjZXIpIHtcbiAgICAgICAgICBwaW5TcGFjZXIgPSBfZ2V0VGFyZ2V0KHBpblNwYWNlcik7XG4gICAgICAgICAgcGluU3BhY2VyICYmICFwaW5TcGFjZXIubm9kZVR5cGUgJiYgKHBpblNwYWNlciA9IHBpblNwYWNlci5jdXJyZW50IHx8IHBpblNwYWNlci5uYXRpdmVFbGVtZW50KTsgLy8gZm9yIFJlYWN0ICYgQW5ndWxhclxuXG4gICAgICAgICAgcGluQ2FjaGUuc3BhY2VySXNOYXRpdmUgPSAhIXBpblNwYWNlcjtcbiAgICAgICAgICBwaW5TcGFjZXIgJiYgKHBpbkNhY2hlLnNwYWNlclN0YXRlID0gX2dldFN0YXRlKHBpblNwYWNlcikpO1xuICAgICAgICB9XG5cbiAgICAgICAgcGluQ2FjaGUuc3BhY2VyID0gc3BhY2VyID0gcGluU3BhY2VyIHx8IF9kb2MuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgc3BhY2VyLmNsYXNzTGlzdC5hZGQoXCJwaW4tc3BhY2VyXCIpO1xuICAgICAgICBpZCAmJiBzcGFjZXIuY2xhc3NMaXN0LmFkZChcInBpbi1zcGFjZXItXCIgKyBpZCk7XG4gICAgICAgIHBpbkNhY2hlLnBpblN0YXRlID0gcGluT3JpZ2luYWxTdGF0ZSA9IF9nZXRTdGF0ZShwaW4pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGluT3JpZ2luYWxTdGF0ZSA9IHBpbkNhY2hlLnBpblN0YXRlO1xuICAgICAgfVxuXG4gICAgICB2YXJzLmZvcmNlM0QgIT09IGZhbHNlICYmIGdzYXAuc2V0KHBpbiwge1xuICAgICAgICBmb3JjZTNEOiB0cnVlXG4gICAgICB9KTtcbiAgICAgIHNlbGYuc3BhY2VyID0gc3BhY2VyID0gcGluQ2FjaGUuc3BhY2VyO1xuICAgICAgY3MgPSBfZ2V0Q29tcHV0ZWRTdHlsZShwaW4pO1xuICAgICAgc3BhY2luZ1N0YXJ0ID0gY3NbcGluU3BhY2luZyArIGRpcmVjdGlvbi5vczJdO1xuICAgICAgcGluR2V0dGVyID0gZ3NhcC5nZXRQcm9wZXJ0eShwaW4pO1xuICAgICAgcGluU2V0dGVyID0gZ3NhcC5xdWlja1NldHRlcihwaW4sIGRpcmVjdGlvbi5hLCBfcHgpOyAvLyBwaW4uZmlyc3RDaGlsZCAmJiAhX21heFNjcm9sbChwaW4sIGRpcmVjdGlvbikgJiYgKHBpbi5zdHlsZS5vdmVyZmxvdyA9IFwiaGlkZGVuXCIpOyAvLyBwcm90ZWN0cyBmcm9tIGNvbGxhcHNpbmcgbWFyZ2lucywgYnV0IGNhbiBoYXZlIHVuaW50ZW5kZWQgY29uc2VxdWVuY2VzIGFzIGRlbW9uc3RyYXRlZCBoZXJlOiBodHRwczovL2NvZGVwZW4uaW8vR3JlZW5Tb2NrL3Blbi8xZTQyYzdhNzNiZmE0MDlkMmNmMWUxODRlN2E0MjQ4ZCBzbyBpdCB3YXMgcmVtb3ZlZCBpbiBmYXZvciBvZiBqdXN0IHRlbGxpbmcgcGVvcGxlIHRvIHNldCB1cCB0aGVpciBDU1MgdG8gYXZvaWQgdGhlIGNvbGxhcHNpbmcgbWFyZ2lucyAob3ZlcmZsb3c6IGhpZGRlbiB8IGF1dG8gaXMganVzdCBvbmUgb3B0aW9uLiBBbm90aGVyIGlzIGJvcmRlci10b3A6IDFweCBzb2xpZCB0cmFuc3BhcmVudCkuXG5cbiAgICAgIF9zd2FwUGluSW4ocGluLCBzcGFjZXIsIGNzKTtcblxuICAgICAgcGluU3RhdGUgPSBfZ2V0U3RhdGUocGluKTtcbiAgICB9XG5cbiAgICBpZiAobWFya2Vycykge1xuICAgICAgbWFya2VyVmFycyA9IF9pc09iamVjdChtYXJrZXJzKSA/IF9zZXREZWZhdWx0cyhtYXJrZXJzLCBfbWFya2VyRGVmYXVsdHMpIDogX21hcmtlckRlZmF1bHRzO1xuICAgICAgbWFya2VyU3RhcnRUcmlnZ2VyID0gX2NyZWF0ZU1hcmtlcihcInNjcm9sbGVyLXN0YXJ0XCIsIGlkLCBzY3JvbGxlciwgZGlyZWN0aW9uLCBtYXJrZXJWYXJzLCAwKTtcbiAgICAgIG1hcmtlckVuZFRyaWdnZXIgPSBfY3JlYXRlTWFya2VyKFwic2Nyb2xsZXItZW5kXCIsIGlkLCBzY3JvbGxlciwgZGlyZWN0aW9uLCBtYXJrZXJWYXJzLCAwLCBtYXJrZXJTdGFydFRyaWdnZXIpO1xuICAgICAgb2Zmc2V0ID0gbWFya2VyU3RhcnRUcmlnZ2VyW1wib2Zmc2V0XCIgKyBkaXJlY3Rpb24ub3AuZDJdO1xuXG4gICAgICB2YXIgY29udGVudCA9IF9nZXRUYXJnZXQoX2dldFByb3h5UHJvcChzY3JvbGxlciwgXCJjb250ZW50XCIpIHx8IHNjcm9sbGVyKTtcblxuICAgICAgbWFya2VyU3RhcnQgPSB0aGlzLm1hcmtlclN0YXJ0ID0gX2NyZWF0ZU1hcmtlcihcInN0YXJ0XCIsIGlkLCBjb250ZW50LCBkaXJlY3Rpb24sIG1hcmtlclZhcnMsIG9mZnNldCwgMCwgY29udGFpbmVyQW5pbWF0aW9uKTtcbiAgICAgIG1hcmtlckVuZCA9IHRoaXMubWFya2VyRW5kID0gX2NyZWF0ZU1hcmtlcihcImVuZFwiLCBpZCwgY29udGVudCwgZGlyZWN0aW9uLCBtYXJrZXJWYXJzLCBvZmZzZXQsIDAsIGNvbnRhaW5lckFuaW1hdGlvbik7XG4gICAgICBjb250YWluZXJBbmltYXRpb24gJiYgKGNhTWFya2VyU2V0dGVyID0gZ3NhcC5xdWlja1NldHRlcihbbWFya2VyU3RhcnQsIG1hcmtlckVuZF0sIGRpcmVjdGlvbi5hLCBfcHgpKTtcblxuICAgICAgaWYgKCF1c2VGaXhlZFBvc2l0aW9uICYmICEoX3Byb3hpZXMubGVuZ3RoICYmIF9nZXRQcm94eVByb3Aoc2Nyb2xsZXIsIFwiZml4ZWRNYXJrZXJzXCIpID09PSB0cnVlKSkge1xuICAgICAgICBfbWFrZVBvc2l0aW9uYWJsZShpc1ZpZXdwb3J0ID8gX2JvZHkgOiBzY3JvbGxlcik7XG5cbiAgICAgICAgZ3NhcC5zZXQoW21hcmtlclN0YXJ0VHJpZ2dlciwgbWFya2VyRW5kVHJpZ2dlcl0sIHtcbiAgICAgICAgICBmb3JjZTNEOiB0cnVlXG4gICAgICAgIH0pO1xuICAgICAgICBtYXJrZXJTdGFydFNldHRlciA9IGdzYXAucXVpY2tTZXR0ZXIobWFya2VyU3RhcnRUcmlnZ2VyLCBkaXJlY3Rpb24uYSwgX3B4KTtcbiAgICAgICAgbWFya2VyRW5kU2V0dGVyID0gZ3NhcC5xdWlja1NldHRlcihtYXJrZXJFbmRUcmlnZ2VyLCBkaXJlY3Rpb24uYSwgX3B4KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoY29udGFpbmVyQW5pbWF0aW9uKSB7XG4gICAgICB2YXIgb2xkT25VcGRhdGUgPSBjb250YWluZXJBbmltYXRpb24udmFycy5vblVwZGF0ZSxcbiAgICAgICAgICBvbGRQYXJhbXMgPSBjb250YWluZXJBbmltYXRpb24udmFycy5vblVwZGF0ZVBhcmFtcztcbiAgICAgIGNvbnRhaW5lckFuaW1hdGlvbi5ldmVudENhbGxiYWNrKFwib25VcGRhdGVcIiwgZnVuY3Rpb24gKCkge1xuICAgICAgICBzZWxmLnVwZGF0ZSgwLCAwLCAxKTtcbiAgICAgICAgb2xkT25VcGRhdGUgJiYgb2xkT25VcGRhdGUuYXBwbHkoY29udGFpbmVyQW5pbWF0aW9uLCBvbGRQYXJhbXMgfHwgW10pO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgc2VsZi5wcmV2aW91cyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiBfdHJpZ2dlcnNbX3RyaWdnZXJzLmluZGV4T2Yoc2VsZikgLSAxXTtcbiAgICB9O1xuXG4gICAgc2VsZi5uZXh0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgcmV0dXJuIF90cmlnZ2Vyc1tfdHJpZ2dlcnMuaW5kZXhPZihzZWxmKSArIDFdO1xuICAgIH07XG5cbiAgICBzZWxmLnJldmVydCA9IGZ1bmN0aW9uIChyZXZlcnQsIHRlbXApIHtcbiAgICAgIGlmICghdGVtcCkge1xuICAgICAgICByZXR1cm4gc2VsZi5raWxsKHRydWUpO1xuICAgICAgfSAvLyBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIGdzYXAuY29udGV4dCgpIGFuZCBnc2FwLm1hdGNoTWVkaWEoKSB3aGljaCBjYWxsIHJldmVydCgpXG5cblxuICAgICAgdmFyIHIgPSByZXZlcnQgIT09IGZhbHNlIHx8ICFzZWxmLmVuYWJsZWQsXG4gICAgICAgICAgcHJldlJlZnJlc2hpbmcgPSBfcmVmcmVzaGluZztcblxuICAgICAgaWYgKHIgIT09IHNlbGYuaXNSZXZlcnRlZCkge1xuICAgICAgICBpZiAocikge1xuICAgICAgICAgIHByZXZTY3JvbGwgPSBNYXRoLm1heChzY3JvbGxGdW5jKCksIHNlbGYuc2Nyb2xsLnJlYyB8fCAwKTsgLy8gcmVjb3JkIHRoZSBzY3JvbGwgc28gd2UgY2FuIHJldmVydCBsYXRlciAocmVwb3NpdGlvbmluZy9waW5uaW5nIHRoaW5ncyBjYW4gYWZmZWN0IHNjcm9sbCBwb3NpdGlvbikuIEluIHRoZSBzdGF0aWMgcmVmcmVzaCgpIG1ldGhvZCwgd2UgZmlyc3QgcmVjb3JkIGFsbCB0aGUgc2Nyb2xsIHBvc2l0aW9ucyBhcyBhIHJlZmVyZW5jZS5cblxuICAgICAgICAgIHByZXZQcm9ncmVzcyA9IHNlbGYucHJvZ3Jlc3M7XG4gICAgICAgICAgcHJldkFuaW1Qcm9ncmVzcyA9IGFuaW1hdGlvbiAmJiBhbmltYXRpb24ucHJvZ3Jlc3MoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIG1hcmtlclN0YXJ0ICYmIFttYXJrZXJTdGFydCwgbWFya2VyRW5kLCBtYXJrZXJTdGFydFRyaWdnZXIsIG1hcmtlckVuZFRyaWdnZXJdLmZvckVhY2goZnVuY3Rpb24gKG0pIHtcbiAgICAgICAgICByZXR1cm4gbS5zdHlsZS5kaXNwbGF5ID0gciA/IFwibm9uZVwiIDogXCJibG9ja1wiO1xuICAgICAgICB9KTtcblxuICAgICAgICBpZiAocikge1xuICAgICAgICAgIF9yZWZyZXNoaW5nID0gc2VsZjtcbiAgICAgICAgICBzZWxmLnVwZGF0ZShyKTsgLy8gbWFrZSBzdXJlIHRoZSBwaW4gaXMgYmFjayBpbiBpdHMgb3JpZ2luYWwgcG9zaXRpb24gc28gdGhhdCBhbGwgdGhlIG1lYXN1cmVtZW50cyBhcmUgY29ycmVjdC4gZG8gdGhpcyBCRUZPUkUgc3dhcHBpbmcgdGhlIHBpbiBvdXRcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwaW4gJiYgKCFwaW5SZXBhcmVudCB8fCAhc2VsZi5pc0FjdGl2ZSkpIHtcbiAgICAgICAgICBpZiAocikge1xuICAgICAgICAgICAgX3N3YXBQaW5PdXQocGluLCBzcGFjZXIsIHBpbk9yaWdpbmFsU3RhdGUpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBfc3dhcFBpbkluKHBpbiwgc3BhY2VyLCBfZ2V0Q29tcHV0ZWRTdHlsZShwaW4pLCBzcGFjZXJTdGF0ZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgciB8fCBzZWxmLnVwZGF0ZShyKTsgLy8gd2hlbiB3ZSdyZSByZXN0b3JpbmcsIHRoZSB1cGRhdGUgc2hvdWxkIHJ1biBBRlRFUiBzd2FwcGluZyB0aGUgcGluIGludG8gaXRzIHBpbi1zcGFjZXIuXG5cbiAgICAgICAgX3JlZnJlc2hpbmcgPSBwcmV2UmVmcmVzaGluZzsgLy8gcmVzdG9yZS4gV2Ugc2V0IGl0IHRvIHRydWUgZHVyaW5nIHRoZSB1cGRhdGUoKSBzbyB0aGF0IHRoaW5ncyBmaXJlIHByb3Blcmx5IGluIHRoZXJlLlxuXG4gICAgICAgIHNlbGYuaXNSZXZlcnRlZCA9IHI7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHNlbGYucmVmcmVzaCA9IGZ1bmN0aW9uIChzb2Z0LCBmb3JjZSwgcG9zaXRpb24sIHBpbk9mZnNldCkge1xuICAgICAgLy8gcG9zaXRpb24gaXMgdHlwaWNhbGx5IG9ubHkgZGVmaW5lZCBpZiBpdCdzIGNvbWluZyBmcm9tIHNldFBvc2l0aW9ucygpIC0gaXQncyBhIHdheSB0byBza2lwIHRoZSBub3JtYWwgcGFyc2luZy4gcGluT2Zmc2V0IGlzIGFsc28gb25seSBmcm9tIHNldFBvc2l0aW9ucygpIGFuZCBpcyBtb3N0bHkgcmVsYXRlZCB0byBmYW5jeSBzdHVmZiB3ZSBuZWVkIHRvIGRvIGluIFNjcm9sbFNtb290aGVyIHdpdGggZWZmZWN0c1xuICAgICAgaWYgKChfcmVmcmVzaGluZyB8fCAhc2VsZi5lbmFibGVkKSAmJiAhZm9yY2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBpZiAocGluICYmIHNvZnQgJiYgX2xhc3RTY3JvbGxUaW1lKSB7XG4gICAgICAgIF9hZGRMaXN0ZW5lcihTY3JvbGxUcmlnZ2VyLCBcInNjcm9sbEVuZFwiLCBfc29mdFJlZnJlc2gpO1xuXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgIV9yZWZyZXNoaW5nQWxsICYmIG9uUmVmcmVzaEluaXQgJiYgb25SZWZyZXNoSW5pdChzZWxmKTtcbiAgICAgIF9yZWZyZXNoaW5nID0gc2VsZjtcblxuICAgICAgaWYgKHR3ZWVuVG8udHdlZW4gJiYgIXBvc2l0aW9uKSB7XG4gICAgICAgIC8vIHdlIHNraXAgdGhpcyBpZiBhIHBvc2l0aW9uIGlzIHBhc3NlZCBpbiBiZWNhdXNlIHR5cGljYWxseSB0aGF0J3MgZnJvbSAuc2V0UG9zaXRpb25zKCkgYW5kIGl0J3MgYmVzdCB0byBhbGxvdyBpbi1wcm9ncmVzcyBzbmFwcGluZyB0byBjb250aW51ZS5cbiAgICAgICAgdHdlZW5Uby50d2Vlbi5raWxsKCk7XG4gICAgICAgIHR3ZWVuVG8udHdlZW4gPSAwO1xuICAgICAgfVxuXG4gICAgICBzY3J1YlR3ZWVuICYmIHNjcnViVHdlZW4ucGF1c2UoKTtcblxuICAgICAgaWYgKGludmFsaWRhdGVPblJlZnJlc2ggJiYgYW5pbWF0aW9uKSB7XG4gICAgICAgIGFuaW1hdGlvbi5yZXZlcnQoe1xuICAgICAgICAgIGtpbGw6IGZhbHNlXG4gICAgICAgIH0pLmludmFsaWRhdGUoKTtcbiAgICAgICAgYW5pbWF0aW9uLmdldENoaWxkcmVuID8gYW5pbWF0aW9uLmdldENoaWxkcmVuKHRydWUsIHRydWUsIGZhbHNlKS5mb3JFYWNoKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgICAgcmV0dXJuIHQudmFycy5pbW1lZGlhdGVSZW5kZXIgJiYgdC5yZW5kZXIoMCwgdHJ1ZSwgdHJ1ZSk7XG4gICAgICAgIH0pIDogYW5pbWF0aW9uLnZhcnMuaW1tZWRpYXRlUmVuZGVyICYmIGFuaW1hdGlvbi5yZW5kZXIoMCwgdHJ1ZSwgdHJ1ZSk7IC8vIGFueSBmcm9tKCkgb3IgZnJvbVRvKCkgdHdlZW5zIHNob3VsZCByZW5kZXIgaW1tZWRpYXRlbHkgKHdlbGwsIHVubGVzcyB0aGV5IGhhdmUgaW1tZWRpYXRlUmVuZGVyOiBmYWxzZSlcbiAgICAgIH1cblxuICAgICAgc2VsZi5pc1JldmVydGVkIHx8IHNlbGYucmV2ZXJ0KHRydWUsIHRydWUpO1xuICAgICAgc2VsZi5fc3ViUGluT2Zmc2V0ID0gZmFsc2U7IC8vIHdlJ2xsIHNldCB0aGlzIHRvIHRydWUgaW4gdGhlIHN1Yi1waW5zIGlmIHdlIGZpbmQgYW55XG5cbiAgICAgIHZhciBzaXplID0gZ2V0U2Nyb2xsZXJTaXplKCksXG4gICAgICAgICAgc2Nyb2xsZXJCb3VuZHMgPSBnZXRTY3JvbGxlck9mZnNldHMoKSxcbiAgICAgICAgICBtYXggPSBjb250YWluZXJBbmltYXRpb24gPyBjb250YWluZXJBbmltYXRpb24uZHVyYXRpb24oKSA6IF9tYXhTY3JvbGwoc2Nyb2xsZXIsIGRpcmVjdGlvbiksXG4gICAgICAgICAgaXNGaXJzdFJlZnJlc2ggPSBjaGFuZ2UgPD0gMC4wMSB8fCAhY2hhbmdlLFxuICAgICAgICAgIG9mZnNldCA9IDAsXG4gICAgICAgICAgb3RoZXJQaW5PZmZzZXQgPSBwaW5PZmZzZXQgfHwgMCxcbiAgICAgICAgICBwYXJzZWRFbmQgPSBfaXNPYmplY3QocG9zaXRpb24pID8gcG9zaXRpb24uZW5kIDogdmFycy5lbmQsXG4gICAgICAgICAgcGFyc2VkRW5kVHJpZ2dlciA9IHZhcnMuZW5kVHJpZ2dlciB8fCB0cmlnZ2VyLFxuICAgICAgICAgIHBhcnNlZFN0YXJ0ID0gX2lzT2JqZWN0KHBvc2l0aW9uKSA/IHBvc2l0aW9uLnN0YXJ0IDogdmFycy5zdGFydCB8fCAodmFycy5zdGFydCA9PT0gMCB8fCAhdHJpZ2dlciA/IDAgOiBwaW4gPyBcIjAgMFwiIDogXCIwIDEwMCVcIiksXG4gICAgICAgICAgcGlubmVkQ29udGFpbmVyID0gc2VsZi5waW5uZWRDb250YWluZXIgPSB2YXJzLnBpbm5lZENvbnRhaW5lciAmJiBfZ2V0VGFyZ2V0KHZhcnMucGlubmVkQ29udGFpbmVyLCBzZWxmKSxcbiAgICAgICAgICB0cmlnZ2VySW5kZXggPSB0cmlnZ2VyICYmIE1hdGgubWF4KDAsIF90cmlnZ2Vycy5pbmRleE9mKHNlbGYpKSB8fCAwLFxuICAgICAgICAgIGkgPSB0cmlnZ2VySW5kZXgsXG4gICAgICAgICAgY3MsXG4gICAgICAgICAgYm91bmRzLFxuICAgICAgICAgIHNjcm9sbCxcbiAgICAgICAgICBpc1ZlcnRpY2FsLFxuICAgICAgICAgIG92ZXJyaWRlLFxuICAgICAgICAgIGN1clRyaWdnZXIsXG4gICAgICAgICAgY3VyUGluLFxuICAgICAgICAgIG9wcG9zaXRlU2Nyb2xsLFxuICAgICAgICAgIGluaXR0ZWQsXG4gICAgICAgICAgcmV2ZXJ0ZWRQaW5zLFxuICAgICAgICAgIGZvcmNlZE92ZXJmbG93LFxuICAgICAgICAgIG1hcmtlclN0YXJ0T2Zmc2V0LFxuICAgICAgICAgIG1hcmtlckVuZE9mZnNldDtcblxuICAgICAgaWYgKG1hcmtlcnMgJiYgX2lzT2JqZWN0KHBvc2l0aW9uKSkge1xuICAgICAgICAvLyBpZiB3ZSBhbHRlciB0aGUgc3RhcnQvZW5kIHBvc2l0aW9ucyB3aXRoIC5zZXRQb3NpdGlvbnMoKSwgaXQgZ2VuZXJhbGx5IGZlZWRzIGluIGFic29sdXRlIE5VTUJFUlMgd2hpY2ggZG9uJ3QgY29udmV5IGluZm9ybWF0aW9uIGFib3V0IHdoZXJlIHRvIGxpbmUgdXAgdGhlIG1hcmtlcnMsIHNvIHRvIGtlZXAgaXQgaW50dWl0aXZlLCB3ZSByZWNvcmQgaG93IGZhciB0aGUgdHJpZ2dlciBwb3NpdGlvbnMgc2hpZnQgYWZ0ZXIgYXBwbHlpbmcgdGhlIG5ldyBudW1iZXJzIGFuZCB0aGVuIG9mZnNldCBieSB0aGF0IG11Y2ggaW4gdGhlIG9wcG9zaXRlIGRpcmVjdGlvbi4gV2UgZG8gdGhlIHNhbWUgdG8gdGhlIGFzc29jaWF0ZWQgdHJpZ2dlciBtYXJrZXJzIHRvbyBvZiBjb3Vyc2UuXG4gICAgICAgIG1hcmtlclN0YXJ0T2Zmc2V0ID0gZ3NhcC5nZXRQcm9wZXJ0eShtYXJrZXJTdGFydFRyaWdnZXIsIGRpcmVjdGlvbi5wKTtcbiAgICAgICAgbWFya2VyRW5kT2Zmc2V0ID0gZ3NhcC5nZXRQcm9wZXJ0eShtYXJrZXJFbmRUcmlnZ2VyLCBkaXJlY3Rpb24ucCk7XG4gICAgICB9XG5cbiAgICAgIHdoaWxlIChpLS0gPiAwKSB7XG4gICAgICAgIC8vIHVzZXIgbWlnaHQgdHJ5IHRvIHBpbiB0aGUgc2FtZSBlbGVtZW50IG1vcmUgdGhhbiBvbmNlLCBzbyB3ZSBtdXN0IGZpbmQgYW55IHByaW9yIHRyaWdnZXJzIHdpdGggdGhlIHNhbWUgcGluLCByZXZlcnQgdGhlbSwgYW5kIGRldGVybWluZSBob3cgbG9uZyB0aGV5J3JlIHBpbm5pbmcgc28gdGhhdCB3ZSBjYW4gb2Zmc2V0IHRoaW5ncyBhcHByb3ByaWF0ZWx5LiBNYWtlIHN1cmUgd2UgcmV2ZXJ0IGZyb20gbGFzdCB0byBmaXJzdCBzbyB0aGF0IHRoaW5ncyBcInJld2luZFwiIHByb3Blcmx5LlxuICAgICAgICBjdXJUcmlnZ2VyID0gX3RyaWdnZXJzW2ldO1xuICAgICAgICBjdXJUcmlnZ2VyLmVuZCB8fCBjdXJUcmlnZ2VyLnJlZnJlc2goMCwgMSkgfHwgKF9yZWZyZXNoaW5nID0gc2VsZik7IC8vIGlmIGl0J3MgYSB0aW1lbGluZS1iYXNlZCB0cmlnZ2VyIHRoYXQgaGFzbid0IGJlZW4gZnVsbHkgaW5pdGlhbGl6ZWQgeWV0IGJlY2F1c2UgaXQncyB3YWl0aW5nIGZvciAxIHRpY2ssIGp1c3QgZm9yY2UgdGhlIHJlZnJlc2goKSBoZXJlLCBvdGhlcndpc2UgaWYgaXQgY29udGFpbnMgYSBwaW4gdGhhdCdzIHN1cHBvc2VkIHRvIGFmZmVjdCBvdGhlciBTY3JvbGxUcmlnZ2VycyBmdXJ0aGVyIGRvd24gdGhlIHBhZ2UsIHRoZXkgd29uJ3QgYmUgYWRqdXN0ZWQgcHJvcGVybHkuXG5cbiAgICAgICAgY3VyUGluID0gY3VyVHJpZ2dlci5waW47XG5cbiAgICAgICAgaWYgKGN1clBpbiAmJiAoY3VyUGluID09PSB0cmlnZ2VyIHx8IGN1clBpbiA9PT0gcGluIHx8IGN1clBpbiA9PT0gcGlubmVkQ29udGFpbmVyKSAmJiAhY3VyVHJpZ2dlci5pc1JldmVydGVkKSB7XG4gICAgICAgICAgcmV2ZXJ0ZWRQaW5zIHx8IChyZXZlcnRlZFBpbnMgPSBbXSk7XG4gICAgICAgICAgcmV2ZXJ0ZWRQaW5zLnVuc2hpZnQoY3VyVHJpZ2dlcik7IC8vIHdlJ2xsIHJldmVydCBmcm9tIGZpcnN0IHRvIGxhc3QgdG8gbWFrZSBzdXJlIHRoaW5ncyByZWFjaCB0aGVpciBlbmQgc3RhdGUgcHJvcGVybHlcblxuICAgICAgICAgIGN1clRyaWdnZXIucmV2ZXJ0KHRydWUsIHRydWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGN1clRyaWdnZXIgIT09IF90cmlnZ2Vyc1tpXSkge1xuICAgICAgICAgIC8vIGluIGNhc2UgaXQgZ290IHJlbW92ZWQuXG4gICAgICAgICAgdHJpZ2dlckluZGV4LS07XG4gICAgICAgICAgaS0tO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIF9pc0Z1bmN0aW9uKHBhcnNlZFN0YXJ0KSAmJiAocGFyc2VkU3RhcnQgPSBwYXJzZWRTdGFydChzZWxmKSk7XG4gICAgICBwYXJzZWRTdGFydCA9IF9wYXJzZUNsYW1wKHBhcnNlZFN0YXJ0LCBcInN0YXJ0XCIsIHNlbGYpO1xuICAgICAgc3RhcnQgPSBfcGFyc2VQb3NpdGlvbihwYXJzZWRTdGFydCwgdHJpZ2dlciwgc2l6ZSwgZGlyZWN0aW9uLCBzY3JvbGxGdW5jKCksIG1hcmtlclN0YXJ0LCBtYXJrZXJTdGFydFRyaWdnZXIsIHNlbGYsIHNjcm9sbGVyQm91bmRzLCBib3JkZXJXaWR0aCwgdXNlRml4ZWRQb3NpdGlvbiwgbWF4LCBjb250YWluZXJBbmltYXRpb24sIHNlbGYuX3N0YXJ0Q2xhbXAgJiYgXCJfc3RhcnRDbGFtcFwiKSB8fCAocGluID8gLTAuMDAxIDogMCk7XG4gICAgICBfaXNGdW5jdGlvbihwYXJzZWRFbmQpICYmIChwYXJzZWRFbmQgPSBwYXJzZWRFbmQoc2VsZikpO1xuXG4gICAgICBpZiAoX2lzU3RyaW5nKHBhcnNlZEVuZCkgJiYgIXBhcnNlZEVuZC5pbmRleE9mKFwiKz1cIikpIHtcbiAgICAgICAgaWYgKH5wYXJzZWRFbmQuaW5kZXhPZihcIiBcIikpIHtcbiAgICAgICAgICBwYXJzZWRFbmQgPSAoX2lzU3RyaW5nKHBhcnNlZFN0YXJ0KSA/IHBhcnNlZFN0YXJ0LnNwbGl0KFwiIFwiKVswXSA6IFwiXCIpICsgcGFyc2VkRW5kO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG9mZnNldCA9IF9vZmZzZXRUb1B4KHBhcnNlZEVuZC5zdWJzdHIoMiksIHNpemUpO1xuICAgICAgICAgIHBhcnNlZEVuZCA9IF9pc1N0cmluZyhwYXJzZWRTdGFydCkgPyBwYXJzZWRTdGFydCA6IChjb250YWluZXJBbmltYXRpb24gPyBnc2FwLnV0aWxzLm1hcFJhbmdlKDAsIGNvbnRhaW5lckFuaW1hdGlvbi5kdXJhdGlvbigpLCBjb250YWluZXJBbmltYXRpb24uc2Nyb2xsVHJpZ2dlci5zdGFydCwgY29udGFpbmVyQW5pbWF0aW9uLnNjcm9sbFRyaWdnZXIuZW5kLCBzdGFydCkgOiBzdGFydCkgKyBvZmZzZXQ7IC8vIF9wYXJzZVBvc2l0aW9uIHdvbid0IGZhY3RvciBpbiB0aGUgb2Zmc2V0IGlmIHRoZSBzdGFydCBpcyBhIG51bWJlciwgc28gZG8gaXQgaGVyZS5cblxuICAgICAgICAgIHBhcnNlZEVuZFRyaWdnZXIgPSB0cmlnZ2VyO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHBhcnNlZEVuZCA9IF9wYXJzZUNsYW1wKHBhcnNlZEVuZCwgXCJlbmRcIiwgc2VsZik7XG4gICAgICBlbmQgPSBNYXRoLm1heChzdGFydCwgX3BhcnNlUG9zaXRpb24ocGFyc2VkRW5kIHx8IChwYXJzZWRFbmRUcmlnZ2VyID8gXCIxMDAlIDBcIiA6IG1heCksIHBhcnNlZEVuZFRyaWdnZXIsIHNpemUsIGRpcmVjdGlvbiwgc2Nyb2xsRnVuYygpICsgb2Zmc2V0LCBtYXJrZXJFbmQsIG1hcmtlckVuZFRyaWdnZXIsIHNlbGYsIHNjcm9sbGVyQm91bmRzLCBib3JkZXJXaWR0aCwgdXNlRml4ZWRQb3NpdGlvbiwgbWF4LCBjb250YWluZXJBbmltYXRpb24sIHNlbGYuX2VuZENsYW1wICYmIFwiX2VuZENsYW1wXCIpKSB8fCAtMC4wMDE7XG4gICAgICBvZmZzZXQgPSAwO1xuICAgICAgaSA9IHRyaWdnZXJJbmRleDtcblxuICAgICAgd2hpbGUgKGktLSkge1xuICAgICAgICBjdXJUcmlnZ2VyID0gX3RyaWdnZXJzW2ldIHx8IHt9O1xuICAgICAgICBjdXJQaW4gPSBjdXJUcmlnZ2VyLnBpbjtcblxuICAgICAgICBpZiAoY3VyUGluICYmIGN1clRyaWdnZXIuc3RhcnQgLSBjdXJUcmlnZ2VyLl9waW5QdXNoIDw9IHN0YXJ0ICYmICFjb250YWluZXJBbmltYXRpb24gJiYgY3VyVHJpZ2dlci5lbmQgPiAwKSB7XG4gICAgICAgICAgY3MgPSBjdXJUcmlnZ2VyLmVuZCAtIChzZWxmLl9zdGFydENsYW1wID8gTWF0aC5tYXgoMCwgY3VyVHJpZ2dlci5zdGFydCkgOiBjdXJUcmlnZ2VyLnN0YXJ0KTtcblxuICAgICAgICAgIGlmICgoY3VyUGluID09PSB0cmlnZ2VyICYmIGN1clRyaWdnZXIuc3RhcnQgLSBjdXJUcmlnZ2VyLl9waW5QdXNoIDwgc3RhcnQgfHwgY3VyUGluID09PSBwaW5uZWRDb250YWluZXIpICYmIGlzTmFOKHBhcnNlZFN0YXJ0KSkge1xuICAgICAgICAgICAgLy8gbnVtZXJpYyBzdGFydCB2YWx1ZXMgc2hvdWxkbid0IGJlIG9mZnNldCBhdCBhbGwgLSB0cmVhdCB0aGVtIGFzIGFic29sdXRlXG4gICAgICAgICAgICBvZmZzZXQgKz0gY3MgKiAoMSAtIGN1clRyaWdnZXIucHJvZ3Jlc3MpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGN1clBpbiA9PT0gcGluICYmIChvdGhlclBpbk9mZnNldCArPSBjcyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgc3RhcnQgKz0gb2Zmc2V0O1xuICAgICAgZW5kICs9IG9mZnNldDtcbiAgICAgIHNlbGYuX3N0YXJ0Q2xhbXAgJiYgKHNlbGYuX3N0YXJ0Q2xhbXAgKz0gb2Zmc2V0KTtcblxuICAgICAgaWYgKHNlbGYuX2VuZENsYW1wICYmICFfcmVmcmVzaGluZ0FsbCkge1xuICAgICAgICBzZWxmLl9lbmRDbGFtcCA9IGVuZCB8fCAtMC4wMDE7XG4gICAgICAgIGVuZCA9IE1hdGgubWluKGVuZCwgX21heFNjcm9sbChzY3JvbGxlciwgZGlyZWN0aW9uKSk7XG4gICAgICB9XG5cbiAgICAgIGNoYW5nZSA9IGVuZCAtIHN0YXJ0IHx8IChzdGFydCAtPSAwLjAxKSAmJiAwLjAwMTtcblxuICAgICAgaWYgKGlzRmlyc3RSZWZyZXNoKSB7XG4gICAgICAgIC8vIG9uIHRoZSB2ZXJ5IGZpcnN0IHJlZnJlc2goKSwgdGhlIHByZXZQcm9ncmVzcyBjb3VsZG4ndCBoYXZlIGJlZW4gYWNjdXJhdGUgeWV0IGJlY2F1c2UgdGhlIHN0YXJ0L2VuZCB3ZXJlIG5ldmVyIGNhbGN1bGF0ZWQsIHNvIHdlIHNldCBpdCBoZXJlLiBCZWZvcmUgMy4xMS41LCBpdCBjb3VsZCBsZWFkIHRvIGFuIGluYWNjdXJhdGUgc2Nyb2xsIHBvc2l0aW9uIHJlc3RvcmF0aW9uIHdpdGggc25hcHBpbmcuXG4gICAgICAgIHByZXZQcm9ncmVzcyA9IGdzYXAudXRpbHMuY2xhbXAoMCwgMSwgZ3NhcC51dGlscy5ub3JtYWxpemUoc3RhcnQsIGVuZCwgcHJldlNjcm9sbCkpO1xuICAgICAgfVxuXG4gICAgICBzZWxmLl9waW5QdXNoID0gb3RoZXJQaW5PZmZzZXQ7XG5cbiAgICAgIGlmIChtYXJrZXJTdGFydCAmJiBvZmZzZXQpIHtcbiAgICAgICAgLy8gb2Zmc2V0IHRoZSBtYXJrZXJzIGlmIG5lY2Vzc2FyeVxuICAgICAgICBjcyA9IHt9O1xuICAgICAgICBjc1tkaXJlY3Rpb24uYV0gPSBcIis9XCIgKyBvZmZzZXQ7XG4gICAgICAgIHBpbm5lZENvbnRhaW5lciAmJiAoY3NbZGlyZWN0aW9uLnBdID0gXCItPVwiICsgc2Nyb2xsRnVuYygpKTtcbiAgICAgICAgZ3NhcC5zZXQoW21hcmtlclN0YXJ0LCBtYXJrZXJFbmRdLCBjcyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChwaW4gJiYgIShfY2xhbXBpbmdNYXggJiYgc2VsZi5lbmQgPj0gX21heFNjcm9sbChzY3JvbGxlciwgZGlyZWN0aW9uKSkpIHtcbiAgICAgICAgY3MgPSBfZ2V0Q29tcHV0ZWRTdHlsZShwaW4pO1xuICAgICAgICBpc1ZlcnRpY2FsID0gZGlyZWN0aW9uID09PSBfdmVydGljYWw7XG4gICAgICAgIHNjcm9sbCA9IHNjcm9sbEZ1bmMoKTsgLy8gcmVjYWxjdWxhdGUgYmVjYXVzZSB0aGUgdHJpZ2dlcnMgY2FuIGFmZmVjdCB0aGUgc2Nyb2xsXG5cbiAgICAgICAgcGluU3RhcnQgPSBwYXJzZUZsb2F0KHBpbkdldHRlcihkaXJlY3Rpb24uYSkpICsgb3RoZXJQaW5PZmZzZXQ7XG5cbiAgICAgICAgaWYgKCFtYXggJiYgZW5kID4gMSkge1xuICAgICAgICAgIC8vIG1ha2VzIHN1cmUgdGhlIHNjcm9sbGVyIGhhcyBhIHNjcm9sbGJhciwgb3RoZXJ3aXNlIGlmIHNvbWV0aGluZyBoYXMgd2lkdGg6IDEwMCUsIGZvciBleGFtcGxlLCBpdCB3b3VsZCBiZSB0b28gYmlnIChleGNsdWRlIHRoZSBzY3JvbGxiYXIpLiBTZWUgaHR0cHM6Ly9nc2FwLmNvbS9mb3J1bXMvdG9waWMvMjUxODItc2Nyb2xsdHJpZ2dlci13aWR0aC1vZi1wYWdlLWluY3JlYXNlLXdoZXJlLW1hcmtlcnMtYXJlLXNldC10by1mYWxzZS9cbiAgICAgICAgICBmb3JjZWRPdmVyZmxvdyA9IChpc1ZpZXdwb3J0ID8gX2RvYy5zY3JvbGxpbmdFbGVtZW50IHx8IF9kb2NFbCA6IHNjcm9sbGVyKS5zdHlsZTtcbiAgICAgICAgICBmb3JjZWRPdmVyZmxvdyA9IHtcbiAgICAgICAgICAgIHN0eWxlOiBmb3JjZWRPdmVyZmxvdyxcbiAgICAgICAgICAgIHZhbHVlOiBmb3JjZWRPdmVyZmxvd1tcIm92ZXJmbG93XCIgKyBkaXJlY3Rpb24uYS50b1VwcGVyQ2FzZSgpXVxuICAgICAgICAgIH07XG5cbiAgICAgICAgICBpZiAoaXNWaWV3cG9ydCAmJiBfZ2V0Q29tcHV0ZWRTdHlsZShfYm9keSlbXCJvdmVyZmxvd1wiICsgZGlyZWN0aW9uLmEudG9VcHBlckNhc2UoKV0gIT09IFwic2Nyb2xsXCIpIHtcbiAgICAgICAgICAgIC8vIGF2b2lkIGFuIGV4dHJhIHNjcm9sbGJhciBpZiBCT1RIIDxodG1sPiBhbmQgPGJvZHk+IGhhdmUgb3ZlcmZsb3cgc2V0IHRvIFwic2Nyb2xsXCJcbiAgICAgICAgICAgIGZvcmNlZE92ZXJmbG93LnN0eWxlW1wib3ZlcmZsb3dcIiArIGRpcmVjdGlvbi5hLnRvVXBwZXJDYXNlKCldID0gXCJzY3JvbGxcIjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBfc3dhcFBpbkluKHBpbiwgc3BhY2VyLCBjcyk7XG5cbiAgICAgICAgcGluU3RhdGUgPSBfZ2V0U3RhdGUocGluKTsgLy8gdHJhbnNmb3JtcyB3aWxsIGludGVyZmVyZSB3aXRoIHRoZSB0b3AvbGVmdC9yaWdodC9ib3R0b20gcGxhY2VtZW50LCBzbyByZW1vdmUgdGhlbSB0ZW1wb3JhcmlseS4gZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkgZmFjdG9ycyBpbiB0cmFuc2Zvcm1zLlxuXG4gICAgICAgIGJvdW5kcyA9IF9nZXRCb3VuZHMocGluLCB0cnVlKTtcbiAgICAgICAgb3Bwb3NpdGVTY3JvbGwgPSB1c2VGaXhlZFBvc2l0aW9uICYmIF9nZXRTY3JvbGxGdW5jKHNjcm9sbGVyLCBpc1ZlcnRpY2FsID8gX2hvcml6b250YWwgOiBfdmVydGljYWwpKCk7XG5cbiAgICAgICAgaWYgKHBpblNwYWNpbmcpIHtcbiAgICAgICAgICBzcGFjZXJTdGF0ZSA9IFtwaW5TcGFjaW5nICsgZGlyZWN0aW9uLm9zMiwgY2hhbmdlICsgb3RoZXJQaW5PZmZzZXQgKyBfcHhdO1xuICAgICAgICAgIHNwYWNlclN0YXRlLnQgPSBzcGFjZXI7XG4gICAgICAgICAgaSA9IHBpblNwYWNpbmcgPT09IF9wYWRkaW5nID8gX2dldFNpemUocGluLCBkaXJlY3Rpb24pICsgY2hhbmdlICsgb3RoZXJQaW5PZmZzZXQgOiAwO1xuXG4gICAgICAgICAgaWYgKGkpIHtcbiAgICAgICAgICAgIHNwYWNlclN0YXRlLnB1c2goZGlyZWN0aW9uLmQsIGkgKyBfcHgpOyAvLyBmb3IgYm94LXNpemluZzogYm9yZGVyLWJveCAobXVzdCBpbmNsdWRlIHBhZGRpbmcpLlxuXG4gICAgICAgICAgICBzcGFjZXIuc3R5bGUuZmxleEJhc2lzICE9PSBcImF1dG9cIiAmJiAoc3BhY2VyLnN0eWxlLmZsZXhCYXNpcyA9IGkgKyBfcHgpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIF9zZXRTdGF0ZShzcGFjZXJTdGF0ZSk7XG5cbiAgICAgICAgICBpZiAocGlubmVkQ29udGFpbmVyKSB7XG4gICAgICAgICAgICAvLyBpbiBTY3JvbGxUcmlnZ2VyLnJlZnJlc2goKSwgd2UgbmVlZCB0byByZS1ldmFsdWF0ZSB0aGUgcGluQ29udGFpbmVyJ3Mgc2l6ZSBiZWNhdXNlIHRoaXMgcGluU3BhY2luZyBtYXkgc3RyZXRjaCBpdCBvdXQsIGJ1dCB3ZSBjYW4ndCBqdXN0IGFkZCB0aGUgZXhhY3QgZGlzdGFuY2UgYmVjYXVzZSBkZXBlbmRpbmcgb24gbGF5b3V0LCBpdCBtYXkgbm90IHB1c2ggdGhpbmdzIGRvd24gb3IgaXQgbWF5IG9ubHkgZG8gc28gcGFydGlhbGx5LlxuICAgICAgICAgICAgX3RyaWdnZXJzLmZvckVhY2goZnVuY3Rpb24gKHQpIHtcbiAgICAgICAgICAgICAgaWYgKHQucGluID09PSBwaW5uZWRDb250YWluZXIgJiYgdC52YXJzLnBpblNwYWNpbmcgIT09IGZhbHNlKSB7XG4gICAgICAgICAgICAgICAgdC5fc3ViUGluT2Zmc2V0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdXNlRml4ZWRQb3NpdGlvbiAmJiBzY3JvbGxGdW5jKHByZXZTY3JvbGwpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGkgPSBfZ2V0U2l6ZShwaW4sIGRpcmVjdGlvbik7XG4gICAgICAgICAgaSAmJiBzcGFjZXIuc3R5bGUuZmxleEJhc2lzICE9PSBcImF1dG9cIiAmJiAoc3BhY2VyLnN0eWxlLmZsZXhCYXNpcyA9IGkgKyBfcHgpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHVzZUZpeGVkUG9zaXRpb24pIHtcbiAgICAgICAgICBvdmVycmlkZSA9IHtcbiAgICAgICAgICAgIHRvcDogYm91bmRzLnRvcCArIChpc1ZlcnRpY2FsID8gc2Nyb2xsIC0gc3RhcnQgOiBvcHBvc2l0ZVNjcm9sbCkgKyBfcHgsXG4gICAgICAgICAgICBsZWZ0OiBib3VuZHMubGVmdCArIChpc1ZlcnRpY2FsID8gb3Bwb3NpdGVTY3JvbGwgOiBzY3JvbGwgLSBzdGFydCkgKyBfcHgsXG4gICAgICAgICAgICBib3hTaXppbmc6IFwiYm9yZGVyLWJveFwiLFxuICAgICAgICAgICAgcG9zaXRpb246IFwiZml4ZWRcIlxuICAgICAgICAgIH07XG4gICAgICAgICAgb3ZlcnJpZGVbX3dpZHRoXSA9IG92ZXJyaWRlW1wibWF4XCIgKyBfV2lkdGhdID0gTWF0aC5jZWlsKGJvdW5kcy53aWR0aCkgKyBfcHg7XG4gICAgICAgICAgb3ZlcnJpZGVbX2hlaWdodF0gPSBvdmVycmlkZVtcIm1heFwiICsgX0hlaWdodF0gPSBNYXRoLmNlaWwoYm91bmRzLmhlaWdodCkgKyBfcHg7XG4gICAgICAgICAgb3ZlcnJpZGVbX21hcmdpbl0gPSBvdmVycmlkZVtfbWFyZ2luICsgX1RvcF0gPSBvdmVycmlkZVtfbWFyZ2luICsgX1JpZ2h0XSA9IG92ZXJyaWRlW19tYXJnaW4gKyBfQm90dG9tXSA9IG92ZXJyaWRlW19tYXJnaW4gKyBfTGVmdF0gPSBcIjBcIjtcbiAgICAgICAgICBvdmVycmlkZVtfcGFkZGluZ10gPSBjc1tfcGFkZGluZ107XG4gICAgICAgICAgb3ZlcnJpZGVbX3BhZGRpbmcgKyBfVG9wXSA9IGNzW19wYWRkaW5nICsgX1RvcF07XG4gICAgICAgICAgb3ZlcnJpZGVbX3BhZGRpbmcgKyBfUmlnaHRdID0gY3NbX3BhZGRpbmcgKyBfUmlnaHRdO1xuICAgICAgICAgIG92ZXJyaWRlW19wYWRkaW5nICsgX0JvdHRvbV0gPSBjc1tfcGFkZGluZyArIF9Cb3R0b21dO1xuICAgICAgICAgIG92ZXJyaWRlW19wYWRkaW5nICsgX0xlZnRdID0gY3NbX3BhZGRpbmcgKyBfTGVmdF07XG4gICAgICAgICAgcGluQWN0aXZlU3RhdGUgPSBfY29weVN0YXRlKHBpbk9yaWdpbmFsU3RhdGUsIG92ZXJyaWRlLCBwaW5SZXBhcmVudCk7XG4gICAgICAgICAgX3JlZnJlc2hpbmdBbGwgJiYgc2Nyb2xsRnVuYygwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChhbmltYXRpb24pIHtcbiAgICAgICAgICAvLyB0aGUgYW5pbWF0aW9uIG1pZ2h0IGJlIGFmZmVjdGluZyB0aGUgdHJhbnNmb3JtLCBzbyB3ZSBtdXN0IGp1bXAgdG8gdGhlIGVuZCwgY2hlY2sgdGhlIHZhbHVlLCBhbmQgY29tcGVuc2F0ZSBhY2NvcmRpbmdseS4gT3RoZXJ3aXNlLCB3aGVuIGl0IGJlY29tZXMgdW5waW5uZWQsIHRoZSBwaW5TZXR0ZXIoKSB3aWxsIGdldCBzZXQgdG8gYSB2YWx1ZSB0aGF0IGRvZXNuJ3QgaW5jbHVkZSB3aGF0ZXZlciB0aGUgYW5pbWF0aW9uIGRpZC5cbiAgICAgICAgICBpbml0dGVkID0gYW5pbWF0aW9uLl9pbml0dGVkOyAvLyBpZiBub3QsIHdlIG11c3QgaW52YWxpZGF0ZSgpIGFmdGVyIHRoaXMgc3RlcCwgb3RoZXJ3aXNlIGl0IGNvdWxkIGxvY2sgaW4gc3RhcnRpbmcgdmFsdWVzIHByZW1hdHVyZWx5LlxuXG4gICAgICAgICAgX3N1cHByZXNzT3ZlcndyaXRlcygxKTtcblxuICAgICAgICAgIGFuaW1hdGlvbi5yZW5kZXIoYW5pbWF0aW9uLmR1cmF0aW9uKCksIHRydWUsIHRydWUpO1xuICAgICAgICAgIHBpbkNoYW5nZSA9IHBpbkdldHRlcihkaXJlY3Rpb24uYSkgLSBwaW5TdGFydCArIGNoYW5nZSArIG90aGVyUGluT2Zmc2V0O1xuICAgICAgICAgIHBpbk1vdmVzID0gTWF0aC5hYnMoY2hhbmdlIC0gcGluQ2hhbmdlKSA+IDE7XG4gICAgICAgICAgdXNlRml4ZWRQb3NpdGlvbiAmJiBwaW5Nb3ZlcyAmJiBwaW5BY3RpdmVTdGF0ZS5zcGxpY2UocGluQWN0aXZlU3RhdGUubGVuZ3RoIC0gMiwgMik7IC8vIHRyYW5zZm9ybSBpcyB0aGUgbGFzdCBwcm9wZXJ0eS92YWx1ZSBzZXQgaW4gdGhlIHN0YXRlIEFycmF5LiBTaW5jZSB0aGUgYW5pbWF0aW9uIGlzIGNvbnRyb2xsaW5nIHRoYXQsIHdlIHNob3VsZCBvbWl0IGl0LlxuXG4gICAgICAgICAgYW5pbWF0aW9uLnJlbmRlcigwLCB0cnVlLCB0cnVlKTtcbiAgICAgICAgICBpbml0dGVkIHx8IGFuaW1hdGlvbi5pbnZhbGlkYXRlKHRydWUpO1xuICAgICAgICAgIGFuaW1hdGlvbi5wYXJlbnQgfHwgYW5pbWF0aW9uLnRvdGFsVGltZShhbmltYXRpb24udG90YWxUaW1lKCkpOyAvLyBpZiwgZm9yIGV4YW1wbGUsIGEgdG9nZ2xlQWN0aW9uIGNhbGxlZCBwbGF5KCkgYW5kIHRoZW4gcmVmcmVzaCgpIGhhcHBlbnMgYW5kIHdoZW4gd2UgcmVuZGVyKDEpIGFib3ZlLCBpdCB3b3VsZCBjYXVzZSB0aGUgYW5pbWF0aW9uIHRvIGNvbXBsZXRlIGFuZCBnZXQgcmVtb3ZlZCBmcm9tIGl0cyBwYXJlbnQsIHNvIHRoaXMgbWFrZXMgc3VyZSBpdCBnZXRzIHB1dCBiYWNrIGluLlxuXG4gICAgICAgICAgX3N1cHByZXNzT3ZlcndyaXRlcygwKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwaW5DaGFuZ2UgPSBjaGFuZ2U7XG4gICAgICAgIH1cblxuICAgICAgICBmb3JjZWRPdmVyZmxvdyAmJiAoZm9yY2VkT3ZlcmZsb3cudmFsdWUgPyBmb3JjZWRPdmVyZmxvdy5zdHlsZVtcIm92ZXJmbG93XCIgKyBkaXJlY3Rpb24uYS50b1VwcGVyQ2FzZSgpXSA9IGZvcmNlZE92ZXJmbG93LnZhbHVlIDogZm9yY2VkT3ZlcmZsb3cuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJvdmVyZmxvdy1cIiArIGRpcmVjdGlvbi5hKSk7XG4gICAgICB9IGVsc2UgaWYgKHRyaWdnZXIgJiYgc2Nyb2xsRnVuYygpICYmICFjb250YWluZXJBbmltYXRpb24pIHtcbiAgICAgICAgLy8gaXQgbWF5IGJlIElOU0lERSBhIHBpbm5lZCBlbGVtZW50LCBzbyB3YWxrIHVwIHRoZSB0cmVlIGFuZCBsb29rIGZvciBhbnkgZWxlbWVudHMgd2l0aCBfcGluT2Zmc2V0IHRvIGNvbXBlbnNhdGUgYmVjYXVzZSBhbnl0aGluZyB3aXRoIHBpblNwYWNpbmcgdGhhdCdzIGFscmVhZHkgc2Nyb2xsZWQgd291bGQgdGhyb3cgb2ZmIHRoZSBtZWFzdXJlbWVudHMgaW4gZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClcbiAgICAgICAgYm91bmRzID0gdHJpZ2dlci5wYXJlbnROb2RlO1xuXG4gICAgICAgIHdoaWxlIChib3VuZHMgJiYgYm91bmRzICE9PSBfYm9keSkge1xuICAgICAgICAgIGlmIChib3VuZHMuX3Bpbk9mZnNldCkge1xuICAgICAgICAgICAgc3RhcnQgLT0gYm91bmRzLl9waW5PZmZzZXQ7XG4gICAgICAgICAgICBlbmQgLT0gYm91bmRzLl9waW5PZmZzZXQ7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgYm91bmRzID0gYm91bmRzLnBhcmVudE5vZGU7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV2ZXJ0ZWRQaW5zICYmIHJldmVydGVkUGlucy5mb3JFYWNoKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgIHJldHVybiB0LnJldmVydChmYWxzZSwgdHJ1ZSk7XG4gICAgICB9KTtcbiAgICAgIHNlbGYuc3RhcnQgPSBzdGFydDtcbiAgICAgIHNlbGYuZW5kID0gZW5kO1xuICAgICAgc2Nyb2xsMSA9IHNjcm9sbDIgPSBfcmVmcmVzaGluZ0FsbCA/IHByZXZTY3JvbGwgOiBzY3JvbGxGdW5jKCk7IC8vIHJlc2V0IHZlbG9jaXR5XG5cbiAgICAgIGlmICghY29udGFpbmVyQW5pbWF0aW9uICYmICFfcmVmcmVzaGluZ0FsbCkge1xuICAgICAgICBzY3JvbGwxIDwgcHJldlNjcm9sbCAmJiBzY3JvbGxGdW5jKHByZXZTY3JvbGwpO1xuICAgICAgICBzZWxmLnNjcm9sbC5yZWMgPSAwO1xuICAgICAgfVxuXG4gICAgICBzZWxmLnJldmVydChmYWxzZSwgdHJ1ZSk7XG4gICAgICBsYXN0UmVmcmVzaCA9IF9nZXRUaW1lKCk7XG5cbiAgICAgIGlmIChzbmFwRGVsYXllZENhbGwpIHtcbiAgICAgICAgbGFzdFNuYXAgPSAtMTsgLy8ganVzdCBzbyBzbmFwcGluZyBnZXRzIHJlLWVuYWJsZWQsIGNsZWFyIG91dCBhbnkgcmVjb3JkZWQgbGFzdCB2YWx1ZVxuICAgICAgICAvLyBzZWxmLmlzQWN0aXZlICYmIHNjcm9sbEZ1bmMoc3RhcnQgKyBjaGFuZ2UgKiBwcmV2UHJvZ3Jlc3MpOyAvLyBwcmV2aW91c2x5IHRoaXMgbGluZSB3YXMgaGVyZSB0byBlbnN1cmUgdGhhdCB3aGVuIHNuYXBwaW5nIGtpY2tzIGluLCBpdCdzIGZyb20gdGhlIHByZXZpb3VzIHByb2dyZXNzIGJ1dCBpbiBzb21lIGNhc2VzIHRoYXQncyBub3QgZGVzaXJhYmxlLCBsaWtlIGFuIGFsbC1wYWdlIFNjcm9sbFRyaWdnZXIgd2hlbiBuZXcgY29udGVudCBnZXRzIGFkZGVkIHRvIHRoZSBwYWdlLCB0aGF0J2QgdG90YWxseSBjaGFuZ2UgdGhlIHByb2dyZXNzLlxuXG4gICAgICAgIHNuYXBEZWxheWVkQ2FsbC5yZXN0YXJ0KHRydWUpO1xuICAgICAgfVxuXG4gICAgICBfcmVmcmVzaGluZyA9IDA7XG4gICAgICBhbmltYXRpb24gJiYgaXNUb2dnbGUgJiYgKGFuaW1hdGlvbi5faW5pdHRlZCB8fCBwcmV2QW5pbVByb2dyZXNzKSAmJiBhbmltYXRpb24ucHJvZ3Jlc3MoKSAhPT0gcHJldkFuaW1Qcm9ncmVzcyAmJiBhbmltYXRpb24ucHJvZ3Jlc3MocHJldkFuaW1Qcm9ncmVzcyB8fCAwLCB0cnVlKS5yZW5kZXIoYW5pbWF0aW9uLnRpbWUoKSwgdHJ1ZSwgdHJ1ZSk7IC8vIG11c3QgZm9yY2UgYSByZS1yZW5kZXIgYmVjYXVzZSBpZiBzYXZlU3R5bGVzKCkgd2FzIHVzZWQgb24gdGhlIHRhcmdldChzKSwgdGhlIHN0eWxlcyBjb3VsZCBoYXZlIGJlZW4gd2lwZWQgb3V0IGR1cmluZyB0aGUgcmVmcmVzaCgpLlxuXG4gICAgICBpZiAoaXNGaXJzdFJlZnJlc2ggfHwgcHJldlByb2dyZXNzICE9PSBzZWxmLnByb2dyZXNzIHx8IGNvbnRhaW5lckFuaW1hdGlvbiB8fCBpbnZhbGlkYXRlT25SZWZyZXNoIHx8IGFuaW1hdGlvbiAmJiAhYW5pbWF0aW9uLl9pbml0dGVkKSB7XG4gICAgICAgIC8vIGVuc3VyZXMgdGhhdCB0aGUgZGlyZWN0aW9uIGlzIHNldCBwcm9wZXJseSAod2hlbiByZWZyZXNoaW5nLCBwcm9ncmVzcyBpcyBzZXQgYmFjayB0byAwIGluaXRpYWxseSwgdGhlbiBiYWNrIGFnYWluIHRvIHdoZXJldmVyIGl0IG5lZWRzIHRvIGJlKSBhbmQgdGhhdCBjYWxsYmFja3MgYXJlIHRyaWdnZXJlZC5cbiAgICAgICAgYW5pbWF0aW9uICYmICFpc1RvZ2dsZSAmJiAoYW5pbWF0aW9uLl9pbml0dGVkIHx8IHByZXZQcm9ncmVzcyB8fCBhbmltYXRpb24udmFycy5pbW1lZGlhdGVSZW5kZXIgIT09IGZhbHNlKSAmJiBhbmltYXRpb24udG90YWxQcm9ncmVzcyhjb250YWluZXJBbmltYXRpb24gJiYgc3RhcnQgPCAtMC4wMDEgJiYgIXByZXZQcm9ncmVzcyA/IGdzYXAudXRpbHMubm9ybWFsaXplKHN0YXJ0LCBlbmQsIDApIDogcHJldlByb2dyZXNzLCB0cnVlKTsgLy8gdG8gYXZvaWQgaXNzdWVzIHdoZXJlIGFuaW1hdGlvbiBjYWxsYmFja3MgbGlrZSBvblN0YXJ0IGFyZW4ndCB0cmlnZ2VyZWQuXG5cbiAgICAgICAgc2VsZi5wcm9ncmVzcyA9IGlzRmlyc3RSZWZyZXNoIHx8IChzY3JvbGwxIC0gc3RhcnQpIC8gY2hhbmdlID09PSBwcmV2UHJvZ3Jlc3MgPyAwIDogcHJldlByb2dyZXNzO1xuICAgICAgfVxuXG4gICAgICBwaW4gJiYgcGluU3BhY2luZyAmJiAoc3BhY2VyLl9waW5PZmZzZXQgPSBNYXRoLnJvdW5kKHNlbGYucHJvZ3Jlc3MgKiBwaW5DaGFuZ2UpKTtcbiAgICAgIHNjcnViVHdlZW4gJiYgc2NydWJUd2Vlbi5pbnZhbGlkYXRlKCk7XG5cbiAgICAgIGlmICghaXNOYU4obWFya2VyU3RhcnRPZmZzZXQpKSB7XG4gICAgICAgIC8vIG51bWJlcnMgd2VyZSBwYXNzZWQgaW4gZm9yIHRoZSBwb3NpdGlvbiB3aGljaCBhcmUgYWJzb2x1dGUsIHNvIGluc3RlYWQgb2YganVzdCBwdXR0aW5nIHRoZSBtYXJrZXJzIGF0IHRoZSB2ZXJ5IGJvdHRvbSBvZiB0aGUgdmlld3BvcnQsIHdlIGZpZ3VyZSBvdXQgaG93IGZhciB0aGV5IHNoaWZ0ZWQgZG93biAoaXQncyBzYWZlIHRvIGFzc3VtZSB0aGV5IHdlcmUgb3JpZ2luYWxseSBwb3NpdGlvbmVkIGluIGNsb3NlciByZWxhdGlvbiB0byB0aGUgdHJpZ2dlciBlbGVtZW50IHdpdGggdmFsdWVzIGxpa2UgXCJ0b3BcIiwgXCJjZW50ZXJcIiwgYSBwZXJjZW50YWdlIG9yIHdoYXRldmVyLCBzbyB3ZSBvZmZzZXQgdGhhdCBtdWNoIGluIHRoZSBvcHBvc2l0ZSBkaXJlY3Rpb24gdG8gYmFzaWNhbGx5IHJldmVydCB0aGVtIHRvIHRoZSByZWxhdGl2ZSBwb3NpdGlvbiB0aHkgd2VyZSBhdCBwcmV2aW91c2x5LlxuICAgICAgICBtYXJrZXJTdGFydE9mZnNldCAtPSBnc2FwLmdldFByb3BlcnR5KG1hcmtlclN0YXJ0VHJpZ2dlciwgZGlyZWN0aW9uLnApO1xuICAgICAgICBtYXJrZXJFbmRPZmZzZXQgLT0gZ3NhcC5nZXRQcm9wZXJ0eShtYXJrZXJFbmRUcmlnZ2VyLCBkaXJlY3Rpb24ucCk7XG5cbiAgICAgICAgX3NoaWZ0TWFya2VyKG1hcmtlclN0YXJ0VHJpZ2dlciwgZGlyZWN0aW9uLCBtYXJrZXJTdGFydE9mZnNldCk7XG5cbiAgICAgICAgX3NoaWZ0TWFya2VyKG1hcmtlclN0YXJ0LCBkaXJlY3Rpb24sIG1hcmtlclN0YXJ0T2Zmc2V0IC0gKHBpbk9mZnNldCB8fCAwKSk7XG5cbiAgICAgICAgX3NoaWZ0TWFya2VyKG1hcmtlckVuZFRyaWdnZXIsIGRpcmVjdGlvbiwgbWFya2VyRW5kT2Zmc2V0KTtcblxuICAgICAgICBfc2hpZnRNYXJrZXIobWFya2VyRW5kLCBkaXJlY3Rpb24sIG1hcmtlckVuZE9mZnNldCAtIChwaW5PZmZzZXQgfHwgMCkpO1xuICAgICAgfVxuXG4gICAgICBpc0ZpcnN0UmVmcmVzaCAmJiAhX3JlZnJlc2hpbmdBbGwgJiYgc2VsZi51cGRhdGUoKTsgLy8gZWRnZSBjYXNlIC0gd2hlbiB5b3UgcmVsb2FkIGEgcGFnZSB3aGVuIGl0J3MgYWxyZWFkeSBzY3JvbGxlZCBkb3duLCBzb21lIGJyb3dzZXJzIGZpcmUgYSBcInNjcm9sbFwiIGV2ZW50IGJlZm9yZSBET01Db250ZW50TG9hZGVkLCB0cmlnZ2VyaW5nIGFuIHVwZGF0ZUFsbCgpLiBJZiB3ZSBkb24ndCB1cGRhdGUgdGhlIHNlbGYucHJvZ3Jlc3MgYXMgcGFydCBvZiByZWZyZXNoKCksIHRoZW4gd2hlbiBpdCBoYXBwZW5zIG5leHQsIGl0IG1heSByZWNvcmQgcHJldlByb2dyZXNzIGFzIDAgd2hlbiBpdCByZWFsbHkgc2hvdWxkbid0LCBwb3RlbnRpYWxseSBjYXVzaW5nIGEgY2FsbGJhY2sgaW4gYW4gYW5pbWF0aW9uIHRvIGZpcmUgYWdhaW4uXG5cbiAgICAgIGlmIChvblJlZnJlc2ggJiYgIV9yZWZyZXNoaW5nQWxsICYmICFleGVjdXRpbmdPblJlZnJlc2gpIHtcbiAgICAgICAgLy8gd2hlbiByZWZyZXNoaW5nIGFsbCwgd2UgZG8gZXh0cmEgd29yayB0byBjb3JyZWN0IHBpbm5lZENvbnRhaW5lciBzaXplcyBhbmQgZW5zdXJlIHRoaW5ncyBkb24ndCBleGNlZWQgdGhlIG1heFNjcm9sbCwgc28gd2Ugc2hvdWxkIGRvIGFsbCB0aGUgcmVmcmVzaGVzIGF0IHRoZSBlbmQgYWZ0ZXIgYWxsIHRoYXQgd29yayBzbyB0aGF0IHRoZSBzdGFydC9lbmQgdmFsdWVzIGFyZSBjb3JyZWN0ZWQuXG4gICAgICAgIGV4ZWN1dGluZ09uUmVmcmVzaCA9IHRydWU7XG4gICAgICAgIG9uUmVmcmVzaChzZWxmKTtcbiAgICAgICAgZXhlY3V0aW5nT25SZWZyZXNoID0gZmFsc2U7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHNlbGYuZ2V0VmVsb2NpdHkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gKHNjcm9sbEZ1bmMoKSAtIHNjcm9sbDIpIC8gKF9nZXRUaW1lKCkgLSBfdGltZTIpICogMTAwMCB8fCAwO1xuICAgIH07XG5cbiAgICBzZWxmLmVuZEFuaW1hdGlvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIF9lbmRBbmltYXRpb24oc2VsZi5jYWxsYmFja0FuaW1hdGlvbik7XG5cbiAgICAgIGlmIChhbmltYXRpb24pIHtcbiAgICAgICAgc2NydWJUd2VlbiA/IHNjcnViVHdlZW4ucHJvZ3Jlc3MoMSkgOiAhYW5pbWF0aW9uLnBhdXNlZCgpID8gX2VuZEFuaW1hdGlvbihhbmltYXRpb24sIGFuaW1hdGlvbi5yZXZlcnNlZCgpKSA6IGlzVG9nZ2xlIHx8IF9lbmRBbmltYXRpb24oYW5pbWF0aW9uLCBzZWxmLmRpcmVjdGlvbiA8IDAsIDEpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBzZWxmLmxhYmVsVG9TY3JvbGwgPSBmdW5jdGlvbiAobGFiZWwpIHtcbiAgICAgIHJldHVybiBhbmltYXRpb24gJiYgYW5pbWF0aW9uLmxhYmVscyAmJiAoc3RhcnQgfHwgc2VsZi5yZWZyZXNoKCkgfHwgc3RhcnQpICsgYW5pbWF0aW9uLmxhYmVsc1tsYWJlbF0gLyBhbmltYXRpb24uZHVyYXRpb24oKSAqIGNoYW5nZSB8fCAwO1xuICAgIH07XG5cbiAgICBzZWxmLmdldFRyYWlsaW5nID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgIHZhciBpID0gX3RyaWdnZXJzLmluZGV4T2Yoc2VsZiksXG4gICAgICAgICAgYSA9IHNlbGYuZGlyZWN0aW9uID4gMCA/IF90cmlnZ2Vycy5zbGljZSgwLCBpKS5yZXZlcnNlKCkgOiBfdHJpZ2dlcnMuc2xpY2UoaSArIDEpO1xuXG4gICAgICByZXR1cm4gKF9pc1N0cmluZyhuYW1lKSA/IGEuZmlsdGVyKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgIHJldHVybiB0LnZhcnMucHJldmVudE92ZXJsYXBzID09PSBuYW1lO1xuICAgICAgfSkgOiBhKS5maWx0ZXIoZnVuY3Rpb24gKHQpIHtcbiAgICAgICAgcmV0dXJuIHNlbGYuZGlyZWN0aW9uID4gMCA/IHQuZW5kIDw9IHN0YXJ0IDogdC5zdGFydCA+PSBlbmQ7XG4gICAgICB9KTtcbiAgICB9O1xuXG4gICAgc2VsZi51cGRhdGUgPSBmdW5jdGlvbiAocmVzZXQsIHJlY29yZFZlbG9jaXR5LCBmb3JjZUZha2UpIHtcbiAgICAgIGlmIChjb250YWluZXJBbmltYXRpb24gJiYgIWZvcmNlRmFrZSAmJiAhcmVzZXQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICB2YXIgc2Nyb2xsID0gX3JlZnJlc2hpbmdBbGwgPT09IHRydWUgPyBwcmV2U2Nyb2xsIDogc2VsZi5zY3JvbGwoKSxcbiAgICAgICAgICBwID0gcmVzZXQgPyAwIDogKHNjcm9sbCAtIHN0YXJ0KSAvIGNoYW5nZSxcbiAgICAgICAgICBjbGlwcGVkID0gcCA8IDAgPyAwIDogcCA+IDEgPyAxIDogcCB8fCAwLFxuICAgICAgICAgIHByZXZQcm9ncmVzcyA9IHNlbGYucHJvZ3Jlc3MsXG4gICAgICAgICAgaXNBY3RpdmUsXG4gICAgICAgICAgd2FzQWN0aXZlLFxuICAgICAgICAgIHRvZ2dsZVN0YXRlLFxuICAgICAgICAgIGFjdGlvbixcbiAgICAgICAgICBzdGF0ZUNoYW5nZWQsXG4gICAgICAgICAgdG9nZ2xlZCxcbiAgICAgICAgICBpc0F0TWF4LFxuICAgICAgICAgIGlzVGFraW5nQWN0aW9uO1xuXG4gICAgICBpZiAocmVjb3JkVmVsb2NpdHkpIHtcbiAgICAgICAgc2Nyb2xsMiA9IHNjcm9sbDE7XG4gICAgICAgIHNjcm9sbDEgPSBjb250YWluZXJBbmltYXRpb24gPyBzY3JvbGxGdW5jKCkgOiBzY3JvbGw7XG5cbiAgICAgICAgaWYgKHNuYXApIHtcbiAgICAgICAgICBzbmFwMiA9IHNuYXAxO1xuICAgICAgICAgIHNuYXAxID0gYW5pbWF0aW9uICYmICFpc1RvZ2dsZSA/IGFuaW1hdGlvbi50b3RhbFByb2dyZXNzKCkgOiBjbGlwcGVkO1xuICAgICAgICB9XG4gICAgICB9IC8vIGFudGljaXBhdGUgdGhlIHBpbm5pbmcgYSBmZXcgdGlja3MgYWhlYWQgb2YgdGltZSBiYXNlZCBvbiB2ZWxvY2l0eSB0byBhdm9pZCBhIHZpc3VhbCBnbGl0Y2ggZHVlIHRvIHRoZSBmYWN0IHRoYXQgbW9zdCBicm93c2VycyBkbyBzY3JvbGxpbmcgb24gYSBzZXBhcmF0ZSB0aHJlYWQgKG5vdCBzeW5jZWQgd2l0aCByZXF1ZXN0QW5pbWF0aW9uRnJhbWUpLlxuXG5cbiAgICAgIGlmIChhbnRpY2lwYXRlUGluICYmIHBpbiAmJiAhX3JlZnJlc2hpbmcgJiYgIV9zdGFydHVwICYmIF9sYXN0U2Nyb2xsVGltZSkge1xuICAgICAgICBpZiAoIWNsaXBwZWQgJiYgc3RhcnQgPCBzY3JvbGwgKyAoc2Nyb2xsIC0gc2Nyb2xsMikgLyAoX2dldFRpbWUoKSAtIF90aW1lMikgKiBhbnRpY2lwYXRlUGluKSB7XG4gICAgICAgICAgY2xpcHBlZCA9IDAuMDAwMTtcbiAgICAgICAgfSBlbHNlIGlmIChjbGlwcGVkID09PSAxICYmIGVuZCA+IHNjcm9sbCArIChzY3JvbGwgLSBzY3JvbGwyKSAvIChfZ2V0VGltZSgpIC0gX3RpbWUyKSAqIGFudGljaXBhdGVQaW4pIHtcbiAgICAgICAgICBjbGlwcGVkID0gMC45OTk5O1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChjbGlwcGVkICE9PSBwcmV2UHJvZ3Jlc3MgJiYgc2VsZi5lbmFibGVkKSB7XG4gICAgICAgIGlzQWN0aXZlID0gc2VsZi5pc0FjdGl2ZSA9ICEhY2xpcHBlZCAmJiBjbGlwcGVkIDwgMTtcbiAgICAgICAgd2FzQWN0aXZlID0gISFwcmV2UHJvZ3Jlc3MgJiYgcHJldlByb2dyZXNzIDwgMTtcbiAgICAgICAgdG9nZ2xlZCA9IGlzQWN0aXZlICE9PSB3YXNBY3RpdmU7XG4gICAgICAgIHN0YXRlQ2hhbmdlZCA9IHRvZ2dsZWQgfHwgISFjbGlwcGVkICE9PSAhIXByZXZQcm9ncmVzczsgLy8gY291bGQgZ28gZnJvbSBzdGFydCBhbGwgdGhlIHdheSB0byBlbmQsIHRodXMgaXQgZGlkbid0IHRvZ2dsZSBidXQgaXQgZGlkIGNoYW5nZSBzdGF0ZSBpbiBhIHNlbnNlIChtYXkgbmVlZCB0byBmaXJlIGEgY2FsbGJhY2spXG5cbiAgICAgICAgc2VsZi5kaXJlY3Rpb24gPSBjbGlwcGVkID4gcHJldlByb2dyZXNzID8gMSA6IC0xO1xuICAgICAgICBzZWxmLnByb2dyZXNzID0gY2xpcHBlZDtcblxuICAgICAgICBpZiAoc3RhdGVDaGFuZ2VkICYmICFfcmVmcmVzaGluZykge1xuICAgICAgICAgIHRvZ2dsZVN0YXRlID0gY2xpcHBlZCAmJiAhcHJldlByb2dyZXNzID8gMCA6IGNsaXBwZWQgPT09IDEgPyAxIDogcHJldlByb2dyZXNzID09PSAxID8gMiA6IDM7IC8vIDAgPSBlbnRlciwgMSA9IGxlYXZlLCAyID0gZW50ZXJCYWNrLCAzID0gbGVhdmVCYWNrICh3ZSBwcmlvcml0aXplIHRoZSBGSVJTVCBlbmNvdW50ZXIsIHRodXMgaWYgeW91IHNjcm9sbCByZWFsbHkgZmFzdCBwYXN0IHRoZSBvbkVudGVyIGFuZCBvbkxlYXZlIGluIG9uZSB0aWNrLCBpdCdkIHByaW9yaXRpemUgb25FbnRlci5cblxuICAgICAgICAgIGlmIChpc1RvZ2dsZSkge1xuICAgICAgICAgICAgYWN0aW9uID0gIXRvZ2dsZWQgJiYgdG9nZ2xlQWN0aW9uc1t0b2dnbGVTdGF0ZSArIDFdICE9PSBcIm5vbmVcIiAmJiB0b2dnbGVBY3Rpb25zW3RvZ2dsZVN0YXRlICsgMV0gfHwgdG9nZ2xlQWN0aW9uc1t0b2dnbGVTdGF0ZV07IC8vIGlmIGl0IGRpZG4ndCB0b2dnbGUsIHRoYXQgbWVhbnMgaXQgc2hvdCByaWdodCBwYXN0IGFuZCBzaW5jZSB3ZSBwcmlvcml0aXplIHRoZSBcImVudGVyXCIgYWN0aW9uLCB3ZSBzaG91bGQgc3dpdGNoIHRvIHRoZSBcImxlYXZlXCIgaW4gdGhpcyBjYXNlIChidXQgb25seSBpZiBvbmUgaXMgZGVmaW5lZClcblxuICAgICAgICAgICAgaXNUYWtpbmdBY3Rpb24gPSBhbmltYXRpb24gJiYgKGFjdGlvbiA9PT0gXCJjb21wbGV0ZVwiIHx8IGFjdGlvbiA9PT0gXCJyZXNldFwiIHx8IGFjdGlvbiBpbiBhbmltYXRpb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHByZXZlbnRPdmVybGFwcyAmJiAodG9nZ2xlZCB8fCBpc1Rha2luZ0FjdGlvbikgJiYgKGlzVGFraW5nQWN0aW9uIHx8IHNjcnViIHx8ICFhbmltYXRpb24pICYmIChfaXNGdW5jdGlvbihwcmV2ZW50T3ZlcmxhcHMpID8gcHJldmVudE92ZXJsYXBzKHNlbGYpIDogc2VsZi5nZXRUcmFpbGluZyhwcmV2ZW50T3ZlcmxhcHMpLmZvckVhY2goZnVuY3Rpb24gKHQpIHtcbiAgICAgICAgICByZXR1cm4gdC5lbmRBbmltYXRpb24oKTtcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIGlmICghaXNUb2dnbGUpIHtcbiAgICAgICAgICBpZiAoc2NydWJUd2VlbiAmJiAhX3JlZnJlc2hpbmcgJiYgIV9zdGFydHVwKSB7XG4gICAgICAgICAgICBzY3J1YlR3ZWVuLl9kcC5fdGltZSAtIHNjcnViVHdlZW4uX3N0YXJ0ICE9PSBzY3J1YlR3ZWVuLl90aW1lICYmIHNjcnViVHdlZW4ucmVuZGVyKHNjcnViVHdlZW4uX2RwLl90aW1lIC0gc2NydWJUd2Vlbi5fc3RhcnQpOyAvLyBpZiB0aGVyZSdzIGEgc2NydWIgb24gYm90aCB0aGUgY29udGFpbmVyIGFuaW1hdGlvbiBhbmQgdGhpcyBvbmUgKG9yIGEgU2Nyb2xsU21vb3RoZXIpLCB0aGUgdXBkYXRlIG9yZGVyIHdvdWxkIGNhdXNlIHRoaXMgb25lIG5vdCB0byBoYXZlIHJlbmRlcmVkIHlldCwgc28gaXQgd291bGRuJ3QgbWFrZSBhbnkgcHJvZ3Jlc3MgYmVmb3JlIHdlIC5yZXN0YXJ0KCkgaXQgaGVhZGluZyB0b3dhcmQgdGhlIG5ldyBwcm9ncmVzcyBzbyBpdCdkIGFwcGVhciBzdHVjayB0aHVzIHdlIGZvcmNlIGEgcmVuZGVyIGhlcmUuXG5cbiAgICAgICAgICAgIGlmIChzY3J1YlR3ZWVuLnJlc2V0VG8pIHtcbiAgICAgICAgICAgICAgc2NydWJUd2Vlbi5yZXNldFRvKFwidG90YWxQcm9ncmVzc1wiLCBjbGlwcGVkLCBhbmltYXRpb24uX3RUaW1lIC8gYW5pbWF0aW9uLl90RHVyKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIGxlZ2FjeSBzdXBwb3J0IChjb3VydGVzeSksIGJlZm9yZSAzLjEwLjBcbiAgICAgICAgICAgICAgc2NydWJUd2Vlbi52YXJzLnRvdGFsUHJvZ3Jlc3MgPSBjbGlwcGVkO1xuICAgICAgICAgICAgICBzY3J1YlR3ZWVuLmludmFsaWRhdGUoKS5yZXN0YXJ0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmIChhbmltYXRpb24pIHtcbiAgICAgICAgICAgIGFuaW1hdGlvbi50b3RhbFByb2dyZXNzKGNsaXBwZWQsICEhKF9yZWZyZXNoaW5nICYmIChsYXN0UmVmcmVzaCB8fCByZXNldCkpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAocGluKSB7XG4gICAgICAgICAgcmVzZXQgJiYgcGluU3BhY2luZyAmJiAoc3BhY2VyLnN0eWxlW3BpblNwYWNpbmcgKyBkaXJlY3Rpb24ub3MyXSA9IHNwYWNpbmdTdGFydCk7XG5cbiAgICAgICAgICBpZiAoIXVzZUZpeGVkUG9zaXRpb24pIHtcbiAgICAgICAgICAgIHBpblNldHRlcihfcm91bmQocGluU3RhcnQgKyBwaW5DaGFuZ2UgKiBjbGlwcGVkKSk7XG4gICAgICAgICAgfSBlbHNlIGlmIChzdGF0ZUNoYW5nZWQpIHtcbiAgICAgICAgICAgIGlzQXRNYXggPSAhcmVzZXQgJiYgY2xpcHBlZCA+IHByZXZQcm9ncmVzcyAmJiBlbmQgKyAxID4gc2Nyb2xsICYmIHNjcm9sbCArIDEgPj0gX21heFNjcm9sbChzY3JvbGxlciwgZGlyZWN0aW9uKTsgLy8gaWYgaXQncyBhdCB0aGUgVkVSWSBlbmQgb2YgdGhlIHBhZ2UsIGRvbid0IHN3aXRjaCBhd2F5IGZyb20gcG9zaXRpb246IGZpeGVkIGJlY2F1c2UgaXQncyBwb2ludGxlc3MgYW5kIGl0IGNvdWxkIGNhdXNlIGEgYnJpZWYgZmxhc2ggd2hlbiB0aGUgdXNlciBzY3JvbGxzIGJhY2sgdXAgKHdoZW4gaXQgZ2V0cyBwaW5uZWQgYWdhaW4pXG5cbiAgICAgICAgICAgIGlmIChwaW5SZXBhcmVudCkge1xuICAgICAgICAgICAgICBpZiAoIXJlc2V0ICYmIChpc0FjdGl2ZSB8fCBpc0F0TWF4KSkge1xuICAgICAgICAgICAgICAgIHZhciBib3VuZHMgPSBfZ2V0Qm91bmRzKHBpbiwgdHJ1ZSksXG4gICAgICAgICAgICAgICAgICAgIF9vZmZzZXQgPSBzY3JvbGwgLSBzdGFydDtcblxuICAgICAgICAgICAgICAgIF9yZXBhcmVudChwaW4sIF9ib2R5LCBib3VuZHMudG9wICsgKGRpcmVjdGlvbiA9PT0gX3ZlcnRpY2FsID8gX29mZnNldCA6IDApICsgX3B4LCBib3VuZHMubGVmdCArIChkaXJlY3Rpb24gPT09IF92ZXJ0aWNhbCA/IDAgOiBfb2Zmc2V0KSArIF9weCk7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgX3JlcGFyZW50KHBpbiwgc3BhY2VyKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBfc2V0U3RhdGUoaXNBY3RpdmUgfHwgaXNBdE1heCA/IHBpbkFjdGl2ZVN0YXRlIDogcGluU3RhdGUpO1xuXG4gICAgICAgICAgICBwaW5Nb3ZlcyAmJiBjbGlwcGVkIDwgMSAmJiBpc0FjdGl2ZSB8fCBwaW5TZXR0ZXIocGluU3RhcnQgKyAoY2xpcHBlZCA9PT0gMSAmJiAhaXNBdE1heCA/IHBpbkNoYW5nZSA6IDApKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBzbmFwICYmICF0d2VlblRvLnR3ZWVuICYmICFfcmVmcmVzaGluZyAmJiAhX3N0YXJ0dXAgJiYgc25hcERlbGF5ZWRDYWxsLnJlc3RhcnQodHJ1ZSk7XG4gICAgICAgIHRvZ2dsZUNsYXNzICYmICh0b2dnbGVkIHx8IG9uY2UgJiYgY2xpcHBlZCAmJiAoY2xpcHBlZCA8IDEgfHwgIV9saW1pdENhbGxiYWNrcykpICYmIF90b0FycmF5KHRvZ2dsZUNsYXNzLnRhcmdldHMpLmZvckVhY2goZnVuY3Rpb24gKGVsKSB7XG4gICAgICAgICAgcmV0dXJuIGVsLmNsYXNzTGlzdFtpc0FjdGl2ZSB8fCBvbmNlID8gXCJhZGRcIiA6IFwicmVtb3ZlXCJdKHRvZ2dsZUNsYXNzLmNsYXNzTmFtZSk7XG4gICAgICAgIH0pOyAvLyBjbGFzc2VzIGNvdWxkIGFmZmVjdCBwb3NpdGlvbmluZywgc28gZG8gaXQgZXZlbiBpZiByZXNldCBvciByZWZyZXNoaW5nIGlzIHRydWUuXG5cbiAgICAgICAgb25VcGRhdGUgJiYgIWlzVG9nZ2xlICYmICFyZXNldCAmJiBvblVwZGF0ZShzZWxmKTtcblxuICAgICAgICBpZiAoc3RhdGVDaGFuZ2VkICYmICFfcmVmcmVzaGluZykge1xuICAgICAgICAgIGlmIChpc1RvZ2dsZSkge1xuICAgICAgICAgICAgaWYgKGlzVGFraW5nQWN0aW9uKSB7XG4gICAgICAgICAgICAgIGlmIChhY3Rpb24gPT09IFwiY29tcGxldGVcIikge1xuICAgICAgICAgICAgICAgIGFuaW1hdGlvbi5wYXVzZSgpLnRvdGFsUHJvZ3Jlc3MoMSk7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAoYWN0aW9uID09PSBcInJlc2V0XCIpIHtcbiAgICAgICAgICAgICAgICBhbmltYXRpb24ucmVzdGFydCh0cnVlKS5wYXVzZSgpO1xuICAgICAgICAgICAgICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gXCJyZXN0YXJ0XCIpIHtcbiAgICAgICAgICAgICAgICBhbmltYXRpb24ucmVzdGFydCh0cnVlKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBhbmltYXRpb25bYWN0aW9uXSgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIG9uVXBkYXRlICYmIG9uVXBkYXRlKHNlbGYpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmICh0b2dnbGVkIHx8ICFfbGltaXRDYWxsYmFja3MpIHtcbiAgICAgICAgICAgIC8vIG9uIHN0YXJ0dXAsIHRoZSBwYWdlIGNvdWxkIGJlIHNjcm9sbGVkIGFuZCB3ZSBkb24ndCB3YW50IHRvIGZpcmUgY2FsbGJhY2tzIHRoYXQgZGlkbid0IHRvZ2dsZS4gRm9yIGV4YW1wbGUgb25FbnRlciBzaG91bGRuJ3QgZmlyZSBpZiB0aGUgU2Nyb2xsVHJpZ2dlciBpc24ndCBhY3R1YWxseSBlbnRlcmVkLlxuICAgICAgICAgICAgb25Ub2dnbGUgJiYgdG9nZ2xlZCAmJiBfY2FsbGJhY2soc2VsZiwgb25Ub2dnbGUpO1xuICAgICAgICAgICAgY2FsbGJhY2tzW3RvZ2dsZVN0YXRlXSAmJiBfY2FsbGJhY2soc2VsZiwgY2FsbGJhY2tzW3RvZ2dsZVN0YXRlXSk7XG4gICAgICAgICAgICBvbmNlICYmIChjbGlwcGVkID09PSAxID8gc2VsZi5raWxsKGZhbHNlLCAxKSA6IGNhbGxiYWNrc1t0b2dnbGVTdGF0ZV0gPSAwKTsgLy8gYSBjYWxsYmFjayBzaG91bGRuJ3QgYmUgY2FsbGVkIGFnYWluIGlmIG9uY2UgaXMgdHJ1ZS5cblxuICAgICAgICAgICAgaWYgKCF0b2dnbGVkKSB7XG4gICAgICAgICAgICAgIC8vIGl0J3MgcG9zc2libGUgdG8gZ28gY29tcGxldGVseSBwYXN0LCBsaWtlIGZyb20gYmVmb3JlIHRoZSBzdGFydCB0byBhZnRlciB0aGUgZW5kIChvciB2aWNlLXZlcnNhKSBpbiB3aGljaCBjYXNlIEJPVEggY2FsbGJhY2tzIHNob3VsZCBiZSBmaXJlZCBpbiB0aGF0IG9yZGVyXG4gICAgICAgICAgICAgIHRvZ2dsZVN0YXRlID0gY2xpcHBlZCA9PT0gMSA/IDEgOiAzO1xuICAgICAgICAgICAgICBjYWxsYmFja3NbdG9nZ2xlU3RhdGVdICYmIF9jYWxsYmFjayhzZWxmLCBjYWxsYmFja3NbdG9nZ2xlU3RhdGVdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoZmFzdFNjcm9sbEVuZCAmJiAhaXNBY3RpdmUgJiYgTWF0aC5hYnMoc2VsZi5nZXRWZWxvY2l0eSgpKSA+IChfaXNOdW1iZXIoZmFzdFNjcm9sbEVuZCkgPyBmYXN0U2Nyb2xsRW5kIDogMjUwMCkpIHtcbiAgICAgICAgICAgIF9lbmRBbmltYXRpb24oc2VsZi5jYWxsYmFja0FuaW1hdGlvbik7XG5cbiAgICAgICAgICAgIHNjcnViVHdlZW4gPyBzY3J1YlR3ZWVuLnByb2dyZXNzKDEpIDogX2VuZEFuaW1hdGlvbihhbmltYXRpb24sIGFjdGlvbiA9PT0gXCJyZXZlcnNlXCIgPyAxIDogIWNsaXBwZWQsIDEpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChpc1RvZ2dsZSAmJiBvblVwZGF0ZSAmJiAhX3JlZnJlc2hpbmcpIHtcbiAgICAgICAgICBvblVwZGF0ZShzZWxmKTtcbiAgICAgICAgfVxuICAgICAgfSAvLyB1cGRhdGUgYWJzb2x1dGVseS1wb3NpdGlvbmVkIG1hcmtlcnMgKG9ubHkgaWYgdGhlIHNjcm9sbGVyIGlzbid0IHRoZSB2aWV3cG9ydClcblxuXG4gICAgICBpZiAobWFya2VyRW5kU2V0dGVyKSB7XG4gICAgICAgIHZhciBuID0gY29udGFpbmVyQW5pbWF0aW9uID8gc2Nyb2xsIC8gY29udGFpbmVyQW5pbWF0aW9uLmR1cmF0aW9uKCkgKiAoY29udGFpbmVyQW5pbWF0aW9uLl9jYVNjcm9sbERpc3QgfHwgMCkgOiBzY3JvbGw7XG4gICAgICAgIG1hcmtlclN0YXJ0U2V0dGVyKG4gKyAobWFya2VyU3RhcnRUcmlnZ2VyLl9pc0ZsaXBwZWQgPyAxIDogMCkpO1xuICAgICAgICBtYXJrZXJFbmRTZXR0ZXIobik7XG4gICAgICB9XG5cbiAgICAgIGNhTWFya2VyU2V0dGVyICYmIGNhTWFya2VyU2V0dGVyKC1zY3JvbGwgLyBjb250YWluZXJBbmltYXRpb24uZHVyYXRpb24oKSAqIChjb250YWluZXJBbmltYXRpb24uX2NhU2Nyb2xsRGlzdCB8fCAwKSk7XG4gICAgfTtcblxuICAgIHNlbGYuZW5hYmxlID0gZnVuY3Rpb24gKHJlc2V0LCByZWZyZXNoKSB7XG4gICAgICBpZiAoIXNlbGYuZW5hYmxlZCkge1xuICAgICAgICBzZWxmLmVuYWJsZWQgPSB0cnVlO1xuXG4gICAgICAgIF9hZGRMaXN0ZW5lcihzY3JvbGxlciwgXCJyZXNpemVcIiwgX29uUmVzaXplKTtcblxuICAgICAgICBpc1ZpZXdwb3J0IHx8IF9hZGRMaXN0ZW5lcihzY3JvbGxlciwgXCJzY3JvbGxcIiwgX29uU2Nyb2xsKTtcbiAgICAgICAgb25SZWZyZXNoSW5pdCAmJiBfYWRkTGlzdGVuZXIoU2Nyb2xsVHJpZ2dlciwgXCJyZWZyZXNoSW5pdFwiLCBvblJlZnJlc2hJbml0KTtcblxuICAgICAgICBpZiAocmVzZXQgIT09IGZhbHNlKSB7XG4gICAgICAgICAgc2VsZi5wcm9ncmVzcyA9IHByZXZQcm9ncmVzcyA9IDA7XG4gICAgICAgICAgc2Nyb2xsMSA9IHNjcm9sbDIgPSBsYXN0U25hcCA9IHNjcm9sbEZ1bmMoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJlZnJlc2ggIT09IGZhbHNlICYmIHNlbGYucmVmcmVzaCgpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBzZWxmLmdldFR3ZWVuID0gZnVuY3Rpb24gKHNuYXApIHtcbiAgICAgIHJldHVybiBzbmFwICYmIHR3ZWVuVG8gPyB0d2VlblRvLnR3ZWVuIDogc2NydWJUd2VlbjtcbiAgICB9O1xuXG4gICAgc2VsZi5zZXRQb3NpdGlvbnMgPSBmdW5jdGlvbiAobmV3U3RhcnQsIG5ld0VuZCwga2VlcENsYW1wLCBwaW5PZmZzZXQpIHtcbiAgICAgIC8vIGRvZXNuJ3QgcGVyc2lzdCBhZnRlciByZWZyZXNoKCkhIEludGVuZGVkIHRvIGJlIGEgd2F5IHRvIG92ZXJyaWRlIHZhbHVlcyB0aGF0IHdlcmUgc2V0IGR1cmluZyByZWZyZXNoKCksIGxpa2UgeW91IGNvdWxkIHNldCBpdCBpbiBvblJlZnJlc2goKVxuICAgICAgaWYgKGNvbnRhaW5lckFuaW1hdGlvbikge1xuICAgICAgICAvLyBjb252ZXJ0IHJhdGlvcyBpbnRvIHNjcm9sbCBwb3NpdGlvbnMuIFJlbWVtYmVyLCBzdGFydC9lbmQgdmFsdWVzIG9uIFNjcm9sbFRyaWdnZXJzIHRoYXQgaGF2ZSBhIGNvbnRhaW5lckFuaW1hdGlvbiByZWZlciB0byB0aGUgdGltZSAoaW4gc2Vjb25kcyksIE5PVCBzY3JvbGwgcG9zaXRpb25zLlxuICAgICAgICB2YXIgc3QgPSBjb250YWluZXJBbmltYXRpb24uc2Nyb2xsVHJpZ2dlcixcbiAgICAgICAgICAgIGR1cmF0aW9uID0gY29udGFpbmVyQW5pbWF0aW9uLmR1cmF0aW9uKCksXG4gICAgICAgICAgICBfY2hhbmdlID0gc3QuZW5kIC0gc3Quc3RhcnQ7XG5cbiAgICAgICAgbmV3U3RhcnQgPSBzdC5zdGFydCArIF9jaGFuZ2UgKiBuZXdTdGFydCAvIGR1cmF0aW9uO1xuICAgICAgICBuZXdFbmQgPSBzdC5zdGFydCArIF9jaGFuZ2UgKiBuZXdFbmQgLyBkdXJhdGlvbjtcbiAgICAgIH1cblxuICAgICAgc2VsZi5yZWZyZXNoKGZhbHNlLCBmYWxzZSwge1xuICAgICAgICBzdGFydDogX2tlZXBDbGFtcChuZXdTdGFydCwga2VlcENsYW1wICYmICEhc2VsZi5fc3RhcnRDbGFtcCksXG4gICAgICAgIGVuZDogX2tlZXBDbGFtcChuZXdFbmQsIGtlZXBDbGFtcCAmJiAhIXNlbGYuX2VuZENsYW1wKVxuICAgICAgfSwgcGluT2Zmc2V0KTtcbiAgICAgIHNlbGYudXBkYXRlKCk7XG4gICAgfTtcblxuICAgIHNlbGYuYWRqdXN0UGluU3BhY2luZyA9IGZ1bmN0aW9uIChhbW91bnQpIHtcbiAgICAgIGlmIChzcGFjZXJTdGF0ZSAmJiBhbW91bnQpIHtcbiAgICAgICAgdmFyIGkgPSBzcGFjZXJTdGF0ZS5pbmRleE9mKGRpcmVjdGlvbi5kKSArIDE7XG4gICAgICAgIHNwYWNlclN0YXRlW2ldID0gcGFyc2VGbG9hdChzcGFjZXJTdGF0ZVtpXSkgKyBhbW91bnQgKyBfcHg7XG4gICAgICAgIHNwYWNlclN0YXRlWzFdID0gcGFyc2VGbG9hdChzcGFjZXJTdGF0ZVsxXSkgKyBhbW91bnQgKyBfcHg7XG5cbiAgICAgICAgX3NldFN0YXRlKHNwYWNlclN0YXRlKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgc2VsZi5kaXNhYmxlID0gZnVuY3Rpb24gKHJlc2V0LCBhbGxvd0FuaW1hdGlvbikge1xuICAgICAgcmVzZXQgIT09IGZhbHNlICYmIHNlbGYucmV2ZXJ0KHRydWUsIHRydWUpO1xuXG4gICAgICBpZiAoc2VsZi5lbmFibGVkKSB7XG4gICAgICAgIHNlbGYuZW5hYmxlZCA9IHNlbGYuaXNBY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgYWxsb3dBbmltYXRpb24gfHwgc2NydWJUd2VlbiAmJiBzY3J1YlR3ZWVuLnBhdXNlKCk7XG4gICAgICAgIHByZXZTY3JvbGwgPSAwO1xuICAgICAgICBwaW5DYWNoZSAmJiAocGluQ2FjaGUudW5jYWNoZSA9IDEpO1xuICAgICAgICBvblJlZnJlc2hJbml0ICYmIF9yZW1vdmVMaXN0ZW5lcihTY3JvbGxUcmlnZ2VyLCBcInJlZnJlc2hJbml0XCIsIG9uUmVmcmVzaEluaXQpO1xuXG4gICAgICAgIGlmIChzbmFwRGVsYXllZENhbGwpIHtcbiAgICAgICAgICBzbmFwRGVsYXllZENhbGwucGF1c2UoKTtcbiAgICAgICAgICB0d2VlblRvLnR3ZWVuICYmIHR3ZWVuVG8udHdlZW4ua2lsbCgpICYmICh0d2VlblRvLnR3ZWVuID0gMCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIWlzVmlld3BvcnQpIHtcbiAgICAgICAgICB2YXIgaSA9IF90cmlnZ2Vycy5sZW5ndGg7XG5cbiAgICAgICAgICB3aGlsZSAoaS0tKSB7XG4gICAgICAgICAgICBpZiAoX3RyaWdnZXJzW2ldLnNjcm9sbGVyID09PSBzY3JvbGxlciAmJiBfdHJpZ2dlcnNbaV0gIT09IHNlbGYpIHtcbiAgICAgICAgICAgICAgcmV0dXJuOyAvL2Rvbid0IHJlbW92ZSB0aGUgbGlzdGVuZXJzIGlmIHRoZXJlIGFyZSBzdGlsbCBvdGhlciB0cmlnZ2VycyByZWZlcmVuY2luZyBpdC5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBfcmVtb3ZlTGlzdGVuZXIoc2Nyb2xsZXIsIFwicmVzaXplXCIsIF9vblJlc2l6ZSk7XG5cbiAgICAgICAgICBpc1ZpZXdwb3J0IHx8IF9yZW1vdmVMaXN0ZW5lcihzY3JvbGxlciwgXCJzY3JvbGxcIiwgX29uU2Nyb2xsKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG5cbiAgICBzZWxmLmtpbGwgPSBmdW5jdGlvbiAocmV2ZXJ0LCBhbGxvd0FuaW1hdGlvbikge1xuICAgICAgc2VsZi5kaXNhYmxlKHJldmVydCwgYWxsb3dBbmltYXRpb24pO1xuICAgICAgc2NydWJUd2VlbiAmJiAhYWxsb3dBbmltYXRpb24gJiYgc2NydWJUd2Vlbi5raWxsKCk7XG4gICAgICBpZCAmJiBkZWxldGUgX2lkc1tpZF07XG5cbiAgICAgIHZhciBpID0gX3RyaWdnZXJzLmluZGV4T2Yoc2VsZik7XG5cbiAgICAgIGkgPj0gMCAmJiBfdHJpZ2dlcnMuc3BsaWNlKGksIDEpO1xuICAgICAgaSA9PT0gX2kgJiYgX2RpcmVjdGlvbiA+IDAgJiYgX2ktLTsgLy8gaWYgd2UncmUgaW4gdGhlIG1pZGRsZSBvZiBhIHJlZnJlc2goKSBvciB1cGRhdGUoKSwgc3BsaWNpbmcgd291bGQgY2F1c2Ugc2tpcHMgaW4gdGhlIGluZGV4LCBzbyBhZGp1c3QuLi5cbiAgICAgIC8vIGlmIG5vIG90aGVyIFNjcm9sbFRyaWdnZXIgaW5zdGFuY2VzIG9mIHRoZSBzYW1lIHNjcm9sbGVyIGFyZSBmb3VuZCwgd2lwZSBvdXQgYW55IHJlY29yZGVkIHNjcm9sbCBwb3NpdGlvbi4gT3RoZXJ3aXNlLCBpbiBhIHNpbmdsZSBwYWdlIGFwcGxpY2F0aW9uLCBmb3IgZXhhbXBsZSwgaXQgY291bGQgbWFpbnRhaW4gc2Nyb2xsIHBvc2l0aW9uIHdoZW4gaXQgcmVhbGx5IHNob3VsZG4ndC5cblxuICAgICAgaSA9IDA7XG5cbiAgICAgIF90cmlnZ2Vycy5mb3JFYWNoKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgIHJldHVybiB0LnNjcm9sbGVyID09PSBzZWxmLnNjcm9sbGVyICYmIChpID0gMSk7XG4gICAgICB9KTtcblxuICAgICAgaSB8fCBfcmVmcmVzaGluZ0FsbCB8fCAoc2VsZi5zY3JvbGwucmVjID0gMCk7XG5cbiAgICAgIGlmIChhbmltYXRpb24pIHtcbiAgICAgICAgYW5pbWF0aW9uLnNjcm9sbFRyaWdnZXIgPSBudWxsO1xuICAgICAgICByZXZlcnQgJiYgYW5pbWF0aW9uLnJldmVydCh7XG4gICAgICAgICAga2lsbDogZmFsc2VcbiAgICAgICAgfSk7XG4gICAgICAgIGFsbG93QW5pbWF0aW9uIHx8IGFuaW1hdGlvbi5raWxsKCk7XG4gICAgICB9XG5cbiAgICAgIG1hcmtlclN0YXJ0ICYmIFttYXJrZXJTdGFydCwgbWFya2VyRW5kLCBtYXJrZXJTdGFydFRyaWdnZXIsIG1hcmtlckVuZFRyaWdnZXJdLmZvckVhY2goZnVuY3Rpb24gKG0pIHtcbiAgICAgICAgcmV0dXJuIG0ucGFyZW50Tm9kZSAmJiBtLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQobSk7XG4gICAgICB9KTtcbiAgICAgIF9wcmltYXJ5ID09PSBzZWxmICYmIChfcHJpbWFyeSA9IDApO1xuXG4gICAgICBpZiAocGluKSB7XG4gICAgICAgIHBpbkNhY2hlICYmIChwaW5DYWNoZS51bmNhY2hlID0gMSk7XG4gICAgICAgIGkgPSAwO1xuXG4gICAgICAgIF90cmlnZ2Vycy5mb3JFYWNoKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgICAgcmV0dXJuIHQucGluID09PSBwaW4gJiYgaSsrO1xuICAgICAgICB9KTtcblxuICAgICAgICBpIHx8IChwaW5DYWNoZS5zcGFjZXIgPSAwKTsgLy8gaWYgdGhlcmUgYXJlbid0IGFueSBtb3JlIFNjcm9sbFRyaWdnZXJzIHdpdGggdGhlIHNhbWUgcGluLCByZW1vdmUgdGhlIHNwYWNlciwgb3RoZXJ3aXNlIGl0IGNvdWxkIGJlIGNvbnRhbWluYXRlZCB3aXRoIG9sZC9zdGFsZSB2YWx1ZXMgaWYgdGhlIHVzZXIgcmUtY3JlYXRlcyBhIFNjcm9sbFRyaWdnZXIgZm9yIHRoZSBzYW1lIGVsZW1lbnQuXG4gICAgICB9XG5cbiAgICAgIHZhcnMub25LaWxsICYmIHZhcnMub25LaWxsKHNlbGYpO1xuICAgIH07XG5cbiAgICBfdHJpZ2dlcnMucHVzaChzZWxmKTtcblxuICAgIHNlbGYuZW5hYmxlKGZhbHNlLCBmYWxzZSk7XG4gICAgY3VzdG9tUmV2ZXJ0UmV0dXJuICYmIGN1c3RvbVJldmVydFJldHVybihzZWxmKTtcblxuICAgIGlmIChhbmltYXRpb24gJiYgYW5pbWF0aW9uLmFkZCAmJiAhY2hhbmdlKSB7XG4gICAgICAvLyBpZiB0aGUgYW5pbWF0aW9uIGlzIGEgdGltZWxpbmUsIGl0IG1heSBub3QgaGF2ZSBiZWVuIHBvcHVsYXRlZCB5ZXQsIHNvIGl0IHdvdWxkbid0IHJlbmRlciBhdCB0aGUgcHJvcGVyIHBsYWNlIG9uIHRoZSBmaXJzdCByZWZyZXNoKCksIHRodXMgd2Ugc2hvdWxkIHNjaGVkdWxlIG9uZSBmb3IgdGhlIG5leHQgdGljay4gSWYgXCJjaGFuZ2VcIiBpcyBkZWZpbmVkLCB3ZSBrbm93IGl0IG11c3QgYmUgcmUtZW5hYmxpbmcsIHRodXMgd2UgY2FuIHJlZnJlc2goKSByaWdodCBhd2F5LlxuICAgICAgdmFyIHVwZGF0ZUZ1bmMgPSBzZWxmLnVwZGF0ZTsgLy8gc29tZSBicm93c2VycyBtYXkgZmlyZSBhIHNjcm9sbCBldmVudCBCRUZPUkUgYSB0aWNrIGVsYXBzZXMgYW5kL29yIHRoZSBET01Db250ZW50TG9hZGVkIGZpcmVzLiBTbyB0aGVyZSdzIGEgY2hhbmNlIHVwZGF0ZSgpIHdpbGwgYmUgY2FsbGVkIEJFRk9SRSBhIHJlZnJlc2goKSBoYXMgaGFwcGVuZWQgb24gYSBUaW1lbGluZS1hdHRhY2hlZCBTY3JvbGxUcmlnZ2VyIHdoaWNoIG1lYW5zIHRoZSBzdGFydC9lbmQgd29uJ3QgYmUgY2FsY3VsYXRlZCB5ZXQuIFdlIGRvbid0IHdhbnQgdG8gYWRkIGNvbmRpdGlvbmFsIGxvZ2ljIGluc2lkZSB0aGUgdXBkYXRlKCkgbWV0aG9kIChsaWtlIGNoZWNrIHRvIHNlZSBpZiBlbmQgaXMgZGVmaW5lZCBhbmQgaWYgbm90LCBmb3JjZSBhIHJlZnJlc2goKSkgYmVjYXVzZSB0aGF0J3MgYSBmdW5jdGlvbiB0aGF0IGdldHMgaGl0IGEgTE9UIChwZXJmb3JtYW5jZSkuIFNvIHdlIHN3YXAgb3V0IHRoZSByZWFsIHVwZGF0ZSgpIG1ldGhvZCBmb3IgdGhpcyBvbmUgdGhhdCdsbCByZS1hdHRhY2ggaXQgdGhlIGZpcnN0IHRpbWUgaXQgZ2V0cyBjYWxsZWQgYW5kIG9mIGNvdXJzZSBmb3JjZXMgYSByZWZyZXNoKCkuXG5cbiAgICAgIHNlbGYudXBkYXRlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBzZWxmLnVwZGF0ZSA9IHVwZGF0ZUZ1bmM7XG4gICAgICAgIF9zY3JvbGxlcnMuY2FjaGUrKzsgLy8gb3RoZXJ3aXNlIGEgY2FjaGVkIHNjcm9sbCBwb3NpdGlvbiBtYXkgZ2V0IHVzZWQgaW4gdGhlIHJlZnJlc2goKSBpbiBhIHZlcnkgcmFyZSBzY2VuYXJpbywgbGlrZSBpZiBTY3JvbGxUcmlnZ2VycyBhcmUgY3JlYXRlZCBpbnNpZGUgYSBET01Db250ZW50TG9hZGVkIGV2ZW50IGFuZCB0aGUgcXVldWVkIHJlcXVlc3RBbmltYXRpb25GcmFtZSgpIGZpcmVzIGJlZm9yZWhhbmQuIFNlZSBodHRwczovL2dzYXAuY29tL2NvbW11bml0eS9mb3J1bXMvdG9waWMvNDEyNjctc2Nyb2xsdHJpZ2dlci1icmVha3Mtb24tcmVmcmVzaC13aGVuLXVzaW5nLWRvbWNvbnRlbnRsb2FkZWQvXG5cbiAgICAgICAgc3RhcnQgfHwgZW5kIHx8IHNlbGYucmVmcmVzaCgpO1xuICAgICAgfTtcblxuICAgICAgZ3NhcC5kZWxheWVkQ2FsbCgwLjAxLCBzZWxmLnVwZGF0ZSk7XG4gICAgICBjaGFuZ2UgPSAwLjAxO1xuICAgICAgc3RhcnQgPSBlbmQgPSAwO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZWxmLnJlZnJlc2goKTtcbiAgICB9XG5cbiAgICBwaW4gJiYgX3F1ZXVlUmVmcmVzaEFsbCgpOyAvLyBwaW5uaW5nIGNvdWxkIGFmZmVjdCB0aGUgcG9zaXRpb25zIG9mIG90aGVyIHRoaW5ncywgc28gbWFrZSBzdXJlIHdlIHF1ZXVlIGEgZnVsbCByZWZyZXNoKClcbiAgfTtcblxuICBTY3JvbGxUcmlnZ2VyLnJlZ2lzdGVyID0gZnVuY3Rpb24gcmVnaXN0ZXIoY29yZSkge1xuICAgIGlmICghX2NvcmVJbml0dGVkKSB7XG4gICAgICBnc2FwID0gY29yZSB8fCBfZ2V0R1NBUCgpO1xuICAgICAgX3dpbmRvd0V4aXN0cygpICYmIHdpbmRvdy5kb2N1bWVudCAmJiBTY3JvbGxUcmlnZ2VyLmVuYWJsZSgpO1xuICAgICAgX2NvcmVJbml0dGVkID0gX2VuYWJsZWQ7XG4gICAgfVxuXG4gICAgcmV0dXJuIF9jb3JlSW5pdHRlZDtcbiAgfTtcblxuICBTY3JvbGxUcmlnZ2VyLmRlZmF1bHRzID0gZnVuY3Rpb24gZGVmYXVsdHMoY29uZmlnKSB7XG4gICAgaWYgKGNvbmZpZykge1xuICAgICAgZm9yICh2YXIgcCBpbiBjb25maWcpIHtcbiAgICAgICAgX2RlZmF1bHRzW3BdID0gY29uZmlnW3BdO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBfZGVmYXVsdHM7XG4gIH07XG5cbiAgU2Nyb2xsVHJpZ2dlci5kaXNhYmxlID0gZnVuY3Rpb24gZGlzYWJsZShyZXNldCwga2lsbCkge1xuICAgIF9lbmFibGVkID0gMDtcblxuICAgIF90cmlnZ2Vycy5mb3JFYWNoKGZ1bmN0aW9uICh0cmlnZ2VyKSB7XG4gICAgICByZXR1cm4gdHJpZ2dlcltraWxsID8gXCJraWxsXCIgOiBcImRpc2FibGVcIl0ocmVzZXQpO1xuICAgIH0pO1xuXG4gICAgX3JlbW92ZUxpc3RlbmVyKF93aW4sIFwid2hlZWxcIiwgX29uU2Nyb2xsKTtcblxuICAgIF9yZW1vdmVMaXN0ZW5lcihfZG9jLCBcInNjcm9sbFwiLCBfb25TY3JvbGwpO1xuXG4gICAgY2xlYXJJbnRlcnZhbChfc3luY0ludGVydmFsKTtcblxuICAgIF9yZW1vdmVMaXN0ZW5lcihfZG9jLCBcInRvdWNoY2FuY2VsXCIsIF9wYXNzVGhyb3VnaCk7XG5cbiAgICBfcmVtb3ZlTGlzdGVuZXIoX2JvZHksIFwidG91Y2hzdGFydFwiLCBfcGFzc1Rocm91Z2gpO1xuXG4gICAgX211bHRpTGlzdGVuZXIoX3JlbW92ZUxpc3RlbmVyLCBfZG9jLCBcInBvaW50ZXJkb3duLHRvdWNoc3RhcnQsbW91c2Vkb3duXCIsIF9wb2ludGVyRG93bkhhbmRsZXIpO1xuXG4gICAgX211bHRpTGlzdGVuZXIoX3JlbW92ZUxpc3RlbmVyLCBfZG9jLCBcInBvaW50ZXJ1cCx0b3VjaGVuZCxtb3VzZXVwXCIsIF9wb2ludGVyVXBIYW5kbGVyKTtcblxuICAgIF9yZXNpemVEZWxheS5raWxsKCk7XG5cbiAgICBfaXRlcmF0ZUF1dG9SZWZyZXNoKF9yZW1vdmVMaXN0ZW5lcik7XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IF9zY3JvbGxlcnMubGVuZ3RoOyBpICs9IDMpIHtcbiAgICAgIF93aGVlbExpc3RlbmVyKF9yZW1vdmVMaXN0ZW5lciwgX3Njcm9sbGVyc1tpXSwgX3Njcm9sbGVyc1tpICsgMV0pO1xuXG4gICAgICBfd2hlZWxMaXN0ZW5lcihfcmVtb3ZlTGlzdGVuZXIsIF9zY3JvbGxlcnNbaV0sIF9zY3JvbGxlcnNbaSArIDJdKTtcbiAgICB9XG4gIH07XG5cbiAgU2Nyb2xsVHJpZ2dlci5lbmFibGUgPSBmdW5jdGlvbiBlbmFibGUoKSB7XG4gICAgX3dpbiA9IHdpbmRvdztcbiAgICBfZG9jID0gZG9jdW1lbnQ7XG4gICAgX2RvY0VsID0gX2RvYy5kb2N1bWVudEVsZW1lbnQ7XG4gICAgX2JvZHkgPSBfZG9jLmJvZHk7XG5cbiAgICBpZiAoZ3NhcCkge1xuICAgICAgX3RvQXJyYXkgPSBnc2FwLnV0aWxzLnRvQXJyYXk7XG4gICAgICBfY2xhbXAgPSBnc2FwLnV0aWxzLmNsYW1wO1xuICAgICAgX2NvbnRleHQgPSBnc2FwLmNvcmUuY29udGV4dCB8fCBfcGFzc1Rocm91Z2g7XG4gICAgICBfc3VwcHJlc3NPdmVyd3JpdGVzID0gZ3NhcC5jb3JlLnN1cHByZXNzT3ZlcndyaXRlcyB8fCBfcGFzc1Rocm91Z2g7XG4gICAgICBfc2Nyb2xsUmVzdG9yYXRpb24gPSBfd2luLmhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gfHwgXCJhdXRvXCI7XG4gICAgICBfbGFzdFNjcm9sbCA9IF93aW4ucGFnZVlPZmZzZXQgfHwgMDtcbiAgICAgIGdzYXAuY29yZS5nbG9iYWxzKFwiU2Nyb2xsVHJpZ2dlclwiLCBTY3JvbGxUcmlnZ2VyKTsgLy8gbXVzdCByZWdpc3RlciB0aGUgZ2xvYmFsIG1hbnVhbGx5IGJlY2F1c2UgaW4gSW50ZXJuZXQgRXhwbG9yZXIsIGZ1bmN0aW9ucyAoY2xhc3NlcykgZG9uJ3QgaGF2ZSBhIFwibmFtZVwiIHByb3BlcnR5LlxuXG4gICAgICBpZiAoX2JvZHkpIHtcbiAgICAgICAgX2VuYWJsZWQgPSAxO1xuICAgICAgICBfZGl2MTAwdmggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpOyAvLyB0byBzb2x2ZSBtb2JpbGUgYnJvd3NlciBhZGRyZXNzIGJhciBzaG93L2hpZGUgcmVzaXppbmcsIHdlIHNob3VsZG4ndCByZWx5IG9uIHdpbmRvdy5pbm5lckhlaWdodC4gSW5zdGVhZCwgdXNlIGEgPGRpdj4gd2l0aCBpdHMgaGVpZ2h0IHNldCB0byAxMDB2aCBhbmQgbWVhc3VyZSB0aGF0IHNpbmNlIHRoYXQncyB3aGF0IHRoZSBzY3JvbGxpbmcgaXMgYmFzZWQgb24gYW55d2F5IGFuZCBpdCdzIG5vdCBhZmZlY3RlZCBieSBhZGRyZXNzIGJhciBzaG93aW5nL2hpZGluZy5cblxuICAgICAgICBfZGl2MTAwdmguc3R5bGUuaGVpZ2h0ID0gXCIxMDB2aFwiO1xuICAgICAgICBfZGl2MTAwdmguc3R5bGUucG9zaXRpb24gPSBcImFic29sdXRlXCI7XG5cbiAgICAgICAgX3JlZnJlc2gxMDB2aCgpO1xuXG4gICAgICAgIF9yYWZCdWdGaXgoKTtcblxuICAgICAgICBPYnNlcnZlci5yZWdpc3Rlcihnc2FwKTsgLy8gaXNUb3VjaCBpcyAwIGlmIG5vIHRvdWNoLCAxIGlmIE9OTFkgdG91Y2gsIGFuZCAyIGlmIGl0IGNhbiBhY2NvbW1vZGF0ZSB0b3VjaCBidXQgYWxzbyBvdGhlciB0eXBlcyBsaWtlIG1vdXNlL3BvaW50ZXIuXG5cbiAgICAgICAgU2Nyb2xsVHJpZ2dlci5pc1RvdWNoID0gT2JzZXJ2ZXIuaXNUb3VjaDtcbiAgICAgICAgX2ZpeElPU0J1ZyA9IE9ic2VydmVyLmlzVG91Y2ggJiYgLyhpUGFkfGlQaG9uZXxpUG9kfE1hYykvZy50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpOyAvLyBzaW5jZSAyMDE3LCBpT1MgaGFzIGhhZCBhIGJ1ZyB0aGF0IGNhdXNlcyBldmVudC5jbGllbnRYL1kgdG8gYmUgaW5hY2N1cmF0ZSB3aGVuIGEgc2Nyb2xsIG9jY3VycywgdGh1cyB3ZSBtdXN0IGFsdGVybmF0ZSBpZ25vcmluZyBldmVyeSBvdGhlciB0b3VjaG1vdmUgZXZlbnQgdG8gd29yayBhcm91bmQgaXQuIFNlZSBodHRwczovL2J1Z3Mud2Via2l0Lm9yZy9zaG93X2J1Zy5jZ2k/aWQ9MTgxOTU0IGFuZCBodHRwczovL2NvZGVwZW4uaW8vR3JlZW5Tb2NrL3Blbi9FeGJyUE5hLzA4N2NlZjE5N2RjMzU0NDVhMDk1MWU4OTM1YzQxNTAzXG5cbiAgICAgICAgX2lnbm9yZU1vYmlsZVJlc2l6ZSA9IE9ic2VydmVyLmlzVG91Y2ggPT09IDE7XG5cbiAgICAgICAgX2FkZExpc3RlbmVyKF93aW4sIFwid2hlZWxcIiwgX29uU2Nyb2xsKTsgLy8gbW9zdGx5IGZvciAzcmQgcGFydHkgc21vb3RoIHNjcm9sbGluZyBsaWJyYXJpZXMuXG5cblxuICAgICAgICBfcm9vdCA9IFtfd2luLCBfZG9jLCBfZG9jRWwsIF9ib2R5XTtcblxuICAgICAgICBpZiAoZ3NhcC5tYXRjaE1lZGlhKSB7XG4gICAgICAgICAgU2Nyb2xsVHJpZ2dlci5tYXRjaE1lZGlhID0gZnVuY3Rpb24gKHZhcnMpIHtcbiAgICAgICAgICAgIHZhciBtbSA9IGdzYXAubWF0Y2hNZWRpYSgpLFxuICAgICAgICAgICAgICAgIHA7XG5cbiAgICAgICAgICAgIGZvciAocCBpbiB2YXJzKSB7XG4gICAgICAgICAgICAgIG1tLmFkZChwLCB2YXJzW3BdKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIG1tO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICBnc2FwLmFkZEV2ZW50TGlzdGVuZXIoXCJtYXRjaE1lZGlhSW5pdFwiLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBfcmVjb3JkU2Nyb2xsUG9zaXRpb25zKCk7XG5cbiAgICAgICAgICAgIF9yZXZlcnRBbGwoKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBnc2FwLmFkZEV2ZW50TGlzdGVuZXIoXCJtYXRjaE1lZGlhUmV2ZXJ0XCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBfcmV2ZXJ0UmVjb3JkZWQoKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBnc2FwLmFkZEV2ZW50TGlzdGVuZXIoXCJtYXRjaE1lZGlhXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIF9yZWZyZXNoQWxsKDAsIDEpO1xuXG4gICAgICAgICAgICBfZGlzcGF0Y2goXCJtYXRjaE1lZGlhXCIpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGdzYXAubWF0Y2hNZWRpYSgpLmFkZChcIihvcmllbnRhdGlvbjogcG9ydHJhaXQpXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIC8vIHdoZW4gb3JpZW50YXRpb24gY2hhbmdlcywgd2Ugc2hvdWxkIHRha2UgbmV3IGJhc2UgbWVhc3VyZW1lbnRzIGZvciB0aGUgaWdub3JlTW9iaWxlUmVzaXplIGZlYXR1cmUuXG4gICAgICAgICAgICBfc2V0QmFzZURpbWVuc2lvbnMoKTtcblxuICAgICAgICAgICAgcmV0dXJuIF9zZXRCYXNlRGltZW5zaW9ucztcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLndhcm4oXCJSZXF1aXJlcyBHU0FQIDMuMTEuMCBvciBsYXRlclwiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIF9zZXRCYXNlRGltZW5zaW9ucygpO1xuXG4gICAgICAgIF9hZGRMaXN0ZW5lcihfZG9jLCBcInNjcm9sbFwiLCBfb25TY3JvbGwpOyAvLyBzb21lIGJyb3dzZXJzIChsaWtlIENocm9tZSksIHRoZSB3aW5kb3cgc3RvcHMgZGlzcGF0Y2hpbmcgc2Nyb2xsIGV2ZW50cyBvbiB0aGUgd2luZG93IGlmIHlvdSBzY3JvbGwgcmVhbGx5IGZhc3QsIGJ1dCBpdCdzIGNvbnNpc3RlbnQgb24gdGhlIGRvY3VtZW50IVxuXG5cbiAgICAgICAgdmFyIGJvZHlIYXNTdHlsZSA9IF9ib2R5Lmhhc0F0dHJpYnV0ZShcInN0eWxlXCIpLFxuICAgICAgICAgICAgYm9keVN0eWxlID0gX2JvZHkuc3R5bGUsXG4gICAgICAgICAgICBib3JkZXIgPSBib2R5U3R5bGUuYm9yZGVyVG9wU3R5bGUsXG4gICAgICAgICAgICBBbmltYXRpb25Qcm90byA9IGdzYXAuY29yZS5BbmltYXRpb24ucHJvdG90eXBlLFxuICAgICAgICAgICAgYm91bmRzLFxuICAgICAgICAgICAgaTtcblxuICAgICAgICBBbmltYXRpb25Qcm90by5yZXZlcnQgfHwgT2JqZWN0LmRlZmluZVByb3BlcnR5KEFuaW1hdGlvblByb3RvLCBcInJldmVydFwiLCB7XG4gICAgICAgICAgdmFsdWU6IGZ1bmN0aW9uIHZhbHVlKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMudGltZSgtMC4wMSwgdHJ1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTsgLy8gb25seSBmb3IgYmFja3dhcmRzIGNvbXBhdGliaWxpdHkgKEFuaW1hdGlvbi5yZXZlcnQoKSB3YXMgYWRkZWQgYWZ0ZXIgMy4xMC40KVxuXG4gICAgICAgIGJvZHlTdHlsZS5ib3JkZXJUb3BTdHlsZSA9IFwic29saWRcIjsgLy8gd29ya3MgYXJvdW5kIGFuIGlzc3VlIHdoZXJlIGEgbWFyZ2luIG9mIGEgY2hpbGQgZWxlbWVudCBjb3VsZCB0aHJvdyBvZmYgdGhlIGJvdW5kcyBvZiB0aGUgX2JvZHksIG1ha2luZyBpdCBzZWVtIGxpa2UgdGhlcmUncyBhIG1hcmdpbiB3aGVuIHRoZXJlIGFjdHVhbGx5IGlzbid0LiBUaGUgYm9yZGVyIGVuc3VyZXMgdGhhdCB0aGUgYm91bmRzIGFyZSBhY2N1cmF0ZS5cblxuICAgICAgICBib3VuZHMgPSBfZ2V0Qm91bmRzKF9ib2R5KTtcbiAgICAgICAgX3ZlcnRpY2FsLm0gPSBNYXRoLnJvdW5kKGJvdW5kcy50b3AgKyBfdmVydGljYWwuc2MoKSkgfHwgMDsgLy8gYWNjb21tb2RhdGUgdGhlIG9mZnNldCBvZiB0aGUgPGJvZHk+IGNhdXNlZCBieSBtYXJnaW5zIGFuZC9vciBwYWRkaW5nXG5cbiAgICAgICAgX2hvcml6b250YWwubSA9IE1hdGgucm91bmQoYm91bmRzLmxlZnQgKyBfaG9yaXpvbnRhbC5zYygpKSB8fCAwO1xuICAgICAgICBib3JkZXIgPyBib2R5U3R5bGUuYm9yZGVyVG9wU3R5bGUgPSBib3JkZXIgOiBib2R5U3R5bGUucmVtb3ZlUHJvcGVydHkoXCJib3JkZXItdG9wLXN0eWxlXCIpO1xuXG4gICAgICAgIGlmICghYm9keUhhc1N0eWxlKSB7XG4gICAgICAgICAgLy8gU1NSIGZyYW1ld29ya3MgbGlrZSBOZXh0LmpzIGNvbXBsYWluIGlmIHRoaXMgYXR0cmlidXRlIGdldHMgYWRkZWQuXG4gICAgICAgICAgX2JvZHkuc2V0QXR0cmlidXRlKFwic3R5bGVcIiwgXCJcIik7IC8vIGl0J3Mgbm90IGVub3VnaCB0byBqdXN0IHJlbW92ZUF0dHJpYnV0ZSgpIC0gd2UgbXVzdCBmaXJzdCBzZXQgaXQgdG8gZW1wdHksIG90aGVyd2lzZSBOZXh0LmpzIGNvbXBsYWlucy5cblxuXG4gICAgICAgICAgX2JvZHkucmVtb3ZlQXR0cmlidXRlKFwic3R5bGVcIik7XG4gICAgICAgIH0gLy8gVE9ETzogKD8pIG1heWJlIG1vdmUgdG8gbGV2ZXJhZ2luZyB0aGUgdmVsb2NpdHkgbWVjaGFuaXNtIGluIE9ic2VydmVyIGFuZCBza2lwIGludGVydmFscy5cblxuXG4gICAgICAgIF9zeW5jSW50ZXJ2YWwgPSBzZXRJbnRlcnZhbChfc3luYywgMjUwKTtcbiAgICAgICAgZ3NhcC5kZWxheWVkQ2FsbCgwLjUsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZXR1cm4gX3N0YXJ0dXAgPSAwO1xuICAgICAgICB9KTtcblxuICAgICAgICBfYWRkTGlzdGVuZXIoX2RvYywgXCJ0b3VjaGNhbmNlbFwiLCBfcGFzc1Rocm91Z2gpOyAvLyBzb21lIG9sZGVyIEFuZHJvaWQgZGV2aWNlcyBpbnRlcm1pdHRlbnRseSBzdG9wIGRpc3BhdGNoaW5nIFwidG91Y2htb3ZlXCIgZXZlbnRzIGlmIHdlIGRvbid0IGxpc3RlbiBmb3IgXCJ0b3VjaGNhbmNlbFwiIG9uIHRoZSBkb2N1bWVudC5cblxuXG4gICAgICAgIF9hZGRMaXN0ZW5lcihfYm9keSwgXCJ0b3VjaHN0YXJ0XCIsIF9wYXNzVGhyb3VnaCk7IC8vd29ya3MgYXJvdW5kIFNhZmFyaSBidWc6IGh0dHBzOi8vZ3NhcC5jb20vZm9ydW1zL3RvcGljLzIxNDUwLWRyYWdnYWJsZS1pbi1pZnJhbWUtb24tbW9iaWxlLWlzLWJ1Z2d5L1xuXG5cbiAgICAgICAgX211bHRpTGlzdGVuZXIoX2FkZExpc3RlbmVyLCBfZG9jLCBcInBvaW50ZXJkb3duLHRvdWNoc3RhcnQsbW91c2Vkb3duXCIsIF9wb2ludGVyRG93bkhhbmRsZXIpO1xuXG4gICAgICAgIF9tdWx0aUxpc3RlbmVyKF9hZGRMaXN0ZW5lciwgX2RvYywgXCJwb2ludGVydXAsdG91Y2hlbmQsbW91c2V1cFwiLCBfcG9pbnRlclVwSGFuZGxlcik7XG5cbiAgICAgICAgX3RyYW5zZm9ybVByb3AgPSBnc2FwLnV0aWxzLmNoZWNrUHJlZml4KFwidHJhbnNmb3JtXCIpO1xuXG4gICAgICAgIF9zdGF0ZVByb3BzLnB1c2goX3RyYW5zZm9ybVByb3ApO1xuXG4gICAgICAgIF9jb3JlSW5pdHRlZCA9IF9nZXRUaW1lKCk7XG4gICAgICAgIF9yZXNpemVEZWxheSA9IGdzYXAuZGVsYXllZENhbGwoMC4yLCBfcmVmcmVzaEFsbCkucGF1c2UoKTtcbiAgICAgICAgX2F1dG9SZWZyZXNoID0gW19kb2MsIFwidmlzaWJpbGl0eWNoYW5nZVwiLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIHcgPSBfd2luLmlubmVyV2lkdGgsXG4gICAgICAgICAgICAgIGggPSBfd2luLmlubmVySGVpZ2h0O1xuXG4gICAgICAgICAgaWYgKF9kb2MuaGlkZGVuKSB7XG4gICAgICAgICAgICBfcHJldldpZHRoID0gdztcbiAgICAgICAgICAgIF9wcmV2SGVpZ2h0ID0gaDtcbiAgICAgICAgICB9IGVsc2UgaWYgKF9wcmV2V2lkdGggIT09IHcgfHwgX3ByZXZIZWlnaHQgIT09IGgpIHtcbiAgICAgICAgICAgIF9vblJlc2l6ZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSwgX2RvYywgXCJET01Db250ZW50TG9hZGVkXCIsIF9yZWZyZXNoQWxsLCBfd2luLCBcImxvYWRcIiwgX3JlZnJlc2hBbGwsIF93aW4sIFwicmVzaXplXCIsIF9vblJlc2l6ZV07XG5cbiAgICAgICAgX2l0ZXJhdGVBdXRvUmVmcmVzaChfYWRkTGlzdGVuZXIpO1xuXG4gICAgICAgIF90cmlnZ2Vycy5mb3JFYWNoKGZ1bmN0aW9uICh0cmlnZ2VyKSB7XG4gICAgICAgICAgcmV0dXJuIHRyaWdnZXIuZW5hYmxlKDAsIDEpO1xuICAgICAgICB9KTtcblxuICAgICAgICBmb3IgKGkgPSAwOyBpIDwgX3Njcm9sbGVycy5sZW5ndGg7IGkgKz0gMykge1xuICAgICAgICAgIF93aGVlbExpc3RlbmVyKF9yZW1vdmVMaXN0ZW5lciwgX3Njcm9sbGVyc1tpXSwgX3Njcm9sbGVyc1tpICsgMV0pO1xuXG4gICAgICAgICAgX3doZWVsTGlzdGVuZXIoX3JlbW92ZUxpc3RlbmVyLCBfc2Nyb2xsZXJzW2ldLCBfc2Nyb2xsZXJzW2kgKyAyXSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoX2RvYykge1xuICAgICAgICB2YXIgb25Mb2FkID0gZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICAgIFNjcm9sbFRyaWdnZXIuZW5hYmxlKCk7XG5cbiAgICAgICAgICBfZG9jLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsIG9uTG9hZCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgX2RvYy5hZGRFdmVudExpc3RlbmVyKFwiRE9NQ29udGVudExvYWRlZFwiLCBvbkxvYWQpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICBTY3JvbGxUcmlnZ2VyLmNvbmZpZyA9IGZ1bmN0aW9uIGNvbmZpZyh2YXJzKSB7XG4gICAgXCJsaW1pdENhbGxiYWNrc1wiIGluIHZhcnMgJiYgKF9saW1pdENhbGxiYWNrcyA9ICEhdmFycy5saW1pdENhbGxiYWNrcyk7XG4gICAgdmFyIG1zID0gdmFycy5zeW5jSW50ZXJ2YWw7XG4gICAgbXMgJiYgY2xlYXJJbnRlcnZhbChfc3luY0ludGVydmFsKSB8fCAoX3N5bmNJbnRlcnZhbCA9IG1zKSAmJiBzZXRJbnRlcnZhbChfc3luYywgbXMpO1xuICAgIFwiaWdub3JlTW9iaWxlUmVzaXplXCIgaW4gdmFycyAmJiAoX2lnbm9yZU1vYmlsZVJlc2l6ZSA9IFNjcm9sbFRyaWdnZXIuaXNUb3VjaCA9PT0gMSAmJiB2YXJzLmlnbm9yZU1vYmlsZVJlc2l6ZSk7XG5cbiAgICBpZiAoXCJhdXRvUmVmcmVzaEV2ZW50c1wiIGluIHZhcnMpIHtcbiAgICAgIF9pdGVyYXRlQXV0b1JlZnJlc2goX3JlbW92ZUxpc3RlbmVyKSB8fCBfaXRlcmF0ZUF1dG9SZWZyZXNoKF9hZGRMaXN0ZW5lciwgdmFycy5hdXRvUmVmcmVzaEV2ZW50cyB8fCBcIm5vbmVcIik7XG4gICAgICBfaWdub3JlUmVzaXplID0gKHZhcnMuYXV0b1JlZnJlc2hFdmVudHMgKyBcIlwiKS5pbmRleE9mKFwicmVzaXplXCIpID09PSAtMTtcbiAgICB9XG4gIH07XG5cbiAgU2Nyb2xsVHJpZ2dlci5zY3JvbGxlclByb3h5ID0gZnVuY3Rpb24gc2Nyb2xsZXJQcm94eSh0YXJnZXQsIHZhcnMpIHtcbiAgICB2YXIgdCA9IF9nZXRUYXJnZXQodGFyZ2V0KSxcbiAgICAgICAgaSA9IF9zY3JvbGxlcnMuaW5kZXhPZih0KSxcbiAgICAgICAgaXNWaWV3cG9ydCA9IF9pc1ZpZXdwb3J0KHQpO1xuXG4gICAgaWYgKH5pKSB7XG4gICAgICBfc2Nyb2xsZXJzLnNwbGljZShpLCBpc1ZpZXdwb3J0ID8gNiA6IDIpO1xuICAgIH1cblxuICAgIGlmICh2YXJzKSB7XG4gICAgICBpc1ZpZXdwb3J0ID8gX3Byb3hpZXMudW5zaGlmdChfd2luLCB2YXJzLCBfYm9keSwgdmFycywgX2RvY0VsLCB2YXJzKSA6IF9wcm94aWVzLnVuc2hpZnQodCwgdmFycyk7XG4gICAgfVxuICB9O1xuXG4gIFNjcm9sbFRyaWdnZXIuY2xlYXJNYXRjaE1lZGlhID0gZnVuY3Rpb24gY2xlYXJNYXRjaE1lZGlhKHF1ZXJ5KSB7XG4gICAgX3RyaWdnZXJzLmZvckVhY2goZnVuY3Rpb24gKHQpIHtcbiAgICAgIHJldHVybiB0Ll9jdHggJiYgdC5fY3R4LnF1ZXJ5ID09PSBxdWVyeSAmJiB0Ll9jdHgua2lsbCh0cnVlLCB0cnVlKTtcbiAgICB9KTtcbiAgfTtcblxuICBTY3JvbGxUcmlnZ2VyLmlzSW5WaWV3cG9ydCA9IGZ1bmN0aW9uIGlzSW5WaWV3cG9ydChlbGVtZW50LCByYXRpbywgaG9yaXpvbnRhbCkge1xuICAgIHZhciBib3VuZHMgPSAoX2lzU3RyaW5nKGVsZW1lbnQpID8gX2dldFRhcmdldChlbGVtZW50KSA6IGVsZW1lbnQpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgICBvZmZzZXQgPSBib3VuZHNbaG9yaXpvbnRhbCA/IF93aWR0aCA6IF9oZWlnaHRdICogcmF0aW8gfHwgMDtcbiAgICByZXR1cm4gaG9yaXpvbnRhbCA/IGJvdW5kcy5yaWdodCAtIG9mZnNldCA+IDAgJiYgYm91bmRzLmxlZnQgKyBvZmZzZXQgPCBfd2luLmlubmVyV2lkdGggOiBib3VuZHMuYm90dG9tIC0gb2Zmc2V0ID4gMCAmJiBib3VuZHMudG9wICsgb2Zmc2V0IDwgX3dpbi5pbm5lckhlaWdodDtcbiAgfTtcblxuICBTY3JvbGxUcmlnZ2VyLnBvc2l0aW9uSW5WaWV3cG9ydCA9IGZ1bmN0aW9uIHBvc2l0aW9uSW5WaWV3cG9ydChlbGVtZW50LCByZWZlcmVuY2VQb2ludCwgaG9yaXpvbnRhbCkge1xuICAgIF9pc1N0cmluZyhlbGVtZW50KSAmJiAoZWxlbWVudCA9IF9nZXRUYXJnZXQoZWxlbWVudCkpO1xuICAgIHZhciBib3VuZHMgPSBlbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgICBzaXplID0gYm91bmRzW2hvcml6b250YWwgPyBfd2lkdGggOiBfaGVpZ2h0XSxcbiAgICAgICAgb2Zmc2V0ID0gcmVmZXJlbmNlUG9pbnQgPT0gbnVsbCA/IHNpemUgLyAyIDogcmVmZXJlbmNlUG9pbnQgaW4gX2tleXdvcmRzID8gX2tleXdvcmRzW3JlZmVyZW5jZVBvaW50XSAqIHNpemUgOiB+cmVmZXJlbmNlUG9pbnQuaW5kZXhPZihcIiVcIikgPyBwYXJzZUZsb2F0KHJlZmVyZW5jZVBvaW50KSAqIHNpemUgLyAxMDAgOiBwYXJzZUZsb2F0KHJlZmVyZW5jZVBvaW50KSB8fCAwO1xuICAgIHJldHVybiBob3Jpem9udGFsID8gKGJvdW5kcy5sZWZ0ICsgb2Zmc2V0KSAvIF93aW4uaW5uZXJXaWR0aCA6IChib3VuZHMudG9wICsgb2Zmc2V0KSAvIF93aW4uaW5uZXJIZWlnaHQ7XG4gIH07XG5cbiAgU2Nyb2xsVHJpZ2dlci5raWxsQWxsID0gZnVuY3Rpb24ga2lsbEFsbChhbGxvd0xpc3RlbmVycykge1xuICAgIF90cmlnZ2Vycy5zbGljZSgwKS5mb3JFYWNoKGZ1bmN0aW9uICh0KSB7XG4gICAgICByZXR1cm4gdC52YXJzLmlkICE9PSBcIlNjcm9sbFNtb290aGVyXCIgJiYgdC5raWxsKCk7XG4gICAgfSk7XG5cbiAgICBpZiAoYWxsb3dMaXN0ZW5lcnMgIT09IHRydWUpIHtcbiAgICAgIHZhciBsaXN0ZW5lcnMgPSBfbGlzdGVuZXJzLmtpbGxBbGwgfHwgW107XG4gICAgICBfbGlzdGVuZXJzID0ge307XG4gICAgICBsaXN0ZW5lcnMuZm9yRWFjaChmdW5jdGlvbiAoZikge1xuICAgICAgICByZXR1cm4gZigpO1xuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiBTY3JvbGxUcmlnZ2VyO1xufSgpO1xuU2Nyb2xsVHJpZ2dlci52ZXJzaW9uID0gXCIzLjE1LjBcIjtcblxuU2Nyb2xsVHJpZ2dlci5zYXZlU3R5bGVzID0gZnVuY3Rpb24gKHRhcmdldHMpIHtcbiAgcmV0dXJuIHRhcmdldHMgPyBfdG9BcnJheSh0YXJnZXRzKS5mb3JFYWNoKGZ1bmN0aW9uICh0YXJnZXQpIHtcbiAgICAvLyBzYXZlZCBzdHlsZXMgYXJlIHJlY29yZGVkIGluIGEgY29uc2VjdXRpdmUgYWx0ZXJuYXRpbmcgQXJyYXksIGxpa2UgW2VsZW1lbnQsIGNzc1RleHQsIHRyYW5zZm9ybSBhdHRyaWJ1dGUsIGNhY2hlLCBtYXRjaE1lZGlhLCAuLi5dXG4gICAgaWYgKHRhcmdldCAmJiB0YXJnZXQuc3R5bGUpIHtcbiAgICAgIHZhciBpID0gX3NhdmVkU3R5bGVzLmluZGV4T2YodGFyZ2V0KTtcblxuICAgICAgaSA+PSAwICYmIF9zYXZlZFN0eWxlcy5zcGxpY2UoaSwgNSk7XG5cbiAgICAgIF9zYXZlZFN0eWxlcy5wdXNoKHRhcmdldCwgdGFyZ2V0LnN0eWxlLmNzc1RleHQsIHRhcmdldC5nZXRCQm94ICYmIHRhcmdldC5nZXRBdHRyaWJ1dGUoXCJ0cmFuc2Zvcm1cIiksIGdzYXAuY29yZS5nZXRDYWNoZSh0YXJnZXQpLCBfY29udGV4dCgpKTtcbiAgICB9XG4gIH0pIDogX3NhdmVkU3R5bGVzO1xufTtcblxuU2Nyb2xsVHJpZ2dlci5yZXZlcnQgPSBmdW5jdGlvbiAoc29mdCwgbWVkaWEpIHtcbiAgcmV0dXJuIF9yZXZlcnRBbGwoIXNvZnQsIG1lZGlhKTtcbn07XG5cblNjcm9sbFRyaWdnZXIuY3JlYXRlID0gZnVuY3Rpb24gKHZhcnMsIGFuaW1hdGlvbikge1xuICByZXR1cm4gbmV3IFNjcm9sbFRyaWdnZXIodmFycywgYW5pbWF0aW9uKTtcbn07XG5cblNjcm9sbFRyaWdnZXIucmVmcmVzaCA9IGZ1bmN0aW9uIChzYWZlKSB7XG4gIHJldHVybiBzYWZlID8gX29uUmVzaXplKHRydWUpIDogKF9jb3JlSW5pdHRlZCB8fCBTY3JvbGxUcmlnZ2VyLnJlZ2lzdGVyKCkpICYmIF9yZWZyZXNoQWxsKHRydWUpO1xufTtcblxuU2Nyb2xsVHJpZ2dlci51cGRhdGUgPSBmdW5jdGlvbiAoZm9yY2UpIHtcbiAgcmV0dXJuICsrX3Njcm9sbGVycy5jYWNoZSAmJiBfdXBkYXRlQWxsKGZvcmNlID09PSB0cnVlID8gMiA6IDApO1xufTtcblxuU2Nyb2xsVHJpZ2dlci5jbGVhclNjcm9sbE1lbW9yeSA9IF9jbGVhclNjcm9sbE1lbW9yeTtcblxuU2Nyb2xsVHJpZ2dlci5tYXhTY3JvbGwgPSBmdW5jdGlvbiAoZWxlbWVudCwgaG9yaXpvbnRhbCkge1xuICByZXR1cm4gX21heFNjcm9sbChlbGVtZW50LCBob3Jpem9udGFsID8gX2hvcml6b250YWwgOiBfdmVydGljYWwpO1xufTtcblxuU2Nyb2xsVHJpZ2dlci5nZXRTY3JvbGxGdW5jID0gZnVuY3Rpb24gKGVsZW1lbnQsIGhvcml6b250YWwpIHtcbiAgcmV0dXJuIF9nZXRTY3JvbGxGdW5jKF9nZXRUYXJnZXQoZWxlbWVudCksIGhvcml6b250YWwgPyBfaG9yaXpvbnRhbCA6IF92ZXJ0aWNhbCk7XG59O1xuXG5TY3JvbGxUcmlnZ2VyLmdldEJ5SWQgPSBmdW5jdGlvbiAoaWQpIHtcbiAgcmV0dXJuIF9pZHNbaWRdO1xufTtcblxuU2Nyb2xsVHJpZ2dlci5nZXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBfdHJpZ2dlcnMuZmlsdGVyKGZ1bmN0aW9uICh0KSB7XG4gICAgcmV0dXJuIHQudmFycy5pZCAhPT0gXCJTY3JvbGxTbW9vdGhlclwiO1xuICB9KTtcbn07IC8vIGl0J3MgY29tbW9uIGZvciBwZW9wbGUgdG8gU2Nyb2xsVHJpZ2dlci5nZXRBbGwodCA9PiB0LmtpbGwoKSkgb24gcGFnZSByb3V0ZXMsIGZvciBleGFtcGxlLCBhbmQgd2UgZG9uJ3Qgd2FudCBpdCB0byBydWluIHNtb290aCBzY3JvbGxpbmcgYnkga2lsbGluZyB0aGUgbWFpbiBTY3JvbGxTbW9vdGhlciBvbmUuXG5cblxuU2Nyb2xsVHJpZ2dlci5pc1Njcm9sbGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuICEhX2xhc3RTY3JvbGxUaW1lO1xufTtcblxuU2Nyb2xsVHJpZ2dlci5zbmFwRGlyZWN0aW9uYWwgPSBfc25hcERpcmVjdGlvbmFsO1xuXG5TY3JvbGxUcmlnZ2VyLmFkZEV2ZW50TGlzdGVuZXIgPSBmdW5jdGlvbiAodHlwZSwgY2FsbGJhY2spIHtcbiAgdmFyIGEgPSBfbGlzdGVuZXJzW3R5cGVdIHx8IChfbGlzdGVuZXJzW3R5cGVdID0gW10pO1xuICB+YS5pbmRleE9mKGNhbGxiYWNrKSB8fCBhLnB1c2goY2FsbGJhY2spO1xufTtcblxuU2Nyb2xsVHJpZ2dlci5yZW1vdmVFdmVudExpc3RlbmVyID0gZnVuY3Rpb24gKHR5cGUsIGNhbGxiYWNrKSB7XG4gIHZhciBhID0gX2xpc3RlbmVyc1t0eXBlXSxcbiAgICAgIGkgPSBhICYmIGEuaW5kZXhPZihjYWxsYmFjayk7XG4gIGkgPj0gMCAmJiBhLnNwbGljZShpLCAxKTtcbn07XG5cblNjcm9sbFRyaWdnZXIuYmF0Y2ggPSBmdW5jdGlvbiAodGFyZ2V0cywgdmFycykge1xuICB2YXIgcmVzdWx0ID0gW10sXG4gICAgICB2YXJzQ29weSA9IHt9LFxuICAgICAgaW50ZXJ2YWwgPSB2YXJzLmludGVydmFsIHx8IDAuMDE2LFxuICAgICAgYmF0Y2hNYXggPSB2YXJzLmJhdGNoTWF4IHx8IDFlOSxcbiAgICAgIHByb3h5Q2FsbGJhY2sgPSBmdW5jdGlvbiBwcm94eUNhbGxiYWNrKHR5cGUsIGNhbGxiYWNrKSB7XG4gICAgdmFyIGVsZW1lbnRzID0gW10sXG4gICAgICAgIHRyaWdnZXJzID0gW10sXG4gICAgICAgIGRlbGF5ID0gZ3NhcC5kZWxheWVkQ2FsbChpbnRlcnZhbCwgZnVuY3Rpb24gKCkge1xuICAgICAgY2FsbGJhY2soZWxlbWVudHMsIHRyaWdnZXJzKTtcbiAgICAgIGVsZW1lbnRzID0gW107XG4gICAgICB0cmlnZ2VycyA9IFtdO1xuICAgIH0pLnBhdXNlKCk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChzZWxmKSB7XG4gICAgICBlbGVtZW50cy5sZW5ndGggfHwgZGVsYXkucmVzdGFydCh0cnVlKTtcbiAgICAgIGVsZW1lbnRzLnB1c2goc2VsZi50cmlnZ2VyKTtcbiAgICAgIHRyaWdnZXJzLnB1c2goc2VsZik7XG4gICAgICBiYXRjaE1heCA8PSBlbGVtZW50cy5sZW5ndGggJiYgZGVsYXkucHJvZ3Jlc3MoMSk7XG4gICAgfTtcbiAgfSxcbiAgICAgIHA7XG5cbiAgZm9yIChwIGluIHZhcnMpIHtcbiAgICB2YXJzQ29weVtwXSA9IHAuc3Vic3RyKDAsIDIpID09PSBcIm9uXCIgJiYgX2lzRnVuY3Rpb24odmFyc1twXSkgJiYgcCAhPT0gXCJvblJlZnJlc2hJbml0XCIgPyBwcm94eUNhbGxiYWNrKHAsIHZhcnNbcF0pIDogdmFyc1twXTtcbiAgfVxuXG4gIGlmIChfaXNGdW5jdGlvbihiYXRjaE1heCkpIHtcbiAgICBiYXRjaE1heCA9IGJhdGNoTWF4KCk7XG5cbiAgICBfYWRkTGlzdGVuZXIoU2Nyb2xsVHJpZ2dlciwgXCJyZWZyZXNoXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiBiYXRjaE1heCA9IHZhcnMuYmF0Y2hNYXgoKTtcbiAgICB9KTtcbiAgfVxuXG4gIF90b0FycmF5KHRhcmdldHMpLmZvckVhY2goZnVuY3Rpb24gKHRhcmdldCkge1xuICAgIHZhciBjb25maWcgPSB7fTtcblxuICAgIGZvciAocCBpbiB2YXJzQ29weSkge1xuICAgICAgY29uZmlnW3BdID0gdmFyc0NvcHlbcF07XG4gICAgfVxuXG4gICAgY29uZmlnLnRyaWdnZXIgPSB0YXJnZXQ7XG4gICAgcmVzdWx0LnB1c2goU2Nyb2xsVHJpZ2dlci5jcmVhdGUoY29uZmlnKSk7XG4gIH0pO1xuXG4gIHJldHVybiByZXN1bHQ7XG59OyAvLyB0byByZWR1Y2UgZmlsZSBzaXplLiBjbGFtcHMgdGhlIHNjcm9sbCBhbmQgYWxzbyByZXR1cm5zIGEgZHVyYXRpb24gbXVsdGlwbGllciBzbyB0aGF0IGlmIHRoZSBzY3JvbGwgZ2V0cyBjaG9wcGVkIHNob3J0ZXIsIHRoZSBkdXJhdGlvbiBnZXRzIGN1cnRhaWxlZCBhcyB3ZWxsIChvdGhlcndpc2UgaWYgeW91J3JlIHZlcnkgY2xvc2UgdG8gdGhlIHRvcCBvZiB0aGUgcGFnZSwgZm9yIGV4YW1wbGUsIGFuZCBzd2lwZSB1cCByZWFsbHkgZmFzdCwgaXQnbGwgc3VkZGVubHkgc2xvdyBkb3duIGFuZCB0YWtlIGEgbG9uZyB0aW1lIHRvIHJlYWNoIHRoZSB0b3ApLlxuXG5cbnZhciBfY2xhbXBTY3JvbGxBbmRHZXREdXJhdGlvbk11bHRpcGxpZXIgPSBmdW5jdGlvbiBfY2xhbXBTY3JvbGxBbmRHZXREdXJhdGlvbk11bHRpcGxpZXIoc2Nyb2xsRnVuYywgY3VycmVudCwgZW5kLCBtYXgpIHtcbiAgY3VycmVudCA+IG1heCA/IHNjcm9sbEZ1bmMobWF4KSA6IGN1cnJlbnQgPCAwICYmIHNjcm9sbEZ1bmMoMCk7XG4gIHJldHVybiBlbmQgPiBtYXggPyAobWF4IC0gY3VycmVudCkgLyAoZW5kIC0gY3VycmVudCkgOiBlbmQgPCAwID8gY3VycmVudCAvIChjdXJyZW50IC0gZW5kKSA6IDE7XG59LFxuICAgIF9hbGxvd05hdGl2ZVBhbm5pbmcgPSBmdW5jdGlvbiBfYWxsb3dOYXRpdmVQYW5uaW5nKHRhcmdldCwgZGlyZWN0aW9uKSB7XG4gIGlmIChkaXJlY3Rpb24gPT09IHRydWUpIHtcbiAgICB0YXJnZXQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0b3VjaC1hY3Rpb25cIik7XG4gIH0gZWxzZSB7XG4gICAgdGFyZ2V0LnN0eWxlLnRvdWNoQWN0aW9uID0gZGlyZWN0aW9uID09PSB0cnVlID8gXCJhdXRvXCIgOiBkaXJlY3Rpb24gPyBcInBhbi1cIiArIGRpcmVjdGlvbiArIChPYnNlcnZlci5pc1RvdWNoID8gXCIgcGluY2gtem9vbVwiIDogXCJcIikgOiBcIm5vbmVcIjsgLy8gbm90ZTogRmlyZWZveCBkb2Vzbid0IHN1cHBvcnQgaXQgcGluY2gtem9vbSBwcm9wZXJseSwgYXQgbGVhc3QgaW4gYWRkaXRpb24gdG8gYSBwYW4teCBvciBwYW4teS5cbiAgfVxuXG4gIHRhcmdldCA9PT0gX2RvY0VsICYmIF9hbGxvd05hdGl2ZVBhbm5pbmcoX2JvZHksIGRpcmVjdGlvbik7XG59LFxuICAgIF9vdmVyZmxvdyA9IHtcbiAgYXV0bzogMSxcbiAgc2Nyb2xsOiAxXG59LFxuICAgIF9uZXN0ZWRTY3JvbGwgPSBmdW5jdGlvbiBfbmVzdGVkU2Nyb2xsKF9yZWY1KSB7XG4gIHZhciBldmVudCA9IF9yZWY1LmV2ZW50LFxuICAgICAgdGFyZ2V0ID0gX3JlZjUudGFyZ2V0LFxuICAgICAgYXhpcyA9IF9yZWY1LmF4aXM7XG5cbiAgdmFyIG5vZGUgPSAoZXZlbnQuY2hhbmdlZFRvdWNoZXMgPyBldmVudC5jaGFuZ2VkVG91Y2hlc1swXSA6IGV2ZW50KS50YXJnZXQsXG4gICAgICBjYWNoZSA9IG5vZGUuX2dzYXAgfHwgZ3NhcC5jb3JlLmdldENhY2hlKG5vZGUpLFxuICAgICAgdGltZSA9IF9nZXRUaW1lKCksXG4gICAgICBjcztcblxuICBpZiAoIWNhY2hlLl9pc1Njcm9sbFQgfHwgdGltZSAtIGNhY2hlLl9pc1Njcm9sbFQgPiAyMDAwKSB7XG4gICAgLy8gY2FjaGUgZm9yIDIgc2Vjb25kcyB0byBpbXByb3ZlIHBlcmZvcm1hbmNlLlxuICAgIHdoaWxlIChub2RlICYmIG5vZGUgIT09IF9ib2R5ICYmIChub2RlLnNjcm9sbEhlaWdodCA8PSBub2RlLmNsaWVudEhlaWdodCAmJiBub2RlLnNjcm9sbFdpZHRoIDw9IG5vZGUuY2xpZW50V2lkdGggfHwgIShfb3ZlcmZsb3dbKGNzID0gX2dldENvbXB1dGVkU3R5bGUobm9kZSkpLm92ZXJmbG93WV0gfHwgX292ZXJmbG93W2NzLm92ZXJmbG93WF0pKSkge1xuICAgICAgbm9kZSA9IG5vZGUucGFyZW50Tm9kZTtcbiAgICB9XG5cbiAgICBjYWNoZS5faXNTY3JvbGwgPSBub2RlICYmIG5vZGUgIT09IHRhcmdldCAmJiAhX2lzVmlld3BvcnQobm9kZSkgJiYgKF9vdmVyZmxvd1soY3MgPSBfZ2V0Q29tcHV0ZWRTdHlsZShub2RlKSkub3ZlcmZsb3dZXSB8fCBfb3ZlcmZsb3dbY3Mub3ZlcmZsb3dYXSk7XG4gICAgY2FjaGUuX2lzU2Nyb2xsVCA9IHRpbWU7XG4gIH1cblxuICBpZiAoY2FjaGUuX2lzU2Nyb2xsIHx8IGF4aXMgPT09IFwieFwiKSB7XG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgZXZlbnQuX2dzYXBBbGxvdyA9IHRydWU7XG4gIH1cbn0sXG4gICAgLy8gY2FwdHVyZSBldmVudHMgb24gc2Nyb2xsYWJsZSBlbGVtZW50cyBJTlNJREUgdGhlIDxib2R5PiBhbmQgYWxsb3cgdGhvc2UgYnkgY2FsbGluZyBzdG9wUHJvcGFnYXRpb24oKSB3aGVuIHdlIGZpbmQgYSBzY3JvbGxhYmxlIGFuY2VzdG9yXG5faW5wdXRPYnNlcnZlciA9IGZ1bmN0aW9uIF9pbnB1dE9ic2VydmVyKHRhcmdldCwgdHlwZSwgaW5wdXRzLCBuZXN0ZWQpIHtcbiAgcmV0dXJuIE9ic2VydmVyLmNyZWF0ZSh7XG4gICAgdGFyZ2V0OiB0YXJnZXQsXG4gICAgY2FwdHVyZTogdHJ1ZSxcbiAgICBkZWJvdW5jZTogZmFsc2UsXG4gICAgbG9ja0F4aXM6IHRydWUsXG4gICAgdHlwZTogdHlwZSxcbiAgICBvbldoZWVsOiBuZXN0ZWQgPSBuZXN0ZWQgJiYgX25lc3RlZFNjcm9sbCxcbiAgICBvblByZXNzOiBuZXN0ZWQsXG4gICAgb25EcmFnOiBuZXN0ZWQsXG4gICAgb25TY3JvbGw6IG5lc3RlZCxcbiAgICBvbkVuYWJsZTogZnVuY3Rpb24gb25FbmFibGUoKSB7XG4gICAgICByZXR1cm4gaW5wdXRzICYmIF9hZGRMaXN0ZW5lcihfZG9jLCBPYnNlcnZlci5ldmVudFR5cGVzWzBdLCBfY2FwdHVyZUlucHV0cywgZmFsc2UsIHRydWUpO1xuICAgIH0sXG4gICAgb25EaXNhYmxlOiBmdW5jdGlvbiBvbkRpc2FibGUoKSB7XG4gICAgICByZXR1cm4gX3JlbW92ZUxpc3RlbmVyKF9kb2MsIE9ic2VydmVyLmV2ZW50VHlwZXNbMF0sIF9jYXB0dXJlSW5wdXRzLCB0cnVlKTtcbiAgICB9XG4gIH0pO1xufSxcbiAgICBfaW5wdXRFeHAgPSAvKGlucHV0fGxhYmVsfHNlbGVjdHx0ZXh0YXJlYSkvaSxcbiAgICBfaW5wdXRJc0ZvY3VzZWQsXG4gICAgX2NhcHR1cmVJbnB1dHMgPSBmdW5jdGlvbiBfY2FwdHVyZUlucHV0cyhlKSB7XG4gIHZhciBpc0lucHV0ID0gX2lucHV0RXhwLnRlc3QoZS50YXJnZXQudGFnTmFtZSk7XG5cbiAgaWYgKGlzSW5wdXQgfHwgX2lucHV0SXNGb2N1c2VkKSB7XG4gICAgZS5fZ3NhcEFsbG93ID0gdHJ1ZTtcbiAgICBfaW5wdXRJc0ZvY3VzZWQgPSBpc0lucHV0O1xuICB9XG59LFxuICAgIF9nZXRTY3JvbGxOb3JtYWxpemVyID0gZnVuY3Rpb24gX2dldFNjcm9sbE5vcm1hbGl6ZXIodmFycykge1xuICBfaXNPYmplY3QodmFycykgfHwgKHZhcnMgPSB7fSk7XG4gIHZhcnMucHJldmVudERlZmF1bHQgPSB2YXJzLmlzTm9ybWFsaXplciA9IHZhcnMuYWxsb3dDbGlja3MgPSB0cnVlO1xuICB2YXJzLnR5cGUgfHwgKHZhcnMudHlwZSA9IFwid2hlZWwsdG91Y2hcIik7XG4gIHZhcnMuZGVib3VuY2UgPSAhIXZhcnMuZGVib3VuY2U7XG4gIHZhcnMuaWQgPSB2YXJzLmlkIHx8IFwibm9ybWFsaXplclwiO1xuXG4gIHZhciBfdmFyczIgPSB2YXJzLFxuICAgICAgbm9ybWFsaXplU2Nyb2xsWCA9IF92YXJzMi5ub3JtYWxpemVTY3JvbGxYLFxuICAgICAgbW9tZW50dW0gPSBfdmFyczIubW9tZW50dW0sXG4gICAgICBhbGxvd05lc3RlZFNjcm9sbCA9IF92YXJzMi5hbGxvd05lc3RlZFNjcm9sbCxcbiAgICAgIG9uUmVsZWFzZSA9IF92YXJzMi5vblJlbGVhc2UsXG4gICAgICBzZWxmLFxuICAgICAgbWF4WSxcbiAgICAgIHRhcmdldCA9IF9nZXRUYXJnZXQodmFycy50YXJnZXQpIHx8IF9kb2NFbCxcbiAgICAgIHNtb290aGVyID0gZ3NhcC5jb3JlLmdsb2JhbHMoKS5TY3JvbGxTbW9vdGhlcixcbiAgICAgIHNtb290aGVySW5zdGFuY2UgPSBzbW9vdGhlciAmJiBzbW9vdGhlci5nZXQoKSxcbiAgICAgIGNvbnRlbnQgPSBfZml4SU9TQnVnICYmICh2YXJzLmNvbnRlbnQgJiYgX2dldFRhcmdldCh2YXJzLmNvbnRlbnQpIHx8IHNtb290aGVySW5zdGFuY2UgJiYgdmFycy5jb250ZW50ICE9PSBmYWxzZSAmJiAhc21vb3RoZXJJbnN0YW5jZS5zbW9vdGgoKSAmJiBzbW9vdGhlckluc3RhbmNlLmNvbnRlbnQoKSksXG4gICAgICBzY3JvbGxGdW5jWSA9IF9nZXRTY3JvbGxGdW5jKHRhcmdldCwgX3ZlcnRpY2FsKSxcbiAgICAgIHNjcm9sbEZ1bmNYID0gX2dldFNjcm9sbEZ1bmModGFyZ2V0LCBfaG9yaXpvbnRhbCksXG4gICAgICBzY2FsZSA9IDEsXG4gICAgICBpbml0aWFsU2NhbGUgPSAoT2JzZXJ2ZXIuaXNUb3VjaCAmJiBfd2luLnZpc3VhbFZpZXdwb3J0ID8gX3dpbi52aXN1YWxWaWV3cG9ydC5zY2FsZSAqIF93aW4udmlzdWFsVmlld3BvcnQud2lkdGggOiBfd2luLm91dGVyV2lkdGgpIC8gX3dpbi5pbm5lcldpZHRoLFxuICAgICAgd2hlZWxSZWZyZXNoID0gMCxcbiAgICAgIHJlc29sdmVNb21lbnR1bUR1cmF0aW9uID0gX2lzRnVuY3Rpb24obW9tZW50dW0pID8gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBtb21lbnR1bShzZWxmKTtcbiAgfSA6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gbW9tZW50dW0gfHwgMi44O1xuICB9LFxuICAgICAgbGFzdFJlZnJlc2hJRCxcbiAgICAgIHNraXBUb3VjaE1vdmUsXG4gICAgICBpbnB1dE9ic2VydmVyID0gX2lucHV0T2JzZXJ2ZXIodGFyZ2V0LCB2YXJzLnR5cGUsIHRydWUsIGFsbG93TmVzdGVkU2Nyb2xsKSxcbiAgICAgIHJlc3VtZVRvdWNoTW92ZSA9IGZ1bmN0aW9uIHJlc3VtZVRvdWNoTW92ZSgpIHtcbiAgICByZXR1cm4gc2tpcFRvdWNoTW92ZSA9IGZhbHNlO1xuICB9LFxuICAgICAgc2Nyb2xsQ2xhbXBYID0gX3Bhc3NUaHJvdWdoLFxuICAgICAgc2Nyb2xsQ2xhbXBZID0gX3Bhc3NUaHJvdWdoLFxuICAgICAgdXBkYXRlQ2xhbXBzID0gZnVuY3Rpb24gdXBkYXRlQ2xhbXBzKCkge1xuICAgIG1heFkgPSBfbWF4U2Nyb2xsKHRhcmdldCwgX3ZlcnRpY2FsKTtcbiAgICBzY3JvbGxDbGFtcFkgPSBfY2xhbXAoX2ZpeElPU0J1ZyA/IDEgOiAwLCBtYXhZKTtcbiAgICBub3JtYWxpemVTY3JvbGxYICYmIChzY3JvbGxDbGFtcFggPSBfY2xhbXAoMCwgX21heFNjcm9sbCh0YXJnZXQsIF9ob3Jpem9udGFsKSkpO1xuICAgIGxhc3RSZWZyZXNoSUQgPSBfcmVmcmVzaElEO1xuICB9LFxuICAgICAgcmVtb3ZlQ29udGVudE9mZnNldCA9IGZ1bmN0aW9uIHJlbW92ZUNvbnRlbnRPZmZzZXQoKSB7XG4gICAgY29udGVudC5fZ3NhcC55ID0gX3JvdW5kKHBhcnNlRmxvYXQoY29udGVudC5fZ3NhcC55KSArIHNjcm9sbEZ1bmNZLm9mZnNldCkgKyBcInB4XCI7XG4gICAgY29udGVudC5zdHlsZS50cmFuc2Zvcm0gPSBcIm1hdHJpeDNkKDEsIDAsIDAsIDAsIDAsIDEsIDAsIDAsIDAsIDAsIDEsIDAsIDAsIFwiICsgcGFyc2VGbG9hdChjb250ZW50Ll9nc2FwLnkpICsgXCIsIDAsIDEpXCI7XG4gICAgc2Nyb2xsRnVuY1kub2Zmc2V0ID0gc2Nyb2xsRnVuY1kuY2FjaGVJRCA9IDA7XG4gIH0sXG4gICAgICBpZ25vcmVEcmFnID0gZnVuY3Rpb24gaWdub3JlRHJhZygpIHtcbiAgICBpZiAoc2tpcFRvdWNoTW92ZSkge1xuICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJlc3VtZVRvdWNoTW92ZSk7XG5cbiAgICAgIHZhciBvZmZzZXQgPSBfcm91bmQoc2VsZi5kZWx0YVkgLyAyKSxcbiAgICAgICAgICBzY3JvbGwgPSBzY3JvbGxDbGFtcFkoc2Nyb2xsRnVuY1kudiAtIG9mZnNldCk7XG5cbiAgICAgIGlmIChjb250ZW50ICYmIHNjcm9sbCAhPT0gc2Nyb2xsRnVuY1kudiArIHNjcm9sbEZ1bmNZLm9mZnNldCkge1xuICAgICAgICBzY3JvbGxGdW5jWS5vZmZzZXQgPSBzY3JvbGwgLSBzY3JvbGxGdW5jWS52O1xuXG4gICAgICAgIHZhciB5ID0gX3JvdW5kKChwYXJzZUZsb2F0KGNvbnRlbnQgJiYgY29udGVudC5fZ3NhcC55KSB8fCAwKSAtIHNjcm9sbEZ1bmNZLm9mZnNldCk7XG5cbiAgICAgICAgY29udGVudC5zdHlsZS50cmFuc2Zvcm0gPSBcIm1hdHJpeDNkKDEsIDAsIDAsIDAsIDAsIDEsIDAsIDAsIDAsIDAsIDEsIDAsIDAsIFwiICsgeSArIFwiLCAwLCAxKVwiO1xuICAgICAgICBjb250ZW50Ll9nc2FwLnkgPSB5ICsgXCJweFwiO1xuICAgICAgICBzY3JvbGxGdW5jWS5jYWNoZUlEID0gX3Njcm9sbGVycy5jYWNoZTtcblxuICAgICAgICBfdXBkYXRlQWxsKCk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIHNjcm9sbEZ1bmNZLm9mZnNldCAmJiByZW1vdmVDb250ZW50T2Zmc2V0KCk7XG4gICAgc2tpcFRvdWNoTW92ZSA9IHRydWU7XG4gIH0sXG4gICAgICB0d2VlbixcbiAgICAgIHN0YXJ0U2Nyb2xsWCxcbiAgICAgIHN0YXJ0U2Nyb2xsWSxcbiAgICAgIG9uU3RvcERlbGF5ZWRDYWxsLFxuICAgICAgb25SZXNpemUgPSBmdW5jdGlvbiBvblJlc2l6ZSgpIHtcbiAgICAvLyBpZiB0aGUgd2luZG93IHJlc2l6ZXMsIGxpa2Ugb24gYW4gaVBob25lIHdoaWNoIEFwcGxlIEZPUkNFUyB0aGUgYWRkcmVzcyBiYXIgdG8gc2hvdy9oaWRlIGV2ZW4gaWYgd2UgZXZlbnQucHJldmVudERlZmF1bHQoKSwgaXQgbWF5IGJlIHNjcm9sbGluZyB0b28gZmFyIG5vdyB0aGF0IHRoZSBhZGRyZXNzIGJhciBpcyBzaG93aW5nLCBzbyB3ZSBtdXN0IGR5bmFtaWNhbGx5IGFkanVzdCB0aGUgbW9tZW50dW0gdHdlZW4uXG4gICAgdXBkYXRlQ2xhbXBzKCk7XG5cbiAgICBpZiAodHdlZW4uaXNBY3RpdmUoKSAmJiB0d2Vlbi52YXJzLnNjcm9sbFkgPiBtYXhZKSB7XG4gICAgICBzY3JvbGxGdW5jWSgpID4gbWF4WSA/IHR3ZWVuLnByb2dyZXNzKDEpICYmIHNjcm9sbEZ1bmNZKG1heFkpIDogdHdlZW4ucmVzZXRUbyhcInNjcm9sbFlcIiwgbWF4WSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnRlbnQgJiYgZ3NhcC5zZXQoY29udGVudCwge1xuICAgIHk6IFwiKz0wXCJcbiAgfSk7IC8vIHRvIGVuc3VyZSB0aGVyZSdzIGEgY2FjaGUgKGVsZW1lbnQuX2dzYXApXG5cbiAgdmFycy5pZ25vcmVDaGVjayA9IGZ1bmN0aW9uIChlKSB7XG4gICAgcmV0dXJuIF9maXhJT1NCdWcgJiYgZS50eXBlID09PSBcInRvdWNobW92ZVwiICYmIGlnbm9yZURyYWcoZSkgfHwgc2NhbGUgPiAxLjA1ICYmIGUudHlwZSAhPT0gXCJ0b3VjaHN0YXJ0XCIgfHwgc2VsZi5pc0dlc3R1cmluZyB8fCBlLnRvdWNoZXMgJiYgZS50b3VjaGVzLmxlbmd0aCA+IDE7XG4gIH07XG5cbiAgdmFycy5vblByZXNzID0gZnVuY3Rpb24gKCkge1xuICAgIHNraXBUb3VjaE1vdmUgPSBmYWxzZTtcbiAgICB2YXIgcHJldlNjYWxlID0gc2NhbGU7XG4gICAgc2NhbGUgPSBfcm91bmQoKF93aW4udmlzdWFsVmlld3BvcnQgJiYgX3dpbi52aXN1YWxWaWV3cG9ydC5zY2FsZSB8fCAxKSAvIGluaXRpYWxTY2FsZSk7XG4gICAgdHdlZW4ucGF1c2UoKTtcbiAgICBwcmV2U2NhbGUgIT09IHNjYWxlICYmIF9hbGxvd05hdGl2ZVBhbm5pbmcodGFyZ2V0LCBzY2FsZSA+IDEuMDEgPyB0cnVlIDogbm9ybWFsaXplU2Nyb2xsWCA/IGZhbHNlIDogXCJ4XCIpO1xuICAgIHN0YXJ0U2Nyb2xsWCA9IHNjcm9sbEZ1bmNYKCk7XG4gICAgc3RhcnRTY3JvbGxZID0gc2Nyb2xsRnVuY1koKTtcbiAgICB1cGRhdGVDbGFtcHMoKTtcbiAgICBsYXN0UmVmcmVzaElEID0gX3JlZnJlc2hJRDtcbiAgfTtcblxuICB2YXJzLm9uUmVsZWFzZSA9IHZhcnMub25HZXN0dXJlU3RhcnQgPSBmdW5jdGlvbiAoc2VsZiwgd2FzRHJhZ2dpbmcpIHtcbiAgICBzY3JvbGxGdW5jWS5vZmZzZXQgJiYgcmVtb3ZlQ29udGVudE9mZnNldCgpO1xuXG4gICAgaWYgKCF3YXNEcmFnZ2luZykge1xuICAgICAgb25TdG9wRGVsYXllZENhbGwucmVzdGFydCh0cnVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgX3Njcm9sbGVycy5jYWNoZSsrOyAvLyBtYWtlIHN1cmUgd2UncmUgcHVsbGluZyB0aGUgbm9uLWNhY2hlZCB2YWx1ZVxuICAgICAgLy8gYWx0ZXJuYXRlIGFsZ29yaXRobTogZHVyWCA9IE1hdGgubWluKDYsIE1hdGguYWJzKHNlbGYudmVsb2NpdHlYIC8gODAwKSksXHRkdXIgPSBNYXRoLm1heChkdXJYLCBNYXRoLm1pbig2LCBNYXRoLmFicyhzZWxmLnZlbG9jaXR5WSAvIDgwMCkpKTsgZHVyID0gZHVyICogKDAuNCArICgxIC0gX3Bvd2VyNEluKGR1ciAvIDYpKSAqIDAuNikpICogKG1vbWVudHVtU3BlZWQgfHwgMSlcblxuICAgICAgdmFyIGR1ciA9IHJlc29sdmVNb21lbnR1bUR1cmF0aW9uKCksXG4gICAgICAgICAgY3VycmVudFNjcm9sbCxcbiAgICAgICAgICBlbmRTY3JvbGw7XG5cbiAgICAgIGlmIChub3JtYWxpemVTY3JvbGxYKSB7XG4gICAgICAgIGN1cnJlbnRTY3JvbGwgPSBzY3JvbGxGdW5jWCgpO1xuICAgICAgICBlbmRTY3JvbGwgPSBjdXJyZW50U2Nyb2xsICsgZHVyICogMC4wNSAqIC1zZWxmLnZlbG9jaXR5WCAvIDAuMjI3OyAvLyB0aGUgY29uc3RhbnQgLjIyNyBpcyBmcm9tIHBvd2VyNCgwLjA1KS4gdmVsb2NpdHkgaXMgaW52ZXJ0ZWQgYmVjYXVzZSBzY3JvbGxpbmcgZ29lcyBpbiB0aGUgb3Bwb3NpdGUgZGlyZWN0aW9uLlxuXG4gICAgICAgIGR1ciAqPSBfY2xhbXBTY3JvbGxBbmRHZXREdXJhdGlvbk11bHRpcGxpZXIoc2Nyb2xsRnVuY1gsIGN1cnJlbnRTY3JvbGwsIGVuZFNjcm9sbCwgX21heFNjcm9sbCh0YXJnZXQsIF9ob3Jpem9udGFsKSk7XG4gICAgICAgIHR3ZWVuLnZhcnMuc2Nyb2xsWCA9IHNjcm9sbENsYW1wWChlbmRTY3JvbGwpO1xuICAgICAgfVxuXG4gICAgICBjdXJyZW50U2Nyb2xsID0gc2Nyb2xsRnVuY1koKTtcbiAgICAgIGVuZFNjcm9sbCA9IGN1cnJlbnRTY3JvbGwgKyBkdXIgKiAwLjA1ICogLXNlbGYudmVsb2NpdHlZIC8gMC4yMjc7IC8vIHRoZSBjb25zdGFudCAuMjI3IGlzIGZyb20gcG93ZXI0KDAuMDUpXG5cbiAgICAgIGR1ciAqPSBfY2xhbXBTY3JvbGxBbmRHZXREdXJhdGlvbk11bHRpcGxpZXIoc2Nyb2xsRnVuY1ksIGN1cnJlbnRTY3JvbGwsIGVuZFNjcm9sbCwgX21heFNjcm9sbCh0YXJnZXQsIF92ZXJ0aWNhbCkpO1xuICAgICAgdHdlZW4udmFycy5zY3JvbGxZID0gc2Nyb2xsQ2xhbXBZKGVuZFNjcm9sbCk7XG4gICAgICB0d2Vlbi5pbnZhbGlkYXRlKCkuZHVyYXRpb24oZHVyKS5wbGF5KDAuMDEpO1xuXG4gICAgICBpZiAoX2ZpeElPU0J1ZyAmJiB0d2Vlbi52YXJzLnNjcm9sbFkgPj0gbWF4WSB8fCBjdXJyZW50U2Nyb2xsID49IG1heFkgLSAxKSB7XG4gICAgICAgIC8vIGlPUyBidWc6IGl0J2xsIHNob3cgdGhlIGFkZHJlc3MgYmFyIGJ1dCBOT1QgZmlyZSB0aGUgd2luZG93IFwicmVzaXplXCIgZXZlbnQgdW50aWwgdGhlIGFuaW1hdGlvbiBpcyBkb25lIGJ1dCB3ZSBtdXN0IHByb3RlY3QgYWdhaW5zdCBvdmVyc2hvb3Qgc28gd2UgbGV2ZXJhZ2UgYW4gb25VcGRhdGUgdG8gZG8gc28uXG4gICAgICAgIGdzYXAudG8oe30sIHtcbiAgICAgICAgICBvblVwZGF0ZTogb25SZXNpemUsXG4gICAgICAgICAgZHVyYXRpb246IGR1clxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBvblJlbGVhc2UgJiYgb25SZWxlYXNlKHNlbGYpO1xuICB9O1xuXG4gIHZhcnMub25XaGVlbCA9IGZ1bmN0aW9uICgpIHtcbiAgICB0d2Vlbi5fdHMgJiYgdHdlZW4ucGF1c2UoKTtcblxuICAgIGlmIChfZ2V0VGltZSgpIC0gd2hlZWxSZWZyZXNoID4gMTAwMCkge1xuICAgICAgLy8gYWZ0ZXIgMSBzZWNvbmQsIHJlZnJlc2ggdGhlIGNsYW1wcyBvdGhlcndpc2UgdGhhdCdsbCBvbmx5IGhhcHBlbiB3aGVuIFNjcm9sbFRyaWdnZXIucmVmcmVzaCgpIGlzIGNhbGxlZCBvciBmb3IgdG91Y2gtc2Nyb2xsaW5nLlxuICAgICAgbGFzdFJlZnJlc2hJRCA9IDA7XG4gICAgICB3aGVlbFJlZnJlc2ggPSBfZ2V0VGltZSgpO1xuICAgIH1cbiAgfTtcblxuICB2YXJzLm9uQ2hhbmdlID0gZnVuY3Rpb24gKHNlbGYsIGR4LCBkeSwgeEFycmF5LCB5QXJyYXkpIHtcbiAgICBfcmVmcmVzaElEICE9PSBsYXN0UmVmcmVzaElEICYmIHVwZGF0ZUNsYW1wcygpO1xuICAgIGR4ICYmIG5vcm1hbGl6ZVNjcm9sbFggJiYgc2Nyb2xsRnVuY1goc2Nyb2xsQ2xhbXBYKHhBcnJheVsyXSA9PT0gZHggPyBzdGFydFNjcm9sbFggKyAoc2VsZi5zdGFydFggLSBzZWxmLngpIDogc2Nyb2xsRnVuY1goKSArIGR4IC0geEFycmF5WzFdKSk7IC8vIGZvciBtb3JlIHByZWNpc2lvbiwgd2UgdHJhY2sgcG9pbnRlci90b3VjaCBtb3ZlbWVudCBmcm9tIHRoZSBzdGFydCwgb3RoZXJ3aXNlIGl0J2xsIGRyaWZ0LlxuXG4gICAgaWYgKGR5KSB7XG4gICAgICBzY3JvbGxGdW5jWS5vZmZzZXQgJiYgcmVtb3ZlQ29udGVudE9mZnNldCgpO1xuICAgICAgdmFyIGlzVG91Y2ggPSB5QXJyYXlbMl0gPT09IGR5LFxuICAgICAgICAgIHkgPSBpc1RvdWNoID8gc3RhcnRTY3JvbGxZICsgc2VsZi5zdGFydFkgLSBzZWxmLnkgOiBzY3JvbGxGdW5jWSgpICsgZHkgLSB5QXJyYXlbMV0sXG4gICAgICAgICAgeUNsYW1wZWQgPSBzY3JvbGxDbGFtcFkoeSk7XG4gICAgICBpc1RvdWNoICYmIHkgIT09IHlDbGFtcGVkICYmIChzdGFydFNjcm9sbFkgKz0geUNsYW1wZWQgLSB5KTtcbiAgICAgIHNjcm9sbEZ1bmNZKHlDbGFtcGVkKTtcbiAgICB9XG5cbiAgICAoZHkgfHwgZHgpICYmIF91cGRhdGVBbGwoKTtcbiAgfTtcblxuICB2YXJzLm9uRW5hYmxlID0gZnVuY3Rpb24gKCkge1xuICAgIF9hbGxvd05hdGl2ZVBhbm5pbmcodGFyZ2V0LCBub3JtYWxpemVTY3JvbGxYID8gZmFsc2UgOiBcInhcIik7XG5cbiAgICBTY3JvbGxUcmlnZ2VyLmFkZEV2ZW50TGlzdGVuZXIoXCJyZWZyZXNoXCIsIG9uUmVzaXplKTtcblxuICAgIF9hZGRMaXN0ZW5lcihfd2luLCBcInJlc2l6ZVwiLCBvblJlc2l6ZSk7XG5cbiAgICBpZiAoc2Nyb2xsRnVuY1kuc21vb3RoKSB7XG4gICAgICBzY3JvbGxGdW5jWS50YXJnZXQuc3R5bGUuc2Nyb2xsQmVoYXZpb3IgPSBcImF1dG9cIjtcbiAgICAgIHNjcm9sbEZ1bmNZLnNtb290aCA9IHNjcm9sbEZ1bmNYLnNtb290aCA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlucHV0T2JzZXJ2ZXIuZW5hYmxlKCk7XG4gIH07XG5cbiAgdmFycy5vbkRpc2FibGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgX2FsbG93TmF0aXZlUGFubmluZyh0YXJnZXQsIHRydWUpO1xuXG4gICAgX3JlbW92ZUxpc3RlbmVyKF93aW4sIFwicmVzaXplXCIsIG9uUmVzaXplKTtcblxuICAgIFNjcm9sbFRyaWdnZXIucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInJlZnJlc2hcIiwgb25SZXNpemUpO1xuICAgIGlucHV0T2JzZXJ2ZXIua2lsbCgpO1xuICB9O1xuXG4gIHZhcnMubG9ja0F4aXMgPSB2YXJzLmxvY2tBeGlzICE9PSBmYWxzZTtcbiAgc2VsZiA9IG5ldyBPYnNlcnZlcih2YXJzKTtcbiAgc2VsZi5pT1MgPSBfZml4SU9TQnVnOyAvLyB1c2VkIGluIHRoZSBPYnNlcnZlciBnZXRDYWNoZWRTY3JvbGwoKSBmdW5jdGlvbiB0byB3b3JrIGFyb3VuZCBhbiBpT1MgYnVnIHRoYXQgd3JlYWtzIGhhdm9jIHdpdGggVG91Y2hFdmVudC5jbGllbnRZIGlmIHdlIGFsbG93IHNjcm9sbCB0byBnbyBhbGwgdGhlIHdheSBiYWNrIHRvIDAuXG5cbiAgX2ZpeElPU0J1ZyAmJiAhc2Nyb2xsRnVuY1koKSAmJiBzY3JvbGxGdW5jWSgxKTsgLy8gaU9TIGJ1ZyBjYXVzZXMgZXZlbnQuY2xpZW50WSB2YWx1ZXMgdG8gZnJlYWsgb3V0ICh3aWxkbHkgaW5hY2N1cmF0ZSkgaWYgdGhlIHNjcm9sbCBwb3NpdGlvbiBpcyBleGFjdGx5IDAuXG5cbiAgX2ZpeElPU0J1ZyAmJiBnc2FwLnRpY2tlci5hZGQoX3Bhc3NUaHJvdWdoKTsgLy8gcHJldmVudCB0aGUgdGlja2VyIGZyb20gc2xlZXBpbmdcblxuICBvblN0b3BEZWxheWVkQ2FsbCA9IHNlbGYuX2RjO1xuICB0d2VlbiA9IGdzYXAudG8oc2VsZiwge1xuICAgIGVhc2U6IFwicG93ZXI0XCIsXG4gICAgcGF1c2VkOiB0cnVlLFxuICAgIGluaGVyaXQ6IGZhbHNlLFxuICAgIHNjcm9sbFg6IG5vcm1hbGl6ZVNjcm9sbFggPyBcIis9MC4xXCIgOiBcIis9MFwiLFxuICAgIHNjcm9sbFk6IFwiKz0wLjFcIixcbiAgICBtb2RpZmllcnM6IHtcbiAgICAgIHNjcm9sbFk6IF9pbnRlcnJ1cHRpb25UcmFja2VyKHNjcm9sbEZ1bmNZLCBzY3JvbGxGdW5jWSgpLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0d2Vlbi5wYXVzZSgpO1xuICAgICAgfSlcbiAgICB9LFxuICAgIG9uVXBkYXRlOiBfdXBkYXRlQWxsLFxuICAgIG9uQ29tcGxldGU6IG9uU3RvcERlbGF5ZWRDYWxsLnZhcnMub25Db21wbGV0ZVxuICB9KTsgLy8gd2UgbmVlZCB0aGUgbW9kaWZpZXIgdG8gc2Vuc2UgaWYgdGhlIHNjcm9sbCBwb3NpdGlvbiBpcyBhbHRlcmVkIG91dHNpZGUgb2YgdGhlIG1vbWVudHVtIHR3ZWVuIChsaWtlIHdpdGggYSBzY3JvbGxUbyB0d2Vlbikgc28gd2UgY2FuIHBhdXNlKCkgaXQgdG8gcHJldmVudCBjb25mbGljdHMuXG5cbiAgcmV0dXJuIHNlbGY7XG59O1xuXG5TY3JvbGxUcmlnZ2VyLnNvcnQgPSBmdW5jdGlvbiAoZnVuYykge1xuICBpZiAoX2lzRnVuY3Rpb24oZnVuYykpIHtcbiAgICByZXR1cm4gX3RyaWdnZXJzLnNvcnQoZnVuYyk7XG4gIH1cblxuICB2YXIgc2Nyb2xsID0gX3dpbi5wYWdlWU9mZnNldCB8fCAwO1xuICBTY3JvbGxUcmlnZ2VyLmdldEFsbCgpLmZvckVhY2goZnVuY3Rpb24gKHQpIHtcbiAgICByZXR1cm4gdC5fc29ydFkgPSB0LnRyaWdnZXIgPyBzY3JvbGwgKyB0LnRyaWdnZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkudG9wIDogdC5zdGFydCArIF93aW4uaW5uZXJIZWlnaHQ7XG4gIH0pO1xuICByZXR1cm4gX3RyaWdnZXJzLnNvcnQoZnVuYyB8fCBmdW5jdGlvbiAoYSwgYikge1xuICAgIHJldHVybiAoYS52YXJzLnJlZnJlc2hQcmlvcml0eSB8fCAwKSAqIC0xZTYgKyAoYS52YXJzLmNvbnRhaW5lckFuaW1hdGlvbiA/IDFlNiA6IGEuX3NvcnRZKSAtICgoYi52YXJzLmNvbnRhaW5lckFuaW1hdGlvbiA/IDFlNiA6IGIuX3NvcnRZKSArIChiLnZhcnMucmVmcmVzaFByaW9yaXR5IHx8IDApICogLTFlNik7XG4gIH0pOyAvLyBhbnl0aGluZyB3aXRoIGEgY29udGFpbmVyQW5pbWF0aW9uIHNob3VsZCByZWZyZXNoIGxhc3QuXG59O1xuXG5TY3JvbGxUcmlnZ2VyLm9ic2VydmUgPSBmdW5jdGlvbiAodmFycykge1xuICByZXR1cm4gbmV3IE9ic2VydmVyKHZhcnMpO1xufTtcblxuU2Nyb2xsVHJpZ2dlci5ub3JtYWxpemVTY3JvbGwgPSBmdW5jdGlvbiAodmFycykge1xuICBpZiAodHlwZW9mIHZhcnMgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICByZXR1cm4gX25vcm1hbGl6ZXI7XG4gIH1cblxuICBpZiAodmFycyA9PT0gdHJ1ZSAmJiBfbm9ybWFsaXplcikge1xuICAgIHJldHVybiBfbm9ybWFsaXplci5lbmFibGUoKTtcbiAgfVxuXG4gIGlmICh2YXJzID09PSBmYWxzZSkge1xuICAgIF9ub3JtYWxpemVyICYmIF9ub3JtYWxpemVyLmtpbGwoKTtcbiAgICBfbm9ybWFsaXplciA9IHZhcnM7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgdmFyIG5vcm1hbGl6ZXIgPSB2YXJzIGluc3RhbmNlb2YgT2JzZXJ2ZXIgPyB2YXJzIDogX2dldFNjcm9sbE5vcm1hbGl6ZXIodmFycyk7XG4gIF9ub3JtYWxpemVyICYmIF9ub3JtYWxpemVyLnRhcmdldCA9PT0gbm9ybWFsaXplci50YXJnZXQgJiYgX25vcm1hbGl6ZXIua2lsbCgpO1xuICBfaXNWaWV3cG9ydChub3JtYWxpemVyLnRhcmdldCkgJiYgKF9ub3JtYWxpemVyID0gbm9ybWFsaXplcik7XG4gIHJldHVybiBub3JtYWxpemVyO1xufTtcblxuU2Nyb2xsVHJpZ2dlci5jb3JlID0ge1xuICAvLyBzbWFsbGVyIGZpbGUgc2l6ZSB3YXkgdG8gbGV2ZXJhZ2UgaW4gU2Nyb2xsU21vb3RoZXIgYW5kIE9ic2VydmVyXG4gIF9nZXRWZWxvY2l0eVByb3A6IF9nZXRWZWxvY2l0eVByb3AsXG4gIF9pbnB1dE9ic2VydmVyOiBfaW5wdXRPYnNlcnZlcixcbiAgX3Njcm9sbGVyczogX3Njcm9sbGVycyxcbiAgX3Byb3hpZXM6IF9wcm94aWVzLFxuICBicmlkZ2U6IHtcbiAgICAvLyB3aGVuIG5vcm1hbGl6ZVNjcm9sbCBzZXRzIHRoZSBzY3JvbGwgcG9zaXRpb24gKHNzID0gc2V0U2Nyb2xsKVxuICAgIHNzOiBmdW5jdGlvbiBzcygpIHtcbiAgICAgIF9sYXN0U2Nyb2xsVGltZSB8fCBfZGlzcGF0Y2goXCJzY3JvbGxTdGFydFwiKTtcbiAgICAgIF9sYXN0U2Nyb2xsVGltZSA9IF9nZXRUaW1lKCk7XG4gICAgfSxcbiAgICAvLyBhIHdheSB0byBnZXQgdGhlIF9yZWZyZXNoaW5nIHZhbHVlIGluIE9ic2VydmVyXG4gICAgcmVmOiBmdW5jdGlvbiByZWYoKSB7XG4gICAgICByZXR1cm4gX3JlZnJlc2hpbmc7XG4gICAgfVxuICB9XG59O1xuX2dldEdTQVAoKSAmJiBnc2FwLnJlZ2lzdGVyUGx1Z2luKFNjcm9sbFRyaWdnZXIpO1xuZXhwb3J0IHsgU2Nyb2xsVHJpZ2dlciBhcyBkZWZhdWx0IH07Il0sIm1hcHBpbmdzIjoiO0FBQUEsU0FBUyxrQkFBa0IsUUFBUSxPQUFPO0NBQUUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0VBQUUsSUFBSSxhQUFhLE1BQU07RUFBSSxXQUFXLGFBQWEsV0FBVyxjQUFjO0VBQU8sV0FBVyxlQUFlO0VBQU0sSUFBSSxXQUFXLFlBQVksV0FBVyxXQUFXO0VBQU0sT0FBTyxlQUFlLFFBQVEsV0FBVyxLQUFLLFVBQVU7Q0FBRztBQUFFO0FBRTVULFNBQVMsYUFBYSxhQUFhLFlBQVksYUFBYTtDQUFFLElBQUksWUFBWSxrQkFBa0IsWUFBWSxXQUFXLFVBQVU7Q0FBRyxJQUFJLGFBQWEsa0JBQWtCLGFBQWEsV0FBVztDQUFHLE9BQU87QUFBYTs7Ozs7Ozs7O0FBWXROLElBQUlBO0lBQ0FDO0lBRUFDO0lBQ0FDO0lBQ0FDO0lBQ0FDO0lBQ0E7SUFDQTtJQUNBQztJQUNBQztJQUNBQztJQUNBO0lBQ0FDO0lBQ0FDLGFBQVcsU0FBUyxXQUFXO0NBQ2pDLE9BQU9WLFVBQVEsT0FBTyxXQUFXLGdCQUFnQixTQUFPLE9BQU8sU0FBU0EsT0FBSyxrQkFBa0JBO0FBQ2pHO0lBQ0lXLGFBQVc7SUFDWCxhQUFhLENBQUM7SUFDZCxhQUFhLENBQUM7SUFDZCxXQUFXLENBQUM7SUFDWkMsYUFBVyxLQUFLO0lBQ2hCLFVBQVUsU0FBUyxRQUFRLE1BQU0sT0FBTztDQUMxQyxPQUFPO0FBQ1Q7SUFDSSxhQUFhLFNBQVMsYUFBYTtDQUNyQyxJQUFJLE9BQU9OLGdCQUFjLE1BQ3JCLE9BQU8sS0FBSyxVQUFVLENBQUMsR0FDdkIsWUFBWSxLQUFLLFlBQ2pCLFVBQVUsS0FBSztDQUNuQixVQUFVLEtBQUssTUFBTSxXQUFXLFVBQVU7Q0FDMUMsUUFBUSxLQUFLLE1BQU0sU0FBUyxRQUFRO0NBQ3BDLGFBQWE7Q0FDYixXQUFXO0NBRVgsVUFBVSxTQUFTLFFBQVEsTUFBTSxPQUFPO0VBQ3RDLE9BQU8sS0FBSyxLQUFLLENBQUMsS0FBSztDQUN6QjtBQUNGO0lBQ0ksZ0JBQWdCLFNBQVMsY0FBYyxTQUFTLFVBQVU7Q0FDNUQsT0FBTyxDQUFDLFNBQVMsUUFBUSxPQUFPLEtBQUssU0FBUyxTQUFTLFFBQVEsT0FBTyxJQUFJLEVBQUUsQ0FBQztBQUMvRTtJQUNJTyxnQkFBYyxTQUFTLFlBQVksSUFBSTtDQUN6QyxPQUFPLENBQUMsQ0FBQyxDQUFDTixRQUFNLFFBQVEsRUFBRTtBQUM1QjtJQUNJTyxpQkFBZSxTQUFTLGFBQWEsU0FBUyxNQUFNLE1BQU0sU0FBUyxTQUFTO0NBQzlFLE9BQU8sUUFBUSxpQkFBaUIsTUFBTSxNQUFNO0VBQzFDLFNBQVMsWUFBWTtFQUNyQixTQUFTLENBQUMsQ0FBQztDQUNiLENBQUM7QUFDSDtJQUNJQyxvQkFBa0IsU0FBUyxnQkFBZ0IsU0FBUyxNQUFNLE1BQU0sU0FBUztDQUMzRSxPQUFPLFFBQVEsb0JBQW9CLE1BQU0sTUFBTSxDQUFDLENBQUMsT0FBTztBQUMxRDtJQUNJLGNBQWM7SUFDZCxhQUFhO0lBQ2JDLGNBQVksU0FBUyxZQUFZO0NBQ25DLE9BQU9SLGlCQUFlQSxjQUFZLGFBQWEsV0FBVztBQUM1RDtJQUNJLG1CQUFtQixTQUFTLGlCQUFpQixHQUFHLFlBQVk7Q0FDOUQsSUFBSSxjQUFjLFNBQVMsWUFBWSxPQUFPO0VBRTVDLElBQUksU0FBUyxVQUFVLEdBQUc7R0FDeEIsZUFBYSxPQUFLLFFBQVEsb0JBQW9CO0dBRTlDLElBQUksZ0JBQWdCQSxpQkFBZUEsY0FBWTtHQUMvQyxRQUFRLFlBQVksSUFBSSxLQUFLLE1BQU0sS0FBSyxNQUFNQSxpQkFBZUEsY0FBWSxNQUFNLElBQUk7R0FFbkYsRUFBRSxLQUFLO0dBQ1AsWUFBWSxVQUFVLFdBQVc7R0FDakMsaUJBQWlCLFFBQVEsTUFBTSxLQUFLO0VBQ3RDLE9BQU8sSUFBSSxjQUFjLFdBQVcsVUFBVSxZQUFZLFdBQVcsUUFBUSxLQUFLLEdBQUc7R0FDbkYsWUFBWSxVQUFVLFdBQVc7R0FDakMsWUFBWSxJQUFJLEVBQUU7RUFDcEI7RUFFQSxPQUFPLFlBQVksSUFBSSxZQUFZO0NBQ3JDO0NBRUEsWUFBWSxTQUFTO0NBQ3JCLE9BQU8sS0FBSztBQUNkO0lBQ0ksY0FBYztDQUNoQixHQUFHO0NBQ0gsR0FBRztDQUNILElBQUk7Q0FDSixJQUFJO0NBQ0osS0FBSztDQUNMLEdBQUc7Q0FDSCxJQUFJO0NBQ0osR0FBRztDQUNILElBQUksaUJBQWlCLFNBQVUsT0FBTztFQUNwQyxPQUFPLFVBQVUsU0FBU04sT0FBSyxTQUFTLE9BQU8sVUFBVSxHQUFHLENBQUMsSUFBSUEsT0FBSyxlQUFlQyxPQUFLLGdCQUFnQkMsU0FBTyxnQkFBZ0JDLFFBQU0sZ0JBQWdCO0NBQ3pKLENBQUM7QUFDSDtJQUNJLFlBQVk7Q0FDZCxHQUFHO0NBQ0gsR0FBRztDQUNILElBQUk7Q0FDSixJQUFJO0NBQ0osS0FBSztDQUNMLEdBQUc7Q0FDSCxJQUFJO0NBQ0osR0FBRztDQUNILElBQUk7Q0FDSixJQUFJLGlCQUFpQixTQUFVLE9BQU87RUFDcEMsT0FBTyxVQUFVLFNBQVNILE9BQUssU0FBUyxZQUFZLEdBQUcsR0FBRyxLQUFLLElBQUlBLE9BQUssZUFBZUMsT0FBSyxlQUFlQyxTQUFPLGVBQWVDLFFBQU0sZUFBZTtDQUN4SixDQUFDO0FBQ0g7SUFDSSxhQUFhLFNBQVMsV0FBVyxHQUFHLE1BQU07Q0FDNUMsUUFBUSxRQUFRLEtBQUssUUFBUSxLQUFLLEtBQUssWUFBWUwsT0FBSyxNQUFNLFFBQUEsQ0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU8sTUFBTSxZQUFZQSxPQUFLLE9BQU8sQ0FBQyxDQUFDLG1CQUFtQixRQUFRLFFBQVEsS0FBSyxzQkFBc0IsQ0FBQyxJQUFJO0FBQzdMO0lBQ0ksWUFBWSxTQUFTLFVBQVUsU0FBUyxNQUFNO0NBRWhELElBQUksSUFBSSxLQUFLO0NBRWIsT0FBTyxLQUNMLElBQUksS0FBSyxPQUFPLFdBQVcsS0FBSyxFQUFFLENBQUMsU0FBUyxPQUFPLEdBQ2pELE9BQU87Q0FJWCxPQUFPO0FBQ1Q7SUFDSSxpQkFBaUIsU0FBUyxlQUFlLFNBQVMsTUFBTTtDQUMxRCxJQUFJLElBQUksS0FBSyxHQUNULEtBQUssS0FBSztDQUVkLGNBQVksT0FBTyxNQUFNLFVBQVVHLE9BQUssb0JBQW9CQztDQUU1RCxJQUFJLElBQUksV0FBVyxRQUFRLE9BQU8sR0FDOUIsU0FBUyxPQUFPLFVBQVUsS0FBSyxJQUFJO0NBRXZDLENBQUMsQ0FBQyxNQUFNLElBQUksV0FBVyxLQUFLLE9BQU8sSUFBSTtDQUN2QyxXQUFXLElBQUksV0FBV1UsZUFBYSxTQUFTLFVBQVVFLFdBQVM7Q0FFbkUsSUFBSSxPQUFPLFdBQVcsSUFBSSxTQUN0QixPQUFPLFNBQVMsV0FBVyxJQUFJLFVBQVUsaUJBQWlCLGNBQWMsU0FBUyxDQUFDLEdBQUcsSUFBSSxNQUFNSCxjQUFZLE9BQU8sSUFBSSxLQUFLLGlCQUFpQixTQUFVLE9BQU87RUFDL0osT0FBTyxVQUFVLFNBQVMsUUFBUSxLQUFLLFFBQVEsUUFBUTtDQUN6RCxDQUFDO0NBQ0QsS0FBSyxTQUFTO0NBQ2QsU0FBUyxLQUFLLFNBQVNiLE9BQUssWUFBWSxTQUFTLGdCQUFnQixNQUFNO0NBRXZFLE9BQU87QUFDVDtJQUNJLG1CQUFtQixTQUFTLGlCQUFpQixPQUFPLGdCQUFnQixVQUFVO0NBQ2hGLElBQUksS0FBSyxPQUNMLEtBQUssT0FDTCxLQUFLWSxXQUFTLEdBQ2QsS0FBSyxJQUNMLE1BQU0sa0JBQWtCLElBQ3hCLGlCQUFpQixLQUFLLElBQUksS0FBSyxNQUFNLENBQUMsR0FDdEMsU0FBUyxTQUFTLE9BQU8sT0FBTyxPQUFPO0VBQ3pDLElBQUksSUFBSUEsV0FBUztFQUVqQixJQUFJLFNBQVMsSUFBSSxLQUFLLEtBQUs7R0FDekIsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztFQUNQLE9BQU8sSUFBSSxVQUNULE1BQU07T0FHTixLQUFLLE1BQU0sUUFBUSxPQUFPLElBQUksT0FBTyxLQUFLO0NBRTlDO0NBY0EsT0FBTztFQUNHO0VBQ1IsT0FBTyxTQWZZLFFBQVE7R0FDM0IsS0FBSyxLQUFLLFdBQVcsSUFBSTtHQUN6QixLQUFLLEtBQUs7RUFDWjtFQWFFLGFBQWEsU0FaWSxZQUFZLGFBQWE7R0FDbEQsSUFBSSxPQUFPLElBQ1AsT0FBTyxJQUNQLElBQUlBLFdBQVM7R0FFakIsQ0FBQyxlQUFlLGdCQUFnQixNQUFNLGdCQUFnQixNQUFNLE9BQU8sV0FBVztHQUM5RSxPQUFPLE9BQU8sTUFBTSxJQUFJLEtBQUssaUJBQWlCLEtBQUssTUFBTSxXQUFXLE9BQU8sQ0FBQyxXQUFXLFdBQVcsSUFBSSxNQUFNLFFBQVE7RUFDdEg7Q0FNQTtBQUNGO0lBQ0ksWUFBWSxTQUFTLFVBQVUsR0FBRyxnQkFBZ0I7Q0FDcEQsa0JBQWtCLENBQUMsRUFBRSxjQUFjLEVBQUUsZUFBZSxTQUFTLEVBQUUsZUFBZTtDQUM5RSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsZUFBZSxLQUFLO0FBQ2xEO0lBQ0ksa0JBQWtCLFNBQVMsZ0JBQWdCLEdBQUc7Q0FDaEQsSUFBSSxNQUFNLEtBQUssSUFBSSxNQUFNLE1BQU0sQ0FBQyxHQUM1QixNQUFNLEtBQUssSUFBSSxNQUFNLE1BQU0sQ0FBQztDQUNoQyxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxJQUFJLEdBQUcsSUFBSSxNQUFNO0FBQ2hEO0lBQ0ksb0JBQW9CLFNBQVMsb0JBQW9CO0NBQ25ELGtCQUFnQlosT0FBSyxLQUFLLFFBQVEsQ0FBQyxDQUFDO0NBQ3BDLG1CQUFpQk0sZ0JBQWMsUUFBUSxXQUFXO0FBQ3BEO0lBQ0ksWUFBWSxTQUFTLFVBQVUsTUFBTTtDQUN2QyxTQUFPLFFBQVFJLFdBQVM7Q0FFeEIsSUFBSSxDQUFDVCxrQkFBZ0JELFVBQVEsT0FBTyxhQUFhLGVBQWUsU0FBUyxNQUFNO0VBQzdFLFNBQU87RUFDUCxTQUFPO0VBQ1AsV0FBU0csT0FBSztFQUNkLFVBQVFBLE9BQUs7RUFDYixVQUFRO0dBQUNEO0dBQU1DO0dBQU1DO0dBQVFDO0VBQUs7RUFDbEMsT0FBYyxNQUFNO0VBRXBCLGFBQVdMLE9BQUssS0FBSyxXQUFXLFdBQVksQ0FBQztFQUU3QyxlQUFlLG9CQUFvQkssVUFBUSxZQUFZO0VBRXZELFdBQVcsU0FBUyxVQUFVSCxPQUFLLGNBQWNBLE9BQUssV0FBVyxrQ0FBa0MsQ0FBQyxDQUFDLFVBQVUsSUFBSSxrQkFBa0JBLFVBQVEsVUFBVSxpQkFBaUIsS0FBSyxVQUFVLG1CQUFtQixJQUFJLElBQUk7RUFDbE4sY0FBYyxTQUFTLGNBQWMsa0JBQWtCRSxXQUFTLDhDQUE4QyxFQUFFLG1CQUFtQkEsWUFBVSx3Q0FBd0Msa0RBQUEsQ0FBbUQsTUFBTSxHQUFHO0VBQ2pQLFdBQVcsV0FBWTtHQUNyQixPQUFPLGFBQVc7RUFDcEIsR0FBRyxHQUFHO0VBQ04saUJBQWU7Q0FDakI7Q0FFQSxtQkFBaUIsa0JBQWtCO0NBRW5DLE9BQU9IO0FBQ1Q7QUFFQSxZQUFZLEtBQUs7QUFDakIsV0FBVyxRQUFRO0FBQ25CLElBQVcsV0FBd0IseUJBQVk7Q0FDN0MsU0FBUyxTQUFTLE1BQU07RUFDdEIsS0FBSyxLQUFLLElBQUk7Q0FDaEI7Q0FFQSxJQUFJLFNBQVMsU0FBUztDQUV0QixPQUFPLE9BQU8sU0FBUyxLQUFLLE1BQU07RUFDaEMsa0JBQWdCLFVBQVVELE1BQUksS0FBSyxRQUFRLEtBQUssc0NBQXNDO0VBQ3RGLG1CQUFpQixrQkFBa0I7RUFDbkMsSUFBSSxZQUFZLEtBQUssV0FDakIsY0FBYyxLQUFLLGFBQ25CLE9BQU8sS0FBSyxNQUNaLFNBQVMsS0FBSyxRQUNkLGFBQWEsS0FBSyxZQUNsQixXQUFXLEtBQUssVUFDaEIsaUJBQWlCLEtBQUssZ0JBQ3RCLFNBQVMsS0FBSyxRQUNkLGNBQWMsS0FBSyxhQUNuQixTQUFTLEtBQUssUUFDZCxhQUFhLEtBQUssWUFDbEIsUUFBUSxLQUFLLE9BQ2IsY0FBYyxLQUFLLGFBQ25CLFlBQVksS0FBSyxXQUNqQixTQUFTLEtBQUssUUFDZCxVQUFVLEtBQUssU0FDZixZQUFZLEtBQUssV0FDakIsVUFBVSxLQUFLLFNBQ2YsU0FBUyxLQUFLLFFBQ2QsT0FBTyxLQUFLLE1BQ1osU0FBUyxLQUFLLFFBQ2QsWUFBWSxLQUFLLFdBQ2pCLFlBQVksS0FBSyxXQUNqQixXQUFXLEtBQUssVUFDaEIsWUFBWSxLQUFLLFdBQ2pCLFlBQVksS0FBSyxXQUNqQixVQUFVLEtBQUssU0FDZixhQUFhLEtBQUssWUFDbEIsU0FBUyxLQUFLLFFBQ2QsY0FBYyxLQUFLLGFBQ25CLGVBQWUsS0FBSyxjQUNwQixpQkFBaUIsS0FBSyxnQkFDdEIsZUFBZSxLQUFLLGNBQ3BCLFVBQVUsS0FBSyxTQUNmLFdBQVcsS0FBSyxVQUNoQixZQUFZLEtBQUssV0FDakIsVUFBVSxLQUFLLFNBQ2YsY0FBYyxLQUFLLGFBQ25CLFVBQVUsS0FBSyxTQUNmLGNBQWMsS0FBSyxhQUNuQixXQUFXLEtBQUssVUFDaEIsYUFBYSxLQUFLO0VBQ3RCLEtBQUssU0FBUyxTQUFTLFdBQVcsTUFBTSxLQUFLSTtFQUM3QyxLQUFLLE9BQU87RUFDWixXQUFXLFNBQVNKLE9BQUssTUFBTSxRQUFRLE1BQU07RUFDN0MsWUFBWSxhQUFhO0VBQ3pCLGNBQWMsZUFBZTtFQUM3QixhQUFhLGNBQWM7RUFDM0IsY0FBYyxlQUFlO0VBQzdCLE9BQU8sUUFBUTtFQUNmLFdBQVcsYUFBYTtFQUN4QixlQUFlLGFBQWEsV0FBV0UsT0FBSyxpQkFBaUJHLE9BQUssQ0FBQyxDQUFDLFVBQVUsS0FBSztFQUVuRixJQUFJLElBQ0EsbUJBQ0EsU0FDQSxPQUNBLFNBQ0EsUUFDQSxNQUNBLE9BQU8sTUFDUCxhQUFhLEdBQ2IsYUFBYSxHQUNiLFVBQVUsS0FBSyxXQUFXLENBQUMsa0JBQWtCLEtBQUssWUFBWSxPQUM5RCxjQUFjLGVBQWUsUUFBUSxXQUFXLEdBQ2hELGNBQWMsZUFBZSxRQUFRLFNBQVMsR0FDOUMsVUFBVSxZQUFZLEdBQ3RCLFVBQVUsWUFBWSxHQUN0QixlQUFlLENBQUMsS0FBSyxRQUFRLE9BQU8sS0FBSyxDQUFDLENBQUMsS0FBSyxRQUFRLFNBQVMsS0FBSyxZQUFZLE9BQU8sZUFFN0YsYUFBYVEsY0FBWSxNQUFNLEdBQzNCLFdBQVcsT0FBTyxpQkFBaUJWLFFBQ25DLFNBQVM7R0FBQztHQUFHO0dBQUc7RUFBQyxHQUVyQixTQUFTO0dBQUM7R0FBRztHQUFHO0VBQUMsR0FDYixjQUFjLEdBQ2QsZUFBZSxTQUFTLGVBQWU7R0FDekMsT0FBTyxjQUFjUyxXQUFTO0VBQ2hDLEdBQ0ksZUFBZSxTQUFTLGFBQWEsR0FBRyxrQkFBa0I7R0FDNUQsUUFBUSxLQUFLLFFBQVEsTUFBTSxVQUFVLFVBQVUsRUFBRSxRQUFRLE1BQU0sS0FBSyxvQkFBb0IsZ0JBQWdCLEVBQUUsZ0JBQWdCLFdBQVcsZUFBZSxZQUFZLEdBQUcsZ0JBQWdCO0VBQ3JMLEdBQ0ksYUFBYSxTQUFTLGFBQWE7R0FDckMsS0FBSyxJQUFJLE1BQU07R0FFZixLQUFLLElBQUksTUFBTTtHQUVmLGtCQUFrQixNQUFNO0dBQ3hCLFVBQVUsT0FBTyxJQUFJO0VBQ3ZCLEdBQ0ksU0FBUyxTQUFTLFNBQVM7R0FDN0IsSUFBSSxLQUFLLEtBQUssU0FBUyxnQkFBZ0IsTUFBTSxHQUN6QyxLQUFLLEtBQUssU0FBUyxnQkFBZ0IsTUFBTSxHQUN6QyxXQUFXLEtBQUssSUFBSSxFQUFFLEtBQUssV0FDM0IsV0FBVyxLQUFLLElBQUksRUFBRSxLQUFLO0dBRS9CLGFBQWEsWUFBWSxhQUFhLFNBQVMsTUFBTSxJQUFJLElBQUksUUFBUSxNQUFNO0dBRTNFLElBQUksVUFBVTtJQUNaLFdBQVcsS0FBSyxTQUFTLEtBQUssUUFBUSxJQUFJO0lBQzFDLFVBQVUsS0FBSyxTQUFTLEtBQUssT0FBTyxJQUFJO0lBQ3hDLGFBQWEsVUFBVSxJQUFJO0lBQzNCLGFBQWEsS0FBSyxTQUFTLE1BQU0sYUFBYSxLQUFLLFVBQVUsSUFBSTtJQUNqRSxhQUFhLEtBQUs7SUFDbEIsT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLEtBQUs7R0FDdEM7R0FFQSxJQUFJLFVBQVU7SUFDWixVQUFVLEtBQUssU0FBUyxLQUFLLE9BQU8sSUFBSTtJQUN4QyxRQUFRLEtBQUssU0FBUyxLQUFLLEtBQUssSUFBSTtJQUNwQyxhQUFhLFVBQVUsSUFBSTtJQUMzQixhQUFhLEtBQUssU0FBUyxNQUFNLGFBQWEsS0FBSyxVQUFVLElBQUk7SUFDakUsYUFBYSxLQUFLO0lBQ2xCLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLO0dBQ3RDO0dBRUEsSUFBSSxTQUFTLFNBQVM7SUFDcEIsVUFBVSxPQUFPLElBQUk7SUFFckIsSUFBSSxTQUFTO0tBQ1gsZUFBZSxZQUFZLEtBQUssWUFBWSxJQUFJO0tBQ2hELFVBQVUsT0FBTyxJQUFJO0tBQ3JCLFVBQVU7SUFDWjtJQUVBLFFBQVE7R0FDVjtHQUVBLFVBQVUsRUFBRSxTQUFTLFVBQVUsY0FBYyxXQUFXLElBQUk7R0FFNUQsSUFBSSxTQUFTO0lBQ1gsUUFBUSxJQUFJO0lBQ1osVUFBVTtHQUNaO0dBRUEsS0FBSztFQUNQLEdBQ0ksVUFBVSxTQUFTLFFBQVEsR0FBRyxHQUFHLE9BQU87R0FDMUMsT0FBTyxVQUFVO0dBQ2pCLE9BQU8sVUFBVTtHQUVqQixLQUFLLElBQUksT0FBTyxDQUFDO0dBRWpCLEtBQUssSUFBSSxPQUFPLENBQUM7R0FFakIsV0FBVyxPQUFPLEtBQUssc0JBQXNCLE1BQU0sS0FBSyxPQUFPO0VBQ2pFLEdBQ0ksd0JBQXdCLFNBQVMsc0JBQXNCLEdBQUcsR0FBRztHQUMvRCxJQUFJLFlBQVksQ0FBQyxNQUFNO0lBQ3JCLEtBQUssT0FBTyxPQUFPLEtBQUssSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxNQUFNO0lBQ3JELFNBQVM7R0FDWDtHQUVBLElBQUksU0FBUyxLQUFLO0lBQ2hCLE9BQU8sTUFBTTtJQUViLEtBQUssSUFBSSxPQUFPLEdBQUcsSUFBSTtHQUV6QjtHQUVBLElBQUksU0FBUyxLQUFLO0lBQ2hCLE9BQU8sTUFBTTtJQUViLEtBQUssSUFBSSxPQUFPLEdBQUcsSUFBSTtHQUN6QjtHQUVBLFdBQVcsT0FBTyxLQUFLLHNCQUFzQixNQUFNLEtBQUssT0FBTztFQUNqRSxHQUNJLFVBQVUsU0FBUyxRQUFRLEdBQUc7R0FDaEMsSUFBSSxhQUFhLEdBQUcsQ0FBQyxHQUNuQjtHQUdGLElBQUksVUFBVSxHQUFHLGNBQWM7R0FDL0IsSUFBSSxJQUFJLEVBQUUsU0FDTixJQUFJLEVBQUUsU0FDTixLQUFLLElBQUksS0FBSyxHQUNkLEtBQUssSUFBSSxLQUFLLEdBQ2QsYUFBYSxLQUFLO0dBQ3RCLEtBQUssSUFBSTtHQUNULEtBQUssSUFBSTtHQUVULElBQUksZUFBZSxNQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUssU0FBUyxDQUFDLEtBQUssZUFBZSxLQUFLLElBQUksS0FBSyxTQUFTLENBQUMsS0FBSyxjQUFjO0lBQ3RILFlBQVksVUFBVSxhQUFhLElBQUk7SUFFdkMsZUFBZSxLQUFLLGFBQWE7SUFDakMsc0JBQXNCLElBQUksRUFBRTtHQUM5QjtFQUNGLEdBQ0ksV0FBVyxLQUFLLFVBQVUsU0FBVSxHQUFHO0dBQ3pDLElBQUksYUFBYSxHQUFHLENBQUMsS0FBSyxLQUFLLEVBQUUsUUFDL0I7R0FHRixLQUFLLE9BQU8sT0FBTztHQUNuQixrQkFBa0IsTUFBTTtHQUN4QixLQUFLLFlBQVk7R0FDakIsSUFBSSxVQUFVLENBQUM7R0FFZixhQUFhLGFBQWE7R0FDMUIsS0FBSyxTQUFTLEtBQUssSUFBSSxFQUFFO0dBQ3pCLEtBQUssU0FBUyxLQUFLLElBQUksRUFBRTtHQUV6QixLQUFLLElBQUksTUFBTTtHQUdmLEtBQUssSUFBSSxNQUFNO0dBRWYsZUFBYSxlQUFlLFNBQVMsVUFBVSxZQUFZLElBQUksU0FBUyxTQUFTLElBQUk7R0FFckYsS0FBSyxTQUFTLEtBQUssU0FBUztHQUM1QixXQUFXLFFBQVEsSUFBSTtFQUN6QixHQUNJLGFBQWEsS0FBSyxZQUFZLFNBQVUsR0FBRztHQUM3QyxJQUFJLGFBQWEsR0FBRyxDQUFDLEdBQ25CO0dBR0Ysa0JBQWdCLGVBQWUsU0FBUyxVQUFVLFlBQVksSUFBSSxTQUFTLElBQUk7R0FFL0UsSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLEtBQUssSUFBSSxLQUFLLE1BQU0sR0FDNUMsY0FBYyxLQUFLLFlBQ25CLGlCQUFpQixnQkFBZ0IsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxNQUFNLElBQUksSUFFNUcsWUFBWSxVQUFVLENBQUM7R0FFdkIsSUFBSSxDQUFDLGtCQUFrQixnQkFBZ0I7SUFDckMsS0FBSyxJQUFJLE1BQU07SUFFZixLQUFLLElBQUksTUFBTTtJQUdmLElBQUksa0JBQWtCLGFBQ3BCLE9BQUssWUFBWSxLQUFNLFdBQVk7S0FFakMsSUFBSUEsV0FBUyxJQUFJLGNBQWMsT0FBTyxDQUFDLEVBQUU7VUFDbkMsRUFBRSxPQUFPLE9BRVgsRUFBRSxPQUFPLE1BQU07V0FDVixJQUFJLFNBQVMsYUFBYTtPQUMvQixJQUFJLGlCQUFpQixTQUFTLFlBQVksYUFBYTtPQUN2RCxlQUFlLGVBQWUsU0FBUyxNQUFNLE1BQU1WLFFBQU0sR0FBRyxVQUFVLFNBQVMsVUFBVSxTQUFTLFVBQVUsU0FBUyxVQUFVLFNBQVMsT0FBTyxPQUFPLE9BQU8sT0FBTyxHQUFHLElBQUk7T0FDM0ssRUFBRSxPQUFPLGNBQWMsY0FBYztNQUN2Qzs7SUFFSixDQUFDO0dBRUw7R0FFQSxLQUFLLGFBQWEsS0FBSyxjQUFjLEtBQUssWUFBWTtHQUN0RCxVQUFVLGVBQWUsQ0FBQyxnQkFBZ0Isa0JBQWtCLFFBQVEsSUFBSTtHQUN4RSxXQUFXLE9BQU87R0FFbEIsYUFBYSxlQUFlLFVBQVUsSUFBSTtHQUMxQyxhQUFhLFVBQVUsTUFBTSxjQUFjO0VBQzdDLEdBQ0ksa0JBQWtCLFNBQVMsZ0JBQWdCLEdBQUc7R0FDaEQsT0FBTyxFQUFFLFdBQVcsRUFBRSxRQUFRLFNBQVMsTUFBTSxLQUFLLGNBQWMsU0FBUyxlQUFlLEdBQUcsS0FBSyxVQUFVO0VBQzVHLEdBQ0ksZ0JBQWdCLFNBQVMsZ0JBQWdCO0dBQzNDLFFBQVEsS0FBSyxjQUFjLFVBQVUsYUFBYSxJQUFJO0VBQ3hELEdBQ0ksV0FBVyxTQUFTLFNBQVMsR0FBRztHQUNsQyxJQUFJLGFBQWEsQ0FBQyxHQUNoQjtHQUdGLElBQUksSUFBSSxZQUFZLEdBQ2hCLElBQUksWUFBWTtHQUNwQixTQUFTLElBQUksV0FBVyxjQUFjLElBQUksV0FBVyxhQUFhLENBQUM7R0FDbkUsVUFBVTtHQUNWLFVBQVU7R0FDVixVQUFVLGtCQUFrQixRQUFRLElBQUk7RUFDMUMsR0FDSSxXQUFXLFNBQVMsU0FBUyxHQUFHO0dBQ2xDLElBQUksYUFBYSxDQUFDLEdBQ2hCO0dBR0YsSUFBSSxVQUFVLEdBQUcsY0FBYztHQUMvQixZQUFZLFVBQVU7R0FDdEIsSUFBSSxjQUFjLEVBQUUsY0FBYyxJQUFJLGFBQWEsRUFBRSxjQUFjLElBQUlBLE9BQUssY0FBYyxLQUFLO0dBQy9GLFFBQVEsRUFBRSxTQUFTLFlBQVksRUFBRSxTQUFTLFlBQVksQ0FBQztHQUN2RCxVQUFVLENBQUMsZ0JBQWdCLGtCQUFrQixRQUFRLElBQUk7RUFDM0QsR0FDSSxVQUFVLFNBQVMsUUFBUSxHQUFHO0dBQ2hDLElBQUksYUFBYSxDQUFDLEdBQ2hCO0dBR0YsSUFBSSxJQUFJLEVBQUUsU0FDTixJQUFJLEVBQUUsU0FDTixLQUFLLElBQUksS0FBSyxHQUNkLEtBQUssSUFBSSxLQUFLO0dBQ2xCLEtBQUssSUFBSTtHQUNULEtBQUssSUFBSTtHQUNULFFBQVE7R0FDUixVQUFVLGtCQUFrQixRQUFRLElBQUk7R0FDeEMsQ0FBQyxNQUFNLE9BQU8sc0JBQXNCLElBQUksRUFBRTtFQUM1QyxHQUNJLFdBQVcsU0FBUyxTQUFTLEdBQUc7R0FDbEMsS0FBSyxRQUFRO0dBQ2IsUUFBUSxJQUFJO0VBQ2QsR0FDSSxjQUFjLFNBQVMsWUFBWSxHQUFHO0dBQ3hDLEtBQUssUUFBUTtHQUNiLFdBQVcsSUFBSTtFQUNqQixHQUNJLFdBQVcsU0FBUyxTQUFTLEdBQUc7R0FDbEMsT0FBTyxhQUFhLENBQUMsS0FBSyxVQUFVLEdBQUcsY0FBYyxLQUFLLFFBQVEsSUFBSTtFQUN4RTtFQUVBLG9CQUFvQixLQUFLLE1BQU1GLE9BQUssWUFBWSxlQUFlLEtBQU0sVUFBVSxDQUFDLENBQUMsTUFBTTtFQUN2RixLQUFLLFNBQVMsS0FBSyxTQUFTO0VBQzVCLEtBQUssTUFBTSxpQkFBaUIsR0FBRyxJQUFJLElBQUk7RUFDdkMsS0FBSyxNQUFNLGlCQUFpQixHQUFHLElBQUksSUFBSTtFQUN2QyxLQUFLLFVBQVU7RUFDZixLQUFLLFVBQVU7RUFDZixLQUFLLGFBQWEsS0FBSyxjQUFjLEtBQUssWUFBWTtFQUV0RCxXQUFTLElBQUk7RUFFYixLQUFLLFNBQVMsU0FBVSxHQUFHO0dBQ3pCLElBQUksQ0FBQyxLQUFLLFdBQVc7SUFDbkIsZUFBYSxhQUFhLFdBQVcsUUFBUSxVQUFVZ0IsV0FBUztJQUVoRSxLQUFLLFFBQVEsUUFBUSxLQUFLLEtBQUtGLGVBQWEsYUFBYSxXQUFXLFFBQVEsVUFBVSxVQUFVLFNBQVMsT0FBTztJQUNoSCxLQUFLLFFBQVEsT0FBTyxLQUFLLEtBQUtBLGVBQWEsUUFBUSxTQUFTLFVBQVUsU0FBUyxPQUFPO0lBRXRGLElBQUksS0FBSyxRQUFRLE9BQU8sS0FBSyxLQUFLLFlBQVksS0FBSyxRQUFRLFNBQVMsS0FBSyxHQUFHO0tBQzFFLGVBQWEsUUFBUSxZQUFZLElBQUksVUFBVSxTQUFTLE9BQU87S0FFL0QsZUFBYSxVQUFVLFlBQVksSUFBSSxVQUFVO0tBRWpELGVBQWEsVUFBVSxZQUFZLElBQUksVUFBVTtLQUVqRCxlQUFlQSxlQUFhLFFBQVEsU0FBUyxjQUFjLE1BQU0sSUFBSTtLQUNyRSxXQUFXQSxlQUFhLFFBQVEsU0FBUyxRQUFRO0tBQ2pELGtCQUFrQkEsZUFBYSxVQUFVLGdCQUFnQixlQUFlO0tBQ3hFLGdCQUFnQkEsZUFBYSxVQUFVLGNBQWMsYUFBYTtLQUNsRSxXQUFXQSxlQUFhLFFBQVEsZUFBZSxTQUFTLFFBQVE7S0FDaEUsY0FBY0EsZUFBYSxRQUFRLGVBQWUsU0FBUyxXQUFXO0tBQ3RFLFVBQVVBLGVBQWEsUUFBUSxlQUFlLFFBQVEsT0FBTztJQUMvRDtJQUVBLEtBQUssWUFBWTtJQUNqQixLQUFLLGFBQWEsS0FBSyxjQUFjLEtBQUssWUFBWSxRQUFRLFVBQVU7SUFFeEUsS0FBSyxJQUFJLE1BQU07SUFFZixLQUFLLElBQUksTUFBTTtJQUVmLFVBQVUsWUFBWTtJQUN0QixVQUFVLFlBQVk7SUFDdEIsS0FBSyxFQUFFLFFBQVEsU0FBUyxDQUFDO0lBQ3pCLFlBQVksU0FBUyxJQUFJO0dBQzNCO0dBRUEsT0FBTztFQUNUO0VBRUEsS0FBSyxVQUFVLFdBQVk7R0FDekIsSUFBSSxLQUFLLFdBQVc7SUFFbEIsV0FBVyxPQUFPLFNBQVUsR0FBRztLQUM3QixPQUFPLE1BQU0sUUFBUUQsY0FBWSxFQUFFLE1BQU07SUFDM0MsQ0FBQyxDQUFDLENBQUMsVUFBVUUsa0JBQWdCLGFBQWEsV0FBVyxRQUFRLFVBQVVDLFdBQVM7SUFFaEYsSUFBSSxLQUFLLFdBQVc7S0FDbEIsS0FBSyxJQUFJLE1BQU07S0FFZixLQUFLLElBQUksTUFBTTtLQUVmLGtCQUFnQixlQUFlLFNBQVMsVUFBVSxZQUFZLElBQUksU0FBUyxJQUFJO0lBQ2pGO0lBRUEsa0JBQWdCLGFBQWEsV0FBVyxRQUFRLFVBQVUsVUFBVSxPQUFPO0lBRTNFLGtCQUFnQixRQUFRLFNBQVMsVUFBVSxPQUFPO0lBRWxELGtCQUFnQixRQUFRLFlBQVksSUFBSSxVQUFVLE9BQU87SUFFekQsa0JBQWdCLFVBQVUsWUFBWSxJQUFJLFVBQVU7SUFFcEQsa0JBQWdCLFVBQVUsWUFBWSxJQUFJLFVBQVU7SUFFcEQsa0JBQWdCLFFBQVEsU0FBUyxjQUFjLElBQUk7SUFFbkQsa0JBQWdCLFFBQVEsU0FBUyxRQUFRO0lBRXpDLGtCQUFnQixVQUFVLGdCQUFnQixlQUFlO0lBRXpELGtCQUFnQixVQUFVLGNBQWMsYUFBYTtJQUVyRCxrQkFBZ0IsUUFBUSxlQUFlLFNBQVMsUUFBUTtJQUV4RCxrQkFBZ0IsUUFBUSxlQUFlLFNBQVMsV0FBVztJQUUzRCxrQkFBZ0IsUUFBUSxlQUFlLFFBQVEsT0FBTztJQUV0RCxLQUFLLFlBQVksS0FBSyxZQUFZLEtBQUssYUFBYTtJQUNwRCxhQUFhLFVBQVUsSUFBSTtHQUM3QjtFQUNGO0VBRUEsS0FBSyxPQUFPLEtBQUssU0FBUyxXQUFZO0dBQ3BDLEtBQUssUUFBUTtHQUViLElBQUksSUFBSSxXQUFXLFFBQVEsSUFBSTtHQUUvQixLQUFLLEtBQUssV0FBVyxPQUFPLEdBQUcsQ0FBQztHQUNoQyxrQkFBZ0IsU0FBUyxnQkFBYztFQUN6QztFQUVBLFdBQVcsS0FBSyxJQUFJO0VBRXBCLGdCQUFnQkgsY0FBWSxNQUFNLE1BQU0sZ0JBQWM7RUFDdEQsS0FBSyxPQUFPLEtBQUs7Q0FDbkI7Q0FFQSxhQUFhLFVBQVUsQ0FBQztFQUN0QixLQUFLO0VBQ0wsS0FBSyxTQUFTLE1BQU07R0FDbEIsT0FBTyxLQUFLLElBQUksWUFBWTtFQUM5QjtDQUNGLEdBQUc7RUFDRCxLQUFLO0VBQ0wsS0FBSyxTQUFTLE1BQU07R0FDbEIsT0FBTyxLQUFLLElBQUksWUFBWTtFQUM5QjtDQUNGLENBQUMsQ0FBQztDQUVGLE9BQU87QUFDVCxFQUFFO0FBQ0YsU0FBUyxVQUFVO0FBRW5CLFNBQVMsU0FBUyxTQUFVLE1BQU07Q0FDaEMsT0FBTyxJQUFJLFNBQVMsSUFBSTtBQUMxQjtBQUVBLFNBQVMsV0FBVztBQUVwQixTQUFTLFNBQVMsV0FBWTtDQUM1QixPQUFPLFdBQVcsTUFBTTtBQUMxQjtBQUVBLFNBQVMsVUFBVSxTQUFVLElBQUk7Q0FDL0IsT0FBTyxXQUFXLE9BQU8sU0FBVSxHQUFHO0VBQ3BDLE9BQU8sRUFBRSxLQUFLLE9BQU87Q0FDdkIsQ0FBQyxDQUFDLENBQUM7QUFDTDtBQUVBSCxXQUFTLEtBQUtWLE9BQUssZUFBZSxRQUFROzs7Ozs7Ozs7OztBQ3JyQjFDLElBQUk7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFFSixXQUFXO0lBQ1AsV0FBVyxLQUFLO0lBQ2hCLFNBQVMsU0FBUztJQUNsQixrQkFBa0I7SUFDbEIsV0FBVztJQUNYLGNBQWMsU0FBUyxZQUFZLE9BQU8sTUFBTSxNQUFNO0NBQ3hELElBQUksUUFBUSxVQUFVLEtBQUssTUFBTSxNQUFNLE9BQU8sR0FBRyxDQUFDLE1BQU0sWUFBWSxNQUFNLFFBQVEsS0FBSyxJQUFJO0NBQzNGLEtBQUssTUFBTSxPQUFPLFdBQVc7Q0FDN0IsT0FBTyxRQUFRLE1BQU0sT0FBTyxHQUFHLE1BQU0sU0FBUyxDQUFDLElBQUk7QUFDckQ7SUFDSSxhQUFhLFNBQVMsV0FBVyxPQUFPLE9BQU87Q0FDakQsT0FBTyxVQUFVLENBQUMsVUFBVSxLQUFLLEtBQUssTUFBTSxPQUFPLEdBQUcsQ0FBQyxNQUFNLFlBQVksV0FBVyxRQUFRLE1BQU07QUFDcEc7SUFDSSxhQUFhLFNBQVMsYUFBYTtDQUNyQyxPQUFPLFlBQVksc0JBQXNCLFVBQVU7QUFDckQ7SUFFQSxzQkFBc0IsU0FBUyxzQkFBc0I7Q0FDbkQsT0FBTyxpQkFBaUI7QUFDMUI7SUFDSSxvQkFBb0IsU0FBUyxvQkFBb0I7Q0FDbkQsT0FBTyxpQkFBaUI7QUFDMUI7SUFDSSxlQUFlLFNBQVMsYUFBYSxHQUFHO0NBQzFDLE9BQU87QUFDVDtJQUNJLFNBQVMsU0FBUyxPQUFPLE9BQU87Q0FDbEMsT0FBTyxLQUFLLE1BQU0sUUFBUSxHQUFNLElBQUksT0FBVTtBQUNoRDtJQUNJLGdCQUFnQixTQUFTLGdCQUFnQjtDQUMzQyxPQUFPLE9BQU8sV0FBVztBQUMzQjtJQUNJLFdBQVcsU0FBUyxXQUFXO0NBQ2pDLE9BQU8sUUFBUSxjQUFjLE1BQU0sT0FBTyxPQUFPLFNBQVMsS0FBSyxrQkFBa0I7QUFDbkY7SUFDSSxjQUFjLFNBQVMsWUFBWSxHQUFHO0NBQ3hDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxRQUFRLENBQUM7QUFDM0I7SUFDSSx3QkFBd0IsU0FBUyxzQkFBc0IsbUJBQW1CO0NBQzVFLFFBQVEsc0JBQXNCLFdBQVcsU0FBUyxLQUFLLFVBQVUsdUJBQXVCLE9BQU8sV0FBVyxzQkFBc0IsTUFBTSxXQUFXO0FBQ25KO0lBQ0ksaUJBQWlCLFNBQVMsZUFBZSxTQUFTO0NBQ3BELE9BQU8sY0FBYyxTQUFTLHVCQUF1QixNQUFNLFlBQVksT0FBTyxJQUFJLFdBQVk7RUFDNUYsWUFBWSxRQUFRLEtBQUs7RUFDekIsWUFBWSxTQUFTO0VBQ3JCLE9BQU87Q0FDVCxJQUFJLFdBQVk7RUFDZCxPQUFPLFdBQVcsT0FBTztDQUMzQjtBQUNGO0lBQ0ksZUFBZSxTQUFTLGFBQWEsVUFBVSxZQUFZLE1BQU07Q0FDbkUsSUFBSSxJQUFJLEtBQUssR0FDVCxLQUFLLEtBQUssSUFDVixJQUFJLEtBQUs7Q0FDYixRQUFRLElBQUksY0FBYyxVQUFVLHVCQUF1QixLQUFLLFdBQVk7RUFDMUUsT0FBTyxFQUFFLENBQUMsQ0FBQztDQUNiLElBQUksV0FBWTtFQUNkLFFBQVEsYUFBYSxzQkFBc0IsRUFBRSxJQUFJLFNBQVMsV0FBVyxRQUFRO0NBQy9FO0FBQ0Y7SUFDSSxrQkFBa0IsU0FBUyxnQkFBZ0IsU0FBUyxZQUFZO0NBQ2xFLE9BQU8sQ0FBQyxjQUFjLENBQUMsU0FBUyxRQUFRLE9BQU8sSUFBSSxlQUFlLE9BQU8sSUFBSSxXQUFZO0VBQ3ZGLE9BQU87Q0FDVDtBQUNGO0lBQ0ksYUFBYSxTQUFTLFdBQVcsU0FBUyxPQUFPO0NBQ25ELElBQUksSUFBSSxNQUFNLEdBQ1YsS0FBSyxNQUFNLElBQ1gsSUFBSSxNQUFNLEdBQ1YsSUFBSSxNQUFNO0NBQ2QsT0FBTyxLQUFLLElBQUksSUFBSSxJQUFJLFdBQVcsUUFBUSxJQUFJLGNBQWMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLGVBQWUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssWUFBWSxPQUFPLEtBQUssT0FBTyxNQUFNLE1BQU0sTUFBTSxzQkFBc0IsRUFBRSxJQUFJLFFBQVEsS0FBSyxRQUFRLFdBQVcsR0FBRztBQUNuTztJQUNJLHNCQUFzQixTQUFTLG9CQUFvQixNQUFNLFFBQVE7Q0FDbkUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLLEdBQzVDLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxRQUFRLGFBQWEsSUFBSSxFQUFFLE1BQU0sS0FBSyxhQUFhLElBQUksYUFBYSxJQUFJLElBQUksYUFBYSxJQUFJLEVBQUU7QUFFdkg7SUFDSSxZQUFZLFNBQVMsVUFBVSxPQUFPO0NBQ3hDLE9BQU8sT0FBTyxVQUFVO0FBQzFCO0lBQ0ksY0FBYyxTQUFTLFlBQVksT0FBTztDQUM1QyxPQUFPLE9BQU8sVUFBVTtBQUMxQjtJQUNJLFlBQVksU0FBUyxVQUFVLE9BQU87Q0FDeEMsT0FBTyxPQUFPLFVBQVU7QUFDMUI7SUFDSSxZQUFZLFNBQVMsVUFBVSxPQUFPO0NBQ3hDLE9BQU8sT0FBTyxVQUFVO0FBQzFCO0lBQ0ksZ0JBQWdCLFNBQVMsY0FBYyxXQUFXLFVBQVUsT0FBTztDQUNyRSxPQUFPLGFBQWEsVUFBVSxTQUFTLFdBQVcsSUFBSSxDQUFDLEtBQUssU0FBUyxVQUFVLE1BQU07QUFDdkY7SUFDSSxZQUFZLFNBQVMsVUFBVSxNQUFNLE1BQU0sWUFBWTtDQUN6RCxJQUFJLEtBQUssU0FBUztFQUNoQixJQUFJLFNBQVMsS0FBSyxPQUFPLEtBQUssS0FBSyxJQUFJLFdBQVk7R0FDakQsT0FBTyxLQUFLLE1BQU0sVUFBVTtFQUM5QixDQUFDLElBQUksS0FBSyxNQUFNLFVBQVU7RUFDMUIsVUFBVSxPQUFPLGNBQWMsS0FBSyxvQkFBb0I7Q0FDMUQ7QUFDRjtJQUNJLE9BQU8sS0FBSztJQUNaLFFBQVE7SUFDUixPQUFPO0lBQ1AsU0FBUztJQUNULFVBQVU7SUFDVixTQUFTO0lBQ1QsVUFBVTtJQUNWLFNBQVM7SUFDVCxRQUFRO0lBQ1IsT0FBTztJQUNQLFVBQVU7SUFDVixXQUFXO0lBQ1gsVUFBVTtJQUNWLFNBQVM7SUFDVCxVQUFVO0lBQ1YsTUFBTTtJQUNOLG9CQUFvQixTQUFTLGtCQUFrQixTQUFTO0NBQzFELE9BQU8sS0FBSyxpQkFBaUIsUUFBUSxhQUFhLEtBQUssZ0JBQWdCLFFBQVEsbUJBQW1CLE9BQU87QUFDM0c7SUFDSSxvQkFBb0IsU0FBUyxrQkFBa0IsU0FBUztDQUUxRCxJQUFJLFdBQVcsa0JBQWtCLE9BQU8sQ0FBQyxDQUFDO0NBRTFDLFFBQVEsTUFBTSxXQUFXLGFBQWEsY0FBYyxhQUFhLFVBQVUsV0FBVztBQUN4RjtJQUNJLGVBQWUsU0FBUyxhQUFhLEtBQUssVUFBVTtDQUN0RCxLQUFLLElBQUksS0FBSyxVQUNaLEtBQUssUUFBUSxJQUFJLEtBQUssU0FBUztDQUdqQyxPQUFPO0FBQ1Q7SUFDSSxhQUFhLFNBQVMsV0FBVyxTQUFTLG1CQUFtQjtDQUMvRCxJQUFJLFFBQVEscUJBQXFCLGtCQUFrQixPQUFPLENBQUMsQ0FBQyxvQkFBb0IsOEJBQThCLEtBQUssR0FBRyxTQUFTO0VBQzdILEdBQUc7RUFDSCxHQUFHO0VBQ0gsVUFBVTtFQUNWLFVBQVU7RUFDVixVQUFVO0VBQ1YsV0FBVztFQUNYLFdBQVc7RUFDWCxPQUFPO0VBQ1AsT0FBTztFQUNQLE9BQU87Q0FDVCxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FDVCxTQUFTLFFBQVEsd0JBQXdCLFFBQVEsc0JBQXNCLElBQUksUUFBUSxpQkFBaUIsc0JBQXNCO0NBQzlILFNBQVMsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUs7Q0FDaEMsT0FBTztBQUNUO0lBQ0ksV0FBVyxTQUFTLFNBQVMsU0FBUyxPQUFPO0NBQy9DLElBQUksS0FBSyxNQUFNO0NBQ2YsT0FBTyxRQUFRLFdBQVcsT0FBTyxRQUFRLFdBQVcsT0FBTztBQUM3RDtJQUNJLHNCQUFzQixTQUFTLG9CQUFvQixVQUFVO0NBQy9ELElBQUksSUFBSSxDQUFDLEdBQ0wsU0FBUyxTQUFTLFFBQ2xCLFdBQVcsU0FBUyxTQUFTLEdBQzdCO0NBRUosS0FBSyxLQUFLLFFBQ1IsRUFBRSxLQUFLLE9BQU8sS0FBSyxRQUFRO0NBRzdCLE9BQU87QUFDVDtJQUNJLG1CQUFtQixTQUFTLGlCQUFpQixXQUFXO0NBQzFELE9BQU8sU0FBVSxPQUFPO0VBQ3RCLE9BQU8sS0FBSyxNQUFNLEtBQUssb0JBQW9CLFNBQVMsR0FBRyxLQUFLO0NBQzlEO0FBQ0Y7SUFDSSxtQkFBbUIsU0FBUyxpQkFBaUIsc0JBQXNCO0NBQ3JFLElBQUksT0FBTyxLQUFLLE1BQU0sS0FBSyxvQkFBb0IsR0FDM0MsSUFBSSxNQUFNLFFBQVEsb0JBQW9CLEtBQUsscUJBQXFCLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLEdBQUcsR0FBRztFQUNoRyxPQUFPLElBQUk7Q0FDYixDQUFDO0NBQ0QsT0FBTyxJQUFJLFNBQVUsT0FBTyxXQUFXLFdBQVc7RUFDaEQsSUFBSSxjQUFjLEtBQUssR0FDckIsWUFBWTtFQUdkLElBQUk7RUFFSixJQUFJLENBQUMsV0FDSCxPQUFPLEtBQUssS0FBSztFQUduQixJQUFJLFlBQVksR0FBRztHQUNqQixTQUFTO0dBRVQsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FDeEIsSUFBSSxFQUFFLE1BQU0sT0FDVixPQUFPLEVBQUU7R0FJYixPQUFPLEVBQUUsSUFBSTtFQUNmLE9BQU87R0FDTCxJQUFJLEVBQUU7R0FDTixTQUFTO0dBRVQsT0FBTyxLQUNMLElBQUksRUFBRSxNQUFNLE9BQ1YsT0FBTyxFQUFFO0VBR2Y7RUFFQSxPQUFPLEVBQUU7Q0FDWCxJQUFJLFNBQVUsT0FBTyxXQUFXLFdBQVc7RUFDekMsSUFBSSxjQUFjLEtBQUssR0FDckIsWUFBWTtFQUdkLElBQUksVUFBVSxLQUFLLEtBQUs7RUFDeEIsT0FBTyxDQUFDLGFBQWEsS0FBSyxJQUFJLFVBQVUsS0FBSyxJQUFJLGFBQWEsVUFBVSxRQUFRLE1BQU0sWUFBWSxJQUFJLFVBQVUsS0FBSyxZQUFZLElBQUksUUFBUSx1QkFBdUIsUUFBUSxvQkFBb0I7Q0FDbE07QUFDRjtJQUNJLHVCQUF1QixTQUFTLHFCQUFxQixVQUFVO0NBQ2pFLE9BQU8sU0FBVSxPQUFPLElBQUk7RUFDMUIsT0FBTyxpQkFBaUIsb0JBQW9CLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLFNBQVM7Q0FDNUU7QUFDRjtJQUNJLGlCQUFpQixTQUFTLGVBQWUsTUFBTSxTQUFTLE9BQU8sVUFBVTtDQUMzRSxPQUFPLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxRQUFRLFNBQVUsTUFBTTtFQUM5QyxPQUFPLEtBQUssU0FBUyxNQUFNLFFBQVE7Q0FDckMsQ0FBQztBQUNIO0lBQ0ksZUFBZSxTQUFTLGFBQWEsU0FBUyxNQUFNLE1BQU0sWUFBWSxTQUFTO0NBQ2pGLE9BQU8sUUFBUSxpQkFBaUIsTUFBTSxNQUFNO0VBQzFDLFNBQVMsQ0FBQztFQUNWLFNBQVMsQ0FBQyxDQUFDO0NBQ2IsQ0FBQztBQUNIO0lBQ0ksa0JBQWtCLFNBQVMsZ0JBQWdCLFNBQVMsTUFBTSxNQUFNLFNBQVM7Q0FDM0UsT0FBTyxRQUFRLG9CQUFvQixNQUFNLE1BQU0sQ0FBQyxDQUFDLE9BQU87QUFDMUQ7SUFDSSxpQkFBaUIsU0FBUyxlQUFlLE1BQU0sSUFBSSxZQUFZO0NBQ2pFLGFBQWEsY0FBYyxXQUFXO0NBRXRDLElBQUksWUFBWTtFQUNkLEtBQUssSUFBSSxTQUFTLFVBQVU7RUFDNUIsS0FBSyxJQUFJLGFBQWEsVUFBVTtDQUNsQztBQUNGO0lBQ0ksa0JBQWtCO0NBQ3BCLFlBQVk7Q0FDWixVQUFVO0NBQ1YsUUFBUTtDQUNSLFVBQVU7Q0FDVixZQUFZO0FBQ2Q7SUFDSSxZQUFZO0NBQ2QsZUFBZTtDQUNmLGVBQWU7QUFDakI7SUFDSSxZQUFZO0NBQ2QsS0FBSztDQUNMLE1BQU07Q0FDTixRQUFRO0NBQ1IsUUFBUTtDQUNSLE9BQU87QUFDVDtJQUNJLGNBQWMsU0FBUyxZQUFZLE9BQU8sTUFBTTtDQUNsRCxJQUFJLFVBQVUsS0FBSyxHQUFHO0VBQ3BCLElBQUksVUFBVSxNQUFNLFFBQVEsR0FBRyxHQUMzQixXQUFXLENBQUMsVUFBVSxFQUFFLE1BQU0sT0FBTyxVQUFVLENBQUMsSUFBSSxLQUFLLFdBQVcsTUFBTSxPQUFPLFVBQVUsQ0FBQyxDQUFDLElBQUk7RUFFckcsSUFBSSxDQUFDLFNBQVM7R0FDWixNQUFNLFFBQVEsR0FBRyxJQUFJLFlBQVksWUFBWSxPQUFPO0dBQ3BELFFBQVEsTUFBTSxPQUFPLEdBQUcsVUFBVSxDQUFDO0VBQ3JDO0VBRUEsUUFBUSxZQUFZLFNBQVMsWUFBWSxVQUFVLFNBQVMsT0FBTyxDQUFDLE1BQU0sUUFBUSxHQUFHLElBQUksV0FBVyxLQUFLLElBQUksT0FBTyxNQUFNLFdBQVcsS0FBSyxLQUFLO0NBQ2pKO0NBRUEsT0FBTztBQUNUO0lBQ0ksZ0JBQWdCLFNBQVMsY0FBYyxNQUFNLE1BQU0sV0FBVyxXQUFXLE9BQU8sUUFBUSxjQUFjLG9CQUFvQjtDQUM1SCxJQUFJLGFBQWEsTUFBTSxZQUNuQixXQUFXLE1BQU0sVUFDakIsV0FBVyxNQUFNLFVBQ2pCLFNBQVMsTUFBTSxRQUNmLGFBQWEsTUFBTTtDQUV2QixJQUFJLElBQUksS0FBSyxjQUFjLEtBQUssR0FDNUIsbUJBQW1CLFlBQVksU0FBUyxLQUFLLGNBQWMsV0FBVyxTQUFTLE1BQU0sU0FDckYsYUFBYSxLQUFLLFFBQVEsVUFBVSxNQUFNLElBQzFDLFNBQVMsbUJBQW1CLFFBQVEsVUFBVSxZQUFZLFdBQVcsVUFBVSxnQkFBZ0IsT0FBTyxXQUN0RyxVQUFVLEtBQUssUUFBUSxPQUFPLE1BQU0sSUFDcEMsUUFBUSxVQUFVLGFBQWEsVUFDL0IsTUFBTSxrQkFBa0IsUUFBUSxnQkFBZ0IsV0FBVyxZQUFZLFFBQVEsa0JBQWtCLGFBQWE7Q0FFbEgsT0FBTyxnQkFBZ0IsY0FBYyx1QkFBdUIsbUJBQW1CLFdBQVc7Q0FDMUYsQ0FBQyxjQUFjLHNCQUFzQixDQUFDLHNCQUFzQixRQUFRLGNBQWMsWUFBWSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsTUFBTSxLQUFLO0NBQ3hKLGlCQUFpQixPQUFPLGlEQUFpRCxhQUFhLGNBQWM7Q0FDcEcsRUFBRSxXQUFXO0NBQ2IsRUFBRSxhQUFhLFNBQVMsaUJBQWlCLFFBQVEsT0FBTyxhQUFhLE9BQU8sR0FBRztDQUMvRSxFQUFFLE1BQU0sVUFBVTtDQUNsQixFQUFFLFlBQVksUUFBUSxTQUFTLElBQUksT0FBTyxNQUFNLE9BQU87Q0FDdkQsT0FBTyxTQUFTLEtBQUssT0FBTyxhQUFhLEdBQUcsT0FBTyxTQUFTLEVBQUUsSUFBSSxPQUFPLFlBQVksQ0FBQztDQUN0RixFQUFFLFVBQVUsRUFBRSxXQUFXLFVBQVUsR0FBRztDQUV0QyxnQkFBZ0IsR0FBRyxHQUFHLFdBQVcsT0FBTztDQUV4QyxPQUFPO0FBQ1Q7SUFDSSxrQkFBa0IsU0FBUyxnQkFBZ0IsUUFBUSxPQUFPLFdBQVcsU0FBUztDQUNoRixJQUFJLE9BQU8sRUFDVCxTQUFTLFFBQ1gsR0FDSSxPQUFPLFVBQVUsVUFBVSxRQUFRLE9BQ25DLGVBQWUsVUFBVSxVQUFVLE9BQU87Q0FDOUMsT0FBTyxhQUFhO0NBQ3BCLEtBQUssVUFBVSxJQUFJLGFBQWEsVUFBVSxPQUFPO0NBQ2pELEtBQUssVUFBVSxLQUFLLFVBQVUsUUFBUTtDQUN0QyxLQUFLLFdBQVcsT0FBTyxVQUFVO0NBQ2pDLEtBQUssV0FBVyxlQUFlLFVBQVU7Q0FDekMsS0FBSyxVQUFVLEtBQUssUUFBUTtDQUM1QixLQUFLLElBQUksUUFBUSxJQUFJO0FBQ3ZCO0lBQ0ksWUFBWSxDQUFDO0lBQ2IsT0FBTyxDQUFDO0lBQ1I7SUFDQSxRQUFRLFNBQVMsUUFBUTtDQUMzQixPQUFPLFNBQVMsSUFBSSxrQkFBa0IsT0FBTyxXQUFXLFNBQVMsc0JBQXNCLFVBQVU7QUFDbkc7SUFDSSxZQUFZLFNBQVMsWUFBWTtDQUVuQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksYUFBYSxZQUFZLFNBQVMsTUFBTSxhQUFhO0VBRXBGLFdBQVc7RUFFWCxJQUFJLGFBQ0YsV0FBVyxTQUFTLHNCQUFzQixVQUFVO09BRXBELFdBQVc7RUFJYixtQkFBbUIsVUFBVSxhQUFhO0VBQzFDLGtCQUFrQixTQUFTO0NBQzdCO0FBQ0Y7SUFDSSxxQkFBcUIsU0FBUyxxQkFBcUI7Q0FDckQsbUJBQW1CLEtBQUs7Q0FDeEIsb0JBQW9CLEtBQUs7QUFDM0I7SUFDSSxZQUFZLFNBQVMsVUFBVSxPQUFPO0NBQ3hDLFdBQVc7Q0FDWCxDQUFDLFVBQVUsUUFBUSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLHFCQUFxQixDQUFDLEtBQUssNEJBQTRCLENBQUMsdUJBQXVCLHFCQUFxQixLQUFLLGNBQWMsS0FBSyxJQUFJLEtBQUssY0FBYyxpQkFBaUIsSUFBSSxLQUFLLGNBQWMsU0FBVSxhQUFhLFFBQVEsSUFBSTtBQUMzUjtJQUVBLGFBQWEsQ0FBQztJQUNWLGNBQWMsQ0FBQztJQUNmLGVBQWUsU0FBUyxlQUFlO0NBQ3pDLE9BQU8sZ0JBQWdCLGVBQWUsYUFBYSxZQUFZLEtBQUssWUFBWSxJQUFJO0FBQ3RGO0lBQ0ksWUFBWSxTQUFTLFVBQVUsTUFBTTtDQUN2QyxPQUFPLFdBQVcsU0FBUyxXQUFXLEtBQUssQ0FBQyxJQUFJLFNBQVUsR0FBRztFQUMzRCxPQUFPLEVBQUU7Q0FDWCxDQUFDLEtBQUs7QUFDUjtJQUNJLGVBQWUsQ0FBQztJQUVwQixrQkFBa0IsU0FBUyxnQkFBZ0IsT0FBTztDQUNoRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQUssR0FDNUMsSUFBSSxDQUFDLFNBQVMsYUFBYSxJQUFJLE1BQU0sYUFBYSxJQUFJLEVBQUUsQ0FBQyxVQUFVLE9BQU87RUFDeEUsYUFBYSxFQUFFLENBQUMsTUFBTSxVQUFVLGFBQWEsSUFBSTtFQUNqRCxhQUFhLEVBQUUsQ0FBQyxXQUFXLGFBQWEsRUFBRSxDQUFDLGFBQWEsYUFBYSxhQUFhLElBQUksTUFBTSxFQUFFO0VBQzlGLGFBQWEsSUFBSSxFQUFFLENBQUMsVUFBVTtDQUNoQztBQUVKO0lBQ0kseUJBQXlCLFNBQVMseUJBQXlCO0NBQzdELE9BQU8sV0FBVyxRQUFRLFNBQVUsS0FBSztFQUN2QyxPQUFPLFlBQVksR0FBRyxLQUFLLEVBQUUsSUFBSSxZQUFZLElBQUksTUFBTSxJQUFJO0NBQzdELENBQUM7QUFDSDtJQUVBLGFBQWEsU0FBUyxXQUFXLE1BQU0sT0FBTztDQUM1QyxJQUFJO0NBRUosS0FBSyxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFBTTtFQUN4QyxVQUFVLFVBQVU7RUFFcEIsSUFBSSxZQUFZLENBQUMsU0FBUyxRQUFRLFNBQVMsUUFDekMsSUFBSSxNQUNGLFFBQVEsS0FBSyxDQUFDO09BRWQsUUFBUSxPQUFPLE1BQU0sSUFBSTtDQUcvQjtDQUVBLGNBQWM7Q0FDZCxTQUFTLGdCQUFnQixLQUFLO0NBQzlCLFNBQVMsVUFBVSxRQUFRO0FBQzdCO0lBQ0kscUJBQXFCLFNBQVMsbUJBQW1CLG1CQUFtQixPQUFPO0NBRTdFLFdBQVc7Q0FDWCxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsV0FBVyxRQUFRLFNBQVUsS0FBSztFQUM5RCxPQUFPLFlBQVksR0FBRyxLQUFLLElBQUksY0FBYyxJQUFJLE1BQU07Q0FDekQsQ0FBQztDQUNELFVBQVUsaUJBQWlCLE1BQU0sS0FBSyxRQUFRLG9CQUFvQixxQkFBcUI7QUFDekY7SUFDSTtJQUNBLGFBQWE7SUFDYjtJQUNBLG1CQUFtQixTQUFTLG1CQUFtQjtDQUVqRCxJQUFJLG9CQUFvQixZQUFZO0VBQ2xDLElBQUksS0FBSyxrQkFBa0I7RUFDM0Isc0JBQXNCLFdBQVk7R0FDaEMsT0FBTyxPQUFPLGNBQWMsWUFBWSxJQUFJO0VBQzlDLENBQUM7Q0FDSDtBQUNGO0lBQ0ksZ0JBQWdCLFNBQVMsZ0JBQWdCO0NBQzNDLE1BQU0sWUFBWSxTQUFTO0NBRTNCLFNBQVMsQ0FBQyxlQUFlLFVBQVUsZ0JBQWdCLEtBQUs7Q0FFeEQsTUFBTSxZQUFZLFNBQVM7QUFDN0I7SUFDSSxrQkFBa0IsU0FBUyxnQkFBZ0IsTUFBTTtDQUNuRCxPQUFPLFNBQVMsOEZBQThGLENBQUMsQ0FBQyxRQUFRLFNBQVUsSUFBSTtFQUNwSSxPQUFPLEdBQUcsTUFBTSxVQUFVLE9BQU8sU0FBUztDQUM1QyxDQUFDO0FBQ0g7SUFDSSxjQUFjLFNBQVMsWUFBWSxPQUFPLFlBQVk7Q0FDeEQsU0FBUyxLQUFLO0NBRWQsUUFBUSxLQUFLO0NBQ2IsUUFBUTtFQUFDO0VBQU07RUFBTTtFQUFRO0NBQUs7Q0FFbEMsSUFBSSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsYUFBYTtFQUM3QyxhQUFhLGVBQWUsYUFBYSxZQUFZO0VBRXJEO0NBQ0Y7Q0FFQSxjQUFjO0NBRWQsaUJBQWlCLGNBQWMsZUFBZTtDQUM5QyxlQUFlLHVCQUF1QjtDQUV0QyxJQUFJLGVBQWUsVUFBVSxhQUFhO0NBRTFDLFNBQVMsY0FBYyxLQUFLO0NBQzVCLGNBQWMsV0FBVztDQUV6QixXQUFXLFFBQVEsU0FBVSxLQUFLO0VBQ2hDLElBQUksWUFBWSxHQUFHLEdBQUc7R0FDcEIsSUFBSSxXQUFXLElBQUksT0FBTyxNQUFNLGlCQUFpQjtHQUVqRCxJQUFJLENBQUM7RUFDUDtDQUNGLENBQUM7Q0FFRCxVQUFVLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFVLEdBQUc7RUFDdEMsT0FBTyxFQUFFLFFBQVE7Q0FDbkIsQ0FBQztDQUdELGNBQWM7Q0FFZCxVQUFVLFFBQVEsU0FBVSxHQUFHO0VBRTdCLElBQUksRUFBRSxpQkFBaUIsRUFBRSxLQUFLO0dBQzVCLElBQUksT0FBTyxFQUFFLEtBQUssYUFBYSxnQkFBZ0IsZ0JBQzNDLFdBQVcsRUFBRSxJQUFJO0dBQ3JCLEVBQUUsT0FBTyxNQUFNLENBQUM7R0FDaEIsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLFFBQVEsUUFBUTtHQUN6QyxFQUFFLFFBQVE7RUFDWjtDQUNGLENBQUM7Q0FFRCxlQUFlO0NBRWYsZ0JBQWdCLElBQUk7Q0FFcEIsVUFBVSxRQUFRLFNBQVUsR0FBRztFQUU3QixJQUFJLE1BQU0sV0FBVyxFQUFFLFVBQVUsRUFBRSxJQUFJLEdBQ25DLFdBQVcsRUFBRSxLQUFLLFFBQVEsU0FBUyxFQUFFLGFBQWEsRUFBRSxNQUFNLEtBQzFELGFBQWEsRUFBRSxlQUFlLEVBQUUsU0FBUztFQUU3QyxDQUFDLFlBQVksZUFBZSxFQUFFLGFBQWEsYUFBYSxNQUFNLElBQUksRUFBRSxPQUFPLFdBQVcsS0FBSyxJQUFJLGFBQWEsTUFBTSxFQUFFLFFBQVEsR0FBRyxHQUFHLElBQUksRUFBRSxLQUFLLElBQUk7Q0FDbkosQ0FBQztDQUVELGdCQUFnQixLQUFLO0NBRXJCLGVBQWU7Q0FDZixhQUFhLFFBQVEsU0FBVSxRQUFRO0VBQ3JDLE9BQU8sVUFBVSxPQUFPLFVBQVUsT0FBTyxPQUFPLEVBQUU7Q0FDcEQsQ0FBQztDQUVELFdBQVcsUUFBUSxTQUFVLEtBQUs7RUFDaEMsSUFBSSxZQUFZLEdBQUcsR0FBRztHQUNwQixJQUFJLFVBQVUsc0JBQXNCLFdBQVk7SUFDOUMsT0FBTyxJQUFJLE9BQU8sTUFBTSxpQkFBaUI7R0FDM0MsQ0FBQztHQUNELElBQUksT0FBTyxJQUFJLElBQUksR0FBRztFQUN4QjtDQUNGLENBQUM7Q0FFRCxtQkFBbUIsb0JBQW9CLENBQUM7Q0FFeEMsYUFBYSxNQUFNO0NBRW5CO0NBQ0EsaUJBQWlCO0NBRWpCLFdBQVcsQ0FBQztDQUVaLFVBQVUsUUFBUSxTQUFVLEdBQUc7RUFDN0IsT0FBTyxZQUFZLEVBQUUsS0FBSyxTQUFTLEtBQUssRUFBRSxLQUFLLFVBQVUsQ0FBQztDQUM1RCxDQUFDO0NBRUQsaUJBQWlCLGNBQWMsZUFBZTtDQUU5QyxVQUFVLFNBQVM7QUFDckI7SUFDSSxjQUFjO0lBQ2QsYUFBYTtJQUNiO0lBQ0EsYUFBYSxTQUFTLFdBQVcsT0FBTztDQUMxQyxJQUFJLFVBQVUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLGFBQWE7RUFFbEQsY0FBYyxhQUFhO0VBQzNCLFlBQVksU0FBUyxPQUFPLENBQUM7RUFFN0IsSUFBSSxJQUFJLFVBQVUsUUFDZCxPQUFPLFNBQVMsR0FDaEIsaUJBQWlCLE9BQU8sVUFBVSxJQUNsQyxTQUFTLEtBQUssVUFBVSxFQUFFLENBQUMsT0FBTztFQUV0QyxhQUFhLGNBQWMsU0FBUyxLQUFLO0VBQ3pDLG1CQUFtQixjQUFjO0VBRWpDLElBQUksZ0JBQWdCO0dBQ2xCLElBQUksbUJBQW1CLENBQUMsa0JBQWtCLE9BQU8sa0JBQWtCLEtBQUs7SUFDdEUsa0JBQWtCO0lBRWxCLFVBQVUsV0FBVztHQUN2QjtHQUVBLFNBQVM7R0FDVCxTQUFTO0VBQ1g7RUFFQSxJQUFJLGFBQWEsR0FBRztHQUNsQixLQUFLO0dBRUwsT0FBTyxPQUFPLEdBQ1osVUFBVSxPQUFPLFVBQVUsR0FBRyxDQUFDLE9BQU8sR0FBRyxjQUFjO0dBR3pELGFBQWE7RUFDZixPQUNFLEtBQUssS0FBSyxHQUFHLEtBQUssR0FBRyxNQUNuQixVQUFVLE9BQU8sVUFBVSxHQUFHLENBQUMsT0FBTyxHQUFHLGNBQWM7RUFJM0QsY0FBYyxhQUFhO0NBQzdCO0NBRUEsU0FBUztBQUNYO0lBQ0ksbUJBQW1CO0NBQUM7Q0FBTztDQUFNO0NBQVM7Q0FBUSxVQUFVO0NBQVMsVUFBVTtDQUFRLFVBQVU7Q0FBTSxVQUFVO0NBQU87Q0FBVztDQUFjO0NBQVM7Q0FBVTtDQUFtQjtDQUFpQjtDQUFnQjtDQUFjO0NBQVk7Q0FBZTtDQUFhO0NBQWE7QUFBTztJQUNsUyxjQUFjLGlCQUFpQixPQUFPO0NBQUM7Q0FBUTtDQUFTO0NBQWEsUUFBUTtDQUFRLFFBQVE7Q0FBUztDQUFZO0NBQVM7Q0FBVSxXQUFXO0NBQU0sV0FBVztDQUFRLFdBQVc7Q0FBUyxXQUFXO0FBQUssQ0FBQztJQUM5TSxjQUFjLFNBQVMsWUFBWSxLQUFLLFFBQVEsT0FBTztDQUN6RCxVQUFVLEtBQUs7Q0FFZixJQUFJLFFBQVEsSUFBSTtDQUVoQixJQUFJLE1BQU0sZ0JBQ1IsVUFBVSxNQUFNLFdBQVc7TUFDdEIsSUFBSSxJQUFJLE1BQU0sV0FBVztFQUM5QixJQUFJLFNBQVMsT0FBTztFQUVwQixJQUFJLFFBQVE7R0FDVixPQUFPLGFBQWEsS0FBSyxNQUFNO0dBQy9CLE9BQU8sWUFBWSxNQUFNO0VBQzNCO0NBQ0Y7Q0FFQSxJQUFJLE1BQU0sWUFBWTtBQUN4QjtJQUNJLGFBQWEsU0FBUyxXQUFXLEtBQUssUUFBUSxJQUFJLGFBQWE7Q0FDakUsSUFBSSxDQUFDLElBQUksTUFBTSxXQUFXO0VBQ3hCLElBQUksSUFBSSxpQkFBaUIsUUFDckIsY0FBYyxPQUFPLE9BQ3JCLFdBQVcsSUFBSSxPQUNmO0VBRUosT0FBTyxLQUFLO0dBQ1YsSUFBSSxpQkFBaUI7R0FDckIsWUFBWSxLQUFLLEdBQUc7RUFDdEI7RUFFQSxZQUFZLFdBQVcsR0FBRyxhQUFhLGFBQWEsYUFBYTtFQUNqRSxHQUFHLFlBQVksYUFBYSxZQUFZLFVBQVU7RUFDbEQsU0FBUyxXQUFXLFNBQVMsVUFBVTtFQUN2QyxZQUFZLFlBQVksR0FBRyxhQUFhO0VBQ3hDLFlBQVksV0FBVztFQUN2QixZQUFZLFlBQVk7RUFDeEIsWUFBWSxVQUFVLFNBQVMsS0FBSyxXQUFXLElBQUk7RUFDbkQsWUFBWSxXQUFXLFNBQVMsS0FBSyxTQUFTLElBQUk7RUFDbEQsWUFBWSxZQUFZLFNBQVMsV0FBVyxTQUFTLFFBQVEsU0FBUyxTQUFTO0VBRS9FLFVBQVUsV0FBVztFQUVyQixTQUFTLFVBQVUsU0FBUyxRQUFRLFVBQVUsR0FBRztFQUNqRCxTQUFTLFdBQVcsU0FBUyxRQUFRLFdBQVcsR0FBRztFQUNuRCxTQUFTLFlBQVksR0FBRztFQUV4QixJQUFJLElBQUksZUFBZSxRQUFRO0dBQzdCLElBQUksV0FBVyxhQUFhLFFBQVEsR0FBRztHQUN2QyxPQUFPLFlBQVksR0FBRztFQUN4QjtFQUVBLElBQUksTUFBTSxZQUFZO0NBQ3hCO0FBQ0Y7SUFDSSxXQUFXO0lBQ1gsWUFBWSxTQUFTLFVBQVUsT0FBTztDQUN4QyxJQUFJLE9BQU87RUFDVCxJQUFJLFFBQVEsTUFBTSxFQUFFLE9BQ2hCLElBQUksTUFBTSxRQUNWLElBQUksR0FDSixHQUNBO0VBQ0osQ0FBQyxNQUFNLEVBQUUsU0FBUyxLQUFLLEtBQUssU0FBUyxNQUFNLENBQUMsRUFBQSxDQUFHLFVBQVU7RUFFekQsT0FBTyxJQUFJLEdBQUcsS0FBSyxHQUFHO0dBQ3BCLFFBQVEsTUFBTSxJQUFJO0dBQ2xCLElBQUksTUFBTTtHQUVWLElBQUksT0FDRixNQUFNLEtBQUs7UUFDTixJQUFJLE1BQU0sSUFDZixNQUFNLGVBQWUsRUFBRSxRQUFRLFVBQVUsS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDO0VBRWpFO0NBQ0Y7QUFDRjtJQUNJLFlBQVksU0FBUyxVQUFVLFNBQVM7Q0FFMUMsSUFBSSxJQUFJLFlBQVksUUFDaEIsUUFBUSxRQUFRLE9BQ2hCLFFBQVEsQ0FBQyxHQUNULElBQUk7Q0FFUixPQUFPLElBQUksR0FBRyxLQUNaLE1BQU0sS0FBSyxZQUFZLElBQUksTUFBTSxZQUFZLEdBQUc7Q0FHbEQsTUFBTSxJQUFJO0NBQ1YsT0FBTztBQUNUO0lBQ0ksYUFBYSxTQUFTLFdBQVcsT0FBTyxVQUFVLGFBQWE7Q0FDakUsSUFBSSxTQUFTLENBQUMsR0FDVixJQUFJLE1BQU0sUUFDVixJQUFJLGNBQWMsSUFBSSxHQUUxQjtDQUVBLE9BQU8sSUFBSSxHQUFHLEtBQUssR0FBRztFQUNwQixJQUFJLE1BQU07RUFDVixPQUFPLEtBQUssR0FBRyxLQUFLLFdBQVcsU0FBUyxLQUFLLE1BQU0sSUFBSSxFQUFFO0NBQzNEO0NBRUEsT0FBTyxJQUFJLE1BQU07Q0FDakIsT0FBTztBQUNUO0lBQ0ksY0FBYztDQUNoQixNQUFNO0NBQ04sS0FBSztBQUNQO0lBU0EsaUJBQWlCLFNBQVMsZUFBZSxPQUFPLFNBQVMsY0FBYyxXQUFXLFFBQVEsUUFBUSxnQkFBZ0IsTUFBTSxnQkFBZ0IsYUFBYSxrQkFBa0IsYUFBYSxvQkFBb0IsZUFBZTtDQUNyTixZQUFZLEtBQUssTUFBTSxRQUFRLE1BQU0sSUFBSTtDQUV6QyxJQUFJLFVBQVUsS0FBSyxLQUFLLE1BQU0sT0FBTyxHQUFHLENBQUMsTUFBTSxPQUM3QyxRQUFRLGVBQWUsTUFBTSxPQUFPLENBQUMsTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLE9BQU8sQ0FBQyxHQUFHLFlBQVksSUFBSTtDQUd0RyxJQUFJLE9BQU8scUJBQXFCLG1CQUFtQixLQUFLLElBQUksR0FDeEQsSUFDQSxJQUNBO0NBQ0osc0JBQXNCLG1CQUFtQixLQUFLLENBQUM7Q0FDL0MsTUFBTSxLQUFLLE1BQU0sUUFBUSxDQUFDO0NBRTFCLElBQUksQ0FBQyxVQUFVLEtBQUssR0FBRztFQUNyQixZQUFZLE9BQU8sTUFBTSxVQUFVLFFBQVEsSUFBSTtFQUMvQyxJQUFJLFdBQVcsU0FBUyxJQUFBLENBQUssTUFBTSxHQUFHLEdBQ2xDLFFBQ0EsYUFDQSxjQUNBO0VBQ0osVUFBVSxXQUFXLFNBQVMsSUFBSSxLQUFLO0VBQ3ZDLFNBQVMsV0FBVyxPQUFPLEtBQUssQ0FBQztFQUVqQyxLQUFLLENBQUMsVUFBVSxDQUFDLE9BQU8sUUFBUSxDQUFDLE9BQU8sUUFBUSxrQkFBa0IsT0FBTyxDQUFDLENBQUMsWUFBWSxRQUFRO0dBRTdGLFVBQVUsUUFBUSxNQUFNO0dBQ3hCLFFBQVEsTUFBTSxVQUFVO0dBQ3hCLFNBQVMsV0FBVyxPQUFPO0dBQzNCLFVBQVUsUUFBUSxNQUFNLFVBQVUsVUFBVSxRQUFRLE1BQU0sZUFBZSxTQUFTO0VBQ3BGO0VBRUEsY0FBYyxZQUFZLFFBQVEsSUFBSSxPQUFPLFVBQVUsRUFBRTtFQUN6RCxlQUFlLFlBQVksUUFBUSxNQUFNLEtBQUssWUFBWTtFQUMxRCxRQUFRLE9BQU8sVUFBVSxLQUFLLGVBQWUsVUFBVSxLQUFLLGNBQWMsY0FBYyxTQUFTO0VBQ2pHLGtCQUFrQixnQkFBZ0IsZ0JBQWdCLGNBQWMsV0FBVyxlQUFlLGVBQWUsTUFBTSxlQUFlLFlBQVksZUFBZSxFQUFFO0VBQzNKLGdCQUFnQixlQUFlO0NBQ2pDLE9BQU87RUFDTCx1QkFBdUIsUUFBUSxLQUFLLE1BQU0sU0FBUyxtQkFBbUIsY0FBYyxPQUFPLG1CQUFtQixjQUFjLEtBQUssR0FBRyxhQUFhLEtBQUs7RUFDdEosa0JBQWtCLGdCQUFnQixnQkFBZ0IsY0FBYyxXQUFXLElBQUk7Q0FDakY7Q0FFQSxJQUFJLGVBQWU7RUFDakIsS0FBSyxpQkFBaUIsU0FBUztFQUMvQixRQUFRLE1BQU0sUUFBUTtDQUN4QjtDQUVBLElBQUksUUFBUTtFQUNWLElBQUksV0FBVyxRQUFRLGNBQ25CLFVBQVUsT0FBTztFQUNyQixLQUFLLFdBQVcsVUFBVTtFQUUxQixnQkFBZ0IsUUFBUSxVQUFVLFdBQVcsV0FBVyxXQUFXLE1BQU0sQ0FBQyxZQUFZLG1CQUFtQixLQUFLLElBQUksTUFBTSxLQUFLLE9BQU8sR0FBRyxJQUFJLE9BQU8sV0FBVyxRQUFRLFdBQVcsQ0FBQztFQUVqTCxJQUFJLGtCQUFrQjtHQUNwQixpQkFBaUIsV0FBVyxjQUFjO0dBQzFDLHFCQUFxQixPQUFPLE1BQU0sVUFBVSxHQUFHLEtBQUssZUFBZSxVQUFVLEdBQUcsS0FBSyxVQUFVLEdBQUcsSUFBSSxPQUFPLFVBQVU7RUFDekg7Q0FDRjtDQUVBLElBQUksc0JBQXNCLFNBQVM7RUFDakMsS0FBSyxXQUFXLE9BQU87RUFDdkIsbUJBQW1CLEtBQUssV0FBVztFQUNuQyxLQUFLLFdBQVcsT0FBTztFQUN2QixtQkFBbUIsZ0JBQWdCLEdBQUcsVUFBVSxLQUFLLEdBQUcsVUFBVTtFQUNsRSxRQUFRLFFBQVEsbUJBQW1CLGdCQUFnQjtDQUNyRDtDQUVBLHNCQUFzQixtQkFBbUIsS0FBSyxJQUFJO0NBQ2xELE9BQU8scUJBQXFCLFFBQVEsS0FBSyxNQUFNLEtBQUs7QUFDdEQ7SUFDSSxhQUFhO0lBQ2IsWUFBWSxTQUFTLFVBQVUsU0FBUyxRQUFRLEtBQUssTUFBTTtDQUM3RCxJQUFJLFFBQVEsZUFBZSxRQUFRO0VBQ2pDLElBQUksUUFBUSxRQUFRLE9BQ2hCLEdBQ0E7RUFFSixJQUFJLFdBQVcsT0FBTztHQUNwQixRQUFRLFVBQVUsTUFBTTtHQUV4QixLQUFLLGtCQUFrQixPQUFPO0dBRTlCLEtBQUssS0FBSyxJQUVSLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLEtBQUssQ0FBQyxLQUFLLEdBQUcsTUFBTSxPQUFPLE1BQU0sT0FBTyxZQUFZLE1BQU0sS0FDL0UsTUFBTSxLQUFLLEdBQUc7R0FJbEIsTUFBTSxNQUFNO0dBQ1osTUFBTSxPQUFPO0VBQ2YsT0FDRSxNQUFNLFVBQVUsUUFBUTtFQUcxQixLQUFLLEtBQUssU0FBUyxPQUFPLENBQUMsQ0FBQyxVQUFVO0VBQ3RDLE9BQU8sWUFBWSxPQUFPO0NBQzVCO0FBQ0Y7SUFDSSx1QkFBdUIsU0FBUyxxQkFBcUIsY0FBYyxjQUFjLGFBQWE7Q0FDaEcsSUFBSSxRQUFRLGNBQ1IsUUFBUTtDQUNaLE9BQU8sU0FBVSxPQUFPO0VBQ3RCLElBQUksVUFBVSxLQUFLLE1BQU0sYUFBYSxDQUFDO0VBRXZDLElBQUksWUFBWSxTQUFTLFlBQVksU0FBUyxLQUFLLElBQUksVUFBVSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksVUFBVSxLQUFLLElBQUksR0FBRztHQUU1RyxRQUFRO0dBQ1IsZUFBZSxZQUFZO0VBQzdCO0VBRUEsUUFBUTtFQUNSLFFBQVEsS0FBSyxNQUFNLEtBQUs7RUFDeEIsT0FBTztDQUNUO0FBQ0Y7SUFDSSxlQUFlLFNBQVMsYUFBYSxRQUFRLFdBQVcsT0FBTztDQUNqRSxJQUFJLE9BQU8sQ0FBQztDQUNaLEtBQUssVUFBVSxLQUFLLE9BQU87Q0FDM0IsS0FBSyxJQUFJLFFBQVEsSUFBSTtBQUN2QjtJQVFBLG1CQUFtQixTQUFTLGlCQUFpQixVQUFVLFdBQVc7Q0FDaEUsSUFBSSxZQUFZLGVBQWUsVUFBVSxTQUFTLEdBQzlDLE9BQU8sWUFBWSxVQUFVLElBRWpDLFdBQVcsU0FBUyxTQUFTLFVBQVUsTUFBTSxjQUFjLFNBQVMsU0FBUztFQUMzRSxJQUFJLFFBQVEsU0FBUyxPQUNqQixhQUFhLEtBQUssWUFDbEIsWUFBWSxDQUFDO0VBQ2pCLGVBQWUsZ0JBQWdCLFVBQVU7RUFFekMsSUFBSSx1QkFBdUIscUJBQXFCLFdBQVcsY0FBYyxXQUFZO0dBQ25GLE1BQU0sS0FBSztHQUNYLFNBQVMsUUFBUTtFQUNuQixDQUFDO0VBRUQsVUFBVSxXQUFXLFdBQVc7RUFFaEMsVUFBVSxXQUFXLFdBQVc7RUFDaEMsU0FBUyxNQUFNLEtBQUs7RUFDcEIsS0FBSyxRQUFRO0VBQ2IsS0FBSyxVQUFVO0VBQ2YsS0FBSyxZQUFZO0VBRWpCLFVBQVUsUUFBUSxXQUFZO0dBQzVCLE9BQU8scUJBQXFCLGVBQWUsVUFBVSxNQUFNLFFBQVEsVUFBVSxNQUFNLFFBQVEsTUFBTSxLQUFLO0VBQ3hHO0VBRUEsS0FBSyxXQUFXLFdBQVk7R0FDMUIsV0FBVztHQUNYLFNBQVMsU0FBUyxXQUFXO0VBQy9CO0VBRUEsS0FBSyxhQUFhLFdBQVk7R0FDNUIsU0FBUyxRQUFRO0dBQ2pCLGNBQWMsV0FBVyxLQUFLLEtBQUs7RUFDckM7RUFFQSxRQUFRLFNBQVMsUUFBUSxLQUFLLEdBQUcsVUFBVSxJQUFJO0VBQy9DLE9BQU87Q0FDVDtDQUVBLFNBQVMsUUFBUTtDQUVqQixVQUFVLGVBQWUsV0FBWTtFQUNuQyxPQUFPLFNBQVMsU0FBUyxTQUFTLE1BQU0sS0FBSyxNQUFNLFNBQVMsUUFBUTtDQUN0RTtDQUVBLGFBQWEsVUFBVSxTQUFTLFVBQVUsWUFBWTtDQUd0RCxjQUFjLFdBQVcsYUFBYSxVQUFVLGFBQWEsVUFBVSxZQUFZO0NBQ25GLE9BQU87QUFDVDtBQUVBLElBQVcsZ0JBQTZCLHlCQUFZO0NBQ2xELFNBQVMsY0FBYyxNQUFNLFdBQVc7RUFDdEMsZ0JBQWdCLGNBQWMsU0FBUyxJQUFJLEtBQUssUUFBUSxLQUFLLDJDQUEyQztFQUV4RyxTQUFTLElBQUk7RUFFYixLQUFLLEtBQUssTUFBTSxTQUFTO0NBQzNCO0NBRUEsSUFBSSxTQUFTLGNBQWM7Q0FFM0IsT0FBTyxPQUFPLFNBQVMsS0FBSyxNQUFNLFdBQVc7RUFDM0MsS0FBSyxXQUFXLEtBQUssUUFBUTtFQUM3QixLQUFLLFFBQVEsS0FBSyxLQUFLLE1BQU0sSUFBSTtFQUVqQyxJQUFJLENBQUMsVUFBVTtHQUNiLEtBQUssU0FBUyxLQUFLLFVBQVUsS0FBSyxPQUFPO0dBQ3pDO0VBQ0Y7RUFFQSxPQUFPLGFBQWEsVUFBVSxJQUFJLEtBQUssVUFBVSxJQUFJLEtBQUssS0FBSyxXQUFXLEVBQ3hFLFNBQVMsS0FDWCxJQUFJLE1BQU0sU0FBUztFQUVuQixJQUFJLFFBQVEsTUFDUixXQUFXLE1BQU0sVUFDakIsY0FBYyxNQUFNLGFBQ3BCLEtBQUssTUFBTSxJQUNYLFdBQVcsTUFBTSxVQUNqQixZQUFZLE1BQU0sV0FDbEIsUUFBUSxNQUFNLE9BQ2QsVUFBVSxNQUFNLFNBQ2hCLE1BQU0sTUFBTSxLQUNaLGFBQWEsTUFBTSxZQUNuQixzQkFBc0IsTUFBTSxxQkFDNUIsZ0JBQWdCLE1BQU0sZUFDdEIsa0JBQWtCLE1BQU0saUJBQ3hCLGlCQUFpQixNQUFNLGdCQUN2QixPQUFPLE1BQU0sTUFDYixPQUFPLE1BQU0sTUFDYixjQUFjLE1BQU0sYUFDcEIsWUFBWSxNQUFNLFdBQ2xCLHFCQUFxQixNQUFNLG9CQUMzQixnQkFBZ0IsTUFBTSxlQUN0QixrQkFBa0IsTUFBTSxpQkFDeEIsWUFBWSxLQUFLLGNBQWMsS0FBSyxzQkFBc0IsS0FBSyxlQUFlLFFBQVEsY0FBYyxXQUNwRyxXQUFXLENBQUMsU0FBUyxVQUFVLEdBQy9CLFdBQVcsV0FBVyxLQUFLLFlBQVksSUFBSSxHQUMzQyxnQkFBZ0IsS0FBSyxLQUFLLFNBQVMsUUFBUSxHQUMzQyxhQUFhLFlBQVksUUFBUSxHQUNqQyxvQkFBb0IsYUFBYSxPQUFPLEtBQUssVUFBVSxjQUFjLFVBQVUsU0FBUyxLQUFLLGNBQWMsYUFBYSxTQUN4SCxZQUFZO0dBQUMsS0FBSztHQUFTLEtBQUs7R0FBUyxLQUFLO0dBQWEsS0FBSztFQUFXLEdBQzNFLGdCQUFnQixZQUFZLEtBQUssY0FBYyxNQUFNLEdBQUcsR0FDeEQsVUFBVSxhQUFhLE9BQU8sS0FBSyxVQUFVLFVBQVUsU0FDdkQsY0FBYyxhQUFhLElBQUksV0FBVyxrQkFBa0IsUUFBUSxDQUFDLENBQUMsV0FBVyxVQUFVLEtBQUssT0FBTyxLQUFLLEdBQzVHLE9BQU8sTUFDUCxnQkFBZ0IsS0FBSyxpQkFBaUIsV0FBWTtHQUNwRCxPQUFPLEtBQUssY0FBYyxJQUFJO0VBQ2hDLEdBQ0ksa0JBQWtCLGFBQWEsVUFBVSxZQUFZLFNBQVMsR0FDOUQscUJBQXFCLGdCQUFnQixVQUFVLFVBQVUsR0FDekQsV0FBVyxHQUNYLGNBQWMsR0FDZCxlQUFlLEdBQ2YsYUFBYSxlQUFlLFVBQVUsU0FBUyxHQUMvQyxTQUNBLFVBQ0EsVUFDQSxTQUNBLFNBQ0EsT0FDQSxLQUNBLGFBQ0EsV0FDQSxvQkFDQSxrQkFDQSxZQUNBLG9CQUNBLFFBQ0Esa0JBQ0EsZ0JBQ0EsVUFDQSxRQUNBLFFBQ0EsV0FDQSxXQUNBLFVBQ0EsV0FDQSxjQUNBLGFBQ0EsbUJBQ0EsVUFDQSxpQkFDQSxJQUNBLE9BQ0EsT0FDQSxZQUNBLGFBQ0EsY0FDQSxpQkFDQSxZQUNBLGtCQUNBLGdCQUNBO0VBR0osS0FBSyxjQUFjLEtBQUssWUFBWTtFQUNwQyxLQUFLLE9BQU87RUFDWixpQkFBaUI7RUFDakIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssU0FBUyxxQkFBcUIsbUJBQW1CLEtBQUssS0FBSyxrQkFBa0IsSUFBSTtFQUN0RixVQUFVLFdBQVc7RUFDckIsS0FBSyxPQUFPO0VBQ1osWUFBWSxhQUFhLEtBQUs7RUFFOUIsSUFBSSxxQkFBcUIsTUFBTTtHQUM3QixRQUFRO0dBQ1IsS0FBSyxvQkFBb0IsVUFBVSxXQUFXO0VBQ2hEO0VBRUEsY0FBYyxjQUFjLGNBQWMsZUFBZTtHQUN2RCxLQUFLLGlCQUFpQixVQUFVLFNBQVM7R0FDekMsTUFBTSxpQkFBaUIsVUFBVSxXQUFXO0VBQzlDO0VBQ0EsS0FBSyxVQUFVLFVBQVUsY0FBYyxZQUFZLFVBQVU7RUFFN0QsS0FBSyxnQkFBZ0IsU0FBVSxPQUFPO0dBQ3BDLGNBQWMsVUFBVSxLQUFLLEtBQUs7R0FFbEMsSUFBSSxDQUFDLGFBQWE7SUFDaEIsY0FBYyxXQUFXLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSztJQUMxQyxhQUFhO0dBQ2YsT0FDRSxhQUFhLFdBQVcsU0FBUyxLQUFLLElBQUksYUFBYSxLQUFLLEdBQUcsV0FBVztJQUN4RSxNQUFNO0lBQ04sZUFBZTtJQUNmLFNBQVM7SUFDVCxVQUFVO0lBQ1YsUUFBUTtJQUNSLFlBQVksU0FBUyxhQUFhO0tBQ2hDLE9BQU8sbUJBQW1CLGdCQUFnQixJQUFJO0lBQ2hEO0dBQ0YsQ0FBQztFQUVMO0VBRUEsSUFBSSxXQUFXO0dBQ2IsVUFBVSxLQUFLLE9BQU87R0FDdEIsVUFBVSxZQUFZLENBQUMsS0FBSyxjQUFjLFVBQVUsS0FBSyxvQkFBb0IsU0FBUyxLQUFLLG9CQUFvQixTQUFTLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxHQUFHLE1BQU0sSUFBSTtHQUU5SyxLQUFLLFlBQVksVUFBVSxNQUFNO0dBQ2pDLFVBQVUsZ0JBQWdCO0dBQzFCLEtBQUssY0FBYyxLQUFLO0dBQ3hCLFFBQVE7R0FDUixPQUFPLEtBQUssVUFBVSxLQUFLO0VBQzdCO0VBRUEsSUFBSSxNQUFNO0dBRVIsSUFBSSxDQUFDLFVBQVUsSUFBSSxLQUFLLEtBQUssTUFDM0IsT0FBTyxFQUNMLFFBQVEsS0FDVjtHQUdGLG9CQUFvQixNQUFNLFNBQVMsS0FBSyxJQUFJLGFBQWEsQ0FBQyxPQUFPLE1BQU0sSUFBSSxVQUFVLEVBQ25GLGdCQUFnQixPQUNsQixDQUFDO0dBRUQsV0FBVyxRQUFRLFNBQVUsR0FBRztJQUM5QixPQUFPLFlBQVksQ0FBQyxLQUFLLEVBQUUsWUFBWSxhQUFhLEtBQUssb0JBQW9CLFNBQVMsY0FBYyxFQUFFLFNBQVM7R0FDakgsQ0FBQztHQUdELFdBQVcsWUFBWSxLQUFLLE1BQU0sSUFBSSxLQUFLLFNBQVMsS0FBSyxXQUFXLFdBQVcsaUJBQWlCLFNBQVMsSUFBSSxLQUFLLFdBQVcsc0JBQXNCLHFCQUFxQixTQUFTLElBQUksS0FBSyxnQkFBZ0IsUUFBUSxTQUFVLE9BQU8sSUFBSTtJQUNyTyxPQUFPLGlCQUFpQixLQUFLLE1BQU0sQ0FBQyxDQUFDLE9BQU8sU0FBUyxJQUFJLGNBQWMsTUFBTSxJQUFJLEdBQUcsU0FBUztHQUMvRixJQUFJLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTTtHQUMvQixlQUFlLEtBQUssWUFBWTtJQUM5QixLQUFLO0lBQ0wsS0FBSztHQUNQO0dBQ0EsZUFBZSxVQUFVLFlBQVksSUFBSSxPQUFPLGFBQWEsS0FBSyxhQUFhLEdBQUcsSUFBSSxPQUFPLGNBQWMsWUFBWTtHQUN2SCxrQkFBa0IsS0FBSyxZQUFZLEtBQUssU0FBUyxjQUFjLEtBQUssSUFBSyxXQUFZO0lBQ25GLElBQUksU0FBUyxXQUFXLEdBQ3BCLG9CQUFvQixTQUFTLElBQUksY0FBYyxLQUMvQyxRQUFRLFFBQVE7SUFFcEIsS0FBSyxxQkFBcUIsS0FBSyxJQUFJLEtBQUssWUFBWSxDQUFDLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsYUFBYSxRQUFRO0tBQ2hILElBQUksWUFBWSxTQUFTLFNBQVMsUUFDOUIsZ0JBQWdCLGFBQWEsQ0FBQyxXQUFXLFVBQVUsY0FBYyxJQUFJLFVBQ3JFLFdBQVcsb0JBQW9CLEtBQUssZ0JBQWdCLFVBQVUsU0FBUyxJQUFJLFVBQVUsT0FBUSxHQUM3RixVQUFVLEtBQUssTUFBTSxNQUFNLENBQUMsVUFBVSxJQUFJLFVBQVUsS0FBSyxXQUFXLENBQUMsSUFBSSxXQUFXLElBQUssR0FDekYsYUFBYSxZQUFZLEtBQUssWUFBWSxRQUFRLElBQUksVUFDdEQsVUFDQSxXQUNBLFFBQVEsTUFDUixVQUFVLE1BQU0sU0FDaEIsZUFBZSxNQUFNLGFBQ3JCLGNBQWMsTUFBTTtLQUN4QixXQUFXLFNBQVMsWUFBWSxJQUFJO0tBQ3BDLFVBQVUsUUFBUSxNQUFNLFdBQVc7S0FFbkMsWUFBWSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sUUFBUSxXQUFXLE1BQU0sQ0FBQztLQUU3RCxJQUFJLFVBQVUsT0FBTyxVQUFVLFNBQVMsY0FBYyxRQUFRO01BQzVELElBQUksU0FBUyxDQUFDLE1BQU0sWUFBWSxNQUFNLFFBQVEsS0FBSyxZQUFZLE1BQU0sR0FFbkU7TUFHRixJQUFJLEtBQUssWUFBWSxPQUNuQixVQUFVLFdBQVc7TUFHdkIsUUFBUSxXQUFXO09BQ2pCLFVBQVUsYUFBYSxLQUFLLEtBQUssSUFBSSxLQUFLLGFBQWEsYUFBYSxHQUFHLEtBQUssV0FBVyxhQUFhLENBQUMsSUFBSSxPQUFRLFdBQVcsT0FBUSxDQUFDLENBQUM7T0FDdEksTUFBTSxLQUFLLFFBQVE7T0FDbkIsTUFBTSxLQUFLLFlBQVksTUFBTTtPQUU3QixhQUFhLFNBQVMsY0FBYztRQUNsQyxPQUFPLGdCQUFnQixRQUFRLElBQUksS0FBSyxnQkFBZ0IsVUFBVSxNQUFNLFlBQVk7T0FDdEY7T0FDQSxZQUFZLFNBQVMsYUFBYTtRQUNoQyxLQUFLLE9BQU87UUFDWixXQUFXLFdBQVc7UUFFdEIsSUFBSSxhQUFhLENBQUMsVUFFaEIsYUFBYSxXQUFXLFFBQVEsaUJBQWlCLFVBQVUsVUFBVSxTQUFTLFVBQVUsS0FBSyxJQUFJLFVBQVUsU0FBUyxRQUFRO1FBRzlILFFBQVEsUUFBUSxhQUFhLENBQUMsV0FBVyxVQUFVLGNBQWMsSUFBSSxLQUFLO1FBQzFFLGtCQUFrQixlQUFlLElBQUk7UUFDckMsZUFBZSxVQUFVLE1BQU0sV0FBVztPQUM1QztNQUNGLEdBQUcsUUFBUSxVQUFVLFFBQVEsWUFBWSxTQUFTLFVBQVUsTUFBTTtNQUNsRSxXQUFXLFVBQVUsTUFBTSxTQUFTLFFBQVEsS0FBSztLQUNuRDtJQUNGLE9BQU8sSUFBSSxLQUFLLFlBQVksYUFBYSxRQUN2QyxnQkFBZ0IsUUFBUSxJQUFJO0dBRWhDLENBQUMsQ0FBQyxDQUFDLE1BQU07RUFDWDtFQUVBLE9BQU8sS0FBSyxNQUFNO0VBQ2xCLFVBQVUsS0FBSyxVQUFVLFdBQVcsV0FBVyxRQUFRLFFBQVEsR0FBRztFQUVsRSxxQkFBcUIsV0FBVyxRQUFRLFNBQVMsUUFBUSxNQUFNO0VBQy9ELHVCQUF1QixxQkFBcUIsbUJBQW1CLElBQUk7RUFDbkUsTUFBTSxRQUFRLE9BQU8sVUFBVSxXQUFXLEdBQUc7RUFDN0MsVUFBVSxXQUFXLE1BQU0sY0FBYztHQUN2QyxTQUFTO0dBQ1QsV0FBVztFQUNiO0VBRUEsSUFBSSxLQUFLO0dBQ1AsZUFBZSxTQUFTLGVBQWUsWUFBWSxhQUFhLENBQUMsY0FBYyxJQUFJLGNBQWMsSUFBSSxXQUFXLFNBQVMsa0JBQWtCLElBQUksVUFBVSxDQUFDLENBQUMsWUFBWSxTQUFTLFFBQVE7R0FFeEwsS0FBSyxNQUFNO0dBQ1gsV0FBVyxLQUFLLEtBQUssU0FBUyxHQUFHO0dBRWpDLElBQUksQ0FBQyxTQUFTLFFBQVE7SUFFcEIsSUFBSSxXQUFXO0tBQ2IsWUFBWSxXQUFXLFNBQVM7S0FDaEMsYUFBYSxDQUFDLFVBQVUsYUFBYSxZQUFZLFVBQVUsV0FBVyxVQUFVO0tBRWhGLFNBQVMsaUJBQWlCLENBQUMsQ0FBQztLQUM1QixjQUFjLFNBQVMsY0FBYyxVQUFVLFNBQVM7SUFDMUQ7SUFFQSxTQUFTLFNBQVMsU0FBUyxhQUFhLEtBQUssY0FBYyxLQUFLO0lBQ2hFLE9BQU8sVUFBVSxJQUFJLFlBQVk7SUFDakMsTUFBTSxPQUFPLFVBQVUsSUFBSSxnQkFBZ0IsRUFBRTtJQUM3QyxTQUFTLFdBQVcsbUJBQW1CLFVBQVUsR0FBRztHQUN0RCxPQUNFLG1CQUFtQixTQUFTO0dBRzlCLEtBQUssWUFBWSxTQUFTLEtBQUssSUFBSSxLQUFLLEVBQ3RDLFNBQVMsS0FDWCxDQUFDO0dBQ0QsS0FBSyxTQUFTLFNBQVMsU0FBUztHQUNoQyxLQUFLLGtCQUFrQixHQUFHO0dBQzFCLGVBQWUsR0FBRyxhQUFhLFVBQVU7R0FDekMsWUFBWSxLQUFLLFlBQVksR0FBRztHQUNoQyxZQUFZLEtBQUssWUFBWSxLQUFLLFVBQVUsR0FBRyxHQUFHO0dBRWxELFdBQVcsS0FBSyxRQUFRLEVBQUU7R0FFMUIsV0FBVyxVQUFVLEdBQUc7RUFDMUI7RUFFQSxJQUFJLFNBQVM7R0FDWCxhQUFhLFVBQVUsT0FBTyxJQUFJLGFBQWEsU0FBUyxlQUFlLElBQUk7R0FDM0UscUJBQXFCLGNBQWMsa0JBQWtCLElBQUksVUFBVSxXQUFXLFlBQVksQ0FBQztHQUMzRixtQkFBbUIsY0FBYyxnQkFBZ0IsSUFBSSxVQUFVLFdBQVcsWUFBWSxHQUFHLGtCQUFrQjtHQUMzRyxTQUFTLG1CQUFtQixXQUFXLFVBQVUsR0FBRztHQUVwRCxJQUFJLFVBQVUsV0FBVyxjQUFjLFVBQVUsU0FBUyxLQUFLLFFBQVE7R0FFdkUsY0FBYyxLQUFLLGNBQWMsY0FBYyxTQUFTLElBQUksU0FBUyxXQUFXLFlBQVksUUFBUSxHQUFHLGtCQUFrQjtHQUN6SCxZQUFZLEtBQUssWUFBWSxjQUFjLE9BQU8sSUFBSSxTQUFTLFdBQVcsWUFBWSxRQUFRLEdBQUcsa0JBQWtCO0dBQ25ILHVCQUF1QixpQkFBaUIsS0FBSyxZQUFZLENBQUMsYUFBYSxTQUFTLEdBQUcsVUFBVSxHQUFHLEdBQUc7R0FFbkcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLFNBQVMsVUFBVSxjQUFjLFVBQVUsY0FBYyxNQUFNLE9BQU87SUFDL0Ysa0JBQWtCLGFBQWEsUUFBUSxRQUFRO0lBRS9DLEtBQUssSUFBSSxDQUFDLG9CQUFvQixnQkFBZ0IsR0FBRyxFQUMvQyxTQUFTLEtBQ1gsQ0FBQztJQUNELG9CQUFvQixLQUFLLFlBQVksb0JBQW9CLFVBQVUsR0FBRyxHQUFHO0lBQ3pFLGtCQUFrQixLQUFLLFlBQVksa0JBQWtCLFVBQVUsR0FBRyxHQUFHO0dBQ3ZFO0VBQ0Y7RUFFQSxJQUFJLG9CQUFvQjtHQUN0QixJQUFJLGNBQWMsbUJBQW1CLEtBQUssVUFDdEMsWUFBWSxtQkFBbUIsS0FBSztHQUN4QyxtQkFBbUIsY0FBYyxZQUFZLFdBQVk7SUFDdkQsS0FBSyxPQUFPLEdBQUcsR0FBRyxDQUFDO0lBQ25CLGVBQWUsWUFBWSxNQUFNLG9CQUFvQixhQUFhLENBQUMsQ0FBQztHQUN0RSxDQUFDO0VBQ0g7RUFFQSxLQUFLLFdBQVcsV0FBWTtHQUMxQixPQUFPLFVBQVUsVUFBVSxRQUFRLElBQUksSUFBSTtFQUM3QztFQUVBLEtBQUssT0FBTyxXQUFZO0dBQ3RCLE9BQU8sVUFBVSxVQUFVLFFBQVEsSUFBSSxJQUFJO0VBQzdDO0VBRUEsS0FBSyxTQUFTLFNBQVUsUUFBUSxNQUFNO0dBQ3BDLElBQUksQ0FBQyxNQUNILE9BQU8sS0FBSyxLQUFLLElBQUk7R0FJdkIsSUFBSSxJQUFJLFdBQVcsU0FBUyxDQUFDLEtBQUssU0FDOUIsaUJBQWlCO0dBRXJCLElBQUksTUFBTSxLQUFLLFlBQVk7SUFDekIsSUFBSSxHQUFHO0tBQ0wsYUFBYSxLQUFLLElBQUksV0FBVyxHQUFHLEtBQUssT0FBTyxPQUFPLENBQUM7S0FFeEQsZUFBZSxLQUFLO0tBQ3BCLG1CQUFtQixhQUFhLFVBQVUsU0FBUztJQUNyRDtJQUVBLGVBQWU7S0FBQztLQUFhO0tBQVc7S0FBb0I7SUFBZ0IsQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0tBQ2pHLE9BQU8sRUFBRSxNQUFNLFVBQVUsSUFBSSxTQUFTO0lBQ3hDLENBQUM7SUFFRCxJQUFJLEdBQUc7S0FDTCxjQUFjO0tBQ2QsS0FBSyxPQUFPLENBQUM7SUFDZjtJQUVBLElBQUksUUFBUSxDQUFDLGVBQWUsQ0FBQyxLQUFLLFdBQ2hDLElBQUksR0FDRixZQUFZLEtBQUssUUFBUSxnQkFBZ0I7U0FFekMsV0FBVyxLQUFLLFFBQVEsa0JBQWtCLEdBQUcsR0FBRyxXQUFXO0lBSS9ELEtBQUssS0FBSyxPQUFPLENBQUM7SUFFbEIsY0FBYztJQUVkLEtBQUssYUFBYTtHQUNwQjtFQUNGO0VBRUEsS0FBSyxVQUFVLFNBQVUsTUFBTSxPQUFPLFVBQVUsV0FBVztHQUV6RCxLQUFLLGVBQWUsQ0FBQyxLQUFLLFlBQVksQ0FBQyxPQUNyQztHQUdGLElBQUksT0FBTyxRQUFRLGlCQUFpQjtJQUNsQyxhQUFhLGVBQWUsYUFBYSxZQUFZO0lBRXJEO0dBQ0Y7R0FFQSxDQUFDLGtCQUFrQixpQkFBaUIsY0FBYyxJQUFJO0dBQ3RELGNBQWM7R0FFZCxJQUFJLFFBQVEsU0FBUyxDQUFDLFVBQVU7SUFFOUIsUUFBUSxNQUFNLEtBQUs7SUFDbkIsUUFBUSxRQUFRO0dBQ2xCO0dBRUEsY0FBYyxXQUFXLE1BQU07R0FFL0IsSUFBSSx1QkFBdUIsV0FBVztJQUNwQyxVQUFVLE9BQU8sRUFDZixNQUFNLE1BQ1IsQ0FBQyxDQUFDLENBQUMsV0FBVztJQUNkLFVBQVUsY0FBYyxVQUFVLFlBQVksTUFBTSxNQUFNLEtBQUssQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0tBQ3BGLE9BQU8sRUFBRSxLQUFLLG1CQUFtQixFQUFFLE9BQU8sR0FBRyxNQUFNLElBQUk7SUFDekQsQ0FBQyxJQUFJLFVBQVUsS0FBSyxtQkFBbUIsVUFBVSxPQUFPLEdBQUcsTUFBTSxJQUFJO0dBQ3ZFO0dBRUEsS0FBSyxjQUFjLEtBQUssT0FBTyxNQUFNLElBQUk7R0FDekMsS0FBSyxnQkFBZ0I7R0FFckIsSUFBSSxPQUFPLGdCQUFnQixHQUN2QixpQkFBaUIsbUJBQW1CLEdBQ3BDLE1BQU0scUJBQXFCLG1CQUFtQixTQUFTLElBQUksV0FBVyxVQUFVLFNBQVMsR0FDekYsaUJBQWlCLFVBQVUsT0FBUSxDQUFDLFFBQ3BDLFNBQVMsR0FDVCxpQkFBaUIsYUFBYSxHQUM5QixZQUFZLFVBQVUsUUFBUSxJQUFJLFNBQVMsTUFBTSxLQUFLLEtBQ3RELG1CQUFtQixLQUFLLGNBQWMsU0FDdEMsY0FBYyxVQUFVLFFBQVEsSUFBSSxTQUFTLFFBQVEsS0FBSyxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUMsVUFBVSxJQUFJLE1BQU0sUUFBUSxXQUNySCxrQkFBa0IsS0FBSyxrQkFBa0IsS0FBSyxtQkFBbUIsV0FBVyxLQUFLLGlCQUFpQixJQUFJLEdBQ3RHLGVBQWUsV0FBVyxLQUFLLElBQUksR0FBRyxVQUFVLFFBQVEsSUFBSSxDQUFDLEtBQUssR0FDbEUsSUFBSSxjQUNKLElBQ0EsUUFDQSxRQUNBLFlBQ0EsVUFDQSxZQUNBLFFBQ0EsZ0JBQ0EsU0FDQSxjQUNBLGdCQUNBLG1CQUNBO0dBRUosSUFBSSxXQUFXLFVBQVUsUUFBUSxHQUFHO0lBRWxDLG9CQUFvQixLQUFLLFlBQVksb0JBQW9CLFVBQVUsQ0FBQztJQUNwRSxrQkFBa0IsS0FBSyxZQUFZLGtCQUFrQixVQUFVLENBQUM7R0FDbEU7R0FFQSxPQUFPLE1BQU0sR0FBRztJQUVkLGFBQWEsVUFBVTtJQUN2QixXQUFXLE9BQU8sV0FBVyxRQUFRLEdBQUcsQ0FBQyxNQUFNLGNBQWM7SUFFN0QsU0FBUyxXQUFXO0lBRXBCLElBQUksV0FBVyxXQUFXLFdBQVcsV0FBVyxPQUFPLFdBQVcsb0JBQW9CLENBQUMsV0FBVyxZQUFZO0tBQzVHLGlCQUFpQixlQUFlLENBQUM7S0FDakMsYUFBYSxRQUFRLFVBQVU7S0FFL0IsV0FBVyxPQUFPLE1BQU0sSUFBSTtJQUM5QjtJQUVBLElBQUksZUFBZSxVQUFVLElBQUk7S0FFL0I7S0FDQTtJQUNGO0dBQ0Y7R0FFQSxZQUFZLFdBQVcsTUFBTSxjQUFjLFlBQVksSUFBSTtHQUMzRCxjQUFjLFlBQVksYUFBYSxTQUFTLElBQUk7R0FDcEQsUUFBUSxlQUFlLGFBQWEsU0FBUyxNQUFNLFdBQVcsV0FBVyxHQUFHLGFBQWEsb0JBQW9CLE1BQU0sZ0JBQWdCLGFBQWEsa0JBQWtCLEtBQUssb0JBQW9CLEtBQUssZUFBZSxhQUFhLE1BQU0sTUFBTSxRQUFTO0dBQ2pQLFlBQVksU0FBUyxNQUFNLFlBQVksVUFBVSxJQUFJO0dBRXJELElBQUksVUFBVSxTQUFTLEtBQUssQ0FBQyxVQUFVLFFBQVEsSUFBSSxHQUNqRCxJQUFJLENBQUMsVUFBVSxRQUFRLEdBQUcsR0FDeEIsYUFBYSxVQUFVLFdBQVcsSUFBSSxZQUFZLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxNQUFNO1FBQ25FO0lBQ0wsU0FBUyxZQUFZLFVBQVUsT0FBTyxDQUFDLEdBQUcsSUFBSTtJQUM5QyxZQUFZLFVBQVUsV0FBVyxJQUFJLGVBQWUscUJBQXFCLEtBQUssTUFBTSxTQUFTLEdBQUcsbUJBQW1CLFNBQVMsR0FBRyxtQkFBbUIsY0FBYyxPQUFPLG1CQUFtQixjQUFjLEtBQUssS0FBSyxJQUFJLFNBQVM7SUFFL04sbUJBQW1CO0dBQ3JCO0dBR0YsWUFBWSxZQUFZLFdBQVcsT0FBTyxJQUFJO0dBQzlDLE1BQU0sS0FBSyxJQUFJLE9BQU8sZUFBZSxjQUFjLG1CQUFtQixXQUFXLE1BQU0sa0JBQWtCLE1BQU0sV0FBVyxXQUFXLElBQUksUUFBUSxXQUFXLGtCQUFrQixNQUFNLGdCQUFnQixhQUFhLGtCQUFrQixLQUFLLG9CQUFvQixLQUFLLGFBQWEsV0FBVyxDQUFDLEtBQUs7R0FDL1IsU0FBUztHQUNULElBQUk7R0FFSixPQUFPLEtBQUs7SUFDVixhQUFhLFVBQVUsTUFBTSxDQUFDO0lBQzlCLFNBQVMsV0FBVztJQUVwQixJQUFJLFVBQVUsV0FBVyxRQUFRLFdBQVcsWUFBWSxTQUFTLENBQUMsc0JBQXNCLFdBQVcsTUFBTSxHQUFHO0tBQzFHLEtBQUssV0FBVyxPQUFPLEtBQUssY0FBYyxLQUFLLElBQUksR0FBRyxXQUFXLEtBQUssSUFBSSxXQUFXO0tBRXJGLEtBQUssV0FBVyxXQUFXLFdBQVcsUUFBUSxXQUFXLFdBQVcsU0FBUyxXQUFXLG9CQUFvQixNQUFNLFdBQVcsR0FFM0gsVUFBVSxNQUFNLElBQUksV0FBVztLQUdqQyxXQUFXLFFBQVEsa0JBQWtCO0lBQ3ZDO0dBQ0Y7R0FFQSxTQUFTO0dBQ1QsT0FBTztHQUNQLEtBQUssZ0JBQWdCLEtBQUssZUFBZTtHQUV6QyxJQUFJLEtBQUssYUFBYSxDQUFDLGdCQUFnQjtJQUNyQyxLQUFLLFlBQVksT0FBTztJQUN4QixNQUFNLEtBQUssSUFBSSxLQUFLLFdBQVcsVUFBVSxTQUFTLENBQUM7R0FDckQ7R0FFQSxTQUFTLE1BQU0sVUFBVSxTQUFTLFFBQVM7R0FFM0MsSUFBSSxnQkFFRixlQUFlLEtBQUssTUFBTSxNQUFNLEdBQUcsR0FBRyxLQUFLLE1BQU0sVUFBVSxPQUFPLEtBQUssVUFBVSxDQUFDO0dBR3BGLEtBQUssV0FBVztHQUVoQixJQUFJLGVBQWUsUUFBUTtJQUV6QixLQUFLLENBQUM7SUFDTixHQUFHLFVBQVUsS0FBSyxPQUFPO0lBQ3pCLG9CQUFvQixHQUFHLFVBQVUsS0FBSyxPQUFPLFdBQVc7SUFDeEQsS0FBSyxJQUFJLENBQUMsYUFBYSxTQUFTLEdBQUcsRUFBRTtHQUN2QztHQUVBLElBQUksT0FBTyxFQUFFLGdCQUFnQixLQUFLLE9BQU8sV0FBVyxVQUFVLFNBQVMsSUFBSTtJQUN6RSxLQUFLLGtCQUFrQixHQUFHO0lBQzFCLGFBQWEsY0FBYztJQUMzQixTQUFTLFdBQVc7SUFFcEIsV0FBVyxXQUFXLFVBQVUsVUFBVSxDQUFDLENBQUMsSUFBSTtJQUVoRCxJQUFJLENBQUMsT0FBTyxNQUFNLEdBQUc7S0FFbkIsa0JBQWtCLGFBQWEsS0FBSyxvQkFBb0IsU0FBUyxTQUFBLENBQVU7S0FDM0UsaUJBQWlCO01BQ2YsT0FBTztNQUNQLE9BQU8sZUFBZSxhQUFhLFVBQVUsRUFBRSxZQUFZO0tBQzdEO0tBRUEsSUFBSSxjQUFjLGtCQUFrQixLQUFLLENBQUMsQ0FBQyxhQUFhLFVBQVUsRUFBRSxZQUFZLE9BQU8sVUFFckYsZUFBZSxNQUFNLGFBQWEsVUFBVSxFQUFFLFlBQVksS0FBSztJQUVuRTtJQUVBLFdBQVcsS0FBSyxRQUFRLEVBQUU7SUFFMUIsV0FBVyxVQUFVLEdBQUc7SUFFeEIsU0FBUyxXQUFXLEtBQUssSUFBSTtJQUM3QixpQkFBaUIsb0JBQW9CLGVBQWUsVUFBVSxhQUFhLGNBQWMsU0FBUyxDQUFDLENBQUM7SUFFcEcsSUFBSSxZQUFZO0tBQ2QsY0FBYyxDQUFDLGFBQWEsVUFBVSxLQUFLLFNBQVMsaUJBQWlCLEdBQUc7S0FDeEUsWUFBWSxJQUFJO0tBQ2hCLElBQUksZUFBZSxXQUFXLFNBQVMsS0FBSyxTQUFTLElBQUksU0FBUyxpQkFBaUI7S0FFbkYsSUFBSSxHQUFHO01BQ0wsWUFBWSxLQUFLLFVBQVUsR0FBRyxJQUFJLEdBQUc7TUFFckMsT0FBTyxNQUFNLGNBQWMsV0FBVyxPQUFPLE1BQU0sWUFBWSxJQUFJO0tBQ3JFO0tBRUEsVUFBVSxXQUFXO0tBRXJCLElBQUksaUJBRUYsVUFBVSxRQUFRLFNBQVUsR0FBRztNQUM3QixJQUFJLEVBQUUsUUFBUSxtQkFBbUIsRUFBRSxLQUFLLGVBQWUsT0FDckQsRUFBRSxnQkFBZ0I7S0FFdEIsQ0FBQztLQUdILG9CQUFvQixXQUFXLFVBQVU7SUFDM0MsT0FBTztLQUNMLElBQUksU0FBUyxLQUFLLFNBQVM7S0FDM0IsS0FBSyxPQUFPLE1BQU0sY0FBYyxXQUFXLE9BQU8sTUFBTSxZQUFZLElBQUk7SUFDMUU7SUFFQSxJQUFJLGtCQUFrQjtLQUNwQixXQUFXO01BQ1QsS0FBSyxPQUFPLE9BQU8sYUFBYSxTQUFTLFFBQVEsa0JBQWtCO01BQ25FLE1BQU0sT0FBTyxRQUFRLGFBQWEsaUJBQWlCLFNBQVMsU0FBUztNQUNyRSxXQUFXO01BQ1gsVUFBVTtLQUNaO0tBQ0EsU0FBUyxVQUFVLFNBQVMsUUFBUSxVQUFVLEtBQUssS0FBSyxPQUFPLEtBQUssSUFBSTtLQUN4RSxTQUFTLFdBQVcsU0FBUyxRQUFRLFdBQVcsS0FBSyxLQUFLLE9BQU8sTUFBTSxJQUFJO0tBQzNFLFNBQVMsV0FBVyxTQUFTLFVBQVUsUUFBUSxTQUFTLFVBQVUsVUFBVSxTQUFTLFVBQVUsV0FBVyxTQUFTLFVBQVUsU0FBUztLQUN0SSxTQUFTLFlBQVksR0FBRztLQUN4QixTQUFTLFdBQVcsUUFBUSxHQUFHLFdBQVc7S0FDMUMsU0FBUyxXQUFXLFVBQVUsR0FBRyxXQUFXO0tBQzVDLFNBQVMsV0FBVyxXQUFXLEdBQUcsV0FBVztLQUM3QyxTQUFTLFdBQVcsU0FBUyxHQUFHLFdBQVc7S0FDM0MsaUJBQWlCLFdBQVcsa0JBQWtCLFVBQVUsV0FBVztLQUNuRSxrQkFBa0IsV0FBVyxDQUFDO0lBQ2hDO0lBRUEsSUFBSSxXQUFXO0tBRWIsVUFBVSxVQUFVO0tBRXBCLG9CQUFvQixDQUFDO0tBRXJCLFVBQVUsT0FBTyxVQUFVLFNBQVMsR0FBRyxNQUFNLElBQUk7S0FDakQsWUFBWSxVQUFVLFVBQVUsQ0FBQyxJQUFJLFdBQVcsU0FBUztLQUN6RCxXQUFXLEtBQUssSUFBSSxTQUFTLFNBQVMsSUFBSTtLQUMxQyxvQkFBb0IsWUFBWSxlQUFlLE9BQU8sZUFBZSxTQUFTLEdBQUcsQ0FBQztLQUVsRixVQUFVLE9BQU8sR0FBRyxNQUFNLElBQUk7S0FDOUIsV0FBVyxVQUFVLFdBQVcsSUFBSTtLQUNwQyxVQUFVLFVBQVUsVUFBVSxVQUFVLFVBQVUsVUFBVSxDQUFDO0tBRTdELG9CQUFvQixDQUFDO0lBQ3ZCLE9BQ0UsWUFBWTtJQUdkLG1CQUFtQixlQUFlLFFBQVEsZUFBZSxNQUFNLGFBQWEsVUFBVSxFQUFFLFlBQVksS0FBSyxlQUFlLFFBQVEsZUFBZSxNQUFNLGVBQWUsY0FBYyxVQUFVLENBQUM7R0FDL0wsT0FBTyxJQUFJLFdBQVcsV0FBVyxLQUFLLENBQUMsb0JBQW9CO0lBRXpELFNBQVMsUUFBUTtJQUVqQixPQUFPLFVBQVUsV0FBVyxPQUFPO0tBQ2pDLElBQUksT0FBTyxZQUFZO01BQ3JCLFNBQVMsT0FBTztNQUNoQixPQUFPLE9BQU87S0FDaEI7S0FFQSxTQUFTLE9BQU87SUFDbEI7R0FDRjtHQUVBLGdCQUFnQixhQUFhLFFBQVEsU0FBVSxHQUFHO0lBQ2hELE9BQU8sRUFBRSxPQUFPLE9BQU8sSUFBSTtHQUM3QixDQUFDO0dBQ0QsS0FBSyxRQUFRO0dBQ2IsS0FBSyxNQUFNO0dBQ1gsVUFBVSxVQUFVLGlCQUFpQixhQUFhLFdBQVc7R0FFN0QsSUFBSSxDQUFDLHNCQUFzQixDQUFDLGdCQUFnQjtJQUMxQyxVQUFVLGNBQWMsV0FBVyxVQUFVO0lBQzdDLEtBQUssT0FBTyxNQUFNO0dBQ3BCO0dBRUEsS0FBSyxPQUFPLE9BQU8sSUFBSTtHQUN2QixjQUFjLFNBQVM7R0FFdkIsSUFBSSxpQkFBaUI7SUFDbkIsV0FBVztJQUdYLGdCQUFnQixRQUFRLElBQUk7R0FDOUI7R0FFQSxjQUFjO0dBQ2QsYUFBYSxhQUFhLFVBQVUsWUFBWSxxQkFBcUIsVUFBVSxTQUFTLE1BQU0sb0JBQW9CLFVBQVUsU0FBUyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsQ0FBQyxPQUFPLFVBQVUsS0FBSyxHQUFHLE1BQU0sSUFBSTtHQUVyTSxJQUFJLGtCQUFrQixpQkFBaUIsS0FBSyxZQUFZLHNCQUFzQix1QkFBdUIsYUFBYSxDQUFDLFVBQVUsVUFBVTtJQUVySSxhQUFhLENBQUMsYUFBYSxVQUFVLFlBQVksZ0JBQWdCLFVBQVUsS0FBSyxvQkFBb0IsVUFBVSxVQUFVLGNBQWMsc0JBQXNCLFFBQVEsU0FBVSxDQUFDLGVBQWUsS0FBSyxNQUFNLFVBQVUsT0FBTyxLQUFLLENBQUMsSUFBSSxjQUFjLElBQUk7SUFFdFAsS0FBSyxXQUFXLG1CQUFtQixVQUFVLFNBQVMsV0FBVyxlQUFlLElBQUk7R0FDdEY7R0FFQSxPQUFPLGVBQWUsT0FBTyxhQUFhLEtBQUssTUFBTSxLQUFLLFdBQVcsU0FBUztHQUM5RSxjQUFjLFdBQVcsV0FBVztHQUVwQyxJQUFJLENBQUMsTUFBTSxpQkFBaUIsR0FBRztJQUU3QixxQkFBcUIsS0FBSyxZQUFZLG9CQUFvQixVQUFVLENBQUM7SUFDckUsbUJBQW1CLEtBQUssWUFBWSxrQkFBa0IsVUFBVSxDQUFDO0lBRWpFLGFBQWEsb0JBQW9CLFdBQVcsaUJBQWlCO0lBRTdELGFBQWEsYUFBYSxXQUFXLHFCQUFxQixhQUFhLEVBQUU7SUFFekUsYUFBYSxrQkFBa0IsV0FBVyxlQUFlO0lBRXpELGFBQWEsV0FBVyxXQUFXLG1CQUFtQixhQUFhLEVBQUU7R0FDdkU7R0FFQSxrQkFBa0IsQ0FBQyxrQkFBa0IsS0FBSyxPQUFPO0dBRWpELElBQUksYUFBYSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQjtJQUV2RCxxQkFBcUI7SUFDckIsVUFBVSxJQUFJO0lBQ2QscUJBQXFCO0dBQ3ZCO0VBQ0Y7RUFFQSxLQUFLLGNBQWMsV0FBWTtHQUM3QixRQUFRLFdBQVcsSUFBSSxZQUFZLFNBQVMsSUFBSSxVQUFVLE9BQVE7RUFDcEU7RUFFQSxLQUFLLGVBQWUsV0FBWTtHQUM5QixjQUFjLEtBQUssaUJBQWlCO0dBRXBDLElBQUksV0FDRixhQUFhLFdBQVcsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLE9BQU8sSUFBSSxjQUFjLFdBQVcsVUFBVSxTQUFTLENBQUMsSUFBSSxZQUFZLGNBQWMsV0FBVyxLQUFLLFlBQVksR0FBRyxDQUFDO0VBRTNLO0VBRUEsS0FBSyxnQkFBZ0IsU0FBVSxPQUFPO0dBQ3BDLE9BQU8sYUFBYSxVQUFVLFdBQVcsU0FBUyxLQUFLLFFBQVEsS0FBSyxTQUFTLFVBQVUsT0FBTyxTQUFTLFVBQVUsU0FBUyxJQUFJLFVBQVU7RUFDMUk7RUFFQSxLQUFLLGNBQWMsU0FBVSxNQUFNO0dBQ2pDLElBQUksSUFBSSxVQUFVLFFBQVEsSUFBSSxHQUMxQixJQUFJLEtBQUssWUFBWSxJQUFJLFVBQVUsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxVQUFVLE1BQU0sSUFBSSxDQUFDO0dBRXBGLFFBQVEsVUFBVSxJQUFJLElBQUksRUFBRSxPQUFPLFNBQVUsR0FBRztJQUM5QyxPQUFPLEVBQUUsS0FBSyxvQkFBb0I7R0FDcEMsQ0FBQyxJQUFJLEVBQUEsQ0FBRyxPQUFPLFNBQVUsR0FBRztJQUMxQixPQUFPLEtBQUssWUFBWSxJQUFJLEVBQUUsT0FBTyxRQUFRLEVBQUUsU0FBUztHQUMxRCxDQUFDO0VBQ0g7RUFFQSxLQUFLLFNBQVMsU0FBVSxPQUFPLGdCQUFnQixXQUFXO0dBQ3hELElBQUksc0JBQXNCLENBQUMsYUFBYSxDQUFDLE9BQ3ZDO0dBR0YsSUFBSSxTQUFTLG1CQUFtQixPQUFPLGFBQWEsS0FBSyxPQUFPLEdBQzVELElBQUksUUFBUSxLQUFLLFNBQVMsU0FBUyxRQUNuQyxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssR0FDdkMsZUFBZSxLQUFLLFVBQ3BCLFVBQ0EsV0FDQSxhQUNBLFFBQ0EsY0FDQSxTQUNBLFNBQ0E7R0FFSixJQUFJLGdCQUFnQjtJQUNsQixVQUFVO0lBQ1YsVUFBVSxxQkFBcUIsV0FBVyxJQUFJO0lBRTlDLElBQUksTUFBTTtLQUNSLFFBQVE7S0FDUixRQUFRLGFBQWEsQ0FBQyxXQUFXLFVBQVUsY0FBYyxJQUFJO0lBQy9EO0dBQ0Y7R0FHQSxJQUFJLGlCQUFpQixPQUFPLENBQUMsZUFBZSxDQUFDLFlBQVk7UUFDbkQsQ0FBQyxXQUFXLFFBQVEsVUFBVSxTQUFTLFlBQVksU0FBUyxJQUFJLFVBQVUsZUFDNUUsVUFBVTtTQUNMLElBQUksWUFBWSxLQUFLLE1BQU0sVUFBVSxTQUFTLFlBQVksU0FBUyxJQUFJLFVBQVUsZUFDdEYsVUFBVTtHQUFBO0dBSWQsSUFBSSxZQUFZLGdCQUFnQixLQUFLLFNBQVM7SUFDNUMsV0FBVyxLQUFLLFdBQVcsQ0FBQyxDQUFDLFdBQVcsVUFBVTtJQUNsRCxZQUFZLENBQUMsQ0FBQyxnQkFBZ0IsZUFBZTtJQUM3QyxVQUFVLGFBQWE7SUFDdkIsZUFBZSxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUUxQyxLQUFLLFlBQVksVUFBVSxlQUFlLElBQUk7SUFDOUMsS0FBSyxXQUFXO0lBRWhCLElBQUksZ0JBQWdCLENBQUMsYUFBYTtLQUNoQyxjQUFjLFdBQVcsQ0FBQyxlQUFlLElBQUksWUFBWSxJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSTtLQUUxRixJQUFJLFVBQVU7TUFDWixTQUFTLENBQUMsV0FBVyxjQUFjLGNBQWMsT0FBTyxVQUFVLGNBQWMsY0FBYyxNQUFNLGNBQWM7TUFFbEgsaUJBQWlCLGNBQWMsV0FBVyxjQUFjLFdBQVcsV0FBVyxVQUFVO0tBQzFGO0lBQ0Y7SUFFQSxvQkFBb0IsV0FBVyxvQkFBb0Isa0JBQWtCLFNBQVMsQ0FBQyxlQUFlLFlBQVksZUFBZSxJQUFJLGdCQUFnQixJQUFJLElBQUksS0FBSyxZQUFZLGVBQWUsQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0tBQzFNLE9BQU8sRUFBRSxhQUFhO0lBQ3hCLENBQUM7SUFFRCxJQUFJLENBQUM7U0FDQyxjQUFjLENBQUMsZUFBZSxDQUFDLFVBQVU7TUFDM0MsV0FBVyxJQUFJLFFBQVEsV0FBVyxXQUFXLFdBQVcsU0FBUyxXQUFXLE9BQU8sV0FBVyxJQUFJLFFBQVEsV0FBVyxNQUFNO01BRTNILElBQUksV0FBVyxTQUNiLFdBQVcsUUFBUSxpQkFBaUIsU0FBUyxVQUFVLFNBQVMsVUFBVSxLQUFLO1dBQzFFO09BRUwsV0FBVyxLQUFLLGdCQUFnQjtPQUNoQyxXQUFXLFdBQVcsQ0FBQyxDQUFDLFFBQVE7TUFDbEM7S0FDRixPQUFPLElBQUksV0FDVCxVQUFVLGNBQWMsU0FBUyxDQUFDLEVBQUUsZ0JBQWdCLGVBQWUsT0FBTztJQUFBO0lBSTlFLElBQUksS0FBSztLQUNQLFNBQVMsZUFBZSxPQUFPLE1BQU0sYUFBYSxVQUFVLE9BQU87S0FFbkUsSUFBSSxDQUFDLGtCQUNILFVBQVUsT0FBTyxXQUFXLFlBQVksT0FBTyxDQUFDO1VBQzNDLElBQUksY0FBYztNQUN2QixVQUFVLENBQUMsU0FBUyxVQUFVLGdCQUFnQixNQUFNLElBQUksVUFBVSxTQUFTLEtBQUssV0FBVyxVQUFVLFNBQVM7TUFFOUcsSUFBSSxhQUNGLElBQUksQ0FBQyxVQUFVLFlBQVksVUFBVTtPQUNuQyxJQUFJLFNBQVMsV0FBVyxLQUFLLElBQUksR0FDN0IsVUFBVSxTQUFTO09BRXZCLFVBQVUsS0FBSyxPQUFPLE9BQU8sT0FBTyxjQUFjLFlBQVksVUFBVSxLQUFLLEtBQUssT0FBTyxRQUFRLGNBQWMsWUFBWSxJQUFJLFdBQVcsR0FBRztNQUMvSSxPQUNFLFVBQVUsS0FBSyxNQUFNO01BSXpCLFVBQVUsWUFBWSxVQUFVLGlCQUFpQixRQUFRO01BRXpELFlBQVksVUFBVSxLQUFLLFlBQVksVUFBVSxZQUFZLFlBQVksS0FBSyxDQUFDLFVBQVUsWUFBWSxFQUFFO0tBQ3pHO0lBQ0Y7SUFFQSxRQUFRLENBQUMsUUFBUSxTQUFTLENBQUMsZUFBZSxDQUFDLFlBQVksZ0JBQWdCLFFBQVEsSUFBSTtJQUNuRixnQkFBZ0IsV0FBVyxRQUFRLFlBQVksVUFBVSxLQUFLLENBQUMscUJBQXFCLFNBQVMsWUFBWSxPQUFPLENBQUMsQ0FBQyxRQUFRLFNBQVUsSUFBSTtLQUN0SSxPQUFPLEdBQUcsVUFBVSxZQUFZLE9BQU8sUUFBUSxTQUFTLENBQUMsWUFBWSxTQUFTO0lBQ2hGLENBQUM7SUFFRCxZQUFZLENBQUMsWUFBWSxDQUFDLFNBQVMsU0FBUyxJQUFJO0lBRWhELElBQUksZ0JBQWdCLENBQUMsYUFBYTtLQUNoQyxJQUFJLFVBQVU7TUFDWixJQUFJLGdCQUNGLElBQUksV0FBVyxZQUNiLFVBQVUsTUFBTSxDQUFDLENBQUMsY0FBYyxDQUFDO1dBQzVCLElBQUksV0FBVyxTQUNwQixVQUFVLFFBQVEsSUFBSSxDQUFDLENBQUMsTUFBTTtXQUN6QixJQUFJLFdBQVcsV0FDcEIsVUFBVSxRQUFRLElBQUk7V0FFdEIsVUFBVSxPQUFPLENBQUM7TUFJdEIsWUFBWSxTQUFTLElBQUk7S0FDM0I7S0FFQSxJQUFJLFdBQVcsQ0FBQyxpQkFBaUI7TUFFL0IsWUFBWSxXQUFXLFVBQVUsTUFBTSxRQUFRO01BQy9DLFVBQVUsZ0JBQWdCLFVBQVUsTUFBTSxVQUFVLFlBQVk7TUFDaEUsU0FBUyxZQUFZLElBQUksS0FBSyxLQUFLLE9BQU8sQ0FBQyxJQUFJLFVBQVUsZUFBZTtNQUV4RSxJQUFJLENBQUMsU0FBUztPQUVaLGNBQWMsWUFBWSxJQUFJLElBQUk7T0FDbEMsVUFBVSxnQkFBZ0IsVUFBVSxNQUFNLFVBQVUsWUFBWTtNQUNsRTtLQUNGO0tBRUEsSUFBSSxpQkFBaUIsQ0FBQyxZQUFZLEtBQUssSUFBSSxLQUFLLFlBQVksQ0FBQyxLQUFLLFVBQVUsYUFBYSxJQUFJLGdCQUFnQixPQUFPO01BQ2xILGNBQWMsS0FBSyxpQkFBaUI7TUFFcEMsYUFBYSxXQUFXLFNBQVMsQ0FBQyxJQUFJLGNBQWMsV0FBVyxXQUFXLFlBQVksSUFBSSxDQUFDLFNBQVMsQ0FBQztLQUN2RztJQUNGLE9BQU8sSUFBSSxZQUFZLFlBQVksQ0FBQyxhQUNsQyxTQUFTLElBQUk7R0FFakI7R0FHQSxJQUFJLGlCQUFpQjtJQUNuQixJQUFJLElBQUkscUJBQXFCLFNBQVMsbUJBQW1CLFNBQVMsS0FBSyxtQkFBbUIsaUJBQWlCLEtBQUs7SUFDaEgsa0JBQWtCLEtBQUssbUJBQW1CLGFBQWEsSUFBSSxFQUFFO0lBQzdELGdCQUFnQixDQUFDO0dBQ25CO0dBRUEsa0JBQWtCLGVBQWUsQ0FBQyxTQUFTLG1CQUFtQixTQUFTLEtBQUssbUJBQW1CLGlCQUFpQixFQUFFO0VBQ3BIO0VBRUEsS0FBSyxTQUFTLFNBQVUsT0FBTyxTQUFTO0dBQ3RDLElBQUksQ0FBQyxLQUFLLFNBQVM7SUFDakIsS0FBSyxVQUFVO0lBRWYsYUFBYSxVQUFVLFVBQVUsU0FBUztJQUUxQyxjQUFjLGFBQWEsVUFBVSxVQUFVLFNBQVM7SUFDeEQsaUJBQWlCLGFBQWEsZUFBZSxlQUFlLGFBQWE7SUFFekUsSUFBSSxVQUFVLE9BQU87S0FDbkIsS0FBSyxXQUFXLGVBQWU7S0FDL0IsVUFBVSxVQUFVLFdBQVcsV0FBVztJQUM1QztJQUVBLFlBQVksU0FBUyxLQUFLLFFBQVE7R0FDcEM7RUFDRjtFQUVBLEtBQUssV0FBVyxTQUFVLE1BQU07R0FDOUIsT0FBTyxRQUFRLFVBQVUsUUFBUSxRQUFRO0VBQzNDO0VBRUEsS0FBSyxlQUFlLFNBQVUsVUFBVSxRQUFRLFdBQVcsV0FBVztHQUVwRSxJQUFJLG9CQUFvQjtJQUV0QixJQUFJLEtBQUssbUJBQW1CLGVBQ3hCLFdBQVcsbUJBQW1CLFNBQVMsR0FDdkMsVUFBVSxHQUFHLE1BQU0sR0FBRztJQUUxQixXQUFXLEdBQUcsUUFBUSxVQUFVLFdBQVc7SUFDM0MsU0FBUyxHQUFHLFFBQVEsVUFBVSxTQUFTO0dBQ3pDO0dBRUEsS0FBSyxRQUFRLE9BQU8sT0FBTztJQUN6QixPQUFPLFdBQVcsVUFBVSxhQUFhLENBQUMsQ0FBQyxLQUFLLFdBQVc7SUFDM0QsS0FBSyxXQUFXLFFBQVEsYUFBYSxDQUFDLENBQUMsS0FBSyxTQUFTO0dBQ3ZELEdBQUcsU0FBUztHQUNaLEtBQUssT0FBTztFQUNkO0VBRUEsS0FBSyxtQkFBbUIsU0FBVSxRQUFRO0dBQ3hDLElBQUksZUFBZSxRQUFRO0lBQ3pCLElBQUksSUFBSSxZQUFZLFFBQVEsVUFBVSxDQUFDLElBQUk7SUFDM0MsWUFBWSxLQUFLLFdBQVcsWUFBWSxFQUFFLElBQUksU0FBUztJQUN2RCxZQUFZLEtBQUssV0FBVyxZQUFZLEVBQUUsSUFBSSxTQUFTO0lBRXZELFVBQVUsV0FBVztHQUN2QjtFQUNGO0VBRUEsS0FBSyxVQUFVLFNBQVUsT0FBTyxnQkFBZ0I7R0FDOUMsVUFBVSxTQUFTLEtBQUssT0FBTyxNQUFNLElBQUk7R0FFekMsSUFBSSxLQUFLLFNBQVM7SUFDaEIsS0FBSyxVQUFVLEtBQUssV0FBVztJQUMvQixrQkFBa0IsY0FBYyxXQUFXLE1BQU07SUFDakQsYUFBYTtJQUNiLGFBQWEsU0FBUyxVQUFVO0lBQ2hDLGlCQUFpQixnQkFBZ0IsZUFBZSxlQUFlLGFBQWE7SUFFNUUsSUFBSSxpQkFBaUI7S0FDbkIsZ0JBQWdCLE1BQU07S0FDdEIsUUFBUSxTQUFTLFFBQVEsTUFBTSxLQUFLLE1BQU0sUUFBUSxRQUFRO0lBQzVEO0lBRUEsSUFBSSxDQUFDLFlBQVk7S0FDZixJQUFJLElBQUksVUFBVTtLQUVsQixPQUFPLEtBQ0wsSUFBSSxVQUFVLEVBQUUsQ0FBQyxhQUFhLFlBQVksVUFBVSxPQUFPLE1BQ3pEO0tBSUosZ0JBQWdCLFVBQVUsVUFBVSxTQUFTO0tBRTdDLGNBQWMsZ0JBQWdCLFVBQVUsVUFBVSxTQUFTO0lBQzdEO0dBQ0Y7RUFDRjtFQUVBLEtBQUssT0FBTyxTQUFVLFFBQVEsZ0JBQWdCO0dBQzVDLEtBQUssUUFBUSxRQUFRLGNBQWM7R0FDbkMsY0FBYyxDQUFDLGtCQUFrQixXQUFXLEtBQUs7R0FDakQsTUFBTSxPQUFPLEtBQUs7R0FFbEIsSUFBSSxJQUFJLFVBQVUsUUFBUSxJQUFJO0dBRTlCLEtBQUssS0FBSyxVQUFVLE9BQU8sR0FBRyxDQUFDO0dBQy9CLE1BQU0sTUFBTSxhQUFhLEtBQUs7R0FHOUIsSUFBSTtHQUVKLFVBQVUsUUFBUSxTQUFVLEdBQUc7SUFDN0IsT0FBTyxFQUFFLGFBQWEsS0FBSyxhQUFhLElBQUk7R0FDOUMsQ0FBQztHQUVELEtBQUssbUJBQW1CLEtBQUssT0FBTyxNQUFNO0dBRTFDLElBQUksV0FBVztJQUNiLFVBQVUsZ0JBQWdCO0lBQzFCLFVBQVUsVUFBVSxPQUFPLEVBQ3pCLE1BQU0sTUFDUixDQUFDO0lBQ0Qsa0JBQWtCLFVBQVUsS0FBSztHQUNuQztHQUVBLGVBQWU7SUFBQztJQUFhO0lBQVc7SUFBb0I7R0FBZ0IsQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0lBQ2pHLE9BQU8sRUFBRSxjQUFjLEVBQUUsV0FBVyxZQUFZLENBQUM7R0FDbkQsQ0FBQztHQUNELGFBQWEsU0FBUyxXQUFXO0dBRWpDLElBQUksS0FBSztJQUNQLGFBQWEsU0FBUyxVQUFVO0lBQ2hDLElBQUk7SUFFSixVQUFVLFFBQVEsU0FBVSxHQUFHO0tBQzdCLE9BQU8sRUFBRSxRQUFRLE9BQU87SUFDMUIsQ0FBQztJQUVELE1BQU0sU0FBUyxTQUFTO0dBQzFCO0dBRUEsS0FBSyxVQUFVLEtBQUssT0FBTyxJQUFJO0VBQ2pDO0VBRUEsVUFBVSxLQUFLLElBQUk7RUFFbkIsS0FBSyxPQUFPLE9BQU8sS0FBSztFQUN4QixzQkFBc0IsbUJBQW1CLElBQUk7RUFFN0MsSUFBSSxhQUFhLFVBQVUsT0FBTyxDQUFDLFFBQVE7R0FFekMsSUFBSSxhQUFhLEtBQUs7R0FFdEIsS0FBSyxTQUFTLFdBQVk7SUFDeEIsS0FBSyxTQUFTO0lBQ2QsV0FBVztJQUVYLFNBQVMsT0FBTyxLQUFLLFFBQVE7R0FDL0I7R0FFQSxLQUFLLFlBQVksS0FBTSxLQUFLLE1BQU07R0FDbEMsU0FBUztHQUNULFFBQVEsTUFBTTtFQUNoQixPQUNFLEtBQUssUUFBUTtFQUdmLE9BQU8saUJBQWlCO0NBQzFCO0NBRUEsY0FBYyxXQUFXLFNBQVMsU0FBUyxNQUFNO0VBQy9DLElBQUksQ0FBQyxjQUFjO0dBQ2pCLE9BQU8sUUFBUSxTQUFTO0dBQ3hCLGNBQWMsS0FBSyxPQUFPLFlBQVksY0FBYyxPQUFPO0dBQzNELGVBQWU7RUFDakI7RUFFQSxPQUFPO0NBQ1Q7Q0FFQSxjQUFjLFdBQVcsU0FBUyxTQUFTLFFBQVE7RUFDakQsSUFBSSxRQUNGLEtBQUssSUFBSSxLQUFLLFFBQ1osVUFBVSxLQUFLLE9BQU87RUFJMUIsT0FBTztDQUNUO0NBRUEsY0FBYyxVQUFVLFNBQVMsUUFBUSxPQUFPLE1BQU07RUFDcEQsV0FBVztFQUVYLFVBQVUsUUFBUSxTQUFVLFNBQVM7R0FDbkMsT0FBTyxRQUFRLE9BQU8sU0FBUyxVQUFVLENBQUMsS0FBSztFQUNqRCxDQUFDO0VBRUQsZ0JBQWdCLE1BQU0sU0FBUyxTQUFTO0VBRXhDLGdCQUFnQixNQUFNLFVBQVUsU0FBUztFQUV6QyxjQUFjLGFBQWE7RUFFM0IsZ0JBQWdCLE1BQU0sZUFBZSxZQUFZO0VBRWpELGdCQUFnQixPQUFPLGNBQWMsWUFBWTtFQUVqRCxlQUFlLGlCQUFpQixNQUFNLG9DQUFvQyxtQkFBbUI7RUFFN0YsZUFBZSxpQkFBaUIsTUFBTSw4QkFBOEIsaUJBQWlCO0VBRXJGLGFBQWEsS0FBSztFQUVsQixvQkFBb0IsZUFBZTtFQUVuQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksV0FBVyxRQUFRLEtBQUssR0FBRztHQUM3QyxlQUFlLGlCQUFpQixXQUFXLElBQUksV0FBVyxJQUFJLEVBQUU7R0FFaEUsZUFBZSxpQkFBaUIsV0FBVyxJQUFJLFdBQVcsSUFBSSxFQUFFO0VBQ2xFO0NBQ0Y7Q0FFQSxjQUFjLFNBQVMsU0FBUyxTQUFTO0VBQ3ZDLE9BQU87RUFDUCxPQUFPO0VBQ1AsU0FBUyxLQUFLO0VBQ2QsUUFBUSxLQUFLO0VBRWIsSUFBSSxNQUFNO0dBQ1IsV0FBVyxLQUFLLE1BQU07R0FDdEIsU0FBUyxLQUFLLE1BQU07R0FDcEIsV0FBVyxLQUFLLEtBQUssV0FBVztHQUNoQyxzQkFBc0IsS0FBSyxLQUFLLHNCQUFzQjtHQUN0RCxxQkFBcUIsS0FBSyxRQUFRLHFCQUFxQjtHQUN2RCxjQUFjLEtBQUssZUFBZTtHQUNsQyxLQUFLLEtBQUssUUFBUSxpQkFBaUIsYUFBYTtHQUVoRCxJQUFJLE9BQU87SUFDVCxXQUFXO0lBQ1gsWUFBWSxTQUFTLGNBQWMsS0FBSztJQUV4QyxVQUFVLE1BQU0sU0FBUztJQUN6QixVQUFVLE1BQU0sV0FBVztJQUUzQixjQUFjO0lBRWQsV0FBVztJQUVYLFNBQVMsU0FBUyxJQUFJO0lBRXRCLGNBQWMsVUFBVSxTQUFTO0lBQ2pDLGFBQWEsU0FBUyxXQUFXLDBCQUEwQixLQUFLLFVBQVUsU0FBUztJQUVuRixzQkFBc0IsU0FBUyxZQUFZO0lBRTNDLGFBQWEsTUFBTSxTQUFTLFNBQVM7SUFHckMsUUFBUTtLQUFDO0tBQU07S0FBTTtLQUFRO0lBQUs7SUFFbEMsSUFBSSxLQUFLLFlBQVk7S0FDbkIsY0FBYyxhQUFhLFNBQVUsTUFBTTtNQUN6QyxJQUFJLEtBQUssS0FBSyxXQUFXLEdBQ3JCO01BRUosS0FBSyxLQUFLLE1BQ1IsR0FBRyxJQUFJLEdBQUcsS0FBSyxFQUFFO01BR25CLE9BQU87S0FDVDtLQUVBLEtBQUssaUJBQWlCLGtCQUFrQixXQUFZO01BQ2xELHVCQUF1QjtNQUV2QixXQUFXO0tBQ2IsQ0FBQztLQUNELEtBQUssaUJBQWlCLG9CQUFvQixXQUFZO01BQ3BELE9BQU8sZ0JBQWdCO0tBQ3pCLENBQUM7S0FDRCxLQUFLLGlCQUFpQixjQUFjLFdBQVk7TUFDOUMsWUFBWSxHQUFHLENBQUM7TUFFaEIsVUFBVSxZQUFZO0tBQ3hCLENBQUM7S0FDRCxLQUFLLFdBQVcsQ0FBQyxDQUFDLElBQUksMkJBQTJCLFdBQVk7TUFFM0QsbUJBQW1CO01BRW5CLE9BQU87S0FDVCxDQUFDO0lBQ0gsT0FDRSxRQUFRLEtBQUssK0JBQStCO0lBRzlDLG1CQUFtQjtJQUVuQixhQUFhLE1BQU0sVUFBVSxTQUFTO0lBR3RDLElBQUksZUFBZSxNQUFNLGFBQWEsT0FBTyxHQUN6QyxZQUFZLE1BQU0sT0FDbEIsU0FBUyxVQUFVLGdCQUNuQixpQkFBaUIsS0FBSyxLQUFLLFVBQVUsV0FDckMsUUFDQTtJQUVKLGVBQWUsVUFBVSxPQUFPLGVBQWUsZ0JBQWdCLFVBQVUsRUFDdkUsT0FBTyxTQUFTLFFBQVE7S0FDdEIsT0FBTyxLQUFLLEtBQUssTUFBTyxJQUFJO0lBQzlCLEVBQ0YsQ0FBQztJQUVELFVBQVUsaUJBQWlCO0lBRTNCLFNBQVMsV0FBVyxLQUFLO0lBQ3pCLFVBQVUsSUFBSSxLQUFLLE1BQU0sT0FBTyxNQUFNLFVBQVUsR0FBRyxDQUFDLEtBQUs7SUFFekQsWUFBWSxJQUFJLEtBQUssTUFBTSxPQUFPLE9BQU8sWUFBWSxHQUFHLENBQUMsS0FBSztJQUM5RCxTQUFTLFVBQVUsaUJBQWlCLFNBQVMsVUFBVSxlQUFlLGtCQUFrQjtJQUV4RixJQUFJLENBQUMsY0FBYztLQUVqQixNQUFNLGFBQWEsU0FBUyxFQUFFO0tBRzlCLE1BQU0sZ0JBQWdCLE9BQU87SUFDL0I7SUFHQSxnQkFBZ0IsWUFBWSxPQUFPLEdBQUc7SUFDdEMsS0FBSyxZQUFZLElBQUssV0FBWTtLQUNoQyxPQUFPLFdBQVc7SUFDcEIsQ0FBQztJQUVELGFBQWEsTUFBTSxlQUFlLFlBQVk7SUFHOUMsYUFBYSxPQUFPLGNBQWMsWUFBWTtJQUc5QyxlQUFlLGNBQWMsTUFBTSxvQ0FBb0MsbUJBQW1CO0lBRTFGLGVBQWUsY0FBYyxNQUFNLDhCQUE4QixpQkFBaUI7SUFFbEYsaUJBQWlCLEtBQUssTUFBTSxZQUFZLFdBQVc7SUFFbkQsWUFBWSxLQUFLLGNBQWM7SUFFL0IsZUFBZSxTQUFTO0lBQ3hCLGVBQWUsS0FBSyxZQUFZLElBQUssV0FBVyxDQUFDLENBQUMsTUFBTTtJQUN4RCxlQUFlO0tBQUM7S0FBTTtLQUFvQixXQUFZO01BQ3BELElBQUksSUFBSSxLQUFLLFlBQ1QsSUFBSSxLQUFLO01BRWIsSUFBSSxLQUFLLFFBQVE7T0FDZixhQUFhO09BQ2IsY0FBYztNQUNoQixPQUFPLElBQUksZUFBZSxLQUFLLGdCQUFnQixHQUM3QyxVQUFVO0tBRWQ7S0FBRztLQUFNO0tBQW9CO0tBQWE7S0FBTTtLQUFRO0tBQWE7S0FBTTtLQUFVO0lBQVM7SUFFOUYsb0JBQW9CLFlBQVk7SUFFaEMsVUFBVSxRQUFRLFNBQVUsU0FBUztLQUNuQyxPQUFPLFFBQVEsT0FBTyxHQUFHLENBQUM7SUFDNUIsQ0FBQztJQUVELEtBQUssSUFBSSxHQUFHLElBQUksV0FBVyxRQUFRLEtBQUssR0FBRztLQUN6QyxlQUFlLGlCQUFpQixXQUFXLElBQUksV0FBVyxJQUFJLEVBQUU7S0FFaEUsZUFBZSxpQkFBaUIsV0FBVyxJQUFJLFdBQVcsSUFBSSxFQUFFO0lBQ2xFO0dBQ0YsT0FBTyxJQUFJLE1BT1QsS0FBSyxpQkFBaUIsb0JBQW9CLFNBTnBCLFNBQVM7SUFDN0IsY0FBYyxPQUFPO0lBRXJCLEtBQUssb0JBQW9CLG9CQUFvQixNQUFNO0dBQ3JELENBRWdEO0VBRXBEO0NBQ0Y7Q0FFQSxjQUFjLFNBQVMsU0FBUyxPQUFPLE1BQU07RUFDM0Msb0JBQW9CLFNBQVMsa0JBQWtCLENBQUMsQ0FBQyxLQUFLO0VBQ3RELElBQUksS0FBSyxLQUFLO0VBQ2QsTUFBTSxjQUFjLGFBQWEsTUFBTSxnQkFBZ0IsT0FBTyxZQUFZLE9BQU8sRUFBRTtFQUNuRix3QkFBd0IsU0FBUyxzQkFBc0IsY0FBYyxZQUFZLEtBQUssS0FBSztFQUUzRixJQUFJLHVCQUF1QixNQUFNO0dBQy9CLG9CQUFvQixlQUFlLEtBQUssb0JBQW9CLGNBQWMsS0FBSyxxQkFBcUIsTUFBTTtHQUMxRyxpQkFBaUIsS0FBSyxvQkFBb0IsR0FBQSxDQUFJLFFBQVEsUUFBUSxNQUFNO0VBQ3RFO0NBQ0Y7Q0FFQSxjQUFjLGdCQUFnQixTQUFTLGNBQWMsUUFBUSxNQUFNO0VBQ2pFLElBQUksSUFBSSxXQUFXLE1BQU0sR0FDckIsSUFBSSxXQUFXLFFBQVEsQ0FBQyxHQUN4QixhQUFhLFlBQVksQ0FBQztFQUU5QixJQUFJLENBQUMsR0FDSCxXQUFXLE9BQU8sR0FBRyxhQUFhLElBQUksQ0FBQztFQUd6QyxJQUFJLE1BQ0YsYUFBYSxTQUFTLFFBQVEsTUFBTSxNQUFNLE9BQU8sTUFBTSxRQUFRLElBQUksSUFBSSxTQUFTLFFBQVEsR0FBRyxJQUFJO0NBRW5HO0NBRUEsY0FBYyxrQkFBa0IsU0FBUyxnQkFBZ0IsT0FBTztFQUM5RCxVQUFVLFFBQVEsU0FBVSxHQUFHO0dBQzdCLE9BQU8sRUFBRSxRQUFRLEVBQUUsS0FBSyxVQUFVLFNBQVMsRUFBRSxLQUFLLEtBQUssTUFBTSxJQUFJO0VBQ25FLENBQUM7Q0FDSDtDQUVBLGNBQWMsZUFBZSxTQUFTLGFBQWEsU0FBUyxPQUFPLFlBQVk7RUFDN0UsSUFBSSxVQUFVLFVBQVUsT0FBTyxJQUFJLFdBQVcsT0FBTyxJQUFJLFFBQUEsQ0FBUyxzQkFBc0IsR0FDcEYsU0FBUyxPQUFPLGFBQWEsU0FBUyxXQUFXLFNBQVM7RUFDOUQsT0FBTyxhQUFhLE9BQU8sUUFBUSxTQUFTLEtBQUssT0FBTyxPQUFPLFNBQVMsS0FBSyxhQUFhLE9BQU8sU0FBUyxTQUFTLEtBQUssT0FBTyxNQUFNLFNBQVMsS0FBSztDQUNySjtDQUVBLGNBQWMscUJBQXFCLFNBQVMsbUJBQW1CLFNBQVMsZ0JBQWdCLFlBQVk7RUFDbEcsVUFBVSxPQUFPLE1BQU0sVUFBVSxXQUFXLE9BQU87RUFDbkQsSUFBSSxTQUFTLFFBQVEsc0JBQXNCLEdBQ3ZDLE9BQU8sT0FBTyxhQUFhLFNBQVMsVUFDcEMsU0FBUyxrQkFBa0IsT0FBTyxPQUFPLElBQUksa0JBQWtCLFlBQVksVUFBVSxrQkFBa0IsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHLElBQUksV0FBVyxjQUFjLElBQUksT0FBTyxNQUFNLFdBQVcsY0FBYyxLQUFLO0VBQ3pOLE9BQU8sY0FBYyxPQUFPLE9BQU8sVUFBVSxLQUFLLGNBQWMsT0FBTyxNQUFNLFVBQVUsS0FBSztDQUM5RjtDQUVBLGNBQWMsVUFBVSxTQUFTLFFBQVEsZ0JBQWdCO0VBQ3ZELFVBQVUsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLFNBQVUsR0FBRztHQUN0QyxPQUFPLEVBQUUsS0FBSyxPQUFPLG9CQUFvQixFQUFFLEtBQUs7RUFDbEQsQ0FBQztFQUVELElBQUksbUJBQW1CLE1BQU07R0FDM0IsSUFBSSxZQUFZLFdBQVcsV0FBVyxDQUFDO0dBQ3ZDLGFBQWEsQ0FBQztHQUNkLFVBQVUsUUFBUSxTQUFVLEdBQUc7SUFDN0IsT0FBTyxFQUFFO0dBQ1gsQ0FBQztFQUNIO0NBQ0Y7Q0FFQSxPQUFPO0FBQ1QsRUFBRTtBQUNGLGNBQWMsVUFBVTtBQUV4QixjQUFjLGFBQWEsU0FBVSxTQUFTO0NBQzVDLE9BQU8sVUFBVSxTQUFTLE9BQU8sQ0FBQyxDQUFDLFFBQVEsU0FBVSxRQUFRO0VBRTNELElBQUksVUFBVSxPQUFPLE9BQU87R0FDMUIsSUFBSSxJQUFJLGFBQWEsUUFBUSxNQUFNO0dBRW5DLEtBQUssS0FBSyxhQUFhLE9BQU8sR0FBRyxDQUFDO0dBRWxDLGFBQWEsS0FBSyxRQUFRLE9BQU8sTUFBTSxTQUFTLE9BQU8sV0FBVyxPQUFPLGFBQWEsV0FBVyxHQUFHLEtBQUssS0FBSyxTQUFTLE1BQU0sR0FBRyxTQUFTLENBQUM7RUFDNUk7Q0FDRixDQUFDLElBQUk7QUFDUDtBQUVBLGNBQWMsU0FBUyxTQUFVLE1BQU0sT0FBTztDQUM1QyxPQUFPLFdBQVcsQ0FBQyxNQUFNLEtBQUs7QUFDaEM7QUFFQSxjQUFjLFNBQVMsU0FBVSxNQUFNLFdBQVc7Q0FDaEQsT0FBTyxJQUFJLGNBQWMsTUFBTSxTQUFTO0FBQzFDO0FBRUEsY0FBYyxVQUFVLFNBQVUsTUFBTTtDQUN0QyxPQUFPLE9BQU8sVUFBVSxJQUFJLEtBQUssZ0JBQWdCLGNBQWMsU0FBUyxNQUFNLFlBQVksSUFBSTtBQUNoRztBQUVBLGNBQWMsU0FBUyxTQUFVLE9BQU87Q0FDdEMsT0FBTyxFQUFFLFdBQVcsU0FBUyxXQUFXLFVBQVUsT0FBTyxJQUFJLENBQUM7QUFDaEU7QUFFQSxjQUFjLG9CQUFvQjtBQUVsQyxjQUFjLFlBQVksU0FBVSxTQUFTLFlBQVk7Q0FDdkQsT0FBTyxXQUFXLFNBQVMsYUFBYSxjQUFjLFNBQVM7QUFDakU7QUFFQSxjQUFjLGdCQUFnQixTQUFVLFNBQVMsWUFBWTtDQUMzRCxPQUFPLGVBQWUsV0FBVyxPQUFPLEdBQUcsYUFBYSxjQUFjLFNBQVM7QUFDakY7QUFFQSxjQUFjLFVBQVUsU0FBVSxJQUFJO0NBQ3BDLE9BQU8sS0FBSztBQUNkO0FBRUEsY0FBYyxTQUFTLFdBQVk7Q0FDakMsT0FBTyxVQUFVLE9BQU8sU0FBVSxHQUFHO0VBQ25DLE9BQU8sRUFBRSxLQUFLLE9BQU87Q0FDdkIsQ0FBQztBQUNIO0FBR0EsY0FBYyxjQUFjLFdBQVk7Q0FDdEMsT0FBTyxDQUFDLENBQUM7QUFDWDtBQUVBLGNBQWMsa0JBQWtCO0FBRWhDLGNBQWMsbUJBQW1CLFNBQVUsTUFBTSxVQUFVO0NBQ3pELElBQUksSUFBSSxXQUFXLFVBQVUsV0FBVyxRQUFRLENBQUM7Q0FDakQsQ0FBQyxFQUFFLFFBQVEsUUFBUSxLQUFLLEVBQUUsS0FBSyxRQUFRO0FBQ3pDO0FBRUEsY0FBYyxzQkFBc0IsU0FBVSxNQUFNLFVBQVU7Q0FDNUQsSUFBSSxJQUFJLFdBQVcsT0FDZixJQUFJLEtBQUssRUFBRSxRQUFRLFFBQVE7Q0FDL0IsS0FBSyxLQUFLLEVBQUUsT0FBTyxHQUFHLENBQUM7QUFDekI7QUFFQSxjQUFjLFFBQVEsU0FBVSxTQUFTLE1BQU07Q0FDN0MsSUFBSSxTQUFTLENBQUMsR0FDVixXQUFXLENBQUMsR0FDWixXQUFXLEtBQUssWUFBWSxNQUM1QixXQUFXLEtBQUssWUFBWSxLQUM1QixnQkFBZ0IsU0FBUyxjQUFjLE1BQU0sVUFBVTtFQUN6RCxJQUFJLFdBQVcsQ0FBQyxHQUNaLFdBQVcsQ0FBQyxHQUNaLFFBQVEsS0FBSyxZQUFZLFVBQVUsV0FBWTtHQUNqRCxTQUFTLFVBQVUsUUFBUTtHQUMzQixXQUFXLENBQUM7R0FDWixXQUFXLENBQUM7RUFDZCxDQUFDLENBQUMsQ0FBQyxNQUFNO0VBQ1QsT0FBTyxTQUFVLE1BQU07R0FDckIsU0FBUyxVQUFVLE1BQU0sUUFBUSxJQUFJO0dBQ3JDLFNBQVMsS0FBSyxLQUFLLE9BQU87R0FDMUIsU0FBUyxLQUFLLElBQUk7R0FDbEIsWUFBWSxTQUFTLFVBQVUsTUFBTSxTQUFTLENBQUM7RUFDakQ7Q0FDRixHQUNJO0NBRUosS0FBSyxLQUFLLE1BQ1IsU0FBUyxLQUFLLEVBQUUsT0FBTyxHQUFHLENBQUMsTUFBTSxRQUFRLFlBQVksS0FBSyxFQUFFLEtBQUssTUFBTSxrQkFBa0IsY0FBYyxHQUFHLEtBQUssRUFBRSxJQUFJLEtBQUs7Q0FHNUgsSUFBSSxZQUFZLFFBQVEsR0FBRztFQUN6QixXQUFXLFNBQVM7RUFFcEIsYUFBYSxlQUFlLFdBQVcsV0FBWTtHQUNqRCxPQUFPLFdBQVcsS0FBSyxTQUFTO0VBQ2xDLENBQUM7Q0FDSDtDQUVBLFNBQVMsT0FBTyxDQUFDLENBQUMsUUFBUSxTQUFVLFFBQVE7RUFDMUMsSUFBSSxTQUFTLENBQUM7RUFFZCxLQUFLLEtBQUssVUFDUixPQUFPLEtBQUssU0FBUztFQUd2QixPQUFPLFVBQVU7RUFDakIsT0FBTyxLQUFLLGNBQWMsT0FBTyxNQUFNLENBQUM7Q0FDMUMsQ0FBQztDQUVELE9BQU87QUFDVDtBQUdBLElBQUksdUNBQXVDLFNBQVMscUNBQXFDLFlBQVksU0FBUyxLQUFLLEtBQUs7Q0FDdEgsVUFBVSxNQUFNLFdBQVcsR0FBRyxJQUFJLFVBQVUsS0FBSyxXQUFXLENBQUM7Q0FDN0QsT0FBTyxNQUFNLE9BQU8sTUFBTSxZQUFZLE1BQU0sV0FBVyxNQUFNLElBQUksV0FBVyxVQUFVLE9BQU87QUFDL0Y7SUFDSSxzQkFBc0IsU0FBUyxvQkFBb0IsUUFBUSxXQUFXO0NBQ3hFLElBQUksY0FBYyxNQUNoQixPQUFPLE1BQU0sZUFBZSxjQUFjO01BRTFDLE9BQU8sTUFBTSxjQUFjLGNBQWMsT0FBTyxTQUFTLFlBQVksU0FBUyxhQUFhLFNBQVMsVUFBVSxnQkFBZ0IsTUFBTTtDQUd0SSxXQUFXLFVBQVUsb0JBQW9CLE9BQU8sU0FBUztBQUMzRDtJQUNJLFlBQVk7Q0FDZCxNQUFNO0NBQ04sUUFBUTtBQUNWO0lBQ0ksZ0JBQWdCLFNBQVMsY0FBYyxPQUFPO0NBQ2hELElBQUksUUFBUSxNQUFNLE9BQ2QsU0FBUyxNQUFNLFFBQ2YsT0FBTyxNQUFNO0NBRWpCLElBQUksUUFBUSxNQUFNLGlCQUFpQixNQUFNLGVBQWUsS0FBSyxNQUFBLENBQU8sUUFDaEUsUUFBUSxLQUFLLFNBQVMsS0FBSyxLQUFLLFNBQVMsSUFBSSxHQUM3QyxPQUFPLFNBQVMsR0FDaEI7Q0FFSixJQUFJLENBQUMsTUFBTSxjQUFjLE9BQU8sTUFBTSxhQUFhLEtBQU07RUFFdkQsT0FBTyxRQUFRLFNBQVMsVUFBVSxLQUFLLGdCQUFnQixLQUFLLGdCQUFnQixLQUFLLGVBQWUsS0FBSyxlQUFlLEVBQUUsV0FBVyxLQUFLLGtCQUFrQixJQUFJLEVBQUEsQ0FBRyxjQUFjLFVBQVUsR0FBRyxjQUN4TCxPQUFPLEtBQUs7RUFHZCxNQUFNLFlBQVksUUFBUSxTQUFTLFVBQVUsQ0FBQyxZQUFZLElBQUksTUFBTSxXQUFXLEtBQUssa0JBQWtCLElBQUksRUFBQSxDQUFHLGNBQWMsVUFBVSxHQUFHO0VBQ3hJLE1BQU0sYUFBYTtDQUNyQjtDQUVBLElBQUksTUFBTSxhQUFhLFNBQVMsS0FBSztFQUNuQyxNQUFNLGdCQUFnQjtFQUN0QixNQUFNLGFBQWE7Q0FDckI7QUFDRjtJQUVBLGlCQUFpQixTQUFTLGVBQWUsUUFBUSxNQUFNLFFBQVEsUUFBUTtDQUNyRSxPQUFPLFNBQVMsT0FBTztFQUNiO0VBQ1IsU0FBUztFQUNULFVBQVU7RUFDVixVQUFVO0VBQ0o7RUFDTixTQUFTLFNBQVMsVUFBVTtFQUM1QixTQUFTO0VBQ1QsUUFBUTtFQUNSLFVBQVU7RUFDVixVQUFVLFNBQVMsV0FBVztHQUM1QixPQUFPLFVBQVUsYUFBYSxNQUFNLFNBQVMsV0FBVyxJQUFJLGdCQUFnQixPQUFPLElBQUk7RUFDekY7RUFDQSxXQUFXLFNBQVMsWUFBWTtHQUM5QixPQUFPLGdCQUFnQixNQUFNLFNBQVMsV0FBVyxJQUFJLGdCQUFnQixJQUFJO0VBQzNFO0NBQ0YsQ0FBQztBQUNIO0lBQ0ksWUFBWTtJQUNaO0lBQ0EsaUJBQWlCLFNBQVMsZUFBZSxHQUFHO0NBQzlDLElBQUksVUFBVSxVQUFVLEtBQUssRUFBRSxPQUFPLE9BQU87Q0FFN0MsSUFBSSxXQUFXLGlCQUFpQjtFQUM5QixFQUFFLGFBQWE7RUFDZixrQkFBa0I7Q0FDcEI7QUFDRjtJQUNJLHVCQUF1QixTQUFTLHFCQUFxQixNQUFNO0NBQzdELFVBQVUsSUFBSSxNQUFNLE9BQU8sQ0FBQztDQUM1QixLQUFLLGlCQUFpQixLQUFLLGVBQWUsS0FBSyxjQUFjO0NBQzdELEtBQUssU0FBUyxLQUFLLE9BQU87Q0FDMUIsS0FBSyxXQUFXLENBQUMsQ0FBQyxLQUFLO0NBQ3ZCLEtBQUssS0FBSyxLQUFLLE1BQU07Q0FFckIsSUFBSSxTQUFTLE1BQ1QsbUJBQW1CLE9BQU8sa0JBQzFCLFdBQVcsT0FBTyxVQUNsQixvQkFBb0IsT0FBTyxtQkFDM0IsWUFBWSxPQUFPLFdBQ25CLE1BQ0EsTUFDQSxTQUFTLFdBQVcsS0FBSyxNQUFNLEtBQUssUUFDcEMsV0FBVyxLQUFLLEtBQUssUUFBUSxDQUFDLENBQUMsZ0JBQy9CLG1CQUFtQixZQUFZLFNBQVMsSUFBSSxHQUM1QyxVQUFVLGVBQWUsS0FBSyxXQUFXLFdBQVcsS0FBSyxPQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxTQUFTLENBQUMsaUJBQWlCLE9BQU8sS0FBSyxpQkFBaUIsUUFBUSxJQUMxSyxjQUFjLGVBQWUsUUFBUSxTQUFTLEdBQzlDLGNBQWMsZUFBZSxRQUFRLFdBQVcsR0FDaEQsUUFBUSxHQUNSLGdCQUFnQixTQUFTLFdBQVcsS0FBSyxpQkFBaUIsS0FBSyxlQUFlLFFBQVEsS0FBSyxlQUFlLFFBQVEsS0FBSyxjQUFjLEtBQUssWUFDMUksZUFBZSxHQUNmLDBCQUEwQixZQUFZLFFBQVEsSUFBSSxXQUFZO0VBQ2hFLE9BQU8sU0FBUyxJQUFJO0NBQ3RCLElBQUksV0FBWTtFQUNkLE9BQU8sWUFBWTtDQUNyQixHQUNJLGVBQ0EsZUFDQSxnQkFBZ0IsZUFBZSxRQUFRLEtBQUssTUFBTSxNQUFNLGlCQUFpQixHQUN6RSxrQkFBa0IsU0FBUyxrQkFBa0I7RUFDL0MsT0FBTyxnQkFBZ0I7Q0FDekIsR0FDSSxlQUFlLGNBQ2YsZUFBZSxjQUNmLGVBQWUsU0FBUyxlQUFlO0VBQ3pDLE9BQU8sV0FBVyxRQUFRLFNBQVM7RUFDbkMsZUFBZSxPQUFPLGFBQWEsSUFBSSxHQUFHLElBQUk7RUFDOUMscUJBQXFCLGVBQWUsT0FBTyxHQUFHLFdBQVcsUUFBUSxXQUFXLENBQUM7RUFDN0UsZ0JBQWdCO0NBQ2xCLEdBQ0ksc0JBQXNCLFNBQVMsc0JBQXNCO0VBQ3ZELFFBQVEsTUFBTSxJQUFJLE9BQU8sV0FBVyxRQUFRLE1BQU0sQ0FBQyxJQUFJLFlBQVksTUFBTSxJQUFJO0VBQzdFLFFBQVEsTUFBTSxZQUFZLHFEQUFxRCxXQUFXLFFBQVEsTUFBTSxDQUFDLElBQUk7RUFDN0csWUFBWSxTQUFTLFlBQVksVUFBVTtDQUM3QyxHQUNJLGFBQWEsU0FBUyxhQUFhO0VBQ3JDLElBQUksZUFBZTtHQUNqQixzQkFBc0IsZUFBZTtHQUVyQyxJQUFJLFNBQVMsT0FBTyxLQUFLLFNBQVMsQ0FBQyxHQUMvQixTQUFTLGFBQWEsWUFBWSxJQUFJLE1BQU07R0FFaEQsSUFBSSxXQUFXLFdBQVcsWUFBWSxJQUFJLFlBQVksUUFBUTtJQUM1RCxZQUFZLFNBQVMsU0FBUyxZQUFZO0lBRTFDLElBQUksSUFBSSxRQUFRLFdBQVcsV0FBVyxRQUFRLE1BQU0sQ0FBQyxLQUFLLEtBQUssWUFBWSxNQUFNO0lBRWpGLFFBQVEsTUFBTSxZQUFZLHFEQUFxRCxJQUFJO0lBQ25GLFFBQVEsTUFBTSxJQUFJLElBQUk7SUFDdEIsWUFBWSxVQUFVLFdBQVc7SUFFakMsV0FBVztHQUNiO0dBRUEsT0FBTztFQUNUO0VBRUEsWUFBWSxVQUFVLG9CQUFvQjtFQUMxQyxnQkFBZ0I7Q0FDbEIsR0FDSSxPQUNBLGNBQ0EsY0FDQSxtQkFDQSxXQUFXLFNBQVMsV0FBVztFQUVqQyxhQUFhO0VBRWIsSUFBSSxNQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssVUFBVSxNQUMzQyxZQUFZLElBQUksT0FBTyxNQUFNLFNBQVMsQ0FBQyxLQUFLLFlBQVksSUFBSSxJQUFJLE1BQU0sUUFBUSxXQUFXLElBQUk7Q0FFakc7Q0FFQSxXQUFXLEtBQUssSUFBSSxTQUFTLEVBQzNCLEdBQUcsTUFDTCxDQUFDO0NBRUQsS0FBSyxjQUFjLFNBQVUsR0FBRztFQUM5QixPQUFPLGNBQWMsRUFBRSxTQUFTLGVBQWUsV0FBVyxDQUFDLEtBQUssUUFBUSxRQUFRLEVBQUUsU0FBUyxnQkFBZ0IsS0FBSyxlQUFlLEVBQUUsV0FBVyxFQUFFLFFBQVEsU0FBUztDQUNqSztDQUVBLEtBQUssVUFBVSxXQUFZO0VBQ3pCLGdCQUFnQjtFQUNoQixJQUFJLFlBQVk7RUFDaEIsUUFBUSxRQUFRLEtBQUssa0JBQWtCLEtBQUssZUFBZSxTQUFTLEtBQUssWUFBWTtFQUNyRixNQUFNLE1BQU07RUFDWixjQUFjLFNBQVMsb0JBQW9CLFFBQVEsUUFBUSxPQUFPLE9BQU8sbUJBQW1CLFFBQVEsR0FBRztFQUN2RyxlQUFlLFlBQVk7RUFDM0IsZUFBZSxZQUFZO0VBQzNCLGFBQWE7RUFDYixnQkFBZ0I7Q0FDbEI7Q0FFQSxLQUFLLFlBQVksS0FBSyxpQkFBaUIsU0FBVSxNQUFNLGFBQWE7RUFDbEUsWUFBWSxVQUFVLG9CQUFvQjtFQUUxQyxJQUFJLENBQUMsYUFDSCxrQkFBa0IsUUFBUSxJQUFJO09BQ3pCO0dBQ0wsV0FBVztHQUdYLElBQUksTUFBTSx3QkFBd0IsR0FDOUIsZUFDQTtHQUVKLElBQUksa0JBQWtCO0lBQ3BCLGdCQUFnQixZQUFZO0lBQzVCLFlBQVksZ0JBQWdCLE1BQU0sTUFBTyxDQUFDLEtBQUssWUFBWTtJQUUzRCxPQUFPLHFDQUFxQyxhQUFhLGVBQWUsV0FBVyxXQUFXLFFBQVEsV0FBVyxDQUFDO0lBQ2xILE1BQU0sS0FBSyxVQUFVLGFBQWEsU0FBUztHQUM3QztHQUVBLGdCQUFnQixZQUFZO0dBQzVCLFlBQVksZ0JBQWdCLE1BQU0sTUFBTyxDQUFDLEtBQUssWUFBWTtHQUUzRCxPQUFPLHFDQUFxQyxhQUFhLGVBQWUsV0FBVyxXQUFXLFFBQVEsU0FBUyxDQUFDO0dBQ2hILE1BQU0sS0FBSyxVQUFVLGFBQWEsU0FBUztHQUMzQyxNQUFNLFdBQVcsQ0FBQyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFJO0dBRTFDLElBQUksY0FBYyxNQUFNLEtBQUssV0FBVyxRQUFRLGlCQUFpQixPQUFPLEdBRXRFLEtBQUssR0FBRyxDQUFDLEdBQUc7SUFDVixVQUFVO0lBQ1YsVUFBVTtHQUNaLENBQUM7RUFFTDtFQUVBLGFBQWEsVUFBVSxJQUFJO0NBQzdCO0NBRUEsS0FBSyxVQUFVLFdBQVk7RUFDekIsTUFBTSxPQUFPLE1BQU0sTUFBTTtFQUV6QixJQUFJLFNBQVMsSUFBSSxlQUFlLEtBQU07R0FFcEMsZ0JBQWdCO0dBQ2hCLGVBQWUsU0FBUztFQUMxQjtDQUNGO0NBRUEsS0FBSyxXQUFXLFNBQVUsTUFBTSxJQUFJLElBQUksUUFBUSxRQUFRO0VBQ3RELGVBQWUsaUJBQWlCLGFBQWE7RUFDN0MsTUFBTSxvQkFBb0IsWUFBWSxhQUFhLE9BQU8sT0FBTyxLQUFLLGdCQUFnQixLQUFLLFNBQVMsS0FBSyxLQUFLLFlBQVksSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO0VBRTdJLElBQUksSUFBSTtHQUNOLFlBQVksVUFBVSxvQkFBb0I7R0FDMUMsSUFBSSxVQUFVLE9BQU8sT0FBTyxJQUN4QixJQUFJLFVBQVUsZUFBZSxLQUFLLFNBQVMsS0FBSyxJQUFJLFlBQVksSUFBSSxLQUFLLE9BQU8sSUFDaEYsV0FBVyxhQUFhLENBQUM7R0FDN0IsV0FBVyxNQUFNLGFBQWEsZ0JBQWdCLFdBQVc7R0FDekQsWUFBWSxRQUFRO0VBQ3RCO0VBRUEsQ0FBQyxNQUFNLE9BQU8sV0FBVztDQUMzQjtDQUVBLEtBQUssV0FBVyxXQUFZO0VBQzFCLG9CQUFvQixRQUFRLG1CQUFtQixRQUFRLEdBQUc7RUFFMUQsY0FBYyxpQkFBaUIsV0FBVyxRQUFRO0VBRWxELGFBQWEsTUFBTSxVQUFVLFFBQVE7RUFFckMsSUFBSSxZQUFZLFFBQVE7R0FDdEIsWUFBWSxPQUFPLE1BQU0saUJBQWlCO0dBQzFDLFlBQVksU0FBUyxZQUFZLFNBQVM7RUFDNUM7RUFFQSxjQUFjLE9BQU87Q0FDdkI7Q0FFQSxLQUFLLFlBQVksV0FBWTtFQUMzQixvQkFBb0IsUUFBUSxJQUFJO0VBRWhDLGdCQUFnQixNQUFNLFVBQVUsUUFBUTtFQUV4QyxjQUFjLG9CQUFvQixXQUFXLFFBQVE7RUFDckQsY0FBYyxLQUFLO0NBQ3JCO0NBRUEsS0FBSyxXQUFXLEtBQUssYUFBYTtDQUNsQyxPQUFPLElBQUksU0FBUyxJQUFJO0NBQ3hCLEtBQUssTUFBTTtDQUVYLGNBQWMsQ0FBQyxZQUFZLEtBQUssWUFBWSxDQUFDO0NBRTdDLGNBQWMsS0FBSyxPQUFPLElBQUksWUFBWTtDQUUxQyxvQkFBb0IsS0FBSztDQUN6QixRQUFRLEtBQUssR0FBRyxNQUFNO0VBQ3BCLE1BQU07RUFDTixRQUFRO0VBQ1IsU0FBUztFQUNULFNBQVMsbUJBQW1CLFVBQVU7RUFDdEMsU0FBUztFQUNULFdBQVcsRUFDVCxTQUFTLHFCQUFxQixhQUFhLFlBQVksR0FBRyxXQUFZO0dBQ3BFLE9BQU8sTUFBTSxNQUFNO0VBQ3JCLENBQUMsRUFDSDtFQUNBLFVBQVU7RUFDVixZQUFZLGtCQUFrQixLQUFLO0NBQ3JDLENBQUM7Q0FFRCxPQUFPO0FBQ1Q7QUFFQSxjQUFjLE9BQU8sU0FBVSxNQUFNO0NBQ25DLElBQUksWUFBWSxJQUFJLEdBQ2xCLE9BQU8sVUFBVSxLQUFLLElBQUk7Q0FHNUIsSUFBSSxTQUFTLEtBQUssZUFBZTtDQUNqQyxjQUFjLE9BQU8sQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0VBQzFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxTQUFTLEVBQUUsUUFBUSxzQkFBc0IsQ0FBQyxDQUFDLE1BQU0sRUFBRSxRQUFRLEtBQUs7Q0FDaEcsQ0FBQztDQUNELE9BQU8sVUFBVSxLQUFLLFFBQVEsU0FBVSxHQUFHLEdBQUc7RUFDNUMsUUFBUSxFQUFFLEtBQUssbUJBQW1CLEtBQUssUUFBUSxFQUFFLEtBQUsscUJBQXFCLE1BQU0sRUFBRSxZQUFZLEVBQUUsS0FBSyxxQkFBcUIsTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLLG1CQUFtQixLQUFLO0NBQy9LLENBQUM7QUFDSDtBQUVBLGNBQWMsVUFBVSxTQUFVLE1BQU07Q0FDdEMsT0FBTyxJQUFJLFNBQVMsSUFBSTtBQUMxQjtBQUVBLGNBQWMsa0JBQWtCLFNBQVUsTUFBTTtDQUM5QyxJQUFJLE9BQU8sU0FBUyxhQUNsQixPQUFPO0NBR1QsSUFBSSxTQUFTLFFBQVEsYUFDbkIsT0FBTyxZQUFZLE9BQU87Q0FHNUIsSUFBSSxTQUFTLE9BQU87RUFDbEIsZUFBZSxZQUFZLEtBQUs7RUFDaEMsY0FBYztFQUNkO0NBQ0Y7Q0FFQSxJQUFJLGFBQWEsZ0JBQWdCLFdBQVcsT0FBTyxxQkFBcUIsSUFBSTtDQUM1RSxlQUFlLFlBQVksV0FBVyxXQUFXLFVBQVUsWUFBWSxLQUFLO0NBQzVFLFlBQVksV0FBVyxNQUFNLE1BQU0sY0FBYztDQUNqRCxPQUFPO0FBQ1Q7QUFFQSxjQUFjLE9BQU87Q0FFRDtDQUNGO0NBQ0o7Q0FDRjtDQUNWLFFBQVE7RUFFTixJQUFJLFNBQVMsS0FBSztHQUNoQixtQkFBbUIsVUFBVSxhQUFhO0dBQzFDLGtCQUFrQixTQUFTO0VBQzdCO0VBRUEsS0FBSyxTQUFTLE1BQU07R0FDbEIsT0FBTztFQUNUO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsS0FBSyxLQUFLLGVBQWUsYUFBYSIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDFdfQ==