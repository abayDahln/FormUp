import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/admin/AdminDashboardPage.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { Users, FileText, Trash2, Search, Shield, ArrowLeft, Loader2, Ban, CheckCircle2, Eye, AlertTriangle, RefreshCw, MessageSquare, X, ExternalLink, Calendar, Mail, User as UserIcon, Lock, CheckCircle } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import { adminGetUsers, adminGetUserDetail, adminGetForms, adminGetFormDetail, adminGetFeedback, adminBanUser, adminActivateUser, adminDeleteUser, adminTakedownForm, adminRestoreForm, adminDeleteForm, adminDeleteFeedback, adminTakedownFormFromFeedback, adminRestoreFormFromFeedback, clearSession, getLocalUser, assetUrl } from "/src/services/apiService.js";
import useDebounce from "/src/hooks/useDebounce.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/admin/AdminDashboardPage.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function AdminDashboardPage() {
	_s();
	const navigate = useNavigate();
	const [user] = useState(() => getLocalUser());
	const [users, setUsers] = useState([]);
	const [forms, setForms] = useState([]);
	const [feedbacks, setFeedbacks] = useState([]);
	const [loading, setLoading] = useState(true);
	const [activeTab, setActiveTab] = useState("users");
	// A3: Sub-tab within feedback tab: 'all' | 'report' | 'masukan'
	const [feedbackSubTab, setFeedbackSubTab] = useState("all");
	const [searchQuery, setSearchQuery] = useState("");
	const debouncedSearch = useDebounce(searchQuery, 300);
	const [toast, setToast] = useState(null);
	const [actionLoadingId, setActionLoadingId] = useState(null);
	const [feedbackTypeFilter, setFeedbackTypeFilter] = useState("all");
	// Modals
	const [selectedUserDetail, setSelectedUserDetail] = useState(null);
	const [loadingUserDetail, setLoadingUserDetail] = useState(false);
	const [selectedFormDetail, setSelectedFormDetail] = useState(null);
	const [loadingFormDetail, setLoadingFormDetail] = useState(false);
	useEffect(() => {
		if (selectedUserDetail || selectedFormDetail) {
			document.body.style.overflow = "hidden";
		} else {
			document.body.style.overflow = "unset";
		}
		return () => {
			document.body.style.overflow = "unset";
		};
	}, [selectedUserDetail, selectedFormDetail]);
	useEffect(() => {
		const userRole = (user?.role || "").toUpperCase();
		if (userRole !== "ADMIN" && userRole !== "SUPER_ADMIN") {
			navigate("/dashboard");
			return;
		}
		const load = async () => {
			setLoading(true);
			try {
				const [usersRes, formsRes, feedbackRes] = await Promise.all([
					adminGetUsers(),
					adminGetForms(),
					adminGetFeedback()
				]);
				if (usersRes.status === 401 || formsRes.status === 401 || feedbackRes.status === 401) {
					clearSession();
					navigate("/login");
					return;
				}
				if (usersRes.ok && usersRes.data) {
					const uData = Array.isArray(usersRes.data) ? usersRes.data : usersRes.data?.items || [];
					setUsers(uData);
				}
				if (formsRes.ok && formsRes.data) {
					const fData = Array.isArray(formsRes.data) ? formsRes.data : formsRes.data?.items || [];
					setForms(fData);
				}
				if (feedbackRes.ok && feedbackRes.data) {
					const fbData = Array.isArray(feedbackRes.data) ? feedbackRes.data : feedbackRes.data?.items || [];
					setFeedbacks(fbData);
				}
			} catch (err) {
				console.error("Error loading admin data:", err);
				showToast("Gagal memuat beberapa data admin", "error");
			} finally {
				setLoading(false);
			}
		};
		load();
	}, [navigate, user]);
	const showToast = (msg, type = "success") => {
		setToast({
			msg,
			type
		});
		setTimeout(() => setToast(null), 3e3);
	};
	const isAdminReport = (fb) => (fb.reason || "").startsWith("ADMIN_");
	const formatFeedbackReason = (rawReason) => {
		if (!rawReason) return "Laporan";
		const stripped = rawReason.startsWith("ADMIN_") ? rawReason.slice(6) : rawReason;
		return stripped.split("_").map((w) => w.charAt(0) + w.slice(1).toLowerCase()).join(" ");
	};
	// ── User Handlers ───────────────────────────────────────────────────────────
	const handleViewUser = async (userId) => {
		setLoadingUserDetail(true);
		setSelectedUserDetail({
			id: userId,
			loading: true
		});
		const res = await adminGetUserDetail(userId);
		setLoadingUserDetail(false);
		if (res.ok && res.data) {
			setSelectedUserDetail(res.data);
		} else {
			showToast(res.message || "Gagal memuat detail pengguna", "error");
			setSelectedUserDetail(null);
		}
	};
	const handleBanUser = async (userId) => {
		if (!window.confirm("Blokir (Ban) pengguna ini? Pengguna tidak akan dapat login.")) return;
		setActionLoadingId(`user_ban_${userId}`);
		const res = await adminBanUser(userId);
		setActionLoadingId(null);
		if (res.ok) {
			setUsers((prev) => prev.map((u) => u.id === userId ? {
				...u,
				isActive: false
			} : u));
			showToast("Pengguna berhasil diblokir (Banned)");
		} else {
			showToast(res.message || "Gagal memblokir pengguna", "error");
		}
	};
	const handleActivateUser = async (userId) => {
		setActionLoadingId(`user_act_${userId}`);
		const res = await adminActivateUser(userId);
		setActionLoadingId(null);
		if (res.ok) {
			setUsers((prev) => prev.map((u) => u.id === userId ? {
				...u,
				isActive: true
			} : u));
			showToast("Pengguna berhasil diaktifkan kembali");
		} else {
			showToast(res.message || "Gagal mengaktifkan pengguna", "error");
		}
	};
	// const handleDeleteUser = async (userId) => {
	//     if (!window.confirm('Hapus pengguna ini? Semua formulir milik pengguna ini juga akan dihapus.')) return;
	//     setActionLoadingId(`user_del_${userId}`);
	//     const res = await adminDeleteUser(userId);
	//     setActionLoadingId(null);
	//     if (res.ok) {
	//         setUsers(prev => prev.filter(u => u.id !== userId));
	//         showToast('Pengguna berhasil dihapus');
	//     } else {
	//         showToast(res.message || 'Gagal menghapus pengguna', 'error');
	//     }
	// };
	// ── Form Handlers ───────────────────────────────────────────────────────────
	const handleViewForm = async (formId) => {
		setLoadingFormDetail(true);
		setSelectedFormDetail({
			id: formId,
			loading: true
		});
		const res = await adminGetFormDetail(formId);
		setLoadingFormDetail(false);
		if (res.ok && res.data) {
			setSelectedFormDetail(res.data);
		} else {
			showToast(res.message || "Gagal memuat detail formulir", "error");
			setSelectedFormDetail(null);
		}
	};
	const handleTakedownForm = async (formId) => {
		if (!window.confirm("Take down formulir ini? Formulir tidak akan bisa diakses publik.")) return;
		setActionLoadingId(`form_td_${formId}`);
		const res = await adminTakedownForm(formId);
		setActionLoadingId(null);
		if (res.ok) {
			setForms((prev) => prev.map((f) => f.id === formId ? {
				...f,
				takenDownAt: new Date().toISOString()
			} : f));
			showToast("Formulir berhasil di-takedown");
		} else {
			showToast(res.message || "Gagal take down formulir", "error");
		}
	};
	const handleRestoreForm = async (formId) => {
		setActionLoadingId(`form_rst_${formId}`);
		const res = await adminRestoreForm(formId);
		setActionLoadingId(null);
		if (res.ok) {
			setForms((prev) => prev.map((f) => f.id === formId ? {
				...f,
				takenDownAt: null
			} : f));
			showToast("Formulir berhasil dipulihkan (Restore)");
		} else {
			showToast(res.message || "Gagal memulihkan formulir", "error");
		}
	};
	const handleDeleteForm = async (formId) => {
		if (!window.confirm("Hapus formulir ini? Tindakan ini tidak dapat dibatalkan.")) return;
		setActionLoadingId(`form_del_${formId}`);
		const res = await adminDeleteForm(formId);
		setActionLoadingId(null);
		if (res.ok) {
			setForms((prev) => prev.filter((f) => f.id !== formId));
			showToast("Formulir berhasil dihapus");
		} else {
			showToast(res.message || "Gagal menghapus formulir", "error");
		}
	};
	// ── Feedback Handlers ───────────────────────────────────────────────────────
	const handleDeleteFeedback = async (fbId) => {
		if (!window.confirm("Hapus laporan umpan balik ini?")) return;
		setActionLoadingId(`fb_del_${fbId}`);
		const res = await adminDeleteFeedback(fbId);
		setActionLoadingId(null);
		if (res.ok) {
			setFeedbacks((prev) => prev.filter((fb) => fb.id !== fbId));
			showToast("Umpan balik berhasil dihapus");
		} else {
			showToast(res.message || "Gagal menghapus umpan balik", "error");
		}
	};
	const handleTakedownFromFeedback = async (fbId) => {
		if (!window.confirm("Take down formulir terkait dari laporan ini?")) return;
		setActionLoadingId(`fb_td_${fbId}`);
		const res = await adminTakedownFormFromFeedback(fbId);
		setActionLoadingId(null);
		if (res.ok) {
			setFeedbacks((prev) => prev.map((fb) => fb.id === fbId ? {
				...fb,
				isTakedown: true
			} : fb));
			showToast("Formulir terkait berhasil di-takedown");
		} else {
			showToast(res.message || "Gagal take down formulir", "error");
		}
	};
	const handleRestoreFromFeedback = async (fbId) => {
		setActionLoadingId(`fb_rst_${fbId}`);
		const res = await adminRestoreFormFromFeedback(fbId);
		setActionLoadingId(null);
		if (res.ok) {
			setFeedbacks((prev) => prev.map((fb) => fb.id === fbId ? {
				...fb,
				isTakedown: false
			} : fb));
			showToast("Formulir terkait berhasil dipulihkan");
		} else {
			showToast(res.message || "Gagal memulihkan formulir", "error");
		}
	};
	// ── Filtered Data ───────────────────────────────────────────────────────────
	const filteredUsers = users.filter((u) => {
		if (!debouncedSearch.trim()) return true;
		const q = debouncedSearch.toLowerCase();
		return u.fullname && u.fullname.toLowerCase().includes(q) || u.username && u.username.toLowerCase().includes(q) || u.email && u.email.toLowerCase().includes(q) || u.role && u.role.toLowerCase().includes(q);
	});
	const filteredForms = forms.filter((f) => {
		if (!debouncedSearch.trim()) return true;
		const q = debouncedSearch.toLowerCase();
		const owner = f.ownerName || f.owner?.fullname || f.ownerEmail || "";
		return f.title && f.title.toLowerCase().includes(q) || f.formLink && f.formLink.toLowerCase().includes(q) || owner.toLowerCase().includes(q);
	});
	const filteredFeedbacks = feedbacks.filter((fb) => {
		if (feedbackTypeFilter === "reports" && !isAdminReport(fb)) return false;
		if (feedbackTypeFilter === "owner" && isAdminReport(fb)) return false;
		if (!debouncedSearch.trim()) return true;
		const q = debouncedSearch.toLowerCase();
		return fb.description && fb.description.toLowerCase().includes(q) || fb.reason && fb.reason.toLowerCase().includes(q) || fb.formTitle && fb.formTitle.toLowerCase().includes(q) || fb.userName && fb.userName.toLowerCase().includes(q) || fb.userEmail && fb.userEmail.toLowerCase().includes(q);
	});
	// A3: Sub-tab filtering for Report vs Masukan
	const REPORT_REASONS = [
		"KONTEN",
		"SPAM",
		"LAPORAN",
		"TIDAK_PANTAS",
		"PELECEHAN",
		"ILLEGAL"
	];
	const subTabFeedbacks = feedbackSubTab === "all" ? filteredFeedbacks : feedbackSubTab === "report" ? filteredFeedbacks.filter((fb) => REPORT_REASONS.some((r) => (fb.reason || "").toUpperCase().includes(r))) : filteredFeedbacks.filter((fb) => !REPORT_REASONS.some((r) => (fb.reason || "").toUpperCase().includes(r)));
	if (loading) return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center justify-center min-h-screen bg-[#F4F8F7] dark:bg-slate-950",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center space-y-2",
			children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin mx-auto text-[#00897B] dark:text-teal-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 304,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-slate-400 dark:text-slate-500 text-sm font-medium",
				children: "Memuat panel kontrol admin..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 305,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 303,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 302,
		columnNumber: 9
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen w-full bg-[#F4F8F7] dark:bg-slate-950 font-sans antialiased text-slate-800 dark:text-slate-100 transition-colors",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 312,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col min-w-0 overflow-y-auto",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 py-4 flex items-center justify-between gap-4",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => navigate("/dashboard"),
								className: "p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 318,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 317,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Shield, {
									size: 18,
									className: "text-[#00897B] dark:text-teal-400"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 322,
									columnNumber: 33
								}, this), "Kontrol & Manajemen Admin"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 321,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 dark:text-slate-500",
								children: "Kelola akun pengguna, formulir global, dan laporan moderasi."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 29
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 320,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 316,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 315,
						columnNumber: 17
					}, this),
					toast && /* @__PURE__ */ _jsxDEV("div", {
						className: `fixed top-4 right-4 z-50 px-4 py-3 rounded-2xl shadow-xl text-xs font-bold text-white transition-all ${toast.type === "error" ? "bg-red-500" : "bg-[#00897B]"}`,
						children: toast.msg
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-6 max-w-6xl mx-auto w-full space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-2 sm:gap-4 mb-6",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3 sm:p-5 shadow-xs flex items-center gap-2 sm:gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 sm:p-3 bg-teal-50 dark:bg-teal-950/50 text-[#00897B] rounded-xl shrink-0",
											children: /* @__PURE__ */ _jsxDEV(Users, {
												size: 18,
												className: "sm:w-6 sm:h-6"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 343,
												columnNumber: 13
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 342,
											columnNumber: 9
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] sm:text-xs font-semibold text-slate-500 dark:text-slate-400 truncate",
												children: "Pengguna Terdaftar"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 346,
												columnNumber: 13
											}, this), /* @__PURE__ */ _jsxDEV("h3", {
												className: "text-sm sm:text-2xl font-bold text-slate-800 dark:text-slate-100 truncate",
												children: users.length
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 349,
												columnNumber: 13
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 345,
											columnNumber: 9
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 341,
										columnNumber: 5
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3 sm:p-5 shadow-xs flex items-center gap-2 sm:gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 sm:p-3 bg-teal-50 dark:bg-teal-950/50 text-[#00897B] rounded-xl shrink-0",
											children: /* @__PURE__ */ _jsxDEV(FileText, {
												size: 18,
												className: "sm:w-6 sm:h-6"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 358,
												columnNumber: 13
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 357,
											columnNumber: 9
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] sm:text-xs font-semibold text-slate-500 dark:text-slate-400 truncate",
												children: "Formulir Aktif"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 361,
												columnNumber: 13
											}, this), /* @__PURE__ */ _jsxDEV("h3", {
												className: "text-sm sm:text-2xl font-bold text-slate-800 dark:text-slate-100 truncate",
												children: forms.length
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 364,
												columnNumber: 13
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 360,
											columnNumber: 9
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 356,
										columnNumber: 5
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3 sm:p-5 shadow-xs flex items-center gap-2 sm:gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 sm:p-3 bg-teal-50 dark:bg-teal-950/50 text-[#00897B] rounded-xl shrink-0",
											children: /* @__PURE__ */ _jsxDEV(MessageSquare, {
												size: 18,
												className: "sm:w-6 sm:h-6"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 373,
												columnNumber: 13
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 372,
											columnNumber: 9
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] sm:text-xs font-semibold text-slate-500 dark:text-slate-400 truncate",
												children: "Umpan Balik Masuk"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 376,
												columnNumber: 13
											}, this), /* @__PURE__ */ _jsxDEV("h3", {
												className: "text-sm sm:text-2xl font-bold text-slate-800 dark:text-slate-100 truncate",
												children: feedbacks.length
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 379,
												columnNumber: 13
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 375,
											columnNumber: 9
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 371,
										columnNumber: 5
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 339,
								columnNumber: 1
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3 sm:p-4 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 sm:flex sm:flex-wrap gap-1.5 sm:gap-2 w-full md:w-auto",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setActiveTab("users"),
											className: `px-2 sm:px-4 py-2 rounded-xl text-[11px] sm:text-xs font-extrabold transition-all cursor-pointer text-center whitespace-nowrap overflow-hidden text-ellipsis ${activeTab === "users" ? "bg-[#00897B] text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
											children: [
												"Pengguna (",
												users.length,
												")"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 391,
											columnNumber: 29
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setActiveTab("forms"),
											className: `px-2 sm:px-4 py-2 rounded-xl text-[11px] sm:text-xs font-extrabold transition-all cursor-pointer text-center whitespace-nowrap overflow-hidden text-ellipsis ${activeTab === "forms" ? "bg-[#00897B] text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
											children: [
												"Formulir (",
												forms.length,
												")"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 402,
											columnNumber: 29
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setActiveTab("feedback"),
											className: `px-2 sm:px-4 py-2 rounded-xl text-[11px] sm:text-xs font-extrabold transition-all cursor-pointer text-center whitespace-nowrap overflow-hidden text-ellipsis ${activeTab === "feedback" ? "bg-[#00897B] text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
											children: [
												"Umpan Balik (",
												feedbacks.length,
												")"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 413,
											columnNumber: 29
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative w-full md:w-64",
									children: [/* @__PURE__ */ _jsxDEV(Search, {
										size: 15,
										className: "absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 427,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: searchQuery,
										onChange: (e) => setSearchQuery(e.target.value),
										placeholder: "Cari data...",
										className: "w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-[#00897B]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 428,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 426,
									columnNumber: 25
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 387,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs",
								children: [
									activeTab === "users" && /* @__PURE__ */ _jsxDEV("div", {
										className: "overflow-x-auto w-full",
										children: /* @__PURE__ */ _jsxDEV("table", {
											className: "w-full text-sm text-left",
											children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
												className: "bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800",
												children: [
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Pengguna"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 447,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Email"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 448,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Peran"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 449,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Status Akun"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 450,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4 text-center",
														children: "Form / Respon"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 451,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4 text-right",
														children: "Aksi"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 452,
														columnNumber: 45
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 446,
												columnNumber: 41
											}, this) }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 445,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("tbody", {
												className: "divide-y divide-slate-100 dark:divide-slate-800",
												children: filteredUsers.length === 0 ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
													colSpan: 6,
													className: "text-center py-8 text-xs text-slate-400",
													children: "Tidak ada pengguna ditemukan."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 458,
													columnNumber: 49
												}, this) }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 457,
													columnNumber: 45
												}, this) : filteredUsers.map((u) => {
													const isBanned = u.isActive === false;
													const isSelf = u.id === user?.id;
													const isAdminUser = (u.role || "").toUpperCase() === "ADMIN" || (u.role || "").toUpperCase() === "SUPER_ADMIN";
													return /* @__PURE__ */ _jsxDEV("tr", {
														className: "hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors",
														children: [
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: [/* @__PURE__ */ _jsxDEV("div", {
																	className: "font-bold text-slate-900 dark:text-white flex items-center gap-2",
																	children: [/* @__PURE__ */ _jsxDEV("span", { children: u.fullname }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 470,
																		columnNumber: 65
																	}, this), isSelf && /* @__PURE__ */ _jsxDEV("span", {
																		className: "text-[10px] bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300 px-1.5 py-0.2 rounded",
																		children: "Anda"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 471,
																		columnNumber: 76
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 469,
																	columnNumber: 61
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "text-[10px] text-slate-400 dark:text-slate-500 font-mono",
																	children: ["@", u.username]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 473,
																	columnNumber: 61
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 468,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-slate-600 dark:text-slate-300 font-medium text-xs",
																children: u.email
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 475,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: /* @__PURE__ */ _jsxDEV("span", {
																	className: `text-[10px] font-extrabold px-2.5 py-0.5 rounded-full ${isAdminUser ? "bg-purple-50 text-purple-600 dark:bg-purple-950/60 dark:text-purple-400 border border-purple-200 dark:border-purple-800" : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400"}`,
																	children: u.role || "USER"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 477,
																	columnNumber: 61
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 476,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: /* @__PURE__ */ _jsxDEV("span", {
																	className: `text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1 ${isBanned ? "bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400 border border-red-200 dark:border-red-800" : "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400"}`,
																	children: [isBanned ? /* @__PURE__ */ _jsxDEV(Ban, { size: 10 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 491,
																		columnNumber: 77
																	}, this) : /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 10 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 491,
																		columnNumber: 97
																	}, this), isBanned ? "Diblokir (Banned)" : "Aktif"]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 486,
																	columnNumber: 61
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 485,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-center text-xs font-semibold text-slate-600 dark:text-slate-400",
																children: [
																	u.formCount ?? 0,
																	" form / ",
																	u.responseCount ?? 0,
																	" respon"
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 495,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-right",
																children: /* @__PURE__ */ _jsxDEV("div", {
																	className: "flex items-center justify-end gap-1.5",
																	children: [/* @__PURE__ */ _jsxDEV("button", {
																		onClick: () => handleViewUser(u.id),
																		className: "p-1.5 text-slate-400 hover:text-[#00897B] dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer",
																		title: "Lihat Detail Pengguna",
																		children: /* @__PURE__ */ _jsxDEV(Eye, { size: 15 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 506,
																			columnNumber: 69
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 501,
																		columnNumber: 65
																	}, this), !isAdminUser && !isSelf && (isBanned ? /* @__PURE__ */ _jsxDEV("button", {
																		onClick: () => handleActivateUser(u.id),
																		disabled: actionLoadingId === `user_act_${u.id}`,
																		className: "p-1.5 text-emerald-500 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors cursor-pointer",
																		title: "Aktifkan Kembali Pengguna",
																		children: /* @__PURE__ */ _jsxDEV(CheckCircle, { size: 15 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 518,
																			columnNumber: 77
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 512,
																		columnNumber: 73
																	}, this) : /* @__PURE__ */ _jsxDEV("button", {
																		onClick: () => handleBanUser(u.id),
																		disabled: actionLoadingId === `user_ban_${u.id}`,
																		className: "p-1.5 text-amber-500 hover:text-amber-700 hover:bg-amber-50 dark:hover:bg-amber-950/40 rounded-lg transition-colors cursor-pointer",
																		title: "Blokir (Ban) Pengguna",
																		children: /* @__PURE__ */ _jsxDEV(Ban, { size: 15 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 527,
																			columnNumber: 77
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 521,
																		columnNumber: 73
																	}, this))]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 499,
																	columnNumber: 61
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 498,
																columnNumber: 57
															}, this)
														]
													}, u.id, true, {
														fileName: _jsxFileName,
														lineNumber: 467,
														columnNumber: 53
													}, this);
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 455,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 444,
											columnNumber: 33
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 443,
										columnNumber: 29
									}, this),
									activeTab === "forms" && /* @__PURE__ */ _jsxDEV("div", {
										className: "overflow-x-auto w-full",
										children: /* @__PURE__ */ _jsxDEV("table", {
											className: "w-full text-sm text-left",
											children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
												className: "bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800",
												children: [
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Judul Formulir"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 560,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Pemilik"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 561,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Status Publikasi"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 562,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Status Moderasi"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 563,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Respons"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 564,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4 text-right",
														children: "Aksi"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 565,
														columnNumber: 45
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 559,
												columnNumber: 41
											}, this) }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 558,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("tbody", {
												className: "divide-y divide-slate-100 dark:divide-slate-800",
												children: filteredForms.length === 0 ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
													colSpan: 6,
													className: "text-center py-8 text-xs text-slate-400",
													children: "Tidak ada formulir ditemukan."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 571,
													columnNumber: 49
												}, this) }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 570,
													columnNumber: 45
												}, this) : filteredForms.map((f) => {
													const isTakenDown = !!f.takenDownAt;
													const isPublished = (f.status || "").toUpperCase() === "PUBLISHED";
													return /* @__PURE__ */ _jsxDEV("tr", {
														className: "hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors",
														children: [
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: [/* @__PURE__ */ _jsxDEV("div", {
																	className: "font-bold text-slate-900 dark:text-white line-clamp-1",
																	children: f.title || "Formulir Tanpa Judul"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 581,
																	columnNumber: 61
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "text-[10px] text-slate-400 dark:text-slate-500 font-mono",
																	children: ["/f/", f.formLink]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 582,
																	columnNumber: 61
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 580,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-xs text-slate-600 dark:text-slate-300 font-medium",
																children: f.ownerName || f.owner?.fullname || f.ownerEmail || "—"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 584,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: /* @__PURE__ */ _jsxDEV("span", {
																	className: `text-[10px] font-bold px-2 py-0.5 rounded-full ${isPublished ? "bg-teal-50 text-teal-600 dark:bg-teal-950/60 dark:text-teal-400 border border-teal-200 dark:border-teal-800" : "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400"}`,
																	children: f.status
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 588,
																	columnNumber: 61
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 587,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: isTakenDown ? /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400 border border-red-200 dark:border-red-800 inline-flex items-center gap-1",
																	children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 10 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 599,
																		columnNumber: 69
																	}, this), " Di-Takedown"]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 598,
																	columnNumber: 65
																}, this) : /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-[10px] font-medium text-emerald-600 dark:text-emerald-400",
																	children: "Normal"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 602,
																	columnNumber: 65
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 596,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-xs font-bold text-slate-700 dark:text-slate-300",
																children: f.responseCount ?? 0
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 607,
																columnNumber: 57
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-right",
																children: /* @__PURE__ */ _jsxDEV("div", {
																	className: "flex items-center justify-end gap-1.5",
																	children: [
																		/* @__PURE__ */ _jsxDEV("button", {
																			onClick: () => handleViewForm(f.id),
																			className: "p-1.5 text-slate-400 hover:text-[#00897B] dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer",
																			title: "Lihat Detail Formulir",
																			children: /* @__PURE__ */ _jsxDEV(Eye, { size: 15 }, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 618,
																				columnNumber: 69
																			}, this)
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 613,
																			columnNumber: 65
																		}, this),
																		isTakenDown ? /* @__PURE__ */ _jsxDEV("button", {
																			onClick: () => handleRestoreForm(f.id),
																			disabled: actionLoadingId === `form_rst_${f.id}`,
																			className: "p-1.5 text-emerald-500 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors cursor-pointer",
																			title: "Pulihkan (Restore) Formulir",
																			children: /* @__PURE__ */ _jsxDEV(RefreshCw, { size: 15 }, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 629,
																				columnNumber: 73
																			}, this)
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 623,
																			columnNumber: 69
																		}, this) : /* @__PURE__ */ _jsxDEV("button", {
																			onClick: () => handleTakedownForm(f.id),
																			disabled: actionLoadingId === `form_td_${f.id}`,
																			className: "p-1.5 text-amber-500 hover:text-amber-700 hover:bg-amber-50 dark:hover:bg-amber-950/40 rounded-lg transition-colors cursor-pointer",
																			title: "Take Down Formulir",
																			children: /* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 15 }, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 638,
																				columnNumber: 73
																			}, this)
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 632,
																			columnNumber: 69
																		}, this),
																		/* @__PURE__ */ _jsxDEV("button", {
																			onClick: () => handleDeleteForm(f.id),
																			disabled: actionLoadingId === `form_del_${f.id}`,
																			className: "p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition-colors cursor-pointer",
																			title: "Hapus Formulir",
																			children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 15 }, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 649,
																				columnNumber: 69
																			}, this)
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 643,
																			columnNumber: 65
																		}, this)
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 611,
																	columnNumber: 61
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 610,
																columnNumber: 57
															}, this)
														]
													}, f.id, true, {
														fileName: _jsxFileName,
														lineNumber: 579,
														columnNumber: 53
													}, this);
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 568,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 557,
											columnNumber: 33
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 556,
										columnNumber: 29
									}, this),
									activeTab === "feedback" && /* @__PURE__ */ _jsxDEV("div", {
										className: "w-full",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2",
											children: [
												{
													id: "all",
													label: "Semua"
												},
												{
													id: "reports",
													label: "🚩 Laporan ke Admin"
												},
												{
													id: "owner",
													label: "Masukan ke Pemilik"
												}
											].map((f) => /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setFeedbackTypeFilter(f.id),
												className: `px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${feedbackTypeFilter === f.id ? "bg-[#00897B] text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
												children: f.label
											}, f.id, false, {
												fileName: _jsxFileName,
												lineNumber: 671,
												columnNumber: 41
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 665,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "overflow-x-auto w-full",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 mb-4 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit",
												children: [
													{
														key: "all",
														label: "Semua",
														count: filteredFeedbacks.length
													},
													{
														key: "report",
														label: "🚨 Laporan",
														count: filteredFeedbacks.filter((fb) => REPORT_REASONS.some((r) => (fb.reason || "").toUpperCase().includes(r))).length
													},
													{
														key: "masukan",
														label: "💬 Masukan",
														count: filteredFeedbacks.filter((fb) => !REPORT_REASONS.some((r) => (fb.reason || "").toUpperCase().includes(r))).length
													}
												].map((tab) => /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setFeedbackSubTab(tab.key),
													className: `px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${feedbackSubTab === tab.key ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm" : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"}`,
													children: [
														tab.label,
														" ",
														/* @__PURE__ */ _jsxDEV("span", {
															className: "ml-1 text-[10px] text-slate-400",
															children: [
																"(",
																tab.count,
																")"
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 703,
															columnNumber: 57
														}, this)
													]
												}, tab.key, true, {
													fileName: _jsxFileName,
													lineNumber: 693,
													columnNumber: 41
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 687,
												columnNumber: 33
											}, this), /* @__PURE__ */ _jsxDEV("table", {
												className: "w-full text-sm text-left",
												children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
													className: "bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800",
													children: [
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Pengirim"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 711,
															columnNumber: 45
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Kategori"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 712,
															columnNumber: 45
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Isi Pesan / Laporan"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 713,
															columnNumber: 45
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Formulir Terkait"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 714,
															columnNumber: 45
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4",
															children: "Tanggal"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 715,
															columnNumber: 45
														}, this),
														/* @__PURE__ */ _jsxDEV("th", {
															className: "py-3 px-4 text-right",
															children: "Aksi"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 716,
															columnNumber: 45
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 710,
													columnNumber: 41
												}, this) }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 709,
													columnNumber: 37
												}, this), /* @__PURE__ */ _jsxDEV("tbody", {
													className: "divide-y divide-slate-100 dark:divide-slate-800",
													children: subTabFeedbacks.length === 0 ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
														colSpan: 6,
														className: "text-center py-8 text-xs text-slate-400",
														children: feedbackSubTab === "report" ? "Tidak ada laporan masuk." : feedbackSubTab === "masukan" ? "Tidak ada masukan masuk." : "Tidak ada umpan balik / laporan masuk."
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 722,
														columnNumber: 49
													}, this) }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 721,
														columnNumber: 45
													}, this) : subTabFeedbacks.map((fb) => /* @__PURE__ */ _jsxDEV("tr", {
														className: "hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors",
														children: [
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: [/* @__PURE__ */ _jsxDEV("div", {
																	className: "font-bold text-slate-900 dark:text-white text-xs",
																	children: fb.userName || fb.user?.fullname || "Anonim"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 730,
																	columnNumber: 57
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "text-[10px] text-slate-400 font-mono",
																	children: fb.userEmail || fb.user?.email || "—"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 731,
																	columnNumber: 57
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 729,
																columnNumber: 53
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4",
																children: /* @__PURE__ */ _jsxDEV("div", {
																	className: "flex flex-col gap-1",
																	children: [isAdminReport(fb) && /* @__PURE__ */ _jsxDEV("span", {
																		className: "text-[9px] font-extrabold px-1.5 py-0.5 rounded w-fit bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400 border border-red-200 dark:border-red-800",
																		children: "🚩 LAPORAN ADMIN"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 736,
																		columnNumber: 65
																	}, this), /* @__PURE__ */ _jsxDEV("span", {
																		className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 w-fit",
																		children: formatFeedbackReason(fb.reason)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 740,
																		columnNumber: 61
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 734,
																	columnNumber: 57
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 733,
																columnNumber: 105
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-xs text-slate-700 dark:text-slate-300 max-w-xs break-words",
																children: fb.description || fb.content || fb.message || "—"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 746,
																columnNumber: 53
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-xs font-medium text-slate-600 dark:text-slate-400",
																children: fb.formTitle || fb.formId ? /* @__PURE__ */ _jsxDEV("span", { children: fb.formTitle || `Form #${fb.formId}` }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 751,
																	columnNumber: 61
																}, this) : /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-slate-400 italic",
																	children: "Umum"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 753,
																	columnNumber: 61
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 749,
																columnNumber: 53
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-[11px] text-slate-500 dark:text-slate-400 whitespace-nowrap",
																children: fb.createdAt ? new Date(fb.createdAt).toLocaleDateString("id-ID", {
																	day: "numeric",
																	month: "short",
																	year: "numeric"
																}) : "—"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 756,
																columnNumber: 53
															}, this),
															/* @__PURE__ */ _jsxDEV("td", {
																className: "py-3.5 px-4 text-right",
																children: /* @__PURE__ */ _jsxDEV("div", {
																	className: "flex items-center justify-end gap-1.5",
																	children: [fb.formId && (fb.isTakedown ? /* @__PURE__ */ _jsxDEV("button", {
																		onClick: () => handleRestoreFromFeedback(fb.id),
																		disabled: actionLoadingId === `fb_rst_${fb.id}`,
																		className: "p-1.5 text-emerald-500 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors cursor-pointer",
																		title: "Pulihkan Formulir dari Laporan",
																		children: /* @__PURE__ */ _jsxDEV(RefreshCw, { size: 15 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 769,
																			columnNumber: 73
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 763,
																		columnNumber: 69
																	}, this) : /* @__PURE__ */ _jsxDEV("button", {
																		onClick: () => handleTakedownFromFeedback(fb.id),
																		disabled: actionLoadingId === `fb_td_${fb.id}`,
																		className: "p-1.5 text-amber-500 hover:text-amber-700 hover:bg-amber-50 dark:hover:bg-amber-950/40 rounded-lg transition-colors cursor-pointer",
																		title: "Take Down Formulir dari Laporan",
																		children: /* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 15 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 778,
																			columnNumber: 73
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 772,
																		columnNumber: 69
																	}, this)), /* @__PURE__ */ _jsxDEV("button", {
																		onClick: () => handleDeleteFeedback(fb.id),
																		disabled: actionLoadingId === `fb_del_${fb.id}`,
																		className: "p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition-colors cursor-pointer",
																		title: "Hapus Umpan Balik",
																		children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 15 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 789,
																			columnNumber: 65
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 783,
																		columnNumber: 61
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 760,
																	columnNumber: 57
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 759,
																columnNumber: 53
															}, this)
														]
													}, fb.id, true, {
														fileName: _jsxFileName,
														lineNumber: 728,
														columnNumber: 49
													}, this))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 719,
													columnNumber: 37
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 707,
												columnNumber: 33
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 685,
											columnNumber: 29
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 664,
										columnNumber: 29
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 439,
								columnNumber: 21
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 336,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 314,
				columnNumber: 13
			}, this),
			selectedUserDetail && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(UserIcon, {
								size: 16,
								className: "text-[#00897B]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 813,
								columnNumber: 33
							}, this), "Detail Akun Pengguna"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 812,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSelectedUserDetail(null),
							className: "p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 817,
								columnNumber: 33
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 816,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 811,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "p-6 space-y-4",
						children: selectedUserDetail.loading ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-8 text-center",
							children: /* @__PURE__ */ _jsxDEV(Loader2, { className: "w-6 h-6 animate-spin mx-auto text-[#00897B]" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 822,
								columnNumber: 67
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 822,
							columnNumber: 33
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-14 h-14 rounded-2xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 flex items-center justify-center text-xl font-black text-[#00897B]",
								children: selectedUserDetail.fullname?.slice(0, 2).toUpperCase() || "US"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 826,
								columnNumber: 41
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-base text-slate-900 dark:text-white",
									children: selectedUserDetail.fullname
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 830,
									columnNumber: 45
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 font-mono",
									children: ["@", selectedUserDetail.username]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 831,
									columnNumber: 45
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex gap-2 mt-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] font-extrabold px-2 py-0.5 bg-purple-50 text-purple-700 rounded-full border border-purple-200",
										children: selectedUserDetail.role || "USER"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 833,
										columnNumber: 49
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: `text-[10px] font-bold px-2 py-0.5 rounded-full ${selectedUserDetail.isActive !== false ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`,
										children: selectedUserDetail.isActive !== false ? "Aktif" : "Diblokir"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 836,
										columnNumber: 49
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 832,
									columnNumber: 45
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 829,
								columnNumber: 41
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 825,
							columnNumber: 37
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3 pt-2 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-400 font-medium text-[10px]",
										children: "EMAIL"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 845,
										columnNumber: 45
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-800 dark:text-slate-200 truncate",
										children: selectedUserDetail.email || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 846,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 844,
									columnNumber: 41
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-400 font-medium text-[10px]",
										children: "TANGGAL LAHIR"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 849,
										columnNumber: 45
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-800 dark:text-slate-200",
										children: selectedUserDetail.birthdate || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 850,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 848,
									columnNumber: 41
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-400 font-medium text-[10px]",
										children: "TOTAL FORMULIR"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 853,
										columnNumber: 45
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-800 dark:text-slate-200",
										children: selectedUserDetail.formCount ?? 0
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 854,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 852,
									columnNumber: 41
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-400 font-medium text-[10px]",
										children: "TOTAL RESPONS"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 857,
										columnNumber: 45
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-800 dark:text-slate-200",
										children: selectedUserDetail.responseCount ?? 0
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 858,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 856,
									columnNumber: 41
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl col-span-2",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-400 font-medium text-[10px]",
										children: "TANGGAL BERGABUNG"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 861,
										columnNumber: 45
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-800 dark:text-slate-200",
										children: selectedUserDetail.createdAt ? new Date(selectedUserDetail.createdAt).toLocaleString("id-ID") : "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 862,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 860,
									columnNumber: 41
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 843,
							columnNumber: 37
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 824,
							columnNumber: 33
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 820,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 810,
					columnNumber: 21
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 809,
				columnNumber: 17
			}, this),
			selectedFormDetail && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(FileText, {
								size: 16,
								className: "text-[#00897B]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 880,
								columnNumber: 33
							}, this), "Detail Formulir"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 879,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSelectedFormDetail(null),
							className: "p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 884,
								columnNumber: 33
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 883,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 878,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "p-6 space-y-4 overflow-y-auto",
						children: selectedFormDetail.loading ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-8 text-center",
							children: /* @__PURE__ */ _jsxDEV(Loader2, { className: "w-6 h-6 animate-spin mx-auto text-[#00897B]" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 889,
								columnNumber: 67
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 889,
							columnNumber: 33
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-bold text-lg text-slate-900 dark:text-white",
								children: selectedFormDetail.title || "Formulir Tanpa Judul"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 893,
								columnNumber: 41
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 font-mono mt-0.5",
								children: ["/f/", selectedFormDetail.formLink]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 894,
								columnNumber: 41
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 892,
								columnNumber: 37
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl",
									children: [
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-400 font-medium text-[10px]",
											children: "PEMILIK FORM"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 899,
											columnNumber: 45
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "font-bold text-slate-800 dark:text-slate-200",
											children: selectedFormDetail.owner?.fullname || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 900,
											columnNumber: 45
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] text-slate-400",
											children: selectedFormDetail.owner?.email || ""
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 901,
											columnNumber: 45
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 898,
									columnNumber: 41
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl",
									children: [
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-400 font-medium text-[10px]",
											children: "STATUS & RESPONS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 904,
											columnNumber: 45
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "font-bold text-slate-800 dark:text-slate-200 uppercase",
											children: selectedFormDetail.status
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 905,
											columnNumber: 45
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] text-[#00897B] font-bold",
											children: [selectedFormDetail.responseCount ?? 0, " respons"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 906,
											columnNumber: 45
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 903,
									columnNumber: 41
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 897,
								columnNumber: 37
							}, this),
							selectedFormDetail.settings && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider",
									children: "Pengaturan Formulir"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 912,
									columnNumber: 45
								}, this), /* @__PURE__ */ _jsxDEV("pre", {
									className: "p-3 bg-slate-900 text-teal-300 font-mono text-[11px] rounded-xl overflow-x-auto",
									children: JSON.stringify(selectedFormDetail.settings, null, 2)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 913,
									columnNumber: 45
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 911,
								columnNumber: 41
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-slate-400 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("p", { children: ["Dibuat pada: ", selectedFormDetail.createdAt ? new Date(selectedFormDetail.createdAt).toLocaleString("id-ID") : "—"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 920,
									columnNumber: 41
								}, this), selectedFormDetail.takenDownAt && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-red-500 font-bold",
									children: ["Di-takedown pada: ", new Date(selectedFormDetail.takenDownAt).toLocaleString("id-ID")]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 922,
									columnNumber: 45
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 919,
								columnNumber: 37
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 891,
							columnNumber: 33
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 887,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 877,
					columnNumber: 21
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 876,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 311,
		columnNumber: 9
	}, this);
}
_s(AdminDashboardPage, "RpEmBU0V0QozclzMzK80JXYLCMk=", false, function() {
	return [useNavigate, useDebounce];
});
_c = AdminDashboardPage;
var _c;
$RefreshReg$(_c, "AdminDashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/admin/AdminDashboardPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/admin/AdminDashboardPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/admin/AdminDashboardPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/admin/AdminDashboardPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLG1CQUFtQjtBQUM1QixTQUNJLE9BQU8sVUFBVSxRQUFRLFFBQVEsUUFBUSxXQUFXLFNBQ3BELEtBQUssY0FBYyxLQUFLLGVBQWUsV0FBVyxlQUNsRCxHQUFHLGNBQWMsVUFBVSxNQUFNLFFBQVEsVUFBVSxNQUFNLG1CQUN0RDtBQUNQLE9BQU8sYUFBYTtBQUNwQixTQUNJLGVBQWUsb0JBQW9CLGVBQWUsb0JBQ2xELGtCQUFrQixjQUFjLG1CQUFtQixpQkFDbkQsbUJBQW1CLGtCQUFrQixpQkFBaUIscUJBQ3RELCtCQUErQiw4QkFDL0IsY0FBYyxjQUFjLGdCQUN6QjtBQUNQLE9BQU8saUJBQWlCOzs7O0FBRXhCLGVBQWUsU0FBUyxxQkFBcUI7O0NBQ3pDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sQ0FBQyxRQUFRLGVBQWUsYUFBYSxDQUFDO0NBQzVDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxDQUFDLENBQUM7Q0FDckMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLENBQUMsQ0FBQztDQUNyQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDLENBQUM7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsT0FBTzs7Q0FFbEQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxLQUFLO0NBQzFELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxrQkFBa0IsWUFBWSxhQUFhLEdBQUc7Q0FDcEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxJQUFJO0NBQzNELE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsS0FBSzs7Q0FHbEUsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBUyxJQUFJO0NBQ2pFLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsS0FBSztDQUNoRSxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLElBQUk7Q0FDakUsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxLQUFLO0NBRWhFLGdCQUFnQjtFQUNaLElBQUksc0JBQXNCLG9CQUFvQjtHQUMxQyxTQUFTLEtBQUssTUFBTSxXQUFXO0VBQ25DLE9BQU87R0FDSCxTQUFTLEtBQUssTUFBTSxXQUFXO0VBQ25DO0VBRUEsYUFBYTtHQUNULFNBQVMsS0FBSyxNQUFNLFdBQVc7RUFDbkM7Q0FDSixHQUFHLENBQUMsb0JBQW9CLGtCQUFrQixDQUFDO0NBRTNDLGdCQUFnQjtFQUNaLE1BQU0sWUFBWSxNQUFNLFFBQVEsR0FBRSxDQUFFLFlBQVk7RUFDaEQsSUFBSSxhQUFhLFdBQVcsYUFBYSxlQUFlO0dBQ3BELFNBQVMsWUFBWTtHQUNyQjtFQUNKO0VBRUEsTUFBTSxPQUFPLFlBQVk7R0FDckIsV0FBVyxJQUFJO0dBQ2YsSUFBSTtJQUNBLE1BQU0sQ0FBQyxVQUFVLFVBQVUsZUFBZSxNQUFNLFFBQVEsSUFBSTtLQUN4RCxjQUFjO0tBQ2QsY0FBYztLQUNkLGlCQUFpQjtJQUNyQixDQUFDO0lBRUQsSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsT0FBTyxZQUFZLFdBQVcsS0FBSztLQUNsRixhQUFhO0tBQ2IsU0FBUyxRQUFRO0tBQ2pCO0lBQ0o7SUFFQSxJQUFJLFNBQVMsTUFBTSxTQUFTLE1BQU07S0FDOUIsTUFBTSxRQUFRLE1BQU0sUUFBUSxTQUFTLElBQUksSUFBSSxTQUFTLE9BQVEsU0FBUyxNQUFNLFNBQVMsQ0FBQztLQUN2RixTQUFTLEtBQUs7SUFDbEI7SUFDQSxJQUFJLFNBQVMsTUFBTSxTQUFTLE1BQU07S0FDOUIsTUFBTSxRQUFRLE1BQU0sUUFBUSxTQUFTLElBQUksSUFBSSxTQUFTLE9BQVEsU0FBUyxNQUFNLFNBQVMsQ0FBQztLQUN2RixTQUFTLEtBQUs7SUFDbEI7SUFDQSxJQUFJLFlBQVksTUFBTSxZQUFZLE1BQU07S0FDcEMsTUFBTSxTQUFTLE1BQU0sUUFBUSxZQUFZLElBQUksSUFBSSxZQUFZLE9BQVEsWUFBWSxNQUFNLFNBQVMsQ0FBQztLQUNqRyxhQUFhLE1BQU07SUFDdkI7R0FDSixTQUFTLEtBQUs7SUFDVixRQUFRLE1BQU0sNkJBQTZCLEdBQUc7SUFDOUMsVUFBVSxvQ0FBb0MsT0FBTztHQUN6RCxVQUFVO0lBQ04sV0FBVyxLQUFLO0dBQ3BCO0VBQ0o7RUFDQSxLQUFLO0NBQ1QsR0FBRyxDQUFDLFVBQVUsSUFBSSxDQUFDO0NBRWYsTUFBTSxhQUFhLEtBQUssT0FBTyxjQUFjO0VBQzdDLFNBQVM7R0FBRTtHQUFLO0VBQUssQ0FBQztFQUN0QixpQkFBaUIsU0FBUyxJQUFJLEdBQUcsR0FBSTtDQUN6QztDQUVBLE1BQU0saUJBQWlCLFFBQVEsR0FBRyxVQUFVLEdBQUUsQ0FBRSxXQUFXLFFBQVE7Q0FFbkUsTUFBTSx3QkFBd0IsY0FBYztFQUN4QyxJQUFJLENBQUMsV0FBVyxPQUFPO0VBQ3ZCLE1BQU0sV0FBVyxVQUFVLFdBQVcsUUFBUSxJQUFJLFVBQVUsTUFBTSxDQUFDLElBQUk7RUFDdkUsT0FBTyxTQUNGLE1BQU0sR0FBRyxDQUFDLENBQ1YsS0FBSSxNQUFLLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQ2hELEtBQUssR0FBRztDQUNqQjs7Q0FHQSxNQUFNLGlCQUFpQixPQUFPLFdBQVc7RUFDckMscUJBQXFCLElBQUk7RUFDekIsc0JBQXNCO0dBQUUsSUFBSTtHQUFRLFNBQVM7RUFBSyxDQUFDO0VBQ25ELE1BQU0sTUFBTSxNQUFNLG1CQUFtQixNQUFNO0VBQzNDLHFCQUFxQixLQUFLO0VBQzFCLElBQUksSUFBSSxNQUFNLElBQUksTUFBTTtHQUNwQixzQkFBc0IsSUFBSSxJQUFJO0VBQ2xDLE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyxnQ0FBZ0MsT0FBTztHQUNoRSxzQkFBc0IsSUFBSTtFQUM5QjtDQUNKO0NBRUEsTUFBTSxnQkFBZ0IsT0FBTyxXQUFXO0VBQ3BDLElBQUksQ0FBQyxPQUFPLFFBQVEsNkRBQTZELEdBQUc7RUFDcEYsbUJBQW1CLFlBQVksUUFBUTtFQUN2QyxNQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07RUFDckMsbUJBQW1CLElBQUk7RUFDdkIsSUFBSSxJQUFJLElBQUk7R0FDUixVQUFTLFNBQVEsS0FBSyxLQUFJLE1BQUssRUFBRSxPQUFPLFNBQVM7SUFBRSxHQUFHO0lBQUcsVUFBVTtHQUFNLElBQUksQ0FBQyxDQUFDO0dBQy9FLFVBQVUscUNBQXFDO0VBQ25ELE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyw0QkFBNEIsT0FBTztFQUNoRTtDQUNKO0NBRUEsTUFBTSxxQkFBcUIsT0FBTyxXQUFXO0VBQ3pDLG1CQUFtQixZQUFZLFFBQVE7RUFDdkMsTUFBTSxNQUFNLE1BQU0sa0JBQWtCLE1BQU07RUFDMUMsbUJBQW1CLElBQUk7RUFDdkIsSUFBSSxJQUFJLElBQUk7R0FDUixVQUFTLFNBQVEsS0FBSyxLQUFJLE1BQUssRUFBRSxPQUFPLFNBQVM7SUFBRSxHQUFHO0lBQUcsVUFBVTtHQUFLLElBQUksQ0FBQyxDQUFDO0dBQzlFLFVBQVUsc0NBQXNDO0VBQ3BELE9BQU87R0FDSCxVQUFVLElBQUksV0FBVywrQkFBK0IsT0FBTztFQUNuRTtDQUNKOzs7Ozs7Ozs7Ozs7OztDQWdCQSxNQUFNLGlCQUFpQixPQUFPLFdBQVc7RUFDckMscUJBQXFCLElBQUk7RUFDekIsc0JBQXNCO0dBQUUsSUFBSTtHQUFRLFNBQVM7RUFBSyxDQUFDO0VBQ25ELE1BQU0sTUFBTSxNQUFNLG1CQUFtQixNQUFNO0VBQzNDLHFCQUFxQixLQUFLO0VBQzFCLElBQUksSUFBSSxNQUFNLElBQUksTUFBTTtHQUNwQixzQkFBc0IsSUFBSSxJQUFJO0VBQ2xDLE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyxnQ0FBZ0MsT0FBTztHQUNoRSxzQkFBc0IsSUFBSTtFQUM5QjtDQUNKO0NBRUEsTUFBTSxxQkFBcUIsT0FBTyxXQUFXO0VBQ3pDLElBQUksQ0FBQyxPQUFPLFFBQVEsa0VBQWtFLEdBQUc7RUFDekYsbUJBQW1CLFdBQVcsUUFBUTtFQUN0QyxNQUFNLE1BQU0sTUFBTSxrQkFBa0IsTUFBTTtFQUMxQyxtQkFBbUIsSUFBSTtFQUN2QixJQUFJLElBQUksSUFBSTtHQUNSLFVBQVMsU0FBUSxLQUFLLEtBQUksTUFBSyxFQUFFLE9BQU8sU0FBUztJQUFFLEdBQUc7SUFBRyxhQUFhLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUFFLElBQUksQ0FBQyxDQUFDO0dBQ3JHLFVBQVUsK0JBQStCO0VBQzdDLE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyw0QkFBNEIsT0FBTztFQUNoRTtDQUNKO0NBRUEsTUFBTSxvQkFBb0IsT0FBTyxXQUFXO0VBQ3hDLG1CQUFtQixZQUFZLFFBQVE7RUFDdkMsTUFBTSxNQUFNLE1BQU0saUJBQWlCLE1BQU07RUFDekMsbUJBQW1CLElBQUk7RUFDdkIsSUFBSSxJQUFJLElBQUk7R0FDUixVQUFTLFNBQVEsS0FBSyxLQUFJLE1BQUssRUFBRSxPQUFPLFNBQVM7SUFBRSxHQUFHO0lBQUcsYUFBYTtHQUFLLElBQUksQ0FBQyxDQUFDO0dBQ2pGLFVBQVUsd0NBQXdDO0VBQ3RELE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyw2QkFBNkIsT0FBTztFQUNqRTtDQUNKO0NBRUEsTUFBTSxtQkFBbUIsT0FBTyxXQUFXO0VBQ3ZDLElBQUksQ0FBQyxPQUFPLFFBQVEsMERBQTBELEdBQUc7RUFDakYsbUJBQW1CLFlBQVksUUFBUTtFQUN2QyxNQUFNLE1BQU0sTUFBTSxnQkFBZ0IsTUFBTTtFQUN4QyxtQkFBbUIsSUFBSTtFQUN2QixJQUFJLElBQUksSUFBSTtHQUNSLFVBQVMsU0FBUSxLQUFLLFFBQU8sTUFBSyxFQUFFLE9BQU8sTUFBTSxDQUFDO0dBQ2xELFVBQVUsMkJBQTJCO0VBQ3pDLE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyw0QkFBNEIsT0FBTztFQUNoRTtDQUNKOztDQUdBLE1BQU0sdUJBQXVCLE9BQU8sU0FBUztFQUN6QyxJQUFJLENBQUMsT0FBTyxRQUFRLGdDQUFnQyxHQUFHO0VBQ3ZELG1CQUFtQixVQUFVLE1BQU07RUFDbkMsTUFBTSxNQUFNLE1BQU0sb0JBQW9CLElBQUk7RUFDMUMsbUJBQW1CLElBQUk7RUFDdkIsSUFBSSxJQUFJLElBQUk7R0FDUixjQUFhLFNBQVEsS0FBSyxRQUFPLE9BQU0sR0FBRyxPQUFPLElBQUksQ0FBQztHQUN0RCxVQUFVLDhCQUE4QjtFQUM1QyxPQUFPO0dBQ0gsVUFBVSxJQUFJLFdBQVcsK0JBQStCLE9BQU87RUFDbkU7Q0FDSjtDQUVBLE1BQU0sNkJBQTZCLE9BQU8sU0FBUztFQUMvQyxJQUFJLENBQUMsT0FBTyxRQUFRLDhDQUE4QyxHQUFHO0VBQ3JFLG1CQUFtQixTQUFTLE1BQU07RUFDbEMsTUFBTSxNQUFNLE1BQU0sOEJBQThCLElBQUk7RUFDcEQsbUJBQW1CLElBQUk7RUFDdkIsSUFBSSxJQUFJLElBQUk7R0FDUixjQUFhLFNBQVEsS0FBSyxLQUFJLE9BQU0sR0FBRyxPQUFPLE9BQU87SUFBRSxHQUFHO0lBQUksWUFBWTtHQUFLLElBQUksRUFBRSxDQUFDO0dBQ3RGLFVBQVUsdUNBQXVDO0VBQ3JELE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyw0QkFBNEIsT0FBTztFQUNoRTtDQUNKO0NBRUEsTUFBTSw0QkFBNEIsT0FBTyxTQUFTO0VBQzlDLG1CQUFtQixVQUFVLE1BQU07RUFDbkMsTUFBTSxNQUFNLE1BQU0sNkJBQTZCLElBQUk7RUFDbkQsbUJBQW1CLElBQUk7RUFDdkIsSUFBSSxJQUFJLElBQUk7R0FDUixjQUFhLFNBQVEsS0FBSyxLQUFJLE9BQU0sR0FBRyxPQUFPLE9BQU87SUFBRSxHQUFHO0lBQUksWUFBWTtHQUFNLElBQUksRUFBRSxDQUFDO0dBQ3ZGLFVBQVUsc0NBQXNDO0VBQ3BELE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyw2QkFBNkIsT0FBTztFQUNqRTtDQUNKOztDQUdBLE1BQU0sZ0JBQWdCLE1BQU0sUUFBTyxNQUFLO0VBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxHQUFHLE9BQU87RUFDcEMsTUFBTSxJQUFJLGdCQUFnQixZQUFZO0VBQ3RDLE9BQ0ssRUFBRSxZQUFZLEVBQUUsU0FBUyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDakQsRUFBRSxZQUFZLEVBQUUsU0FBUyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDakQsRUFBRSxTQUFTLEVBQUUsTUFBTSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDM0MsRUFBRSxRQUFRLEVBQUUsS0FBSyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUM7Q0FFbEQsQ0FBQztDQUVELE1BQU0sZ0JBQWdCLE1BQU0sUUFBTyxNQUFLO0VBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxHQUFHLE9BQU87RUFDcEMsTUFBTSxJQUFJLGdCQUFnQixZQUFZO0VBQ3RDLE1BQU0sUUFBUSxFQUFFLGFBQWEsRUFBRSxPQUFPLFlBQVksRUFBRSxjQUFjO0VBQ2xFLE9BQ0ssRUFBRSxTQUFTLEVBQUUsTUFBTSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDM0MsRUFBRSxZQUFZLEVBQUUsU0FBUyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDbEQsTUFBTSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUM7Q0FFdEMsQ0FBQztDQUVHLE1BQU0sb0JBQW9CLFVBQVUsUUFBTyxPQUFNO0VBQ2pELElBQUksdUJBQXVCLGFBQWEsQ0FBQyxjQUFjLEVBQUUsR0FBRyxPQUFPO0VBQ25FLElBQUksdUJBQXVCLFdBQVcsY0FBYyxFQUFFLEdBQUcsT0FBTztFQUVoRSxJQUFJLENBQUMsZ0JBQWdCLEtBQUssR0FBRyxPQUFPO0VBQ3BDLE1BQU0sSUFBSSxnQkFBZ0IsWUFBWTtFQUN0QyxPQUNLLEdBQUcsZUFBZSxHQUFHLFlBQVksWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQ3pELEdBQUcsVUFBVSxHQUFHLE9BQU8sWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQy9DLEdBQUcsYUFBYSxHQUFHLFVBQVUsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQ3JELEdBQUcsWUFBWSxHQUFHLFNBQVMsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQ25ELEdBQUcsYUFBYSxHQUFHLFVBQVUsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDO0NBRTlELENBQUM7O0NBR0QsTUFBTSxpQkFBaUI7RUFBQztFQUFVO0VBQVE7RUFBVztFQUFnQjtFQUFhO0NBQVM7Q0FDM0YsTUFBTSxrQkFBa0IsbUJBQW1CLFFBQ3JDLG9CQUNBLG1CQUFtQixXQUNuQixrQkFBa0IsUUFBTyxPQUFNLGVBQWUsTUFBSyxPQUFNLEdBQUcsVUFBVSxHQUFFLENBQUUsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUNwRyxrQkFBa0IsUUFBTyxPQUFNLENBQUMsZUFBZSxNQUFLLE9BQU0sR0FBRyxVQUFVLEdBQUUsQ0FBRSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0NBRTNHLElBQUksU0FBUyxPQUNULHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1gsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNJLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGlFQUFrRTs7OzthQUNyRix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF5RDtHQUFnQzs7OztXQUNyRzs7Ozs7O0NBQ0o7Ozs7O0NBR1QsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0ksd0JBQUMsU0FBRCxDQUFVOzs7OztHQUVWLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFVBQUQ7UUFBUSxlQUFlLFNBQVMsWUFBWTtRQUFHLFdBQVU7a0JBQ3JELHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O09BQ2xCOzs7O2lCQUNSLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNJLHdCQUFDLFFBQUQ7U0FBUSxNQUFNO1NBQUksV0FBVTtRQUFxQzs7OztrQkFBQywyQkFFbEU7Ozs7O2lCQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE2QztPQUErRDs7OztlQUN4SDs7OztlQUNKOzs7Ozs7S0FDSjs7Ozs7S0FFSixTQUNHLHdCQUFDLE9BQUQ7TUFBSyxXQUFXLHdHQUF3RyxNQUFNLFNBQVMsVUFBVSxlQUFlO2dCQUMzSixNQUFNO0tBQ047Ozs7O0tBR1Qsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FHaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FFSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNYLHdCQUFDLE9BQUQ7WUFBTyxNQUFNO1lBQUksV0FBVTtXQUFpQjs7Ozs7VUFDM0M7Ozs7b0JBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBbUY7V0FFN0Y7Ozs7cUJBQ0gsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1QsTUFBTTtXQUNQOzs7O21CQUNIOzs7OztrQkFDSjs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWCx3QkFBQyxVQUFEO1lBQVUsTUFBTTtZQUFJLFdBQVU7V0FBaUI7Ozs7O1VBQzlDOzs7O29CQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQW1GO1dBRTdGOzs7O3FCQUNILHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNULE1BQU07V0FDUDs7OzttQkFDSDs7Ozs7a0JBQ0o7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1gsd0JBQUMsZUFBRDtZQUFlLE1BQU07WUFBSSxXQUFVO1dBQWlCOzs7OztVQUNuRDs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFtRjtXQUU3Rjs7OztxQkFDSCx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDVCxVQUFVO1dBQ1g7Ozs7bUJBQ0g7Ozs7O2tCQUNZOzs7Ozs7UUFDQTs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FHSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNJLHdCQUFDLFVBQUQ7V0FDSSxlQUFlLGFBQWEsT0FBTztXQUNuQyxXQUFXLGdLQUNQLGNBQWMsVUFDUixzQ0FDQTtxQkFMZDtZQU9DO1lBQ2MsTUFBTTtZQUFPO1dBQ3BCOzs7Ozs7VUFFUix3QkFBQyxVQUFEO1dBQ0ksZUFBZSxhQUFhLE9BQU87V0FDbkMsV0FBVyxnS0FDUCxjQUFjLFVBQ1Isc0NBQ0E7cUJBTGQ7WUFPQztZQUNjLE1BQU07WUFBTztXQUNwQjs7Ozs7O1VBRVIsd0JBQUMsVUFBRDtXQUNJLGVBQWUsYUFBYSxVQUFVO1dBQ3RDLFdBQVcsZ0tBQ1AsY0FBYyxhQUNSLHNDQUNBO3FCQUxkO1lBT0M7WUFDaUIsVUFBVTtZQUFPO1dBQzNCOzs7Ozs7U0FDUDs7Ozs7a0JBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxRQUFEO1VBQVEsTUFBTTtVQUFJLFdBQVU7U0FBMkQ7Ozs7bUJBQ3ZGLHdCQUFDLFNBQUQ7VUFDSSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVUsTUFBSyxlQUFlLEVBQUUsT0FBTyxLQUFLO1VBQzVDLGFBQVk7VUFDWixXQUFVO1NBQ2I7Ozs7aUJBQ0E7Ozs7O2dCQUNKOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUdLLGNBQWMsV0FDWCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWCx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBakIsQ0FDSSx3QkFBQyxTQUFELFlBQ0ksd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQ7YUFDSSx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFZOzs7OzthQUN0Qyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFTOzs7OzthQUNuQyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFTOzs7OzthQUNuQyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFlOzs7OzthQUN6Qyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBd0I7YUFBaUI7Ozs7O2FBQ3ZELHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUF1QjthQUFROzs7OztZQUM3Qzs7Ozs7b0JBQ0Q7Ozs7cUJBQ1Asd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQ1osY0FBYyxXQUFXLElBQ3RCLHdCQUFDLE1BQUQsWUFDSSx3QkFBQyxNQUFEO2FBQUksU0FBUzthQUFHLFdBQVU7dUJBQTBDO1lBQWlDOzs7O3FCQUNyRzs7Ozt1QkFFSixjQUFjLEtBQUksTUFBSzthQUNuQixNQUFNLFdBQVcsRUFBRSxhQUFhO2FBQ2hDLE1BQU0sU0FBUyxFQUFFLE9BQU8sTUFBTTthQUM5QixNQUFNLGVBQWUsRUFBRSxRQUFRLEdBQUUsQ0FBRSxZQUFZLE1BQU0sWUFBWSxFQUFFLFFBQVEsR0FBRSxDQUFFLFlBQVksTUFBTTthQUVqRyxPQUNJLHdCQUFDLE1BQUQ7Y0FBZSxXQUFVO3dCQUF6QjtlQUNJLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFBZCxDQUNJLHdCQUFDLE9BQUQ7aUJBQUssV0FBVTsyQkFBZixDQUNJLHdCQUFDLFFBQUQsWUFBTyxFQUFFLFNBQWU7Ozs7MkJBQ3ZCLFVBQVUsd0JBQUMsUUFBRDtrQkFBTSxXQUFVOzRCQUFrRztpQkFBVTs7Ozt5QkFDdEk7Ozs7OzBCQUNMLHdCQUFDLE9BQUQ7aUJBQUssV0FBVTsyQkFBZixDQUEwRSxLQUFFLEVBQUUsUUFBYzs7Ozs7d0JBQzVGOzs7Ozs7ZUFDSix3QkFBQyxNQUFEO2dCQUFJLFdBQVU7MEJBQXNFLEVBQUU7ZUFBVTs7Ozs7ZUFDaEcsd0JBQUMsTUFBRDtnQkFBSSxXQUFVOzBCQUNWLHdCQUFDLFFBQUQ7aUJBQU0sV0FBVyx5REFDYixjQUNNLDRIQUNBOzJCQUVMLEVBQUUsUUFBUTtnQkFDVDs7Ozs7ZUFDTjs7Ozs7ZUFDSix3QkFBQyxNQUFEO2dCQUFJLFdBQVU7MEJBQ1Ysd0JBQUMsUUFBRDtpQkFBTSxXQUFXLGlGQUNiLFdBQ00sMEdBQ0E7MkJBSFYsQ0FLSyxXQUFXLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7NEJBQUksd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OzsyQkFDeEQsV0FBVyxzQkFBc0IsT0FDaEM7Ozs7OztlQUNOOzs7OztlQUNKLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFBZDtpQkFDSyxFQUFFLGFBQWE7aUJBQUU7aUJBQVMsRUFBRSxpQkFBaUI7aUJBQUU7Z0JBQ2hEOzs7Ozs7ZUFDSix3QkFBQyxNQUFEO2dCQUFJLFdBQVU7MEJBQ1Ysd0JBQUMsT0FBRDtpQkFBSyxXQUFVOzJCQUFmLENBRUksd0JBQUMsVUFBRDtrQkFDSSxlQUFlLGVBQWUsRUFBRSxFQUFFO2tCQUNsQyxXQUFVO2tCQUNWLE9BQU07NEJBRU4sd0JBQUMsS0FBRCxFQUFLLE1BQU0sR0FBSzs7Ozs7aUJBQ1o7Ozs7MkJBR1AsQ0FBQyxlQUFlLENBQUMsV0FDZCxXQUNJLHdCQUFDLFVBQUQ7a0JBQ0ksZUFBZSxtQkFBbUIsRUFBRSxFQUFFO2tCQUN0QyxVQUFVLG9CQUFvQixZQUFZLEVBQUU7a0JBQzVDLFdBQVU7a0JBQ1YsT0FBTTs0QkFFTix3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztpQkFDcEI7Ozs7NEJBRVIsd0JBQUMsVUFBRDtrQkFDSSxlQUFlLGNBQWMsRUFBRSxFQUFFO2tCQUNqQyxVQUFVLG9CQUFvQixZQUFZLEVBQUU7a0JBQzVDLFdBQVU7a0JBQ1YsT0FBTTs0QkFFTix3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OztpQkFDWjs7OzswQkFlZjs7Ozs7O2VBQ0w7Ozs7O2NBQ0o7Z0JBOUVLLEVBQUU7Ozs7b0JBOEVQO1lBRVosQ0FBQztXQUVGOzs7O21CQUNKOzs7Ozs7U0FDTjs7Ozs7U0FJUixjQUFjLFdBQ1gsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1gsd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0ksd0JBQUMsU0FBRCxZQUNJLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkO2FBQ0ksd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQVk7YUFBa0I7Ozs7O2FBQzVDLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUFZO2FBQVc7Ozs7O2FBQ3JDLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUFZO2FBQW9COzs7OzthQUM5Qyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFtQjs7Ozs7YUFDN0Msd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQVk7YUFBVzs7Ozs7YUFDckMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQXVCO2FBQVE7Ozs7O1lBQzdDOzs7OztvQkFDRDs7OztxQkFDUCx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFDWixjQUFjLFdBQVcsSUFDdEIsd0JBQUMsTUFBRCxZQUNJLHdCQUFDLE1BQUQ7YUFBSSxTQUFTO2FBQUcsV0FBVTt1QkFBMEM7WUFBaUM7Ozs7cUJBQ3JHOzs7O3VCQUVKLGNBQWMsS0FBSSxNQUFLO2FBQ25CLE1BQU0sY0FBYyxDQUFDLENBQUMsRUFBRTthQUN4QixNQUFNLGVBQWUsRUFBRSxVQUFVLEdBQUUsQ0FBRSxZQUFZLE1BQU07YUFFdkQsT0FDSSx3QkFBQyxNQUFEO2NBQWUsV0FBVTt3QkFBekI7ZUFDSSx3QkFBQyxNQUFEO2dCQUFJLFdBQVU7MEJBQWQsQ0FDSSx3QkFBQyxPQUFEO2lCQUFLLFdBQVU7MkJBQXlELEVBQUUsU0FBUztnQkFBNEI7Ozs7MEJBQy9HLHdCQUFDLE9BQUQ7aUJBQUssV0FBVTsyQkFBZixDQUEwRSxPQUFJLEVBQUUsUUFBYzs7Ozs7d0JBQzlGOzs7Ozs7ZUFDSix3QkFBQyxNQUFEO2dCQUFJLFdBQVU7MEJBQ1QsRUFBRSxhQUFhLEVBQUUsT0FBTyxZQUFZLEVBQUUsY0FBYztlQUNyRDs7Ozs7ZUFDSix3QkFBQyxNQUFEO2dCQUFJLFdBQVU7MEJBQ1Ysd0JBQUMsUUFBRDtpQkFBTSxXQUFXLGtEQUNiLGNBQ00sZ0hBQ0E7MkJBRUwsRUFBRTtnQkFDRDs7Ozs7ZUFDTjs7Ozs7ZUFDSix3QkFBQyxNQUFEO2dCQUFJLFdBQVU7MEJBQ1QsY0FDRyx3QkFBQyxRQUFEO2lCQUFNLFdBQVU7MkJBQWhCLENBQ0ksd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7OzsyQkFBQyxjQUN6Qjs7Ozs7MkJBRU4sd0JBQUMsUUFBRDtpQkFBTSxXQUFVOzJCQUFpRTtnQkFFM0U7Ozs7O2VBRVY7Ozs7O2VBQ0osd0JBQUMsTUFBRDtnQkFBSSxXQUFVOzBCQUNULEVBQUUsaUJBQWlCO2VBQ3BCOzs7OztlQUNKLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFDVix3QkFBQyxPQUFEO2lCQUFLLFdBQVU7MkJBQWY7a0JBRUksd0JBQUMsVUFBRDttQkFDSSxlQUFlLGVBQWUsRUFBRSxFQUFFO21CQUNsQyxXQUFVO21CQUNWLE9BQU07NkJBRU4sd0JBQUMsS0FBRCxFQUFLLE1BQU0sR0FBSzs7Ozs7a0JBQ1o7Ozs7O2tCQUdQLGNBQ0csd0JBQUMsVUFBRDttQkFDSSxlQUFlLGtCQUFrQixFQUFFLEVBQUU7bUJBQ3JDLFVBQVUsb0JBQW9CLFlBQVksRUFBRTttQkFDNUMsV0FBVTttQkFDVixPQUFNOzZCQUVOLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O2tCQUNsQjs7Ozs2QkFFUix3QkFBQyxVQUFEO21CQUNJLGVBQWUsbUJBQW1CLEVBQUUsRUFBRTttQkFDdEMsVUFBVSxvQkFBb0IsV0FBVyxFQUFFO21CQUMzQyxXQUFVO21CQUNWLE9BQU07NkJBRU4sd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7Ozs7a0JBQ3RCOzs7OztrQkFJWix3QkFBQyxVQUFEO21CQUNJLGVBQWUsaUJBQWlCLEVBQUUsRUFBRTttQkFDcEMsVUFBVSxvQkFBb0IsWUFBWSxFQUFFO21CQUM1QyxXQUFVO21CQUNWLE9BQU07NkJBRU4sd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7a0JBQ2Y7Ozs7O2lCQUNQOzs7Ozs7ZUFDTDs7Ozs7Y0FDSjtnQkExRUssRUFBRTs7OztvQkEwRVA7WUFFWixDQUFDO1dBRUY7Ozs7bUJBQ0o7Ozs7OztTQUNOOzs7OztTQUlSLGNBQWMsY0FDWCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNWO1lBQ0c7YUFBRSxJQUFJO2FBQU8sT0FBTztZQUFRO1lBQzVCO2FBQUUsSUFBSTthQUFXLE9BQU87WUFBc0I7WUFDOUM7YUFBRSxJQUFJO2FBQVMsT0FBTztZQUFxQjtXQUMvQyxDQUFDLENBQUMsS0FBSSxNQUNGLHdCQUFDLFVBQUQ7WUFFSSxNQUFLO1lBQ0wsZUFBZSxzQkFBc0IsRUFBRSxFQUFFO1lBQ3pDLFdBQVcsOEVBQ1AsdUJBQXVCLEVBQUUsS0FDbkIsc0NBQ0E7c0JBR1QsRUFBRTtXQUNDLEdBVkMsRUFBRTs7OztrQkFVSCxDQUNYO1VBQ0E7Ozs7b0JBQ1Qsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FFSSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDVjthQUNHO2NBQUUsS0FBSztjQUFPLE9BQU87Y0FBUyxPQUFPLGtCQUFrQjthQUFPO2FBQzlEO2NBQUUsS0FBSztjQUFVLE9BQU87Y0FBYyxPQUFPLGtCQUFrQixRQUFPLE9BQU0sZUFBZSxNQUFLLE9BQU0sR0FBRyxVQUFVLEdBQUUsQ0FBRSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUFPO2FBQzFKO2NBQUUsS0FBSztjQUFXLE9BQU87Y0FBYyxPQUFPLGtCQUFrQixRQUFPLE9BQU0sQ0FBQyxlQUFlLE1BQUssT0FBTSxHQUFHLFVBQVUsR0FBRSxDQUFFLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQU87WUFDaEssQ0FBQyxDQUFDLEtBQUksUUFDRix3QkFBQyxVQUFEO2FBRUksTUFBSzthQUNMLGVBQWUsa0JBQWtCLElBQUksR0FBRzthQUN4QyxXQUFXLDBFQUNQLG1CQUFtQixJQUFJLE1BQ2pCLHdFQUNBO3VCQVBkO2NBVUssSUFBSTtjQUFNO2NBQUMsd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQWhCO2dCQUFrRDtnQkFBRSxJQUFJO2dCQUFNO2VBQU87Ozs7OzthQUM3RTtlQVZDLElBQUk7Ozs7bUJBVUwsQ0FDWDtXQUNBOzs7O3FCQUNMLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUFqQixDQUVJLHdCQUFDLFNBQUQsWUFDSSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBZDtjQUNJLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUFZO2NBQVk7Ozs7O2NBQ3RDLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUFZO2NBQVk7Ozs7O2NBQ3RDLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUFZO2NBQXVCOzs7OztjQUNqRCx3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFBWTtjQUFvQjs7Ozs7Y0FDOUMsd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQVk7Y0FBVzs7Ozs7Y0FDckMsd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQXVCO2NBQVE7Ozs7O2FBQzdDOzs7OztxQkFDRDs7OztzQkFDUCx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFDWixnQkFBZ0IsV0FBVyxJQUN4Qix3QkFBQyxNQUFELFlBQ0ksd0JBQUMsTUFBRDtjQUFJLFNBQVM7Y0FBRyxXQUFVO3dCQUNyQixtQkFBbUIsV0FBVyw2QkFBNkIsbUJBQW1CLFlBQVksNkJBQTZCO2FBQ3hIOzs7O3NCQUNKOzs7O3dCQUVKLGdCQUFnQixLQUFJLE9BQ2hCLHdCQUFDLE1BQUQ7Y0FBZ0IsV0FBVTt3QkFBMUI7ZUFDSSx3QkFBQyxNQUFEO2dCQUFJLFdBQVU7MEJBQWQsQ0FDSSx3QkFBQyxPQUFEO2lCQUFLLFdBQVU7MkJBQW9ELEdBQUcsWUFBWSxHQUFHLE1BQU0sWUFBWTtnQkFBYzs7OzswQkFDckgsd0JBQUMsT0FBRDtpQkFBSyxXQUFVOzJCQUF3QyxHQUFHLGFBQWEsR0FBRyxNQUFNLFNBQVM7Z0JBQVM7Ozs7d0JBQ2xHOzs7Ozs7ZUFDZ0Qsd0JBQUMsTUFBRDtnQkFBSSxXQUFVOzBCQUM5RCx3QkFBQyxPQUFEO2lCQUFLLFdBQVU7MkJBQWYsQ0FDSyxjQUFjLEVBQUUsS0FDYix3QkFBQyxRQUFEO2tCQUFNLFdBQVU7NEJBQThKO2lCQUV4Szs7OzsyQkFFVix3QkFBQyxRQUFEO2tCQUFNLFdBQVU7NEJBQ1gscUJBQXFCLEdBQUcsTUFBTTtpQkFDN0I7Ozs7eUJBQ0w7Ozs7OztlQUNMOzs7OztlQUVKLHdCQUFDLE1BQUQ7Z0JBQUksV0FBVTswQkFDVCxHQUFHLGVBQWUsR0FBRyxXQUFXLEdBQUcsV0FBVztlQUMvQzs7Ozs7ZUFDSix3QkFBQyxNQUFEO2dCQUFJLFdBQVU7MEJBQ1QsR0FBRyxhQUFhLEdBQUcsU0FDaEIsd0JBQUMsUUFBRCxZQUFPLEdBQUcsYUFBYSxTQUFTLEdBQUcsU0FBZTs7OzsyQkFFbEQsd0JBQUMsUUFBRDtpQkFBTSxXQUFVOzJCQUF3QjtnQkFBVTs7Ozs7ZUFFdEQ7Ozs7O2VBQ0osd0JBQUMsTUFBRDtnQkFBSSxXQUFVOzBCQUNULEdBQUcsWUFBWSxJQUFJLEtBQUssR0FBRyxTQUFTLENBQUMsQ0FBQyxtQkFBbUIsU0FBUztpQkFBRSxLQUFLO2lCQUFXLE9BQU87aUJBQVMsTUFBTTtnQkFBVSxDQUFDLElBQUk7ZUFDMUg7Ozs7O2VBQ0osd0JBQUMsTUFBRDtnQkFBSSxXQUFVOzBCQUNWLHdCQUFDLE9BQUQ7aUJBQUssV0FBVTsyQkFBZixDQUNLLEdBQUcsV0FDQSxHQUFHLGFBQ0Msd0JBQUMsVUFBRDtrQkFDSSxlQUFlLDBCQUEwQixHQUFHLEVBQUU7a0JBQzlDLFVBQVUsb0JBQW9CLFVBQVUsR0FBRztrQkFDM0MsV0FBVTtrQkFDVixPQUFNOzRCQUVOLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O2lCQUNsQjs7Ozs0QkFFUix3QkFBQyxVQUFEO2tCQUNJLGVBQWUsMkJBQTJCLEdBQUcsRUFBRTtrQkFDL0MsVUFBVSxvQkFBb0IsU0FBUyxHQUFHO2tCQUMxQyxXQUFVO2tCQUNWLE9BQU07NEJBRU4sd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7Ozs7aUJBQ3RCOzs7OzRCQUloQix3QkFBQyxVQUFEO2tCQUNJLGVBQWUscUJBQXFCLEdBQUcsRUFBRTtrQkFDekMsVUFBVSxvQkFBb0IsVUFBVSxHQUFHO2tCQUMzQyxXQUFVO2tCQUNWLE9BQU07NEJBRU4sd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7aUJBQ2Y7Ozs7eUJBQ1A7Ozs7OztlQUNMOzs7OztjQUNKO2dCQWpFSyxHQUFHOzs7O29CQWlFUixDQUNQO1lBRUY7Ozs7b0JBQ0o7Ozs7O21CQUNOOzs7OztrQkFDQTs7Ozs7O1FBR1I7Ozs7OztNQUVKOzs7Ozs7SUFDSjs7Ozs7O0dBR0osc0JBQ0csd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNJLHdCQUFDLFVBQUQ7UUFBVSxNQUFNO1FBQUksV0FBVTtPQUFrQjs7OztpQkFBQyxzQkFFakQ7Ozs7O2dCQUNKLHdCQUFDLFVBQUQ7T0FBUSxlQUFlLHNCQUFzQixJQUFJO09BQUcsV0FBVTtpQkFDMUQsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7TUFDVjs7OztjQUNQOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNWLG1CQUFtQixVQUNoQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBbUIsd0JBQUMsU0FBRCxFQUFTLFdBQVUsOENBQStDOzs7OztNQUFNOzs7O2lCQUUxRyxnREFDSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNWLG1CQUFtQixVQUFVLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZLEtBQUs7T0FDMUQ7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUNJLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzRCxtQkFBbUI7UUFBYTs7Ozs7UUFDcEcsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWIsQ0FBZ0QsS0FBRSxtQkFBbUIsUUFBWTs7Ozs7O1FBQ2pGLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ1gsbUJBQW1CLFFBQVE7U0FDMUI7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVcsa0RBQWtELG1CQUFtQixhQUFhLFFBQVEsbUNBQW1DO29CQUN6SSxtQkFBbUIsYUFBYSxRQUFRLFVBQVU7U0FDakQ7Ozs7aUJBQ0w7Ozs7OztPQUNKOzs7O2VBQ0o7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBeUM7U0FBUTs7OzttQkFDOUQsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXlELG1CQUFtQixTQUFTO1NBQU87Ozs7aUJBQ3hHOzs7Ozs7UUFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF5QztTQUFnQjs7OzttQkFDdEUsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWdELG1CQUFtQixhQUFhO1NBQU87Ozs7aUJBQ25HOzs7Ozs7UUFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF5QztTQUFpQjs7OzttQkFDdkUsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWdELG1CQUFtQixhQUFhO1NBQUs7Ozs7aUJBQ2pHOzs7Ozs7UUFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF5QztTQUFnQjs7OzttQkFDdEUsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWdELG1CQUFtQixpQkFBaUI7U0FBSzs7OztpQkFDckc7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXlDO1NBQW9COzs7O21CQUMxRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDUixtQkFBbUIsWUFBWSxJQUFJLEtBQUssbUJBQW1CLFNBQVMsQ0FBQyxDQUFDLGVBQWUsT0FBTyxJQUFJO1NBQ2xHOzs7O2lCQUNGOzs7Ozs7T0FDSjs7Ozs7Y0FDUDs7Ozs7S0FFTDs7OzthQUNKOzs7Ozs7R0FDSjs7Ozs7R0FJUixzQkFDRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNYLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQ0ksd0JBQUMsVUFBRDtRQUFVLE1BQU07UUFBSSxXQUFVO09BQWtCOzs7O2lCQUFDLGlCQUVqRDs7Ozs7Z0JBQ0osd0JBQUMsVUFBRDtPQUFRLGVBQWUsc0JBQXNCLElBQUk7T0FBRyxXQUFVO2lCQUMxRCx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztNQUNWOzs7O2NBQ1A7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1YsbUJBQW1CLFVBQ2hCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFtQix3QkFBQyxTQUFELEVBQVMsV0FBVSw4Q0FBK0M7Ozs7O01BQU07Ozs7aUJBRTFHO09BQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFvRCxtQkFBbUIsU0FBUztPQUEyQjs7OztpQkFDekgsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWIsQ0FBdUQsT0FBSSxtQkFBbUIsUUFBWTs7Ozs7ZUFDekY7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNJLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUF5QztVQUFlOzs7OztVQUNyRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBZ0QsbUJBQW1CLE9BQU8sWUFBWTtVQUFPOzs7OztVQUMxRyx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBOEIsbUJBQW1CLE9BQU8sU0FBUztVQUFNOzs7OztTQUNuRjs7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDSSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBeUM7VUFBbUI7Ozs7O1VBQ3pFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUEwRCxtQkFBbUI7VUFBVTs7Ozs7VUFDcEcsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWIsQ0FBcUQsbUJBQW1CLGlCQUFpQixHQUFFLFVBQVc7Ozs7OztTQUNyRzs7Ozs7Z0JBQ0o7Ozs7OztPQUVKLG1CQUFtQixZQUNoQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFnRTtRQUFzQjs7OztrQkFDbkcsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1YsS0FBSyxVQUFVLG1CQUFtQixVQUFVLE1BQU0sQ0FBQztRQUNuRDs7OztnQkFDSjs7Ozs7O09BR1Qsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxLQUFELGFBQUcsaUJBQWMsbUJBQW1CLFlBQVksSUFBSSxLQUFLLG1CQUFtQixTQUFTLENBQUMsQ0FBQyxlQUFlLE9BQU8sSUFBSSxHQUFPOzs7O2tCQUN2SCxtQkFBbUIsZUFDaEIsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWIsQ0FBc0Msc0JBQW1CLElBQUksS0FBSyxtQkFBbUIsV0FBVyxDQUFDLENBQUMsZUFBZSxPQUFPLENBQUs7Ozs7O2dCQUVoSTs7Ozs7O01BQ1A7Ozs7O0tBRUw7Ozs7YUFDSjs7Ozs7O0dBQ0o7Ozs7O0VBRVI7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFkbWluRGFzaGJvYXJkUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBcbiAgICBVc2VycywgRmlsZVRleHQsIFRyYXNoMiwgU2VhcmNoLCBTaGllbGQsIEFycm93TGVmdCwgTG9hZGVyMixcbiAgICBCYW4sIENoZWNrQ2lyY2xlMiwgRXllLCBBbGVydFRyaWFuZ2xlLCBSZWZyZXNoQ3csIE1lc3NhZ2VTcXVhcmUsXG4gICAgWCwgRXh0ZXJuYWxMaW5rLCBDYWxlbmRhciwgTWFpbCwgVXNlciBhcyBVc2VySWNvbiwgTG9jaywgQ2hlY2tDaXJjbGVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBTaWRlYmFyIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvbGF5b3V0L1NpZGViYXInO1xuaW1wb3J0IHtcbiAgICBhZG1pbkdldFVzZXJzLCBhZG1pbkdldFVzZXJEZXRhaWwsIGFkbWluR2V0Rm9ybXMsIGFkbWluR2V0Rm9ybURldGFpbCxcbiAgICBhZG1pbkdldEZlZWRiYWNrLCBhZG1pbkJhblVzZXIsIGFkbWluQWN0aXZhdGVVc2VyLCBhZG1pbkRlbGV0ZVVzZXIsXG4gICAgYWRtaW5UYWtlZG93bkZvcm0sIGFkbWluUmVzdG9yZUZvcm0sIGFkbWluRGVsZXRlRm9ybSwgYWRtaW5EZWxldGVGZWVkYmFjayxcbiAgICBhZG1pblRha2Vkb3duRm9ybUZyb21GZWVkYmFjaywgYWRtaW5SZXN0b3JlRm9ybUZyb21GZWVkYmFjayxcbiAgICBjbGVhclNlc3Npb24sIGdldExvY2FsVXNlciwgYXNzZXRVcmxcbn0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgdXNlRGVib3VuY2UgZnJvbSAnLi4vLi4vaG9va3MvdXNlRGVib3VuY2UnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBZG1pbkRhc2hib2FyZFBhZ2UoKSB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IFt1c2VyXSA9IHVzZVN0YXRlKCgpID0+IGdldExvY2FsVXNlcigpKTtcbiAgICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcbiAgICBjb25zdCBbZm9ybXMsIHNldEZvcm1zXSA9IHVzZVN0YXRlKFtdKTtcbiAgICBjb25zdCBbZmVlZGJhY2tzLCBzZXRGZWVkYmFja3NdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICAgIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZSgndXNlcnMnKTtcbiAgICAvLyBBMzogU3ViLXRhYiB3aXRoaW4gZmVlZGJhY2sgdGFiOiAnYWxsJyB8ICdyZXBvcnQnIHwgJ21hc3VrYW4nXG4gICAgY29uc3QgW2ZlZWRiYWNrU3ViVGFiLCBzZXRGZWVkYmFja1N1YlRhYl0gPSB1c2VTdGF0ZSgnYWxsJyk7XG4gICAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgZGVib3VuY2VkU2VhcmNoID0gdXNlRGVib3VuY2Uoc2VhcmNoUXVlcnksIDMwMCk7XG4gICAgY29uc3QgW3RvYXN0LCBzZXRUb2FzdF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbYWN0aW9uTG9hZGluZ0lkLCBzZXRBY3Rpb25Mb2FkaW5nSWRdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2ZlZWRiYWNrVHlwZUZpbHRlciwgc2V0RmVlZGJhY2tUeXBlRmlsdGVyXSA9IHVzZVN0YXRlKCdhbGwnKTsgXG5cbiAgICAvLyBNb2RhbHNcbiAgICBjb25zdCBbc2VsZWN0ZWRVc2VyRGV0YWlsLCBzZXRTZWxlY3RlZFVzZXJEZXRhaWxdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2xvYWRpbmdVc2VyRGV0YWlsLCBzZXRMb2FkaW5nVXNlckRldGFpbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3NlbGVjdGVkRm9ybURldGFpbCwgc2V0U2VsZWN0ZWRGb3JtRGV0YWlsXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtsb2FkaW5nRm9ybURldGFpbCwgc2V0TG9hZGluZ0Zvcm1EZXRhaWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKHNlbGVjdGVkVXNlckRldGFpbCB8fCBzZWxlY3RlZEZvcm1EZXRhaWwpIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSAnaGlkZGVuJztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSAndW5zZXQnO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSAndW5zZXQnO1xuICAgICAgICB9O1xuICAgIH0sIFtzZWxlY3RlZFVzZXJEZXRhaWwsIHNlbGVjdGVkRm9ybURldGFpbF0pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgdXNlclJvbGUgPSAodXNlcj8ucm9sZSB8fCAnJykudG9VcHBlckNhc2UoKTtcbiAgICAgICAgaWYgKHVzZXJSb2xlICE9PSAnQURNSU4nICYmIHVzZXJSb2xlICE9PSAnU1VQRVJfQURNSU4nKSB7XG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL2Rhc2hib2FyZCcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbG9hZCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IFt1c2Vyc1JlcywgZm9ybXNSZXMsIGZlZWRiYWNrUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgICAgICAgYWRtaW5HZXRVc2VycygpLFxuICAgICAgICAgICAgICAgICAgICBhZG1pbkdldEZvcm1zKCksXG4gICAgICAgICAgICAgICAgICAgIGFkbWluR2V0RmVlZGJhY2soKVxuICAgICAgICAgICAgICAgIF0pO1xuXG4gICAgICAgICAgICAgICAgaWYgKHVzZXJzUmVzLnN0YXR1cyA9PT0gNDAxIHx8IGZvcm1zUmVzLnN0YXR1cyA9PT0gNDAxIHx8IGZlZWRiYWNrUmVzLnN0YXR1cyA9PT0gNDAxKSB7XG4gICAgICAgICAgICAgICAgICAgIGNsZWFyU2Vzc2lvbigpO1xuICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZSgnL2xvZ2luJyk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAodXNlcnNSZXMub2sgJiYgdXNlcnNSZXMuZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB1RGF0YSA9IEFycmF5LmlzQXJyYXkodXNlcnNSZXMuZGF0YSkgPyB1c2Vyc1Jlcy5kYXRhIDogKHVzZXJzUmVzLmRhdGE/Lml0ZW1zIHx8IFtdKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0VXNlcnModURhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoZm9ybXNSZXMub2sgJiYgZm9ybXNSZXMuZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmRGF0YSA9IEFycmF5LmlzQXJyYXkoZm9ybXNSZXMuZGF0YSkgPyBmb3Jtc1Jlcy5kYXRhIDogKGZvcm1zUmVzLmRhdGE/Lml0ZW1zIHx8IFtdKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybXMoZkRhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoZmVlZGJhY2tSZXMub2sgJiYgZmVlZGJhY2tSZXMuZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmYkRhdGEgPSBBcnJheS5pc0FycmF5KGZlZWRiYWNrUmVzLmRhdGEpID8gZmVlZGJhY2tSZXMuZGF0YSA6IChmZWVkYmFja1Jlcy5kYXRhPy5pdGVtcyB8fCBbXSk7XG4gICAgICAgICAgICAgICAgICAgIHNldEZlZWRiYWNrcyhmYkRhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxvYWRpbmcgYWRtaW4gZGF0YTonLCBlcnIpO1xuICAgICAgICAgICAgICAgIHNob3dUb2FzdCgnR2FnYWwgbWVtdWF0IGJlYmVyYXBhIGRhdGEgYWRtaW4nLCAnZXJyb3InKTtcbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGxvYWQoKTtcbiAgICB9LCBbbmF2aWdhdGUsIHVzZXJdKTtcblxuICAgICAgICBjb25zdCBzaG93VG9hc3QgPSAobXNnLCB0eXBlID0gJ3N1Y2Nlc3MnKSA9PiB7XG4gICAgICAgIHNldFRvYXN0KHsgbXNnLCB0eXBlIH0pO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFRvYXN0KG51bGwpLCAzMDAwKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaXNBZG1pblJlcG9ydCA9IChmYikgPT4gKGZiLnJlYXNvbiB8fCAnJykuc3RhcnRzV2l0aCgnQURNSU5fJyk7XG5cbiAgICBjb25zdCBmb3JtYXRGZWVkYmFja1JlYXNvbiA9IChyYXdSZWFzb24pID0+IHtcbiAgICAgICAgaWYgKCFyYXdSZWFzb24pIHJldHVybiAnTGFwb3Jhbic7XG4gICAgICAgIGNvbnN0IHN0cmlwcGVkID0gcmF3UmVhc29uLnN0YXJ0c1dpdGgoJ0FETUlOXycpID8gcmF3UmVhc29uLnNsaWNlKDYpIDogcmF3UmVhc29uO1xuICAgICAgICByZXR1cm4gc3RyaXBwZWRcbiAgICAgICAgICAgIC5zcGxpdCgnXycpXG4gICAgICAgICAgICAubWFwKHcgPT4gdy5jaGFyQXQoMCkgKyB3LnNsaWNlKDEpLnRvTG93ZXJDYXNlKCkpXG4gICAgICAgICAgICAuam9pbignICcpO1xuICAgIH07XG5cbiAgICAvLyDilIDilIAgVXNlciBIYW5kbGVycyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBjb25zdCBoYW5kbGVWaWV3VXNlciA9IGFzeW5jICh1c2VySWQpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZ1VzZXJEZXRhaWwodHJ1ZSk7XG4gICAgICAgIHNldFNlbGVjdGVkVXNlckRldGFpbCh7IGlkOiB1c2VySWQsIGxvYWRpbmc6IHRydWUgfSk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkbWluR2V0VXNlckRldGFpbCh1c2VySWQpO1xuICAgICAgICBzZXRMb2FkaW5nVXNlckRldGFpbChmYWxzZSk7XG4gICAgICAgIGlmIChyZXMub2sgJiYgcmVzLmRhdGEpIHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkVXNlckRldGFpbChyZXMuZGF0YSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbXVhdCBkZXRhaWwgcGVuZ2d1bmEnLCAnZXJyb3InKTtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkVXNlckRldGFpbChudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVCYW5Vc2VyID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xuICAgICAgICBpZiAoIXdpbmRvdy5jb25maXJtKCdCbG9raXIgKEJhbikgcGVuZ2d1bmEgaW5pPyBQZW5nZ3VuYSB0aWRhayBha2FuIGRhcGF0IGxvZ2luLicpKSByZXR1cm47XG4gICAgICAgIHNldEFjdGlvbkxvYWRpbmdJZChgdXNlcl9iYW5fJHt1c2VySWR9YCk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkbWluQmFuVXNlcih1c2VySWQpO1xuICAgICAgICBzZXRBY3Rpb25Mb2FkaW5nSWQobnVsbCk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIHNldFVzZXJzKHByZXYgPT4gcHJldi5tYXAodSA9PiB1LmlkID09PSB1c2VySWQgPyB7IC4uLnUsIGlzQWN0aXZlOiBmYWxzZSB9IDogdSkpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KCdQZW5nZ3VuYSBiZXJoYXNpbCBkaWJsb2tpciAoQmFubmVkKScpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW1ibG9raXIgcGVuZ2d1bmEnLCAnZXJyb3InKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVBY3RpdmF0ZVVzZXIgPSBhc3luYyAodXNlcklkKSA9PiB7XG4gICAgICAgIHNldEFjdGlvbkxvYWRpbmdJZChgdXNlcl9hY3RfJHt1c2VySWR9YCk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkbWluQWN0aXZhdGVVc2VyKHVzZXJJZCk7XG4gICAgICAgIHNldEFjdGlvbkxvYWRpbmdJZChudWxsKTtcbiAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgc2V0VXNlcnMocHJldiA9PiBwcmV2Lm1hcCh1ID0+IHUuaWQgPT09IHVzZXJJZCA/IHsgLi4udSwgaXNBY3RpdmU6IHRydWUgfSA6IHUpKTtcbiAgICAgICAgICAgIHNob3dUb2FzdCgnUGVuZ2d1bmEgYmVyaGFzaWwgZGlha3RpZmthbiBrZW1iYWxpJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbmdha3RpZmthbiBwZW5nZ3VuYScsICdlcnJvcicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIGNvbnN0IGhhbmRsZURlbGV0ZVVzZXIgPSBhc3luYyAodXNlcklkKSA9PiB7XG4gICAgLy8gICAgIGlmICghd2luZG93LmNvbmZpcm0oJ0hhcHVzIHBlbmdndW5hIGluaT8gU2VtdWEgZm9ybXVsaXIgbWlsaWsgcGVuZ2d1bmEgaW5pIGp1Z2EgYWthbiBkaWhhcHVzLicpKSByZXR1cm47XG4gICAgLy8gICAgIHNldEFjdGlvbkxvYWRpbmdJZChgdXNlcl9kZWxfJHt1c2VySWR9YCk7XG4gICAgLy8gICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkbWluRGVsZXRlVXNlcih1c2VySWQpO1xuICAgIC8vICAgICBzZXRBY3Rpb25Mb2FkaW5nSWQobnVsbCk7XG4gICAgLy8gICAgIGlmIChyZXMub2spIHtcbiAgICAvLyAgICAgICAgIHNldFVzZXJzKHByZXYgPT4gcHJldi5maWx0ZXIodSA9PiB1LmlkICE9PSB1c2VySWQpKTtcbiAgICAvLyAgICAgICAgIHNob3dUb2FzdCgnUGVuZ2d1bmEgYmVyaGFzaWwgZGloYXB1cycpO1xuICAgIC8vICAgICB9IGVsc2Uge1xuICAgIC8vICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW5naGFwdXMgcGVuZ2d1bmEnLCAnZXJyb3InKTtcbiAgICAvLyAgICAgfVxuICAgIC8vIH07XG5cbiAgICAvLyDilIDilIAgRm9ybSBIYW5kbGVycyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBjb25zdCBoYW5kbGVWaWV3Rm9ybSA9IGFzeW5jIChmb3JtSWQpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZ0Zvcm1EZXRhaWwodHJ1ZSk7XG4gICAgICAgIHNldFNlbGVjdGVkRm9ybURldGFpbCh7IGlkOiBmb3JtSWQsIGxvYWRpbmc6IHRydWUgfSk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkbWluR2V0Rm9ybURldGFpbChmb3JtSWQpO1xuICAgICAgICBzZXRMb2FkaW5nRm9ybURldGFpbChmYWxzZSk7XG4gICAgICAgIGlmIChyZXMub2sgJiYgcmVzLmRhdGEpIHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkRm9ybURldGFpbChyZXMuZGF0YSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbXVhdCBkZXRhaWwgZm9ybXVsaXInLCAnZXJyb3InKTtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkRm9ybURldGFpbChudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVUYWtlZG93bkZvcm0gPSBhc3luYyAoZm9ybUlkKSA9PiB7XG4gICAgICAgIGlmICghd2luZG93LmNvbmZpcm0oJ1Rha2UgZG93biBmb3JtdWxpciBpbmk/IEZvcm11bGlyIHRpZGFrIGFrYW4gYmlzYSBkaWFrc2VzIHB1Ymxpay4nKSkgcmV0dXJuO1xuICAgICAgICBzZXRBY3Rpb25Mb2FkaW5nSWQoYGZvcm1fdGRfJHtmb3JtSWR9YCk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkbWluVGFrZWRvd25Gb3JtKGZvcm1JZCk7XG4gICAgICAgIHNldEFjdGlvbkxvYWRpbmdJZChudWxsKTtcbiAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgc2V0Rm9ybXMocHJldiA9PiBwcmV2Lm1hcChmID0+IGYuaWQgPT09IGZvcm1JZCA/IHsgLi4uZiwgdGFrZW5Eb3duQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9IDogZikpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KCdGb3JtdWxpciBiZXJoYXNpbCBkaS10YWtlZG93bicpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCB0YWtlIGRvd24gZm9ybXVsaXInLCAnZXJyb3InKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVSZXN0b3JlRm9ybSA9IGFzeW5jIChmb3JtSWQpID0+IHtcbiAgICAgICAgc2V0QWN0aW9uTG9hZGluZ0lkKGBmb3JtX3JzdF8ke2Zvcm1JZH1gKTtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYWRtaW5SZXN0b3JlRm9ybShmb3JtSWQpO1xuICAgICAgICBzZXRBY3Rpb25Mb2FkaW5nSWQobnVsbCk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIHNldEZvcm1zKHByZXYgPT4gcHJldi5tYXAoZiA9PiBmLmlkID09PSBmb3JtSWQgPyB7IC4uLmYsIHRha2VuRG93bkF0OiBudWxsIH0gOiBmKSk7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ0Zvcm11bGlyIGJlcmhhc2lsIGRpcHVsaWhrYW4gKFJlc3RvcmUpJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbXVsaWhrYW4gZm9ybXVsaXInLCAnZXJyb3InKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVEZWxldGVGb3JtID0gYXN5bmMgKGZvcm1JZCkgPT4ge1xuICAgICAgICBpZiAoIXdpbmRvdy5jb25maXJtKCdIYXB1cyBmb3JtdWxpciBpbmk/IFRpbmRha2FuIGluaSB0aWRhayBkYXBhdCBkaWJhdGFsa2FuLicpKSByZXR1cm47XG4gICAgICAgIHNldEFjdGlvbkxvYWRpbmdJZChgZm9ybV9kZWxfJHtmb3JtSWR9YCk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkbWluRGVsZXRlRm9ybShmb3JtSWQpO1xuICAgICAgICBzZXRBY3Rpb25Mb2FkaW5nSWQobnVsbCk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIHNldEZvcm1zKHByZXYgPT4gcHJldi5maWx0ZXIoZiA9PiBmLmlkICE9PSBmb3JtSWQpKTtcbiAgICAgICAgICAgIHNob3dUb2FzdCgnRm9ybXVsaXIgYmVyaGFzaWwgZGloYXB1cycpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW5naGFwdXMgZm9ybXVsaXInLCAnZXJyb3InKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyDilIDilIAgRmVlZGJhY2sgSGFuZGxlcnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgY29uc3QgaGFuZGxlRGVsZXRlRmVlZGJhY2sgPSBhc3luYyAoZmJJZCkgPT4ge1xuICAgICAgICBpZiAoIXdpbmRvdy5jb25maXJtKCdIYXB1cyBsYXBvcmFuIHVtcGFuIGJhbGlrIGluaT8nKSkgcmV0dXJuO1xuICAgICAgICBzZXRBY3Rpb25Mb2FkaW5nSWQoYGZiX2RlbF8ke2ZiSWR9YCk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkbWluRGVsZXRlRmVlZGJhY2soZmJJZCk7XG4gICAgICAgIHNldEFjdGlvbkxvYWRpbmdJZChudWxsKTtcbiAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgc2V0RmVlZGJhY2tzKHByZXYgPT4gcHJldi5maWx0ZXIoZmIgPT4gZmIuaWQgIT09IGZiSWQpKTtcbiAgICAgICAgICAgIHNob3dUb2FzdCgnVW1wYW4gYmFsaWsgYmVyaGFzaWwgZGloYXB1cycpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW5naGFwdXMgdW1wYW4gYmFsaWsnLCAnZXJyb3InKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVUYWtlZG93bkZyb21GZWVkYmFjayA9IGFzeW5jIChmYklkKSA9PiB7XG4gICAgICAgIGlmICghd2luZG93LmNvbmZpcm0oJ1Rha2UgZG93biBmb3JtdWxpciB0ZXJrYWl0IGRhcmkgbGFwb3JhbiBpbmk/JykpIHJldHVybjtcbiAgICAgICAgc2V0QWN0aW9uTG9hZGluZ0lkKGBmYl90ZF8ke2ZiSWR9YCk7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkbWluVGFrZWRvd25Gb3JtRnJvbUZlZWRiYWNrKGZiSWQpO1xuICAgICAgICBzZXRBY3Rpb25Mb2FkaW5nSWQobnVsbCk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIHNldEZlZWRiYWNrcyhwcmV2ID0+IHByZXYubWFwKGZiID0+IGZiLmlkID09PSBmYklkID8geyAuLi5mYiwgaXNUYWtlZG93bjogdHJ1ZSB9IDogZmIpKTtcbiAgICAgICAgICAgIHNob3dUb2FzdCgnRm9ybXVsaXIgdGVya2FpdCBiZXJoYXNpbCBkaS10YWtlZG93bicpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCB0YWtlIGRvd24gZm9ybXVsaXInLCAnZXJyb3InKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVSZXN0b3JlRnJvbUZlZWRiYWNrID0gYXN5bmMgKGZiSWQpID0+IHtcbiAgICAgICAgc2V0QWN0aW9uTG9hZGluZ0lkKGBmYl9yc3RfJHtmYklkfWApO1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhZG1pblJlc3RvcmVGb3JtRnJvbUZlZWRiYWNrKGZiSWQpO1xuICAgICAgICBzZXRBY3Rpb25Mb2FkaW5nSWQobnVsbCk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIHNldEZlZWRiYWNrcyhwcmV2ID0+IHByZXYubWFwKGZiID0+IGZiLmlkID09PSBmYklkID8geyAuLi5mYiwgaXNUYWtlZG93bjogZmFsc2UgfSA6IGZiKSk7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ0Zvcm11bGlyIHRlcmthaXQgYmVyaGFzaWwgZGlwdWxpaGthbicpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW11bGloa2FuIGZvcm11bGlyJywgJ2Vycm9yJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8g4pSA4pSAIEZpbHRlcmVkIERhdGEg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZXJzLmZpbHRlcih1ID0+IHtcbiAgICAgICAgaWYgKCFkZWJvdW5jZWRTZWFyY2gudHJpbSgpKSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgY29uc3QgcSA9IGRlYm91bmNlZFNlYXJjaC50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgKHUuZnVsbG5hbWUgJiYgdS5mdWxsbmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKSB8fFxuICAgICAgICAgICAgKHUudXNlcm5hbWUgJiYgdS51c2VybmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKSB8fFxuICAgICAgICAgICAgKHUuZW1haWwgJiYgdS5lbWFpbC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKSB8fFxuICAgICAgICAgICAgKHUucm9sZSAmJiB1LnJvbGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSlcbiAgICAgICAgKTtcbiAgICB9KTtcblxuICAgIGNvbnN0IGZpbHRlcmVkRm9ybXMgPSBmb3Jtcy5maWx0ZXIoZiA9PiB7XG4gICAgICAgIGlmICghZGVib3VuY2VkU2VhcmNoLnRyaW0oKSkgcmV0dXJuIHRydWU7XG4gICAgICAgIGNvbnN0IHEgPSBkZWJvdW5jZWRTZWFyY2gudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgY29uc3Qgb3duZXIgPSBmLm93bmVyTmFtZSB8fCBmLm93bmVyPy5mdWxsbmFtZSB8fCBmLm93bmVyRW1haWwgfHwgJyc7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAoZi50aXRsZSAmJiBmLnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpIHx8XG4gICAgICAgICAgICAoZi5mb3JtTGluayAmJiBmLmZvcm1MaW5rLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpIHx8XG4gICAgICAgICAgICBvd25lci50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpXG4gICAgICAgICk7XG4gICAgfSk7XG5cbiAgICAgICAgY29uc3QgZmlsdGVyZWRGZWVkYmFja3MgPSBmZWVkYmFja3MuZmlsdGVyKGZiID0+IHtcbiAgICAgICAgaWYgKGZlZWRiYWNrVHlwZUZpbHRlciA9PT0gJ3JlcG9ydHMnICYmICFpc0FkbWluUmVwb3J0KGZiKSkgcmV0dXJuIGZhbHNlO1xuICAgICAgICBpZiAoZmVlZGJhY2tUeXBlRmlsdGVyID09PSAnb3duZXInICYmIGlzQWRtaW5SZXBvcnQoZmIpKSByZXR1cm4gZmFsc2U7XG5cbiAgICAgICAgaWYgKCFkZWJvdW5jZWRTZWFyY2gudHJpbSgpKSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgY29uc3QgcSA9IGRlYm91bmNlZFNlYXJjaC50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgKGZiLmRlc2NyaXB0aW9uICYmIGZiLmRlc2NyaXB0aW9uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpIHx8XG4gICAgICAgICAgICAoZmIucmVhc29uICYmIGZiLnJlYXNvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKSB8fFxuICAgICAgICAgICAgKGZiLmZvcm1UaXRsZSAmJiBmYi5mb3JtVGl0bGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSkgfHxcbiAgICAgICAgICAgIChmYi51c2VyTmFtZSAmJiBmYi51c2VyTmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKSB8fFxuICAgICAgICAgICAgKGZiLnVzZXJFbWFpbCAmJiBmYi51c2VyRW1haWwudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSlcbiAgICAgICAgKTtcbiAgICB9KTtcblxuICAgIC8vIEEzOiBTdWItdGFiIGZpbHRlcmluZyBmb3IgUmVwb3J0IHZzIE1hc3VrYW5cbiAgICBjb25zdCBSRVBPUlRfUkVBU09OUyA9IFsnS09OVEVOJywgJ1NQQU0nLCAnTEFQT1JBTicsICdUSURBS19QQU5UQVMnLCAnUEVMRUNFSEFOJywgJ0lMTEVHQUwnXTtcbiAgICBjb25zdCBzdWJUYWJGZWVkYmFja3MgPSBmZWVkYmFja1N1YlRhYiA9PT0gJ2FsbCdcbiAgICAgICAgPyBmaWx0ZXJlZEZlZWRiYWNrc1xuICAgICAgICA6IGZlZWRiYWNrU3ViVGFiID09PSAncmVwb3J0J1xuICAgICAgICA/IGZpbHRlcmVkRmVlZGJhY2tzLmZpbHRlcihmYiA9PiBSRVBPUlRfUkVBU09OUy5zb21lKHIgPT4gKGZiLnJlYXNvbiB8fCAnJykudG9VcHBlckNhc2UoKS5pbmNsdWRlcyhyKSkpXG4gICAgICAgIDogZmlsdGVyZWRGZWVkYmFja3MuZmlsdGVyKGZiID0+ICFSRVBPUlRfUkVBU09OUy5zb21lKHIgPT4gKGZiLnJlYXNvbiB8fCAnJykudG9VcHBlckNhc2UoKS5pbmNsdWRlcyhyKSkpO1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWluLWgtc2NyZWVuIGJnLVsjRjRGOEY3XSBkYXJrOmJnLXNsYXRlLTk1MFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTggaC04IGFuaW1hdGUtc3BpbiBteC1hdXRvIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+TWVtdWF0IHBhbmVsIGtvbnRyb2wgYWRtaW4uLi48L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gdy1mdWxsIGJnLVsjRjRGOEY3XSBkYXJrOmJnLXNsYXRlLTk1MCBmb250LXNhbnMgYW50aWFsaWFzZWQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgPFNpZGViYXIgLz5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBtaW4tdy0wIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcHgtNiBweS00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvZGFzaGJvYXJkJyl9IGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFycm93TGVmdCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkIHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBLb250cm9sICYgTWFuYWplbWVuIEFkbWluXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5LZWxvbGEgYWt1biBwZW5nZ3VuYSwgZm9ybXVsaXIgZ2xvYmFsLCBkYW4gbGFwb3JhbiBtb2RlcmFzaS48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7dG9hc3QgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZpeGVkIHRvcC00IHJpZ2h0LTQgei01MCBweC00IHB5LTMgcm91bmRlZC0yeGwgc2hhZG93LXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgJHt0b2FzdC50eXBlID09PSAnZXJyb3InID8gJ2JnLXJlZC01MDAnIDogJ2JnLVsjMDA4OTdCXSd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dG9hc3QubXNnfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgbWF4LXctNnhsIG14LWF1dG8gdy1mdWxsIHNwYWNlLXktNlwiPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0IENhcmRzIC0gQmVyamVqZXIgMSBiYXJpcyBkaSBzZW11YSB1a3VyYW4gbGF5YXIgKi99XG48ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTIgc206Z2FwLTQgbWItNlwiPlxuICAgIHsvKiBDYXJkIDE6IFBlbmdndW5hIFRlcmRhZnRhciAqL31cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTMgc206cC01IHNoYWRvdy14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzbTpnYXAtNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBzbTpwLTMgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzUwIHRleHQtWyMwMDg5N0JdIHJvdW5kZWQteGwgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgIDxVc2VycyBzaXplPXsxOH0gY2xhc3NOYW1lPVwic206dy02IHNtOmgtNlwiIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBzbTp0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgIFBlbmdndW5hIFRlcmRhZnRhclxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gc206dGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICB7dXNlcnMubGVuZ3RofVxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG5cbiAgICB7LyogQ2FyZCAyOiBGb3JtdWxpciBBa3RpZiAqL31cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTMgc206cC01IHNoYWRvdy14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzbTpnYXAtNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBzbTpwLTMgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzUwIHRleHQtWyMwMDg5N0JdIHJvdW5kZWQteGwgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgIDxGaWxlVGV4dCBzaXplPXsxOH0gY2xhc3NOYW1lPVwic206dy02IHNtOmgtNlwiIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBzbTp0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgIEZvcm11bGlyIEFrdGlmXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgIHtmb3Jtcy5sZW5ndGh9XG4gICAgICAgICAgICA8L2gzPlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cblxuICAgIHsvKiBDYXJkIDM6IFVtcGFuIEJhbGlrICovfVxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtMyBzbTpwLTUgc2hhZG93LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNtOmdhcC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHNtOnAtMyBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNTAgdGV4dC1bIzAwODk3Ql0gcm91bmRlZC14bCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgc2l6ZT17MTh9IGNsYXNzTmFtZT1cInNtOnctNiBzbTpoLTZcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gc206dGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICBVbXBhbiBCYWxpayBNYXN1a1xuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gc206dGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICB7ZmVlZGJhY2tzLmxlbmd0aH1cbiAgICAgICAgICAgIDwvaDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFRhYiBOYXZpZ2F0aW9uICYgU2VhcmNoICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTMgc206cC00IGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1lbmdndW5ha2FuIGdyaWQgMyBrb2xvbSBwYWRhIG1vYmlsZSBhZ2FyIGtldGlnYSBjYXJkL3RvbWJvbCBzZWphamFyICYgcHJlc2lzaSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBzbTpmbGV4IHNtOmZsZXgtd3JhcCBnYXAtMS41IHNtOmdhcC0yIHctZnVsbCBtZDp3LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYigndXNlcnMnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBzbTpweC00IHB5LTIgcm91bmRlZC14bCB0ZXh0LVsxMXB4XSBzbTp0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHRleHQtY2VudGVyIHdoaXRlc3BhY2Utbm93cmFwIG92ZXJmbG93LWhpZGRlbiB0ZXh0LWVsbGlwc2lzICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICd1c2VycycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctWyMwMDg5N0JdIHRleHQtd2hpdGUgc2hhZG93LXhzJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGVuZ2d1bmEgKHt1c2Vycy5sZW5ndGh9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2Zvcm1zJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIgc206cHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC1bMTFweF0gc206dGV4dC14cyBmb250LWV4dHJhYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciB0ZXh0LWNlbnRlciB3aGl0ZXNwYWNlLW5vd3JhcCBvdmVyZmxvdy1oaWRkZW4gdGV4dC1lbGxpcHNpcyAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnZm9ybXMnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLVsjMDA4OTdCXSB0ZXh0LXdoaXRlIHNoYWRvdy14cycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZvcm11bGlyICh7Zm9ybXMubGVuZ3RofSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdmZWVkYmFjaycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yIHNtOnB4LTQgcHktMiByb3VuZGVkLXhsIHRleHQtWzExcHhdIHNtOnRleHQteHMgZm9udC1leHRyYWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgdGV4dC1jZW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgb3ZlcmZsb3ctaGlkZGVuIHRleHQtZWxsaXBzaXMgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ2ZlZWRiYWNrJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1bIzAwODk3Ql0gdGV4dC13aGl0ZSBzaGFkb3cteHMnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBVbXBhbiBCYWxpayAoe2ZlZWRiYWNrcy5sZW5ndGh9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBJbnB1dCBQZW5jYXJpYW4gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtZDp3LTY0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlYXJjaCBzaXplPXsxNX0gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ2FyaSBkYXRhLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItMyBweS0xLjUgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFRhYmxlIFZpZXdzICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDilIDilIAgVEFCIDE6IFVTRVJTIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICd1c2VycycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIHctZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtc20gdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIHRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+UGVuZ2d1bmE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+RW1haWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+UGVyYW48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+U3RhdHVzIEFrdW48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtY2VudGVyXCI+Rm9ybSAvIFJlc3BvbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1yaWdodFwiPkFrc2k8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkVXNlcnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17Nn0gY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOCB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+VGlkYWsgYWRhIHBlbmdndW5hIGRpdGVtdWthbi48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkVXNlcnMubWFwKHUgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNCYW5uZWQgPSB1LmlzQWN0aXZlID09PSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZiA9IHUuaWQgPT09IHVzZXI/LmlkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNBZG1pblVzZXIgPSAodS5yb2xlIHx8ICcnKS50b1VwcGVyQ2FzZSgpID09PSAnQURNSU4nIHx8ICh1LnJvbGUgfHwgJycpLnRvVXBwZXJDYXNlKCkgPT09ICdTVVBFUl9BRE1JTic7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17dS5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dS5mdWxsbmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzU2VsZiAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBiZy10ZWFsLTEwMCB0ZXh0LXRlYWwtNzAwIGRhcms6YmctdGVhbC05MDAgZGFyazp0ZXh0LXRlYWwtMzAwIHB4LTEuNSBweS0wLjIgcm91bmRlZFwiPkFuZGE8L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgZm9udC1tb25vXCI+QHt1LnVzZXJuYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bSB0ZXh0LXhzXCI+e3UuZW1haWx9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMHB4XSBmb250LWV4dHJhYm9sZCBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWRtaW5Vc2VyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXB1cnBsZS01MCB0ZXh0LXB1cnBsZS02MDAgZGFyazpiZy1wdXJwbGUtOTUwLzYwIGRhcms6dGV4dC1wdXJwbGUtNDAwIGJvcmRlciBib3JkZXItcHVycGxlLTIwMCBkYXJrOmJvcmRlci1wdXJwbGUtODAwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNjAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Uucm9sZSB8fCAnVVNFUid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0Jhbm5lZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcmVkLTUwIHRleHQtcmVkLTYwMCBkYXJrOmJnLXJlZC05NTAvNjAgZGFyazp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIGRhcms6Ym9yZGVyLXJlZC04MDAnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC02MDAgZGFyazpiZy1lbWVyYWxkLTk1MC82MCBkYXJrOnRleHQtZW1lcmFsZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzQmFubmVkID8gPEJhbiBzaXplPXsxMH0gLz4gOiA8Q2hlY2tDaXJjbGUyIHNpemU9ezEwfSAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNCYW5uZWQgPyAnRGlibG9raXIgKEJhbm5lZCknIDogJ0FrdGlmJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtY2VudGVyIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dS5mb3JtQ291bnQgPz8gMH0gZm9ybSAvIHt1LnJlc3BvbnNlQ291bnQgPz8gMH0gcmVzcG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRGV0YWlsICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVmlld1VzZXIodS5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtWyMwMDg5N0JdIGRhcms6aG92ZXI6dGV4dC10ZWFsLTQwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTGloYXQgRGV0YWlsIFBlbmdndW5hXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFeWUgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQmFuIC8gVW5iYW4gKG5vdCBmb3IgYWRtaW4gb3Igc2VsZikgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0FkbWluVXNlciAmJiAhaXNTZWxmICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNCYW5uZWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQWN0aXZhdGVVc2VyKHUuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXthY3Rpb25Mb2FkaW5nSWQgPT09IGB1c2VyX2FjdF8ke3UuaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LWVtZXJhbGQtNTAwIGhvdmVyOnRleHQtZW1lcmFsZC03MDAgaG92ZXI6YmctZW1lcmFsZC01MCBkYXJrOmhvdmVyOmJnLWVtZXJhbGQtOTUwLzQwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQWt0aWZrYW4gS2VtYmFsaSBQZW5nZ3VuYVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQmFuVXNlcih1LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17YWN0aW9uTG9hZGluZ0lkID09PSBgdXNlcl9iYW5fJHt1LmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1hbWJlci01MDAgaG92ZXI6dGV4dC1hbWJlci03MDAgaG92ZXI6YmctYW1iZXItNTAgZGFyazpob3ZlcjpiZy1hbWJlci05NTAvNDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJCbG9raXIgKEJhbikgUGVuZ2d1bmFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCYW4gc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRGVsZXRlIFVzZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIHshaXNBZG1pblVzZXIgJiYgIWlzU2VsZiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZVVzZXIodS5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17YWN0aW9uTG9hZGluZ0lkID09PSBgdXNlcl9kZWxfJHt1LmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXJlZC00MDAgaG92ZXI6dGV4dC1yZWQtNjAwIGhvdmVyOmJnLXJlZC01MCBkYXJrOmhvdmVyOmJnLXJlZC05NTAvNDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkhhcHVzIFBlbmdndW5hXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX0gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDilIDilIAgVEFCIDI6IEZPUk1TIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdmb3JtcycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIHctZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtc20gdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIHRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+SnVkdWwgRm9ybXVsaXI8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+UGVtaWxpazwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5TdGF0dXMgUHVibGlrYXNpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlN0YXR1cyBNb2RlcmFzaTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5SZXNwb25zPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXJpZ2h0XCI+QWtzaTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCBkYXJrOmRpdmlkZS1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRGb3Jtcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs2fSBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04IHRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5UaWRhayBhZGEgZm9ybXVsaXIgZGl0ZW11a2FuLjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRGb3Jtcy5tYXAoZiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1Rha2VuRG93biA9ICEhZi50YWtlbkRvd25BdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzUHVibGlzaGVkID0gKGYuc3RhdHVzIHx8ICcnKS50b1VwcGVyQ2FzZSgpID09PSAnUFVCTElTSEVEJztcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtmLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBsaW5lLWNsYW1wLTFcIj57Zi50aXRsZSB8fCAnRm9ybXVsaXIgVGFucGEgSnVkdWwnfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGZvbnQtbW9ub1wiPi9mL3tmLmZvcm1MaW5rfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zi5vd25lck5hbWUgfHwgZi5vd25lcj8uZnVsbG5hbWUgfHwgZi5vd25lckVtYWlsIHx8ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1B1Ymxpc2hlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctdGVhbC01MCB0ZXh0LXRlYWwtNjAwIGRhcms6YmctdGVhbC05NTAvNjAgZGFyazp0ZXh0LXRlYWwtNDAwIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDAnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS01MDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zi5zdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzVGFrZW5Eb3duID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctcmVkLTUwIHRleHQtcmVkLTYwMCBkYXJrOmJnLXJlZC05NTAvNjAgZGFyazp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIGRhcms6Ym9yZGVyLXJlZC04MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIHNpemU9ezEwfSAvPiBEaS1UYWtlZG93blxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tZWRpdW0gdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm9ybWFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmLnJlc3BvbnNlQ291bnQgPz8gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEZXRhaWwgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVWaWV3Rm9ybShmLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1bIzAwODk3Ql0gZGFyazpob3Zlcjp0ZXh0LXRlYWwtNDAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMaWhhdCBEZXRhaWwgRm9ybXVsaXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV5ZSBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBUYWtlZG93biAvIFJlc3RvcmUgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzVGFrZW5Eb3duID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZXN0b3JlRm9ybShmLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXthY3Rpb25Mb2FkaW5nSWQgPT09IGBmb3JtX3JzdF8ke2YuaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtZW1lcmFsZC01MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBob3ZlcjpiZy1lbWVyYWxkLTUwIGRhcms6aG92ZXI6YmctZW1lcmFsZC05NTAvNDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlB1bGloa2FuIChSZXN0b3JlKSBGb3JtdWxpclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRha2Vkb3duRm9ybShmLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXthY3Rpb25Mb2FkaW5nSWQgPT09IGBmb3JtX3RkXyR7Zi5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1hbWJlci01MDAgaG92ZXI6dGV4dC1hbWJlci03MDAgaG92ZXI6YmctYW1iZXItNTAgZGFyazpob3ZlcjpiZy1hbWJlci05NTAvNDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlRha2UgRG93biBGb3JtdWxpclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIERlbGV0ZSBGb3JtICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlRm9ybShmLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2FjdGlvbkxvYWRpbmdJZCA9PT0gYGZvcm1fZGVsXyR7Zi5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXJlZC00MDAgaG92ZXI6dGV4dC1yZWQtNjAwIGhvdmVyOmJnLXJlZC01MCBkYXJrOmhvdmVyOmJnLXJlZC05NTAvNDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiSGFwdXMgRm9ybXVsaXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pSA4pSAIFRBQiAzOiBGRUVEQkFDSyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnZmVlZGJhY2snICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAnYWxsJywgbGFiZWw6ICdTZW11YScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAncmVwb3J0cycsIGxhYmVsOiAn8J+aqSBMYXBvcmFuIGtlIEFkbWluJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdvd25lcicsIGxhYmVsOiAnTWFzdWthbiBrZSBQZW1pbGlrJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXS5tYXAoZiA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2YuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGZWVkYmFja1R5cGVGaWx0ZXIoZi5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQteGwgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmZWVkYmFja1R5cGVGaWx0ZXIgPT09IGYuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1bIzAwODk3Ql0gdGV4dC13aGl0ZSBzaGFkb3cteHMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIHctZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQTM6IFN1Yi10YWIgbmF2aWdhdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBtYi00IHAtMSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCB3LWZpdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2FsbCcsIGxhYmVsOiAnU2VtdWEnLCBjb3VudDogZmlsdGVyZWRGZWVkYmFja3MubGVuZ3RoIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdyZXBvcnQnLCBsYWJlbDogJ/CfmqggTGFwb3JhbicsIGNvdW50OiBmaWx0ZXJlZEZlZWRiYWNrcy5maWx0ZXIoZmIgPT4gUkVQT1JUX1JFQVNPTlMuc29tZShyID0+IChmYi5yZWFzb24gfHwgJycpLnRvVXBwZXJDYXNlKCkuaW5jbHVkZXMocikpKS5sZW5ndGggfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ21hc3VrYW4nLCBsYWJlbDogJ/CfkqwgTWFzdWthbicsIGNvdW50OiBmaWx0ZXJlZEZlZWRiYWNrcy5maWx0ZXIoZmIgPT4gIVJFUE9SVF9SRUFTT05TLnNvbWUociA9PiAoZmIucmVhc29uIHx8ICcnKS50b1VwcGVyQ2FzZSgpLmluY2x1ZGVzKHIpKSkubGVuZ3RoIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCh0YWIgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt0YWIua2V5fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmVlZGJhY2tTdWJUYWIodGFiLmtleSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrU3ViVGFiID09PSB0YWIua2V5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgZGFyazpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RhYi5sYWJlbH0gPHNwYW4gY2xhc3NOYW1lPVwibWwtMSB0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPih7dGFiLmNvdW50fSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1zbSB0ZXh0LWxlZnRcIj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlBlbmdpcmltPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPkthdGVnb3JpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPklzaSBQZXNhbiAvIExhcG9yYW48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+Rm9ybXVsaXIgVGVya2FpdDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5UYW5nZ2FsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXJpZ2h0XCI+QWtzaTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCBkYXJrOmRpdmlkZS1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3ViVGFiRmVlZGJhY2tzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezZ9IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTggdGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmZWVkYmFja1N1YlRhYiA9PT0gJ3JlcG9ydCcgPyAnVGlkYWsgYWRhIGxhcG9yYW4gbWFzdWsuJyA6IGZlZWRiYWNrU3ViVGFiID09PSAnbWFzdWthbicgPyAnVGlkYWsgYWRhIG1hc3VrYW4gbWFzdWsuJyA6ICdUaWRhayBhZGEgdW1wYW4gYmFsaWsgLyBsYXBvcmFuIG1hc3VrLid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YlRhYkZlZWRiYWNrcy5tYXAoZmIgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17ZmIuaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzQwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0ZXh0LXhzXCI+e2ZiLnVzZXJOYW1lIHx8IGZiLnVzZXI/LmZ1bGxuYW1lIHx8ICdBbm9uaW0nfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPntmYi51c2VyRW1haWwgfHwgZmIudXNlcj8uZW1haWwgfHwgJ+KAlCd9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzQWRtaW5SZXBvcnQoZmIpICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIGZvbnQtZXh0cmFib2xkIHB4LTEuNSBweS0wLjUgcm91bmRlZCB3LWZpdCBiZy1yZWQtNTAgdGV4dC1yZWQtNjAwIGRhcms6YmctcmVkLTk1MC82MCBkYXJrOnRleHQtcmVkLTQwMCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5qpIExBUE9SQU4gQURNSU5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgdy1maXRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RmVlZGJhY2tSZWFzb24oZmIucmVhc29uKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC14cyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1heC13LXhzIGJyZWFrLXdvcmRzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmYi5kZXNjcmlwdGlvbiB8fCBmYi5jb250ZW50IHx8IGZiLm1lc3NhZ2UgfHwgJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmYi5mb3JtVGl0bGUgfHwgZmIuZm9ybUlkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2ZiLmZvcm1UaXRsZSB8fCBgRm9ybSAjJHtmYi5mb3JtSWR9YH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBpdGFsaWNcIj5VbXVtPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZiLmNyZWF0ZWRBdCA/IG5ldyBEYXRlKGZiLmNyZWF0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdpZC1JRCcsIHsgZGF5OiAnbnVtZXJpYycsIG1vbnRoOiAnc2hvcnQnLCB5ZWFyOiAnbnVtZXJpYycgfSkgOiAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZiLmZvcm1JZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmIuaXNUYWtlZG93biA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVzdG9yZUZyb21GZWVkYmFjayhmYi5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17YWN0aW9uTG9hZGluZ0lkID09PSBgZmJfcnN0XyR7ZmIuaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtZW1lcmFsZC01MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBob3ZlcjpiZy1lbWVyYWxkLTUwIGRhcms6aG92ZXI6YmctZW1lcmFsZC05NTAvNDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlB1bGloa2FuIEZvcm11bGlyIGRhcmkgTGFwb3JhblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRha2Vkb3duRnJvbUZlZWRiYWNrKGZiLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXthY3Rpb25Mb2FkaW5nSWQgPT09IGBmYl90ZF8ke2ZiLmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LWFtYmVyLTUwMCBob3Zlcjp0ZXh0LWFtYmVyLTcwMCBob3ZlcjpiZy1hbWJlci01MCBkYXJrOmhvdmVyOmJnLWFtYmVyLTk1MC80MCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVGFrZSBEb3duIEZvcm11bGlyIGRhcmkgTGFwb3JhblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlRmVlZGJhY2soZmIuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXthY3Rpb25Mb2FkaW5nSWQgPT09IGBmYl9kZWxfJHtmYi5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtcmVkLTQwMCBob3Zlcjp0ZXh0LXJlZC02MDAgaG92ZXI6YmctcmVkLTUwIGRhcms6aG92ZXI6YmctcmVkLTk1MC80MCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkhhcHVzIFVtcGFuIEJhbGlrXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7Lyog4pSA4pSAIE1PREFMOiBVU0VSIERFVEFJTCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi99XG4gICAgICAgICAgICB7c2VsZWN0ZWRVc2VyRGV0YWlsICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBiZy1ibGFjay80MCBiYWNrZHJvcC1ibHVyLXhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCB3LWZ1bGwgbWF4LXctbGcgc2hhZG93LTJ4bCBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXJJY29uIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LVsjMDA4OTdCXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERldGFpbCBBa3VuIFBlbmdndW5hXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkVXNlckRldGFpbChudWxsKX0gY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFVzZXJEZXRhaWwubG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS04IHRleHQtY2VudGVyXCI+PExvYWRlcjIgY2xhc3NOYW1lPVwidy02IGgtNiBhbmltYXRlLXNwaW4gbXgtYXV0byB0ZXh0LVsjMDA4OTdCXVwiIC8+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLTJ4bCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXhsIGZvbnQtYmxhY2sgdGV4dC1bIzAwODk3Ql1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkVXNlckRldGFpbC5mdWxsbmFtZT8uc2xpY2UoMCwgMikudG9VcHBlckNhc2UoKSB8fCAnVVMnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1iYXNlIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPntzZWxlY3RlZFVzZXJEZXRhaWwuZnVsbG5hbWV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5Ae3NlbGVjdGVkVXNlckRldGFpbC51c2VybmFtZX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWV4dHJhYm9sZCBweC0yIHB5LTAuNSBiZy1wdXJwbGUtNTAgdGV4dC1wdXJwbGUtNzAwIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRVc2VyRGV0YWlsLnJvbGUgfHwgJ1VTRVInfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCAke3NlbGVjdGVkVXNlckRldGFpbC5pc0FjdGl2ZSAhPT0gZmFsc2UgPyAnYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwJyA6ICdiZy1yZWQtNTAgdGV4dC1yZWQtNzAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRVc2VyRGV0YWlsLmlzQWN0aXZlICE9PSBmYWxzZSA/ICdBa3RpZicgOiAnRGlibG9raXInfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgcHQtMiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bSB0ZXh0LVsxMHB4XVwiPkVNQUlMPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCB0cnVuY2F0ZVwiPntzZWxlY3RlZFVzZXJEZXRhaWwuZW1haWwgfHwgJ+KAlCd9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW0gdGV4dC1bMTBweF1cIj5UQU5HR0FMIExBSElSPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPntzZWxlY3RlZFVzZXJEZXRhaWwuYmlydGhkYXRlIHx8ICfigJQnfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtIHRleHQtWzEwcHhdXCI+VE9UQUwgRk9STVVMSVI8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+e3NlbGVjdGVkVXNlckRldGFpbC5mb3JtQ291bnQgPz8gMH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bSB0ZXh0LVsxMHB4XVwiPlRPVEFMIFJFU1BPTlM8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+e3NlbGVjdGVkVXNlckRldGFpbC5yZXNwb25zZUNvdW50ID8/IDB9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIHJvdW5kZWQteGwgY29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bSB0ZXh0LVsxMHB4XVwiPlRBTkdHQUwgQkVSR0FCVU5HPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkVXNlckRldGFpbC5jcmVhdGVkQXQgPyBuZXcgRGF0ZShzZWxlY3RlZFVzZXJEZXRhaWwuY3JlYXRlZEF0KS50b0xvY2FsZVN0cmluZygnaWQtSUQnKSA6ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiDilIDilIAgTU9EQUw6IEZPUk0gREVUQUlMIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL31cbiAgICAgICAgICAgIHtzZWxlY3RlZEZvcm1EZXRhaWwgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGJnLWJsYWNrLzQwIGJhY2tkcm9wLWJsdXIteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHctZnVsbCBtYXgtdy14bCBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0xNTAgbWF4LWgtWzkwdmhdIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtWyMwMDg5N0JdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGV0YWlsIEZvcm11bGlyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkRm9ybURldGFpbChudWxsKX0gY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNCBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRGb3JtRGV0YWlsLmxvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktOCB0ZXh0LWNlbnRlclwiPjxMb2FkZXIyIGNsYXNzTmFtZT1cInctNiBoLTYgYW5pbWF0ZS1zcGluIG14LWF1dG8gdGV4dC1bIzAwODk3Ql1cIiAvPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj57c2VsZWN0ZWRGb3JtRGV0YWlsLnRpdGxlIHx8ICdGb3JtdWxpciBUYW5wYSBKdWR1bCd9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ubyBtdC0wLjVcIj4vZi97c2VsZWN0ZWRGb3JtRGV0YWlsLmZvcm1MaW5rfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW0gdGV4dC1bMTBweF1cIj5QRU1JTElLIEZPUk08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+e3NlbGVjdGVkRm9ybURldGFpbC5vd25lcj8uZnVsbG5hbWUgfHwgJ+KAlCd9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPntzZWxlY3RlZEZvcm1EZXRhaWwub3duZXI/LmVtYWlsIHx8ICcnfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtIHRleHQtWzEwcHhdXCI+U1RBVFVTICYgUkVTUE9OUzwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgdXBwZXJjYXNlXCI+e3NlbGVjdGVkRm9ybURldGFpbC5zdGF0dXN9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LVsjMDA4OTdCXSBmb250LWJvbGRcIj57c2VsZWN0ZWRGb3JtRGV0YWlsLnJlc3BvbnNlQ291bnQgPz8gMH0gcmVzcG9uczwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRGb3JtRGV0YWlsLnNldHRpbmdzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+UGVuZ2F0dXJhbiBGb3JtdWxpcjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtOTAwIHRleHQtdGVhbC0zMDAgZm9udC1tb25vIHRleHQtWzExcHhdIHJvdW5kZWQteGwgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7SlNPTi5zdHJpbmdpZnkoc2VsZWN0ZWRGb3JtRGV0YWlsLnNldHRpbmdzLCBudWxsLCAyKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wcmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIHNwYWNlLXktMSBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+RGlidWF0IHBhZGE6IHtzZWxlY3RlZEZvcm1EZXRhaWwuY3JlYXRlZEF0ID8gbmV3IERhdGUoc2VsZWN0ZWRGb3JtRGV0YWlsLmNyZWF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoJ2lkLUlEJykgOiAn4oCUJ308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRm9ybURldGFpbC50YWtlbkRvd25BdCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBmb250LWJvbGRcIj5EaS10YWtlZG93biBwYWRhOiB7bmV3IERhdGUoc2VsZWN0ZWRGb3JtRGV0YWlsLnRha2VuRG93bkF0KS50b0xvY2FsZVN0cmluZygnaWQtSUQnKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==