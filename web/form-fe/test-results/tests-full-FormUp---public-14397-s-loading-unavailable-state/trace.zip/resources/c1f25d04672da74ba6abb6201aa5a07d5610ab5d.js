import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/form-builder/CreateForm.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { Loader2, ArrowLeft, AlertCircle } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import { createForm, clearSession } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-builder/CreateForm.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function CreateForm() {
	_s();
	const navigate = useNavigate();
	const location = useLocation();
	const templateData = location.state?.templateData;
	const [error, setError] = useState("");
	const [creating, setCreating] = useState(true);
	useEffect(() => {
		let isMounted = true;
		const initForm = async () => {
			try {
				setCreating(true);
				setError("");
				const payload = {
					title: templateData?.title || "Formulir Tanpa Judul",
					description: templateData?.description || ""
				};
				const res = await createForm(payload);
				if (!isMounted) return;
				if (res.status === 401) {
					clearSession();
					navigate("/login");
					return;
				}
				if (res.ok && res.data?.id) {
					navigate(`/forms/${res.data.id}/edit`, { replace: true });
				} else {
					setError(res.message || "Gagal membuat formulir baru.");
					setCreating(false);
				}
			} catch (err) {
				if (!isMounted) return;
				console.error("Create form error:", err);
				setError("Terjadi kesalahan saat membuat formulir.");
				setCreating(false);
			}
		};
		initForm();
		return () => {
			isMounted = false;
		};
	}, [navigate, templateData]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-[#F4F8F7] dark:bg-slate-950 flex items-center justify-center p-4 font-sans text-slate-800 dark:text-slate-100",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl p-8 text-center space-y-5",
			children: creating ? /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-4 py-6",
				children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-10 h-10 text-[#00897B] dark:text-teal-400 animate-spin mx-auto" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-base font-extrabold text-slate-900 dark:text-white",
					children: "Menyiapkan Formulir Baru..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 29
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
					children: "Anda akan langsung diarahkan ke Form Builder."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 29
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 25
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 21
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-12 h-12 rounded-full bg-red-100 dark:bg-red-950/50 text-red-600 dark:text-red-400 flex items-center justify-center mx-auto",
						children: /* @__PURE__ */ _jsxDEV(AlertCircle, { size: 24 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 29
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base font-extrabold text-slate-900 dark:text-white",
						children: "Gagal Membuat Formulir"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 29
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-red-500 dark:text-red-400 mt-1",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 29
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex gap-3 pt-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => navigate("/my-forms"),
							className: "flex-1 py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all",
							children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 33
							}, this), " Kembali"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => window.location.reload(),
							className: "flex-1 py-2.5 px-4 bg-[#00897B] hover:bg-[#00796B] text-white font-bold text-xs rounded-xl transition-all",
							children: "Coba Lagi"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 25
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 21
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 9
	}, this);
}
_s(CreateForm, "LYjqTOf/O/8/dT1esURsE1v8CuY=", false, function() {
	return [useNavigate, useLocation];
});
_c = CreateForm;
var _c;
$RefreshReg$(_c, "CreateForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/form-builder/CreateForm.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-builder/CreateForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-builder/CreateForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-builder/CreateForm.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGFBQWEsbUJBQW1CO0FBQ3pDLFNBQVMsU0FBUyxXQUFXLG1CQUFtQjtBQUNoRCxTQUFTLFlBQVksb0JBQW9COzs7O0FBRXpDLGVBQWUsU0FBUyxhQUFhOztDQUNqQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLGVBQWUsU0FBUyxPQUFPO0NBRXJDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxJQUFJO0NBRTdDLGdCQUFnQjtFQUNaLElBQUksWUFBWTtFQUVoQixNQUFNLFdBQVcsWUFBWTtHQUN6QixJQUFJO0lBQ0EsWUFBWSxJQUFJO0lBQ2hCLFNBQVMsRUFBRTtJQUVYLE1BQU0sVUFBVTtLQUNaLE9BQU8sY0FBYyxTQUFTO0tBQzlCLGFBQWEsY0FBYyxlQUFlO0lBQzlDO0lBRUEsTUFBTSxNQUFNLE1BQU0sV0FBVyxPQUFPO0lBRXBDLElBQUksQ0FBQyxXQUFXO0lBRWhCLElBQUksSUFBSSxXQUFXLEtBQUs7S0FDcEIsYUFBYTtLQUNiLFNBQVMsUUFBUTtLQUNqQjtJQUNKO0lBRUEsSUFBSSxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUk7S0FDeEIsU0FBUyxVQUFVLElBQUksS0FBSyxHQUFHLFFBQVEsRUFBRSxTQUFTLEtBQUssQ0FBQztJQUM1RCxPQUFPO0tBQ0gsU0FBUyxJQUFJLFdBQVcsOEJBQThCO0tBQ3RELFlBQVksS0FBSztJQUNyQjtHQUNKLFNBQVMsS0FBSztJQUNWLElBQUksQ0FBQyxXQUFXO0lBQ2hCLFFBQVEsTUFBTSxzQkFBc0IsR0FBRztJQUN2QyxTQUFTLDBDQUEwQztJQUNuRCxZQUFZLEtBQUs7R0FDckI7RUFDSjtFQUVBLFNBQVM7RUFFVCxhQUFhO0dBQ1QsWUFBWTtFQUNoQjtDQUNKLEdBQUcsQ0FBQyxVQUFVLFlBQVksQ0FBQztDQUUzQixPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1gsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDVixXQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxTQUFELEVBQVMsV0FBVSxtRUFBb0U7Ozs7Y0FDdkYsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQTBEO0lBQStCOzs7O2NBQ3ZHLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWtEO0lBQWdEOzs7O1lBQzlHOzs7O1lBQ0o7Ozs7O2NBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNYLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O0tBQ3ZCOzs7OztLQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBMEQ7S0FBMEI7Ozs7ZUFDbEcsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQStDO0tBQVM7Ozs7YUFDcEU7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxVQUFEO09BQ0ksZUFBZSxTQUFTLFdBQVc7T0FDbkMsV0FBVTtpQkFGZCxDQUlJLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7aUJBQUMsVUFDbkI7Ozs7O2dCQUNSLHdCQUFDLFVBQUQ7T0FDSSxlQUFlLE9BQU8sU0FBUyxPQUFPO09BQ3RDLFdBQVU7aUJBQ2I7TUFFTzs7OztjQUNQOzs7Ozs7SUFDSjs7Ozs7O0VBRVI7Ozs7O0NBQ0o7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ3JlYXRlRm9ybS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgTG9hZGVyMiwgQXJyb3dMZWZ0LCBBbGVydENpcmNsZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVGb3JtLCBjbGVhclNlc3Npb24gfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ3JlYXRlRm9ybSgpIHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuICAgIGNvbnN0IHRlbXBsYXRlRGF0YSA9IGxvY2F0aW9uLnN0YXRlPy50ZW1wbGF0ZURhdGE7XG5cbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbY3JlYXRpbmcsIHNldENyZWF0aW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgbGV0IGlzTW91bnRlZCA9IHRydWU7XG5cbiAgICAgICAgY29uc3QgaW5pdEZvcm0gPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHNldENyZWF0aW5nKHRydWUpO1xuICAgICAgICAgICAgICAgIHNldEVycm9yKCcnKTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiB0ZW1wbGF0ZURhdGE/LnRpdGxlIHx8ICdGb3JtdWxpciBUYW5wYSBKdWR1bCcsXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiB0ZW1wbGF0ZURhdGE/LmRlc2NyaXB0aW9uIHx8ICcnLFxuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjcmVhdGVGb3JtKHBheWxvYWQpO1xuXG4gICAgICAgICAgICAgICAgaWYgKCFpc01vdW50ZWQpIHJldHVybjtcblxuICAgICAgICAgICAgICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDEpIHtcbiAgICAgICAgICAgICAgICAgICAgY2xlYXJTZXNzaW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChyZXMub2sgJiYgcmVzLmRhdGE/LmlkKSB7XG4gICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvZm9ybXMvJHtyZXMuZGF0YS5pZH0vZWRpdGAsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcihyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVtYnVhdCBmb3JtdWxpciBiYXJ1LicpO1xuICAgICAgICAgICAgICAgICAgICBzZXRDcmVhdGluZyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFpc01vdW50ZWQpIHJldHVybjtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdDcmVhdGUgZm9ybSBlcnJvcjonLCBlcnIpO1xuICAgICAgICAgICAgICAgIHNldEVycm9yKCdUZXJqYWRpIGtlc2FsYWhhbiBzYWF0IG1lbWJ1YXQgZm9ybXVsaXIuJyk7XG4gICAgICAgICAgICAgICAgc2V0Q3JlYXRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGluaXRGb3JtKCk7XG5cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGlzTW91bnRlZCA9IGZhbHNlO1xuICAgICAgICB9O1xuICAgIH0sIFtuYXZpZ2F0ZSwgdGVtcGxhdGVEYXRhXSk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1bI0Y0RjhGN10gZGFyazpiZy1zbGF0ZS05NTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGZvbnQtc2FucyB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc2hhZG93LXhsIHAtOCB0ZXh0LWNlbnRlciBzcGFjZS15LTVcIj5cbiAgICAgICAgICAgICAgICB7Y3JlYXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IHB5LTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgYW5pbWF0ZS1zcGluIG14LWF1dG9cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPk1lbnlpYXBrYW4gRm9ybXVsaXIgQmFydS4uLjwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5BbmRhIGFrYW4gbGFuZ3N1bmcgZGlhcmFoa2FuIGtlIEZvcm0gQnVpbGRlci48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtZnVsbCBiZy1yZWQtMTAwIGRhcms6YmctcmVkLTk1MC81MCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBzaXplPXsyNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPkdhZ2FsIE1lbWJ1YXQgRm9ybXVsaXI8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1yZWQtNTAwIGRhcms6dGV4dC1yZWQtNDAwIG10LTFcIj57ZXJyb3J9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTMgcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9teS1mb3JtcycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMi41IHB4LTQgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCB0ZXh0LXhzIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QXJyb3dMZWZ0IHNpemU9ezE0fSAvPiBLZW1iYWxpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yLjUgcHgtNCBiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb2JhIExhZ2lcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXX0=