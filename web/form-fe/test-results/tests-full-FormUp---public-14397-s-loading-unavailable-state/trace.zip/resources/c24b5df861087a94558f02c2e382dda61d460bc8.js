import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboard/userDashboard/templateForm.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { HelpCircle, Loader2, FileText, CheckCircle2, Calculator, Code2, Sparkles, ArrowRight } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import Topbar from "/src/components/layout/Topbar.jsx";
import { createForm, updateFormSettings, saveQuestions, clearSession } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/templateForm.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const TEMPLATES = [
	{
		id: "tpl-umum",
		title: "Formulir Pendaftaran & Survei Umum",
		category: "Form Umum",
		categoryColor: "text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800",
		icon: FileText,
		questionCount: 6,
		description: "Templat serbaguna seperti Google Form dengan urutan soal teracak secara default untuk mengumpulkan biodata, jenis kelamin, hobi, dan kritik/saran.",
		bannerImage: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&auto=format&fit=crop&q=80",
		settings: {
			randomizeQuestions: true,
			formTypeId: 1,
			showScore: false,
			oneResponse: false,
			requiredLogin: false
		},
		questions: [
			{
				typeId: 1,
				question: "Nama Lengkap",
				isRequired: true,
				options: []
			},
			{
				typeId: 1,
				question: "Alamat Email",
				isRequired: true,
				options: []
			},
			{
				typeId: 1,
				question: "Nomor Telepon / WhatsApp",
				isRequired: true,
				options: []
			},
			{
				typeId: 2,
				question: "Jenis Kelamin",
				isRequired: true,
				options: [{
					optionText: "Laki-laki",
					isCorrect: false
				}, {
					optionText: "Perempuan",
					isCorrect: false
				}]
			},
			{
				typeId: 3,
				question: "Hobi & Minat",
				isRequired: false,
				options: [
					{
						optionText: "Membaca Buku",
						isCorrect: false
					},
					{
						optionText: "Olahraga & Kebugaran",
						isCorrect: false
					},
					{
						optionText: "Musik & Kesenian",
						isCorrect: false
					},
					{
						optionText: "Teknologi & Koding",
						isCorrect: false
					}
				]
			},
			{
				typeId: 1,
				question: "Kritik dan Saran untuk Peningkatan Layanan Kami",
				isRequired: false,
				options: []
			}
		]
	},
	{
		id: "tpl-ujian-pg",
		title: "Ujian Pilihan Ganda & Kuis Akademik",
		category: "Ujian PG",
		categoryColor: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800",
		icon: CheckCircle2,
		questionCount: 3,
		description: "Templat ujian pilihan ganda resmi dengan pengaturan otomatis: Timer 30 menit, Batasi 1 respons per pengguna, dan Wajib login akun.",
		bannerImage: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=800&auto=format&fit=crop&q=80",
		settings: {
			timerDuration: 1800,
			oneResponse: true,
			requiredLogin: true,
			showScore: true,
			randomizeQuestions: true,
			formTypeId: 2
		},
		questions: [
			{
				typeId: 2,
				question: "Apa nama ibu kota negara Indonesia yang baru yang berlokasi di Kalimantan Timur?",
				isRequired: true,
				correctAnswer: "Nusantara",
				options: [
					{
						optionText: "Nusantara",
						isCorrect: true
					},
					{
						optionText: "Jakarta",
						isCorrect: false
					},
					{
						optionText: "Balikpapan",
						isCorrect: false
					},
					{
						optionText: "Samarinda",
						isCorrect: false
					}
				]
			},
			{
				typeId: 2,
				question: "Berapakah hasil dari 10 + 5?",
				isRequired: true,
				correctAnswer: "15",
				options: [
					{
						optionText: "15",
						isCorrect: true
					},
					{
						optionText: "12",
						isCorrect: false
					},
					{
						optionText: "20",
						isCorrect: false
					},
					{
						optionText: "25",
						isCorrect: false
					}
				]
			},
			{
				typeId: 2,
				question: "Manakah planet terbesar di dalam tata surya kita?",
				isRequired: true,
				correctAnswer: "Yupiter",
				options: [
					{
						optionText: "Yupiter",
						isCorrect: true
					},
					{
						optionText: "Saturnus",
						isCorrect: false
					},
					{
						optionText: "Bumi",
						isCorrect: false
					},
					{
						optionText: "Mars",
						isCorrect: false
					}
				]
			}
		]
	},
	{
		id: "tpl-matematika",
		title: "Kuis & Latihan Soal Matematika",
		category: "Matematika",
		categoryColor: "text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/60 border border-purple-200 dark:border-purple-800",
		icon: Calculator,
		questionCount: 4,
		description: "Templat soal matematika interaktif yang memanfaatkan rumus KaTeX rendered LaTeX, aljabar, integral tentu, limit, dan geometri Pythagoras.",
		bannerImage: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&auto=format&fit=crop&q=80",
		settings: {
			showScore: true,
			randomizeQuestions: true,
			formTypeId: 1,
			oneResponse: false,
			requiredLogin: false
		},
		questions: [
			{
				typeId: 2,
				question: "<p>Tentukan himpunan penyelesaian dari persamaan kuadrat berikut jika $$a = 1, b = -5, c = 6$$ menggunakan rumus kuadratik:</p><p>$$x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$$</p>",
				isRequired: true,
				correctAnswer: "x = 2 dan x = 3",
				options: [
					{
						optionText: "x = 2 dan x = 3",
						isCorrect: true
					},
					{
						optionText: "x = -2 dan x = -3",
						isCorrect: false
					},
					{
						optionText: "x = 1 dan x = 6",
						isCorrect: false
					},
					{
						optionText: "x = -1 dan x = 5",
						isCorrect: false
					}
				]
			},
			{
				typeId: 2,
				question: "<p>Berapakah hasil evaluasi dari integral tentu berikut?</p><p>$$\\int_{0}^{2} 3x^2 \\, dx$$</p>",
				isRequired: true,
				correctAnswer: "8",
				options: [
					{
						optionText: "8",
						isCorrect: true
					},
					{
						optionText: "6",
						isCorrect: false
					},
					{
						optionText: "12",
						isCorrect: false
					},
					{
						optionText: "4",
						isCorrect: false
					}
				]
			},
			{
				typeId: 2,
				question: "<p>Hitunglah nilai limit fungsi trigonometri berikut:</p><p>$$\\lim_{x \\to 0} \\frac{\\sin(2x)}{x}$$</p>",
				isRequired: true,
				correctAnswer: "2",
				options: [
					{
						optionText: "2",
						isCorrect: true
					},
					{
						optionText: "0",
						isCorrect: false
					},
					{
						optionText: "1",
						isCorrect: false
					},
					{
						optionText: "Tak Hingga (\\infty)",
						isCorrect: false
					}
				]
			},
			{
				typeId: 2,
				question: "<p>Diketahui segitiga siku-siku dengan panjang sisi tegak $$a = 6\\text{ cm}$$ dan $$b = 8\\text{ cm}$$. Berapakah panjang sisi miring ($$c$$) berdasarkan teorema Pythagoras $$a^2 + b^2 = c^2$$?</p>",
				isRequired: true,
				correctAnswer: "10 cm",
				options: [
					{
						optionText: "10 cm",
						isCorrect: true
					},
					{
						optionText: "12 cm",
						isCorrect: false
					},
					{
						optionText: "14 cm",
						isCorrect: false
					},
					{
						optionText: "15 cm",
						isCorrect: false
					}
				]
			}
		]
	},
	{
		id: "tpl-coding",
		title: "Tes Kompetensi Pemrograman & Koding",
		category: "Koding",
		categoryColor: "text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800",
		icon: Code2,
		questionCount: 4,
		description: "Templat tes koding terstruktur dengan blok kode bawaan (syntax highlighting), logika JavaScript, rekursi Python, struktur data LIFO, dan query SQL.",
		bannerImage: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80",
		settings: {
			showScore: true,
			oneResponse: true,
			timerDuration: 2700,
			formTypeId: 1,
			randomizeQuestions: false,
			requiredLogin: false
		},
		questions: [
			{
				typeId: 2,
				question: "<p>Perhatikan potongan kode JavaScript berikut:</p><pre><code class=\"language-javascript\">const numbers = [1, 2, 3, 4];\nconst result = numbers.map(n => n * 2).filter(n => n > 4);\nconsole.log(result);</code></pre><p>Apakah output yang dicetak ke console?</p>",
				isRequired: true,
				correctAnswer: "[6, 8]",
				options: [
					{
						optionText: "[6, 8]",
						isCorrect: true
					},
					{
						optionText: "[4, 6, 8]",
						isCorrect: false
					},
					{
						optionText: "[2, 4, 6, 8]",
						isCorrect: false
					},
					{
						optionText: "[8]",
						isCorrect: false
					}
				]
			},
			{
				typeId: 2,
				question: "<p>Perhatikan fungsi rekursif Python berikut:</p><pre><code class=\"language-python\">def faktorial(n):\n    if n <= 1:\n        return 1\n    return n * faktorial(n - 1)\n\nprint(faktorial(4))</code></pre><p>Berapakah nilai yang dihasilkan saat fungsi tersebut dieksekusi?</p>",
				isRequired: true,
				correctAnswer: "24",
				options: [
					{
						optionText: "24",
						isCorrect: true
					},
					{
						optionText: "12",
						isCorrect: false
					},
					{
						optionText: "16",
						isCorrect: false
					},
					{
						optionText: "4",
						isCorrect: false
					}
				]
			},
			{
				typeId: 2,
				question: "<p>Dalam struktur data pemrograman, operasi <code>push()</code> dan <code>pop()</code> pada Stack mengikuti prinsip dasar apa?</p>",
				isRequired: true,
				correctAnswer: "LIFO (Last In, First Out)",
				options: [
					{
						optionText: "LIFO (Last In, First Out)",
						isCorrect: true
					},
					{
						optionText: "FIFO (First In, First Out)",
						isCorrect: false
					},
					{
						optionText: "LILO (Last In, Last Out)",
						isCorrect: false
					},
					{
						optionText: "Random Access",
						isCorrect: false
					}
				]
			},
			{
				typeId: 2,
				question: "<p>Perhatikan query SQL berikut:</p><pre><code class=\"language-sql\">SELECT COUNT(*) FROM users WHERE status = 'active';</code></pre><p>Apa fungsi utama dari klausa <code>COUNT(*)</code> tersebut?</p>",
				isRequired: true,
				correctAnswer: "Menghitung total baris pengguna yang berstatus aktif",
				options: [
					{
						optionText: "Menghitung total baris pengguna yang berstatus aktif",
						isCorrect: true
					},
					{
						optionText: "Mengambil seluruh kolom tabel users",
						isCorrect: false
					},
					{
						optionText: "Menjumlahkan nilai kolom status",
						isCorrect: false
					},
					{
						optionText: "Menghapus data user yang aktif",
						isCorrect: false
					}
				]
			}
		]
	}
];
export default function TemplatesPage() {
	_s();
	const navigate = useNavigate();
	const [cloningId, setCloningId] = useState(null);
	const [searchQuery, setSearchQuery] = useState("");
	const handleCreateFromTemplate = async (template) => {
		if (!template) return;
		setCloningId(template.id);
		try {
			// 1. Buat form baru dengan judul & deskripsi templat
			const formRes = await createForm({
				title: template.title,
				description: template.description
			});
			if (formRes.status === 401) {
				clearSession();
				navigate("/login");
				return;
			}
			if (formRes.ok && formRes.data?.id) {
				const formId = formRes.data.id;
				// 2. Simpan pengaturan templat jika tersedia
				if (template.settings) {
					await updateFormSettings(formId, template.settings);
				}
				// 3. Simpan seluruh soal templat beserta kunci jawaban & opsi
				if (template.questions?.length > 0) {
					const formattedQuestions = template.questions.map((q, idx) => ({
						typeId: q.typeId,
						question: q.question,
						questionFormat: "html",
						questionOrder: idx + 1,
						isRequired: !!q.isRequired,
						correctAnswer: q.correctAnswer || null,
						options: (q.options || []).map((o, oi) => ({
							optionText: o.optionText,
							isCorrect: !!o.isCorrect,
							optionOrder: oi + 1
						}))
					}));
					await saveQuestions(formId, formattedQuestions);
				}
				// 4. Langsung navigasi ke Form Builder dengan data terisi utuh
				navigate(`/forms/${formId}/edit`);
			} else {
				navigate("/create-form");
			}
		} catch (err) {
			console.error("Error using template:", err);
			navigate("/create-form");
		} finally {
			setCloningId(null);
		}
	};
	const filteredTemplates = TEMPLATES.filter((tpl) => {
		if (!searchQuery.trim()) return true;
		const q = searchQuery.toLowerCase();
		return tpl.title.toLowerCase().includes(q) || tpl.description.toLowerCase().includes(q) || tpl.category.toLowerCase().includes(q);
	});
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen w-full bg-[#F4F8F7] dark:bg-slate-950 font-sans antialiased text-slate-800 dark:text-slate-100 transition-colors",
		children: [/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 344,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex-1 flex flex-col min-w-0 overflow-y-auto",
			children: /* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 w-full p-4 sm:p-6 lg:p-8 space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV(Topbar, {
						searchQuery,
						onSearchChange: setSearchQuery,
						placeholder: "Cari templat atau kategori..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 349,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight",
							children: "Galeri Templat Pilihan"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV(Sparkles, {
							size: 20,
							className: "text-[#00897B] dark:text-teal-400"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 358,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 356,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 font-medium mt-1 max-w-xl",
						children: "Pilih templat profesional yang langsung terisi pertanyaan, kunci jawaban, dan pengaturan bawaan."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 360,
						columnNumber: 25
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-6",
						children: filteredTemplates.map((tpl) => {
							const IconComponent = tpl.icon;
							const isCloning = cloningId === tpl.id;
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all flex flex-col overflow-hidden group",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "h-44 w-full relative bg-slate-100 dark:bg-slate-800 overflow-hidden flex items-center justify-center border-b border-slate-100 dark:border-slate-800",
									children: [
										/* @__PURE__ */ _jsxDEV("img", {
											src: tpl.bannerImage,
											alt: tpl.title,
											className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 374,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-linear-to-t from-black/60 via-transparent to-transparent" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 379,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute bottom-3 left-4 right-4 flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: `text-[11px] font-extrabold px-3 py-1 rounded-full shadow-xs backdrop-blur-md ${tpl.categoryColor}`,
												children: tpl.category
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 382,
												columnNumber: 45
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-white text-xs font-bold flex items-center gap-1.5 drop-shadow-md",
												children: [
													/* @__PURE__ */ _jsxDEV(HelpCircle, { size: 14 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 386,
														columnNumber: 49
													}, this),
													" ",
													tpl.questionCount,
													" Soal Lengkap"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 385,
												columnNumber: 45
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 381,
											columnNumber: 41
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 373,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-6 flex-1 flex flex-col justify-between space-y-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400",
												children: /* @__PURE__ */ _jsxDEV(IconComponent, { size: 18 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 395,
													columnNumber: 53
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 394,
												columnNumber: 49
											}, this), /* @__PURE__ */ _jsxDEV("h3", {
												className: "text-base font-extrabold text-slate-900 dark:text-white line-clamp-1 group-hover:text-[#00897B] dark:group-hover:text-teal-400 transition-colors",
												children: tpl.title
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 397,
												columnNumber: 49
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 393,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500 dark:text-slate-400 font-medium leading-relaxed",
											children: tpl.description
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 401,
											columnNumber: 45
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 392,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "pt-2 border-t border-slate-100 dark:border-slate-800",
										children: /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => handleCreateFromTemplate(tpl),
											disabled: isCloning,
											className: "w-full py-3 px-4 bg-[#00897B] hover:bg-[#00796B] active:scale-[0.99] dark:bg-teal-600 dark:hover:bg-teal-700 text-white font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer shadow-xs",
											children: isCloning ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
												size: 15,
												className: "animate-spin"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 414,
												columnNumber: 57
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Menyiapkan Formulir & Soal..." }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 415,
												columnNumber: 57
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 413,
												columnNumber: 53
											}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Gunakan Templat Ini" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 419,
												columnNumber: 57
											}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 420,
												columnNumber: 57
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 418,
												columnNumber: 53
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 407,
											columnNumber: 45
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 406,
										columnNumber: 41
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 391,
									columnNumber: 37
								}, this)]
							}, tpl.id, true, {
								fileName: _jsxFileName,
								lineNumber: 372,
								columnNumber: 33
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 365,
						columnNumber: 21
					}, this),
					filteredTemplates.length === 0 && searchQuery && /* @__PURE__ */ _jsxDEV("div", {
						className: "py-16 text-center text-slate-400 dark:text-slate-500 text-sm font-medium",
						children: [
							"Tidak ada templat yang cocok dengan pencarian \"",
							searchQuery,
							"\"."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 433,
						columnNumber: 25
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 347,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 346,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 343,
		columnNumber: 9
	}, this);
}
_s(TemplatesPage, "U69aBrGEY45/YmA0IprVT71HpMI=", false, function() {
	return [useNavigate];
});
_c = TemplatesPage;
var _c;
$RefreshReg$(_c, "TemplatesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/dashboard/userDashboard/templateForm.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/templateForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/templateForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/templateForm.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxtQkFBbUI7QUFDNUIsU0FDSSxZQUFZLFNBQVMsVUFBVSxjQUMvQixZQUFZLE9BQU8sVUFBVSxrQkFDMUI7QUFDUCxPQUFPLGFBQWE7QUFDcEIsT0FBTyxZQUFZO0FBQ25CLFNBQ0ksWUFBWSxvQkFBb0IsZUFBZSxvQkFDNUM7Ozs7QUFFUCxNQUFNLFlBQVk7Q0FDZDtFQUNJLElBQUk7RUFDSixPQUFPO0VBQ1AsVUFBVTtFQUNWLGVBQWU7RUFDZixNQUFNO0VBQ04sZUFBZTtFQUNmLGFBQWE7RUFDYixhQUFhO0VBQ2IsVUFBVTtHQUNOLG9CQUFvQjtHQUNwQixZQUFZO0dBQ1osV0FBVztHQUNYLGFBQWE7R0FDYixlQUFlO0VBQ25CO0VBQ0EsV0FBVztHQUNQO0lBQ0ksUUFBUTtJQUNSLFVBQVU7SUFDVixZQUFZO0lBQ1osU0FBUyxDQUFDO0dBQ2Q7R0FDQTtJQUNJLFFBQVE7SUFDUixVQUFVO0lBQ1YsWUFBWTtJQUNaLFNBQVMsQ0FBQztHQUNkO0dBQ0E7SUFDSSxRQUFRO0lBQ1IsVUFBVTtJQUNWLFlBQVk7SUFDWixTQUFTLENBQUM7R0FDZDtHQUNBO0lBQ0ksUUFBUTtJQUNSLFVBQVU7SUFDVixZQUFZO0lBQ1osU0FBUyxDQUNMO0tBQUUsWUFBWTtLQUFhLFdBQVc7SUFBTSxHQUM1QztLQUFFLFlBQVk7S0FBYSxXQUFXO0lBQU0sQ0FDaEQ7R0FDSjtHQUNBO0lBQ0ksUUFBUTtJQUNSLFVBQVU7SUFDVixZQUFZO0lBQ1osU0FBUztLQUNMO01BQUUsWUFBWTtNQUFnQixXQUFXO0tBQU07S0FDL0M7TUFBRSxZQUFZO01BQXdCLFdBQVc7S0FBTTtLQUN2RDtNQUFFLFlBQVk7TUFBb0IsV0FBVztLQUFNO0tBQ25EO01BQUUsWUFBWTtNQUFzQixXQUFXO0tBQU07SUFDekQ7R0FDSjtHQUNBO0lBQ0ksUUFBUTtJQUNSLFVBQVU7SUFDVixZQUFZO0lBQ1osU0FBUyxDQUFDO0dBQ2Q7RUFDSjtDQUNKO0NBQ0E7RUFDSSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixlQUFlO0VBQ2YsTUFBTTtFQUNOLGVBQWU7RUFDZixhQUFhO0VBQ2IsYUFBYTtFQUNiLFVBQVU7R0FDTixlQUFlO0dBQ2YsYUFBYTtHQUNiLGVBQWU7R0FDZixXQUFXO0dBQ1gsb0JBQW9CO0dBQ3BCLFlBQVk7RUFDaEI7RUFDQSxXQUFXO0dBQ1A7SUFDSSxRQUFRO0lBQ1IsVUFBVTtJQUNWLFlBQVk7SUFDWixlQUFlO0lBQ2YsU0FBUztLQUNMO01BQUUsWUFBWTtNQUFhLFdBQVc7S0FBSztLQUMzQztNQUFFLFlBQVk7TUFBVyxXQUFXO0tBQU07S0FDMUM7TUFBRSxZQUFZO01BQWMsV0FBVztLQUFNO0tBQzdDO01BQUUsWUFBWTtNQUFhLFdBQVc7S0FBTTtJQUNoRDtHQUNKO0dBQ0E7SUFDSSxRQUFRO0lBQ1IsVUFBVTtJQUNWLFlBQVk7SUFDWixlQUFlO0lBQ2YsU0FBUztLQUNMO01BQUUsWUFBWTtNQUFNLFdBQVc7S0FBSztLQUNwQztNQUFFLFlBQVk7TUFBTSxXQUFXO0tBQU07S0FDckM7TUFBRSxZQUFZO01BQU0sV0FBVztLQUFNO0tBQ3JDO01BQUUsWUFBWTtNQUFNLFdBQVc7S0FBTTtJQUN6QztHQUNKO0dBQ0E7SUFDSSxRQUFRO0lBQ1IsVUFBVTtJQUNWLFlBQVk7SUFDWixlQUFlO0lBQ2YsU0FBUztLQUNMO01BQUUsWUFBWTtNQUFXLFdBQVc7S0FBSztLQUN6QztNQUFFLFlBQVk7TUFBWSxXQUFXO0tBQU07S0FDM0M7TUFBRSxZQUFZO01BQVEsV0FBVztLQUFNO0tBQ3ZDO01BQUUsWUFBWTtNQUFRLFdBQVc7S0FBTTtJQUMzQztHQUNKO0VBQ0o7Q0FDSjtDQUNBO0VBQ0ksSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsZUFBZTtFQUNmLE1BQU07RUFDTixlQUFlO0VBQ2YsYUFBYTtFQUNiLGFBQWE7RUFDYixVQUFVO0dBQ04sV0FBVztHQUNYLG9CQUFvQjtHQUNwQixZQUFZO0dBQ1osYUFBYTtHQUNiLGVBQWU7RUFDbkI7RUFDQSxXQUFXO0dBQ1A7SUFDSSxRQUFRO0lBQ1IsVUFBVTtJQUNWLFlBQVk7SUFDWixlQUFlO0lBQ2YsU0FBUztLQUNMO01BQUUsWUFBWTtNQUFtQixXQUFXO0tBQUs7S0FDakQ7TUFBRSxZQUFZO01BQXFCLFdBQVc7S0FBTTtLQUNwRDtNQUFFLFlBQVk7TUFBbUIsV0FBVztLQUFNO0tBQ2xEO01BQUUsWUFBWTtNQUFvQixXQUFXO0tBQU07SUFDdkQ7R0FDSjtHQUNBO0lBQ0ksUUFBUTtJQUNSLFVBQVU7SUFDVixZQUFZO0lBQ1osZUFBZTtJQUNmLFNBQVM7S0FDTDtNQUFFLFlBQVk7TUFBSyxXQUFXO0tBQUs7S0FDbkM7TUFBRSxZQUFZO01BQUssV0FBVztLQUFNO0tBQ3BDO01BQUUsWUFBWTtNQUFNLFdBQVc7S0FBTTtLQUNyQztNQUFFLFlBQVk7TUFBSyxXQUFXO0tBQU07SUFDeEM7R0FDSjtHQUNBO0lBQ0ksUUFBUTtJQUNSLFVBQVU7SUFDVixZQUFZO0lBQ1osZUFBZTtJQUNmLFNBQVM7S0FDTDtNQUFFLFlBQVk7TUFBSyxXQUFXO0tBQUs7S0FDbkM7TUFBRSxZQUFZO01BQUssV0FBVztLQUFNO0tBQ3BDO01BQUUsWUFBWTtNQUFLLFdBQVc7S0FBTTtLQUNwQztNQUFFLFlBQVk7TUFBd0IsV0FBVztLQUFNO0lBQzNEO0dBQ0o7R0FDQTtJQUNJLFFBQVE7SUFDUixVQUFVO0lBQ1YsWUFBWTtJQUNaLGVBQWU7SUFDZixTQUFTO0tBQ0w7TUFBRSxZQUFZO01BQVMsV0FBVztLQUFLO0tBQ3ZDO01BQUUsWUFBWTtNQUFTLFdBQVc7S0FBTTtLQUN4QztNQUFFLFlBQVk7TUFBUyxXQUFXO0tBQU07S0FDeEM7TUFBRSxZQUFZO01BQVMsV0FBVztLQUFNO0lBQzVDO0dBQ0o7RUFDSjtDQUNKO0NBQ0E7RUFDSSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixlQUFlO0VBQ2YsTUFBTTtFQUNOLGVBQWU7RUFDZixhQUFhO0VBQ2IsYUFBYTtFQUNiLFVBQVU7R0FDTixXQUFXO0dBQ1gsYUFBYTtHQUNiLGVBQWU7R0FDZixZQUFZO0dBQ1osb0JBQW9CO0dBQ3BCLGVBQWU7RUFDbkI7RUFDQSxXQUFXO0dBQ1A7SUFDSSxRQUFRO0lBQ1IsVUFBVTtJQUNWLFlBQVk7SUFDWixlQUFlO0lBQ2YsU0FBUztLQUNMO01BQUUsWUFBWTtNQUFVLFdBQVc7S0FBSztLQUN4QztNQUFFLFlBQVk7TUFBYSxXQUFXO0tBQU07S0FDNUM7TUFBRSxZQUFZO01BQWdCLFdBQVc7S0FBTTtLQUMvQztNQUFFLFlBQVk7TUFBTyxXQUFXO0tBQU07SUFDMUM7R0FDSjtHQUNBO0lBQ0ksUUFBUTtJQUNSLFVBQVU7SUFDVixZQUFZO0lBQ1osZUFBZTtJQUNmLFNBQVM7S0FDTDtNQUFFLFlBQVk7TUFBTSxXQUFXO0tBQUs7S0FDcEM7TUFBRSxZQUFZO01BQU0sV0FBVztLQUFNO0tBQ3JDO01BQUUsWUFBWTtNQUFNLFdBQVc7S0FBTTtLQUNyQztNQUFFLFlBQVk7TUFBSyxXQUFXO0tBQU07SUFDeEM7R0FDSjtHQUNBO0lBQ0ksUUFBUTtJQUNSLFVBQVU7SUFDVixZQUFZO0lBQ1osZUFBZTtJQUNmLFNBQVM7S0FDTDtNQUFFLFlBQVk7TUFBNkIsV0FBVztLQUFLO0tBQzNEO01BQUUsWUFBWTtNQUE4QixXQUFXO0tBQU07S0FDN0Q7TUFBRSxZQUFZO01BQTRCLFdBQVc7S0FBTTtLQUMzRDtNQUFFLFlBQVk7TUFBaUIsV0FBVztLQUFNO0lBQ3BEO0dBQ0o7R0FDQTtJQUNJLFFBQVE7SUFDUixVQUFVO0lBQ1YsWUFBWTtJQUNaLGVBQWU7SUFDZixTQUFTO0tBQ0w7TUFBRSxZQUFZO01BQXdELFdBQVc7S0FBSztLQUN0RjtNQUFFLFlBQVk7TUFBdUMsV0FBVztLQUFNO0tBQ3RFO01BQUUsWUFBWTtNQUFtQyxXQUFXO0tBQU07S0FDbEU7TUFBRSxZQUFZO01BQWtDLFdBQVc7S0FBTTtJQUNyRTtHQUNKO0VBQ0o7Q0FDSjtBQUNKO0FBRUEsZUFBZSxTQUFTLGdCQUFnQjs7Q0FDcEMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsSUFBSTtDQUMvQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBRWpELE1BQU0sMkJBQTJCLE9BQU8sYUFBYTtFQUNqRCxJQUFJLENBQUMsVUFBVTtFQUNmLGFBQWEsU0FBUyxFQUFFO0VBRXhCLElBQUk7O0dBRUEsTUFBTSxVQUFVLE1BQU0sV0FBVztJQUM3QixPQUFPLFNBQVM7SUFDaEIsYUFBYSxTQUFTO0dBQzFCLENBQUM7R0FFRCxJQUFJLFFBQVEsV0FBVyxLQUFLO0lBQ3hCLGFBQWE7SUFDYixTQUFTLFFBQVE7SUFDakI7R0FDSjtHQUVBLElBQUksUUFBUSxNQUFNLFFBQVEsTUFBTSxJQUFJO0lBQ2hDLE1BQU0sU0FBUyxRQUFRLEtBQUs7O0lBRzVCLElBQUksU0FBUyxVQUFVO0tBQ25CLE1BQU0sbUJBQW1CLFFBQVEsU0FBUyxRQUFRO0lBQ3REOztJQUdBLElBQUksU0FBUyxXQUFXLFNBQVMsR0FBRztLQUNoQyxNQUFNLHFCQUFxQixTQUFTLFVBQVUsS0FBSyxHQUFHLFNBQVM7TUFDM0QsUUFBUSxFQUFFO01BQ1YsVUFBVSxFQUFFO01BQ1osZ0JBQWdCO01BQ2hCLGVBQWUsTUFBTTtNQUNyQixZQUFZLENBQUMsQ0FBQyxFQUFFO01BQ2hCLGVBQWUsRUFBRSxpQkFBaUI7TUFDbEMsVUFBVSxFQUFFLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSyxHQUFHLFFBQVE7T0FDdkMsWUFBWSxFQUFFO09BQ2QsV0FBVyxDQUFDLENBQUMsRUFBRTtPQUNmLGFBQWEsS0FBSztNQUN0QixFQUFFO0tBQ04sRUFBRTtLQUVGLE1BQU0sY0FBYyxRQUFRLGtCQUFrQjtJQUNsRDs7SUFHQSxTQUFTLFVBQVUsT0FBTyxNQUFNO0dBQ3BDLE9BQU87SUFDSCxTQUFTLGNBQWM7R0FDM0I7RUFDSixTQUFTLEtBQUs7R0FDVixRQUFRLE1BQU0seUJBQXlCLEdBQUc7R0FDMUMsU0FBUyxjQUFjO0VBQzNCLFVBQVU7R0FDTixhQUFhLElBQUk7RUFDckI7Q0FDSjtDQUVBLE1BQU0sb0JBQW9CLFVBQVUsUUFBUSxRQUFRO0VBQ2hELElBQUksQ0FBQyxZQUFZLEtBQUssR0FBRyxPQUFPO0VBQ2hDLE1BQU0sSUFBSSxZQUFZLFlBQVk7RUFDbEMsT0FDSSxJQUFJLE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQ2xDLElBQUksWUFBWSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDeEMsSUFBSSxTQUFTLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQztDQUU3QyxDQUFDO0NBRUQsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0ksd0JBQUMsU0FBRCxDQUFVOzs7O1lBRVYsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQjtLQUVJLHdCQUFDLFFBQUQ7TUFDaUI7TUFDYixnQkFBZ0I7TUFDaEIsYUFBWTtLQUNmOzs7OztLQUVELHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUF3RTtNQUEwQjs7OztnQkFDaEgsd0JBQUMsVUFBRDtPQUFVLE1BQU07T0FBSSxXQUFVO01BQXFDOzs7O2NBQ2xFOzs7OztlQUNMLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF1RTtLQUVqRjs7OzthQUNGOzs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUVWLGtCQUFrQixLQUFLLFFBQVE7T0FDNUIsTUFBTSxnQkFBZ0IsSUFBSTtPQUMxQixNQUFNLFlBQVksY0FBYyxJQUFJO09BRXBDLE9BQ0ksd0JBQUMsT0FBRDtRQUFrQixXQUFVO2tCQUE1QixDQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0ksd0JBQUMsT0FBRDtXQUNJLEtBQUssSUFBSTtXQUNULEtBQUssSUFBSTtXQUNULFdBQVU7VUFDYjs7Ozs7VUFDRCx3QkFBQyxPQUFELEVBQUssV0FBVSwrRUFBZ0Y7Ozs7O1VBRS9GLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsUUFBRDtZQUFNLFdBQVcsZ0ZBQWdGLElBQUk7c0JBQ2hHLElBQUk7V0FDSDs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEI7YUFDSSx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OzthQUFDO2FBQUUsSUFBSTthQUFjO1lBQzFDOzs7OzttQkFDTDs7Ozs7O1NBQ0o7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNYLHdCQUFDLGVBQUQsRUFBZSxNQUFNLEdBQUs7Ozs7O1dBQ3pCOzs7O3FCQUNMLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNULElBQUk7V0FDTDs7OzttQkFDSDs7Ozs7b0JBQ0wsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1IsSUFBSTtVQUNOOzs7O2tCQUNGOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWCx3QkFBQyxVQUFEO1dBQ0ksZUFBZSx5QkFBeUIsR0FBRztXQUMzQyxVQUFVO1dBQ1YsV0FBVTtxQkFFVCxZQUNHLGdEQUNJLHdCQUFDLFNBQUQ7WUFBUyxNQUFNO1lBQUksV0FBVTtXQUFnQjs7OztxQkFDN0Msd0JBQUMsUUFBRCxZQUFNLGdDQUFtQzs7OzttQkFDM0M7Ozs7c0JBRUYsZ0RBQ0ksd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7OztxQkFDL0Isd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7OzttQkFDekI7Ozs7O1VBRUY7Ozs7O1NBQ1A7Ozs7aUJBQ0o7Ozs7O2dCQUNKO1VBdERLLElBQUk7Ozs7Y0FzRFQ7TUFFYixDQUFDO0tBRUE7Ozs7O0tBRUosa0JBQWtCLFdBQVcsS0FBSyxlQUMvQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUEwRjtPQUN0QztPQUFZO01BQzNEOzs7Ozs7SUFHUDs7Ozs7O0VBQ0w7Ozs7VUFDSjs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidGVtcGxhdGVGb3JtLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQge1xuICAgIEhlbHBDaXJjbGUsIExvYWRlcjIsIEZpbGVUZXh0LCBDaGVja0NpcmNsZTIsXG4gICAgQ2FsY3VsYXRvciwgQ29kZTIsIFNwYXJrbGVzLCBBcnJvd1JpZ2h0XG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgU2lkZWJhciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2xheW91dC9TaWRlYmFyJztcbmltcG9ydCBUb3BiYXIgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9sYXlvdXQvVG9wYmFyJztcbmltcG9ydCB7XG4gICAgY3JlYXRlRm9ybSwgdXBkYXRlRm9ybVNldHRpbmdzLCBzYXZlUXVlc3Rpb25zLCBjbGVhclNlc3Npb25cbn0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5cbmNvbnN0IFRFTVBMQVRFUyA9IFtcbiAgICB7XG4gICAgICAgIGlkOiAndHBsLXVtdW0nLFxuICAgICAgICB0aXRsZTogJ0Zvcm11bGlyIFBlbmRhZnRhcmFuICYgU3VydmVpIFVtdW0nLFxuICAgICAgICBjYXRlZ29yeTogJ0Zvcm0gVW11bScsXG4gICAgICAgIGNhdGVnb3J5Q29sb3I6ICd0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCcsXG4gICAgICAgIGljb246IEZpbGVUZXh0LFxuICAgICAgICBxdWVzdGlvbkNvdW50OiA2LFxuICAgICAgICBkZXNjcmlwdGlvbjogJ1RlbXBsYXQgc2VyYmFndW5hIHNlcGVydGkgR29vZ2xlIEZvcm0gZGVuZ2FuIHVydXRhbiBzb2FsIHRlcmFjYWsgc2VjYXJhIGRlZmF1bHQgdW50dWsgbWVuZ3VtcHVsa2FuIGJpb2RhdGEsIGplbmlzIGtlbGFtaW4sIGhvYmksIGRhbiBrcml0aWsvc2FyYW4uJyxcbiAgICAgICAgYmFubmVySW1hZ2U6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTQ1NDE2NTgwNDYwNi1jM2Q1N2JjODZiNDA/dz04MDAmYXV0bz1mb3JtYXQmZml0PWNyb3AmcT04MCcsXG4gICAgICAgIHNldHRpbmdzOiB7XG4gICAgICAgICAgICByYW5kb21pemVRdWVzdGlvbnM6IHRydWUsXG4gICAgICAgICAgICBmb3JtVHlwZUlkOiAxLFxuICAgICAgICAgICAgc2hvd1Njb3JlOiBmYWxzZSxcbiAgICAgICAgICAgIG9uZVJlc3BvbnNlOiBmYWxzZSxcbiAgICAgICAgICAgIHJlcXVpcmVkTG9naW46IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBxdWVzdGlvbnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0eXBlSWQ6IDEsXG4gICAgICAgICAgICAgICAgcXVlc3Rpb246ICdOYW1hIExlbmdrYXAnLFxuICAgICAgICAgICAgICAgIGlzUmVxdWlyZWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgb3B0aW9uczogW11cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdHlwZUlkOiAxLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiAnQWxhbWF0IEVtYWlsJyxcbiAgICAgICAgICAgICAgICBpc1JlcXVpcmVkOiB0cnVlLFxuICAgICAgICAgICAgICAgIG9wdGlvbnM6IFtdXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHR5cGVJZDogMSxcbiAgICAgICAgICAgICAgICBxdWVzdGlvbjogJ05vbW9yIFRlbGVwb24gLyBXaGF0c0FwcCcsXG4gICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBvcHRpb25zOiBbXVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0eXBlSWQ6IDIsXG4gICAgICAgICAgICAgICAgcXVlc3Rpb246ICdKZW5pcyBLZWxhbWluJyxcbiAgICAgICAgICAgICAgICBpc1JlcXVpcmVkOiB0cnVlLFxuICAgICAgICAgICAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnTGFraS1sYWtpJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdQZXJlbXB1YW4nLCBpc0NvcnJlY3Q6IGZhbHNlIH1cbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHR5cGVJZDogMyxcbiAgICAgICAgICAgICAgICBxdWVzdGlvbjogJ0hvYmkgJiBNaW5hdCcsXG4gICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdNZW1iYWNhIEJ1a3UnLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ09sYWhyYWdhICYgS2VidWdhcmFuJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdNdXNpayAmIEtlc2VuaWFuJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdUZWtub2xvZ2kgJiBLb2RpbmcnLCBpc0NvcnJlY3Q6IGZhbHNlIH1cbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHR5cGVJZDogMSxcbiAgICAgICAgICAgICAgICBxdWVzdGlvbjogJ0tyaXRpayBkYW4gU2FyYW4gdW50dWsgUGVuaW5na2F0YW4gTGF5YW5hbiBLYW1pJyxcbiAgICAgICAgICAgICAgICBpc1JlcXVpcmVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBvcHRpb25zOiBbXVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGlkOiAndHBsLXVqaWFuLXBnJyxcbiAgICAgICAgdGl0bGU6ICdVamlhbiBQaWxpaGFuIEdhbmRhICYgS3VpcyBBa2FkZW1paycsXG4gICAgICAgIGNhdGVnb3J5OiAnVWppYW4gUEcnLFxuICAgICAgICBjYXRlZ29yeUNvbG9yOiAndGV4dC1ibHVlLTcwMCBkYXJrOnRleHQtYmx1ZS0zMDAgYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTUwLzYwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgZGFyazpib3JkZXItYmx1ZS04MDAnLFxuICAgICAgICBpY29uOiBDaGVja0NpcmNsZTIsXG4gICAgICAgIHF1ZXN0aW9uQ291bnQ6IDMsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnVGVtcGxhdCB1amlhbiBwaWxpaGFuIGdhbmRhIHJlc21pIGRlbmdhbiBwZW5nYXR1cmFuIG90b21hdGlzOiBUaW1lciAzMCBtZW5pdCwgQmF0YXNpIDEgcmVzcG9ucyBwZXIgcGVuZ2d1bmEsIGRhbiBXYWppYiBsb2dpbiBha3VuLicsXG4gICAgICAgIGJhbm5lckltYWdlOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE0MzQwMzAyMTY0MTEtMGI3OTNmNGI0MTczP3c9ODAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAnLFxuICAgICAgICBzZXR0aW5nczoge1xuICAgICAgICAgICAgdGltZXJEdXJhdGlvbjogMTgwMCxcbiAgICAgICAgICAgIG9uZVJlc3BvbnNlOiB0cnVlLFxuICAgICAgICAgICAgcmVxdWlyZWRMb2dpbjogdHJ1ZSxcbiAgICAgICAgICAgIHNob3dTY29yZTogdHJ1ZSxcbiAgICAgICAgICAgIHJhbmRvbWl6ZVF1ZXN0aW9uczogdHJ1ZSxcbiAgICAgICAgICAgIGZvcm1UeXBlSWQ6IDIsXG4gICAgICAgIH0sXG4gICAgICAgIHF1ZXN0aW9uczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHR5cGVJZDogMixcbiAgICAgICAgICAgICAgICBxdWVzdGlvbjogJ0FwYSBuYW1hIGlidSBrb3RhIG5lZ2FyYSBJbmRvbmVzaWEgeWFuZyBiYXJ1IHlhbmcgYmVybG9rYXNpIGRpIEthbGltYW50YW4gVGltdXI/JyxcbiAgICAgICAgICAgICAgICBpc1JlcXVpcmVkOiB0cnVlLFxuICAgICAgICAgICAgICAgIGNvcnJlY3RBbnN3ZXI6ICdOdXNhbnRhcmEnLFxuICAgICAgICAgICAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnTnVzYW50YXJhJywgaXNDb3JyZWN0OiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ0pha2FydGEnLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ0JhbGlrcGFwYW4nLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1NhbWFyaW5kYScsIGlzQ29ycmVjdDogZmFsc2UgfVxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdHlwZUlkOiAyLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiAnQmVyYXBha2FoIGhhc2lsIGRhcmkgMTAgKyA1PycsXG4gICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiAnMTUnLFxuICAgICAgICAgICAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnMTUnLCBpc0NvcnJlY3Q6IHRydWUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnMTInLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJzIwJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICcyNScsIGlzQ29ycmVjdDogZmFsc2UgfVxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdHlwZUlkOiAyLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiAnTWFuYWthaCBwbGFuZXQgdGVyYmVzYXIgZGkgZGFsYW0gdGF0YSBzdXJ5YSBraXRhPycsXG4gICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiAnWXVwaXRlcicsXG4gICAgICAgICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdZdXBpdGVyJywgaXNDb3JyZWN0OiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1NhdHVybnVzJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdCdW1pJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdNYXJzJywgaXNDb3JyZWN0OiBmYWxzZSB9XG4gICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGlkOiAndHBsLW1hdGVtYXRpa2EnLFxuICAgICAgICB0aXRsZTogJ0t1aXMgJiBMYXRpaGFuIFNvYWwgTWF0ZW1hdGlrYScsXG4gICAgICAgIGNhdGVnb3J5OiAnTWF0ZW1hdGlrYScsXG4gICAgICAgIGNhdGVnb3J5Q29sb3I6ICd0ZXh0LXB1cnBsZS03MDAgZGFyazp0ZXh0LXB1cnBsZS0zMDAgYmctcHVycGxlLTUwIGRhcms6YmctcHVycGxlLTk1MC82MCBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDAgZGFyazpib3JkZXItcHVycGxlLTgwMCcsXG4gICAgICAgIGljb246IENhbGN1bGF0b3IsXG4gICAgICAgIHF1ZXN0aW9uQ291bnQ6IDQsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnVGVtcGxhdCBzb2FsIG1hdGVtYXRpa2EgaW50ZXJha3RpZiB5YW5nIG1lbWFuZmFhdGthbiBydW11cyBLYVRlWCByZW5kZXJlZCBMYVRlWCwgYWxqYWJhciwgaW50ZWdyYWwgdGVudHUsIGxpbWl0LCBkYW4gZ2VvbWV0cmkgUHl0aGFnb3Jhcy4nLFxuICAgICAgICBiYW5uZXJJbWFnZTogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNjM1MDcwMDQxMDc4LWUzNjNkYmUwMDVjYj93PTgwMCZhdXRvPWZvcm1hdCZmaXQ9Y3JvcCZxPTgwJyxcbiAgICAgICAgc2V0dGluZ3M6IHtcbiAgICAgICAgICAgIHNob3dTY29yZTogdHJ1ZSxcbiAgICAgICAgICAgIHJhbmRvbWl6ZVF1ZXN0aW9uczogdHJ1ZSxcbiAgICAgICAgICAgIGZvcm1UeXBlSWQ6IDEsXG4gICAgICAgICAgICBvbmVSZXNwb25zZTogZmFsc2UsXG4gICAgICAgICAgICByZXF1aXJlZExvZ2luOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgcXVlc3Rpb25zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdHlwZUlkOiAyLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiAnPHA+VGVudHVrYW4gaGltcHVuYW4gcGVueWVsZXNhaWFuIGRhcmkgcGVyc2FtYWFuIGt1YWRyYXQgYmVyaWt1dCBqaWthICQkYSA9IDEsIGIgPSAtNSwgYyA9IDYkJCBtZW5nZ3VuYWthbiBydW11cyBrdWFkcmF0aWs6PC9wPjxwPiQkeCA9IFxcXFxmcmFjey1iIFxcXFxwbSBcXFxcc3FydHtiXjIgLSA0YWN9fXsyYX0kJDwvcD4nLFxuICAgICAgICAgICAgICAgIGlzUmVxdWlyZWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgY29ycmVjdEFuc3dlcjogJ3ggPSAyIGRhbiB4ID0gMycsXG4gICAgICAgICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICd4ID0gMiBkYW4geCA9IDMnLCBpc0NvcnJlY3Q6IHRydWUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAneCA9IC0yIGRhbiB4ID0gLTMnLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ3ggPSAxIGRhbiB4ID0gNicsIGlzQ29ycmVjdDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAneCA9IC0xIGRhbiB4ID0gNScsIGlzQ29ycmVjdDogZmFsc2UgfVxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdHlwZUlkOiAyLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiAnPHA+QmVyYXBha2FoIGhhc2lsIGV2YWx1YXNpIGRhcmkgaW50ZWdyYWwgdGVudHUgYmVyaWt1dD88L3A+PHA+JCRcXFxcaW50X3swfV57Mn0gM3heMiBcXFxcLCBkeCQkPC9wPicsXG4gICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiAnOCcsXG4gICAgICAgICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICc4JywgaXNDb3JyZWN0OiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJzYnLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJzEyJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICc0JywgaXNDb3JyZWN0OiBmYWxzZSB9XG4gICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0eXBlSWQ6IDIsXG4gICAgICAgICAgICAgICAgcXVlc3Rpb246ICc8cD5IaXR1bmdsYWggbmlsYWkgbGltaXQgZnVuZ3NpIHRyaWdvbm9tZXRyaSBiZXJpa3V0OjwvcD48cD4kJFxcXFxsaW1fe3ggXFxcXHRvIDB9IFxcXFxmcmFje1xcXFxzaW4oMngpfXt4fSQkPC9wPicsXG4gICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiAnMicsXG4gICAgICAgICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICcyJywgaXNDb3JyZWN0OiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJzAnLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJzEnLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1RhayBIaW5nZ2EgKFxcXFxpbmZ0eSknLCBpc0NvcnJlY3Q6IGZhbHNlIH1cbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHR5cGVJZDogMixcbiAgICAgICAgICAgICAgICBxdWVzdGlvbjogJzxwPkRpa2V0YWh1aSBzZWdpdGlnYSBzaWt1LXNpa3UgZGVuZ2FuIHBhbmphbmcgc2lzaSB0ZWdhayAkJGEgPSA2XFxcXHRleHR7IGNtfSQkIGRhbiAkJGIgPSA4XFxcXHRleHR7IGNtfSQkLiBCZXJhcGFrYWggcGFuamFuZyBzaXNpIG1pcmluZyAoJCRjJCQpIGJlcmRhc2Fya2FuIHRlb3JlbWEgUHl0aGFnb3JhcyAkJGFeMiArIGJeMiA9IGNeMiQkPzwvcD4nLFxuICAgICAgICAgICAgICAgIGlzUmVxdWlyZWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgY29ycmVjdEFuc3dlcjogJzEwIGNtJyxcbiAgICAgICAgICAgICAgICBvcHRpb25zOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJzEwIGNtJywgaXNDb3JyZWN0OiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJzEyIGNtJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICcxNCBjbScsIGlzQ29ycmVjdDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnMTUgY20nLCBpc0NvcnJlY3Q6IGZhbHNlIH1cbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9LFxuICAgIHtcbiAgICAgICAgaWQ6ICd0cGwtY29kaW5nJyxcbiAgICAgICAgdGl0bGU6ICdUZXMgS29tcGV0ZW5zaSBQZW1yb2dyYW1hbiAmIEtvZGluZycsXG4gICAgICAgIGNhdGVnb3J5OiAnS29kaW5nJyxcbiAgICAgICAgY2F0ZWdvcnlDb2xvcjogJ3RleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC82MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwJyxcbiAgICAgICAgaWNvbjogQ29kZTIsXG4gICAgICAgIHF1ZXN0aW9uQ291bnQ6IDQsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnVGVtcGxhdCB0ZXMga29kaW5nIHRlcnN0cnVrdHVyIGRlbmdhbiBibG9rIGtvZGUgYmF3YWFuIChzeW50YXggaGlnaGxpZ2h0aW5nKSwgbG9naWthIEphdmFTY3JpcHQsIHJla3Vyc2kgUHl0aG9uLCBzdHJ1a3R1ciBkYXRhIExJRk8sIGRhbiBxdWVyeSBTUUwuJyxcbiAgICAgICAgYmFubmVySW1hZ2U6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU1NTA2NjkzMS00MzY1ZDE0YmFiOGM/dz04MDAmYXV0bz1mb3JtYXQmZml0PWNyb3AmcT04MCcsXG4gICAgICAgIHNldHRpbmdzOiB7XG4gICAgICAgICAgICBzaG93U2NvcmU6IHRydWUsXG4gICAgICAgICAgICBvbmVSZXNwb25zZTogdHJ1ZSxcbiAgICAgICAgICAgIHRpbWVyRHVyYXRpb246IDI3MDAsXG4gICAgICAgICAgICBmb3JtVHlwZUlkOiAxLFxuICAgICAgICAgICAgcmFuZG9taXplUXVlc3Rpb25zOiBmYWxzZSxcbiAgICAgICAgICAgIHJlcXVpcmVkTG9naW46IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBxdWVzdGlvbnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0eXBlSWQ6IDIsXG4gICAgICAgICAgICAgICAgcXVlc3Rpb246ICc8cD5QZXJoYXRpa2FuIHBvdG9uZ2FuIGtvZGUgSmF2YVNjcmlwdCBiZXJpa3V0OjwvcD48cHJlPjxjb2RlIGNsYXNzPVwibGFuZ3VhZ2UtamF2YXNjcmlwdFwiPmNvbnN0IG51bWJlcnMgPSBbMSwgMiwgMywgNF07XFxuY29uc3QgcmVzdWx0ID0gbnVtYmVycy5tYXAobiA9PiBuICogMikuZmlsdGVyKG4gPT4gbiA+IDQpO1xcbmNvbnNvbGUubG9nKHJlc3VsdCk7PC9jb2RlPjwvcHJlPjxwPkFwYWthaCBvdXRwdXQgeWFuZyBkaWNldGFrIGtlIGNvbnNvbGU/PC9wPicsXG4gICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiAnWzYsIDhdJyxcbiAgICAgICAgICAgICAgICBvcHRpb25zOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1s2LCA4XScsIGlzQ29ycmVjdDogdHJ1ZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdbNCwgNiwgOF0nLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1syLCA0LCA2LCA4XScsIGlzQ29ycmVjdDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnWzhdJywgaXNDb3JyZWN0OiBmYWxzZSB9XG4gICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0eXBlSWQ6IDIsXG4gICAgICAgICAgICAgICAgcXVlc3Rpb246ICc8cD5QZXJoYXRpa2FuIGZ1bmdzaSByZWt1cnNpZiBQeXRob24gYmVyaWt1dDo8L3A+PHByZT48Y29kZSBjbGFzcz1cImxhbmd1YWdlLXB5dGhvblwiPmRlZiBmYWt0b3JpYWwobik6XFxuICAgIGlmIG4gPD0gMTpcXG4gICAgICAgIHJldHVybiAxXFxuICAgIHJldHVybiBuICogZmFrdG9yaWFsKG4gLSAxKVxcblxcbnByaW50KGZha3RvcmlhbCg0KSk8L2NvZGU+PC9wcmU+PHA+QmVyYXBha2FoIG5pbGFpIHlhbmcgZGloYXNpbGthbiBzYWF0IGZ1bmdzaSB0ZXJzZWJ1dCBkaWVrc2VrdXNpPzwvcD4nLFxuICAgICAgICAgICAgICAgIGlzUmVxdWlyZWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgY29ycmVjdEFuc3dlcjogJzI0JyxcbiAgICAgICAgICAgICAgICBvcHRpb25zOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJzI0JywgaXNDb3JyZWN0OiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJzEyJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICcxNicsIGlzQ29ycmVjdDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnNCcsIGlzQ29ycmVjdDogZmFsc2UgfVxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdHlwZUlkOiAyLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiAnPHA+RGFsYW0gc3RydWt0dXIgZGF0YSBwZW1yb2dyYW1hbiwgb3BlcmFzaSA8Y29kZT5wdXNoKCk8L2NvZGU+IGRhbiA8Y29kZT5wb3AoKTwvY29kZT4gcGFkYSBTdGFjayBtZW5naWt1dGkgcHJpbnNpcCBkYXNhciBhcGE/PC9wPicsXG4gICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiAnTElGTyAoTGFzdCBJbiwgRmlyc3QgT3V0KScsXG4gICAgICAgICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdMSUZPIChMYXN0IEluLCBGaXJzdCBPdXQpJywgaXNDb3JyZWN0OiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ0ZJRk8gKEZpcnN0IEluLCBGaXJzdCBPdXQpJywgaXNDb3JyZWN0OiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdMSUxPIChMYXN0IEluLCBMYXN0IE91dCknLCBpc0NvcnJlY3Q6IGZhbHNlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgb3B0aW9uVGV4dDogJ1JhbmRvbSBBY2Nlc3MnLCBpc0NvcnJlY3Q6IGZhbHNlIH1cbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHR5cGVJZDogMixcbiAgICAgICAgICAgICAgICBxdWVzdGlvbjogJzxwPlBlcmhhdGlrYW4gcXVlcnkgU1FMIGJlcmlrdXQ6PC9wPjxwcmU+PGNvZGUgY2xhc3M9XCJsYW5ndWFnZS1zcWxcIj5TRUxFQ1QgQ09VTlQoKikgRlJPTSB1c2VycyBXSEVSRSBzdGF0dXMgPSBcXCdhY3RpdmVcXCc7PC9jb2RlPjwvcHJlPjxwPkFwYSBmdW5nc2kgdXRhbWEgZGFyaSBrbGF1c2EgPGNvZGU+Q09VTlQoKik8L2NvZGU+IHRlcnNlYnV0PzwvcD4nLFxuICAgICAgICAgICAgICAgIGlzUmVxdWlyZWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgY29ycmVjdEFuc3dlcjogJ01lbmdoaXR1bmcgdG90YWwgYmFyaXMgcGVuZ2d1bmEgeWFuZyBiZXJzdGF0dXMgYWt0aWYnLFxuICAgICAgICAgICAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnTWVuZ2hpdHVuZyB0b3RhbCBiYXJpcyBwZW5nZ3VuYSB5YW5nIGJlcnN0YXR1cyBha3RpZicsIGlzQ29ycmVjdDogdHJ1ZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG9wdGlvblRleHQ6ICdNZW5nYW1iaWwgc2VsdXJ1aCBrb2xvbSB0YWJlbCB1c2VycycsIGlzQ29ycmVjdDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnTWVuanVtbGFoa2FuIG5pbGFpIGtvbG9tIHN0YXR1cycsIGlzQ29ycmVjdDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBvcHRpb25UZXh0OiAnTWVuZ2hhcHVzIGRhdGEgdXNlciB5YW5nIGFrdGlmJywgaXNDb3JyZWN0OiBmYWxzZSB9XG4gICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxuXTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVGVtcGxhdGVzUGFnZSgpIHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgW2Nsb25pbmdJZCwgc2V0Q2xvbmluZ0lkXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoJycpO1xuXG4gICAgY29uc3QgaGFuZGxlQ3JlYXRlRnJvbVRlbXBsYXRlID0gYXN5bmMgKHRlbXBsYXRlKSA9PiB7XG4gICAgICAgIGlmICghdGVtcGxhdGUpIHJldHVybjtcbiAgICAgICAgc2V0Q2xvbmluZ0lkKHRlbXBsYXRlLmlkKTtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gMS4gQnVhdCBmb3JtIGJhcnUgZGVuZ2FuIGp1ZHVsICYgZGVza3JpcHNpIHRlbXBsYXRcbiAgICAgICAgICAgIGNvbnN0IGZvcm1SZXMgPSBhd2FpdCBjcmVhdGVGb3JtKHtcbiAgICAgICAgICAgICAgICB0aXRsZTogdGVtcGxhdGUudGl0bGUsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHRlbXBsYXRlLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGlmIChmb3JtUmVzLnN0YXR1cyA9PT0gNDAxKSB7XG4gICAgICAgICAgICAgICAgY2xlYXJTZXNzaW9uKCk7XG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoJy9sb2dpbicpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGZvcm1SZXMub2sgJiYgZm9ybVJlcy5kYXRhPy5pZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1JZCA9IGZvcm1SZXMuZGF0YS5pZDtcblxuICAgICAgICAgICAgICAgIC8vIDIuIFNpbXBhbiBwZW5nYXR1cmFuIHRlbXBsYXQgamlrYSB0ZXJzZWRpYVxuICAgICAgICAgICAgICAgIGlmICh0ZW1wbGF0ZS5zZXR0aW5ncykge1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCB1cGRhdGVGb3JtU2V0dGluZ3MoZm9ybUlkLCB0ZW1wbGF0ZS5zZXR0aW5ncyk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLy8gMy4gU2ltcGFuIHNlbHVydWggc29hbCB0ZW1wbGF0IGJlc2VydGEga3VuY2kgamF3YWJhbiAmIG9wc2lcbiAgICAgICAgICAgICAgICBpZiAodGVtcGxhdGUucXVlc3Rpb25zPy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZFF1ZXN0aW9ucyA9IHRlbXBsYXRlLnF1ZXN0aW9ucy5tYXAoKHEsIGlkeCkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGVJZDogcS50eXBlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbjogcS5xdWVzdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uRm9ybWF0OiAnaHRtbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbk9yZGVyOiBpZHggKyAxLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogISFxLmlzUmVxdWlyZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiBxLmNvcnJlY3RBbnN3ZXIgfHwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IChxLm9wdGlvbnMgfHwgW10pLm1hcCgobywgb2kpID0+ICh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uVGV4dDogby5vcHRpb25UZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdDogISFvLmlzQ29ycmVjdCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25PcmRlcjogb2kgKyAxLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgc2F2ZVF1ZXN0aW9ucyhmb3JtSWQsIGZvcm1hdHRlZFF1ZXN0aW9ucyk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLy8gNC4gTGFuZ3N1bmcgbmF2aWdhc2kga2UgRm9ybSBCdWlsZGVyIGRlbmdhbiBkYXRhIHRlcmlzaSB1dHVoXG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoYC9mb3Jtcy8ke2Zvcm1JZH0vZWRpdGApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZSgnL2NyZWF0ZS1mb3JtJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgdXNpbmcgdGVtcGxhdGU6JywgZXJyKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKCcvY3JlYXRlLWZvcm0nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldENsb25pbmdJZChudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBmaWx0ZXJlZFRlbXBsYXRlcyA9IFRFTVBMQVRFUy5maWx0ZXIoKHRwbCkgPT4ge1xuICAgICAgICBpZiAoIXNlYXJjaFF1ZXJ5LnRyaW0oKSkgcmV0dXJuIHRydWU7XG4gICAgICAgIGNvbnN0IHEgPSBzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgdHBsLnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHxcbiAgICAgICAgICAgIHRwbC5kZXNjcmlwdGlvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpIHx8XG4gICAgICAgICAgICB0cGwuY2F0ZWdvcnkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKVxuICAgICAgICApO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctWyNGNEY4RjddIGRhcms6Ymctc2xhdGUtOTUwIGZvbnQtc2FucyBhbnRpYWxpYXNlZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICA8U2lkZWJhciAvPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGZsZXgtY29sIG1pbi13LTAgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIHctZnVsbCBwLTQgc206cC02IGxnOnAtOCBzcGFjZS15LTZcIj5cblxuICAgICAgICAgICAgICAgICAgICA8VG9wYmFyIFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoUXVlcnk9e3NlYXJjaFF1ZXJ5fSBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2hhbmdlPXtzZXRTZWFyY2hRdWVyeX0gXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNhcmkgdGVtcGxhdCBhdGF1IGthdGVnb3JpLi4uXCIgXG4gICAgICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+R2FsZXJpIFRlbXBsYXQgUGlsaWhhbjwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW0gbXQtMSBtYXgtdy14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBpbGloIHRlbXBsYXQgcHJvZmVzaW9uYWwgeWFuZyBsYW5nc3VuZyB0ZXJpc2kgcGVydGFueWFhbiwga3VuY2kgamF3YWJhbiwgZGFuIHBlbmdhdHVyYW4gYmF3YWFuLlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cblxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkVGVtcGxhdGVzLm1hcCgodHBsKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgSWNvbkNvbXBvbmVudCA9IHRwbC5pY29uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQ2xvbmluZyA9IGNsb25pbmdJZCA9PT0gdHBsLmlkO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3RwbC5pZH0gY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZmxleCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC00NCB3LWZ1bGwgcmVsYXRpdmUgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIG92ZXJmbG93LWhpZGRlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXt0cGwuYmFubmVySW1hZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17dHBsLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlciBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1saW5lYXItdG8tdCBmcm9tLWJsYWNrLzYwIHZpYS10cmFuc3BhcmVudCB0by10cmFuc3BhcmVudFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMyBsZWZ0LTQgcmlnaHQtNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBzaGFkb3cteHMgYmFja2Ryb3AtYmx1ci1tZCAke3RwbC5jYXRlZ29yeUNvbG9yfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RwbC5jYXRlZ29yeX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZHJvcC1zaGFkb3ctbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxIZWxwQ2lyY2xlIHNpemU9ezE0fSAvPiB7dHBsLnF1ZXN0aW9uQ291bnR9IFNvYWwgTGVuZ2thcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgZmxleC0xIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQ29tcG9uZW50IHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBsaW5lLWNsYW1wLTEgZ3JvdXAtaG92ZXI6dGV4dC1bIzAwODk3Ql0gZGFyazpncm91cC1ob3Zlcjp0ZXh0LXRlYWwtNDAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RwbC50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW0gbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHBsLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ3JlYXRlRnJvbVRlbXBsYXRlKHRwbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNDbG9uaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgcHgtNCBiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIGFjdGl2ZTpzY2FsZS1bMC45OV0gZGFyazpiZy10ZWFsLTYwMCBkYXJrOmhvdmVyOmJnLXRlYWwtNzAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcm91bmRlZC0yeGwgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZGlzYWJsZWQ6b3BhY2l0eS02MCBjdXJzb3ItcG9pbnRlciBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNDbG9uaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIHNpemU9ezE1fSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NZW55aWFwa2FuIEZvcm11bGlyICYgU29hbC4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+R3VuYWthbiBUZW1wbGF0IEluaTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFycm93UmlnaHQgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkVGVtcGxhdGVzLmxlbmd0aCA9PT0gMCAmJiBzZWFyY2hRdWVyeSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTE2IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpZGFrIGFkYSB0ZW1wbGF0IHlhbmcgY29jb2sgZGVuZ2FuIHBlbmNhcmlhbiBcIntzZWFyY2hRdWVyeX1cIi5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPC9tYWluPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59Il19