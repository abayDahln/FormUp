import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/landing/LandingPage.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import gsap from "/node_modules/.vite/deps/gsap.js?v=e41adea3";
import { ScrollTrigger } from "/node_modules/.vite/deps/gsap_ScrollTrigger.js?v=eff444cb";
import Lenis from "/node_modules/.vite/deps/@studio-freight_lenis.js?v=b5faa77f";
import { ArrowUpRight, Smartphone, Check, ChevronDown, Layers, BarChart2, QrCode, Globe, Download, Plus } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import { isAuthenticated } from "/src/services/apiService.js";
import logo from "/src/assets/logo.png?import";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/landing/LandingPage.jsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
gsap.registerPlugin(ScrollTrigger);
ScrollTrigger.config({ ignoreMobileResize: true });
/* ─────────────────────────────────────────────
PALET — krem hangat + hijau (warna app)
───────────────────────────────────────────── */
const CREAM = "#F6F4ED";
const INK = "#1C2620";
const GREEN = "#157A4E";
const GREEN_DEEP = "#0E5A3A";
const DARK = "#0D1F17";
const TINT = "#ECEFE4";
const LIGHT = "#5BC98C";
/* ─────────────────────────────────────────────
DATA
───────────────────────────────────────────── */
const RITUAL_LINES = [
	"Buka laptop, tunggu loading.",
	"Rancang formulir dari nol.",
	"Tempel link ke tiap grup chat.",
	"Susun nilai manual di spreadsheet.",
	"Ulangi semuanya besok pagi."
];
const WORKFLOW = [
	{
		num: "01",
		title: "Rancang",
		desc: "Pilihan ganda, essay, atau skala penilaian — lengkap dengan bobot nilai per soal."
	},
	{
		num: "02",
		title: "Atur",
		desc: "Batas waktu, acak urutan soal, dan batasi satu kali pengisian per responden."
	},
	{
		num: "03",
		title: "Bagikan",
		desc: "Link pendek dan QR code siap ditampilkan di proyektor, papan tulis, atau story."
	},
	{
		num: "04",
		title: "Pantau",
		desc: "Rekap nilai dan grafik jawaban terhitung otomatis. Ekspor ke CSV / XLSX satu klik."
	}
];
const BEATS = [
	{
		num: "01",
		screen: "build",
		title: "Rancang",
		desc: "Susun kuis atau survei lewat builder yang ringan — tersedia di web dan aplikasi Android."
	},
	{
		num: "02",
		screen: "share",
		title: "Bagikan",
		desc: "Satu link, satu QR code. Peserta mengisi lewat browser tanpa perlu memasang apa pun."
	},
	{
		num: "03",
		screen: "track",
		title: "Pantau",
		desc: "Respons masuk real-time. Nilai dan grafik terhitung otomatis, siap diekspor kapan pun."
	}
];
const FEATURES = [
	{
		icon: Layers,
		title: "Form builder yang ringan",
		desc: "Antarmuka bersih, tanpa iklan, nyaman dipakai di layar kecil maupun besar."
	},
	{
		icon: BarChart2,
		title: "Hasil terhitung otomatis",
		desc: "Grafik jawaban dan rekap nilai langsung jadi. Tidak ada rumus spreadsheet manual."
	},
	{
		icon: QrCode,
		title: "QR code bawaan",
		desc: "Peserta pindai, langsung mengisi. Tidak perlu mengetik alamat apa pun."
	}
];
const MANIFESTO = "Ide untuk kuis atau survei bisa muncul kapan saja — di kelas, di perjalanan, di sela rapat. FormUp membuat satu akunmu cukup: rancang di web, bagikan dan pantau dari mana saja. Data tidak perlu menunggu kamu duduk di depan laptop.";
const FAQS = [
	{
		q: "Apakah FormUp gratis?",
		a: "Ya. Membuat formulir, membagikan, dan mengumpulkan respons tidak dikenakan biaya."
	},
	{
		q: "Bagaimana sinkronisasi web dan mobile?",
		a: "Satu akun untuk keduanya. Formulir yang dibuat di web langsung muncul di aplikasi Android, dan sebaliknya."
	},
	{
		q: "Ada batas jumlah respons?",
		a: "Tidak ada. Kumpulkan respons sebanyak apa pun dari siswa, peserta, atau responden survei."
	},
	{
		q: "Bisakah hasil diekspor?",
		a: "Bisa. Rekapitulasi dapat diekspor ke CSV dan XLSX dari halaman respons."
	}
];
const APK_URL = "https://github.com/abayDahln/FormUp/releases/download/v1.0.0/formup-android.apk";
const EXE_URL = "https://github.com/abayDahln/FormUp/releases/download/v1.0.0/formup-windows-installer.exe";
/* ─────────────────────────────────────────────
MAGNETIC
───────────────────────────────────────────── */
function Magnetic({ children, className = "", strength = .35 }) {
	_s();
	const ref = useRef(null);
	const xTo = useRef(null);
	const yTo = useRef(null);
	useEffect(() => {
		xTo.current = gsap.quickTo(ref.current, "x", {
			duration: .5,
			ease: "power3.out"
		});
		yTo.current = gsap.quickTo(ref.current, "y", {
			duration: .5,
			ease: "power3.out"
		});
	}, []);
	const onMove = useCallback((e) => {
		const rect = ref.current.getBoundingClientRect();
		xTo.current((e.clientX - (rect.left + rect.width / 2)) * strength);
		yTo.current((e.clientY - (rect.top + rect.height / 2)) * strength);
	}, [strength]);
	const onLeave = useCallback(() => {
		xTo.current(0);
		yTo.current(0);
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		ref,
		onMouseMove: onMove,
		onMouseLeave: onLeave,
		className: `inline-block ${className}`,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 105,
		columnNumber: 5
	}, this);
}
_s(Magnetic, "LPGPGZARccCxWtm42hTEAVArbRE=");
_c = Magnetic;
/* ─────────────────────────────────────────────
STAT — count-up mandiri via IntersectionObserver
───────────────────────────────────────────── */
function Stat({ value, suffix, label }) {
	_s2();
	const [n, setN] = useState(value);
	const started = useRef(false);
	const ref = useRef(null);
	useEffect(() => {
		const el = ref.current;
		const io = new IntersectionObserver(([e]) => {
			if (!e.isIntersecting || started.current) return;
			started.current = true;
			io.disconnect();
			const start = performance.now();
			const dur = 1400;
			const tick = (t) => {
				const p = Math.min(1, (t - start) / dur);
				setN(Math.round(value * (1 - Math.pow(1 - p, 3))));
				if (p < 1) requestAnimationFrame(tick);
			};
			requestAnimationFrame(tick);
		}, { threshold: .4 });
		io.observe(el);
		return () => io.disconnect();
	}, [value]);
	return /* @__PURE__ */ _jsxDEV("div", {
		ref,
		children: [/* @__PURE__ */ _jsxDEV("p", {
			className: "text-5xl md:text-6xl font-extrabold tracking-tight",
			style: { color: INK },
			children: [n, /* @__PURE__ */ _jsxDEV("span", {
				style: { color: GREEN },
				children: suffix
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 141,
				columnNumber: 12
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 140,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			className: "text-sm mt-3 leading-relaxed",
			style: { color: `${INK}80` },
			children: label
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 143,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 139,
		columnNumber: 5
	}, this);
}
_s2(Stat, "GQLAshQxyp/FTCUi9aQAbzmcUEA=");
_c2 = Stat;
/* ─────────────────────────────────────────────
LAYAR PONSEL CERITA (build / share / track)
───────────────────────────────────────────── */
function StoryPhone({ screen }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative w-[250px]",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "absolute -bottom-8 left-1/2 -translate-x-1/2 w-48 h-7 rounded-full blur-2xl",
			style: { backgroundColor: `${GREEN}40` }
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 154,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative rounded-[40px] p-2.5 border border-white/25",
			style: {
				background: "linear-gradient(180deg, #2E3B33 0%, #141D18 100%)",
				boxShadow: "0 36px 80px -22px rgba(13,31,23,0.55)"
			},
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-[32px] p-5 aspect-[9/18] flex flex-col gap-4 text-left overflow-hidden",
				style: { backgroundColor: "#0D1512" },
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-20 h-4 rounded-full mx-auto flex items-center justify-end px-2",
						style: { backgroundColor: "#16211B" },
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "w-1.5 h-1.5 rounded-full",
							style: { backgroundColor: `${LIGHT}CC` }
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 11
					}, this),
					screen === "build" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold text-white",
							children: "Formulir baru"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[10px] mt-0.5",
							style: { color: "#5BC98C" },
							children: "Draf tersimpan otomatis"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 170,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-xl p-3 space-y-2",
							style: {
								backgroundColor: "rgba(255,255,255,0.04)",
								border: "1px solid rgba(255,255,255,0.07)"
							},
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "h-2 w-3/4 rounded-full",
									style: { backgroundColor: "rgba(255,255,255,0.18)" }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 175,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "h-6 rounded-md flex items-center px-2 text-[9px] text-stone-400",
									style: { backgroundColor: "rgba(255,255,255,0.06)" },
									children: "Pilihan ganda"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "h-6 rounded-md flex items-center px-2 text-[9px] text-stone-400",
									style: { backgroundColor: "rgba(255,255,255,0.06)" },
									children: "Essay"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 179,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-xl px-3 py-2.5 flex items-center justify-center gap-1.5 text-[10px] font-bold text-white",
							style: { backgroundColor: GREEN },
							children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 11 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 17
							}, this), " Tambah pertanyaan"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 13
					}, this),
					screen === "share" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold text-white",
							children: "Ujian Harian Fisika"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[10px] mt-0.5 text-stone-400",
							children: "Siap dibagikan"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 194,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-xl p-4 flex flex-col items-center gap-3",
							style: {
								backgroundColor: "rgba(255,255,255,0.04)",
								border: "1px solid rgba(255,255,255,0.07)"
							},
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-24 h-24 rounded-xl flex items-center justify-center",
								style: { backgroundColor: "#F6F4ED" },
								children: /* @__PURE__ */ _jsxDEV(QrCode, {
									size: 64,
									style: { color: INK }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 200,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[10px] font-semibold",
								style: { color: LIGHT },
								children: "formup.app/f/8x2k"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-xl px-3 py-2 flex items-center justify-between",
							style: {
								backgroundColor: `${GREEN}1F`,
								border: `1px solid ${GREEN}40`
							},
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-medium",
								style: { color: LIGHT },
								children: "Siap dipindai"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(Check, {
								size: 13,
								style: { color: LIGHT }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 13
					}, this),
					screen === "track" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold text-white",
							children: "Rekap respons"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[10px] mt-0.5",
							style: { color: LIGHT },
							children: "128 dari 140 sudah mengisi"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 216,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-xl p-4 space-y-2.5",
							style: {
								backgroundColor: "rgba(255,255,255,0.04)",
								border: "1px solid rgba(255,255,255,0.07)"
							},
							children: [
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-stone-400",
									children: "Persebaran nilai"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 220,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-end gap-1.5 h-20",
									children: [
										35,
										55,
										80,
										100,
										70,
										45
									].map((h, i) => /* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 rounded-t-sm",
										style: {
											height: `${h}%`,
											backgroundColor: i === 3 ? LIGHT : GREEN
										}
									}, i, false, {
										fileName: _jsxFileName,
										lineNumber: 223,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 221,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between text-[8px] text-stone-500",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 227,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "50" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 227,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "100" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 227,
											columnNumber: 48
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-xl px-3 py-2 flex items-center justify-between",
							style: {
								backgroundColor: `${GREEN}1F`,
								border: `1px solid ${GREEN}40`
							},
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-medium",
								style: { color: LIGHT },
								children: "Ekspor CSV / XLSX"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(Download, {
								size: 12,
								style: { color: LIGHT }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 233,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 230,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 213,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-auto pt-3 flex items-center justify-between text-[10px] text-stone-500",
						style: { borderTop: "1px solid rgba(255,255,255,0.07)" },
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "formup.app" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 240,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							style: { color: LIGHT },
							children: "Terhubung"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 238,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 161,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 156,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 153,
		columnNumber: 5
	}, this);
}
_c3 = StoryPhone;
/* ─────────────────────────────────────────────
MAIN
───────────────────────────────────────────── */
export default function LandingPage() {
	_s3();
	const navigate = useNavigate();
	const [scrolled, setScrolled] = useState(false);
	const [openFaq, setOpenFaq] = useState(null);
	const [preset, setPreset] = useState("quiz");
	const [beat, setBeat] = useState(0);
	const [screen, setScreen] = useState("build");
	const containerRef = useRef(null);
	const phoneIntroRef = useRef(null);
	const phoneFloatRef = useRef(null);
	const phoneFallRef = useRef(null);
	const phoneTiltRef = useRef(null);
	const glareRef = useRef(null);
	const rotXTo = useRef(null);
	const rotYTo = useRef(null);
	useEffect(() => {
		if (isAuthenticated()) navigate("/dashboard", { replace: true });
	}, [navigate]);
	/* ── TILT 3D hero ── */
	useEffect(() => {
		if (!phoneTiltRef.current) return;
		rotXTo.current = gsap.quickTo(phoneTiltRef.current, "rotationX", {
			duration: .6,
			ease: "power3.out"
		});
		rotYTo.current = gsap.quickTo(phoneTiltRef.current, "rotationY", {
			duration: .6,
			ease: "power3.out"
		});
	}, []);
	const handleMouseMove = useCallback((e) => {
		const rect = e.currentTarget.getBoundingClientRect();
		const px = (e.clientX - rect.left) / rect.width;
		const py = (e.clientY - rect.top) / rect.height;
		rotXTo.current?.((py - .5) * -18);
		rotYTo.current?.((px - .5) * 22);
		if (glareRef.current) {
			glareRef.current.style.background = `radial-gradient(circle at ${px * 100}% ${py * 100}%, rgba(255,255,255,0.4) 0%, transparent 55%)`;
		}
	}, []);
	const handleMouseLeave = useCallback(() => {
		rotXTo.current?.(0);
		rotYTo.current?.(0);
		if (glareRef.current) {
			glareRef.current.style.background = "radial-gradient(circle at 50% 20%, rgba(255,255,255,0.18) 0%, transparent 55%)";
		}
	}, []);
	/* ── LENIS + GSAP ── */
	useEffect(() => {
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		let lenis = null;
		if (!reduced) {
			lenis = new Lenis({
				duration: 1.15,
				smoothWheel: true
			});
			lenis.on("scroll", ScrollTrigger.update);
		}
		const raf = (time) => lenis?.raf(time * 1e3);
		gsap.ticker.add(raf);
		gsap.ticker.lagSmoothing(0);
		const onScroll = () => setScrolled(window.scrollY > 24);
		window.addEventListener("scroll", onScroll, { passive: true });
		const mm = gsap.matchMedia();
		const ctx = gsap.context(() => {
			/* ── progress bar halaman ── */
			gsap.to("#page-progress", {
				scaleX: 1,
				ease: "none",
				scrollTrigger: {
					trigger: document.body,
					start: "top top",
					end: "bottom bottom",
					scrub: .3
				}
			});
			/* ── HERO ENTRANCE (time-based, pasti jalan) ── */
			gsap.timeline({ defaults: { ease: "power4.out" } }).fromTo(".nav-item", {
				y: -18,
				opacity: 0
			}, {
				y: 0,
				opacity: 1,
				stagger: .08,
				duration: .8
			}, .1).fromTo(".hero-kicker", {
				y: 16,
				opacity: 0
			}, {
				y: 0,
				opacity: 1,
				duration: .8
			}, .25).fromTo(".hero-line", { yPercent: 110 }, {
				yPercent: 0,
				stagger: .12,
				duration: 1.1
			}, .3).fromTo(".hero-sub", {
				y: 20,
				opacity: 0
			}, {
				y: 0,
				opacity: 1,
				duration: .8
			}, .7).fromTo(".hero-cta", {
				y: 16,
				opacity: 0
			}, {
				y: 0,
				opacity: 1,
				stagger: .1,
				duration: .7
			}, .85).fromTo(".hero-meta", { opacity: 0 }, {
				opacity: 1,
				duration: .9
			}, 1).fromTo(phoneIntroRef.current, {
				y: 80,
				opacity: 0,
				scale: .94
			}, {
				y: 0,
				opacity: 1,
				scale: 1,
				duration: 1.3,
				ease: "power3.out"
			}, .45);
			/* levitasi */
			gsap.to(phoneFloatRef.current, {
				y: -12,
				duration: 3.2,
				repeat: -1,
				yoyo: true,
				ease: "sine.inOut"
			});
			/* hp "jatuh" keluar hero — scrub di wrapper terluar, tween tunggal */
			gsap.to(phoneFallRef.current, {
				y: 340,
				rotate: -14,
				opacity: 0,
				ease: "none",
				scrollTrigger: {
					trigger: "#hero",
					start: "top top",
					end: "bottom top",
					scrub: 1
				}
			});
			/* ── RITUAL — stacked pinning (konten nyata, anti blank) ── */
			mm.add("(min-width: 768px)", () => {
				gsap.utils.toArray(".ritual-panel").forEach((panel) => {
					gsap.from(panel.querySelector(".ritual-inner"), {
						y: 70,
						opacity: 0,
						duration: 1,
						ease: "power3.out",
						scrollTrigger: {
							trigger: panel,
							start: "top 62%",
							toggleActions: "play none none reverse"
						}
					});
					ScrollTrigger.create({
						trigger: panel,
						start: "top top",
						pin: true,
						pinSpacing: false
					});
				});
			});
			mm.add("(max-width: 767px)", () => {
				gsap.utils.toArray(".m-reveal").forEach((el) => {
					gsap.from(el, {
						y: 36,
						opacity: 0,
						duration: .9,
						ease: "power3.out",
						scrollTrigger: {
							trigger: el,
							start: "top 88%",
							once: true
						}
					});
				});
			});
			/* ── MANIFESTO — kata menyala ── */
			gsap.fromTo(".mword", { opacity: .15 }, {
				opacity: 1,
				stagger: .05,
				ease: "none",
				scrollTrigger: {
					trigger: "#manifesto",
					start: "top 78%",
					end: "bottom 65%",
					scrub: 1,
					invalidateOnRefresh: true
				}
			});
			/* ── ALUR — GSAP PIN (bukan CSS sticky, fixes overflow-x bug).
			Track mulai dari posisi natural → walau tween gagal, kartu pertama tetap terlihat. ── */
			mm.add("(min-width: 768px)", () => {
				const track = document.querySelector(".wf-track");
				const dist = () => Math.max(0, track.scrollWidth - window.innerWidth + 60);
				gsap.to(track, {
					x: () => -dist(),
					ease: "none",
					scrollTrigger: {
						trigger: "#alur",
						start: "top top",
						end: () => "+=" + dist(),
						scrub: 1,
						pin: true,
						anticipatePin: 1,
						invalidateOnRefresh: true
					}
				});
				gsap.fromTo(".wf-progress", { scaleX: 0 }, {
					scaleX: 1,
					ease: "none",
					scrollTrigger: {
						trigger: "#alur",
						start: "top top",
						end: () => "+=" + dist(),
						scrub: 1,
						invalidateOnRefresh: true
					}
				});
			});
			/* ── CERITA — ponsel menemani scroll 2,5 layar.
			Beat pakai toggleClass (CSS transition) → tidak ada konten yang
			nyangkut hidden walau pengukuran meleset. ── */
			mm.add("(min-width: 768px)", () => {
				ScrollTrigger.create({
					trigger: "#cerita",
					start: "top top",
					end: "+=250%",
					pin: ".cerita-stage",
					anticipatePin: 1
				});
				const beats = gsap.utils.toArray(".beat");
				const step = () => window.innerHeight * .8;
				beats.forEach((b, i) => {
					ScrollTrigger.create({
						trigger: "#cerita",
						start: () => "top+=" + i * step() + " top",
						end: () => "top+=" + (i + 1) * step() + " top",
						onToggle: (self) => {
							if (!self.isActive) return;
							beats.forEach((x) => x.classList.remove("beat-active"));
							b.classList.add("beat-active");
							setBeat(i);
							setScreen(BEATS[i].screen);
						}
					});
				});
				/* gerak ponsel: melayang → jatuh keluar di akhir */
				gsap.timeline({ scrollTrigger: {
					trigger: "#cerita",
					start: "top top",
					end: "+=250%",
					scrub: 1
				} }).fromTo(".cerita-phone", {
					y: 90,
					rotate: 5
				}, {
					y: -30,
					rotate: -4,
					ease: "none",
					duration: 3
				}).to(".cerita-phone", {
					y: 320,
					rotate: 16,
					opacity: 0,
					ease: "power1.in",
					duration: 1
				});
			});
			/* ── FITUR ── */
			gsap.from(".feature-card", {
				y: 56,
				opacity: 0,
				duration: .9,
				stagger: .12,
				ease: "power3.out",
				scrollTrigger: {
					trigger: "#fitur",
					start: "top 78%",
					once: true
				}
			});
			/* ── TRIO FAN-OUT 3D (play-once) ── */
			const trioTl = gsap.timeline({
				scrollTrigger: {
					trigger: "#trio",
					start: "top 85%",
					once: true
				},
				defaults: {
					duration: 1.1,
					ease: "power3.out"
				}
			});
			trioTl.fromTo(".trio-left", {
				x: 90,
				rotateY: 0,
				rotateZ: 0,
				scale: .72,
				opacity: 0
			}, {
				x: 0,
				rotateY: 22,
				rotateZ: -8,
				scale: .9,
				opacity: 1
			}, 0).fromTo(".trio-right", {
				x: -90,
				rotateY: 0,
				rotateZ: 0,
				scale: .72,
				opacity: 0
			}, {
				x: 0,
				rotateY: -22,
				rotateZ: 8,
				scale: .9,
				opacity: 1
			}, 0).fromTo(".trio-center", {
				scale: .88,
				y: 36
			}, {
				scale: 1.04,
				y: -6
			}, 0);
			/* ── FAQ ── */
			gsap.from(".faq-card", {
				y: 28,
				opacity: 0,
				duration: .7,
				stagger: .08,
				ease: "power2.out",
				scrollTrigger: {
					trigger: "#faq",
					start: "top 82%",
					once: true
				}
			});
		}, containerRef);
		/* refresh setelah font, gambar, dan layout stabil */
		if (document.fonts?.ready) document.fonts.ready.then(() => ScrollTrigger.refresh());
		const onLoad = () => ScrollTrigger.refresh();
		window.addEventListener("load", onLoad);
		const t = setTimeout(() => ScrollTrigger.refresh(), 600);
		return () => {
			clearTimeout(t);
			ctx.revert();
			mm.revert();
			gsap.ticker.remove(raf);
			lenis?.destroy();
			window.removeEventListener("scroll", onScroll);
			window.removeEventListener("load", onLoad);
		};
	}, []);
	const setActiveBeat = (i) => {
		setBeat(i);
		setScreen(BEATS[i].screen);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		ref: containerRef,
		className: "min-h-screen overflow-x-clip antialiased",
		style: {
			backgroundColor: CREAM,
			color: INK,
			fontFamily: "'Inter', system-ui, sans-serif"
		},
		children: [
			/* @__PURE__ */ _jsxDEV("style", { children: `
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Instrument+Serif:ital@0;1&display=swap');
        .font-serifit { font-family: 'Instrument Serif', Georgia, serif; }

        @keyframes blink { 50% { opacity: .2 } }
        .blink { animation: blink 1.6s ease-in-out infinite; }

        /* beat cerita — desktop: tumpukan absolut; mobile: alur normal */
        @media (min-width: 768px) {
          .beat {
            position: absolute; inset: 0;
            display: flex; flex-direction: column; justify-content: center;
            opacity: 0; transform: translateY(28px);
            transition: opacity .55s ease, transform .55s ease;
            pointer-events: none;
          }
          .beat-active { opacity: 1 !important; transform: none !important; pointer-events: auto; }
        }
        @media (prefers-reduced-motion: reduce) {
          .blink { animation: none !important; }
          .beat { transition: none !important; }
        }
      ` }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 480,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				id: "page-progress",
				className: "fixed top-0 left-0 right-0 h-[3px] origin-left scale-x-0 z-[60]",
				style: { backgroundColor: GREEN }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 504,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("nav", {
				className: `fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 ${scrolled ? "backdrop-blur-md border-b py-3" : "bg-transparent py-5"}`,
				style: scrolled ? {
					backgroundColor: `${CREAM}D9`,
					borderColor: `${INK}1A`
				} : {},
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-6xl mx-auto flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						className: "nav-item flex items-center gap-2.5",
						children: [/* @__PURE__ */ _jsxDEV("img", {
							src: logo,
							alt: "FormUp",
							className: "w-8 h-8 object-contain"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 513,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-lg font-bold tracking-tight",
							children: ["Form", /* @__PURE__ */ _jsxDEV("span", {
								style: { color: GREEN },
								children: "Up"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 514,
								columnNumber: 68
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 514,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 512,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 sm:gap-4",
						children: [/* @__PURE__ */ _jsxDEV(Link, {
							to: "/login",
							className: "nav-item px-3 py-2 text-sm font-medium transition-colors",
							style: { color: `${INK}99` },
							children: "Masuk"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 517,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(Magnetic, { children: /* @__PURE__ */ _jsxDEV(Link, {
							to: "/register",
							className: "nav-item px-5 py-2.5 text-sm font-semibold text-[#F6F4ED] rounded-full transition-colors duration-300",
							style: { backgroundColor: INK },
							onMouseEnter: (e) => e.currentTarget.style.backgroundColor = GREEN,
							onMouseLeave: (e) => e.currentTarget.style.backgroundColor = INK,
							children: "Daftar gratis"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 522,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 521,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 516,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 511,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 508,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "hero",
				className: "relative px-6 pt-36 pb-24 lg:pt-40 overflow-hidden",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-6xl mx-auto grid lg:grid-cols-[1.1fr_0.9fr] gap-16 items-center",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "hero-kicker text-xs font-bold tracking-[0.18em] uppercase mb-7 flex items-center gap-2.5",
							style: { color: GREEN },
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "w-1.5 h-1.5 rounded-full",
								style: { backgroundColor: GREEN }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 541,
								columnNumber: 15
							}, this), "Form builder untuk web & mobile"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 539,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-5xl sm:text-7xl lg:text-[5.4rem] font-extrabold tracking-[-0.03em] leading-[1.02]",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "block overflow-hidden pb-1",
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: "hero-line block",
									children: "Buat formulir,"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 545,
									columnNumber: 60
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 545,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "block overflow-hidden pb-2",
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: "hero-line block",
									children: /* @__PURE__ */ _jsxDEV("span", {
										className: "font-serifit italic font-normal",
										style: { color: GREEN },
										children: "dari mana saja."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 548,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 547,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 546,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 544,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "hero-sub text-base max-w-md leading-relaxed mt-7",
							style: { color: `${INK}99` },
							children: "Kuis, survei, dan pantauan nilai dalam hitungan menit. Rancang di browser, bagikan lewat link atau QR, pantau hasilnya langsung."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 552,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row items-start gap-3.5 mt-9",
							children: [
								/* @__PURE__ */ _jsxDEV(Magnetic, {
									className: "hero-cta w-full sm:w-auto",
									children: /* @__PURE__ */ _jsxDEV("a", {
										href: APK_URL,
										download: "formup-android.apk",
										target: "_blank",
										rel: "noopener noreferrer",
										className: "w-full sm:w-auto px-7 py-3.5 text-[#F6F4ED] text-sm font-semibold rounded-full transition-colors duration-300 flex items-center justify-center gap-2",
										style: { backgroundColor: GREEN },
										onMouseEnter: (e) => e.currentTarget.style.backgroundColor = GREEN_DEEP,
										onMouseLeave: (e) => e.currentTarget.style.backgroundColor = GREEN,
										children: [
											/* @__PURE__ */ _jsxDEV(Smartphone, { size: 16 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 565,
												columnNumber: 19
											}, this),
											" Unduh APK (Android) ",
											/* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 15 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 565,
												columnNumber: 64
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 559,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 558,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Magnetic, {
									className: "hero-cta w-full sm:w-auto",
									children: /* @__PURE__ */ _jsxDEV("a", {
										href: EXE_URL,
										download: "formup-windows-installer.exe",
										target: "_blank",
										rel: "noopener noreferrer",
										className: "w-full sm:w-auto px-7 py-3.5 text-[#F6F4ED] text-sm font-semibold rounded-full transition-colors duration-300 flex items-center justify-center gap-2",
										style: { backgroundColor: INK },
										onMouseEnter: (e) => e.currentTarget.style.backgroundColor = DARK,
										onMouseLeave: (e) => e.currentTarget.style.backgroundColor = INK,
										children: [
											/* @__PURE__ */ _jsxDEV(Download, { size: 16 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 576,
												columnNumber: 19
											}, this),
											" Unduh Installer (Windows) ",
											/* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 15 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 576,
												columnNumber: 68
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 570,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 569,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Magnetic, {
									className: "hero-cta w-full sm:w-auto",
									strength: .25,
									children: /* @__PURE__ */ _jsxDEV(Link, {
										to: "/login",
										className: "w-full sm:w-auto px-7 py-3.5 text-sm font-semibold rounded-full border transition-all flex items-center justify-center gap-2",
										style: {
											borderColor: `${INK}33`,
											color: INK
										},
										onMouseEnter: (e) => {
											e.currentTarget.style.borderColor = `${INK}80`;
											e.currentTarget.style.backgroundColor = `${INK}0D`;
										},
										onMouseLeave: (e) => {
											e.currentTarget.style.borderColor = `${INK}33`;
											e.currentTarget.style.backgroundColor = "transparent";
										},
										children: [/* @__PURE__ */ _jsxDEV(Globe, {
											size: 16,
											style: { color: `${INK}80` }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 587,
											columnNumber: 19
										}, this), " Buka di browser"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 581,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 580,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 556,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "hero-meta text-sm mt-9 font-medium",
							style: { color: `${INK}66` },
							children: [
								"Gratis tanpa batas respons",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "mx-2.5",
									style: { color: GREEN },
									children: "•"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 593,
									columnNumber: 15
								}, this),
								"Sinkron web & mobile",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "mx-2.5",
									style: { color: GREEN },
									children: "•"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 595,
									columnNumber: 15
								}, this),
								"QR code bawaan"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 591,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 538,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-center lg:justify-end",
						style: { perspective: "1400px" },
						children: /* @__PURE__ */ _jsxDEV("div", {
							ref: phoneFallRef,
							children: /* @__PURE__ */ _jsxDEV("div", {
								ref: phoneIntroRef,
								children: /* @__PURE__ */ _jsxDEV("div", {
									ref: phoneFloatRef,
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "relative w-[270px]",
										onMouseMove: handleMouseMove,
										onMouseLeave: handleMouseLeave,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute -bottom-8 left-1/2 -translate-x-1/2 w-52 h-7 rounded-full blur-2xl",
											style: { backgroundColor: `${GREEN}40` }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 606,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											ref: phoneTiltRef,
											className: "relative rounded-[44px] p-2.5 border border-white/25",
											style: {
												transformStyle: "preserve-3d",
												background: "linear-gradient(180deg, #33413A 0%, #17211C 100%)",
												boxShadow: "0 36px 80px -22px rgba(28,38,32,0.55)"
											},
											children: [/* @__PURE__ */ _jsxDEV("div", {
												ref: glareRef,
												className: "absolute inset-0 rounded-[42px] pointer-events-none opacity-60 mix-blend-overlay",
												style: { background: "radial-gradient(circle at 50% 20%, rgba(255,255,255,0.18) 0%, transparent 55%)" }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 616,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "rounded-[34px] p-5 aspect-[9/18] flex flex-col gap-4 text-left overflow-hidden",
												style: { backgroundColor: "#0E1613" },
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "w-20 h-4 rounded-full mx-auto flex items-center justify-end px-2",
														style: { backgroundColor: "#182420" },
														children: /* @__PURE__ */ _jsxDEV("div", {
															className: "w-1.5 h-1.5 rounded-full",
															style: { backgroundColor: `${LIGHT}CC` }
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 624,
															columnNumber: 27
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 622,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center justify-between",
														children: [/* @__PURE__ */ _jsxDEV("div", {
															className: "flex gap-1 p-1 rounded-lg",
															style: { backgroundColor: "rgba(255,255,255,0.05)" },
															children: [["quiz", "Kuis"], ["survey", "Survei"]].map(([id, label]) => /* @__PURE__ */ _jsxDEV("button", {
																onClick: () => setPreset(id),
																className: `px-3 py-1 text-[11px] font-semibold rounded-md transition-colors duration-200 ${preset === id ? "text-white" : "text-stone-400 hover:text-stone-200"}`,
																style: preset === id ? { backgroundColor: GREEN } : {},
																children: label
															}, id, false, {
																fileName: _jsxFileName,
																lineNumber: 630,
																columnNumber: 31
															}, this))
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 628,
															columnNumber: 27
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "text-[10px] font-semibold flex items-center gap-1.5 blink",
															style: { color: LIGHT },
															children: [/* @__PURE__ */ _jsxDEV("span", {
																className: "w-1.5 h-1.5 rounded-full",
																style: { backgroundColor: LIGHT }
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 638,
																columnNumber: 29
															}, this), " LIVE"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 637,
															columnNumber: 27
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 627,
														columnNumber: 25
													}, this),
													preset === "quiz" ? /* @__PURE__ */ _jsxDEV("div", {
														className: "rounded-xl p-3.5 space-y-2.5",
														style: {
															backgroundColor: "rgba(255,255,255,0.04)",
															border: "1px solid rgba(255,255,255,0.07)"
														},
														children: [
															/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xs font-bold text-white",
																children: "Ujian Harian Fisika"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 646,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("p", {
																className: "text-[10px] text-stone-400 mt-0.5",
																children: "10 soal · 15 menit"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 647,
																columnNumber: 31
															}, this)] }, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 645,
																columnNumber: 29
															}, this),
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-[11px] text-stone-200",
																children: "1. Satuan SI untuk gaya adalah…"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 649,
																columnNumber: 29
															}, this),
															/* @__PURE__ */ _jsxDEV("div", {
																className: "grid grid-cols-2 gap-1.5",
																children: [/* @__PURE__ */ _jsxDEV("div", {
																	className: "py-1.5 rounded-md text-[10px] font-semibold text-center text-white flex items-center justify-center gap-1",
																	style: { backgroundColor: GREEN },
																	children: [/* @__PURE__ */ _jsxDEV(Check, { size: 10 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 653,
																		columnNumber: 33
																	}, this), " Newton"]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 651,
																	columnNumber: 31
																}, this), [
																	"Joule",
																	"Pascal",
																	"Watt"
																].map((o) => /* @__PURE__ */ _jsxDEV("div", {
																	className: "py-1.5 rounded-md text-[10px] text-center text-stone-400",
																	style: { backgroundColor: "rgba(255,255,255,0.05)" },
																	children: o
																}, o, false, {
																	fileName: _jsxFileName,
																	lineNumber: 656,
																	columnNumber: 33
																}, this))]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 650,
																columnNumber: 29
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 643,
														columnNumber: 27
													}, this) : /* @__PURE__ */ _jsxDEV("div", {
														className: "rounded-xl p-3.5 space-y-2.5",
														style: {
															backgroundColor: "rgba(255,255,255,0.04)",
															border: "1px solid rgba(255,255,0.07)"
														},
														children: [
															/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xs font-bold text-white",
																children: "Survei Kepuasan Kelas"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 665,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("p", {
																className: "text-[10px] text-stone-400 mt-0.5",
																children: "Anonim · 2 pertanyaan"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 666,
																columnNumber: 31
															}, this)] }, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 664,
																columnNumber: 29
															}, this),
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-[11px] text-stone-200",
																children: "Seberapa jelas materi hari ini?"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 668,
																columnNumber: 29
															}, this),
															/* @__PURE__ */ _jsxDEV("div", {
																className: "flex gap-1.5",
																children: [/* @__PURE__ */ _jsxDEV("div", {
																	className: "flex-1 py-1.5 rounded-md text-[10px] font-semibold text-center text-white",
																	style: { backgroundColor: GREEN },
																	children: "Sangat jelas"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 670,
																	columnNumber: 31
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "flex-1 py-1.5 rounded-md text-[10px] text-center text-stone-400",
																	style: { backgroundColor: "rgba(255,255,255,0.05)" },
																	children: "Cukup"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 672,
																	columnNumber: 31
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 669,
																columnNumber: 29
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 662,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "rounded-xl px-3 py-2 flex items-center justify-between",
														style: {
															backgroundColor: `${GREEN}1F`,
															border: `1px solid ${GREEN}40`
														},
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "text-[10px] font-medium",
															style: { color: LIGHT },
															children: "Tersinkron dengan web"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 680,
															columnNumber: 27
														}, this), /* @__PURE__ */ _jsxDEV(Check, {
															size: 13,
															style: { color: LIGHT }
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 681,
															columnNumber: 27
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 678,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "mt-auto pt-3 flex items-center justify-between text-[10px] text-stone-500",
														style: { borderTop: "1px solid rgba(255,255,255,0.07)" },
														children: [/* @__PURE__ */ _jsxDEV("span", { children: "formup.app" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 686,
															columnNumber: 27
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															style: { color: LIGHT },
															children: "Terhubung"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 687,
															columnNumber: 27
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 684,
														columnNumber: 25
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 620,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 608,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 605,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 604,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 603,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 602,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 601,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 537,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 536,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "relative",
				children: [RITUAL_LINES.map((line, i) => /* @__PURE__ */ _jsxDEV("div", {
					className: "ritual-panel relative min-h-[85vh] md:min-h-screen flex items-center justify-center px-6",
					style: {
						backgroundColor: i % 2 === 1 ? TINT : CREAM,
						zIndex: i + 2
					},
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "ritual-inner text-center max-w-3xl",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold tracking-[0.2em] uppercase mb-6",
							style: { color: GREEN },
							children: [
								"Ritual lama · ",
								i + 1,
								" dari ",
								RITUAL_LINES.length
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 705,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-4xl sm:text-6xl font-extrabold tracking-tight leading-[1.08]",
							children: line
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 708,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 704,
						columnNumber: 13
					}, this)
				}, i, false, {
					fileName: _jsxFileName,
					lineNumber: 702,
					columnNumber: 11
				}, this)), /* @__PURE__ */ _jsxDEV("div", {
					className: "ritual-panel relative min-h-[85vh] md:min-h-screen flex items-center justify-center px-6",
					style: {
						backgroundColor: GREEN,
						zIndex: RITUAL_LINES.length + 2
					},
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "ritual-inner text-center max-w-3xl",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold tracking-[0.2em] uppercase mb-7",
							style: { color: "#F6F4EDB3" },
							children: "Lalu FormUp bertanya"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 715,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-5xl sm:text-7xl font-extrabold tracking-tight leading-[1.05] text-[#F6F4ED]",
							children: [
								"Kenapa harus",
								" ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-serifit italic font-normal",
									children: "sesulit itu?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 720,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 718,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 714,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 712,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 700,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "manifesto",
				className: "relative px-6 py-28 md:py-40",
				style: {
					backgroundColor: CREAM,
					zIndex: 10
				},
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-3xl mx-auto",
					children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "m-reveal text-xs font-bold tracking-[0.18em] uppercase mb-8",
						style: { color: GREEN },
						children: "Manifesto"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 729,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-2xl sm:text-3xl md:text-[2.4rem] font-medium leading-snug md:leading-[1.35] tracking-[-0.01em]",
						children: MANIFESTO.split(" ").map((w, i) => /* @__PURE__ */ _jsxDEV("span", {
							className: "mword inline-block mr-[0.28em]",
							children: w
						}, i, false, {
							fileName: _jsxFileName,
							lineNumber: 734,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 732,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 728,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 727,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "alur",
				className: "relative",
				style: {
					backgroundColor: TINT,
					zIndex: 10
				},
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "wf-progress absolute top-0 left-0 right-0 h-1 origin-left scale-x-0 z-30",
					style: { backgroundColor: GREEN }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 742,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "min-h-screen flex flex-col justify-center overflow-hidden py-24 md:py-0",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "px-6 md:px-[7vw] mb-10 md:mb-14 flex items-end justify-between gap-6",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "m-reveal text-xs font-bold tracking-[0.18em] uppercase mb-4",
							style: { color: GREEN },
							children: "Cara kerja"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 746,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h2", {
							className: "m-reveal text-3xl sm:text-5xl font-extrabold tracking-tight leading-[1.05]",
							children: [
								"Empat langkah.",
								/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 750,
									columnNumber: 31
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-serifit italic font-normal",
									style: { color: GREEN },
									children: "Nol ribet."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 751,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 749,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 745,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "hidden md:flex items-center gap-2 text-xs font-semibold tracking-wide uppercase",
							style: { color: `${INK}66` },
							children: ["Scroll ", /* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 755,
								columnNumber: 22
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 754,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 744,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "wf-track flex flex-col md:flex-row gap-5 md:gap-[2.5vw] px-6 md:px-[7vw] md:w-max will-change-transform",
						children: WORKFLOW.map((step) => /* @__PURE__ */ _jsxDEV("article", {
							className: "group relative shrink-0 p-8 md:p-10 rounded-3xl border overflow-hidden md:w-[36vw] lg:w-[28vw] transition-colors duration-500",
							style: {
								backgroundColor: CREAM,
								borderColor: `${INK}1A`
							},
							onMouseEnter: (e) => e.currentTarget.style.borderColor = `${GREEN}80`,
							onMouseLeave: (e) => e.currentTarget.style.borderColor = `${INK}1A`,
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "absolute -top-8 -right-3 text-[10rem] font-extrabold leading-none select-none pointer-events-none",
									style: { color: `${INK}08` },
									children: step.num
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 767,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm font-extrabold mb-6 relative",
									style: { color: GREEN },
									children: step.num
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 771,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-2xl font-extrabold mb-3 relative",
									children: step.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 772,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm leading-relaxed relative",
									style: { color: `${INK}99` },
									children: step.desc
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 773,
									columnNumber: 17
								}, this)
							]
						}, step.num, true, {
							fileName: _jsxFileName,
							lineNumber: 761,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 759,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 743,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 741,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "cerita",
				className: "relative",
				style: {
					backgroundColor: CREAM,
					zIndex: 10
				},
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "cerita-stage relative h-screen overflow-hidden",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "max-w-6xl mx-auto h-full px-6 grid md:grid-cols-2 gap-10 items-center",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "relative md:h-[420px] py-10 md:py-0",
							children: [BEATS.map((b, i) => /* @__PURE__ */ _jsxDEV("div", {
								className: `beat ${i === 0 ? "beat-active" : ""} max-w-md`,
								onClick: () => setActiveBeat(i),
								children: [
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs font-bold tracking-[0.2em] uppercase mb-5",
										style: { color: GREEN },
										children: [
											b.num,
											" — ",
											BEATS.length,
											" langkah utama"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 789,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-4xl sm:text-6xl font-extrabold tracking-tight mb-5",
										children: [b.title, /* @__PURE__ */ _jsxDEV("span", {
											className: "font-serifit italic font-normal",
											style: { color: GREEN },
											children: "."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 794,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 792,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-base leading-relaxed",
										style: { color: `${INK}99` },
										children: b.desc
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 796,
										columnNumber: 19
									}, this)
								]
							}, b.num, true, {
								fileName: _jsxFileName,
								lineNumber: 786,
								columnNumber: 17
							}, this)), /* @__PURE__ */ _jsxDEV("div", {
								className: "hidden md:flex absolute -bottom-2 left-0 gap-2",
								children: BEATS.map((b, i) => /* @__PURE__ */ _jsxDEV("span", {
									className: "h-1.5 rounded-full transition-all duration-500",
									style: {
										width: beat === i ? 28 : 10,
										backgroundColor: beat === i ? GREEN : `${INK}26`
									}
								}, b.num, false, {
									fileName: _jsxFileName,
									lineNumber: 801,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 799,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 784,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "hidden md:flex justify-center",
							style: { perspective: "1400px" },
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "cerita-phone",
								children: /* @__PURE__ */ _jsxDEV(StoryPhone, { screen }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 811,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 810,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 809,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 783,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 782,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 781,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "fitur",
				className: "relative px-6 py-24 md:py-32",
				style: {
					backgroundColor: CREAM,
					zIndex: 10
				},
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-6xl mx-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold tracking-[0.18em] uppercase mb-4",
							style: { color: GREEN },
							children: "Kemampuan utama"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 821,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-3xl sm:text-5xl font-extrabold tracking-tight mb-14",
							children: [
								"Yang kamu butuhkan,",
								" ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-serifit italic font-normal",
									style: { color: GREEN },
									children: "tidak lebih."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 826,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 824,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid md:grid-cols-3 gap-5 mb-20",
							children: FEATURES.map((f) => /* @__PURE__ */ _jsxDEV("article", {
								className: "feature-card group relative p-8 rounded-3xl border bg-white transition-all duration-500 hover:-translate-y-1.5",
								style: {
									borderColor: `${INK}14`,
									boxShadow: "0 1px 2px rgba(28,38,32,0.05)"
								},
								onMouseEnter: (e) => e.currentTarget.style.borderColor = `${GREEN}66`,
								onMouseLeave: (e) => e.currentTarget.style.borderColor = `${INK}14`,
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-11 h-11 rounded-xl flex items-center justify-center mb-6 transition-transform duration-500 group-hover:scale-110",
										style: {
											backgroundColor: `${GREEN}14`,
											color: GREEN
										},
										children: /* @__PURE__ */ _jsxDEV(f.icon, { size: 20 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 838,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 836,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-base font-bold mb-2.5",
										children: f.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 840,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm leading-relaxed",
										style: { color: `${INK}99` },
										children: f.desc
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 841,
										columnNumber: 17
									}, this)
								]
							}, f.title, true, {
								fileName: _jsxFileName,
								lineNumber: 830,
								columnNumber: 15
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 828,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid sm:grid-cols-3 gap-y-12 gap-x-8 pt-12",
							style: { borderTop: `1px solid ${INK}14` },
							children: [
								/* @__PURE__ */ _jsxDEV(Stat, {
									value: 3,
									suffix: " menit",
									label: "rata-rata waktu membuat satu formulir"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 846,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(Stat, {
									value: 100,
									suffix: "%",
									label: "gratis, tanpa batas jumlah respons"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 847,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(Stat, {
									value: 1,
									suffix: " klik",
									label: "untuk ekspor rekap ke CSV / XLSX"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 848,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 845,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 820,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 819,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "faq",
				className: "relative px-6 pb-24 md:pb-32",
				style: {
					backgroundColor: CREAM,
					zIndex: 10
				},
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-2xl mx-auto",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-3xl sm:text-4xl font-extrabold tracking-tight text-center mb-12",
						children: "Pertanyaan umum"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 856,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: FAQS.map((faq, i) => {
							const open = openFaq === i;
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "faq-card rounded-2xl border bg-white overflow-hidden transition-colors duration-300",
								style: { borderColor: open ? `${GREEN}80` : `${INK}14` },
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setOpenFaq(open ? null : i),
									className: "w-full p-5 text-left flex items-center justify-between gap-4 font-semibold text-sm transition-colors",
									style: { color: open ? GREEN : INK },
									children: [/* @__PURE__ */ _jsxDEV("span", { children: faq.q }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 868,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-transform duration-300",
										style: {
											transform: open ? "rotate(180deg)" : "none",
											backgroundColor: open ? `${GREEN}1F` : `${INK}0D`,
											color: open ? GREEN : `${INK}80`
										},
										children: /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 15 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 875,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 869,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 865,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid transition-all duration-300 ease-in-out",
									style: {
										gridTemplateRows: open ? "1fr" : "0fr",
										opacity: open ? 1 : 0
									},
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "overflow-hidden",
										children: /* @__PURE__ */ _jsxDEV("p", {
											className: "px-5 pb-5 text-sm leading-relaxed pt-4",
											style: {
												color: `${INK}99`,
												borderTop: `1px solid ${INK}0F`
											},
											children: faq.a
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 881,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 880,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 878,
									columnNumber: 19
								}, this)]
							}, i, true, {
								fileName: _jsxFileName,
								lineNumber: 863,
								columnNumber: 17
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 859,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 855,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 854,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "relative text-[#F6F4ED] overflow-hidden flex flex-col",
				style: {
					height: "100vh",
					background: `linear-gradient(180deg, ${CREAM} 0%, ${DARK} 14%, ${DARK} 100%)`,
					zIndex: 10
				},
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex-1 flex flex-col items-center justify-center text-center px-6 max-w-3xl mx-auto w-full pt-20",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "m-reveal text-xs font-bold tracking-[0.18em] uppercase mb-5",
								style: { color: LIGHT },
								children: "Aplikasi Android"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 898,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "m-reveal text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.05] mb-5",
								children: [
									"Bawa FormUp",
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-serifit italic font-normal",
										style: { color: LIGHT },
										children: "ke mana-mana."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 903,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 901,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "m-reveal text-sm sm:text-base max-w-md mx-auto leading-relaxed mb-8",
								style: { color: "#F6F4EDA6" },
								children: "Daftar lewat browser sekarang, pasang aplikasinya sesudahnya — semua formulirmu sudah menunggu di sana."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 905,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "m-reveal flex flex-col sm:flex-row items-center justify-center gap-3.5",
								children: [
									/* @__PURE__ */ _jsxDEV(Magnetic, { children: /* @__PURE__ */ _jsxDEV("a", {
										href: APK_URL,
										download: "formup-android.apk",
										target: "_blank",
										rel: "noopener noreferrer",
										className: "px-7 py-3.5 text-sm font-bold rounded-full flex items-center gap-2 transition-colors duration-300",
										style: {
											backgroundColor: GREEN,
											color: "#F6F4ED"
										},
										onMouseEnter: (e) => e.currentTarget.style.backgroundColor = LIGHT,
										onMouseLeave: (e) => e.currentTarget.style.backgroundColor = GREEN,
										children: [/* @__PURE__ */ _jsxDEV(Smartphone, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 918,
											columnNumber: 17
										}, this), " Unduh APK (Android)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 912,
										columnNumber: 15
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 911,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV(Magnetic, { children: /* @__PURE__ */ _jsxDEV("a", {
										href: EXE_URL,
										download: "formup-windows-installer.exe",
										target: "_blank",
										rel: "noopener noreferrer",
										className: "px-7 py-3.5 text-sm font-bold rounded-full flex items-center gap-2 transition-colors duration-300",
										style: {
											backgroundColor: INK,
											color: "#F6F4ED"
										},
										onMouseEnter: (e) => e.currentTarget.style.backgroundColor = DARK,
										onMouseLeave: (e) => e.currentTarget.style.backgroundColor = INK,
										children: [/* @__PURE__ */ _jsxDEV(Download, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 929,
											columnNumber: 17
										}, this), " Unduh Installer (Windows)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 923,
										columnNumber: 15
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 922,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV(Link, {
										to: "/register",
										className: "px-7 py-3.5 text-sm font-semibold rounded-full border transition-all",
										style: {
											borderColor: "#F6F4ED33",
											color: "#F6F4EDCC"
										},
										onMouseEnter: (e) => {
											e.currentTarget.style.borderColor = "#F6F4ED80";
											e.currentTarget.style.backgroundColor = "#F6F4ED0D";
										},
										onMouseLeave: (e) => {
											e.currentTarget.style.borderColor = "#F6F4ED33";
											e.currentTarget.style.backgroundColor = "transparent";
										},
										children: ["Daftar gratis ", /* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 15 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 938,
											columnNumber: 29
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 932,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 909,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 897,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						id: "trio",
						className: "hidden md:flex items-end justify-center gap-6 lg:gap-8 px-6 shrink-0",
						style: { perspective: "1400px" },
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "trio-left w-28 lg:w-32 shrink-0 rounded-[28px] border border-white/15 p-2 shadow-2xl",
								style: { background: "linear-gradient(180deg, #2E3B33 0%, #131C17 100%)" },
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "w-full h-full rounded-[22px] p-3 flex flex-col justify-center gap-2 text-left aspect-[9/19]",
									style: { backgroundColor: "#0B1210" },
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-1.5 rounded-full mx-auto",
											style: { backgroundColor: "#5BC98C66" }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 950,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[9px] font-bold text-stone-400",
											children: "Analitik respon"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 951,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-full h-9 rounded-lg flex items-center justify-center text-[9px] font-bold",
											style: {
												backgroundColor: `${GREEN}26`,
												border: `1px solid ${GREEN}59`,
												color: LIGHT
											},
											children: "98% selesai"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 952,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-full h-1 rounded-full",
											style: { backgroundColor: "rgba(255,255,255,0.1)" }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 956,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 948,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 946,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "trio-center w-36 lg:w-44 shrink-0 rounded-[34px] border border-white/25 p-2.5",
								style: {
									background: "linear-gradient(180deg, #38473E 0%, #131C17 100%)",
									boxShadow: "0 30px 70px rgba(0,0,0,0.5)"
								},
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "w-full h-full rounded-[26px] p-4 flex flex-col justify-between text-left aspect-[9/19]",
									style: { backgroundColor: "#0B1210" },
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-16 h-3 rounded-full mx-auto",
											style: { backgroundColor: "#16211B" }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 964,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold text-white",
												children: "FormUp Mobile"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 966,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "p-2 rounded-lg text-[10px] font-semibold",
												style: {
													backgroundColor: `${GREEN}26`,
													border: `1px solid ${GREEN}59`,
													color: LIGHT
												},
												children: "Sinkronisasi aktif"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 967,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 965,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-full py-2.5 rounded-lg text-[10px] font-bold text-center text-white",
											style: { backgroundColor: GREEN },
											children: "Siap digunakan"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 972,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 962,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 960,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "trio-right w-28 lg:w-32 shrink-0 rounded-[28px] border border-white/15 p-2 shadow-2xl",
								style: { background: "linear-gradient(180deg, #2E3B33 0%, #131C17 100%)" },
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "w-full h-full rounded-[22px] p-3 flex flex-col justify-center gap-2 text-left aspect-[9/19]",
									style: { backgroundColor: "#0B1210" },
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-1.5 rounded-full mx-auto",
											style: { backgroundColor: "#5BC98C66" }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 983,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[9px] font-bold text-stone-400",
											children: "QR code"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 984,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-12 h-12 rounded-lg mx-auto flex items-center justify-center border border-white/10",
											style: { backgroundColor: "rgba(255,255,255,0.05)" },
											children: /* @__PURE__ */ _jsxDEV(QrCode, {
												size: 20,
												style: { color: LIGHT }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 987,
												columnNumber: 17
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 985,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-full h-1 rounded-full",
											style: { backgroundColor: "rgba(255,255,255,0.1)" }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 989,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 981,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 979,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 944,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("footer", {
						className: "px-6 pt-5 pb-6 shrink-0",
						style: { backgroundColor: DARK },
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-sm",
							style: {
								color: "#F6F4ED66",
								borderTop: "1px solid rgba(246,244,237,0.08)",
								paddingTop: "1.25rem"
							},
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("img", {
										src: logo,
										alt: "FormUp",
										className: "w-5 h-5 object-contain opacity-70"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 999,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-[#F6F4EDCC]",
										children: "FormUp"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1e3,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "mx-1",
										children: "·"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1001,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: ["© ", new Date().getFullYear()] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1002,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 998,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-7",
								children: [
									/* @__PURE__ */ _jsxDEV(Link, {
										to: "/login",
										className: "hover:text-[#F6F4ED] transition-colors",
										children: "Masuk"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1005,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV(Link, {
										to: "/register",
										className: "hover:text-[#F6F4ED] transition-colors",
										children: "Daftar"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1006,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: APK_URL,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "hover:text-[#F6F4ED] transition-colors",
										children: "Aplikasi Android"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1007,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1004,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 996,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 995,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 895,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 477,
		columnNumber: 5
	}, this);
}
_s3(LandingPage, "JBhz/ch+GpJHeLfdCKW8EPG+wX4=", false, function() {
	return [useNavigate];
});
_c4 = LandingPage;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "Magnetic");
$RefreshReg$(_c2, "Stat");
$RefreshReg$(_c3, "StoryPhone");
$RefreshReg$(_c4, "LandingPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/landing/LandingPage.jsx?t=1789530336154";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/landing/LandingPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/landing/LandingPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/landing/LandingPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsUUFBUSxtQkFBbUI7QUFDekQsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxPQUFPLFVBQVU7QUFDakIsU0FBUyxxQkFBcUI7QUFDOUIsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsY0FBYyxZQUFZLE9BQU8sYUFDakMsUUFBUSxXQUFXLFFBQVEsT0FBTyxVQUFVLFlBQ3ZDO0FBQ1AsU0FBUyx1QkFBdUI7QUFDaEMsT0FBTyxVQUFVOzs7O0FBRWpCLEtBQUssZUFBZSxhQUFhO0FBQ2pDLGNBQWMsT0FBTyxFQUFFLG9CQUFvQixLQUFLLENBQUM7Ozs7QUFLakQsTUFBTSxRQUFRO0FBQ2QsTUFBTSxNQUFNO0FBQ1osTUFBTSxRQUFRO0FBQ2QsTUFBTSxhQUFhO0FBQ25CLE1BQU0sT0FBTztBQUNiLE1BQU0sT0FBTztBQUNiLE1BQU0sUUFBUTs7OztBQUtkLE1BQU0sZUFBZTtDQUNuQjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Y7QUFFQSxNQUFNLFdBQVc7Q0FDZjtFQUFFLEtBQUs7RUFBTSxPQUFPO0VBQ2xCLE1BQU07Q0FBb0Y7Q0FDNUY7RUFBRSxLQUFLO0VBQU0sT0FBTztFQUNsQixNQUFNO0NBQStFO0NBQ3ZGO0VBQUUsS0FBSztFQUFNLE9BQU87RUFDbEIsTUFBTTtDQUFrRjtDQUMxRjtFQUFFLEtBQUs7RUFBTSxPQUFPO0VBQ2xCLE1BQU07Q0FBcUY7QUFDL0Y7QUFFQSxNQUFNLFFBQVE7Q0FDWjtFQUFFLEtBQUs7RUFBTSxRQUFRO0VBQVMsT0FBTztFQUNuQyxNQUFNO0NBQTJGO0NBQ25HO0VBQUUsS0FBSztFQUFNLFFBQVE7RUFBUyxPQUFPO0VBQ25DLE1BQU07Q0FBdUY7Q0FDL0Y7RUFBRSxLQUFLO0VBQU0sUUFBUTtFQUFTLE9BQU87RUFDbkMsTUFBTTtDQUF5RjtBQUNuRztBQUVBLE1BQU0sV0FBVztDQUNmO0VBQUUsTUFBTTtFQUFRLE9BQU87RUFDckIsTUFBTTtDQUE2RTtDQUNyRjtFQUFFLE1BQU07RUFBVyxPQUFPO0VBQ3hCLE1BQU07Q0FBb0Y7Q0FDNUY7RUFBRSxNQUFNO0VBQVEsT0FBTztFQUNyQixNQUFNO0NBQXlFO0FBQ25GO0FBRUEsTUFBTSxZQUNKO0FBRUYsTUFBTSxPQUFPO0NBQ1g7RUFBRSxHQUFHO0VBQ0gsR0FBRztDQUFvRjtDQUN6RjtFQUFFLEdBQUc7RUFDSCxHQUFHO0NBQTZHO0NBQ2xIO0VBQUUsR0FBRztFQUNILEdBQUc7Q0FBNEY7Q0FDakc7RUFBRSxHQUFHO0VBQ0gsR0FBRztDQUEwRTtBQUNqRjtBQUVBLE1BQU0sVUFBVTtBQUNoQixNQUFNLFVBQVU7Ozs7QUFLaEIsU0FBUyxTQUFTLEVBQUUsVUFBVSxZQUFZLElBQUksV0FBVyxPQUFROztDQUMvRCxNQUFNLE1BQU0sT0FBTyxJQUFJO0NBQ3ZCLE1BQU0sTUFBTSxPQUFPLElBQUk7Q0FDdkIsTUFBTSxNQUFNLE9BQU8sSUFBSTtDQUV2QixnQkFBZ0I7RUFDZCxJQUFJLFVBQVUsS0FBSyxRQUFRLElBQUksU0FBUyxLQUFLO0dBQUUsVUFBVTtHQUFLLE1BQU07RUFBYSxDQUFDO0VBQ2xGLElBQUksVUFBVSxLQUFLLFFBQVEsSUFBSSxTQUFTLEtBQUs7R0FBRSxVQUFVO0dBQUssTUFBTTtFQUFhLENBQUM7Q0FDcEYsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLFNBQVMsYUFBYSxNQUFNO0VBQ2hDLE1BQU0sT0FBTyxJQUFJLFFBQVEsc0JBQXNCO0VBQy9DLElBQUksU0FBUyxFQUFFLFdBQVcsS0FBSyxPQUFPLEtBQUssUUFBUSxNQUFNLFFBQVE7RUFDakUsSUFBSSxTQUFTLEVBQUUsV0FBVyxLQUFLLE1BQU0sS0FBSyxTQUFTLE1BQU0sUUFBUTtDQUNuRSxHQUFHLENBQUMsUUFBUSxDQUFDO0NBQ2IsTUFBTSxVQUFVLGtCQUFrQjtFQUFFLElBQUksUUFBUSxDQUFDO0VBQUcsSUFBSSxRQUFRLENBQUM7Q0FBRyxHQUFHLENBQUMsQ0FBQztDQUV6RSxPQUNFLHdCQUFDLE9BQUQ7RUFBVTtFQUFLLGFBQWE7RUFBUSxjQUFjO0VBQVMsV0FBVyxnQkFBZ0I7RUFDbkY7Q0FDRTs7Ozs7QUFFVDs7Ozs7O0FBS0EsU0FBUyxLQUFLLEVBQUUsT0FBTyxRQUFRLFNBQVM7O0NBQ3RDLE1BQU0sQ0FBQyxHQUFHLFFBQVEsU0FBUyxLQUFLO0NBQ2hDLE1BQU0sVUFBVSxPQUFPLEtBQUs7Q0FDNUIsTUFBTSxNQUFNLE9BQU8sSUFBSTtDQUV2QixnQkFBZ0I7RUFDZCxNQUFNLEtBQUssSUFBSTtFQUNmLE1BQU0sS0FBSyxJQUFJLHNCQUFzQixDQUFDLE9BQU87R0FDM0MsSUFBSSxDQUFDLEVBQUUsa0JBQWtCLFFBQVEsU0FBUztHQUMxQyxRQUFRLFVBQVU7R0FDbEIsR0FBRyxXQUFXO0dBQ2QsTUFBTSxRQUFRLFlBQVksSUFBSTtHQUM5QixNQUFNLE1BQU07R0FDWixNQUFNLFFBQVEsTUFBTTtJQUNsQixNQUFNLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxTQUFTLEdBQUc7SUFDdkMsS0FBSyxLQUFLLE1BQU0sU0FBUyxJQUFJLEtBQUssSUFBSSxJQUFJLEdBQUcsQ0FBQyxFQUFFLENBQUM7SUFDakQsSUFBSSxJQUFJLEdBQUcsc0JBQXNCLElBQUk7R0FDdkM7R0FDQSxzQkFBc0IsSUFBSTtFQUM1QixHQUFHLEVBQUUsV0FBVyxHQUFJLENBQUM7RUFDckIsR0FBRyxRQUFRLEVBQUU7RUFDYixhQUFhLEdBQUcsV0FBVztDQUM3QixHQUFHLENBQUMsS0FBSyxDQUFDO0NBRVYsT0FDRSx3QkFBQyxPQUFEO0VBQVU7WUFBVixDQUNFLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO0dBQXFELE9BQU8sRUFBRSxPQUFPLElBQUk7YUFBdEYsQ0FDRyxHQUFFLHdCQUFDLFFBQUQ7SUFBTSxPQUFPLEVBQUUsT0FBTyxNQUFNO2NBQUk7R0FBYTs7OztXQUMvQzs7Ozs7WUFDSCx3QkFBQyxLQUFEO0dBQUcsV0FBVTtHQUErQixPQUFPLEVBQUUsT0FBTyxHQUFHLElBQUksSUFBSTthQUFJO0VBQVM7Ozs7VUFDakY7Ozs7OztBQUVUOzs7Ozs7QUFLQSxTQUFTLFdBQVcsRUFBRSxVQUFVO0NBQzlCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQ2IsT0FBTyxFQUFFLGlCQUFpQixHQUFHLE1BQU0sSUFBSTtFQUFJOzs7O1lBQzdDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQ2IsT0FBTztJQUNMLFlBQVk7SUFDWixXQUFXO0dBQ2I7YUFDQSx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUNiLE9BQU8sRUFBRSxpQkFBaUIsVUFBVTtjQUR0QztLQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQ2IsT0FBTyxFQUFFLGlCQUFpQixVQUFVO2dCQUNwQyx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUEyQixPQUFPLEVBQUUsaUJBQWlCLEdBQUcsTUFBTSxJQUFJO01BQUk7Ozs7O0tBQ2xGOzs7OztLQUVKLFdBQVcsV0FDVjtNQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBK0I7TUFBZ0I7Ozs7Z0JBQzVELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO09BQXFCLE9BQU8sRUFBRSxPQUFPLFVBQVU7aUJBQUc7TUFBMEI7Ozs7Y0FDdEY7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBMkIsT0FBTztRQUFFLGlCQUFpQjtRQUEwQixRQUFRO09BQW1DO2lCQUF6STtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQXlCLE9BQU8sRUFBRSxpQkFBaUIseUJBQXlCO1FBQUk7Ozs7O1FBQy9GLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQWtFLE9BQU8sRUFBRSxpQkFBaUIseUJBQXlCO21CQUFHO1FBRWxJOzs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQWtFLE9BQU8sRUFBRSxpQkFBaUIseUJBQXlCO21CQUFHO1FBRWxJOzs7OztPQUNGOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUNiLE9BQU8sRUFBRSxpQkFBaUIsTUFBTTtpQkFEbEMsQ0FFRSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2lCQUFDLG9CQUNmOzs7Ozs7S0FDTDs7Ozs7S0FHSCxXQUFXLFdBQ1Y7TUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQStCO01BQXNCOzs7O2dCQUNsRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBb0M7TUFBaUI7Ozs7Y0FDL0Q7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FDYixPQUFPO1FBQUUsaUJBQWlCO1FBQTBCLFFBQVE7T0FBbUM7aUJBRGpHLENBRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFDYixPQUFPLEVBQUUsaUJBQWlCLFVBQVU7a0JBQ3BDLHdCQUFDLFFBQUQ7U0FBUSxNQUFNO1NBQUksT0FBTyxFQUFFLE9BQU8sSUFBSTtRQUFJOzs7OztPQUN2Qzs7OztpQkFDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtRQUE0QixPQUFPLEVBQUUsT0FBTyxNQUFNO2tCQUFHO09BQW9COzs7O2VBQ25GOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUNiLE9BQU87UUFBRSxpQkFBaUIsR0FBRyxNQUFNO1FBQUssUUFBUSxhQUFhLE1BQU07T0FBSTtpQkFEekUsQ0FFRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUEwQixPQUFPLEVBQUUsT0FBTyxNQUFNO2tCQUFHO09BQW1COzs7O2lCQUN0Rix3QkFBQyxPQUFEO1FBQU8sTUFBTTtRQUFJLE9BQU8sRUFBRSxPQUFPLE1BQU07T0FBSTs7OztlQUN4Qzs7Ozs7O0tBQ0w7Ozs7O0tBR0gsV0FBVyxXQUNWO01BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUErQjtNQUFnQjs7OztnQkFDNUQsd0JBQUMsS0FBRDtPQUFHLFdBQVU7T0FBcUIsT0FBTyxFQUFFLE9BQU8sTUFBTTtpQkFBRztNQUE2Qjs7OztjQUNyRjs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUNiLE9BQU87UUFBRSxpQkFBaUI7UUFBMEIsUUFBUTtPQUFtQztpQkFEakc7UUFFRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkI7UUFBbUI7Ozs7O1FBQzdELHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaO1VBQUM7VUFBSTtVQUFJO1VBQUk7VUFBSztVQUFJO1NBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUNqQyx3QkFBQyxPQUFEO1VBQWEsV0FBVTtVQUFzQixPQUFPO1dBQUUsUUFBUSxHQUFHLEVBQUU7V0FBSSxpQkFBaUIsTUFBTSxJQUFJLFFBQVE7VUFBTTtTQUFJLEdBQTFHOzs7O2dCQUEwRyxDQUNySDtRQUNFOzs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O1VBQUMsd0JBQUMsUUFBRCxZQUFNLEtBQVE7Ozs7O1VBQUMsd0JBQUMsUUFBRCxZQUFNLE1BQVM7Ozs7O1NBQ3pDOzs7Ozs7T0FDRjs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FDYixPQUFPO1FBQUUsaUJBQWlCLEdBQUcsTUFBTTtRQUFLLFFBQVEsYUFBYSxNQUFNO09BQUk7aUJBRHpFLENBRUUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7UUFBMEIsT0FBTyxFQUFFLE9BQU8sTUFBTTtrQkFBRztPQUF1Qjs7OztpQkFDMUYsd0JBQUMsVUFBRDtRQUFVLE1BQU07UUFBSSxPQUFPLEVBQUUsT0FBTyxNQUFNO09BQUk7Ozs7ZUFDM0M7Ozs7OztLQUNMOzs7OztLQUdKLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQ2IsT0FBTyxFQUFFLFdBQVcsbUNBQW1DO2dCQUR6RCxDQUVFLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztnQkFDdEIsd0JBQUMsUUFBRDtPQUFNLE9BQU8sRUFBRSxPQUFPLE1BQU07aUJBQUc7TUFBZTs7OztjQUMzQzs7Ozs7O0lBQ0Y7Ozs7OztFQUNGOzs7O1VBQ0Y7Ozs7OztBQUVUOzs7OztBQUtBLGVBQWUsU0FBUyxjQUFjOztDQUNwQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsS0FBSztDQUM5QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsTUFBTTtDQUMzQyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsQ0FBQztDQUNsQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsT0FBTztDQUU1QyxNQUFNLGVBQWUsT0FBTyxJQUFJO0NBQ2hDLE1BQU0sZ0JBQWdCLE9BQU8sSUFBSTtDQUNqQyxNQUFNLGdCQUFnQixPQUFPLElBQUk7Q0FDakMsTUFBTSxlQUFlLE9BQU8sSUFBSTtDQUNoQyxNQUFNLGVBQWUsT0FBTyxJQUFJO0NBQ2hDLE1BQU0sV0FBVyxPQUFPLElBQUk7Q0FDNUIsTUFBTSxTQUFTLE9BQU8sSUFBSTtDQUMxQixNQUFNLFNBQVMsT0FBTyxJQUFJO0NBRTFCLGdCQUFnQjtFQUNkLElBQUksZ0JBQWdCLEdBQUcsU0FBUyxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDakUsR0FBRyxDQUFDLFFBQVEsQ0FBQzs7Q0FHYixnQkFBZ0I7RUFDZCxJQUFJLENBQUMsYUFBYSxTQUFTO0VBQzNCLE9BQU8sVUFBVSxLQUFLLFFBQVEsYUFBYSxTQUFTLGFBQWE7R0FBRSxVQUFVO0dBQUssTUFBTTtFQUFhLENBQUM7RUFDdEcsT0FBTyxVQUFVLEtBQUssUUFBUSxhQUFhLFNBQVMsYUFBYTtHQUFFLFVBQVU7R0FBSyxNQUFNO0VBQWEsQ0FBQztDQUN4RyxHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sa0JBQWtCLGFBQWEsTUFBTTtFQUN6QyxNQUFNLE9BQU8sRUFBRSxjQUFjLHNCQUFzQjtFQUNuRCxNQUFNLE1BQU0sRUFBRSxVQUFVLEtBQUssUUFBUSxLQUFLO0VBQzFDLE1BQU0sTUFBTSxFQUFFLFVBQVUsS0FBSyxPQUFPLEtBQUs7RUFDekMsT0FBTyxXQUFXLEtBQUssTUFBTyxDQUFDLEVBQUU7RUFDakMsT0FBTyxXQUFXLEtBQUssTUFBTyxFQUFFO0VBQ2hDLElBQUksU0FBUyxTQUFTO0dBQ3BCLFNBQVMsUUFBUSxNQUFNLGFBQ3JCLDZCQUE2QixLQUFLLElBQUksSUFBSSxLQUFLLElBQUk7RUFDdkQ7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUNMLE1BQU0sbUJBQW1CLGtCQUFrQjtFQUN6QyxPQUFPLFVBQVUsQ0FBQztFQUNsQixPQUFPLFVBQVUsQ0FBQztFQUNsQixJQUFJLFNBQVMsU0FBUztHQUNwQixTQUFTLFFBQVEsTUFBTSxhQUNyQjtFQUNKO0NBQ0YsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ2QsTUFBTSxVQUFVLE9BQU8sV0FBVyxrQ0FBa0MsQ0FBQyxDQUFDO0VBRXRFLElBQUksUUFBUTtFQUNaLElBQUksQ0FBQyxTQUFTO0dBQ1osUUFBUSxJQUFJLE1BQU07SUFBRSxVQUFVO0lBQU0sYUFBYTtHQUFLLENBQUM7R0FDdkQsTUFBTSxHQUFHLFVBQVUsY0FBYyxNQUFNO0VBQ3pDO0VBQ0EsTUFBTSxPQUFPLFNBQVMsT0FBTyxJQUFJLE9BQU8sR0FBSTtFQUM1QyxLQUFLLE9BQU8sSUFBSSxHQUFHO0VBQ25CLEtBQUssT0FBTyxhQUFhLENBQUM7RUFFMUIsTUFBTSxpQkFBaUIsWUFBWSxPQUFPLFVBQVUsRUFBRTtFQUN0RCxPQUFPLGlCQUFpQixVQUFVLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQztFQUU3RCxNQUFNLEtBQUssS0FBSyxXQUFXO0VBRTNCLE1BQU0sTUFBTSxLQUFLLGNBQWM7O0dBRTdCLEtBQUssR0FBRyxrQkFBa0I7SUFDeEIsUUFBUTtJQUFHLE1BQU07SUFDakIsZUFBZTtLQUFFLFNBQVMsU0FBUztLQUFNLE9BQU87S0FBVyxLQUFLO0tBQWlCLE9BQU87SUFBSTtHQUM5RixDQUFDOztHQUdELEtBQUssU0FBUyxFQUFFLFVBQVUsRUFBRSxNQUFNLGFBQWEsRUFBRSxDQUFDLENBQUMsQ0FDaEQsT0FBTyxhQUFhO0lBQUUsR0FBRyxDQUFDO0lBQUksU0FBUztHQUFFLEdBQUc7SUFBRSxHQUFHO0lBQUcsU0FBUztJQUFHLFNBQVM7SUFBTSxVQUFVO0dBQUksR0FBRyxFQUFHLENBQUMsQ0FDcEcsT0FBTyxnQkFBZ0I7SUFBRSxHQUFHO0lBQUksU0FBUztHQUFFLEdBQUc7SUFBRSxHQUFHO0lBQUcsU0FBUztJQUFHLFVBQVU7R0FBSSxHQUFHLEdBQUksQ0FBQyxDQUN4RixPQUFPLGNBQWMsRUFBRSxVQUFVLElBQUksR0FBRztJQUFFLFVBQVU7SUFBRyxTQUFTO0lBQU0sVUFBVTtHQUFJLEdBQUcsRUFBRyxDQUFDLENBQzNGLE9BQU8sYUFBYTtJQUFFLEdBQUc7SUFBSSxTQUFTO0dBQUUsR0FBRztJQUFFLEdBQUc7SUFBRyxTQUFTO0lBQUcsVUFBVTtHQUFJLEdBQUcsRUFBRyxDQUFDLENBQ3BGLE9BQU8sYUFBYTtJQUFFLEdBQUc7SUFBSSxTQUFTO0dBQUUsR0FBRztJQUFFLEdBQUc7SUFBRyxTQUFTO0lBQUcsU0FBUztJQUFLLFVBQVU7R0FBSSxHQUFHLEdBQUksQ0FBQyxDQUNuRyxPQUFPLGNBQWMsRUFBRSxTQUFTLEVBQUUsR0FBRztJQUFFLFNBQVM7SUFBRyxVQUFVO0dBQUksR0FBRyxDQUFDLENBQUMsQ0FDdEUsT0FBTyxjQUFjLFNBQVM7SUFBRSxHQUFHO0lBQUksU0FBUztJQUFHLE9BQU87R0FBSyxHQUM5RDtJQUFFLEdBQUc7SUFBRyxTQUFTO0lBQUcsT0FBTztJQUFHLFVBQVU7SUFBSyxNQUFNO0dBQWEsR0FBRyxHQUFJOztHQUczRSxLQUFLLEdBQUcsY0FBYyxTQUFTO0lBQUUsR0FBRyxDQUFDO0lBQUksVUFBVTtJQUFLLFFBQVEsQ0FBQztJQUFHLE1BQU07SUFBTSxNQUFNO0dBQWEsQ0FBQzs7R0FHcEcsS0FBSyxHQUFHLGFBQWEsU0FBUztJQUM1QixHQUFHO0lBQUssUUFBUSxDQUFDO0lBQUksU0FBUztJQUFHLE1BQU07SUFDdkMsZUFBZTtLQUFFLFNBQVM7S0FBUyxPQUFPO0tBQVcsS0FBSztLQUFjLE9BQU87SUFBRTtHQUNuRixDQUFDOztHQUdELEdBQUcsSUFBSSw0QkFBNEI7SUFDakMsS0FBSyxNQUFNLFFBQVEsZUFBZSxDQUFDLENBQUMsU0FBUyxVQUFVO0tBQ3JELEtBQUssS0FBSyxNQUFNLGNBQWMsZUFBZSxHQUFHO01BQzlDLEdBQUc7TUFBSSxTQUFTO01BQUcsVUFBVTtNQUFHLE1BQU07TUFDdEMsZUFBZTtPQUFFLFNBQVM7T0FBTyxPQUFPO09BQVcsZUFBZTtNQUF5QjtLQUM3RixDQUFDO0tBQ0QsY0FBYyxPQUFPO01BQUUsU0FBUztNQUFPLE9BQU87TUFBVyxLQUFLO01BQU0sWUFBWTtLQUFNLENBQUM7SUFDekYsQ0FBQztHQUNILENBQUM7R0FFRCxHQUFHLElBQUksNEJBQTRCO0lBQ2pDLEtBQUssTUFBTSxRQUFRLFdBQVcsQ0FBQyxDQUFDLFNBQVMsT0FBTztLQUM5QyxLQUFLLEtBQUssSUFBSTtNQUNaLEdBQUc7TUFBSSxTQUFTO01BQUcsVUFBVTtNQUFLLE1BQU07TUFDeEMsZUFBZTtPQUFFLFNBQVM7T0FBSSxPQUFPO09BQVcsTUFBTTtNQUFLO0tBQzdELENBQUM7SUFDSCxDQUFDO0dBQ0gsQ0FBQzs7R0FHRCxLQUFLLE9BQU8sVUFBVSxFQUFFLFNBQVMsSUFBSyxHQUFHO0lBQ3ZDLFNBQVM7SUFBRyxTQUFTO0lBQU0sTUFBTTtJQUNqQyxlQUFlO0tBQ2IsU0FBUztLQUFjLE9BQU87S0FBVyxLQUFLO0tBQzlDLE9BQU87S0FBRyxxQkFBcUI7SUFDakM7R0FDRixDQUFDOzs7R0FJRCxHQUFHLElBQUksNEJBQTRCO0lBQ2pDLE1BQU0sUUFBUSxTQUFTLGNBQWMsV0FBVztJQUNoRCxNQUFNLGFBQWEsS0FBSyxJQUFJLEdBQUcsTUFBTSxjQUFjLE9BQU8sYUFBYSxFQUFFO0lBQ3pFLEtBQUssR0FBRyxPQUFPO0tBQ2IsU0FBUyxDQUFDLEtBQUs7S0FBRyxNQUFNO0tBQ3hCLGVBQWU7TUFDYixTQUFTO01BQVMsT0FBTztNQUN6QixXQUFXLE9BQU8sS0FBSztNQUN2QixPQUFPO01BQUcsS0FBSztNQUFNLGVBQWU7TUFBRyxxQkFBcUI7S0FDOUQ7SUFDRixDQUFDO0lBQ0QsS0FBSyxPQUFPLGdCQUFnQixFQUFFLFFBQVEsRUFBRSxHQUFHO0tBQ3pDLFFBQVE7S0FBRyxNQUFNO0tBQ2pCLGVBQWU7TUFDYixTQUFTO01BQVMsT0FBTztNQUN6QixXQUFXLE9BQU8sS0FBSztNQUFHLE9BQU87TUFBRyxxQkFBcUI7S0FDM0Q7SUFDRixDQUFDO0dBQ0gsQ0FBQzs7OztHQUtELEdBQUcsSUFBSSw0QkFBNEI7SUFDakMsY0FBYyxPQUFPO0tBQ25CLFNBQVM7S0FBVyxPQUFPO0tBQVcsS0FBSztLQUMzQyxLQUFLO0tBQWlCLGVBQWU7SUFDdkMsQ0FBQztJQUVELE1BQU0sUUFBUSxLQUFLLE1BQU0sUUFBUSxPQUFPO0lBQ3hDLE1BQU0sYUFBYSxPQUFPLGNBQWM7SUFDeEMsTUFBTSxTQUFTLEdBQUcsTUFBTTtLQUN0QixjQUFjLE9BQU87TUFDbkIsU0FBUztNQUNULGFBQWEsVUFBVSxJQUFJLEtBQUssSUFBSTtNQUNwQyxXQUFXLFdBQVcsSUFBSSxLQUFLLEtBQUssSUFBSTtNQUN4QyxXQUFXLFNBQVM7T0FDbEIsSUFBSSxDQUFDLEtBQUssVUFBVTtPQUNwQixNQUFNLFNBQVMsTUFBTSxFQUFFLFVBQVUsT0FBTyxhQUFhLENBQUM7T0FDdEQsRUFBRSxVQUFVLElBQUksYUFBYTtPQUM3QixRQUFRLENBQUM7T0FDVCxVQUFVLE1BQU0sRUFBRSxDQUFDLE1BQU07TUFDM0I7S0FDRixDQUFDO0lBQ0gsQ0FBQzs7SUFHRCxLQUFLLFNBQVMsRUFDWixlQUFlO0tBQUUsU0FBUztLQUFXLE9BQU87S0FBVyxLQUFLO0tBQVUsT0FBTztJQUFFLEVBQ2pGLENBQUMsQ0FBQyxDQUNDLE9BQU8saUJBQWlCO0tBQUUsR0FBRztLQUFJLFFBQVE7SUFBRSxHQUFHO0tBQUUsR0FBRyxDQUFDO0tBQUksUUFBUSxDQUFDO0tBQUcsTUFBTTtLQUFRLFVBQVU7SUFBRSxDQUFDLENBQUMsQ0FDaEcsR0FBRyxpQkFBaUI7S0FBRSxHQUFHO0tBQUssUUFBUTtLQUFJLFNBQVM7S0FBRyxNQUFNO0tBQWEsVUFBVTtJQUFFLENBQUM7R0FDM0YsQ0FBQzs7R0FHRCxLQUFLLEtBQUssaUJBQWlCO0lBQ3pCLEdBQUc7SUFBSSxTQUFTO0lBQUcsVUFBVTtJQUFLLFNBQVM7SUFBTSxNQUFNO0lBQ3ZELGVBQWU7S0FBRSxTQUFTO0tBQVUsT0FBTztLQUFXLE1BQU07SUFBSztHQUNuRSxDQUFDOztHQUdELE1BQU0sU0FBUyxLQUFLLFNBQVM7SUFDM0IsZUFBZTtLQUFFLFNBQVM7S0FBUyxPQUFPO0tBQVcsTUFBTTtJQUFLO0lBQ2hFLFVBQVU7S0FBRSxVQUFVO0tBQUssTUFBTTtJQUFhO0dBQ2hELENBQUM7R0FDRCxPQUNHLE9BQU8sY0FDTjtJQUFFLEdBQUc7SUFBSSxTQUFTO0lBQUcsU0FBUztJQUFHLE9BQU87SUFBTSxTQUFTO0dBQUUsR0FDekQ7SUFBRSxHQUFHO0lBQUcsU0FBUztJQUFJLFNBQVMsQ0FBQztJQUFHLE9BQU87SUFBSyxTQUFTO0dBQUUsR0FBRyxDQUFDLENBQUMsQ0FDL0QsT0FBTyxlQUNOO0lBQUUsR0FBRyxDQUFDO0lBQUksU0FBUztJQUFHLFNBQVM7SUFBRyxPQUFPO0lBQU0sU0FBUztHQUFFLEdBQzFEO0lBQUUsR0FBRztJQUFHLFNBQVMsQ0FBQztJQUFJLFNBQVM7SUFBRyxPQUFPO0lBQUssU0FBUztHQUFFLEdBQUcsQ0FBQyxDQUFDLENBQy9ELE9BQU8sZ0JBQWdCO0lBQUUsT0FBTztJQUFNLEdBQUc7R0FBRyxHQUFHO0lBQUUsT0FBTztJQUFNLEdBQUcsQ0FBQztHQUFFLEdBQUcsQ0FBQzs7R0FHM0UsS0FBSyxLQUFLLGFBQWE7SUFDckIsR0FBRztJQUFJLFNBQVM7SUFBRyxVQUFVO0lBQUssU0FBUztJQUFNLE1BQU07SUFDdkQsZUFBZTtLQUFFLFNBQVM7S0FBUSxPQUFPO0tBQVcsTUFBTTtJQUFLO0dBQ2pFLENBQUM7RUFDSCxHQUFHLFlBQVk7O0VBR2YsSUFBSSxTQUFTLE9BQU8sT0FBTyxTQUFTLE1BQU0sTUFBTSxXQUFXLGNBQWMsUUFBUSxDQUFDO0VBQ2xGLE1BQU0sZUFBZSxjQUFjLFFBQVE7RUFDM0MsT0FBTyxpQkFBaUIsUUFBUSxNQUFNO0VBQ3RDLE1BQU0sSUFBSSxpQkFBaUIsY0FBYyxRQUFRLEdBQUcsR0FBRztFQUV2RCxhQUFhO0dBQ1gsYUFBYSxDQUFDO0dBQ2QsSUFBSSxPQUFPO0dBQ1gsR0FBRyxPQUFPO0dBQ1YsS0FBSyxPQUFPLE9BQU8sR0FBRztHQUN0QixPQUFPLFFBQVE7R0FDZixPQUFPLG9CQUFvQixVQUFVLFFBQVE7R0FDN0MsT0FBTyxvQkFBb0IsUUFBUSxNQUFNO0VBQzNDO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLGlCQUFpQixNQUFNO0VBQUUsUUFBUSxDQUFDO0VBQUcsVUFBVSxNQUFNLEVBQUUsQ0FBQyxNQUFNO0NBQUc7Q0FFdkUsT0FDRSx3QkFBQyxPQUFEO0VBQUssS0FBSztFQUFjLFdBQVU7RUFDaEMsT0FBTztHQUFFLGlCQUFpQjtHQUFPLE9BQU87R0FBSyxZQUFZO0VBQWlDO1lBRDVGO0dBR0Usd0JBQUMsU0FBRCxZQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1FBc0JDOzs7OztHQUVULHdCQUFDLE9BQUQ7SUFBSyxJQUFHO0lBQWdCLFdBQVU7SUFDaEMsT0FBTyxFQUFFLGlCQUFpQixNQUFNO0dBQUk7Ozs7O0dBR3RDLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLG9FQUNkLFdBQVcsbUNBQW1DO0lBQzVDLE9BQU8sV0FBVztLQUFFLGlCQUFpQixHQUFHLE1BQU07S0FBSyxhQUFhLEdBQUcsSUFBSTtJQUFJLElBQUksQ0FBQztjQUNsRix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFNLElBQUc7TUFBSSxXQUFVO2dCQUF2QixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxLQUFLO09BQU0sS0FBSTtPQUFTLFdBQVU7TUFBMEI7Ozs7Z0JBQ2pFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUFtRCxRQUFJLHdCQUFDLFFBQUQ7UUFBTSxPQUFPLEVBQUUsT0FBTyxNQUFNO2tCQUFHO09BQVE7Ozs7ZUFBTzs7Ozs7Y0FDakc7Ozs7O2VBQ04sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQU0sSUFBRztPQUFTLFdBQVU7T0FDMUIsT0FBTyxFQUFFLE9BQU8sR0FBRyxJQUFJLElBQUk7aUJBQUc7TUFFMUI7Ozs7Z0JBQ04sd0JBQUMsVUFBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO09BQ1AsV0FBVTtPQUNWLE9BQU8sRUFBRSxpQkFBaUIsSUFBSTtPQUM5QixlQUFlLE1BQU8sRUFBRSxjQUFjLE1BQU0sa0JBQWtCO09BQzlELGVBQWUsTUFBTyxFQUFFLGNBQWMsTUFBTSxrQkFBa0I7aUJBQy9EO01BRUs7Ozs7ZUFDRTs7OztjQUNQOzs7OzthQUNGOzs7Ozs7R0FDRjs7Ozs7R0FHTCx3QkFBQyxXQUFEO0lBQVMsSUFBRztJQUFPLFdBQVU7Y0FDM0Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtPQUNYLE9BQU8sRUFBRSxPQUFPLE1BQU07aUJBRHhCLENBRUUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7UUFBMkIsT0FBTyxFQUFFLGlCQUFpQixNQUFNO09BQUk7Ozs7aUJBQUMsaUNBRS9FOzs7Ozs7TUFDSCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE2Qix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBa0I7UUFBb0I7Ozs7O09BQU87Ozs7aUJBQzFHLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNkLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNkLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO1VBQWtDLE9BQU8sRUFBRSxPQUFPLE1BQU07b0JBQUc7U0FBcUI7Ozs7O1FBQzVGOzs7OztPQUNGOzs7O2VBQ0o7Ozs7OztNQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO09BQW1ELE9BQU8sRUFBRSxPQUFPLEdBQUcsSUFBSSxJQUFJO2lCQUFHO01BRzNGOzs7OztNQUNILHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsVUFBRDtTQUFVLFdBQVU7bUJBQ2xCLHdCQUFDLEtBQUQ7VUFBRyxNQUFNO1VBQVMsVUFBUztVQUFxQixRQUFPO1VBQVMsS0FBSTtVQUNsRSxXQUFVO1VBQ1YsT0FBTyxFQUFFLGlCQUFpQixNQUFNO1VBQ2hDLGVBQWUsTUFBTyxFQUFFLGNBQWMsTUFBTSxrQkFBa0I7VUFDOUQsZUFBZSxNQUFPLEVBQUUsY0FBYyxNQUFNLGtCQUFrQjtvQkFKaEU7V0FNRSx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztXQUFDO1dBQXFCLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O1VBQ3JFOzs7Ozs7UUFDSzs7Ozs7UUFFVix3QkFBQyxVQUFEO1NBQVUsV0FBVTttQkFDbEIsd0JBQUMsS0FBRDtVQUFHLE1BQU07VUFBUyxVQUFTO1VBQStCLFFBQU87VUFBUyxLQUFJO1VBQzVFLFdBQVU7VUFDVixPQUFPLEVBQUUsaUJBQWlCLElBQUk7VUFDOUIsZUFBZSxNQUFPLEVBQUUsY0FBYyxNQUFNLGtCQUFrQjtVQUM5RCxlQUFlLE1BQU8sRUFBRSxjQUFjLE1BQU0sa0JBQWtCO29CQUpoRTtXQU1FLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O1dBQUM7V0FBMkIsd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7Ozs7VUFDekU7Ozs7OztRQUNLOzs7OztRQUVWLHdCQUFDLFVBQUQ7U0FBVSxXQUFVO1NBQTRCLFVBQVU7bUJBQ3hELHdCQUFDLE1BQUQ7VUFBTSxJQUFHO1VBQ1AsV0FBVTtVQUNWLE9BQU87V0FBRSxhQUFhLEdBQUcsSUFBSTtXQUFLLE9BQU87VUFBSTtVQUM3QyxlQUFlLE1BQU07V0FBRSxFQUFFLGNBQWMsTUFBTSxjQUFjLEdBQUcsSUFBSTtXQUFLLEVBQUUsY0FBYyxNQUFNLGtCQUFrQixHQUFHLElBQUk7VUFBSztVQUMzSCxlQUFlLE1BQU07V0FBRSxFQUFFLGNBQWMsTUFBTSxjQUFjLEdBQUcsSUFBSTtXQUFLLEVBQUUsY0FBYyxNQUFNLGtCQUFrQjtVQUFlO29CQUpoSSxDQU1FLHdCQUFDLE9BQUQ7V0FBTyxNQUFNO1dBQUksT0FBTyxFQUFFLE9BQU8sR0FBRyxJQUFJLElBQUk7VUFBSTs7OztvQkFBQyxrQkFDN0M7Ozs7OztRQUNFOzs7OztPQUNQOzs7Ozs7TUFDTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtPQUFxQyxPQUFPLEVBQUUsT0FBTyxHQUFHLElBQUksSUFBSTtpQkFBN0U7UUFBZ0Y7UUFFOUUsd0JBQUMsUUFBRDtTQUFNLFdBQVU7U0FBUyxPQUFPLEVBQUUsT0FBTyxNQUFNO21CQUFHO1FBQU87Ozs7O1FBQUM7UUFFMUQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7U0FBUyxPQUFPLEVBQUUsT0FBTyxNQUFNO21CQUFHO1FBQU87Ozs7O1FBQUM7T0FFekQ7Ozs7OztLQUNBOzs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBcUMsT0FBTyxFQUFFLGFBQWEsU0FBUztnQkFDakYsd0JBQUMsT0FBRDtPQUFLLEtBQUs7aUJBQ1Isd0JBQUMsT0FBRDtRQUFLLEtBQUs7a0JBQ1Isd0JBQUMsT0FBRDtTQUFLLEtBQUs7bUJBQ1Isd0JBQUMsT0FBRDtVQUFLLFdBQVU7VUFBcUIsYUFBYTtVQUFpQixjQUFjO29CQUFoRixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQ2IsT0FBTyxFQUFFLGlCQUFpQixHQUFHLE1BQU0sSUFBSTtVQUFJOzs7O29CQUM3Qyx3QkFBQyxPQUFEO1dBQUssS0FBSztXQUNSLFdBQVU7V0FDVixPQUFPO1lBQ0wsZ0JBQWdCO1lBQ2hCLFlBQVk7WUFDWixXQUFXO1dBQ2I7cUJBTkYsQ0FRRSx3QkFBQyxPQUFEO1lBQUssS0FBSztZQUNSLFdBQVU7WUFDVixPQUFPLEVBQUUsWUFBWSxpRkFBaUY7V0FDdkc7Ozs7cUJBQ0Qsd0JBQUMsT0FBRDtZQUFLLFdBQVU7WUFDYixPQUFPLEVBQUUsaUJBQWlCLFVBQVU7c0JBRHRDO2FBRUUsd0JBQUMsT0FBRDtjQUFLLFdBQVU7Y0FDYixPQUFPLEVBQUUsaUJBQWlCLFVBQVU7d0JBQ3BDLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO2VBQTJCLE9BQU8sRUFBRSxpQkFBaUIsR0FBRyxNQUFNLElBQUk7Y0FBSTs7Ozs7YUFDbEY7Ozs7O2FBRUwsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDRSx3QkFBQyxPQUFEO2VBQUssV0FBVTtlQUE0QixPQUFPLEVBQUUsaUJBQWlCLHlCQUF5Qjt5QkFDM0YsQ0FBQyxDQUFDLFFBQVEsTUFBTSxHQUFHLENBQUMsVUFBVSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLFdBQ2xELHdCQUFDLFVBQUQ7Z0JBQWlCLGVBQWUsVUFBVSxFQUFFO2dCQUMxQyxXQUFXLGlGQUFpRixXQUFXLEtBQUssZUFBZTtnQkFDM0gsT0FBTyxXQUFXLEtBQUssRUFBRSxpQkFBaUIsTUFBTSxJQUFJLENBQUM7MEJBQ3BEO2VBQ0ssR0FKSzs7OztzQkFJTCxDQUNUO2NBQ0U7Ozs7d0JBQ0wsd0JBQUMsUUFBRDtlQUFNLFdBQVU7ZUFBNEQsT0FBTyxFQUFFLE9BQU8sTUFBTTt5QkFBbEcsQ0FDRSx3QkFBQyxRQUFEO2dCQUFNLFdBQVU7Z0JBQTJCLE9BQU8sRUFBRSxpQkFBaUIsTUFBTTtlQUFJOzs7O3lCQUFDLE9BQzVFOzs7OztzQkFDSDs7Ozs7O2FBRUosV0FBVyxTQUNWLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO2NBQ2IsT0FBTztlQUFFLGlCQUFpQjtlQUEwQixRQUFRO2NBQW1DO3dCQURqRztlQUVFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO2dCQUFHLFdBQVU7MEJBQStCO2VBQXNCOzs7O3lCQUNsRSx3QkFBQyxLQUFEO2dCQUFHLFdBQVU7MEJBQW9DO2VBQXFCOzs7O3VCQUNuRTs7Ozs7ZUFDTCx3QkFBQyxLQUFEO2dCQUFHLFdBQVU7MEJBQTZCO2VBQWtDOzs7OztlQUM1RSx3QkFBQyxPQUFEO2dCQUFLLFdBQVU7MEJBQWYsQ0FDRSx3QkFBQyxPQUFEO2lCQUFLLFdBQVU7aUJBQ2IsT0FBTyxFQUFFLGlCQUFpQixNQUFNOzJCQURsQyxDQUVFLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7MkJBQUMsU0FDaEI7Ozs7OzBCQUNKO2lCQUFDO2lCQUFTO2lCQUFVO2dCQUFNLENBQUMsQ0FBQyxLQUFLLE1BQ2hDLHdCQUFDLE9BQUQ7aUJBQWEsV0FBVTtpQkFDckIsT0FBTyxFQUFFLGlCQUFpQix5QkFBeUI7MkJBQUk7Z0JBQU8sR0FEdEQ7Ozs7dUJBQ3NELENBQ2pFLENBQ0U7Ozs7OztjQUNGOzs7Ozt3QkFFTCx3QkFBQyxPQUFEO2NBQUssV0FBVTtjQUNiLE9BQU87ZUFBRSxpQkFBaUI7ZUFBMEIsUUFBUTtjQUErQjt3QkFEN0Y7ZUFFRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtnQkFBRyxXQUFVOzBCQUErQjtlQUF3Qjs7Ozt5QkFDcEUsd0JBQUMsS0FBRDtnQkFBRyxXQUFVOzBCQUFvQztlQUF3Qjs7Ozt1QkFDdEU7Ozs7O2VBQ0wsd0JBQUMsS0FBRDtnQkFBRyxXQUFVOzBCQUE2QjtlQUFrQzs7Ozs7ZUFDNUUsd0JBQUMsT0FBRDtnQkFBSyxXQUFVOzBCQUFmLENBQ0Usd0JBQUMsT0FBRDtpQkFBSyxXQUFVO2lCQUNiLE9BQU8sRUFBRSxpQkFBaUIsTUFBTTsyQkFBRztnQkFBaUI7Ozs7MEJBQ3RELHdCQUFDLE9BQUQ7aUJBQUssV0FBVTtpQkFDYixPQUFPLEVBQUUsaUJBQWlCLHlCQUF5QjsyQkFBRztnQkFBVTs7Ozt3QkFDL0Q7Ozs7OztjQUNGOzs7Ozs7YUFHUCx3QkFBQyxPQUFEO2NBQUssV0FBVTtjQUNiLE9BQU87ZUFBRSxpQkFBaUIsR0FBRyxNQUFNO2VBQUssUUFBUSxhQUFhLE1BQU07Y0FBSTt3QkFEekUsQ0FFRSx3QkFBQyxRQUFEO2VBQU0sV0FBVTtlQUEwQixPQUFPLEVBQUUsT0FBTyxNQUFNO3lCQUFHO2NBQTJCOzs7O3dCQUM5Rix3QkFBQyxPQUFEO2VBQU8sTUFBTTtlQUFJLE9BQU8sRUFBRSxPQUFPLE1BQU07Y0FBSTs7OztzQkFDeEM7Ozs7OzthQUVMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO2NBQ2IsT0FBTyxFQUFFLFdBQVcsbUNBQW1DO3dCQUR6RCxDQUVFLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7Ozt3QkFDdEIsd0JBQUMsUUFBRDtlQUFNLE9BQU8sRUFBRSxPQUFPLE1BQU07eUJBQUc7Y0FBZTs7OztzQkFDM0M7Ozs7OztZQUNGOzs7OzttQkFDRjs7Ozs7a0JBQ0Y7Ozs7OztRQUNGOzs7OztPQUNGOzs7OztNQUNGOzs7OztLQUNGOzs7O2FBQ0Y7Ozs7OztHQUNFOzs7OztHQUdULHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQ0csYUFBYSxLQUFLLE1BQU0sTUFDdkIsd0JBQUMsT0FBRDtLQUFhLFdBQVU7S0FDckIsT0FBTztNQUFFLGlCQUFpQixJQUFJLE1BQU0sSUFBSSxPQUFPO01BQU8sUUFBUSxJQUFJO0tBQUU7ZUFDcEUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtPQUFvRCxPQUFPLEVBQUUsT0FBTyxNQUFNO2lCQUF2RjtRQUEwRjtRQUN6RSxJQUFJO1FBQUU7UUFBTyxhQUFhO09BQ3hDOzs7OztnQkFDSCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBcUU7TUFBUTs7OztjQUN2Rjs7Ozs7O0lBQ0YsR0FSSzs7OztXQVFMLENBQ04sR0FDRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUNiLE9BQU87TUFBRSxpQkFBaUI7TUFBTyxRQUFRLGFBQWEsU0FBUztLQUFFO2VBQ2pFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7T0FBb0QsT0FBTyxFQUFFLE9BQU8sWUFBWTtpQkFBRztNQUU3Rjs7OztnQkFDSCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUFnRztRQUNqRjtRQUNiLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFrQztRQUFrQjs7Ozs7T0FDbkU7Ozs7O2NBQ0E7Ozs7OztJQUNGOzs7O1lBQ0U7Ozs7OztHQUdULHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQVksV0FBVTtJQUErQixPQUFPO0tBQUUsaUJBQWlCO0tBQU8sUUFBUTtJQUFHO2NBQzNHLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtNQUE4RCxPQUFPLEVBQUUsT0FBTyxNQUFNO2dCQUFHO0tBRWpHOzs7O2VBQ0gsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsVUFBVSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUM1Qix3QkFBQyxRQUFEO09BQWMsV0FBVTtpQkFBa0M7TUFBUSxHQUF2RDs7OzthQUF1RCxDQUNuRTtLQUNBOzs7O2FBQ0E7Ozs7OztHQUNFOzs7OztHQUdULHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQU8sV0FBVTtJQUFXLE9BQU87S0FBRSxpQkFBaUI7S0FBTSxRQUFRO0lBQUc7Y0FBbkYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUEyRSxPQUFPLEVBQUUsaUJBQWlCLE1BQU07SUFBSTs7OztjQUM5SCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7T0FBOEQsT0FBTyxFQUFFLE9BQU8sTUFBTTtpQkFBRztNQUVqRzs7OztnQkFDSCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUEyRjtRQUMzRSx3QkFBQyxNQUFELENBQUs7Ozs7O1FBQ25CLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO1NBQWtDLE9BQU8sRUFBRSxPQUFPLE1BQU07bUJBQUc7UUFBZ0I7Ozs7O09BQ3pGOzs7OztjQUNEOzs7O2dCQUNMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO09BQWtGLE9BQU8sRUFBRSxPQUFPLEdBQUcsSUFBSSxJQUFJO2lCQUExSCxDQUE2SCxXQUNwSCx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O2VBQy9COzs7OztjQUNBOzs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLFNBQVMsS0FBSyxTQUNiLHdCQUFDLFdBQUQ7T0FDRSxXQUFVO09BQ1YsT0FBTztRQUFFLGlCQUFpQjtRQUFPLGFBQWEsR0FBRyxJQUFJO09BQUk7T0FDekQsZUFBZSxNQUFPLEVBQUUsY0FBYyxNQUFNLGNBQWMsR0FBRyxNQUFNO09BQ25FLGVBQWUsTUFBTyxFQUFFLGNBQWMsTUFBTSxjQUFjLEdBQUcsSUFBSTtpQkFKbkU7UUFNRSx3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUNiLE9BQU8sRUFBRSxPQUFPLEdBQUcsSUFBSSxJQUFJO21CQUMxQixLQUFLO1FBQ0g7Ozs7O1FBQ0wsd0JBQUMsS0FBRDtTQUFHLFdBQVU7U0FBdUMsT0FBTyxFQUFFLE9BQU8sTUFBTTttQkFBSSxLQUFLO1FBQU87Ozs7O1FBQzFGLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QyxLQUFLO1FBQVU7Ozs7O1FBQ3RFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO1NBQW1DLE9BQU8sRUFBRSxPQUFPLEdBQUcsSUFBSSxJQUFJO21CQUFJLEtBQUs7UUFBUTs7Ozs7T0FDckY7U0FiSyxLQUFLOzs7O2FBYVYsQ0FDVjtLQUNFOzs7O2FBQ0Y7Ozs7O1lBQ0U7Ozs7OztHQUdULHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQVMsV0FBVTtJQUFXLE9BQU87S0FBRSxpQkFBaUI7S0FBTyxRQUFRO0lBQUc7Y0FDcEYsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0csTUFBTSxLQUFLLEdBQUcsTUFDYix3QkFBQyxPQUFEO1FBQ0UsV0FBVyxRQUFRLE1BQU0sSUFBSSxnQkFBZ0IsR0FBRztRQUNoRCxlQUFlLGNBQWMsQ0FBQztrQkFGaEM7U0FHRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtVQUFvRCxPQUFPLEVBQUUsT0FBTyxNQUFNO29CQUF2RjtXQUNHLEVBQUU7V0FBSTtXQUFJLE1BQU07V0FBTztVQUN2Qjs7Ozs7O1NBQ0gsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FDRyxFQUFFLE9BQ0gsd0JBQUMsUUFBRDtXQUFNLFdBQVU7V0FBa0MsT0FBTyxFQUFFLE9BQU8sTUFBTTtxQkFBRztVQUFPOzs7O2tCQUNoRjs7Ozs7O1NBQ0osd0JBQUMsS0FBRDtVQUFHLFdBQVU7VUFBNEIsT0FBTyxFQUFFLE9BQU8sR0FBRyxJQUFJLElBQUk7b0JBQUksRUFBRTtTQUFROzs7OztRQUMvRTtVQVhLLEVBQUU7Ozs7Y0FXUCxDQUNOLEdBQ0Qsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osTUFBTSxLQUFLLEdBQUcsTUFDYix3QkFBQyxRQUFEO1NBQWtCLFdBQVU7U0FDMUIsT0FBTztVQUNMLE9BQU8sU0FBUyxJQUFJLEtBQUs7VUFDekIsaUJBQWlCLFNBQVMsSUFBSSxRQUFRLEdBQUcsSUFBSTtTQUMvQztRQUFJLEdBSkssRUFBRTs7OztlQUlQLENBQ1A7T0FDRTs7OztlQUNGOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUFnQyxPQUFPLEVBQUUsYUFBYSxTQUFTO2lCQUM1RSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxZQUFELEVBQW9CLE9BQVM7Ozs7O09BQzFCOzs7OztNQUNGOzs7O2NBQ0Y7Ozs7OztJQUNGOzs7OztHQUNFOzs7OztHQUdULHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQVEsV0FBVTtJQUErQixPQUFPO0tBQUUsaUJBQWlCO0tBQU8sUUFBUTtJQUFHO2NBQ3ZHLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtPQUFxRCxPQUFPLEVBQUUsT0FBTyxNQUFNO2lCQUFHO01BRXhGOzs7OztNQUNILHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQXlFO1FBQ25EO1FBQ3BCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO1NBQWtDLE9BQU8sRUFBRSxPQUFPLE1BQU07bUJBQUc7UUFBa0I7Ozs7O09BQzNGOzs7Ozs7TUFDSix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixTQUFTLEtBQUssTUFDYix3QkFBQyxXQUFEO1FBQ0UsV0FBVTtRQUNWLE9BQU87U0FBRSxhQUFhLEdBQUcsSUFBSTtTQUFLLFdBQVc7UUFBZ0M7UUFDN0UsZUFBZSxNQUFPLEVBQUUsY0FBYyxNQUFNLGNBQWMsR0FBRyxNQUFNO1FBQ25FLGVBQWUsTUFBTyxFQUFFLGNBQWMsTUFBTSxjQUFjLEdBQUcsSUFBSTtrQkFKbkU7U0FNRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtVQUNiLE9BQU87V0FBRSxpQkFBaUIsR0FBRyxNQUFNO1dBQUssT0FBTztVQUFNO29CQUNyRCx3QkFBQyxFQUFFLE1BQUgsRUFBUSxNQUFNLEdBQUs7Ozs7O1NBQ2hCOzs7OztTQUNMLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixFQUFFO1NBQVU7Ozs7O1NBQ3hELHdCQUFDLEtBQUQ7VUFBRyxXQUFVO1VBQTBCLE9BQU8sRUFBRSxPQUFPLEdBQUcsSUFBSSxJQUFJO29CQUFJLEVBQUU7U0FBUTs7Ozs7UUFDekU7VUFaSyxFQUFFOzs7O2NBWVAsQ0FDVjtNQUNFOzs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQTZDLE9BQU8sRUFBRSxXQUFXLGFBQWEsSUFBSSxJQUFJO2lCQUFyRztRQUNFLHdCQUFDLE1BQUQ7U0FBTSxPQUFPO1NBQUcsUUFBTztTQUFTLE9BQU07UUFBeUM7Ozs7O1FBQy9FLHdCQUFDLE1BQUQ7U0FBTSxPQUFPO1NBQUssUUFBTztTQUFJLE9BQU07UUFBc0M7Ozs7O1FBQ3pFLHdCQUFDLE1BQUQ7U0FBTSxPQUFPO1NBQUcsUUFBTztTQUFRLE9BQU07UUFBb0M7Ozs7O09BQ3RFOzs7Ozs7S0FDRjs7Ozs7O0dBQ0U7Ozs7O0dBR1Qsd0JBQUMsV0FBRDtJQUFTLElBQUc7SUFBTSxXQUFVO0lBQStCLE9BQU87S0FBRSxpQkFBaUI7S0FBTyxRQUFRO0lBQUc7Y0FDckcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUF1RTtLQUVqRjs7OztlQUNKLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLEtBQUssS0FBSyxLQUFLLE1BQU07T0FDcEIsTUFBTSxPQUFPLFlBQVk7T0FDekIsT0FDRSx3QkFBQyxPQUFEO1FBQWEsV0FBVTtRQUNyQixPQUFPLEVBQUUsYUFBYSxPQUFPLEdBQUcsTUFBTSxNQUFNLEdBQUcsSUFBSSxJQUFJO2tCQUR6RCxDQUVFLHdCQUFDLFVBQUQ7U0FBUSxlQUFlLFdBQVcsT0FBTyxPQUFPLENBQUM7U0FDL0MsV0FBVTtTQUNWLE9BQU8sRUFBRSxPQUFPLE9BQU8sUUFBUSxJQUFJO21CQUZyQyxDQUdFLHdCQUFDLFFBQUQsWUFBTyxJQUFJLEVBQVE7Ozs7bUJBQ25CLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQ2IsT0FBTztXQUNMLFdBQVcsT0FBTyxtQkFBbUI7V0FDckMsaUJBQWlCLE9BQU8sR0FBRyxNQUFNLE1BQU0sR0FBRyxJQUFJO1dBQzlDLE9BQU8sT0FBTyxRQUFRLEdBQUcsSUFBSTtVQUMvQjtvQkFDQSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztTQUNyQjs7OztpQkFDQzs7Ozs7a0JBQ1Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FDYixPQUFPO1VBQUUsa0JBQWtCLE9BQU8sUUFBUTtVQUFPLFNBQVMsT0FBTyxJQUFJO1NBQUU7bUJBQ3ZFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO1dBQ1gsT0FBTztZQUFFLE9BQU8sR0FBRyxJQUFJO1lBQUssV0FBVyxhQUFhLElBQUk7V0FBSTtxQkFDM0QsSUFBSTtVQUNKOzs7OztTQUNBOzs7OztRQUNGOzs7O2dCQUNGO1VBeEJLOzs7O2NBd0JMO01BRVQsQ0FBQztLQUNFOzs7O2FBQ0Y7Ozs7OztHQUNFOzs7OztHQUdULHdCQUFDLFdBQUQ7SUFBUyxXQUFVO0lBQ2pCLE9BQU87S0FBRSxRQUFRO0tBQVMsWUFBWSwyQkFBMkIsTUFBTSxPQUFPLEtBQUssUUFBUSxLQUFLO0tBQVMsUUFBUTtJQUFHO2NBRHRIO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtRQUE4RCxPQUFPLEVBQUUsT0FBTyxNQUFNO2tCQUFHO09BRWpHOzs7OztPQUNILHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkO1NBQTRHO1NBQzlGO1NBQ1osd0JBQUMsUUFBRDtVQUFNLFdBQVU7VUFBa0MsT0FBTyxFQUFFLE9BQU8sTUFBTTtvQkFBRztTQUFtQjs7Ozs7UUFDNUY7Ozs7OztPQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO1FBQXNFLE9BQU8sRUFBRSxPQUFPLFlBQVk7a0JBQUc7T0FHL0c7Ozs7O09BQ0gsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FFRSx3QkFBQyxVQUFELFlBQ0Usd0JBQUMsS0FBRDtVQUFHLE1BQU07VUFBUyxVQUFTO1VBQXFCLFFBQU87VUFBUyxLQUFJO1VBQ2xFLFdBQVU7VUFDVixPQUFPO1dBQUUsaUJBQWlCO1dBQU8sT0FBTztVQUFVO1VBQ2xELGVBQWUsTUFBTyxFQUFFLGNBQWMsTUFBTSxrQkFBa0I7VUFDOUQsZUFBZSxNQUFPLEVBQUUsY0FBYyxNQUFNLGtCQUFrQjtvQkFKaEUsQ0FNRSx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7O29CQUFDLHNCQUN2Qjs7Ozs7a0JBQ0s7Ozs7O1NBRVYsd0JBQUMsVUFBRCxZQUNFLHdCQUFDLEtBQUQ7VUFBRyxNQUFNO1VBQVMsVUFBUztVQUErQixRQUFPO1VBQVMsS0FBSTtVQUM1RSxXQUFVO1VBQ1YsT0FBTztXQUFFLGlCQUFpQjtXQUFLLE9BQU87VUFBVTtVQUNoRCxlQUFlLE1BQU8sRUFBRSxjQUFjLE1BQU0sa0JBQWtCO1VBQzlELGVBQWUsTUFBTyxFQUFFLGNBQWMsTUFBTSxrQkFBa0I7b0JBSmhFLENBTUUsd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OztvQkFBQyw0QkFDckI7Ozs7O2tCQUNLOzs7OztTQUNWLHdCQUFDLE1BQUQ7VUFBTSxJQUFHO1VBQ1AsV0FBVTtVQUNWLE9BQU87V0FBRSxhQUFhO1dBQWEsT0FBTztVQUFZO1VBQ3RELGVBQWUsTUFBTTtXQUFFLEVBQUUsY0FBYyxNQUFNLGNBQWM7V0FBYSxFQUFFLGNBQWMsTUFBTSxrQkFBa0I7VUFBYTtVQUM3SCxlQUFlLE1BQU07V0FBRSxFQUFFLGNBQWMsTUFBTSxjQUFjO1dBQWEsRUFBRSxjQUFjLE1BQU0sa0JBQWtCO1VBQWU7b0JBSmpJLENBS0Msa0JBQ2Usd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztrQkFDbkM7Ozs7OztRQUNIOzs7Ozs7TUFDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLElBQUc7TUFBTyxXQUFVO01BQ3ZCLE9BQU8sRUFBRSxhQUFhLFNBQVM7Z0JBRGpDO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFDYixPQUFPLEVBQUUsWUFBWSxvREFBb0Q7a0JBQ3pFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQ2IsT0FBTyxFQUFFLGlCQUFpQixVQUFVO21CQUR0QztVQUVFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQWlDLE9BQU8sRUFBRSxpQkFBaUIsWUFBWTtVQUFJOzs7OztVQUMxRix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBc0M7VUFBb0I7Ozs7O1VBQ3pFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQ2IsT0FBTztZQUFFLGlCQUFpQixHQUFHLE1BQU07WUFBSyxRQUFRLGFBQWEsTUFBTTtZQUFLLE9BQU87V0FBTTtxQkFBRztVQUVyRjs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUEwQixPQUFPLEVBQUUsaUJBQWlCLHdCQUF3QjtVQUFJOzs7OztTQUM1Rjs7Ozs7O09BQ0Y7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFDYixPQUFPO1NBQUUsWUFBWTtTQUFxRCxXQUFXO1FBQThCO2tCQUNuSCx3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUNiLE9BQU8sRUFBRSxpQkFBaUIsVUFBVTttQkFEdEM7VUFFRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUFnQyxPQUFPLEVBQUUsaUJBQWlCLFVBQVU7VUFBSTs7Ozs7VUFDdkYsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBK0I7V0FBa0I7Ozs7cUJBQ2hFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO1lBQ2IsT0FBTzthQUFFLGlCQUFpQixHQUFHLE1BQU07YUFBSyxRQUFRLGFBQWEsTUFBTTthQUFLLE9BQU87WUFBTTtzQkFBRztXQUVyRjs7OzttQkFDRjs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7V0FDYixPQUFPLEVBQUUsaUJBQWlCLE1BQU07cUJBQUc7VUFFaEM7Ozs7O1NBQ0Y7Ozs7OztPQUNGOzs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQ2IsT0FBTyxFQUFFLFlBQVksb0RBQW9EO2tCQUN6RSx3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUNiLE9BQU8sRUFBRSxpQkFBaUIsVUFBVTttQkFEdEM7VUFFRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUFpQyxPQUFPLEVBQUUsaUJBQWlCLFlBQVk7VUFBSTs7Ozs7VUFDMUYsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQXNDO1VBQVk7Ozs7O1VBQ2pFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQ2IsT0FBTyxFQUFFLGlCQUFpQix5QkFBeUI7cUJBQ25ELHdCQUFDLFFBQUQ7WUFBUSxNQUFNO1lBQUksT0FBTyxFQUFFLE9BQU8sTUFBTTtXQUFJOzs7OztVQUN6Qzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUEwQixPQUFPLEVBQUUsaUJBQWlCLHdCQUF3QjtVQUFJOzs7OztTQUM1Rjs7Ozs7O09BQ0Y7Ozs7O01BQ0Y7Ozs7OztLQUdMLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQTBCLE9BQU8sRUFBRSxpQkFBaUIsS0FBSztnQkFDekUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FDYixPQUFPO1FBQUUsT0FBTztRQUFhLFdBQVc7UUFBb0MsWUFBWTtPQUFVO2lCQURwRyxDQUVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLEtBQUs7VUFBTSxLQUFJO1VBQVMsV0FBVTtTQUFxQzs7Ozs7U0FDNUUsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZCO1NBQVk7Ozs7O1NBQ3pELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFPO1NBQU87Ozs7O1NBQzlCLHdCQUFDLFFBQUQsYUFBTSxNQUFHLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFROzs7OztRQUNyQzs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxNQUFEO1VBQU0sSUFBRztVQUFTLFdBQVU7b0JBQXlDO1NBQVc7Ozs7O1NBQ2hGLHdCQUFDLE1BQUQ7VUFBTSxJQUFHO1VBQVksV0FBVTtvQkFBeUM7U0FBWTs7Ozs7U0FDcEYsd0JBQUMsS0FBRDtVQUFHLE1BQU07VUFBUyxRQUFPO1VBQVMsS0FBSTtVQUFzQixXQUFVO29CQUF5QztTQUFtQjs7Ozs7UUFDL0g7Ozs7O2VBQ0Y7Ozs7OztLQUNDOzs7OztJQUNEOzs7Ozs7RUFFTjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTGFuZGluZ1BhZ2UuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IGdzYXAgZnJvbSAnZ3NhcCc7XG5pbXBvcnQgeyBTY3JvbGxUcmlnZ2VyIH0gZnJvbSAnZ3NhcC9TY3JvbGxUcmlnZ2VyJztcbmltcG9ydCBMZW5pcyBmcm9tICdAc3R1ZGlvLWZyZWlnaHQvbGVuaXMnO1xuaW1wb3J0IHtcbiAgQXJyb3dVcFJpZ2h0LCBTbWFydHBob25lLCBDaGVjaywgQ2hldnJvbkRvd24sXG4gIExheWVycywgQmFyQ2hhcnQyLCBRckNvZGUsIEdsb2JlLCBEb3dubG9hZCwgUGx1c1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgaXNBdXRoZW50aWNhdGVkIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgbG9nbyBmcm9tIFwiLi4vLi4vYXNzZXRzL2xvZ28ucG5nXCI7XG5cbmdzYXAucmVnaXN0ZXJQbHVnaW4oU2Nyb2xsVHJpZ2dlcik7XG5TY3JvbGxUcmlnZ2VyLmNvbmZpZyh7IGlnbm9yZU1vYmlsZVJlc2l6ZTogdHJ1ZSB9KTtcblxuLyog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICBQQUxFVCDigJQga3JlbSBoYW5nYXQgKyBoaWphdSAod2FybmEgYXBwKVxu4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5jb25zdCBDUkVBTSA9ICcjRjZGNEVEJztcbmNvbnN0IElOSyA9ICcjMUMyNjIwJztcbmNvbnN0IEdSRUVOID0gJyMxNTdBNEUnO1xuY29uc3QgR1JFRU5fREVFUCA9ICcjMEU1QTNBJztcbmNvbnN0IERBUksgPSAnIzBEMUYxNyc7XG5jb25zdCBUSU5UID0gJyNFQ0VGRTQnO1xuY29uc3QgTElHSFQgPSAnIzVCQzk4Qyc7XG5cbi8qIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgREFUQVxu4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5jb25zdCBSSVRVQUxfTElORVMgPSBbXG4gICdCdWthIGxhcHRvcCwgdHVuZ2d1IGxvYWRpbmcuJyxcbiAgJ1JhbmNhbmcgZm9ybXVsaXIgZGFyaSBub2wuJyxcbiAgJ1RlbXBlbCBsaW5rIGtlIHRpYXAgZ3J1cCBjaGF0LicsXG4gICdTdXN1biBuaWxhaSBtYW51YWwgZGkgc3ByZWFkc2hlZXQuJyxcbiAgJ1VsYW5naSBzZW11YW55YSBiZXNvayBwYWdpLicsXG5dO1xuXG5jb25zdCBXT1JLRkxPVyA9IFtcbiAgeyBudW06ICcwMScsIHRpdGxlOiAnUmFuY2FuZycsXG4gICAgZGVzYzogJ1BpbGloYW4gZ2FuZGEsIGVzc2F5LCBhdGF1IHNrYWxhIHBlbmlsYWlhbiDigJQgbGVuZ2thcCBkZW5nYW4gYm9ib3QgbmlsYWkgcGVyIHNvYWwuJyB9LFxuICB7IG51bTogJzAyJywgdGl0bGU6ICdBdHVyJyxcbiAgICBkZXNjOiAnQmF0YXMgd2FrdHUsIGFjYWsgdXJ1dGFuIHNvYWwsIGRhbiBiYXRhc2kgc2F0dSBrYWxpIHBlbmdpc2lhbiBwZXIgcmVzcG9uZGVuLicgfSxcbiAgeyBudW06ICcwMycsIHRpdGxlOiAnQmFnaWthbicsXG4gICAgZGVzYzogJ0xpbmsgcGVuZGVrIGRhbiBRUiBjb2RlIHNpYXAgZGl0YW1waWxrYW4gZGkgcHJveWVrdG9yLCBwYXBhbiB0dWxpcywgYXRhdSBzdG9yeS4nIH0sXG4gIHsgbnVtOiAnMDQnLCB0aXRsZTogJ1BhbnRhdScsXG4gICAgZGVzYzogJ1Jla2FwIG5pbGFpIGRhbiBncmFmaWsgamF3YWJhbiB0ZXJoaXR1bmcgb3RvbWF0aXMuIEVrc3BvciBrZSBDU1YgLyBYTFNYIHNhdHUga2xpay4nIH0sXG5dO1xuXG5jb25zdCBCRUFUUyA9IFtcbiAgeyBudW06ICcwMScsIHNjcmVlbjogJ2J1aWxkJywgdGl0bGU6ICdSYW5jYW5nJyxcbiAgICBkZXNjOiAnU3VzdW4ga3VpcyBhdGF1IHN1cnZlaSBsZXdhdCBidWlsZGVyIHlhbmcgcmluZ2FuIOKAlCB0ZXJzZWRpYSBkaSB3ZWIgZGFuIGFwbGlrYXNpIEFuZHJvaWQuJyB9LFxuICB7IG51bTogJzAyJywgc2NyZWVuOiAnc2hhcmUnLCB0aXRsZTogJ0JhZ2lrYW4nLFxuICAgIGRlc2M6ICdTYXR1IGxpbmssIHNhdHUgUVIgY29kZS4gUGVzZXJ0YSBtZW5naXNpIGxld2F0IGJyb3dzZXIgdGFucGEgcGVybHUgbWVtYXNhbmcgYXBhIHB1bi4nIH0sXG4gIHsgbnVtOiAnMDMnLCBzY3JlZW46ICd0cmFjaycsIHRpdGxlOiAnUGFudGF1JyxcbiAgICBkZXNjOiAnUmVzcG9ucyBtYXN1ayByZWFsLXRpbWUuIE5pbGFpIGRhbiBncmFmaWsgdGVyaGl0dW5nIG90b21hdGlzLCBzaWFwIGRpZWtzcG9yIGthcGFuIHB1bi4nIH0sXG5dO1xuXG5jb25zdCBGRUFUVVJFUyA9IFtcbiAgeyBpY29uOiBMYXllcnMsIHRpdGxlOiAnRm9ybSBidWlsZGVyIHlhbmcgcmluZ2FuJyxcbiAgICBkZXNjOiAnQW50YXJtdWthIGJlcnNpaCwgdGFucGEgaWtsYW4sIG55YW1hbiBkaXBha2FpIGRpIGxheWFyIGtlY2lsIG1hdXB1biBiZXNhci4nIH0sXG4gIHsgaWNvbjogQmFyQ2hhcnQyLCB0aXRsZTogJ0hhc2lsIHRlcmhpdHVuZyBvdG9tYXRpcycsXG4gICAgZGVzYzogJ0dyYWZpayBqYXdhYmFuIGRhbiByZWthcCBuaWxhaSBsYW5nc3VuZyBqYWRpLiBUaWRhayBhZGEgcnVtdXMgc3ByZWFkc2hlZXQgbWFudWFsLicgfSxcbiAgeyBpY29uOiBRckNvZGUsIHRpdGxlOiAnUVIgY29kZSBiYXdhYW4nLFxuICAgIGRlc2M6ICdQZXNlcnRhIHBpbmRhaSwgbGFuZ3N1bmcgbWVuZ2lzaS4gVGlkYWsgcGVybHUgbWVuZ2V0aWsgYWxhbWF0IGFwYSBwdW4uJyB9LFxuXTtcblxuY29uc3QgTUFOSUZFU1RPID1cbiAgJ0lkZSB1bnR1ayBrdWlzIGF0YXUgc3VydmVpIGJpc2EgbXVuY3VsIGthcGFuIHNhamEg4oCUIGRpIGtlbGFzLCBkaSBwZXJqYWxhbmFuLCBkaSBzZWxhIHJhcGF0LiBGb3JtVXAgbWVtYnVhdCBzYXR1IGFrdW5tdSBjdWt1cDogcmFuY2FuZyBkaSB3ZWIsIGJhZ2lrYW4gZGFuIHBhbnRhdSBkYXJpIG1hbmEgc2FqYS4gRGF0YSB0aWRhayBwZXJsdSBtZW51bmdndSBrYW11IGR1ZHVrIGRpIGRlcGFuIGxhcHRvcC4nO1xuXG5jb25zdCBGQVFTID0gW1xuICB7IHE6ICdBcGFrYWggRm9ybVVwIGdyYXRpcz8nLFxuICAgIGE6ICdZYS4gTWVtYnVhdCBmb3JtdWxpciwgbWVtYmFnaWthbiwgZGFuIG1lbmd1bXB1bGthbiByZXNwb25zIHRpZGFrIGRpa2VuYWthbiBiaWF5YS4nIH0sXG4gIHsgcTogJ0JhZ2FpbWFuYSBzaW5rcm9uaXNhc2kgd2ViIGRhbiBtb2JpbGU/JyxcbiAgICBhOiAnU2F0dSBha3VuIHVudHVrIGtlZHVhbnlhLiBGb3JtdWxpciB5YW5nIGRpYnVhdCBkaSB3ZWIgbGFuZ3N1bmcgbXVuY3VsIGRpIGFwbGlrYXNpIEFuZHJvaWQsIGRhbiBzZWJhbGlrbnlhLicgfSxcbiAgeyBxOiAnQWRhIGJhdGFzIGp1bWxhaCByZXNwb25zPycsXG4gICAgYTogJ1RpZGFrIGFkYS4gS3VtcHVsa2FuIHJlc3BvbnMgc2ViYW55YWsgYXBhIHB1biBkYXJpIHNpc3dhLCBwZXNlcnRhLCBhdGF1IHJlc3BvbmRlbiBzdXJ2ZWkuJyB9LFxuICB7IHE6ICdCaXNha2FoIGhhc2lsIGRpZWtzcG9yPycsXG4gICAgYTogJ0Jpc2EuIFJla2FwaXR1bGFzaSBkYXBhdCBkaWVrc3BvciBrZSBDU1YgZGFuIFhMU1ggZGFyaSBoYWxhbWFuIHJlc3BvbnMuJyB9LFxuXTtcblxuY29uc3QgQVBLX1VSTCA9ICdodHRwczovL2dpdGh1Yi5jb20vYWJheURhaGxuL0Zvcm1VcC9yZWxlYXNlcy9kb3dubG9hZC92MS4wLjAvZm9ybXVwLWFuZHJvaWQuYXBrJztcbmNvbnN0IEVYRV9VUkwgPSAnaHR0cHM6Ly9naXRodWIuY29tL2FiYXlEYWhsbi9Gb3JtVXAvcmVsZWFzZXMvZG93bmxvYWQvdjEuMC4wL2Zvcm11cC13aW5kb3dzLWluc3RhbGxlci5leGUnO1xuXG4vKiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgIE1BR05FVElDXG7ilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cbmZ1bmN0aW9uIE1hZ25ldGljKHsgY2hpbGRyZW4sIGNsYXNzTmFtZSA9ICcnLCBzdHJlbmd0aCA9IDAuMzUgfSkge1xuICBjb25zdCByZWYgPSB1c2VSZWYobnVsbCk7XG4gIGNvbnN0IHhUbyA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgeVRvID0gdXNlUmVmKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgeFRvLmN1cnJlbnQgPSBnc2FwLnF1aWNrVG8ocmVmLmN1cnJlbnQsICd4JywgeyBkdXJhdGlvbjogMC41LCBlYXNlOiAncG93ZXIzLm91dCcgfSk7XG4gICAgeVRvLmN1cnJlbnQgPSBnc2FwLnF1aWNrVG8ocmVmLmN1cnJlbnQsICd5JywgeyBkdXJhdGlvbjogMC41LCBlYXNlOiAncG93ZXIzLm91dCcgfSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBvbk1vdmUgPSB1c2VDYWxsYmFjaygoZSkgPT4ge1xuICAgIGNvbnN0IHJlY3QgPSByZWYuY3VycmVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICB4VG8uY3VycmVudCgoZS5jbGllbnRYIC0gKHJlY3QubGVmdCArIHJlY3Qud2lkdGggLyAyKSkgKiBzdHJlbmd0aCk7XG4gICAgeVRvLmN1cnJlbnQoKGUuY2xpZW50WSAtIChyZWN0LnRvcCArIHJlY3QuaGVpZ2h0IC8gMikpICogc3RyZW5ndGgpO1xuICB9LCBbc3RyZW5ndGhdKTtcbiAgY29uc3Qgb25MZWF2ZSA9IHVzZUNhbGxiYWNrKCgpID0+IHsgeFRvLmN1cnJlbnQoMCk7IHlUby5jdXJyZW50KDApOyB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHJlZj17cmVmfSBvbk1vdXNlTW92ZT17b25Nb3ZlfSBvbk1vdXNlTGVhdmU9e29uTGVhdmV9IGNsYXNzTmFtZT17YGlubGluZS1ibG9jayAke2NsYXNzTmFtZX1gfT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLyog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICBTVEFUIOKAlCBjb3VudC11cCBtYW5kaXJpIHZpYSBJbnRlcnNlY3Rpb25PYnNlcnZlclxu4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5mdW5jdGlvbiBTdGF0KHsgdmFsdWUsIHN1ZmZpeCwgbGFiZWwgfSkge1xuICBjb25zdCBbbiwgc2V0Tl0gPSB1c2VTdGF0ZSh2YWx1ZSk7XG4gIGNvbnN0IHN0YXJ0ZWQgPSB1c2VSZWYoZmFsc2UpO1xuICBjb25zdCByZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBlbCA9IHJlZi5jdXJyZW50O1xuICAgIGNvbnN0IGlvID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKChbZV0pID0+IHtcbiAgICAgIGlmICghZS5pc0ludGVyc2VjdGluZyB8fCBzdGFydGVkLmN1cnJlbnQpIHJldHVybjtcbiAgICAgIHN0YXJ0ZWQuY3VycmVudCA9IHRydWU7XG4gICAgICBpby5kaXNjb25uZWN0KCk7XG4gICAgICBjb25zdCBzdGFydCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgY29uc3QgZHVyID0gMTQwMDtcbiAgICAgIGNvbnN0IHRpY2sgPSAodCkgPT4ge1xuICAgICAgICBjb25zdCBwID0gTWF0aC5taW4oMSwgKHQgLSBzdGFydCkgLyBkdXIpO1xuICAgICAgICBzZXROKE1hdGgucm91bmQodmFsdWUgKiAoMSAtIE1hdGgucG93KDEgLSBwLCAzKSkpKTtcbiAgICAgICAgaWYgKHAgPCAxKSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGljayk7XG4gICAgICB9O1xuICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRpY2spO1xuICAgIH0sIHsgdGhyZXNob2xkOiAwLjQgfSk7XG4gICAgaW8ub2JzZXJ2ZShlbCk7XG4gICAgcmV0dXJuICgpID0+IGlvLmRpc2Nvbm5lY3QoKTtcbiAgfSwgW3ZhbHVlXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHJlZj17cmVmfT5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNXhsIG1kOnRleHQtNnhsIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0XCIgc3R5bGU9e3sgY29sb3I6IElOSyB9fT5cbiAgICAgICAge259PHNwYW4gc3R5bGU9e3sgY29sb3I6IEdSRUVOIH19PntzdWZmaXh9PC9zcGFuPlxuICAgICAgPC9wPlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBtdC0zIGxlYWRpbmctcmVsYXhlZFwiIHN0eWxlPXt7IGNvbG9yOiBgJHtJTkt9ODBgIH19PntsYWJlbH08L3A+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8qIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgTEFZQVIgUE9OU0VMIENFUklUQSAoYnVpbGQgLyBzaGFyZSAvIHRyYWNrKVxu4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5mdW5jdGlvbiBTdG9yeVBob25lKHsgc2NyZWVuIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctWzI1MHB4XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTggbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiB3LTQ4IGgtNyByb3VuZGVkLWZ1bGwgYmx1ci0yeGxcIlxuICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGAke0dSRUVOfTQwYCB9fSAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSByb3VuZGVkLVs0MHB4XSBwLTIuNSBib3JkZXIgYm9yZGVyLXdoaXRlLzI1XCJcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDE4MGRlZywgIzJFM0IzMyAwJSwgIzE0MUQxOCAxMDAlKScsXG4gICAgICAgICAgYm94U2hhZG93OiAnMCAzNnB4IDgwcHggLTIycHggcmdiYSgxMywzMSwyMywwLjU1KScsXG4gICAgICAgIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtWzMycHhdIHAtNSBhc3BlY3QtWzkvMThdIGZsZXggZmxleC1jb2wgZ2FwLTQgdGV4dC1sZWZ0IG92ZXJmbG93LWhpZGRlblwiXG4gICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnIzBEMTUxMicgfX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIwIGgtNCByb3VuZGVkLWZ1bGwgbXgtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBweC0yXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyMxNjIxMUInIH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGxcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGAke0xJR0hUfUNDYCB9fSAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge3NjcmVlbiA9PT0gJ2J1aWxkJyAmJiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5Gb3JtdWxpciBiYXJ1PC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIG10LTAuNVwiIHN0eWxlPXt7IGNvbG9yOiAnIzVCQzk4QycgfX0+RHJhZiB0ZXJzaW1wYW4gb3RvbWF0aXM8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgcC0zIHNwYWNlLXktMlwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjU1LDI1NSwyNTUsMC4wNCknLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSgyNTUsMjU1LDI1NSwwLjA3KScgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIgdy0zLzQgcm91bmRlZC1mdWxsXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjE4KScgfX0gLz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNiByb3VuZGVkLW1kIGZsZXggaXRlbXMtY2VudGVyIHB4LTIgdGV4dC1bOXB4XSB0ZXh0LXN0b25lLTQwMFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjU1LDI1NSwyNTUsMC4wNiknIH19PlxuICAgICAgICAgICAgICAgICAgUGlsaWhhbiBnYW5kYVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC02IHJvdW5kZWQtbWQgZmxleCBpdGVtcy1jZW50ZXIgcHgtMiB0ZXh0LVs5cHhdIHRleHQtc3RvbmUtNDAwXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjA2KScgfX0+XG4gICAgICAgICAgICAgICAgICBFc3NheVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIHB4LTMgcHktMi41IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogR1JFRU4gfX0+XG4gICAgICAgICAgICAgICAgPFBsdXMgc2l6ZT17MTF9IC8+IFRhbWJhaCBwZXJ0YW55YWFuXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHtzY3JlZW4gPT09ICdzaGFyZScgJiYgKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+VWppYW4gSGFyaWFuIEZpc2lrYTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBtdC0wLjUgdGV4dC1zdG9uZS00MDBcIj5TaWFwIGRpYmFnaWthbjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBwLTQgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTNcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjU1LDI1NSwyNTUsMC4wNCknLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSgyNTUsMjU1LDI1NSwwLjA3KScgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTI0IGgtMjQgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6ICcjRjZGNEVEJyB9fT5cbiAgICAgICAgICAgICAgICAgIDxRckNvZGUgc2l6ZT17NjR9IHN0eWxlPXt7IGNvbG9yOiBJTksgfX0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkXCIgc3R5bGU9e3sgY29sb3I6IExJR0hUIH19PmZvcm11cC5hcHAvZi84eDJrPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIHB4LTMgcHktMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYCR7R1JFRU59MUZgLCBib3JkZXI6IGAxcHggc29saWQgJHtHUkVFTn00MGAgfX0+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tZWRpdW1cIiBzdHlsZT17eyBjb2xvcjogTElHSFQgfX0+U2lhcCBkaXBpbmRhaTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8Q2hlY2sgc2l6ZT17MTN9IHN0eWxlPXt7IGNvbG9yOiBMSUdIVCB9fSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7c2NyZWVuID09PSAndHJhY2snICYmIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlJla2FwIHJlc3BvbnM8L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gbXQtMC41XCIgc3R5bGU9e3sgY29sb3I6IExJR0hUIH19PjEyOCBkYXJpIDE0MCBzdWRhaCBtZW5naXNpPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIHAtNCBzcGFjZS15LTIuNVwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjA0KScsIGJvcmRlcjogJzFweCBzb2xpZCByZ2JhKDI1NSwyNTUsMjU1LDAuMDcpJyB9fT5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXN0b25lLTQwMFwiPlBlcnNlYmFyYW4gbmlsYWk8L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBnYXAtMS41IGgtMjBcIj5cbiAgICAgICAgICAgICAgICAgIHtbMzUsIDU1LCA4MCwgMTAwLCA3MCwgNDVdLm1hcCgoaCwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZmxleC0xIHJvdW5kZWQtdC1zbVwiIHN0eWxlPXt7IGhlaWdodDogYCR7aH0lYCwgYmFja2dyb3VuZENvbG9yOiBpID09PSAzID8gTElHSFQgOiBHUkVFTiB9fSAvPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LVs4cHhdIHRleHQtc3RvbmUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj4wPC9zcGFuPjxzcGFuPjUwPC9zcGFuPjxzcGFuPjEwMDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBweC0zIHB5LTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGAke0dSRUVOfTFGYCwgYm9yZGVyOiBgMXB4IHNvbGlkICR7R1JFRU59NDBgIH19PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbWVkaXVtXCIgc3R5bGU9e3sgY29sb3I6IExJR0hUIH19PkVrc3BvciBDU1YgLyBYTFNYPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxMn0gc3R5bGU9e3sgY29sb3I6IExJR0hUIH19IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtYXV0byBwdC0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMHB4XSB0ZXh0LXN0b25lLTUwMFwiXG4gICAgICAgICAgICBzdHlsZT17eyBib3JkZXJUb3A6ICcxcHggc29saWQgcmdiYSgyNTUsMjU1LDI1NSwwLjA3KScgfX0+XG4gICAgICAgICAgICA8c3Bhbj5mb3JtdXAuYXBwPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IExJR0hUIH19PlRlcmh1YnVuZzwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLyog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICBNQUlOXG7ilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExhbmRpbmdQYWdlKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IFtzY3JvbGxlZCwgc2V0U2Nyb2xsZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbb3BlbkZhcSwgc2V0T3BlbkZhcV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW3ByZXNldCwgc2V0UHJlc2V0XSA9IHVzZVN0YXRlKCdxdWl6Jyk7XG4gIGNvbnN0IFtiZWF0LCBzZXRCZWF0XSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbc2NyZWVuLCBzZXRTY3JlZW5dID0gdXNlU3RhdGUoJ2J1aWxkJyk7XG5cbiAgY29uc3QgY29udGFpbmVyUmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCBwaG9uZUludHJvUmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCBwaG9uZUZsb2F0UmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCBwaG9uZUZhbGxSZWYgPSB1c2VSZWYobnVsbCk7XG4gIGNvbnN0IHBob25lVGlsdFJlZiA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgZ2xhcmVSZWYgPSB1c2VSZWYobnVsbCk7XG4gIGNvbnN0IHJvdFhUbyA9IHVzZVJlZihudWxsKTtcbiAgY29uc3Qgcm90WVRvID0gdXNlUmVmKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzQXV0aGVudGljYXRlZCgpKSBuYXZpZ2F0ZSgnL2Rhc2hib2FyZCcsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgfSwgW25hdmlnYXRlXSk7XG5cbiAgLyog4pSA4pSAIFRJTFQgM0QgaGVybyDilIDilIAgKi9cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBob25lVGlsdFJlZi5jdXJyZW50KSByZXR1cm47XG4gICAgcm90WFRvLmN1cnJlbnQgPSBnc2FwLnF1aWNrVG8ocGhvbmVUaWx0UmVmLmN1cnJlbnQsICdyb3RhdGlvblgnLCB7IGR1cmF0aW9uOiAwLjYsIGVhc2U6ICdwb3dlcjMub3V0JyB9KTtcbiAgICByb3RZVG8uY3VycmVudCA9IGdzYXAucXVpY2tUbyhwaG9uZVRpbHRSZWYuY3VycmVudCwgJ3JvdGF0aW9uWScsIHsgZHVyYXRpb246IDAuNiwgZWFzZTogJ3Bvd2VyMy5vdXQnIH0pO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgaGFuZGxlTW91c2VNb3ZlID0gdXNlQ2FsbGJhY2soKGUpID0+IHtcbiAgICBjb25zdCByZWN0ID0gZS5jdXJyZW50VGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHB4ID0gKGUuY2xpZW50WCAtIHJlY3QubGVmdCkgLyByZWN0LndpZHRoO1xuICAgIGNvbnN0IHB5ID0gKGUuY2xpZW50WSAtIHJlY3QudG9wKSAvIHJlY3QuaGVpZ2h0O1xuICAgIHJvdFhUby5jdXJyZW50Py4oKHB5IC0gMC41KSAqIC0xOCk7XG4gICAgcm90WVRvLmN1cnJlbnQ/LigocHggLSAwLjUpICogMjIpO1xuICAgIGlmIChnbGFyZVJlZi5jdXJyZW50KSB7XG4gICAgICBnbGFyZVJlZi5jdXJyZW50LnN0eWxlLmJhY2tncm91bmQgPVxuICAgICAgICBgcmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCAke3B4ICogMTAwfSUgJHtweSAqIDEwMH0lLCByZ2JhKDI1NSwyNTUsMjU1LDAuNCkgMCUsIHRyYW5zcGFyZW50IDU1JSlgO1xuICAgIH1cbiAgfSwgW10pO1xuICBjb25zdCBoYW5kbGVNb3VzZUxlYXZlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHJvdFhUby5jdXJyZW50Py4oMCk7XG4gICAgcm90WVRvLmN1cnJlbnQ/LigwKTtcbiAgICBpZiAoZ2xhcmVSZWYuY3VycmVudCkge1xuICAgICAgZ2xhcmVSZWYuY3VycmVudC5zdHlsZS5iYWNrZ3JvdW5kID1cbiAgICAgICAgJ3JhZGlhbC1ncmFkaWVudChjaXJjbGUgYXQgNTAlIDIwJSwgcmdiYSgyNTUsMjU1LDI1NSwwLjE4KSAwJSwgdHJhbnNwYXJlbnQgNTUlKSc7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgLyog4pSA4pSAIExFTklTICsgR1NBUCDilIDilIAgKi9cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCByZWR1Y2VkID0gd2luZG93Lm1hdGNoTWVkaWEoJyhwcmVmZXJzLXJlZHVjZWQtbW90aW9uOiByZWR1Y2UpJykubWF0Y2hlcztcblxuICAgIGxldCBsZW5pcyA9IG51bGw7XG4gICAgaWYgKCFyZWR1Y2VkKSB7XG4gICAgICBsZW5pcyA9IG5ldyBMZW5pcyh7IGR1cmF0aW9uOiAxLjE1LCBzbW9vdGhXaGVlbDogdHJ1ZSB9KTtcbiAgICAgIGxlbmlzLm9uKCdzY3JvbGwnLCBTY3JvbGxUcmlnZ2VyLnVwZGF0ZSk7XG4gICAgfVxuICAgIGNvbnN0IHJhZiA9ICh0aW1lKSA9PiBsZW5pcz8ucmFmKHRpbWUgKiAxMDAwKTtcbiAgICBnc2FwLnRpY2tlci5hZGQocmFmKTtcbiAgICBnc2FwLnRpY2tlci5sYWdTbW9vdGhpbmcoMCk7XG5cbiAgICBjb25zdCBvblNjcm9sbCA9ICgpID0+IHNldFNjcm9sbGVkKHdpbmRvdy5zY3JvbGxZID4gMjQpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCBvblNjcm9sbCwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuXG4gICAgY29uc3QgbW0gPSBnc2FwLm1hdGNoTWVkaWEoKTtcblxuICAgIGNvbnN0IGN0eCA9IGdzYXAuY29udGV4dCgoKSA9PiB7XG4gICAgICAvKiDilIDilIAgcHJvZ3Jlc3MgYmFyIGhhbGFtYW4g4pSA4pSAICovXG4gICAgICBnc2FwLnRvKCcjcGFnZS1wcm9ncmVzcycsIHtcbiAgICAgICAgc2NhbGVYOiAxLCBlYXNlOiAnbm9uZScsXG4gICAgICAgIHNjcm9sbFRyaWdnZXI6IHsgdHJpZ2dlcjogZG9jdW1lbnQuYm9keSwgc3RhcnQ6ICd0b3AgdG9wJywgZW5kOiAnYm90dG9tIGJvdHRvbScsIHNjcnViOiAwLjMgfSxcbiAgICAgIH0pO1xuXG4gICAgICAvKiDilIDilIAgSEVSTyBFTlRSQU5DRSAodGltZS1iYXNlZCwgcGFzdGkgamFsYW4pIOKUgOKUgCAqL1xuICAgICAgZ3NhcC50aW1lbGluZSh7IGRlZmF1bHRzOiB7IGVhc2U6ICdwb3dlcjQub3V0JyB9IH0pXG4gICAgICAgIC5mcm9tVG8oJy5uYXYtaXRlbScsIHsgeTogLTE4LCBvcGFjaXR5OiAwIH0sIHsgeTogMCwgb3BhY2l0eTogMSwgc3RhZ2dlcjogMC4wOCwgZHVyYXRpb246IDAuOCB9LCAwLjEpXG4gICAgICAgIC5mcm9tVG8oJy5oZXJvLWtpY2tlcicsIHsgeTogMTYsIG9wYWNpdHk6IDAgfSwgeyB5OiAwLCBvcGFjaXR5OiAxLCBkdXJhdGlvbjogMC44IH0sIDAuMjUpXG4gICAgICAgIC5mcm9tVG8oJy5oZXJvLWxpbmUnLCB7IHlQZXJjZW50OiAxMTAgfSwgeyB5UGVyY2VudDogMCwgc3RhZ2dlcjogMC4xMiwgZHVyYXRpb246IDEuMSB9LCAwLjMpXG4gICAgICAgIC5mcm9tVG8oJy5oZXJvLXN1YicsIHsgeTogMjAsIG9wYWNpdHk6IDAgfSwgeyB5OiAwLCBvcGFjaXR5OiAxLCBkdXJhdGlvbjogMC44IH0sIDAuNylcbiAgICAgICAgLmZyb21UbygnLmhlcm8tY3RhJywgeyB5OiAxNiwgb3BhY2l0eTogMCB9LCB7IHk6IDAsIG9wYWNpdHk6IDEsIHN0YWdnZXI6IDAuMSwgZHVyYXRpb246IDAuNyB9LCAwLjg1KVxuICAgICAgICAuZnJvbVRvKCcuaGVyby1tZXRhJywgeyBvcGFjaXR5OiAwIH0sIHsgb3BhY2l0eTogMSwgZHVyYXRpb246IDAuOSB9LCAxKVxuICAgICAgICAuZnJvbVRvKHBob25lSW50cm9SZWYuY3VycmVudCwgeyB5OiA4MCwgb3BhY2l0eTogMCwgc2NhbGU6IDAuOTQgfSxcbiAgICAgICAgICB7IHk6IDAsIG9wYWNpdHk6IDEsIHNjYWxlOiAxLCBkdXJhdGlvbjogMS4zLCBlYXNlOiAncG93ZXIzLm91dCcgfSwgMC40NSk7XG5cbiAgICAgIC8qIGxldml0YXNpICovXG4gICAgICBnc2FwLnRvKHBob25lRmxvYXRSZWYuY3VycmVudCwgeyB5OiAtMTIsIGR1cmF0aW9uOiAzLjIsIHJlcGVhdDogLTEsIHlveW86IHRydWUsIGVhc2U6ICdzaW5lLmluT3V0JyB9KTtcblxuICAgICAgLyogaHAgXCJqYXR1aFwiIGtlbHVhciBoZXJvIOKAlCBzY3J1YiBkaSB3cmFwcGVyIHRlcmx1YXIsIHR3ZWVuIHR1bmdnYWwgKi9cbiAgICAgIGdzYXAudG8ocGhvbmVGYWxsUmVmLmN1cnJlbnQsIHtcbiAgICAgICAgeTogMzQwLCByb3RhdGU6IC0xNCwgb3BhY2l0eTogMCwgZWFzZTogJ25vbmUnLFxuICAgICAgICBzY3JvbGxUcmlnZ2VyOiB7IHRyaWdnZXI6ICcjaGVybycsIHN0YXJ0OiAndG9wIHRvcCcsIGVuZDogJ2JvdHRvbSB0b3AnLCBzY3J1YjogMSB9LFxuICAgICAgfSk7XG5cbiAgICAgIC8qIOKUgOKUgCBSSVRVQUwg4oCUIHN0YWNrZWQgcGlubmluZyAoa29udGVuIG55YXRhLCBhbnRpIGJsYW5rKSDilIDilIAgKi9cbiAgICAgIG1tLmFkZCgnKG1pbi13aWR0aDogNzY4cHgpJywgKCkgPT4ge1xuICAgICAgICBnc2FwLnV0aWxzLnRvQXJyYXkoJy5yaXR1YWwtcGFuZWwnKS5mb3JFYWNoKChwYW5lbCkgPT4ge1xuICAgICAgICAgIGdzYXAuZnJvbShwYW5lbC5xdWVyeVNlbGVjdG9yKCcucml0dWFsLWlubmVyJyksIHtcbiAgICAgICAgICAgIHk6IDcwLCBvcGFjaXR5OiAwLCBkdXJhdGlvbjogMSwgZWFzZTogJ3Bvd2VyMy5vdXQnLFxuICAgICAgICAgICAgc2Nyb2xsVHJpZ2dlcjogeyB0cmlnZ2VyOiBwYW5lbCwgc3RhcnQ6ICd0b3AgNjIlJywgdG9nZ2xlQWN0aW9uczogJ3BsYXkgbm9uZSBub25lIHJldmVyc2UnIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgU2Nyb2xsVHJpZ2dlci5jcmVhdGUoeyB0cmlnZ2VyOiBwYW5lbCwgc3RhcnQ6ICd0b3AgdG9wJywgcGluOiB0cnVlLCBwaW5TcGFjaW5nOiBmYWxzZSB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcblxuICAgICAgbW0uYWRkKCcobWF4LXdpZHRoOiA3NjdweCknLCAoKSA9PiB7XG4gICAgICAgIGdzYXAudXRpbHMudG9BcnJheSgnLm0tcmV2ZWFsJykuZm9yRWFjaCgoZWwpID0+IHtcbiAgICAgICAgICBnc2FwLmZyb20oZWwsIHtcbiAgICAgICAgICAgIHk6IDM2LCBvcGFjaXR5OiAwLCBkdXJhdGlvbjogMC45LCBlYXNlOiAncG93ZXIzLm91dCcsXG4gICAgICAgICAgICBzY3JvbGxUcmlnZ2VyOiB7IHRyaWdnZXI6IGVsLCBzdGFydDogJ3RvcCA4OCUnLCBvbmNlOiB0cnVlIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIC8qIOKUgOKUgCBNQU5JRkVTVE8g4oCUIGthdGEgbWVueWFsYSDilIDilIAgKi9cbiAgICAgIGdzYXAuZnJvbVRvKCcubXdvcmQnLCB7IG9wYWNpdHk6IDAuMTUgfSwge1xuICAgICAgICBvcGFjaXR5OiAxLCBzdGFnZ2VyOiAwLjA1LCBlYXNlOiAnbm9uZScsXG4gICAgICAgIHNjcm9sbFRyaWdnZXI6IHtcbiAgICAgICAgICB0cmlnZ2VyOiAnI21hbmlmZXN0bycsIHN0YXJ0OiAndG9wIDc4JScsIGVuZDogJ2JvdHRvbSA2NSUnLFxuICAgICAgICAgIHNjcnViOiAxLCBpbnZhbGlkYXRlT25SZWZyZXNoOiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG5cbiAgICAgIC8qIOKUgOKUgCBBTFVSIOKAlCBHU0FQIFBJTiAoYnVrYW4gQ1NTIHN0aWNreSwgZml4ZXMgb3ZlcmZsb3cteCBidWcpLlxuICAgICAgICAgVHJhY2sgbXVsYWkgZGFyaSBwb3Npc2kgbmF0dXJhbCDihpIgd2FsYXUgdHdlZW4gZ2FnYWwsIGthcnR1IHBlcnRhbWEgdGV0YXAgdGVybGloYXQuIOKUgOKUgCAqL1xuICAgICAgbW0uYWRkKCcobWluLXdpZHRoOiA3NjhweCknLCAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHRyYWNrID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLndmLXRyYWNrJyk7XG4gICAgICAgIGNvbnN0IGRpc3QgPSAoKSA9PiBNYXRoLm1heCgwLCB0cmFjay5zY3JvbGxXaWR0aCAtIHdpbmRvdy5pbm5lcldpZHRoICsgNjApO1xuICAgICAgICBnc2FwLnRvKHRyYWNrLCB7XG4gICAgICAgICAgeDogKCkgPT4gLWRpc3QoKSwgZWFzZTogJ25vbmUnLFxuICAgICAgICAgIHNjcm9sbFRyaWdnZXI6IHtcbiAgICAgICAgICAgIHRyaWdnZXI6ICcjYWx1cicsIHN0YXJ0OiAndG9wIHRvcCcsXG4gICAgICAgICAgICBlbmQ6ICgpID0+ICcrPScgKyBkaXN0KCksXG4gICAgICAgICAgICBzY3J1YjogMSwgcGluOiB0cnVlLCBhbnRpY2lwYXRlUGluOiAxLCBpbnZhbGlkYXRlT25SZWZyZXNoOiB0cnVlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBnc2FwLmZyb21UbygnLndmLXByb2dyZXNzJywgeyBzY2FsZVg6IDAgfSwge1xuICAgICAgICAgIHNjYWxlWDogMSwgZWFzZTogJ25vbmUnLFxuICAgICAgICAgIHNjcm9sbFRyaWdnZXI6IHtcbiAgICAgICAgICAgIHRyaWdnZXI6ICcjYWx1cicsIHN0YXJ0OiAndG9wIHRvcCcsXG4gICAgICAgICAgICBlbmQ6ICgpID0+ICcrPScgKyBkaXN0KCksIHNjcnViOiAxLCBpbnZhbGlkYXRlT25SZWZyZXNoOiB0cnVlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIC8qIOKUgOKUgCBDRVJJVEEg4oCUIHBvbnNlbCBtZW5lbWFuaSBzY3JvbGwgMiw1IGxheWFyLlxuICAgICAgICAgQmVhdCBwYWthaSB0b2dnbGVDbGFzcyAoQ1NTIHRyYW5zaXRpb24pIOKGkiB0aWRhayBhZGEga29udGVuIHlhbmdcbiAgICAgICAgIG55YW5na3V0IGhpZGRlbiB3YWxhdSBwZW5ndWt1cmFuIG1lbGVzZXQuIOKUgOKUgCAqL1xuICAgICAgbW0uYWRkKCcobWluLXdpZHRoOiA3NjhweCknLCAoKSA9PiB7XG4gICAgICAgIFNjcm9sbFRyaWdnZXIuY3JlYXRlKHtcbiAgICAgICAgICB0cmlnZ2VyOiAnI2Nlcml0YScsIHN0YXJ0OiAndG9wIHRvcCcsIGVuZDogJys9MjUwJScsXG4gICAgICAgICAgcGluOiAnLmNlcml0YS1zdGFnZScsIGFudGljaXBhdGVQaW46IDEsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IGJlYXRzID0gZ3NhcC51dGlscy50b0FycmF5KCcuYmVhdCcpO1xuICAgICAgICBjb25zdCBzdGVwID0gKCkgPT4gd2luZG93LmlubmVySGVpZ2h0ICogMC44O1xuICAgICAgICBiZWF0cy5mb3JFYWNoKChiLCBpKSA9PiB7XG4gICAgICAgICAgU2Nyb2xsVHJpZ2dlci5jcmVhdGUoe1xuICAgICAgICAgICAgdHJpZ2dlcjogJyNjZXJpdGEnLFxuICAgICAgICAgICAgc3RhcnQ6ICgpID0+ICd0b3ArPScgKyBpICogc3RlcCgpICsgJyB0b3AnLFxuICAgICAgICAgICAgZW5kOiAoKSA9PiAndG9wKz0nICsgKGkgKyAxKSAqIHN0ZXAoKSArICcgdG9wJyxcbiAgICAgICAgICAgIG9uVG9nZ2xlOiAoc2VsZikgPT4ge1xuICAgICAgICAgICAgICBpZiAoIXNlbGYuaXNBY3RpdmUpIHJldHVybjtcbiAgICAgICAgICAgICAgYmVhdHMuZm9yRWFjaCgoeCkgPT4geC5jbGFzc0xpc3QucmVtb3ZlKCdiZWF0LWFjdGl2ZScpKTtcbiAgICAgICAgICAgICAgYi5jbGFzc0xpc3QuYWRkKCdiZWF0LWFjdGl2ZScpO1xuICAgICAgICAgICAgICBzZXRCZWF0KGkpO1xuICAgICAgICAgICAgICBzZXRTY3JlZW4oQkVBVFNbaV0uc2NyZWVuKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8qIGdlcmFrIHBvbnNlbDogbWVsYXlhbmcg4oaSIGphdHVoIGtlbHVhciBkaSBha2hpciAqL1xuICAgICAgICBnc2FwLnRpbWVsaW5lKHtcbiAgICAgICAgICBzY3JvbGxUcmlnZ2VyOiB7IHRyaWdnZXI6ICcjY2VyaXRhJywgc3RhcnQ6ICd0b3AgdG9wJywgZW5kOiAnKz0yNTAlJywgc2NydWI6IDEgfSxcbiAgICAgICAgfSlcbiAgICAgICAgICAuZnJvbVRvKCcuY2VyaXRhLXBob25lJywgeyB5OiA5MCwgcm90YXRlOiA1IH0sIHsgeTogLTMwLCByb3RhdGU6IC00LCBlYXNlOiAnbm9uZScsIGR1cmF0aW9uOiAzIH0pXG4gICAgICAgICAgLnRvKCcuY2VyaXRhLXBob25lJywgeyB5OiAzMjAsIHJvdGF0ZTogMTYsIG9wYWNpdHk6IDAsIGVhc2U6ICdwb3dlcjEuaW4nLCBkdXJhdGlvbjogMSB9KTtcbiAgICAgIH0pO1xuXG4gICAgICAvKiDilIDilIAgRklUVVIg4pSA4pSAICovXG4gICAgICBnc2FwLmZyb20oJy5mZWF0dXJlLWNhcmQnLCB7XG4gICAgICAgIHk6IDU2LCBvcGFjaXR5OiAwLCBkdXJhdGlvbjogMC45LCBzdGFnZ2VyOiAwLjEyLCBlYXNlOiAncG93ZXIzLm91dCcsXG4gICAgICAgIHNjcm9sbFRyaWdnZXI6IHsgdHJpZ2dlcjogJyNmaXR1cicsIHN0YXJ0OiAndG9wIDc4JScsIG9uY2U6IHRydWUgfSxcbiAgICAgIH0pO1xuXG4gICAgICAvKiDilIDilIAgVFJJTyBGQU4tT1VUIDNEIChwbGF5LW9uY2UpIOKUgOKUgCAqL1xuICAgICAgY29uc3QgdHJpb1RsID0gZ3NhcC50aW1lbGluZSh7XG4gICAgICAgIHNjcm9sbFRyaWdnZXI6IHsgdHJpZ2dlcjogJyN0cmlvJywgc3RhcnQ6ICd0b3AgODUlJywgb25jZTogdHJ1ZSB9LFxuICAgICAgICBkZWZhdWx0czogeyBkdXJhdGlvbjogMS4xLCBlYXNlOiAncG93ZXIzLm91dCcgfSxcbiAgICAgIH0pO1xuICAgICAgdHJpb1RsXG4gICAgICAgIC5mcm9tVG8oJy50cmlvLWxlZnQnLFxuICAgICAgICAgIHsgeDogOTAsIHJvdGF0ZVk6IDAsIHJvdGF0ZVo6IDAsIHNjYWxlOiAwLjcyLCBvcGFjaXR5OiAwIH0sXG4gICAgICAgICAgeyB4OiAwLCByb3RhdGVZOiAyMiwgcm90YXRlWjogLTgsIHNjYWxlOiAwLjksIG9wYWNpdHk6IDEgfSwgMClcbiAgICAgICAgLmZyb21UbygnLnRyaW8tcmlnaHQnLFxuICAgICAgICAgIHsgeDogLTkwLCByb3RhdGVZOiAwLCByb3RhdGVaOiAwLCBzY2FsZTogMC43Miwgb3BhY2l0eTogMCB9LFxuICAgICAgICAgIHsgeDogMCwgcm90YXRlWTogLTIyLCByb3RhdGVaOiA4LCBzY2FsZTogMC45LCBvcGFjaXR5OiAxIH0sIDApXG4gICAgICAgIC5mcm9tVG8oJy50cmlvLWNlbnRlcicsIHsgc2NhbGU6IDAuODgsIHk6IDM2IH0sIHsgc2NhbGU6IDEuMDQsIHk6IC02IH0sIDApO1xuXG4gICAgICAvKiDilIDilIAgRkFRIOKUgOKUgCAqL1xuICAgICAgZ3NhcC5mcm9tKCcuZmFxLWNhcmQnLCB7XG4gICAgICAgIHk6IDI4LCBvcGFjaXR5OiAwLCBkdXJhdGlvbjogMC43LCBzdGFnZ2VyOiAwLjA4LCBlYXNlOiAncG93ZXIyLm91dCcsXG4gICAgICAgIHNjcm9sbFRyaWdnZXI6IHsgdHJpZ2dlcjogJyNmYXEnLCBzdGFydDogJ3RvcCA4MiUnLCBvbmNlOiB0cnVlIH0sXG4gICAgICB9KTtcbiAgICB9LCBjb250YWluZXJSZWYpO1xuXG4gICAgLyogcmVmcmVzaCBzZXRlbGFoIGZvbnQsIGdhbWJhciwgZGFuIGxheW91dCBzdGFiaWwgKi9cbiAgICBpZiAoZG9jdW1lbnQuZm9udHM/LnJlYWR5KSBkb2N1bWVudC5mb250cy5yZWFkeS50aGVuKCgpID0+IFNjcm9sbFRyaWdnZXIucmVmcmVzaCgpKTtcbiAgICBjb25zdCBvbkxvYWQgPSAoKSA9PiBTY3JvbGxUcmlnZ2VyLnJlZnJlc2goKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbG9hZCcsIG9uTG9hZCk7XG4gICAgY29uc3QgdCA9IHNldFRpbWVvdXQoKCkgPT4gU2Nyb2xsVHJpZ2dlci5yZWZyZXNoKCksIDYwMCk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY2xlYXJUaW1lb3V0KHQpO1xuICAgICAgY3R4LnJldmVydCgpO1xuICAgICAgbW0ucmV2ZXJ0KCk7XG4gICAgICBnc2FwLnRpY2tlci5yZW1vdmUocmFmKTtcbiAgICAgIGxlbmlzPy5kZXN0cm95KCk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgb25TY3JvbGwpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2xvYWQnLCBvbkxvYWQpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICBjb25zdCBzZXRBY3RpdmVCZWF0ID0gKGkpID0+IHsgc2V0QmVhdChpKTsgc2V0U2NyZWVuKEJFQVRTW2ldLnNjcmVlbik7IH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHJlZj17Y29udGFpbmVyUmVmfSBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gb3ZlcmZsb3cteC1jbGlwIGFudGlhbGlhc2VkXCJcbiAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogQ1JFQU0sIGNvbG9yOiBJTkssIGZvbnRGYW1pbHk6IFwiJ0ludGVyJywgc3lzdGVtLXVpLCBzYW5zLXNlcmlmXCIgfX0+XG5cbiAgICAgIDxzdHlsZT57YFxuICAgICAgICBAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1JbnRlcjp3Z2h0QDQwMDs1MDA7NjAwOzcwMDs4MDAmZmFtaWx5PUluc3RydW1lbnQrU2VyaWY6aXRhbEAwOzEmZGlzcGxheT1zd2FwJyk7XG4gICAgICAgIC5mb250LXNlcmlmaXQgeyBmb250LWZhbWlseTogJ0luc3RydW1lbnQgU2VyaWYnLCBHZW9yZ2lhLCBzZXJpZjsgfVxuXG4gICAgICAgIEBrZXlmcmFtZXMgYmxpbmsgeyA1MCUgeyBvcGFjaXR5OiAuMiB9IH1cbiAgICAgICAgLmJsaW5rIHsgYW5pbWF0aW9uOiBibGluayAxLjZzIGVhc2UtaW4tb3V0IGluZmluaXRlOyB9XG5cbiAgICAgICAgLyogYmVhdCBjZXJpdGEg4oCUIGRlc2t0b3A6IHR1bXB1a2FuIGFic29sdXQ7IG1vYmlsZTogYWx1ciBub3JtYWwgKi9cbiAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XG4gICAgICAgICAgLmJlYXQge1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlOyBpbnNldDogMDtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7IGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47IGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICAgICAgb3BhY2l0eTogMDsgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDI4cHgpO1xuICAgICAgICAgICAgdHJhbnNpdGlvbjogb3BhY2l0eSAuNTVzIGVhc2UsIHRyYW5zZm9ybSAuNTVzIGVhc2U7XG4gICAgICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLmJlYXQtYWN0aXZlIHsgb3BhY2l0eTogMSAhaW1wb3J0YW50OyB0cmFuc2Zvcm06IG5vbmUgIWltcG9ydGFudDsgcG9pbnRlci1ldmVudHM6IGF1dG87IH1cbiAgICAgICAgfVxuICAgICAgICBAbWVkaWEgKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSkge1xuICAgICAgICAgIC5ibGluayB7IGFuaW1hdGlvbjogbm9uZSAhaW1wb3J0YW50OyB9XG4gICAgICAgICAgLmJlYXQgeyB0cmFuc2l0aW9uOiBub25lICFpbXBvcnRhbnQ7IH1cbiAgICAgICAgfVxuICAgICAgYH08L3N0eWxlPlxuXG4gICAgICA8ZGl2IGlkPVwicGFnZS1wcm9ncmVzc1wiIGNsYXNzTmFtZT1cImZpeGVkIHRvcC0wIGxlZnQtMCByaWdodC0wIGgtWzNweF0gb3JpZ2luLWxlZnQgc2NhbGUteC0wIHotWzYwXVwiXG4gICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogR1JFRU4gfX0gLz5cblxuICAgICAgey8qIOKUgOKUgCBOQVZCQVIg4pSA4pSAICovfVxuICAgICAgPG5hdiBjbGFzc05hbWU9e2BmaXhlZCB0b3AtMCBsZWZ0LTAgcmlnaHQtMCB6LTUwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBweC02ICR7XG4gICAgICAgIHNjcm9sbGVkID8gJ2JhY2tkcm9wLWJsdXItbWQgYm9yZGVyLWIgcHktMycgOiAnYmctdHJhbnNwYXJlbnQgcHktNSdcbiAgICAgIH1gfSBzdHlsZT17c2Nyb2xsZWQgPyB7IGJhY2tncm91bmRDb2xvcjogYCR7Q1JFQU19RDlgLCBib3JkZXJDb2xvcjogYCR7SU5LfTFBYCB9IDoge319PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTZ4bCBteC1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cIm5hdi1pdGVtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgIDxpbWcgc3JjPXtsb2dvfSBhbHQ9XCJGb3JtVXBcIiBjbGFzc05hbWU9XCJ3LTggaC04IG9iamVjdC1jb250YWluXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0XCI+Rm9ybTxzcGFuIHN0eWxlPXt7IGNvbG9yOiBHUkVFTiB9fT5VcDwvc3Bhbj48L3NwYW4+XG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgc206Z2FwLTRcIj5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCIgY2xhc3NOYW1lPVwibmF2LWl0ZW0gcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogYCR7SU5LfTk5YCB9fT5cbiAgICAgICAgICAgICAgTWFzdWtcbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDxNYWduZXRpYz5cbiAgICAgICAgICAgICAgPExpbmsgdG89XCIvcmVnaXN0ZXJcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm5hdi1pdGVtIHB4LTUgcHktMi41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LVsjRjZGNEVEXSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IElOSyB9fVxuICAgICAgICAgICAgICAgIG9uTW91c2VFbnRlcj17KGUpID0+IChlLmN1cnJlbnRUYXJnZXQuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gR1JFRU4pfVxuICAgICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17KGUpID0+IChlLmN1cnJlbnRUYXJnZXQuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gSU5LKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIERhZnRhciBncmF0aXNcbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgPC9NYWduZXRpYz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L25hdj5cblxuICAgICAgey8qIOKVkOKVkOKVkCBIRVJPIOKVkOKVkOKVkCAqL31cbiAgICAgIDxzZWN0aW9uIGlkPVwiaGVyb1wiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTYgcHQtMzYgcGItMjQgbGc6cHQtNDAgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNnhsIG14LWF1dG8gZ3JpZCBsZzpncmlkLWNvbHMtWzEuMWZyXzAuOWZyXSBnYXAtMTYgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhlcm8ta2lja2VyIHRleHQteHMgZm9udC1ib2xkIHRyYWNraW5nLVswLjE4ZW1dIHVwcGVyY2FzZSBtYi03IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIlxuICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogR1JFRU4gfX0+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogR1JFRU4gfX0gLz5cbiAgICAgICAgICAgICAgRm9ybSBidWlsZGVyIHVudHVrIHdlYiAmYW1wOyBtb2JpbGVcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTV4bCBzbTp0ZXh0LTd4bCBsZzp0ZXh0LVs1LjRyZW1dIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLVstMC4wM2VtXSBsZWFkaW5nLVsxLjAyXVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBvdmVyZmxvdy1oaWRkZW4gcGItMVwiPjxzcGFuIGNsYXNzTmFtZT1cImhlcm8tbGluZSBibG9ja1wiPkJ1YXQgZm9ybXVsaXIsPC9zcGFuPjwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgb3ZlcmZsb3ctaGlkZGVuIHBiLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoZXJvLWxpbmUgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VyaWZpdCBpdGFsaWMgZm9udC1ub3JtYWxcIiBzdHlsZT17eyBjb2xvcjogR1JFRU4gfX0+ZGFyaSBtYW5hIHNhamEuPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhlcm8tc3ViIHRleHQtYmFzZSBtYXgtdy1tZCBsZWFkaW5nLXJlbGF4ZWQgbXQtN1wiIHN0eWxlPXt7IGNvbG9yOiBgJHtJTkt9OTlgIH19PlxuICAgICAgICAgICAgICBLdWlzLCBzdXJ2ZWksIGRhbiBwYW50YXVhbiBuaWxhaSBkYWxhbSBoaXR1bmdhbiBtZW5pdC4gUmFuY2FuZyBkaSBicm93c2VyLFxuICAgICAgICAgICAgICBiYWdpa2FuIGxld2F0IGxpbmsgYXRhdSBRUiwgcGFudGF1IGhhc2lsbnlhIGxhbmdzdW5nLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IGdhcC0zLjUgbXQtOVwiPlxuICAgICAgICAgICAgICB7LyogVG9tYm9sIGRvd25sb2FkIEFQSyAqL31cbiAgICAgICAgICAgICAgPE1hZ25ldGljIGNsYXNzTmFtZT1cImhlcm8tY3RhIHctZnVsbCBzbTp3LWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8YSBocmVmPXtBUEtfVVJMfSBkb3dubG9hZD1cImZvcm11cC1hbmRyb2lkLmFwa1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHNtOnctYXV0byBweC03IHB5LTMuNSB0ZXh0LVsjRjZGNEVEXSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IEdSRUVOIH19XG4gICAgICAgICAgICAgICAgICBvbk1vdXNlRW50ZXI9eyhlKSA9PiAoZS5jdXJyZW50VGFyZ2V0LnN0eWxlLmJhY2tncm91bmRDb2xvciA9IEdSRUVOX0RFRVApfVxuICAgICAgICAgICAgICAgICAgb25Nb3VzZUxlYXZlPXsoZSkgPT4gKGUuY3VycmVudFRhcmdldC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBHUkVFTil9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFNtYXJ0cGhvbmUgc2l6ZT17MTZ9IC8+IFVuZHVoIEFQSyAoQW5kcm9pZCkgPEFycm93VXBSaWdodCBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgIDwvTWFnbmV0aWM+XG4gICAgICAgICAgICAgIHsvKiBUb21ib2wgZG93bmxvYWQgV2luZG93cyBpbnN0YWxsZXIgKi99XG4gICAgICAgICAgICAgIDxNYWduZXRpYyBjbGFzc05hbWU9XCJoZXJvLWN0YSB3LWZ1bGwgc206dy1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj17RVhFX1VSTH0gZG93bmxvYWQ9XCJmb3JtdXAtd2luZG93cy1pbnN0YWxsZXIuZXhlXCIgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIHB4LTcgcHktMy41IHRleHQtWyNGNkY0RURdIHRleHQtc20gZm9udC1zZW1pYm9sZCByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogSU5LIH19XG4gICAgICAgICAgICAgICAgICBvbk1vdXNlRW50ZXI9eyhlKSA9PiAoZS5jdXJyZW50VGFyZ2V0LnN0eWxlLmJhY2tncm91bmRDb2xvciA9IERBUkspfVxuICAgICAgICAgICAgICAgICAgb25Nb3VzZUxlYXZlPXsoZSkgPT4gKGUuY3VycmVudFRhcmdldC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBJTkspfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxNn0gLz4gVW5kdWggSW5zdGFsbGVyIChXaW5kb3dzKSA8QXJyb3dVcFJpZ2h0IHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPC9NYWduZXRpYz5cbiAgICAgICAgICAgICAgey8qIFRvbWJvbCBidWthIGRpIGJyb3dzZXIgKi99XG4gICAgICAgICAgICAgIDxNYWduZXRpYyBjbGFzc05hbWU9XCJoZXJvLWN0YSB3LWZ1bGwgc206dy1hdXRvXCIgc3RyZW5ndGg9ezAuMjV9PlxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gcHgtNyBweS0zLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYm9yZGVyQ29sb3I6IGAke0lOS30zM2AsIGNvbG9yOiBJTksgfX1cbiAgICAgICAgICAgICAgICAgIG9uTW91c2VFbnRlcj17KGUpID0+IHsgZS5jdXJyZW50VGFyZ2V0LnN0eWxlLmJvcmRlckNvbG9yID0gYCR7SU5LfTgwYDsgZS5jdXJyZW50VGFyZ2V0LnN0eWxlLmJhY2tncm91bmRDb2xvciA9IGAke0lOS30wRGA7IH19XG4gICAgICAgICAgICAgICAgICBvbk1vdXNlTGVhdmU9eyhlKSA9PiB7IGUuY3VycmVudFRhcmdldC5zdHlsZS5ib3JkZXJDb2xvciA9IGAke0lOS30zM2A7IGUuY3VycmVudFRhcmdldC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSAndHJhbnNwYXJlbnQnOyB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxHbG9iZSBzaXplPXsxNn0gc3R5bGU9e3sgY29sb3I6IGAke0lOS304MGAgfX0gLz4gQnVrYSBkaSBicm93c2VyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICA8L01hZ25ldGljPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJoZXJvLW1ldGEgdGV4dC1zbSBtdC05IGZvbnQtbWVkaXVtXCIgc3R5bGU9e3sgY29sb3I6IGAke0lOS302NmAgfX0+XG4gICAgICAgICAgICAgIEdyYXRpcyB0YW5wYSBiYXRhcyByZXNwb25zXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm14LTIuNVwiIHN0eWxlPXt7IGNvbG9yOiBHUkVFTiB9fT7igKI8L3NwYW4+XG4gICAgICAgICAgICAgIFNpbmtyb24gd2ViICZhbXA7IG1vYmlsZVxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJteC0yLjVcIiBzdHlsZT17eyBjb2xvcjogR1JFRU4gfX0+4oCiPC9zcGFuPlxuICAgICAgICAgICAgICBRUiBjb2RlIGJhd2FhblxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIHBvbnNlbCBoZXJvOiBpbnRybyDihpIgZmFsbCB3cmFwcGVyIOKGkiBmbG9hdCDihpIgdGlsdCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgbGc6anVzdGlmeS1lbmRcIiBzdHlsZT17eyBwZXJzcGVjdGl2ZTogJzE0MDBweCcgfX0+XG4gICAgICAgICAgICA8ZGl2IHJlZj17cGhvbmVGYWxsUmVmfT5cbiAgICAgICAgICAgICAgPGRpdiByZWY9e3Bob25lSW50cm9SZWZ9PlxuICAgICAgICAgICAgICAgIDxkaXYgcmVmPXtwaG9uZUZsb2F0UmVmfT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1bMjcwcHhdXCIgb25Nb3VzZU1vdmU9e2hhbmRsZU1vdXNlTW92ZX0gb25Nb3VzZUxlYXZlPXtoYW5kbGVNb3VzZUxlYXZlfT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTggbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiB3LTUyIGgtNyByb3VuZGVkLWZ1bGwgYmx1ci0yeGxcIlxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYCR7R1JFRU59NDBgIH19IC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgcmVmPXtwaG9uZVRpbHRSZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC1bNDRweF0gcC0yLjUgYm9yZGVyIGJvcmRlci13aGl0ZS8yNVwiXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybVN0eWxlOiAncHJlc2VydmUtM2QnLFxuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCgxODBkZWcsICMzMzQxM0EgMCUsICMxNzIxMUMgMTAwJSknLFxuICAgICAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiAnMCAzNnB4IDgwcHggLTIycHggcmdiYSgyOCwzOCwzMiwwLjU1KScsXG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgcmVmPXtnbGFyZVJlZn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgcm91bmRlZC1bNDJweF0gcG9pbnRlci1ldmVudHMtbm9uZSBvcGFjaXR5LTYwIG1peC1ibGVuZC1vdmVybGF5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6ICdyYWRpYWwtZ3JhZGllbnQoY2lyY2xlIGF0IDUwJSAyMCUsIHJnYmEoMjU1LDI1NSwyNTUsMC4xOCkgMCUsIHRyYW5zcGFyZW50IDU1JSknIH19XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtWzM0cHhdIHAtNSBhc3BlY3QtWzkvMThdIGZsZXggZmxleC1jb2wgZ2FwLTQgdGV4dC1sZWZ0IG92ZXJmbG93LWhpZGRlblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6ICcjMEUxNjEzJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yMCBoLTQgcm91bmRlZC1mdWxsIG14LWF1dG8gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgcHgtMlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyMxODI0MjAnIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYCR7TElHSFR9Q0NgIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xIHAtMSByb3VuZGVkLWxnXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjA1KScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1tbJ3F1aXonLCAnS3VpcyddLCBbJ3N1cnZleScsICdTdXJ2ZWknXV0ubWFwKChbaWQsIGxhYmVsXSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2lkfSBvbkNsaWNrPXsoKSA9PiBzZXRQcmVzZXQoaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCAke3ByZXNldCA9PT0gaWQgPyAndGV4dC13aGl0ZScgOiAndGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC1zdG9uZS0yMDAnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXtwcmVzZXQgPT09IGlkID8geyBiYWNrZ3JvdW5kQ29sb3I6IEdSRUVOIH0gOiB7fX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJsaW5rXCIgc3R5bGU9e3sgY29sb3I6IExJR0hUIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogTElHSFQgfX0gLz4gTElWRVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAge3ByZXNldCA9PT0gJ3F1aXonID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgcC0zLjUgc3BhY2UteS0yLjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjU1LDI1NSwyNTUsMC4wNCknLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSgyNTUsMjU1LDI1NSwwLjA3KScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5VamlhbiBIYXJpYW4gRmlzaWthPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zdG9uZS00MDAgbXQtMC41XCI+MTAgc29hbCDCtyAxNSBtZW5pdDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXN0b25lLTIwMFwiPjEuIFNhdHVhbiBTSSB1bnR1ayBnYXlhIGFkYWxhaOKApjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xLjUgcm91bmRlZC1tZCB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtY2VudGVyIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IEdSRUVOIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgc2l6ZT17MTB9IC8+IE5ld3RvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7WydKb3VsZScsICdQYXNjYWwnLCAnV2F0dCddLm1hcCgobykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17b30gY2xhc3NOYW1lPVwicHktMS41IHJvdW5kZWQtbWQgdGV4dC1bMTBweF0gdGV4dC1jZW50ZXIgdGV4dC1zdG9uZS00MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjU1LDI1NSwyNTUsMC4wNSknIH19PntvfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIHAtMy41IHNwYWNlLXktMi41XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6ICdyZ2JhKDI1NSwyNTUsMjU1LDAuMDQpJywgYm9yZGVyOiAnMXB4IHNvbGlkIHJnYmEoMjU1LDI1NSwwLjA3KScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5TdXJ2ZWkgS2VwdWFzYW4gS2VsYXM8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXN0b25lLTQwMCBtdC0wLjVcIj5Bbm9uaW0gwrcgMiBwZXJ0YW55YWFuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc3RvbmUtMjAwXCI+U2ViZXJhcGEgamVsYXMgbWF0ZXJpIGhhcmkgaW5pPzwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcHktMS41IHJvdW5kZWQtbWQgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWNlbnRlciB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBHUkVFTiB9fT5TYW5nYXQgamVsYXM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTEuNSByb3VuZGVkLW1kIHRleHQtWzEwcHhdIHRleHQtY2VudGVyIHRleHQtc3RvbmUtNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjA1KScgfX0+Q3VrdXA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgcHgtMyBweS0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYCR7R1JFRU59MUZgLCBib3JkZXI6IGAxcHggc29saWQgJHtHUkVFTn00MGAgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbWVkaXVtXCIgc3R5bGU9e3sgY29sb3I6IExJR0hUIH19PlRlcnNpbmtyb24gZGVuZ2FuIHdlYjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrIHNpemU9ezEzfSBzdHlsZT17eyBjb2xvcjogTElHSFQgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LWF1dG8gcHQtMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTBweF0gdGV4dC1zdG9uZS01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBib3JkZXJUb3A6ICcxcHggc29saWQgcmdiYSgyNTUsMjU1LDI1NSwwLjA3KScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPmZvcm11cC5hcHA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBMSUdIVCB9fT5UZXJodWJ1bmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiDilZDilZDilZAgUklUVUFMIOKAlCBzdGFja2VkIHBpbm5pbmcg4pWQ4pWQ4pWQICovfVxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAge1JJVFVBTF9MSU5FUy5tYXAoKGxpbmUsIGkpID0+IChcbiAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwicml0dWFsLXBhbmVsIHJlbGF0aXZlIG1pbi1oLVs4NXZoXSBtZDptaW4taC1zY3JlZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHgtNlwiXG4gICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGkgJSAyID09PSAxID8gVElOVCA6IENSRUFNLCB6SW5kZXg6IGkgKyAyIH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXR1YWwtaW5uZXIgdGV4dC1jZW50ZXIgbWF4LXctM3hsXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRyYWNraW5nLVswLjJlbV0gdXBwZXJjYXNlIG1iLTZcIiBzdHlsZT17eyBjb2xvcjogR1JFRU4gfX0+XG4gICAgICAgICAgICAgICAgUml0dWFsIGxhbWEgwrcge2kgKyAxfSBkYXJpIHtSSVRVQUxfTElORVMubGVuZ3RofVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNHhsIHNtOnRleHQtNnhsIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IGxlYWRpbmctWzEuMDhdXCI+e2xpbmV9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpdHVhbC1wYW5lbCByZWxhdGl2ZSBtaW4taC1bODV2aF0gbWQ6bWluLWgtc2NyZWVuIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB4LTZcIlxuICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogR1JFRU4sIHpJbmRleDogUklUVUFMX0xJTkVTLmxlbmd0aCArIDIgfX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXR1YWwtaW5uZXIgdGV4dC1jZW50ZXIgbWF4LXctM3hsXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0cmFja2luZy1bMC4yZW1dIHVwcGVyY2FzZSBtYi03XCIgc3R5bGU9e3sgY29sb3I6ICcjRjZGNEVEQjMnIH19PlxuICAgICAgICAgICAgICBMYWx1IEZvcm1VcCBiZXJ0YW55YVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC01eGwgc206dGV4dC03eGwgZm9udC1leHRyYWJvbGQgdHJhY2tpbmctdGlnaHQgbGVhZGluZy1bMS4wNV0gdGV4dC1bI0Y2RjRFRF1cIj5cbiAgICAgICAgICAgICAgS2VuYXBhIGhhcnVzeycgJ31cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZXJpZml0IGl0YWxpYyBmb250LW5vcm1hbFwiPnNlc3VsaXQgaXR1Pzwvc3Bhbj5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiDilZDilZDilZAgTUFOSUZFU1RPIOKVkOKVkOKVkCAqL31cbiAgICAgIDxzZWN0aW9uIGlkPVwibWFuaWZlc3RvXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgcHgtNiBweS0yOCBtZDpweS00MFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogQ1JFQU0sIHpJbmRleDogMTAgfX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctM3hsIG14LWF1dG9cIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtLXJldmVhbCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFja2luZy1bMC4xOGVtXSB1cHBlcmNhc2UgbWItOFwiIHN0eWxlPXt7IGNvbG9yOiBHUkVFTiB9fT5cbiAgICAgICAgICAgIE1hbmlmZXN0b1xuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBtZDp0ZXh0LVsyLjRyZW1dIGZvbnQtbWVkaXVtIGxlYWRpbmctc251ZyBtZDpsZWFkaW5nLVsxLjM1XSB0cmFja2luZy1bLTAuMDFlbV1cIj5cbiAgICAgICAgICAgIHtNQU5JRkVTVE8uc3BsaXQoJyAnKS5tYXAoKHcsIGkpID0+IChcbiAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJtd29yZCBpbmxpbmUtYmxvY2sgbXItWzAuMjhlbV1cIj57d308L3NwYW4+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7Lyog4pWQ4pWQ4pWQIEFMVVIg4oCUIEdTQVAgcGluIGhvcml6b250YWwgc2NydWIg4pWQ4pWQ4pWQICovfVxuICAgICAgPHNlY3Rpb24gaWQ9XCJhbHVyXCIgY2xhc3NOYW1lPVwicmVsYXRpdmVcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFRJTlQsIHpJbmRleDogMTAgfX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2YtcHJvZ3Jlc3MgYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHJpZ2h0LTAgaC0xIG9yaWdpbi1sZWZ0IHNjYWxlLXgtMCB6LTMwXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBHUkVFTiB9fSAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LWhpZGRlbiBweS0yNCBtZDpweS0wXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IG1kOnB4LVs3dnddIG1iLTEwIG1kOm1iLTE0IGZsZXggaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBnYXAtNlwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibS1yZXZlYWwgdGV4dC14cyBmb250LWJvbGQgdHJhY2tpbmctWzAuMThlbV0gdXBwZXJjYXNlIG1iLTRcIiBzdHlsZT17eyBjb2xvcjogR1JFRU4gfX0+XG4gICAgICAgICAgICAgICAgQ2FyYSBrZXJqYVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJtLXJldmVhbCB0ZXh0LTN4bCBzbTp0ZXh0LTV4bCBmb250LWV4dHJhYm9sZCB0cmFja2luZy10aWdodCBsZWFkaW5nLVsxLjA1XVwiPlxuICAgICAgICAgICAgICAgIEVtcGF0IGxhbmdrYWguPGJyIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZXJpZml0IGl0YWxpYyBmb250LW5vcm1hbFwiIHN0eWxlPXt7IGNvbG9yOiBHUkVFTiB9fT5Ob2wgcmliZXQuPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYWNraW5nLXdpZGUgdXBwZXJjYXNlXCIgc3R5bGU9e3sgY29sb3I6IGAke0lOS302NmAgfX0+XG4gICAgICAgICAgICAgIFNjcm9sbCA8QXJyb3dVcFJpZ2h0IHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3Zi10cmFjayBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGdhcC01IG1kOmdhcC1bMi41dnddIHB4LTYgbWQ6cHgtWzd2d10gbWQ6dy1tYXggd2lsbC1jaGFuZ2UtdHJhbnNmb3JtXCI+XG4gICAgICAgICAgICB7V09SS0ZMT1cubWFwKChzdGVwKSA9PiAoXG4gICAgICAgICAgICAgIDxhcnRpY2xlIGtleT17c3RlcC5udW19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgc2hyaW5rLTAgcC04IG1kOnAtMTAgcm91bmRlZC0zeGwgYm9yZGVyIG92ZXJmbG93LWhpZGRlbiBtZDp3LVszNnZ3XSBsZzp3LVsyOHZ3XSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi01MDBcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogQ1JFQU0sIGJvcmRlckNvbG9yOiBgJHtJTkt9MUFgIH19XG4gICAgICAgICAgICAgICAgb25Nb3VzZUVudGVyPXsoZSkgPT4gKGUuY3VycmVudFRhcmdldC5zdHlsZS5ib3JkZXJDb2xvciA9IGAke0dSRUVOfTgwYCl9XG4gICAgICAgICAgICAgICAgb25Nb3VzZUxlYXZlPXsoZSkgPT4gKGUuY3VycmVudFRhcmdldC5zdHlsZS5ib3JkZXJDb2xvciA9IGAke0lOS30xQWApfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTggLXJpZ2h0LTMgdGV4dC1bMTByZW1dIGZvbnQtZXh0cmFib2xkIGxlYWRpbmctbm9uZSBzZWxlY3Qtbm9uZSBwb2ludGVyLWV2ZW50cy1ub25lXCJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBgJHtJTkt9MDhgIH19PlxuICAgICAgICAgICAgICAgICAge3N0ZXAubnVtfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgbWItNiByZWxhdGl2ZVwiIHN0eWxlPXt7IGNvbG9yOiBHUkVFTiB9fT57c3RlcC5udW19PC9wPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWV4dHJhYm9sZCBtYi0zIHJlbGF0aXZlXCI+e3N0ZXAudGl0bGV9PC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCByZWxhdGl2ZVwiIHN0eWxlPXt7IGNvbG9yOiBgJHtJTkt9OTlgIH19PntzdGVwLmRlc2N9PC9wPlxuICAgICAgICAgICAgICA8L2FydGljbGU+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiDilZDilZDilZAgQ0VSSVRBIOKAlCBwb25zZWwgbWVuZW1hbmkgc2Nyb2xsIDIsNSBsYXlhciDilZDilZDilZAgKi99XG4gICAgICA8c2VjdGlvbiBpZD1cImNlcml0YVwiIGNsYXNzTmFtZT1cInJlbGF0aXZlXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBDUkVBTSwgekluZGV4OiAxMCB9fT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjZXJpdGEtc3RhZ2UgcmVsYXRpdmUgaC1zY3JlZW4gb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy02eGwgbXgtYXV0byBoLWZ1bGwgcHgtNiBncmlkIG1kOmdyaWQtY29scy0yIGdhcC0xMCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWQ6aC1bNDIwcHhdIHB5LTEwIG1kOnB5LTBcIj5cbiAgICAgICAgICAgICAge0JFQVRTLm1hcCgoYiwgaSkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtiLm51bX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJlYXQgJHtpID09PSAwID8gJ2JlYXQtYWN0aXZlJyA6ICcnfSBtYXgtdy1tZGB9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVCZWF0KGkpfT5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRyYWNraW5nLVswLjJlbV0gdXBwZXJjYXNlIG1iLTVcIiBzdHlsZT17eyBjb2xvcjogR1JFRU4gfX0+XG4gICAgICAgICAgICAgICAgICAgIHtiLm51bX0g4oCUIHtCRUFUUy5sZW5ndGh9IGxhbmdrYWggdXRhbWFcbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBzbTp0ZXh0LTZ4bCBmb250LWV4dHJhYm9sZCB0cmFja2luZy10aWdodCBtYi01XCI+XG4gICAgICAgICAgICAgICAgICAgIHtiLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlcmlmaXQgaXRhbGljIGZvbnQtbm9ybWFsXCIgc3R5bGU9e3sgY29sb3I6IEdSRUVOIH19Pi48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGxlYWRpbmctcmVsYXhlZFwiIHN0eWxlPXt7IGNvbG9yOiBgJHtJTkt9OTlgIH19PntiLmRlc2N9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6ZmxleCBhYnNvbHV0ZSAtYm90dG9tLTIgbGVmdC0wIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAge0JFQVRTLm1hcCgoYiwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtiLm51bX0gY2xhc3NOYW1lPVwiaC0xLjUgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IGJlYXQgPT09IGkgPyAyOCA6IDEwLFxuICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogYmVhdCA9PT0gaSA/IEdSRUVOIDogYCR7SU5LfTI2YCxcbiAgICAgICAgICAgICAgICAgICAgfX0gLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmZsZXgganVzdGlmeS1jZW50ZXJcIiBzdHlsZT17eyBwZXJzcGVjdGl2ZTogJzE0MDBweCcgfX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2VyaXRhLXBob25lXCI+XG4gICAgICAgICAgICAgICAgPFN0b3J5UGhvbmUgc2NyZWVuPXtzY3JlZW59IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7Lyog4pWQ4pWQ4pWQIEZJVFVSICsgU1RBVElTVElLIOKVkOKVkOKVkCAqL31cbiAgICAgIDxzZWN0aW9uIGlkPVwiZml0dXJcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC02IHB5LTI0IG1kOnB5LTMyXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBDUkVBTSwgekluZGV4OiAxMCB9fT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy02eGwgbXgtYXV0b1wiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRyYWNraW5nLVswLjE4ZW1dIHVwcGVyY2FzZSBtYi00XCIgc3R5bGU9e3sgY29sb3I6IEdSRUVOIH19PlxuICAgICAgICAgICAgS2VtYW1wdWFuIHV0YW1hXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBzbTp0ZXh0LTV4bCBmb250LWV4dHJhYm9sZCB0cmFja2luZy10aWdodCBtYi0xNFwiPlxuICAgICAgICAgICAgWWFuZyBrYW11IGJ1dHVoa2FuLHsnICd9XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlcmlmaXQgaXRhbGljIGZvbnQtbm9ybWFsXCIgc3R5bGU9e3sgY29sb3I6IEdSRUVOIH19PnRpZGFrIGxlYmloLjwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtZDpncmlkLWNvbHMtMyBnYXAtNSBtYi0yMFwiPlxuICAgICAgICAgICAge0ZFQVRVUkVTLm1hcCgoZikgPT4gKFxuICAgICAgICAgICAgICA8YXJ0aWNsZSBrZXk9e2YudGl0bGV9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmVhdHVyZS1jYXJkIGdyb3VwIHJlbGF0aXZlIHAtOCByb3VuZGVkLTN4bCBib3JkZXIgYmctd2hpdGUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwIGhvdmVyOi10cmFuc2xhdGUteS0xLjVcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJvcmRlckNvbG9yOiBgJHtJTkt9MTRgLCBib3hTaGFkb3c6ICcwIDFweCAycHggcmdiYSgyOCwzOCwzMiwwLjA1KScgfX1cbiAgICAgICAgICAgICAgICBvbk1vdXNlRW50ZXI9eyhlKSA9PiAoZS5jdXJyZW50VGFyZ2V0LnN0eWxlLmJvcmRlckNvbG9yID0gYCR7R1JFRU59NjZgKX1cbiAgICAgICAgICAgICAgICBvbk1vdXNlTGVhdmU9eyhlKSA9PiAoZS5jdXJyZW50VGFyZ2V0LnN0eWxlLmJvcmRlckNvbG9yID0gYCR7SU5LfTE0YCl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC0xMSByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTYgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tNTAwIGdyb3VwLWhvdmVyOnNjYWxlLTExMFwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGAke0dSRUVOfTE0YCwgY29sb3I6IEdSRUVOIH19PlxuICAgICAgICAgICAgICAgICAgPGYuaWNvbiBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCBtYi0yLjVcIj57Zi50aXRsZX08L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1yZWxheGVkXCIgc3R5bGU9e3sgY29sb3I6IGAke0lOS305OWAgfX0+e2YuZGVzY308L3A+XG4gICAgICAgICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBzbTpncmlkLWNvbHMtMyBnYXAteS0xMiBnYXAteC04IHB0LTEyXCIgc3R5bGU9e3sgYm9yZGVyVG9wOiBgMXB4IHNvbGlkICR7SU5LfTE0YCB9fT5cbiAgICAgICAgICAgIDxTdGF0IHZhbHVlPXszfSBzdWZmaXg9XCIgbWVuaXRcIiBsYWJlbD1cInJhdGEtcmF0YSB3YWt0dSBtZW1idWF0IHNhdHUgZm9ybXVsaXJcIiAvPlxuICAgICAgICAgICAgPFN0YXQgdmFsdWU9ezEwMH0gc3VmZml4PVwiJVwiIGxhYmVsPVwiZ3JhdGlzLCB0YW5wYSBiYXRhcyBqdW1sYWggcmVzcG9uc1wiIC8+XG4gICAgICAgICAgICA8U3RhdCB2YWx1ZT17MX0gc3VmZml4PVwiIGtsaWtcIiBsYWJlbD1cInVudHVrIGVrc3BvciByZWthcCBrZSBDU1YgLyBYTFNYXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiDilZDilZDilZAgRkFRIOKVkOKVkOKVkCAqL31cbiAgICAgIDxzZWN0aW9uIGlkPVwiZmFxXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgcHgtNiBwYi0yNCBtZDpwYi0zMlwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogQ1JFQU0sIHpJbmRleDogMTAgfX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctMnhsIG14LWF1dG9cIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1jZW50ZXIgbWItMTJcIj5cbiAgICAgICAgICAgIFBlcnRhbnlhYW4gdW11bVxuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIHtGQVFTLm1hcCgoZmFxLCBpKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IG9wZW4gPSBvcGVuRmFxID09PSBpO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJmYXEtY2FyZCByb3VuZGVkLTJ4bCBib3JkZXIgYmctd2hpdGUgb3ZlcmZsb3ctaGlkZGVuIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMFwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBib3JkZXJDb2xvcjogb3BlbiA/IGAke0dSRUVOfTgwYCA6IGAke0lOS30xNGAgfX0+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldE9wZW5GYXEob3BlbiA/IG51bGwgOiBpKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtNSB0ZXh0LWxlZnQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IGZvbnQtc2VtaWJvbGQgdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBvcGVuID8gR1JFRU4gOiBJTksgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntmYXEucX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy03IGgtNyByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hyaW5rLTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiBvcGVuID8gJ3JvdGF0ZSgxODBkZWcpJyA6ICdub25lJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogb3BlbiA/IGAke0dSRUVOfTFGYCA6IGAke0lOS30wRGAsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogb3BlbiA/IEdSRUVOIDogYCR7SU5LfTgwYCxcbiAgICAgICAgICAgICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0XCJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZ3JpZFRlbXBsYXRlUm93czogb3BlbiA/ICcxZnInIDogJzBmcicsIG9wYWNpdHk6IG9wZW4gPyAxIDogMCB9fT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJweC01IHBiLTUgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgcHQtNFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogYCR7SU5LfTk5YCwgYm9yZGVyVG9wOiBgMXB4IHNvbGlkICR7SU5LfTBGYCB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmYXEuYX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiDilZDilZDilZAgRklOQUxFIOKAlCB0ZXBhdCBzYXR1IGxheWFyIHBlbnVoIOKVkOKVkOKVkCAqL31cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJlbGF0aXZlIHRleHQtWyNGNkY0RURdIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sXCJcbiAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiAnMTAwdmgnLCBiYWNrZ3JvdW5kOiBgbGluZWFyLWdyYWRpZW50KDE4MGRlZywgJHtDUkVBTX0gMCUsICR7REFSS30gMTQlLCAke0RBUkt9IDEwMCUpYCwgekluZGV4OiAxMCB9fT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1jZW50ZXIgcHgtNiBtYXgtdy0zeGwgbXgtYXV0byB3LWZ1bGwgcHQtMjBcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtLXJldmVhbCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFja2luZy1bMC4xOGVtXSB1cHBlcmNhc2UgbWItNVwiIHN0eWxlPXt7IGNvbG9yOiBMSUdIVCB9fT5cbiAgICAgICAgICAgIEFwbGlrYXNpIEFuZHJvaWRcbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm0tcmV2ZWFsIHRleHQtNHhsIHNtOnRleHQtNXhsIGxnOnRleHQtNnhsIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IGxlYWRpbmctWzEuMDVdIG1iLTVcIj5cbiAgICAgICAgICAgIEJhd2EgRm9ybVVweycgJ31cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VyaWZpdCBpdGFsaWMgZm9udC1ub3JtYWxcIiBzdHlsZT17eyBjb2xvcjogTElHSFQgfX0+a2UgbWFuYS1tYW5hLjwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm0tcmV2ZWFsIHRleHQtc20gc206dGV4dC1iYXNlIG1heC13LW1kIG14LWF1dG8gbGVhZGluZy1yZWxheGVkIG1iLThcIiBzdHlsZT17eyBjb2xvcjogJyNGNkY0RURBNicgfX0+XG4gICAgICAgICAgICBEYWZ0YXIgbGV3YXQgYnJvd3NlciBzZWthcmFuZywgcGFzYW5nIGFwbGlrYXNpbnlhIHNlc3VkYWhueWEg4oCUXG4gICAgICAgICAgICBzZW11YSBmb3JtdWxpcm11IHN1ZGFoIG1lbnVuZ2d1IGRpIHNhbmEuXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibS1yZXZlYWwgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMuNVwiPlxuICAgICAgICAgICAgey8qIFRvbWJvbCBkb3dubG9hZCBBUEsgKi99XG4gICAgICAgICAgICA8TWFnbmV0aWM+XG4gICAgICAgICAgICAgIDxhIGhyZWY9e0FQS19VUkx9IGRvd25sb2FkPVwiZm9ybXVwLWFuZHJvaWQuYXBrXCIgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNyBweS0zLjUgdGV4dC1zbSBmb250LWJvbGQgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMFwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBHUkVFTiwgY29sb3I6ICcjRjZGNEVEJyB9fVxuICAgICAgICAgICAgICAgIG9uTW91c2VFbnRlcj17KGUpID0+IChlLmN1cnJlbnRUYXJnZXQuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gTElHSFQpfVxuICAgICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17KGUpID0+IChlLmN1cnJlbnRUYXJnZXQuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gR1JFRU4pfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFNtYXJ0cGhvbmUgc2l6ZT17MTZ9IC8+IFVuZHVoIEFQSyAoQW5kcm9pZClcbiAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPC9NYWduZXRpYz5cbiAgICAgICAgICAgIHsvKiBUb21ib2wgZG93bmxvYWQgV2luZG93cyBpbnN0YWxsZXIgKi99XG4gICAgICAgICAgICA8TWFnbmV0aWM+XG4gICAgICAgICAgICAgIDxhIGhyZWY9e0VYRV9VUkx9IGRvd25sb2FkPVwiZm9ybXVwLXdpbmRvd3MtaW5zdGFsbGVyLmV4ZVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTcgcHktMy41IHRleHQtc20gZm9udC1ib2xkIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDBcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogSU5LLCBjb2xvcjogJyNGNkY0RUQnIH19XG4gICAgICAgICAgICAgICAgb25Nb3VzZUVudGVyPXsoZSkgPT4gKGUuY3VycmVudFRhcmdldC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBEQVJLKX1cbiAgICAgICAgICAgICAgICBvbk1vdXNlTGVhdmU9eyhlKSA9PiAoZS5jdXJyZW50VGFyZ2V0LnN0eWxlLmJhY2tncm91bmRDb2xvciA9IElOSyl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8RG93bmxvYWQgc2l6ZT17MTZ9IC8+IFVuZHVoIEluc3RhbGxlciAoV2luZG93cylcbiAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPC9NYWduZXRpYz5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL3JlZ2lzdGVyXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNyBweS0zLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBib3JkZXIgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICBzdHlsZT17eyBib3JkZXJDb2xvcjogJyNGNkY0RUQzMycsIGNvbG9yOiAnI0Y2RjRFRENDJyB9fVxuICAgICAgICAgICAgICBvbk1vdXNlRW50ZXI9eyhlKSA9PiB7IGUuY3VycmVudFRhcmdldC5zdHlsZS5ib3JkZXJDb2xvciA9ICcjRjZGNEVEODAnOyBlLmN1cnJlbnRUYXJnZXQuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gJyNGNkY0RUQwRCc7IH19XG4gICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17KGUpID0+IHsgZS5jdXJyZW50VGFyZ2V0LnN0eWxlLmJvcmRlckNvbG9yID0gJyNGNkY0RUQzMyc7IGUuY3VycmVudFRhcmdldC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSAndHJhbnNwYXJlbnQnOyB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBEYWZ0YXIgZ3JhdGlzIDxBcnJvd1VwUmlnaHQgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiB0cmlvIDNEIChkZXNrdG9wIHNhamEsIGFnYXIgbXVhdCBzYXR1IGxheWFyKSAqL31cbiAgICAgICAgPGRpdiBpZD1cInRyaW9cIiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6ZmxleCBpdGVtcy1lbmQganVzdGlmeS1jZW50ZXIgZ2FwLTYgbGc6Z2FwLTggcHgtNiBzaHJpbmstMFwiXG4gICAgICAgICAgc3R5bGU9e3sgcGVyc3BlY3RpdmU6ICcxNDAwcHgnIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJpby1sZWZ0IHctMjggbGc6dy0zMiBzaHJpbmstMCByb3VuZGVkLVsyOHB4XSBib3JkZXIgYm9yZGVyLXdoaXRlLzE1IHAtMiBzaGFkb3ctMnhsXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCAjMkUzQjMzIDAlLCAjMTMxQzE3IDEwMCUpJyB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCByb3VuZGVkLVsyMnB4XSBwLTMgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBnYXAtMiB0ZXh0LWxlZnQgYXNwZWN0LVs5LzE5XVwiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyMwQjEyMTAnIH19PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTEuNSByb3VuZGVkLWZ1bGwgbXgtYXV0b1wiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyM1QkM5OEM2NicgfX0gLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTQwMFwiPkFuYWxpdGlrIHJlc3BvbjwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBoLTkgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LVs5cHhdIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHtHUkVFTn0yNmAsIGJvcmRlcjogYDFweCBzb2xpZCAke0dSRUVOfTU5YCwgY29sb3I6IExJR0hUIH19PlxuICAgICAgICAgICAgICAgIDk4JSBzZWxlc2FpXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBoLTEgcm91bmRlZC1mdWxsXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjEpJyB9fSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRyaW8tY2VudGVyIHctMzYgbGc6dy00NCBzaHJpbmstMCByb3VuZGVkLVszNHB4XSBib3JkZXIgYm9yZGVyLXdoaXRlLzI1IHAtMi41XCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCAjMzg0NzNFIDAlLCAjMTMxQzE3IDEwMCUpJywgYm94U2hhZG93OiAnMCAzMHB4IDcwcHggcmdiYSgwLDAsMCwwLjUpJyB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCByb3VuZGVkLVsyNnB4XSBwLTQgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1sZWZ0IGFzcGVjdC1bOS8xOV1cIlxuICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6ICcjMEIxMjEwJyB9fT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMyByb3VuZGVkLWZ1bGwgbXgtYXV0b1wiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyMxNjIxMUInIH19IC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+Rm9ybVVwIE1vYmlsZTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtbGcgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZFwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGAke0dSRUVOfTI2YCwgYm9yZGVyOiBgMXB4IHNvbGlkICR7R1JFRU59NTlgLCBjb2xvcjogTElHSFQgfX0+XG4gICAgICAgICAgICAgICAgICBTaW5rcm9uaXNhc2kgYWt0aWZcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSByb3VuZGVkLWxnIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IEdSRUVOIH19PlxuICAgICAgICAgICAgICAgIFNpYXAgZGlndW5ha2FuXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRyaW8tcmlnaHQgdy0yOCBsZzp3LTMyIHNocmluay0wIHJvdW5kZWQtWzI4cHhdIGJvcmRlciBib3JkZXItd2hpdGUvMTUgcC0yIHNoYWRvdy0yeGxcIlxuICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCgxODBkZWcsICMyRTNCMzMgMCUsICMxMzFDMTcgMTAwJSknIH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIHJvdW5kZWQtWzIycHhdIHAtMyBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGdhcC0yIHRleHQtbGVmdCBhc3BlY3QtWzkvMTldXCJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnIzBCMTIxMCcgfX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtMS41IHJvdW5kZWQtZnVsbCBteC1hdXRvXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnIzVCQzk4QzY2JyB9fSAvPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtc3RvbmUtNDAwXCI+UVIgY29kZTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLWxnIG14LWF1dG8gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci13aGl0ZS8xMFwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjA1KScgfX0+XG4gICAgICAgICAgICAgICAgPFFyQ29kZSBzaXplPXsyMH0gc3R5bGU9e3sgY29sb3I6IExJR0hUIH19IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBoLTEgcm91bmRlZC1mdWxsXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjEpJyB9fSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBmb290ZXIgYmFyIGRpIGRhbGFtIGxheWFyIHBlbnVoICovfVxuICAgICAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cInB4LTYgcHQtNSBwYi02IHNocmluay0wXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBEQVJLIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNnhsIG14LWF1dG8gZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHRleHQtc21cIlxuICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6ICcjRjZGNEVENjYnLCBib3JkZXJUb3A6ICcxcHggc29saWQgcmdiYSgyNDYsMjQ0LDIzNywwLjA4KScsIHBhZGRpbmdUb3A6ICcxLjI1cmVtJyB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGltZyBzcmM9e2xvZ299IGFsdD1cIkZvcm1VcFwiIGNsYXNzTmFtZT1cInctNSBoLTUgb2JqZWN0LWNvbnRhaW4gb3BhY2l0eS03MFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LVsjRjZGNEVEQ0NdXCI+Rm9ybVVwPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJteC0xXCI+wrc8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPsKpIHtuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCl9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC03XCI+XG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCIgY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC1bI0Y2RjRFRF0gdHJhbnNpdGlvbi1jb2xvcnNcIj5NYXN1azwvTGluaz5cbiAgICAgICAgICAgICAgPExpbmsgdG89XCIvcmVnaXN0ZXJcIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LVsjRjZGNEVEXSB0cmFuc2l0aW9uLWNvbG9yc1wiPkRhZnRhcjwvTGluaz5cbiAgICAgICAgICAgICAgPGEgaHJlZj17QVBLX1VSTH0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtWyNGNkY0RURdIHRyYW5zaXRpb24tY29sb3JzXCI+QXBsaWthc2kgQW5kcm9pZDwvYT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Zvb3Rlcj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgIDwvZGl2PlxuICApO1xufVxuIl19