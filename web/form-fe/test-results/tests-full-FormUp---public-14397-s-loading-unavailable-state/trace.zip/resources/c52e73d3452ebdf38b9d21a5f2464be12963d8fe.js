import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/profile/ProfilePage.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { User, Lock, Upload, Save, ArrowLeft } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import { getMyProfile, updateProfile, changePassword, uploadProfileImage, clearSession, assetUrl, saveSession, getLocalUser } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/profile/ProfilePage.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function ProfilePage() {
	_s();
	const navigate = useNavigate();
	const [profile, setProfile] = useState(null);
	const [loading, setLoading] = useState(true);
	const [saving, setSaving] = useState(false);
	const [toast, setToast] = useState(null);
	// Profile form
	const [fullname, setFullname] = useState("");
	const [username, setUsername] = useState("");
	const [email, setEmail] = useState("");
	const [birthdate, setBirthdate] = useState("");
	// Password form
	const [oldPassword, setOldPassword] = useState("");
	const [newPassword, setNewPassword] = useState("");
	const [confirmPassword, setConfirmPassword] = useState("");
	const [pwLoading, setPwLoading] = useState(false);
	const [pwError, setPwError] = useState("");
	useEffect(() => {
		const load = async () => {
			setLoading(true);
			const res = await getMyProfile();
			if (res.status === 401) {
				clearSession();
				navigate("/login");
				return;
			}
			if (res.ok && res.data) {
				const d = res.data;
				setProfile(d);
				setFullname(d.fullname || "");
				setUsername(d.username || "");
				setEmail(d.email || "");
				setBirthdate(d.birthdate ? d.birthdate.substring(0, 10) : "");
			}
			setLoading(false);
		};
		load();
	}, [navigate]);
	const showToast = (msg, type = "success") => {
		setToast({
			msg,
			type
		});
		setTimeout(() => setToast(null), 3e3);
	};
	const handleSaveProfile = async (e) => {
		e.preventDefault();
		setSaving(true);
		const res = await updateProfile({
			fullname,
			username,
			birthdate
		});
		setSaving(false);
		if (res.ok) {
			const updated = {
				...profile,
				fullname,
				username,
				birthdate
			};
			setProfile(updated);
			const current = getLocalUser();
			if (current) saveSession({
				token: localStorage.getItem("token"),
				user: {
					...current,
					fullname,
					username
				}
			});
			showToast("Profil berhasil diperbarui!");
		} else {
			showToast(res.message || "Gagal memperbarui profil", "error");
		}
	};
	const handleAvatarUpload = async (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const res = await uploadProfileImage(file);
		if (res.ok) {
			const updated = await getMyProfile();
			if (updated.ok) {
				setProfile(updated.data);
				const current = getLocalUser();
				if (current) saveSession({
					token: localStorage.getItem("token"),
					user: {
						...current,
						profileImage: updated.data.profileImage
					}
				});
			}
			showToast("Foto profil berhasil diubah!");
		} else {
			showToast(res.message || "Gagal mengunggah foto profil", "error");
		}
	};
	const handleUpdatePassword = async (e) => {
		e.preventDefault();
		setPwError("");
		if (newPassword !== confirmPassword) {
			setPwError("Kata sandi baru dan konfirmasi tidak cocok.");
			return;
		}
		if (newPassword.length < 8) {
			setPwError("Kata sandi minimal harus 8 karakter.");
			return;
		}
		setPwLoading(true);
		const res = await changePassword(oldPassword, newPassword);
		setPwLoading(false);
		if (res.ok) {
			setOldPassword("");
			setNewPassword("");
			setConfirmPassword("");
			showToast("Kata sandi berhasil diperbarui!");
		} else {
			setPwError(res.message || "Gagal memperbarui kata sandi.");
		}
	};
	if (loading) return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center justify-center min-h-screen bg-[#F4F8F7] dark:bg-slate-950",
		children: /* @__PURE__ */ _jsxDEV("p", {
			className: "text-slate-400 dark:text-slate-500 text-sm font-medium",
			children: "Memuat data profil..."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 112,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 111,
		columnNumber: 9
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen w-full bg-[#F4F8F7] dark:bg-slate-950 font-sans antialiased text-slate-800 dark:text-slate-100 transition-colors",
		children: [/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex-1 flex flex-col min-w-0 overflow-y-auto",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 py-4 flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigate("/dashboard"),
						className: "p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-base font-extrabold text-slate-900 dark:text-white",
						children: "Pengaturan Akun & Profil"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400 dark:text-slate-500",
						children: "Kelola informasi identitas, foto profil, dan kata sandi Anda."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 25
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 17
				}, this),
				toast && /* @__PURE__ */ _jsxDEV("div", {
					className: `fixed top-4 right-4 z-50 px-4 py-3 rounded-2xl shadow-xl text-xs font-bold text-white transition-all ${toast.type === "error" ? "bg-red-500" : "bg-[#00897B]"}`,
					children: toast.msg
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-6 max-w-2xl mx-auto w-full space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs flex items-center gap-6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "relative group",
								children: [/* @__PURE__ */ _jsxDEV("img", {
									src: assetUrl(profile?.profileImage, `https://ui-avatars.com/api/?name=${encodeURIComponent(profile?.fullname || "U")}&background=00897B&color=fff&size=128`),
									alt: profile?.fullname,
									className: "w-20 h-20 rounded-2xl object-cover border-2 border-[#00897B]/30 dark:border-teal-500/40 shadow-sm"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("label", {
									className: "absolute inset-0 bg-black/40 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-white",
									children: [/* @__PURE__ */ _jsxDEV(Upload, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/*",
										className: "hidden",
										onChange: handleAvatarUpload
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 152,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-base font-bold text-slate-900 dark:text-white",
										children: profile?.fullname
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 156,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 dark:text-slate-500 font-mono",
										children: ["@", profile?.username]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 157,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("label", {
										className: "inline-flex items-center gap-1.5 text-xs font-bold text-[#00897B] dark:text-teal-400 hover:underline cursor-pointer pt-1",
										children: [
											/* @__PURE__ */ _jsxDEV(Upload, { size: 12 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 159,
												columnNumber: 33
											}, this),
											" Ubah Foto Profil",
											/* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "image/*",
												className: "hidden",
												onChange: handleAvatarUpload
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 160,
												columnNumber: 33
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 158,
										columnNumber: 29
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3",
								children: [/* @__PURE__ */ _jsxDEV(User, {
									size: 16,
									className: "text-[#00897B] dark:text-teal-400"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 168,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider",
									children: "Informasi Pribadi"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("form", {
								onSubmit: handleSaveProfile,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
											children: "Nama Lengkap"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 175,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											required: true,
											value: fullname,
											onChange: (e) => setFullname(e.target.value),
											className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-semibold bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 176,
											columnNumber: 37
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 174,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
											children: "Nama Pengguna (Username)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 185,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											required: true,
											value: username,
											onChange: (e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, "")),
											className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-mono font-semibold bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 186,
											columnNumber: 37
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 184,
											columnNumber: 33
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
											children: "Alamat Email"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 197,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "email",
											disabled: true,
											value: email,
											className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-semibold bg-slate-50 dark:bg-slate-800/50 text-slate-400 dark:text-slate-500 cursor-not-allowed"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 198,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-slate-400 dark:text-slate-500 mt-1",
											children: "Alamat email terdaftar tidak dapat diubah secara langsung."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 204,
											columnNumber: 33
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
										children: "Tanggal Lahir"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 208,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "date",
										value: birthdate,
										onChange: (e) => setBirthdate(e.target.value),
										className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-semibold bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 209,
										columnNumber: 33
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 207,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pt-2 flex justify-end",
										children: /* @__PURE__ */ _jsxDEV("button", {
											type: "submit",
											disabled: saving,
											className: "flex items-center gap-1.5 px-5 py-2.5 bg-[#00897B] hover:bg-[#00796B] text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer disabled:opacity-60",
											children: [
												/* @__PURE__ */ _jsxDEV(Save, { size: 14 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 223,
													columnNumber: 37
												}, this),
												" ",
												saving ? "Menyimpan..." : "Simpan Perubahan"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 218,
											columnNumber: 33
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 217,
										columnNumber: 29
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3",
									children: [/* @__PURE__ */ _jsxDEV(Lock, {
										size: 16,
										className: "text-[#00897B] dark:text-teal-400"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 232,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("h3", {
										className: "text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider",
										children: "Ubah Kata Sandi"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 233,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 231,
									columnNumber: 25
								}, this),
								pwError && /* @__PURE__ */ _jsxDEV("div", {
									className: "px-4 py-2.5 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-xl text-xs font-bold text-red-600 dark:text-red-400",
									children: pwError
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 237,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("form", {
									onSubmit: handleUpdatePassword,
									className: "space-y-4",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
											children: "Kata Sandi Saat Ini"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 244,
											columnNumber: 33
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "password",
											required: true,
											value: oldPassword,
											onChange: (e) => setOldPassword(e.target.value),
											placeholder: "Masukkan kata sandi saat ini",
											className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-semibold bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 245,
											columnNumber: 33
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 243,
											columnNumber: 29
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
												children: "Kata Sandi Baru"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 257,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "password",
												required: true,
												value: newPassword,
												onChange: (e) => setNewPassword(e.target.value),
												placeholder: "Min. 8 karakter",
												className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-semibold bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 258,
												columnNumber: 37
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 256,
												columnNumber: 33
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
												children: "Konfirmasi Kata Sandi Baru"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 268,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "password",
												required: true,
												value: confirmPassword,
												onChange: (e) => setConfirmPassword(e.target.value),
												placeholder: "Ulangi kata sandi baru",
												className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-semibold bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00897B]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 269,
												columnNumber: 37
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 267,
												columnNumber: 33
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 255,
											columnNumber: 29
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "pt-2 flex justify-end",
											children: /* @__PURE__ */ _jsxDEV("button", {
												type: "submit",
												disabled: pwLoading,
												className: "flex items-center gap-1.5 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-teal-600 dark:hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer disabled:opacity-60",
												children: [
													/* @__PURE__ */ _jsxDEV(Lock, { size: 14 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 286,
														columnNumber: 37
													}, this),
													" ",
													pwLoading ? "Memperbarui..." : "Perbarui Kata Sandi"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 281,
												columnNumber: 33
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 280,
											columnNumber: 29
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 242,
									columnNumber: 25
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 230,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 120,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 117,
		columnNumber: 9
	}, this);
}
_s(ProfilePage, "pG053o6+4bfsg+LcKc8J/A9flfs=", false, function() {
	return [useNavigate];
});
_c = ProfilePage;
var _c;
$RefreshReg$(_c, "ProfilePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/profile/ProfilePage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/profile/ProfilePage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/profile/ProfilePage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/profile/ProfilePage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLE1BQU0sTUFBTSxRQUFRLE1BQU0saUJBQWlCO0FBQ3BELE9BQU8sYUFBYTtBQUNwQixTQUNJLGNBQWMsZUFBZSxnQkFBZ0Isb0JBQzdDLGNBQWMsVUFBVSxhQUFhLG9CQUNsQzs7OztBQUVQLGVBQWUsU0FBUyxjQUFjOztDQUNsQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsSUFBSTs7Q0FHdkMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTs7Q0FHN0MsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBRXpDLGdCQUFnQjtFQUNaLE1BQU0sT0FBTyxZQUFZO0dBQ3JCLFdBQVcsSUFBSTtHQUNmLE1BQU0sTUFBTSxNQUFNLGFBQWE7R0FDL0IsSUFBSSxJQUFJLFdBQVcsS0FBSztJQUFFLGFBQWE7SUFBRyxTQUFTLFFBQVE7SUFBRztHQUFRO0dBQ3RFLElBQUksSUFBSSxNQUFNLElBQUksTUFBTTtJQUNwQixNQUFNLElBQUksSUFBSTtJQUNkLFdBQVcsQ0FBQztJQUNaLFlBQVksRUFBRSxZQUFZLEVBQUU7SUFDNUIsWUFBWSxFQUFFLFlBQVksRUFBRTtJQUM1QixTQUFTLEVBQUUsU0FBUyxFQUFFO0lBQ3RCLGFBQWEsRUFBRSxZQUFZLEVBQUUsVUFBVSxVQUFVLEdBQUcsRUFBRSxJQUFJLEVBQUU7R0FDaEU7R0FDQSxXQUFXLEtBQUs7RUFDcEI7RUFDQSxLQUFLO0NBQ1QsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUViLE1BQU0sYUFBYSxLQUFLLE9BQU8sY0FBYztFQUN6QyxTQUFTO0dBQUU7R0FBSztFQUFLLENBQUM7RUFDdEIsaUJBQWlCLFNBQVMsSUFBSSxHQUFHLEdBQUk7Q0FDekM7Q0FFQSxNQUFNLG9CQUFvQixPQUFPLE1BQU07RUFDbkMsRUFBRSxlQUFlO0VBQ2pCLFVBQVUsSUFBSTtFQUNkLE1BQU0sTUFBTSxNQUFNLGNBQWM7R0FBRTtHQUFVO0dBQVU7RUFBVSxDQUFDO0VBQ2pFLFVBQVUsS0FBSztFQUNmLElBQUksSUFBSSxJQUFJO0dBQ1IsTUFBTSxVQUFVO0lBQUUsR0FBRztJQUFTO0lBQVU7SUFBVTtHQUFVO0dBQzVELFdBQVcsT0FBTztHQUNsQixNQUFNLFVBQVUsYUFBYTtHQUM3QixJQUFJLFNBQVMsWUFBWTtJQUFFLE9BQU8sYUFBYSxRQUFRLE9BQU87SUFBRyxNQUFNO0tBQUUsR0FBRztLQUFTO0tBQVU7SUFBUztHQUFFLENBQUM7R0FDM0csVUFBVSw2QkFBNkI7RUFDM0MsT0FBTztHQUNILFVBQVUsSUFBSSxXQUFXLDRCQUE0QixPQUFPO0VBQ2hFO0NBQ0o7Q0FFQSxNQUFNLHFCQUFxQixPQUFPLE1BQU07RUFDcEMsTUFBTSxPQUFPLEVBQUUsT0FBTyxRQUFRO0VBQzlCLElBQUksQ0FBQyxNQUFNO0VBQ1gsTUFBTSxNQUFNLE1BQU0sbUJBQW1CLElBQUk7RUFDekMsSUFBSSxJQUFJLElBQUk7R0FDUixNQUFNLFVBQVUsTUFBTSxhQUFhO0dBQ25DLElBQUksUUFBUSxJQUFJO0lBQ1osV0FBVyxRQUFRLElBQUk7SUFDdkIsTUFBTSxVQUFVLGFBQWE7SUFDN0IsSUFBSSxTQUFTLFlBQVk7S0FBRSxPQUFPLGFBQWEsUUFBUSxPQUFPO0tBQUcsTUFBTTtNQUFFLEdBQUc7TUFBUyxjQUFjLFFBQVEsS0FBSztLQUFhO0lBQUUsQ0FBQztHQUNwSTtHQUNBLFVBQVUsOEJBQThCO0VBQzVDLE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyxnQ0FBZ0MsT0FBTztFQUNwRTtDQUNKO0NBRUEsTUFBTSx1QkFBdUIsT0FBTyxNQUFNO0VBQ3RDLEVBQUUsZUFBZTtFQUNqQixXQUFXLEVBQUU7RUFDYixJQUFJLGdCQUFnQixpQkFBaUI7R0FDakMsV0FBVyw2Q0FBNkM7R0FDeEQ7RUFDSjtFQUNBLElBQUksWUFBWSxTQUFTLEdBQUc7R0FDeEIsV0FBVyxzQ0FBc0M7R0FDakQ7RUFDSjtFQUNBLGFBQWEsSUFBSTtFQUNqQixNQUFNLE1BQU0sTUFBTSxlQUFlLGFBQWEsV0FBVztFQUN6RCxhQUFhLEtBQUs7RUFDbEIsSUFBSSxJQUFJLElBQUk7R0FDUixlQUFlLEVBQUU7R0FDakIsZUFBZSxFQUFFO0dBQ2pCLG1CQUFtQixFQUFFO0dBQ3JCLFVBQVUsaUNBQWlDO0VBQy9DLE9BQU87R0FDSCxXQUFXLElBQUksV0FBVywrQkFBK0I7RUFDN0Q7Q0FDSjtDQUVBLElBQUksU0FBUyxPQUNULHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1gsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBeUQ7RUFBd0I7Ozs7O0NBQzdGOzs7OztDQUdULE9BQ0ksd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNJLHdCQUFDLFNBQUQsQ0FBVTs7OztZQUVWLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsVUFBRDtNQUFRLGVBQWUsU0FBUyxZQUFZO01BQUcsV0FBVTtnQkFDckQsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7S0FDbEI7Ozs7ZUFDUix3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTBEO0tBQTRCOzs7O2VBQ3BHLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE2QztLQUFnRTs7OzthQUN6SDs7OzthQUNKOzs7Ozs7SUFFSixTQUNHLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLHdHQUF3RyxNQUFNLFNBQVMsVUFBVSxlQUFlO2VBQzNKLE1BQU07SUFDTjs7Ozs7SUFHVCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BR0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLE9BQUQ7U0FDSSxLQUFLLFNBQ0QsU0FBUyxjQUNULG9DQUFvQyxtQkFBbUIsU0FBUyxZQUFZLEdBQUcsRUFBRSxzQ0FDckY7U0FDQSxLQUFLLFNBQVM7U0FDZCxXQUFVO1FBQ2I7Ozs7a0JBQ0Qsd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQ0ksd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7OzttQkFDbkIsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxRQUFPO1VBQVUsV0FBVTtVQUFTLFVBQVU7U0FBcUI7Ozs7aUJBQ25GOzs7OztnQkFDTjs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDSSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBc0QsU0FBUztTQUFhOzs7OztTQUMxRix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYixDQUFvRSxLQUFFLFNBQVMsUUFBWTs7Ozs7O1NBQzNGLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQjtXQUNJLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7O1dBQUM7V0FDcEIsd0JBQUMsU0FBRDtZQUFPLE1BQUs7WUFBTyxRQUFPO1lBQVUsV0FBVTtZQUFTLFVBQVU7V0FBcUI7Ozs7O1VBQ25GOzs7Ozs7UUFDTjs7Ozs7ZUFDSjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLE1BQUQ7U0FBTSxNQUFNO1NBQUksV0FBVTtRQUFxQzs7OztrQkFDL0Qsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWlGO1FBQXFCOzs7O2dCQUNuSDs7Ozs7aUJBRUwsd0JBQUMsUUFBRDtRQUFNLFVBQVU7UUFBbUIsV0FBVTtrQkFBN0M7U0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBa0U7VUFBbUI7Ozs7b0JBQ3RHLHdCQUFDLFNBQUQ7V0FDSSxNQUFLO1dBQ0w7V0FDQSxPQUFPO1dBQ1AsV0FBVSxNQUFLLFlBQVksRUFBRSxPQUFPLEtBQUs7V0FDekMsV0FBVTtVQUNiOzs7O2tCQUNBOzs7O29CQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBa0U7VUFBK0I7Ozs7b0JBQ2xILHdCQUFDLFNBQUQ7V0FDSSxNQUFLO1dBQ0w7V0FDQSxPQUFPO1dBQ1AsV0FBVSxNQUFLLFlBQVksRUFBRSxPQUFPLE1BQU0sWUFBWSxDQUFDLENBQUMsUUFBUSxlQUFlLEVBQUUsQ0FBQztXQUNsRixXQUFVO1VBQ2I7Ozs7a0JBQ0E7Ozs7a0JBQ0o7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFDSSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBa0U7VUFBbUI7Ozs7O1VBQ3RHLHdCQUFDLFNBQUQ7V0FDSSxNQUFLO1dBQ0w7V0FDQSxPQUFPO1dBQ1AsV0FBVTtVQUNiOzs7OztVQUNELHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFzRDtVQUE2RDs7Ozs7U0FDL0g7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFrRTtTQUFvQjs7OzttQkFDdkcsd0JBQUMsU0FBRDtVQUNJLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVSxNQUFLLGFBQWEsRUFBRSxPQUFPLEtBQUs7VUFDMUMsV0FBVTtTQUNiOzs7O2lCQUNBOzs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNYLHdCQUFDLFVBQUQ7V0FDSSxNQUFLO1dBQ0wsVUFBVTtXQUNWLFdBQVU7cUJBSGQ7WUFLSSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztZQUFDO1lBQUUsU0FBUyxpQkFBaUI7V0FDMUM7Ozs7OztTQUNQOzs7OztRQUNIOzs7OztlQUNMOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsTUFBRDtVQUFNLE1BQU07VUFBSSxXQUFVO1NBQXFDOzs7O21CQUMvRCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBaUY7U0FBbUI7Ozs7aUJBQ2pIOzs7Ozs7UUFFSixXQUNHLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNWO1FBQ0E7Ozs7O1FBR1Qsd0JBQUMsUUFBRDtTQUFNLFVBQVU7U0FBc0IsV0FBVTttQkFBaEQ7VUFDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWtFO1VBQTBCOzs7O29CQUM3Ryx3QkFBQyxTQUFEO1dBQ0ksTUFBSztXQUNMO1dBQ0EsT0FBTztXQUNQLFdBQVUsTUFBSyxlQUFlLEVBQUUsT0FBTyxLQUFLO1dBQzVDLGFBQVk7V0FDWixXQUFVO1VBQ2I7Ozs7a0JBQ0E7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQWtFO1dBQXNCOzs7O3FCQUN6Ryx3QkFBQyxTQUFEO1lBQ0ksTUFBSztZQUNMO1lBQ0EsT0FBTztZQUNQLFdBQVUsTUFBSyxlQUFlLEVBQUUsT0FBTyxLQUFLO1lBQzVDLGFBQVk7WUFDWixXQUFVO1dBQ2I7Ozs7bUJBQ0E7Ozs7cUJBQ0wsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUFrRTtXQUFpQzs7OztxQkFDcEgsd0JBQUMsU0FBRDtZQUNJLE1BQUs7WUFDTDtZQUNBLE9BQU87WUFDUCxXQUFVLE1BQUssbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1lBQ2hELGFBQVk7WUFDWixXQUFVO1dBQ2I7Ozs7bUJBQ0E7Ozs7bUJBQ0o7Ozs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNYLHdCQUFDLFVBQUQ7WUFDSSxNQUFLO1lBQ0wsVUFBVTtZQUNWLFdBQVU7c0JBSGQ7YUFLSSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OzthQUFDO2FBQUUsWUFBWSxtQkFBbUI7WUFDL0M7Ozs7OztVQUNQOzs7OztTQUNIOzs7Ozs7T0FDTDs7Ozs7O0tBRUo7Ozs7OztHQUNKOzs7OztVQUNKOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9maWxlUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBVc2VyLCBMb2NrLCBVcGxvYWQsIFNhdmUsIEFycm93TGVmdCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgU2lkZWJhciBmcm9tICcuLi8uLi9jb21wb25lbnRzL2xheW91dC9TaWRlYmFyJztcbmltcG9ydCB7XG4gICAgZ2V0TXlQcm9maWxlLCB1cGRhdGVQcm9maWxlLCBjaGFuZ2VQYXNzd29yZCwgdXBsb2FkUHJvZmlsZUltYWdlLFxuICAgIGNsZWFyU2Vzc2lvbiwgYXNzZXRVcmwsIHNhdmVTZXNzaW9uLCBnZXRMb2NhbFVzZXJcbn0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByb2ZpbGVQYWdlKCkge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBbcHJvZmlsZSwgc2V0UHJvZmlsZV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFt0b2FzdCwgc2V0VG9hc3RdID0gdXNlU3RhdGUobnVsbCk7XG5cbiAgICAvLyBQcm9maWxlIGZvcm1cbiAgICBjb25zdCBbZnVsbG5hbWUsIHNldEZ1bGxuYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbYmlydGhkYXRlLCBzZXRCaXJ0aGRhdGVdID0gdXNlU3RhdGUoJycpO1xuXG4gICAgLy8gUGFzc3dvcmQgZm9ybVxuICAgIGNvbnN0IFtvbGRQYXNzd29yZCwgc2V0T2xkUGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtuZXdQYXNzd29yZCwgc2V0TmV3UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtjb25maXJtUGFzc3dvcmQsIHNldENvbmZpcm1QYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW3B3TG9hZGluZywgc2V0UHdMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbcHdFcnJvciwgc2V0UHdFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBsb2FkID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdldE15UHJvZmlsZSgpO1xuICAgICAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSkgeyBjbGVhclNlc3Npb24oKTsgbmF2aWdhdGUoJy9sb2dpbicpOyByZXR1cm47IH1cbiAgICAgICAgICAgIGlmIChyZXMub2sgJiYgcmVzLmRhdGEpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkID0gcmVzLmRhdGE7XG4gICAgICAgICAgICAgICAgc2V0UHJvZmlsZShkKTtcbiAgICAgICAgICAgICAgICBzZXRGdWxsbmFtZShkLmZ1bGxuYW1lIHx8ICcnKTtcbiAgICAgICAgICAgICAgICBzZXRVc2VybmFtZShkLnVzZXJuYW1lIHx8ICcnKTtcbiAgICAgICAgICAgICAgICBzZXRFbWFpbChkLmVtYWlsIHx8ICcnKTtcbiAgICAgICAgICAgICAgICBzZXRCaXJ0aGRhdGUoZC5iaXJ0aGRhdGUgPyBkLmJpcnRoZGF0ZS5zdWJzdHJpbmcoMCwgMTApIDogJycpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH07XG4gICAgICAgIGxvYWQoKTtcbiAgICB9LCBbbmF2aWdhdGVdKTtcblxuICAgIGNvbnN0IHNob3dUb2FzdCA9IChtc2csIHR5cGUgPSAnc3VjY2VzcycpID0+IHtcbiAgICAgICAgc2V0VG9hc3QoeyBtc2csIHR5cGUgfSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0VG9hc3QobnVsbCksIDMwMDApO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlUHJvZmlsZSA9IGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgc2V0U2F2aW5nKHRydWUpO1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB1cGRhdGVQcm9maWxlKHsgZnVsbG5hbWUsIHVzZXJuYW1lLCBiaXJ0aGRhdGUgfSk7XG4gICAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSB7IC4uLnByb2ZpbGUsIGZ1bGxuYW1lLCB1c2VybmFtZSwgYmlydGhkYXRlIH07XG4gICAgICAgICAgICBzZXRQcm9maWxlKHVwZGF0ZWQpO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudCA9IGdldExvY2FsVXNlcigpO1xuICAgICAgICAgICAgaWYgKGN1cnJlbnQpIHNhdmVTZXNzaW9uKHsgdG9rZW46IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0b2tlbicpLCB1c2VyOiB7IC4uLmN1cnJlbnQsIGZ1bGxuYW1lLCB1c2VybmFtZSB9IH0pO1xuICAgICAgICAgICAgc2hvd1RvYXN0KCdQcm9maWwgYmVyaGFzaWwgZGlwZXJiYXJ1aSEnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNob3dUb2FzdChyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVtcGVyYmFydWkgcHJvZmlsJywgJ2Vycm9yJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQXZhdGFyVXBsb2FkID0gYXN5bmMgKGUpID0+IHtcbiAgICAgICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgICAgIGlmICghZmlsZSkgcmV0dXJuO1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB1cGxvYWRQcm9maWxlSW1hZ2UoZmlsZSk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCBnZXRNeVByb2ZpbGUoKTtcbiAgICAgICAgICAgIGlmICh1cGRhdGVkLm9rKSB7XG4gICAgICAgICAgICAgICAgc2V0UHJvZmlsZSh1cGRhdGVkLmRhdGEpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnQgPSBnZXRMb2NhbFVzZXIoKTtcbiAgICAgICAgICAgICAgICBpZiAoY3VycmVudCkgc2F2ZVNlc3Npb24oeyB0b2tlbjogbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rva2VuJyksIHVzZXI6IHsgLi4uY3VycmVudCwgcHJvZmlsZUltYWdlOiB1cGRhdGVkLmRhdGEucHJvZmlsZUltYWdlIH0gfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzaG93VG9hc3QoJ0ZvdG8gcHJvZmlsIGJlcmhhc2lsIGRpdWJhaCEnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNob3dUb2FzdChyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVuZ3VuZ2dhaCBmb3RvIHByb2ZpbCcsICdlcnJvcicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVVwZGF0ZVBhc3N3b3JkID0gYXN5bmMgKGUpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzZXRQd0Vycm9yKCcnKTtcbiAgICAgICAgaWYgKG5ld1Bhc3N3b3JkICE9PSBjb25maXJtUGFzc3dvcmQpIHtcbiAgICAgICAgICAgIHNldFB3RXJyb3IoJ0thdGEgc2FuZGkgYmFydSBkYW4ga29uZmlybWFzaSB0aWRhayBjb2Nvay4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobmV3UGFzc3dvcmQubGVuZ3RoIDwgOCkge1xuICAgICAgICAgICAgc2V0UHdFcnJvcignS2F0YSBzYW5kaSBtaW5pbWFsIGhhcnVzIDgga2FyYWt0ZXIuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0UHdMb2FkaW5nKHRydWUpO1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjaGFuZ2VQYXNzd29yZChvbGRQYXNzd29yZCwgbmV3UGFzc3dvcmQpO1xuICAgICAgICBzZXRQd0xvYWRpbmcoZmFsc2UpO1xuICAgICAgICBpZiAocmVzLm9rKSB7XG4gICAgICAgICAgICBzZXRPbGRQYXNzd29yZCgnJyk7XG4gICAgICAgICAgICBzZXROZXdQYXNzd29yZCgnJyk7XG4gICAgICAgICAgICBzZXRDb25maXJtUGFzc3dvcmQoJycpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KCdLYXRhIHNhbmRpIGJlcmhhc2lsIGRpcGVyYmFydWkhJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRQd0Vycm9yKHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW1wZXJiYXJ1aSBrYXRhIHNhbmRpLicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLXNjcmVlbiBiZy1bI0Y0RjhGN10gZGFyazpiZy1zbGF0ZS05NTBcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPk1lbXVhdCBkYXRhIHByb2ZpbC4uLjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gdy1mdWxsIGJnLVsjRjRGOEY3XSBkYXJrOmJnLXNsYXRlLTk1MCBmb250LXNhbnMgYW50aWFsaWFzZWQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgPFNpZGViYXIgLz5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBtaW4tdy0wIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcHgtNiBweS00IGZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9kYXNoYm9hcmQnKX0gY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd0xlZnQgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5QZW5nYXR1cmFuIEFrdW4gJiBQcm9maWw8L2gxPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+S2Vsb2xhIGluZm9ybWFzaSBpZGVudGl0YXMsIGZvdG8gcHJvZmlsLCBkYW4ga2F0YSBzYW5kaSBBbmRhLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7dG9hc3QgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZpeGVkIHRvcC00IHJpZ2h0LTQgei01MCBweC00IHB5LTMgcm91bmRlZC0yeGwgc2hhZG93LXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgJHt0b2FzdC50eXBlID09PSAnZXJyb3InID8gJ2JnLXJlZC01MDAnIDogJ2JnLVsjMDA4OTdCXSd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dG9hc3QubXNnfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgbWF4LXctMnhsIG14LWF1dG8gdy1mdWxsIHNwYWNlLXktNlwiPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBdmF0YXIgQ2FyZCAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC02IHNoYWRvdy14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXthc3NldFVybChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb2ZpbGU/LnByb2ZpbGVJbWFnZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBodHRwczovL3VpLWF2YXRhcnMuY29tL2FwaS8/bmFtZT0ke2VuY29kZVVSSUNvbXBvbmVudChwcm9maWxlPy5mdWxsbmFtZSB8fCAnVScpfSZiYWNrZ3JvdW5kPTAwODk3QiZjb2xvcj1mZmYmc2l6ZT0xMjhgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17cHJvZmlsZT8uZnVsbG5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMjAgaC0yMCByb3VuZGVkLTJ4bCBvYmplY3QtY292ZXIgYm9yZGVyLTIgYm9yZGVyLVsjMDA4OTdCXS8zMCBkYXJrOmJvcmRlci10ZWFsLTUwMC80MCBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2svNDAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBjdXJzb3ItcG9pbnRlciB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxVcGxvYWQgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlLypcIiBjbGFzc05hbWU9XCJoaWRkZW5cIiBvbkNoYW5nZT17aGFuZGxlQXZhdGFyVXBsb2FkfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3Byb2ZpbGU/LmZ1bGxuYW1lfTwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGZvbnQtbW9ub1wiPkB7cHJvZmlsZT8udXNlcm5hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgaG92ZXI6dW5kZXJsaW5lIGN1cnNvci1wb2ludGVyIHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBzaXplPXsxMn0gLz4gVWJhaCBGb3RvIFByb2ZpbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qXCIgY2xhc3NOYW1lPVwiaGlkZGVuXCIgb25DaGFuZ2U9e2hhbmRsZUF2YXRhclVwbG9hZH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBQcm9maWxlIEluZm9ybWF0aW9uIEZvcm0gKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtNiBzaGFkb3cteHMgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlciBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+SW5mb3JtYXNpIFByaWJhZGk8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlUHJvZmlsZX0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+TmFtYSBMZW5na2FwPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmdWxsbmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGdWxsbmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5OYW1hIFBlbmdndW5hIChVc2VybmFtZSk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFVzZXJuYW1lKGUudGFyZ2V0LnZhbHVlLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvW15hLXowLTlfXS9nLCAnJykpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtbW9ubyBmb250LXNlbWlib2xkIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPkFsYW1hdCBFbWFpbDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzUwIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgY3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBtdC0xXCI+QWxhbWF0IGVtYWlsIHRlcmRhZnRhciB0aWRhayBkYXBhdCBkaXViYWggc2VjYXJhIGxhbmdzdW5nLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5UYW5nZ2FsIExhaGlyPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YmlydGhkYXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0QmlydGhkYXRlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC01IHB5LTIuNSBiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTYXZlIHNpemU9ezE0fSAvPiB7c2F2aW5nID8gJ01lbnlpbXBhbi4uLicgOiAnU2ltcGFuIFBlcnViYWhhbid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogQ2hhbmdlIFBhc3N3b3JkIEZvcm0gKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtNiBzaGFkb3cteHMgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9jayBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+VWJhaCBLYXRhIFNhbmRpPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7cHdFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTUwLzUwIGJvcmRlciBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwd0Vycm9yfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVVwZGF0ZVBhc3N3b3JkfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+S2F0YSBTYW5kaSBTYWF0IEluaTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17b2xkUGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRPbGRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1hc3Vra2FuIGthdGEgc2FuZGkgc2FhdCBpbmlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5LYXRhIFNhbmRpIEJhcnU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdQYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXROZXdQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJNaW4uIDgga2FyYWt0ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+S29uZmlybWFzaSBLYXRhIFNhbmRpIEJhcnU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maXJtUGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Q29uZmlybVBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlVsYW5naSBrYXRhIHNhbmRpIGJhcnVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwd0xvYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTUgcHktMi41IGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgZGFyazpiZy10ZWFsLTYwMCBkYXJrOmhvdmVyOmJnLXRlYWwtNzAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2NrIHNpemU9ezE0fSAvPiB7cHdMb2FkaW5nID8gJ01lbXBlcmJhcnVpLi4uJyA6ICdQZXJiYXJ1aSBLYXRhIFNhbmRpJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==