import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/form-responses/FormAnalyticsPage.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { ArrowLeft, Users, FileText, Award, TrendingUp, Eye, X, CheckCircle2, XCircle, MinusCircle, ChevronLeft, ChevronRight, Loader2, BarChart3, Check, AlertCircle, Download } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import { getFormById, getFormAnalytics, exportFormResponses, clearSession } from "/src/services/apiService.js";
import { getGeminiApiKey, analyzeFormAnalyticsWithAI, AVAILABLE_MODELS } from "/src/services/aiService.js";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-responses/FormAnalyticsPage.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const PAGE_SIZE = 25;
export default function FormAnalyticsPage() {
	_s();
	const { id } = useParams();
	const navigate = useNavigate();
	const [form, setForm] = useState(null);
	const [analytics, setAnalytics] = useState(null);
	const [respondents, setRespondents] = useState([]);
	const [loading, setLoading] = useState(true);
	const [loadingMore, setLoadingMore] = useState(false);
	const [page, setPage] = useState(1);
	const [hasMore, setHasMore] = useState(true);
	const [totalCount, setTotalCount] = useState(0);
	const [selectedRespondent, setSelectedRespondent] = useState(null);
	const [exportingFormat, setExportingFormat] = useState(null);
	const [exportError, setExportError] = useState(null);
	const [includeAnswerKey, setIncludeAnswerKey] = useState(true);
	// AI-3: AI Analysis state
	const [aiAnalyzing, setAiAnalyzing] = useState(false);
	const [aiInsight, setAiInsight] = useState("");
	const [aiError, setAiError] = useState("");
	const [aiModel, setAiModel] = useState(() => {
		const m = localStorage.getItem("formup_selected_model_chat");
		return m && !m.includes("-pro") && AVAILABLE_MODELS.some((model) => model.id === m) ? m : "gemini-3.6-flash";
	});
	const handleExport = async (format) => {
		if (!id || exportingFormat !== null) return;
		setExportingFormat(format);
		setExportError(null);
		try {
			const res = await exportFormResponses(id, format, includeAnswerKey);
			if (!res.ok) {
				setExportError(res.message || `Gagal mengekspor data ke format ${format.toUpperCase()}`);
				setTimeout(() => setExportError(null), 4e3);
			}
		} catch (err) {
			setExportError(`Terjadi kesalahan saat mengekspor data ${format.toUpperCase()}`);
			setTimeout(() => setExportError(null), 4e3);
		} finally {
			setExportingFormat(null);
		}
	};
	// AI-3: Analyze analytics with Gemini
	const handleAiAnalyze = async () => {
		setAiAnalyzing(true);
		setAiInsight("");
		setAiError("");
		try {
			const summary = `
Formulir: ${form?.title || "Tidak diketahui"}
Total Respons: ${analytics?.totalResponses ?? respondents.length}
Total Soal: ${analytics?.totalQuestions ?? 0}
Soal Dinilai: ${analytics?.scorableQuestions ?? 0}
Rata-rata Skor: ${analytics?.averageScore != null ? analytics.averageScore + "%" : "N/A"}

Distribusi Predikat:
- Sangat Baik (A, 90-100%): ${gradeDistribution.A} siswa
- Baik (B, 75-89%): ${gradeDistribution.B} siswa
- Cukup (C, 60-74%): ${gradeDistribution.C} siswa
- Kurang (D, 40-59%): ${gradeDistribution.D} siswa
- Perlu Remidi (E, <40%): ${gradeDistribution.E} siswa

Kriteria Kelulusan (>= 70%):
- Lulus: ${passRateMetrics.passed} siswa (${passRateMetrics.passPercent}%)
- Belum Lulus: ${passRateMetrics.failed} siswa (${passRateMetrics.failPercent}%)

Analisis Akurasi Soal (diurutkan dari tersulit):
${questionAccuracyMap.slice(0, 10).map((q) => `- "${(q.question || "").replace(/<[^>]*>/g, "").substring(0, 80)}": akurasi ${q.accuracy}% (${q.correctCount}/${q.totalAttempts})`).join("\n")}
`.trim();
			const res = await analyzeFormAnalyticsWithAI({
				summary,
				selectedModel: aiModel,
				customApiKey: getGeminiApiKey()
			});
			if (!res.ok) {
				setAiError(res.message || "Gagal menganalisis data kuis.");
				return;
			}
			setAiInsight(res.data);
		} catch (err) {
			setAiError("Gagal menganalisis: " + err.message);
		} finally {
			setAiAnalyzing(false);
		}
	};
	useEffect(() => {
		const load = async () => {
			setLoading(true);
			try {
				const [formRes, analyticsRes] = await Promise.all([getFormById(id), getFormAnalytics(id, 1, PAGE_SIZE)]);
				if (formRes.status === 401) {
					clearSession();
					navigate("/login");
					return;
				}
				if (formRes.ok) {
					setForm(formRes.data);
				}
				if (analyticsRes.ok && analyticsRes.data) {
					setAnalytics(analyticsRes.data);
					const list = analyticsRes.data.respondents || [];
					const total = analyticsRes.data.totalResponses ?? list.length;
					setRespondents(list);
					setTotalCount(total);
					setHasMore(list.length >= PAGE_SIZE);
				}
			} catch (error) {
				console.error("Failed to load analytics:", error);
			} finally {
				setLoading(false);
			}
		};
		load();
	}, [id, navigate]);
	const handleLoadMore = useCallback(async () => {
		if (loadingMore || !hasMore) return;
		setLoadingMore(true);
		const nextPage = page + 1;
		const res = await getFormAnalytics(id, nextPage, PAGE_SIZE);
		setLoadingMore(false);
		if (res.ok && res.data) {
			const newList = res.data.respondents || [];
			if (newList.length > 0) {
				setRespondents((prev) => [...prev, ...newList]);
				setPage(nextPage);
				setHasMore(newList.length >= PAGE_SIZE);
			} else {
				setHasMore(false);
			}
		}
	}, [
		id,
		page,
		loadingMore,
		hasMore
	]);
	// ── Analytical Calculations for Diagrams ─────────────────────────────────
	const gradeDistribution = useMemo(() => {
		const counts = {
			A: 0,
			B: 0,
			C: 0,
			D: 0,
			E: 0,
			total: 0
		};
		(respondents || []).forEach((r) => {
			if (r.score == null) return;
			counts.total++;
			if (r.score >= 90) counts.A++;
			else if (r.score >= 75) counts.B++;
			else if (r.score >= 60) counts.C++;
			else if (r.score >= 40) counts.D++;
			else counts.E++;
		});
		return counts;
	}, [respondents]);
	const passRateMetrics = useMemo(() => {
		let passed = 0;
		let failed = 0;
		(respondents || []).forEach((r) => {
			if (r.score == null) return;
			if (r.score >= 70) passed++;
			else failed++;
		});
		const total = passed + failed;
		return {
			passed,
			failed,
			total,
			passPercent: total > 0 ? Math.round(passed / total * 100) : 0,
			failPercent: total > 0 ? Math.round(failed / total * 100) : 0
		};
	}, [respondents]);
	const questionAccuracyMap = useMemo(() => {
		const qMap = {};
		(respondents || []).forEach((r) => {
			(r.answers || []).forEach((a) => {
				if (!a.questionId) return;
				if (!qMap[a.questionId]) {
					qMap[a.questionId] = {
						questionId: a.questionId,
						question: a.question || `Soal #${a.questionId}`,
						questionFormat: a.questionFormat || "text",
						correctCount: 0,
						totalAttempts: 0
					};
				}
				if (a.isCorrect != null) {
					qMap[a.questionId].totalAttempts++;
					if (a.isCorrect === true) qMap[a.questionId].correctCount++;
				}
			});
		});
		return Object.values(qMap).map((q) => ({
			...q,
			accuracy: q.totalAttempts > 0 ? Math.round(q.correctCount / q.totalAttempts * 100) : 0
		})).sort((a, b) => a.accuracy - b.accuracy);
	}, [respondents]);
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-center min-h-screen bg-[#F4F8F7] dark:bg-slate-950",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "text-center space-y-2",
				children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin mx-auto text-[#00897B] dark:text-teal-400" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 242,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-400 dark:text-slate-500 text-sm font-medium",
					children: "Memuat analisis formulir..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 243,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 241,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 240,
			columnNumber: 13
		}, this);
	}
	const currentIndex = selectedRespondent ? respondents.findIndex((r) => r.responseId === selectedRespondent.responseId) : -1;
	const goPrevious = () => {
		if (currentIndex > 0) {
			setSelectedRespondent(respondents[currentIndex - 1]);
		}
	};
	const goNext = () => {
		if (currentIndex < respondents.length - 1) {
			setSelectedRespondent(respondents[currentIndex + 1]);
		}
	};
	const getAnswerStatus = (answer) => {
		if (answer.isCorrect === true) {
			return {
				label: "Benar",
				icon: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 269,
					columnNumber: 23
				}, this),
				className: "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
			};
		}
		if (answer.isCorrect === false) {
			return {
				label: "Salah",
				icon: /* @__PURE__ */ _jsxDEV(XCircle, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 277,
					columnNumber: 23
				}, this),
				className: "text-red-600 bg-red-50 dark:bg-red-950/60 dark:text-red-400 border-red-200 dark:border-red-800"
			};
		}
		return {
			label: "Tidak Dinilai",
			icon: /* @__PURE__ */ _jsxDEV(MinusCircle, { size: 16 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 284,
				columnNumber: 19
			}, this),
			className: "text-slate-500 bg-slate-50 dark:bg-slate-800 dark:text-slate-400 border-slate-200 dark:border-slate-700"
		};
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen w-full bg-[#F4F8F7] dark:bg-slate-950 font-sans antialiased text-slate-800 dark:text-slate-100 transition-colors",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 291,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col min-w-0 overflow-y-auto",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 py-4 flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3 min-w-0",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => navigate(`/forms/${id}/responses`),
								className: "p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 302,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 298,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("h1", {
									className: "text-base font-extrabold text-slate-900 dark:text-white truncate",
									children: [form?.title || "Formulir", " — Analisis & Diagram"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 dark:text-slate-500",
									children: [
										"Ringkasan performa & analisis hasil (",
										respondents.length,
										" / ",
										totalCount || respondents.length,
										" responden dimuat)"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 308,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 304,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 297,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleAiAnalyze,
									disabled: aiAnalyzing || respondents.length === 0,
									className: "px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50",
									children: [/* @__PURE__ */ _jsxDEV(BarChart3, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 322,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: aiAnalyzing ? "Menganalisis..." : "Analisis Pintar" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 323,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 317,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("select", {
									"aria-label": "Model Analisis Pintar",
									value: aiModel,
									onChange: (e) => {
										setAiModel(e.target.value);
										localStorage.setItem("formup_selected_model_chat", e.target.value);
									},
									className: "max-w-36 px-2 py-1.5 text-[11px] font-bold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200",
									children: AVAILABLE_MODELS.map((model) => /* @__PURE__ */ _jsxDEV("option", {
										value: model.id,
										children: model.name
									}, model.id, false, {
										fileName: _jsxFileName,
										lineNumber: 326,
										columnNumber: 60
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("label", {
									className: "flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 select-none cursor-pointer font-medium px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "checkbox",
										checked: includeAnswerKey,
										onChange: (e) => setIncludeAnswerKey(e.target.checked),
										className: "rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 330,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Kunci Jawaban" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 336,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 329,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleExport("xlsx"),
									disabled: exportingFormat !== null,
									className: "px-3 py-1.5 text-xs font-bold rounded-xl border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 bg-emerald-50/70 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50",
									title: "Export ke Excel (.xlsx)",
									children: [/* @__PURE__ */ _jsxDEV(Download, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 345,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: exportingFormat === "xlsx" ? "Mengunduh..." : "Export XLSX" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 346,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 339,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleExport("csv"),
									disabled: exportingFormat !== null,
									className: "px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50",
									title: "Export ke CSV (.csv)",
									children: [/* @__PURE__ */ _jsxDEV(Download, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 355,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: exportingFormat === "csv" ? "Mengunduh..." : "Export CSV" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 356,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleExport("pdf"),
									disabled: exportingFormat !== null,
									className: "px-3 py-1.5 text-xs font-bold rounded-xl border border-red-300 dark:border-red-800 text-red-700 dark:text-red-400 bg-red-50/70 dark:bg-red-950/40 hover:bg-red-100 dark:hover:bg-red-900/50 flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50",
									title: "Export ke PDF (.pdf)",
									children: [/* @__PURE__ */ _jsxDEV(Download, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 365,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: exportingFormat === "pdf" ? "Mengunduh..." : "Export PDF" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 366,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 359,
									columnNumber: 25
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 315,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 296,
						columnNumber: 17
					}, this),
					exportError && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-red-50 dark:bg-red-950/60 border-b border-red-200 dark:border-red-800 px-6 py-2.5 text-xs text-red-600 dark:text-red-400 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { size: 15 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 373,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: exportError }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 374,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 372,
						columnNumber: 21
					}, this),
					(aiInsight || aiError) && /* @__PURE__ */ _jsxDEV("div", {
						className: "mx-6 mt-4 p-5 rounded-2xl border border-purple-200 dark:border-purple-800 bg-purple-50/60 dark:bg-purple-950/30 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-purple-700 dark:text-purple-300 font-extrabold text-sm",
								children: [/* @__PURE__ */ _jsxDEV(BarChart3, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 383,
									columnNumber: 33
								}, this), " Analisis Pintar — Hasil Ujian"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 382,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setAiInsight("");
									setAiError("");
								},
								className: "text-purple-400 hover:text-purple-600 cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 386,
									columnNumber: 98
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 385,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 381,
							columnNumber: 25
						}, this), aiError ? /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-red-600 dark:text-red-400",
							children: aiError
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 389,
							columnNumber: 29
						}, this) : renderAiMarkdown(aiInsight)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 380,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-6 max-w-5xl mx-auto w-full space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
								children: [
									{
										label: "Total Respons",
										value: analytics?.totalResponses ?? 0,
										icon: /* @__PURE__ */ _jsxDEV(Users, { size: 18 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 404,
											columnNumber: 39
										}, this),
										color: "text-[#00897B] dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60"
									},
									{
										label: "Total Soal",
										value: analytics?.totalQuestions ?? 0,
										icon: /* @__PURE__ */ _jsxDEV(FileText, { size: 18 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 410,
											columnNumber: 39
										}, this),
										color: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60"
									},
									{
										label: "Soal Dinilai",
										value: analytics?.scorableQuestions ?? 0,
										icon: /* @__PURE__ */ _jsxDEV(Award, { size: 18 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 416,
											columnNumber: 39
										}, this),
										color: "text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60"
									},
									{
										label: "Rata-rata Skor",
										value: analytics?.averageScore != null ? `${analytics.averageScore}%` : "N/A",
										icon: /* @__PURE__ */ _jsxDEV(TrendingUp, { size: 18 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 425,
											columnNumber: 39
										}, this),
										color: "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60"
									}
								].map(({ label, value, icon, color }) => /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 flex items-center gap-3 shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: `p-2.5 rounded-xl ${color}`,
										children: icon
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 433,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wide",
										children: label
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 438,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xl font-extrabold text-slate-900 dark:text-white",
										children: value
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 442,
										columnNumber: 37
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 437,
										columnNumber: 33
									}, this)]
								}, label, true, {
									fileName: _jsxFileName,
									lineNumber: 429,
									columnNumber: 29
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 399,
								columnNumber: 21
							}, this),
							respondents.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-6",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 space-y-4 shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV(BarChart3, {
												size: 18,
												className: "text-[#00897B] dark:text-teal-400"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 458,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("h2", {
												className: "text-sm font-bold text-slate-900 dark:text-white",
												children: "Diagram Distribusi Predikat Skor"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 459,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 457,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-bold text-slate-400 dark:text-slate-500",
											children: [gradeDistribution.total, " Responden Dinilai"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 461,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 456,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-3",
										children: [
											{
												grade: "Sangat Baik (A)",
												range: "90 - 100%",
												count: gradeDistribution.A,
												color: "bg-emerald-500",
												bg: "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300"
											},
											{
												grade: "Baik (B)",
												range: "75 - 89%",
												count: gradeDistribution.B,
												color: "bg-teal-500",
												bg: "bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300"
											},
											{
												grade: "Cukup (C)",
												range: "60 - 74%",
												count: gradeDistribution.C,
												color: "bg-blue-500",
												bg: "bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300"
											},
											{
												grade: "Kurang (D)",
												range: "40 - 59%",
												count: gradeDistribution.D,
												color: "bg-amber-500",
												bg: "bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300"
											},
											{
												grade: "Perlu Remidi (E)",
												range: "< 40%",
												count: gradeDistribution.E,
												color: "bg-red-500",
												bg: "bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300"
											}
										].map((item) => {
											const pct = gradeDistribution.total > 0 ? Math.round(item.count / gradeDistribution.total * 100) : 0;
											return /* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-1",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-between text-xs",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "font-bold text-slate-700 dark:text-slate-300",
														children: [
															item.grade,
															" ",
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-[10px] text-slate-400 font-normal",
																children: [
																	"(",
																	item.range,
																	")"
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 476,
																columnNumber: 129
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 476,
														columnNumber: 53
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-extrabold text-slate-800 dark:text-slate-200",
														children: [
															item.count,
															" (",
															pct,
															"%)"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 477,
														columnNumber: 53
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 475,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden",
													children: /* @__PURE__ */ _jsxDEV("div", {
														className: `h-full ${item.color} transition-all duration-500 rounded-full`,
														style: { width: `${pct}%` }
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 480,
														columnNumber: 53
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 479,
													columnNumber: 49
												}, this)]
											}, item.grade, true, {
												fileName: _jsxFileName,
												lineNumber: 474,
												columnNumber: 45
											}, this);
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 464,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 455,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 space-y-4 shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV(Award, {
												size: 18,
												className: "text-emerald-600 dark:text-emerald-400"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 492,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("h2", {
												className: "text-sm font-bold text-slate-900 dark:text-white",
												children: "Diagram Kriteria Kelulusan (≥ 70%)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 493,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 491,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-bold text-slate-400 dark:text-slate-500",
											children: "Threshold 70%"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 495,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 490,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-5 pt-1",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-xs font-extrabold",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-emerald-600 dark:text-emerald-400 flex items-center gap-1",
													children: [
														"✓ Lulus: ",
														passRateMetrics.passed,
														" (",
														passRateMetrics.passPercent,
														"%)"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 502,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-red-500 dark:text-red-400 flex items-center gap-1",
													children: [
														"✗ Belum Lulus: ",
														passRateMetrics.failed,
														" (",
														passRateMetrics.failPercent,
														"%)"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 503,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 501,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "w-full h-4 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "bg-emerald-500 h-full transition-all duration-500",
													style: { width: `${passRateMetrics.passPercent}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 506,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "bg-red-400 h-full transition-all duration-500",
													style: { width: `${passRateMetrics.failPercent}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 507,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 505,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 500,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-2 gap-3 pt-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "p-3 bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/50 rounded-xl space-y-1",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400",
													children: "Responden Lulus"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 513,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-2xl font-black text-emerald-700 dark:text-emerald-300",
													children: passRateMetrics.passed
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 514,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 512,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "p-3 bg-red-50/70 dark:bg-red-950/40 border border-red-100 dark:border-red-900/50 rounded-xl space-y-1",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] font-bold uppercase tracking-wider text-red-500 dark:text-red-400",
													children: "Perlu Pengayaan"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 517,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-2xl font-black text-red-600 dark:text-red-300",
													children: passRateMetrics.failed
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 518,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 516,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 511,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 498,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 489,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 452,
								columnNumber: 25
							}, this),
							questionAccuracyMap.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 space-y-4 shadow-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(TrendingUp, {
											size: 18,
											className: "text-indigo-600 dark:text-indigo-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 532,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("h2", {
											className: "text-sm font-bold text-slate-900 dark:text-white",
											children: "Analisis Tingkat Kesukaran & Akurasi Per Soal"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 533,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 531,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-bold text-slate-400 dark:text-slate-500",
										children: "Diurutkan dari Soal Tersulit"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 535,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 530,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-4",
									children: (questionAccuracyMap || []).map((q, idx) => {
										const isHardest = idx === 0 && q.accuracy < 60;
										const isEasiest = idx === (questionAccuracyMap || []).length - 1 && q.accuracy > 80;
										return /* @__PURE__ */ _jsxDEV("div", {
											className: "p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700/60 space-y-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-start justify-between gap-3 text-xs",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-start gap-2 flex-1",
													children: [
														/* @__PURE__ */ _jsxDEV(RichContentRenderer, {
															content: q.question,
															format: q.questionFormat,
															className: "font-bold text-slate-800 dark:text-slate-100"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 547,
															columnNumber: 53
														}, this),
														isHardest && /* @__PURE__ */ _jsxDEV("span", {
															className: "text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-red-100 text-red-600 dark:bg-red-950 dark:text-red-400 border border-red-200 shrink-0",
															children: "⚠️ Soal Tersulit"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 548,
															columnNumber: 67
														}, this),
														isEasiest && /* @__PURE__ */ _jsxDEV("span", {
															className: "text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 border border-emerald-200 shrink-0",
															children: "⭐ Soal Termudah"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 549,
															columnNumber: 67
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 546,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-extrabold text-slate-700 dark:text-slate-300 shrink-0",
													children: [
														"Akurasi ",
														q.accuracy,
														"% (",
														q.correctCount,
														"/",
														q.totalAttempts,
														")"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 551,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 545,
												columnNumber: 45
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: `h-full transition-all duration-500 rounded-full ${q.accuracy >= 75 ? "bg-emerald-500" : q.accuracy >= 50 ? "bg-amber-500" : "bg-red-500"}`,
													style: { width: `${q.accuracy}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 556,
													columnNumber: 49
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 555,
												columnNumber: 45
											}, this)]
										}, q.questionId, true, {
											fileName: _jsxFileName,
											lineNumber: 544,
											columnNumber: 41
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 538,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 529,
								columnNumber: 25
							}, this),
							respondents.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between",
										children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
											className: "text-sm font-bold text-slate-900 dark:text-white",
											children: "Rincian Responden"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 574,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400 dark:text-slate-500 mt-0.5",
											children: "Klik Review Jawaban untuk melihat jawaban lengkap."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 577,
											columnNumber: 41
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 573,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 572,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "overflow-x-auto w-full",
										children: /* @__PURE__ */ _jsxDEV("table", {
											className: "w-full text-sm text-left",
											children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
												className: "bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800",
												children: [
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "#"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 587,
														columnNumber: 49
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Responden"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 588,
														columnNumber: 49
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Dijawab"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 589,
														columnNumber: 49
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Benar"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 590,
														columnNumber: 49
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Skor"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 591,
														columnNumber: 49
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4",
														children: "Waktu Submit"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 592,
														columnNumber: 49
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "py-3 px-4 text-right",
														children: "Aksi"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 593,
														columnNumber: 49
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 586,
												columnNumber: 45
											}, this) }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 585,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("tbody", {
												className: "divide-y divide-slate-100 dark:divide-slate-800",
												children: (respondents || []).map((r, i) => /* @__PURE__ */ _jsxDEV("tr", {
													className: "hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors",
													children: [
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-slate-400",
															children: i + 1
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 603,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4",
															children: [/* @__PURE__ */ _jsxDEV("div", {
																className: "font-bold text-slate-900 dark:text-white",
																children: r.respondentName || "Anonim"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 608,
																columnNumber: 57
															}, this), /* @__PURE__ */ _jsxDEV("div", {
																className: "text-[10px] text-slate-400 dark:text-slate-500",
																children: ["Respons #", r.responseId]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 611,
																columnNumber: 57
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 607,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-slate-600 dark:text-slate-300 font-medium",
															children: [
																r.answeredCount,
																"/",
																r.totalQuestions
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 616,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-slate-600 dark:text-slate-300 font-medium",
															children: [
																r.correctCount,
																"/",
																r.scorableQuestions
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 620,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4",
															children: r.score != null ? /* @__PURE__ */ _jsxDEV("span", {
																className: `text-xs font-bold px-2.5 py-0.5 rounded-full ${r.score >= 70 ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800" : "bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400 border border-red-200 dark:border-red-800"}`,
																children: [r.score, "%"]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 626,
																columnNumber: 61
															}, this) : /* @__PURE__ */ _jsxDEV("span", {
																className: "text-slate-400 dark:text-slate-500 text-xs",
																children: "N/A"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 636,
																columnNumber: 61
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 624,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-slate-500 dark:text-slate-400 text-xs",
															children: r.submittedAt ? new Date(r.submittedAt).toLocaleDateString("id-ID", {
																day: "2-digit",
																month: "short",
																year: "numeric"
															}) : "-"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 642,
															columnNumber: 53
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "py-3.5 px-4 text-right",
															children: /* @__PURE__ */ _jsxDEV("button", {
																onClick: () => setSelectedRespondent(r),
																className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#00897B] hover:bg-[#00796B] text-white text-xs font-bold shadow-xs transition-all cursor-pointer",
																children: [/* @__PURE__ */ _jsxDEV(Eye, { size: 13 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 657,
																	columnNumber: 61
																}, this), " Review Jawaban"]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 653,
																columnNumber: 57
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 652,
															columnNumber: 53
														}, this)
													]
												}, r.responseId, true, {
													fileName: _jsxFileName,
													lineNumber: 599,
													columnNumber: 49
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 597,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 584,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 583,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 571,
									columnNumber: 29
								}, this), hasMore && /* @__PURE__ */ _jsxDEV("div", {
									className: "text-center pt-2",
									children: /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleLoadMore,
										disabled: loadingMore,
										className: "px-5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 mx-auto disabled:opacity-60 cursor-pointer",
										children: loadingMore ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
											size: 14,
											className: "animate-spin text-[#00897B] dark:text-teal-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 677,
											columnNumber: 49
										}, this), "Memuat responden..."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 676,
											columnNumber: 45
										}, this) : `Muat Lebih Banyak (${respondents.length} dari ${totalCount || "banyak"})`
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 670,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 669,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 570,
								columnNumber: 25
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-12 text-center text-slate-400 dark:text-slate-500 text-sm font-medium shadow-xs",
								children: "Belum ada respons yang masuk untuk formulir ini."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 688,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 396,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 293,
				columnNumber: 13
			}, this),
			selectedRespondent && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] flex flex-col border border-slate-200/80 dark:border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-slate-900 dark:text-white text-sm",
							children: ["Detail Respons — ", selectedRespondent.respondentName || "Anonim"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 703,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-400 dark:text-slate-500",
							children: [
								"Respons #",
								selectedRespondent.responseId,
								" • Skor: ",
								selectedRespondent.score != null ? `${selectedRespondent.score}%` : "N/A"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 706,
							columnNumber: 33
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 702,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: goPrevious,
									disabled: currentIndex <= 0,
									className: "p-1.5 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 disabled:opacity-30 cursor-pointer",
									title: "Sebelumnya",
									children: /* @__PURE__ */ _jsxDEV(ChevronLeft, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 718,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 712,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: goNext,
									disabled: currentIndex >= respondents.length - 1,
									className: "p-1.5 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 disabled:opacity-30 cursor-pointer",
									title: "Berikutnya",
									children: /* @__PURE__ */ _jsxDEV(ChevronRight, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 726,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 720,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setSelectedRespondent(null),
									className: "p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl cursor-pointer",
									children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 733,
										columnNumber: 37
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 729,
									columnNumber: 33
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 711,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 701,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-y-auto p-4 space-y-4 flex-1",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-3 gap-3 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl text-center text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400 dark:text-slate-500 font-bold uppercase text-[10px]",
									children: "Dijawab"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 742,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "font-extrabold text-slate-800 dark:text-slate-200 text-sm mt-0.5",
									children: [
										selectedRespondent.answeredCount,
										"/",
										selectedRespondent.totalQuestions
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 743,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 741,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400 dark:text-slate-500 font-bold uppercase text-[10px]",
									children: "Benar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 746,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "font-extrabold text-slate-800 dark:text-slate-200 text-sm mt-0.5",
									children: [
										selectedRespondent.correctCount,
										"/",
										selectedRespondent.scorableQuestions
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 747,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 745,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400 dark:text-slate-500 font-bold uppercase text-[10px]",
									children: "Skor"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 750,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "font-extrabold text-[#00897B] dark:text-teal-400 text-sm mt-0.5",
									children: selectedRespondent.score != null ? `${selectedRespondent.score}%` : "N/A"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 751,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 749,
									columnNumber: 33
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 740,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: (selectedRespondent?.answers || []).map((a, i) => {
								const status = getAnswerStatus(a);
								return /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-50 dark:bg-slate-800/40 rounded-xl p-4 border border-slate-200/60 dark:border-slate-700/60 space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-2 flex-1",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-slate-400 text-xs",
												children: [i + 1, "."]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 766,
												columnNumber: 53
											}, this), /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
												content: a.question,
												format: a.questionFormat,
												className: "text-xs font-bold text-slate-800 dark:text-slate-200"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 767,
												columnNumber: 53
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 765,
											columnNumber: 49
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: `inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-0.5 rounded-full border shrink-0 ${status.className}`,
											children: [
												status.icon,
												" ",
												status.label
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 770,
											columnNumber: 49
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 764,
										columnNumber: 45
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "pl-4 space-y-1 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-baseline gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-400 dark:text-slate-500 font-medium",
												children: "Jawaban:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 777,
												columnNumber: 53
											}, this), /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
												content: a.optionText || a.answerText || "—",
												format: "text",
												className: "font-bold text-slate-800 dark:text-slate-100"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 778,
												columnNumber: 53
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 776,
											columnNumber: 49
										}, this), a.correctAnswer && /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-baseline gap-2 text-emerald-600 dark:text-emerald-400",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-medium",
												children: "Kunci:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 783,
												columnNumber: 57
											}, this), /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
												content: a.correctAnswer,
												format: "text",
												className: "font-bold"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 784,
												columnNumber: 57
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 782,
											columnNumber: 53
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 775,
										columnNumber: 45
									}, this)]
								}, i, true, {
									fileName: _jsxFileName,
									lineNumber: 760,
									columnNumber: 41
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 755,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 739,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 699,
					columnNumber: 21
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 698,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 290,
		columnNumber: 9
	}, this);
}
_s(FormAnalyticsPage, "gdlvU/jO9EemvE6ruRaWLDL4p1s=", false, function() {
	return [useParams, useNavigate];
});
_c = FormAnalyticsPage;
function renderAiMarkdown(text) {
	if (!text) return null;
	// Split by code blocks first
	const parts = text.split(/(```[\s\S]*?```)/g);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed",
		children: parts.map((part, pIdx) => {
			if (part.startsWith("```") && part.endsWith("```")) {
				const firstNewline = part.indexOf("\n");
				let lang = "";
				let code = "";
				if (firstNewline !== -1) {
					lang = part.slice(3, firstNewline).trim();
					code = part.slice(firstNewline + 1, -3);
				} else {
					code = part.slice(3, -3);
				}
				return /* @__PURE__ */ _jsxDEV("div", {
					className: "my-2 p-3 bg-slate-900 text-slate-100 rounded-xl font-mono text-xs overflow-x-auto",
					children: [lang && /* @__PURE__ */ _jsxDEV("div", {
						className: "text-[10px] text-purple-400 font-bold mb-1 uppercase",
						children: lang
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 821,
						columnNumber: 38
					}, this), /* @__PURE__ */ _jsxDEV("pre", {
						className: "whitespace-pre font-mono",
						children: /* @__PURE__ */ _jsxDEV("code", { children: code }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 822,
							columnNumber: 71
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 822,
						columnNumber: 29
					}, this)]
				}, pIdx, true, {
					fileName: _jsxFileName,
					lineNumber: 820,
					columnNumber: 25
				}, this);
			}
			const lines = part.split("\n");
			const elements = [];
			let currentList = [];
			let isNumberedList = false;
			const flushList = () => {
				if (currentList.length > 0) {
					if (isNumberedList) {
						elements.push(/* @__PURE__ */ _jsxDEV("ol", {
							className: "list-decimal list-inside space-y-1 my-1.5 ml-2",
							children: currentList.map((li, i) => /* @__PURE__ */ _jsxDEV("li", { children: parseInlineMarkdown(li) }, i, false, {
								fileName: _jsxFileName,
								lineNumber: 838,
								columnNumber: 41
							}, this))
						}, `ol-${elements.length}`, false, {
							fileName: _jsxFileName,
							lineNumber: 836,
							columnNumber: 33
						}, this));
					} else {
						elements.push(/* @__PURE__ */ _jsxDEV("ul", {
							className: "list-disc list-inside space-y-1 my-1.5 ml-2",
							children: currentList.map((li, i) => /* @__PURE__ */ _jsxDEV("li", { children: parseInlineMarkdown(li) }, i, false, {
								fileName: _jsxFileName,
								lineNumber: 846,
								columnNumber: 41
							}, this))
						}, `ul-${elements.length}`, false, {
							fileName: _jsxFileName,
							lineNumber: 844,
							columnNumber: 33
						}, this));
					}
					currentList = [];
				}
			};
			lines.forEach((line, lIdx) => {
				const trimmed = line.trim();
				if (!trimmed) {
					flushList();
					return;
				}
				if (trimmed.startsWith("### ")) {
					flushList();
					elements.push(/* @__PURE__ */ _jsxDEV("h4", {
						className: "font-extrabold text-sm sm:text-base text-slate-900 dark:text-white mt-3 mb-1",
						children: parseInlineMarkdown(trimmed.slice(4))
					}, `h4-${lIdx}`, false, {
						fileName: _jsxFileName,
						lineNumber: 866,
						columnNumber: 29
					}, this));
					return;
				}
				if (trimmed.startsWith("## ")) {
					flushList();
					elements.push(/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-extrabold text-base text-slate-900 dark:text-white mt-4 mb-1.5 pb-1 border-b border-purple-200/50 dark:border-purple-800/50",
						children: parseInlineMarkdown(trimmed.slice(3))
					}, `h3-${lIdx}`, false, {
						fileName: _jsxFileName,
						lineNumber: 875,
						columnNumber: 29
					}, this));
					return;
				}
				if (trimmed.startsWith("# ")) {
					flushList();
					elements.push(/* @__PURE__ */ _jsxDEV("h2", {
						className: "font-extrabold text-lg text-slate-900 dark:text-white mt-4 mb-2",
						children: parseInlineMarkdown(trimmed.slice(2))
					}, `h2-${lIdx}`, false, {
						fileName: _jsxFileName,
						lineNumber: 884,
						columnNumber: 29
					}, this));
					return;
				}
				if (/^[-*]\s+/.test(trimmed)) {
					if (isNumberedList) flushList();
					isNumberedList = false;
					currentList.push(trimmed.replace(/^[-*]\s+/, ""));
					return;
				}
				if (/^\d+\.\s+/.test(trimmed)) {
					if (!isNumberedList && currentList.length > 0) flushList();
					isNumberedList = true;
					currentList.push(trimmed.replace(/^\d+\.\s+/, ""));
					return;
				}
				flushList();
				elements.push(/* @__PURE__ */ _jsxDEV("p", {
					className: "leading-relaxed",
					children: parseInlineMarkdown(trimmed)
				}, `p-${lIdx}`, false, {
					fileName: _jsxFileName,
					lineNumber: 907,
					columnNumber: 25
				}, this));
			});
			flushList();
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-1.5",
				children: elements
			}, pIdx, false, {
				fileName: _jsxFileName,
				lineNumber: 915,
				columnNumber: 24
			}, this);
		})
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 807,
		columnNumber: 9
	}, this);
}
function parseInlineMarkdown(text) {
	if (!text) return null;
	const tokenRegex = /(\*\*.*?\*\*|`.*?`|\*.*?\*)/g;
	const parts = text.split(tokenRegex);
	return parts.map((part, i) => {
		if (part.startsWith("**") && part.endsWith("**")) {
			return /* @__PURE__ */ _jsxDEV("strong", {
				className: "font-bold text-slate-900 dark:text-white",
				children: part.slice(2, -2)
			}, i, false, {
				fileName: _jsxFileName,
				lineNumber: 929,
				columnNumber: 20
			}, this);
		}
		if (part.startsWith("`") && part.endsWith("`")) {
			return /* @__PURE__ */ _jsxDEV("code", {
				className: "px-1.5 py-0.5 rounded bg-purple-100/70 dark:bg-purple-900/40 text-purple-800 dark:text-purple-300 font-mono text-[11px]",
				children: part.slice(1, -1)
			}, i, false, {
				fileName: _jsxFileName,
				lineNumber: 932,
				columnNumber: 20
			}, this);
		}
		if (part.startsWith("*") && part.endsWith("*")) {
			return /* @__PURE__ */ _jsxDEV("em", {
				className: "italic",
				children: part.slice(1, -1)
			}, i, false, {
				fileName: _jsxFileName,
				lineNumber: 935,
				columnNumber: 20
			}, this);
		}
		return part;
	});
}
var _c;
$RefreshReg$(_c, "FormAnalyticsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/form-responses/FormAnalyticsPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-responses/FormAnalyticsPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-responses/FormAnalyticsPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-responses/FormAnalyticsPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsYUFBYSxlQUFlO0FBQzFELFNBQVMsYUFBYSxpQkFBaUI7QUFDdkMsU0FDSSxXQUNBLE9BQ0EsVUFDQSxPQUNBLFlBQ0EsS0FDQSxHQUNBLGNBQ0EsU0FDQSxhQUNBLGFBQ0EsY0FDQSxTQUNBLFdBQ0EsT0FDQSxhQUNBLGdCQUNHO0FBRVAsT0FBTyxhQUFhO0FBQ3BCLFNBQ0ksYUFDQSxrQkFDQSxxQkFDQSxvQkFDRztBQUNQLFNBQVMsaUJBQWlCLDRCQUE0Qix3QkFBd0I7QUFDOUUsT0FBTyx5QkFBeUI7Ozs7QUFFaEMsTUFBTSxZQUFZO0FBRWxCLGVBQWUsU0FBUyxvQkFBb0I7O0NBQ3hDLE1BQU0sRUFBRSxPQUFPLFVBQVU7Q0FDekIsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLElBQUk7Q0FDckMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsSUFBSTtDQUMvQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxDQUFDLENBQUM7Q0FDakQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsQ0FBQztDQUNsQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxDQUFDO0NBQzlDLE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsSUFBSTtDQUNqRSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7Q0FDM0QsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsSUFBSTtDQUNuRCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLElBQUk7O0NBRzdELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsU0FBUyxjQUFjLGVBQWU7RUFBRSxNQUFNLElBQUksYUFBYSxRQUFRLDRCQUE0QjtFQUFHLE9BQU8sS0FBSyxDQUFDLEVBQUUsU0FBUyxNQUFNLEtBQUssaUJBQWlCLE1BQUssVUFBUyxNQUFNLE9BQU8sQ0FBQyxJQUFJLElBQUk7Q0FBb0IsQ0FBQztDQUUxTixNQUFNLGVBQWUsT0FBTyxXQUFXO0VBQ25DLElBQUksQ0FBQyxNQUFNLG9CQUFvQixNQUFNO0VBQ3JDLG1CQUFtQixNQUFNO0VBQ3pCLGVBQWUsSUFBSTtFQUVuQixJQUFJO0dBQ0EsTUFBTSxNQUFNLE1BQU0sb0JBQW9CLElBQUksUUFBUSxnQkFBZ0I7R0FDbEUsSUFBSSxDQUFDLElBQUksSUFBSTtJQUNULGVBQWUsSUFBSSxXQUFXLG1DQUFtQyxPQUFPLFlBQVksR0FBRztJQUN2RixpQkFBaUIsZUFBZSxJQUFJLEdBQUcsR0FBSTtHQUMvQztFQUNKLFNBQVMsS0FBSztHQUNWLGVBQWUsMENBQTBDLE9BQU8sWUFBWSxHQUFHO0dBQy9FLGlCQUFpQixlQUFlLElBQUksR0FBRyxHQUFJO0VBQy9DLFVBQVU7R0FDTixtQkFBbUIsSUFBSTtFQUMzQjtDQUNKOztDQUdBLE1BQU0sa0JBQWtCLFlBQVk7RUFDaEMsZUFBZSxJQUFJO0VBQ25CLGFBQWEsRUFBRTtFQUNmLFdBQVcsRUFBRTtFQUViLElBQUk7R0FDQSxNQUFNLFVBQVU7WUFDaEIsTUFBTSxTQUFTLGtCQUFrQjtpQkFDNUIsV0FBVyxrQkFBa0IsWUFBWSxPQUFPO2NBQ25ELFdBQVcsa0JBQWtCLEVBQUU7Z0JBQzdCLFdBQVcscUJBQXFCLEVBQUU7a0JBQ2hDLFdBQVcsZ0JBQWdCLE9BQU8sVUFBVSxlQUFlLE1BQU0sTUFBTTs7OzhCQUczRCxrQkFBa0IsRUFBRTtzQkFDNUIsa0JBQWtCLEVBQUU7dUJBQ25CLGtCQUFrQixFQUFFO3dCQUNuQixrQkFBa0IsRUFBRTs0QkFDaEIsa0JBQWtCLEVBQUU7OztXQUdyQyxnQkFBZ0IsT0FBTyxVQUFVLGdCQUFnQixZQUFZO2lCQUN2RCxnQkFBZ0IsT0FBTyxVQUFVLGdCQUFnQixZQUFZOzs7RUFHNUUsb0JBQW9CLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxLQUFJLE1BQUssT0FBTyxFQUFFLFlBQVksR0FBRSxDQUFFLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FBQyxVQUFVLEdBQUcsRUFBRSxFQUFFLGFBQWEsRUFBRSxTQUFTLEtBQUssRUFBRSxhQUFhLEdBQUcsRUFBRSxjQUFjLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFO0VBQzFMLEtBQUs7R0FFSyxNQUFNLE1BQU0sTUFBTSwyQkFBMkI7SUFBRTtJQUFTLGVBQWU7SUFBUyxjQUFjLGdCQUFnQjtHQUFFLENBQUM7R0FDakgsSUFBSSxDQUFDLElBQUksSUFBSTtJQUNULFdBQVcsSUFBSSxXQUFXLCtCQUErQjtJQUN6RDtHQUNKO0dBRUEsYUFBYSxJQUFJLElBQUk7RUFDekIsU0FBUyxLQUFLO0dBQ1YsV0FBVyx5QkFBeUIsSUFBSSxPQUFPO0VBQ25ELFVBQVU7R0FDTixlQUFlLEtBQUs7RUFDeEI7Q0FDSjtDQUVBLGdCQUFnQjtFQUNaLE1BQU0sT0FBTyxZQUFZO0dBQ3JCLFdBQVcsSUFBSTtHQUVmLElBQUk7SUFDQSxNQUFNLENBQUMsU0FBUyxnQkFBZ0IsTUFBTSxRQUFRLElBQUksQ0FDOUMsWUFBWSxFQUFFLEdBQ2QsaUJBQWlCLElBQUksR0FBRyxTQUFTLENBQ3JDLENBQUM7SUFFRCxJQUFJLFFBQVEsV0FBVyxLQUFLO0tBQ3hCLGFBQWE7S0FDYixTQUFTLFFBQVE7S0FDakI7SUFDSjtJQUVBLElBQUksUUFBUSxJQUFJO0tBQ1osUUFBUSxRQUFRLElBQUk7SUFDeEI7SUFFQSxJQUFJLGFBQWEsTUFBTSxhQUFhLE1BQU07S0FDdEMsYUFBYSxhQUFhLElBQUk7S0FDOUIsTUFBTSxPQUFPLGFBQWEsS0FBSyxlQUFlLENBQUM7S0FDL0MsTUFBTSxRQUFRLGFBQWEsS0FBSyxrQkFBa0IsS0FBSztLQUN2RCxlQUFlLElBQUk7S0FDbkIsY0FBYyxLQUFLO0tBQ25CLFdBQVcsS0FBSyxVQUFVLFNBQVM7SUFDdkM7R0FDSixTQUFTLE9BQU87SUFDWixRQUFRLE1BQU0sNkJBQTZCLEtBQUs7R0FDcEQsVUFBVTtJQUNOLFdBQVcsS0FBSztHQUNwQjtFQUNKO0VBRUEsS0FBSztDQUNULEdBQUcsQ0FBQyxJQUFJLFFBQVEsQ0FBQztDQUVqQixNQUFNLGlCQUFpQixZQUFZLFlBQVk7RUFDM0MsSUFBSSxlQUFlLENBQUMsU0FBUztFQUM3QixlQUFlLElBQUk7RUFFbkIsTUFBTSxXQUFXLE9BQU87RUFDeEIsTUFBTSxNQUFNLE1BQU0saUJBQWlCLElBQUksVUFBVSxTQUFTO0VBQzFELGVBQWUsS0FBSztFQUVwQixJQUFJLElBQUksTUFBTSxJQUFJLE1BQU07R0FDcEIsTUFBTSxVQUFVLElBQUksS0FBSyxlQUFlLENBQUM7R0FDekMsSUFBSSxRQUFRLFNBQVMsR0FBRztJQUNwQixnQkFBZSxTQUFRLENBQUMsR0FBRyxNQUFNLEdBQUcsT0FBTyxDQUFDO0lBQzVDLFFBQVEsUUFBUTtJQUNoQixXQUFXLFFBQVEsVUFBVSxTQUFTO0dBQzFDLE9BQU87SUFDSCxXQUFXLEtBQUs7R0FDcEI7RUFDSjtDQUNKLEdBQUc7RUFBQztFQUFJO0VBQU07RUFBYTtDQUFPLENBQUM7O0NBR25DLE1BQU0sb0JBQW9CLGNBQWM7RUFDcEMsTUFBTSxTQUFTO0dBQUUsR0FBRztHQUFHLEdBQUc7R0FBRyxHQUFHO0dBQUcsR0FBRztHQUFHLEdBQUc7R0FBRyxPQUFPO0VBQUU7RUFDeEQsQ0FBQyxlQUFlLENBQUMsRUFBQyxDQUFFLFNBQVEsTUFBSztHQUM3QixJQUFJLEVBQUUsU0FBUyxNQUFNO0dBQ3JCLE9BQU87R0FDUCxJQUFJLEVBQUUsU0FBUyxJQUFJLE9BQU87UUFDckIsSUFBSSxFQUFFLFNBQVMsSUFBSSxPQUFPO1FBQzFCLElBQUksRUFBRSxTQUFTLElBQUksT0FBTztRQUMxQixJQUFJLEVBQUUsU0FBUyxJQUFJLE9BQU87UUFDMUIsT0FBTztFQUNoQixDQUFDO0VBQ0QsT0FBTztDQUNYLEdBQUcsQ0FBQyxXQUFXLENBQUM7Q0FFaEIsTUFBTSxrQkFBa0IsY0FBYztFQUNsQyxJQUFJLFNBQVM7RUFDYixJQUFJLFNBQVM7RUFDYixDQUFDLGVBQWUsQ0FBQyxFQUFDLENBQUUsU0FBUSxNQUFLO0dBQzdCLElBQUksRUFBRSxTQUFTLE1BQU07R0FDckIsSUFBSSxFQUFFLFNBQVMsSUFBSTtRQUNkO0VBQ1QsQ0FBQztFQUNELE1BQU0sUUFBUSxTQUFTO0VBQ3ZCLE9BQU87R0FDSDtHQUNBO0dBQ0E7R0FDQSxhQUFhLFFBQVEsSUFBSSxLQUFLLE1BQU8sU0FBUyxRQUFTLEdBQUcsSUFBSTtHQUM5RCxhQUFhLFFBQVEsSUFBSSxLQUFLLE1BQU8sU0FBUyxRQUFTLEdBQUcsSUFBSTtFQUNsRTtDQUNKLEdBQUcsQ0FBQyxXQUFXLENBQUM7Q0FFaEIsTUFBTSxzQkFBc0IsY0FBYztFQUN0QyxNQUFNLE9BQU8sQ0FBQztFQUNkLENBQUMsZUFBZSxDQUFDLEVBQUMsQ0FBRSxTQUFRLE1BQUs7R0FDN0IsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxFQUFDLENBQUUsU0FBUSxNQUFLO0lBQzNCLElBQUksQ0FBQyxFQUFFLFlBQVk7SUFDbkIsSUFBSSxDQUFDLEtBQUssRUFBRSxhQUFhO0tBQ3JCLEtBQUssRUFBRSxjQUFjO01BQ2pCLFlBQVksRUFBRTtNQUNkLFVBQVUsRUFBRSxZQUFZLFNBQVMsRUFBRTtNQUNuQyxnQkFBZ0IsRUFBRSxrQkFBa0I7TUFDcEMsY0FBYztNQUNkLGVBQWU7S0FDbkI7SUFDSjtJQUNBLElBQUksRUFBRSxhQUFhLE1BQU07S0FDckIsS0FBSyxFQUFFLFdBQVcsQ0FBQztLQUNuQixJQUFJLEVBQUUsY0FBYyxNQUFNLEtBQUssRUFBRSxXQUFXLENBQUM7SUFDakQ7R0FDSixDQUFDO0VBQ0wsQ0FBQztFQUVELE9BQU8sT0FBTyxPQUFPLElBQUksQ0FBQyxDQUFDLEtBQUksT0FBTTtHQUNqQyxHQUFHO0dBQ0gsVUFBVSxFQUFFLGdCQUFnQixJQUFJLEtBQUssTUFBTyxFQUFFLGVBQWUsRUFBRSxnQkFBaUIsR0FBRyxJQUFJO0VBQzNGLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsV0FBVyxFQUFFLFFBQVE7Q0FDOUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztDQUVoQixJQUFJLFNBQVM7RUFDVCxPQUNJLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1gsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGlFQUFrRTs7OztjQUNyRix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF5RDtJQUE4Qjs7OztZQUNuRzs7Ozs7O0VBQ0o7Ozs7O0NBRWI7Q0FFQSxNQUFNLGVBQWUscUJBQ2YsWUFBWSxXQUFVLE1BQUssRUFBRSxlQUFlLG1CQUFtQixVQUFVLElBQ3pFLENBQUM7Q0FFUCxNQUFNLG1CQUFtQjtFQUNyQixJQUFJLGVBQWUsR0FBRztHQUNsQixzQkFBc0IsWUFBWSxlQUFlLEVBQUU7RUFDdkQ7Q0FDSjtDQUVBLE1BQU0sZUFBZTtFQUNqQixJQUFJLGVBQWUsWUFBWSxTQUFTLEdBQUc7R0FDdkMsc0JBQXNCLFlBQVksZUFBZSxFQUFFO0VBQ3ZEO0NBQ0o7Q0FFQSxNQUFNLG1CQUFtQixXQUFXO0VBQ2hDLElBQUksT0FBTyxjQUFjLE1BQU07R0FDM0IsT0FBTztJQUNILE9BQU87SUFDUCxNQUFNLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O0lBQy9CLFdBQVc7R0FDZjtFQUNKO0VBRUEsSUFBSSxPQUFPLGNBQWMsT0FBTztHQUM1QixPQUFPO0lBQ0gsT0FBTztJQUNQLE1BQU0sd0JBQUMsU0FBRCxFQUFTLE1BQU0sR0FBSzs7Ozs7SUFDMUIsV0FBVztHQUNmO0VBQ0o7RUFFQSxPQUFPO0dBQ0gsT0FBTztHQUNQLE1BQU0sd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7Ozs7R0FDOUIsV0FBVztFQUNmO0NBQ0o7Q0FFQSxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDSSx3QkFBQyxTQUFELENBQVU7Ozs7O0dBRVYsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUdJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxVQUFEO1FBQ0ksZUFBZSxTQUFTLFVBQVUsR0FBRyxXQUFXO1FBQ2hELFdBQVU7a0JBRVYsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7T0FDbEI7Ozs7aUJBQ1Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUNLLE1BQU0sU0FBUyxZQUFXLHVCQUMzQjs7Ozs7a0JBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWI7VUFBMEQ7VUFDaEIsWUFBWTtVQUFPO1VBQUksY0FBYyxZQUFZO1VBQU87U0FDL0Y7Ozs7O2dCQUNGOzs7OztlQUNKOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUVJLHdCQUFDLFVBQUQ7U0FDSSxTQUFTO1NBQ1QsVUFBVSxlQUFlLFlBQVksV0FBVztTQUNoRCxXQUFVO21CQUhkLENBS0ksd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OzttQkFDdEIsd0JBQUMsUUFBRCxZQUFPLGNBQWMsb0JBQW9CLGtCQUF3Qjs7OztpQkFDN0Q7Ozs7OztRQUNSLHdCQUFDLFVBQUQ7U0FBUSxjQUFXO1NBQXdCLE9BQU87U0FBUyxXQUFVLE1BQUs7VUFBRSxXQUFXLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBYSxRQUFRLDhCQUE4QixFQUFFLE9BQU8sS0FBSztTQUFHO1NBQUcsV0FBVTttQkFDcEwsaUJBQWlCLEtBQUksVUFBUyx3QkFBQyxVQUFEO1VBQXVCLE9BQU8sTUFBTTtvQkFBSyxNQUFNO1NBQWEsR0FBL0MsTUFBTTs7OztnQkFBeUMsQ0FBQztRQUN4Rjs7Ozs7UUFFUix3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FDSSx3QkFBQyxTQUFEO1VBQ0ksTUFBSztVQUNMLFNBQVM7VUFDVCxXQUFVLE1BQUssb0JBQW9CLEVBQUUsT0FBTyxPQUFPO1VBQ25ELFdBQVU7U0FDYjs7OzttQkFDRCx3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O2lCQUN0Qjs7Ozs7O1FBRVAsd0JBQUMsVUFBRDtTQUNJLGVBQWUsYUFBYSxNQUFNO1NBQ2xDLFVBQVUsb0JBQW9CO1NBQzlCLFdBQVU7U0FDVixPQUFNO21CQUpWLENBTUksd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OzttQkFDckIsd0JBQUMsUUFBRCxZQUFPLG9CQUFvQixTQUFTLGlCQUFpQixjQUFvQjs7OztpQkFDckU7Ozs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDSSxlQUFlLGFBQWEsS0FBSztTQUNqQyxVQUFVLG9CQUFvQjtTQUM5QixXQUFVO1NBQ1YsT0FBTTttQkFKVixDQU1JLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7bUJBQ3JCLHdCQUFDLFFBQUQsWUFBTyxvQkFBb0IsUUFBUSxpQkFBaUIsYUFBbUI7Ozs7aUJBQ25FOzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0ksZUFBZSxhQUFhLEtBQUs7U0FDakMsVUFBVSxvQkFBb0I7U0FDOUIsV0FBVTtTQUNWLE9BQU07bUJBSlYsQ0FNSSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7O21CQUNyQix3QkFBQyxRQUFELFlBQU8sb0JBQW9CLFFBQVEsaUJBQWlCLGFBQW1COzs7O2lCQUNuRTs7Ozs7O09BQ1A7Ozs7O2NBQ0o7Ozs7OztLQUVKLGVBQ0csd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7O2dCQUN4Qix3QkFBQyxRQUFELFlBQU8sWUFBa0I7Ozs7Y0FDeEI7Ozs7OztNQUlQLGFBQWEsWUFDWCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O2tCQUFDLGdDQUN0Qjs7Ozs7aUJBQ0wsd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxlQUFlO1NBQUUsYUFBYSxFQUFFO1NBQUcsV0FBVyxFQUFFO1FBQUc7UUFDckUsV0FBVTtrQkFBdUQsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7T0FBUzs7OztlQUMzRjs7Ozs7Z0JBQ0osVUFDRyx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBMEM7TUFBVzs7OztpQkFFbEUsaUJBQWlCLFNBQVMsQ0FFN0I7Ozs7OztLQUdULHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BR0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1Y7U0FDRztVQUNJLE9BQU87VUFDUCxPQUFPLFdBQVcsa0JBQWtCO1VBQ3BDLE1BQU0sd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7Ozs7VUFDeEIsT0FBTztTQUNYO1NBQ0E7VUFDSSxPQUFPO1VBQ1AsT0FBTyxXQUFXLGtCQUFrQjtVQUNwQyxNQUFNLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O1VBQzNCLE9BQU87U0FDWDtTQUNBO1VBQ0ksT0FBTztVQUNQLE9BQU8sV0FBVyxxQkFBcUI7VUFDdkMsTUFBTSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztVQUN4QixPQUFPO1NBQ1g7U0FDQTtVQUNJLE9BQU87VUFDUCxPQUNJLFdBQVcsZ0JBQWdCLE9BQ3JCLEdBQUcsVUFBVSxhQUFhLEtBQzFCO1VBQ1YsTUFBTSx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztVQUM3QixPQUFPO1NBQ1g7UUFDSixDQUFDLENBQUMsS0FBSyxFQUFFLE9BQU8sT0FBTyxNQUFNLFlBQ3pCLHdCQUFDLE9BQUQ7U0FFSSxXQUFVO21CQUZkLENBSUksd0JBQUMsT0FBRDtVQUFLLFdBQVcsb0JBQW9CO29CQUMvQjtTQUNBOzs7O21CQUVMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDUjtTQUNGOzs7O21CQUVILHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNSO1NBQ0Y7Ozs7aUJBQ0Y7Ozs7aUJBQ0o7V0FoQkk7Ozs7ZUFnQkosQ0FDUjtPQUNBOzs7OztPQUdKLFlBQVksU0FBUyxLQUNsQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUdJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFdBQUQ7WUFBVyxNQUFNO1lBQUksV0FBVTtXQUFxQzs7OztxQkFDcEUsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQW1EO1dBQW9DOzs7O21CQUNwRzs7Ozs7b0JBQ0wsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQTRFLGtCQUFrQixPQUFNLG9CQUF3Qjs7Ozs7a0JBQzNIOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDVjtXQUNHO1lBQUUsT0FBTztZQUFtQixPQUFPO1lBQWEsT0FBTyxrQkFBa0I7WUFBRyxPQUFPO1lBQWtCLElBQUk7V0FBOEU7V0FDdkw7WUFBRSxPQUFPO1lBQVksT0FBTztZQUFZLE9BQU8sa0JBQWtCO1lBQUcsT0FBTztZQUFlLElBQUk7V0FBa0U7V0FDaEs7WUFBRSxPQUFPO1lBQWEsT0FBTztZQUFZLE9BQU8sa0JBQWtCO1lBQUcsT0FBTztZQUFlLElBQUk7V0FBa0U7V0FDaks7WUFBRSxPQUFPO1lBQWMsT0FBTztZQUFZLE9BQU8sa0JBQWtCO1lBQUcsT0FBTztZQUFnQixJQUFJO1dBQXNFO1dBQ3ZLO1lBQUUsT0FBTztZQUFvQixPQUFPO1lBQVMsT0FBTyxrQkFBa0I7WUFBRyxPQUFPO1lBQWMsSUFBSTtXQUE4RDtVQUNwSyxDQUFDLENBQUMsS0FBSSxTQUFRO1dBQ1YsTUFBTSxNQUFNLGtCQUFrQixRQUFRLElBQUksS0FBSyxNQUFPLEtBQUssUUFBUSxrQkFBa0IsUUFBUyxHQUFHLElBQUk7V0FDckcsT0FDSSx3QkFBQyxPQUFEO1lBQXNCLFdBQVU7c0JBQWhDLENBQ0ksd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDSSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBaEI7ZUFBZ0UsS0FBSztlQUFNO2VBQUMsd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUFoQjtpQkFBeUQ7aUJBQUUsS0FBSztpQkFBTTtnQkFBTzs7Ozs7O2NBQU87Ozs7O3VCQUNoSyx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBaEI7ZUFBcUUsS0FBSztlQUFNO2VBQUc7ZUFBSTtjQUFROzs7OztxQkFDOUY7Ozs7O3NCQUNMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUNYLHdCQUFDLE9BQUQ7Y0FBSyxXQUFXLFVBQVUsS0FBSyxNQUFNO2NBQTRDLE9BQU8sRUFBRSxPQUFPLEdBQUcsSUFBSSxHQUFHO2FBQUk7Ozs7O1lBQzlHOzs7O29CQUNKO2NBUkssS0FBSzs7OztrQkFRVjtVQUViLENBQUM7U0FDQTs7OztpQkFDSjs7Ozs7a0JBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsT0FBRDtZQUFPLE1BQU07WUFBSSxXQUFVO1dBQTBDOzs7O3FCQUNyRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBbUQ7V0FBeUM7Ozs7bUJBQ3pHOzs7OztvQkFDTCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBMkQ7VUFBbUI7Ozs7a0JBQzdGOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUVJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FBaUY7Y0FBVSxnQkFBZ0I7Y0FBTztjQUFHLGdCQUFnQjtjQUFZO2FBQVE7Ozs7O3NCQUN6Six3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FBeUU7Y0FBZ0IsZ0JBQWdCO2NBQU87Y0FBRyxnQkFBZ0I7Y0FBWTthQUFROzs7OztvQkFDdEo7Ozs7O3FCQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0ksd0JBQUMsT0FBRDthQUFLLFdBQVU7YUFBb0QsT0FBTyxFQUFFLE9BQU8sR0FBRyxnQkFBZ0IsWUFBWSxHQUFHO1lBQUk7Ozs7c0JBQ3pILHdCQUFDLE9BQUQ7YUFBSyxXQUFVO2FBQWdELE9BQU8sRUFBRSxPQUFPLEdBQUcsZ0JBQWdCLFlBQVksR0FBRztZQUFJOzs7O29CQUNwSDs7Ozs7bUJBQ0o7Ozs7O29CQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBd0Y7WUFBa0I7Ozs7c0JBQ3ZILHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUE4RCxnQkFBZ0I7WUFBVTs7OztvQkFDcEc7Ozs7O3FCQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0ksd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWdGO1lBQWtCOzs7O3NCQUMvRyx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBc0QsZ0JBQWdCO1lBQVU7Ozs7b0JBQzVGOzs7OzttQkFDSjs7Ozs7a0JBQ0o7Ozs7O2lCQUNKOzs7OztnQkFFSjs7Ozs7O09BSVIsb0JBQW9CLFNBQVMsS0FDMUIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsWUFBRDtXQUFZLE1BQU07V0FBSSxXQUFVO1VBQXdDOzs7O29CQUN4RSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBbUQ7VUFBaUQ7Ozs7a0JBQ2pIOzs7OzttQkFDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMkQ7U0FBa0M7Ozs7aUJBQzVHOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTtvQkFDVCx1QkFBdUIsQ0FBQyxFQUFDLENBQUUsS0FBSyxHQUFHLFFBQVE7VUFDekMsTUFBTSxZQUFZLFFBQVEsS0FBSyxFQUFFLFdBQVc7VUFDNUMsTUFBTSxZQUFZLFNBQVMsdUJBQXVCLENBQUMsRUFBQyxDQUFFLFNBQVMsS0FBSyxFQUFFLFdBQVc7VUFFakYsT0FDSSx3QkFBQyxPQUFEO1dBQXdCLFdBQVU7cUJBQWxDLENBQ0ksd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZjtjQUNJLHdCQUFDLHFCQUFEO2VBQXFCLFNBQVMsRUFBRTtlQUFVLFFBQVEsRUFBRTtlQUFnQixXQUFVO2NBQWdEOzs7OztjQUM3SCxhQUFhLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUErSTtjQUFzQjs7Ozs7Y0FDbE0sYUFBYSx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBbUs7Y0FBcUI7Ozs7O2FBQ3JOOzs7OztzQkFDTCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FBNkU7Y0FDaEUsRUFBRTtjQUFTO2NBQUksRUFBRTtjQUFhO2NBQUUsRUFBRTtjQUFjO2FBQ3ZEOzs7OztvQkFDTDs7Ozs7cUJBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ1gsd0JBQUMsT0FBRDthQUNJLFdBQVcsbURBQW1ELEVBQUUsWUFBWSxLQUFLLG1CQUFtQixFQUFFLFlBQVksS0FBSyxpQkFBaUI7YUFDeEksT0FBTyxFQUFFLE9BQU8sR0FBRyxFQUFFLFNBQVMsR0FBRztZQUNwQzs7Ozs7V0FDQTs7OzttQkFDSjthQWpCSyxFQUFFOzs7O2lCQWlCUDtTQUViLENBQUM7UUFDQTs7OztnQkFDSjs7Ozs7O09BSVIsWUFBWSxTQUFTLElBQ2xCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQW1EO1VBRTdEOzs7O29CQUNKLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFvRDtVQUU5RDs7OztrQkFDRjs7Ozs7U0FDSjs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWCx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBakIsQ0FDSSx3QkFBQyxTQUFELFlBQ0ksd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQ7YUFDSSx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFLOzs7OzthQUMvQix3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFhOzs7OzthQUN2Qyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFXOzs7OzthQUNyQyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFTOzs7OzthQUNuQyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFROzs7OzthQUNsQyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBWTthQUFnQjs7Ozs7YUFDMUMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQXVCO2FBQVE7Ozs7O1lBQzdDOzs7OztvQkFDRDs7OztxQkFFUCx3QkFBQyxTQUFEO1lBQU8sV0FBVTt1QkFDWCxlQUFlLENBQUMsRUFBQyxDQUFFLEtBQUssR0FBRyxNQUN6Qix3QkFBQyxNQUFEO2FBRUksV0FBVTt1QkFGZDtjQUlJLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUNULElBQUk7Y0FDTDs7Ozs7Y0FFSix3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFBZCxDQUNJLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFDVixFQUFFLGtCQUFrQjtlQUNwQjs7Ozt5QkFDTCx3QkFBQyxPQUFEO2dCQUFLLFdBQVU7MEJBQWYsQ0FBZ0UsYUFDbEQsRUFBRSxVQUNYOzs7Ozt1QkFDTDs7Ozs7O2NBRUosd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQWQ7Z0JBQ0ssRUFBRTtnQkFBYztnQkFBRSxFQUFFO2VBQ3JCOzs7Ozs7Y0FFSix3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFBZDtnQkFDSyxFQUFFO2dCQUFhO2dCQUFFLEVBQUU7ZUFDcEI7Ozs7OztjQUVKLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUNULEVBQUUsU0FBUyxPQUNSLHdCQUFDLFFBQUQ7Z0JBQ0ksV0FBVyxnREFDUCxFQUFFLFNBQVMsS0FDTCxrSUFDQTswQkFKZCxDQU9LLEVBQUUsT0FBTSxHQUNQOzs7OzswQkFFTix3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQTZDO2VBRXZEOzs7OztjQUVWOzs7OztjQUVKLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUNULEVBQUUsY0FDRyxJQUFJLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxtQkFBbUIsU0FBUztnQkFDaEQsS0FBSztnQkFDTCxPQUFPO2dCQUNQLE1BQU07ZUFDVixDQUFDLElBQ0Q7Y0FDTjs7Ozs7Y0FFSix3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFDVix3QkFBQyxVQUFEO2dCQUNJLGVBQWUsc0JBQXNCLENBQUM7Z0JBQ3RDLFdBQVU7MEJBRmQsQ0FJSSx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OzBCQUFDLGlCQUNiOzs7Ozs7Y0FDUjs7Ozs7YUFDSjtlQTVESyxFQUFFOzs7O21CQTREUCxDQUNQO1dBQ0U7Ozs7bUJBQ0o7Ozs7OztTQUNOOzs7O2lCQUNKOzs7OztrQkFHSixXQUNHLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNYLHdCQUFDLFVBQUQ7VUFDSSxTQUFTO1VBQ1QsVUFBVTtVQUNWLFdBQVU7b0JBRVQsY0FDRyxnREFDSSx3QkFBQyxTQUFEO1dBQVMsTUFBTTtXQUFJLFdBQVU7VUFBa0Q7Ozs7b0JBQUMscUJBRWxGOzs7O3FCQUVGLHNCQUFzQixZQUFZLE9BQU8sUUFBUSxjQUFjLFNBQVM7U0FFeEU7Ozs7O1FBQ1A7Ozs7Z0JBRVI7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUE0SztPQUV0TDs7Ozs7TUFHUjs7Ozs7O0lBQ0o7Ozs7OztHQUdKLHNCQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1gsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUVJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQWlFLHFCQUMzQyxtQkFBbUIsa0JBQWtCLFFBQ3ZEOzs7OztnQkFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUE4RDtRQUNoRCxtQkFBbUI7UUFBVztRQUFVLG1CQUFtQixTQUFTLE9BQU8sR0FBRyxtQkFBbUIsTUFBTSxLQUFLO09BQ3ZIOzs7OztjQUNGOzs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0ksd0JBQUMsVUFBRDtTQUNJLFNBQVM7U0FDVCxVQUFVLGdCQUFnQjtTQUMxQixXQUFVO1NBQ1YsT0FBTTttQkFFTix3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztRQUNwQjs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0ksU0FBUztTQUNULFVBQVUsZ0JBQWdCLFlBQVksU0FBUztTQUMvQyxXQUFVO1NBQ1YsT0FBTTttQkFFTix3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OztRQUNyQjs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0ksZUFBZSxzQkFBc0IsSUFBSTtTQUN6QyxXQUFVO21CQUVWLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O1FBQ1Y7Ozs7O09BQ1A7Ozs7O2NBQ0o7Ozs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBcUU7UUFBVTs7OztrQkFDNUYsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWI7VUFBaUYsbUJBQW1CO1VBQWM7VUFBRSxtQkFBbUI7U0FBa0I7Ozs7O2dCQUN4Sjs7Ozs7UUFDTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXFFO1FBQVE7Ozs7a0JBQzFGLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQWlGLG1CQUFtQjtVQUFhO1VBQUUsbUJBQW1CO1NBQXFCOzs7OztnQkFDMUo7Ozs7O1FBQ0wsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFxRTtRQUFPOzs7O2tCQUN6Rix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBbUUsbUJBQW1CLFNBQVMsT0FBTyxHQUFHLG1CQUFtQixNQUFNLEtBQUs7UUFBUzs7OztnQkFDNUo7Ozs7O09BQ0o7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2tCQUNULG9CQUFvQixXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUssR0FBRyxNQUFNO1FBQy9DLE1BQU0sU0FBUyxnQkFBZ0IsQ0FBQztRQUVoQyxPQUNJLHdCQUFDLE9BQUQ7U0FFSSxXQUFVO21CQUZkLENBSUksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUFvRCxJQUFJLEdBQUUsR0FBTzs7Ozs7cUJBQ2pFLHdCQUFDLHFCQUFEO1lBQXFCLFNBQVMsRUFBRTtZQUFVLFFBQVEsRUFBRTtZQUFnQixXQUFVO1dBQXdEOzs7O21CQUNySTs7Ozs7b0JBRUwsd0JBQUMsUUFBRDtXQUFNLFdBQVcsbUdBQW1HLE9BQU87cUJBQTNIO1lBQ0ssT0FBTztZQUFLO1lBQUUsT0FBTztXQUNwQjs7Ozs7a0JBQ0w7Ozs7O21CQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUQ7V0FBYzs7OztxQkFDL0Usd0JBQUMscUJBQUQ7WUFBcUIsU0FBUyxFQUFFLGNBQWMsRUFBRSxjQUFjO1lBQUssUUFBTztZQUFPLFdBQVU7V0FBZ0Q7Ozs7bUJBQzFJOzs7OztvQkFFSixFQUFFLGlCQUNDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWM7V0FBWTs7OztxQkFDMUMsd0JBQUMscUJBQUQ7WUFBcUIsU0FBUyxFQUFFO1lBQWUsUUFBTztZQUFPLFdBQVU7V0FBYTs7OzttQkFDbkY7Ozs7O2tCQUVSOzs7OztpQkFDSjtXQTNCSTs7OztlQTJCSjtPQUViLENBQUM7TUFDQTs7OztjQUNKOzs7OzthQUNKOzs7Ozs7R0FDSjs7Ozs7RUFFUjs7Ozs7O0FBRWI7Ozs7O0FBRUEsU0FBUyxpQkFBaUIsTUFBTTtDQUM1QixJQUFJLENBQUMsTUFBTSxPQUFPOztDQUdsQixNQUFNLFFBQVEsS0FBSyxNQUFNLG1CQUFtQjtDQUU1QyxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1YsTUFBTSxLQUFLLE1BQU0sU0FBUztHQUN2QixJQUFJLEtBQUssV0FBVyxLQUFLLEtBQUssS0FBSyxTQUFTLEtBQUssR0FBRztJQUNoRCxNQUFNLGVBQWUsS0FBSyxRQUFRLElBQUk7SUFDdEMsSUFBSSxPQUFPO0lBQ1gsSUFBSSxPQUFPO0lBQ1gsSUFBSSxpQkFBaUIsQ0FBQyxHQUFHO0tBQ3JCLE9BQU8sS0FBSyxNQUFNLEdBQUcsWUFBWSxDQUFDLENBQUMsS0FBSztLQUN4QyxPQUFPLEtBQUssTUFBTSxlQUFlLEdBQUcsQ0FBQyxDQUFDO0lBQzFDLE9BQU87S0FDSCxPQUFPLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztJQUMzQjtJQUNBLE9BQ0ksd0JBQUMsT0FBRDtLQUFnQixXQUFVO2VBQTFCLENBQ0ssUUFBUSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBd0Q7S0FBVTs7OztlQUMxRix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBMkIsd0JBQUMsUUFBRCxZQUFPLEtBQVc7Ozs7O0tBQU07Ozs7YUFDakU7T0FISzs7OztXQUdMO0dBRWI7R0FFQSxNQUFNLFFBQVEsS0FBSyxNQUFNLElBQUk7R0FDN0IsTUFBTSxXQUFXLENBQUM7R0FDbEIsSUFBSSxjQUFjLENBQUM7R0FDbkIsSUFBSSxpQkFBaUI7R0FFckIsTUFBTSxrQkFBa0I7SUFDcEIsSUFBSSxZQUFZLFNBQVMsR0FBRztLQUN4QixJQUFJLGdCQUFnQjtNQUNoQixTQUFTLEtBQ0wsd0JBQUMsTUFBRDtPQUFrQyxXQUFVO2lCQUN2QyxZQUFZLEtBQUssSUFBSSxNQUNsQix3QkFBQyxNQUFELFlBQWEsb0JBQW9CLEVBQUUsRUFBTSxHQUFoQzs7OztjQUFnQyxDQUM1QztNQUNELEdBSkssTUFBTSxTQUFTOzs7O2FBSXBCLENBQ1I7S0FDSixPQUFPO01BQ0gsU0FBUyxLQUNMLHdCQUFDLE1BQUQ7T0FBa0MsV0FBVTtpQkFDdkMsWUFBWSxLQUFLLElBQUksTUFDbEIsd0JBQUMsTUFBRCxZQUFhLG9CQUFvQixFQUFFLEVBQU0sR0FBaEM7Ozs7Y0FBZ0MsQ0FDNUM7TUFDRCxHQUpLLE1BQU0sU0FBUzs7OzthQUlwQixDQUNSO0tBQ0o7S0FDQSxjQUFjLENBQUM7SUFDbkI7R0FDSjtHQUVBLE1BQU0sU0FBUyxNQUFNLFNBQVM7SUFDMUIsTUFBTSxVQUFVLEtBQUssS0FBSztJQUUxQixJQUFJLENBQUMsU0FBUztLQUNWLFVBQVU7S0FDVjtJQUNKO0lBRUEsSUFBSSxRQUFRLFdBQVcsTUFBTSxHQUFHO0tBQzVCLFVBQVU7S0FDVixTQUFTLEtBQ0wsd0JBQUMsTUFBRDtNQUF1QixXQUFVO2dCQUM1QixvQkFBb0IsUUFBUSxNQUFNLENBQUMsQ0FBQztLQUNyQyxHQUZLLE1BQU07Ozs7WUFFWCxDQUNSO0tBQ0E7SUFDSjtJQUNBLElBQUksUUFBUSxXQUFXLEtBQUssR0FBRztLQUMzQixVQUFVO0tBQ1YsU0FBUyxLQUNMLHdCQUFDLE1BQUQ7TUFBdUIsV0FBVTtnQkFDNUIsb0JBQW9CLFFBQVEsTUFBTSxDQUFDLENBQUM7S0FDckMsR0FGSyxNQUFNOzs7O1lBRVgsQ0FDUjtLQUNBO0lBQ0o7SUFDQSxJQUFJLFFBQVEsV0FBVyxJQUFJLEdBQUc7S0FDMUIsVUFBVTtLQUNWLFNBQVMsS0FDTCx3QkFBQyxNQUFEO01BQXVCLFdBQVU7Z0JBQzVCLG9CQUFvQixRQUFRLE1BQU0sQ0FBQyxDQUFDO0tBQ3JDLEdBRkssTUFBTTs7OztZQUVYLENBQ1I7S0FDQTtJQUNKO0lBRUEsSUFBSSxXQUFXLEtBQUssT0FBTyxHQUFHO0tBQzFCLElBQUksZ0JBQWdCLFVBQVU7S0FDOUIsaUJBQWlCO0tBQ2pCLFlBQVksS0FBSyxRQUFRLFFBQVEsWUFBWSxFQUFFLENBQUM7S0FDaEQ7SUFDSjtJQUVBLElBQUksWUFBWSxLQUFLLE9BQU8sR0FBRztLQUMzQixJQUFJLENBQUMsa0JBQWtCLFlBQVksU0FBUyxHQUFHLFVBQVU7S0FDekQsaUJBQWlCO0tBQ2pCLFlBQVksS0FBSyxRQUFRLFFBQVEsYUFBYSxFQUFFLENBQUM7S0FDakQ7SUFDSjtJQUVBLFVBQVU7SUFDVixTQUFTLEtBQ0wsd0JBQUMsS0FBRDtLQUFxQixXQUFVO2VBQzFCLG9CQUFvQixPQUFPO0lBQzdCLEdBRkssS0FBSzs7OztXQUVWLENBQ1A7R0FDSixDQUFDO0dBRUQsVUFBVTtHQUVWLE9BQU8sd0JBQUMsT0FBRDtJQUFnQixXQUFVO2NBQWU7R0FBYyxHQUE3Qzs7OztVQUE2QztFQUNsRSxDQUFDO0NBQ0E7Ozs7O0FBRWI7QUFFQSxTQUFTLG9CQUFvQixNQUFNO0NBQy9CLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FFbEIsTUFBTSxhQUFhO0NBQ25CLE1BQU0sUUFBUSxLQUFLLE1BQU0sVUFBVTtDQUVuQyxPQUFPLE1BQU0sS0FBSyxNQUFNLE1BQU07RUFDMUIsSUFBSSxLQUFLLFdBQVcsSUFBSSxLQUFLLEtBQUssU0FBUyxJQUFJLEdBQUc7R0FDOUMsT0FBTyx3QkFBQyxVQUFEO0lBQWdCLFdBQVU7Y0FBNEMsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0dBQVUsR0FBbkY7Ozs7VUFBbUY7RUFDM0c7RUFDQSxJQUFJLEtBQUssV0FBVyxHQUFHLEtBQUssS0FBSyxTQUFTLEdBQUcsR0FBRztHQUM1QyxPQUFPLHdCQUFDLFFBQUQ7SUFBYyxXQUFVO2NBQTJILEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztHQUFRLEdBQWhLOzs7O1VBQWdLO0VBQ3RMO0VBQ0EsSUFBSSxLQUFLLFdBQVcsR0FBRyxLQUFLLEtBQUssU0FBUyxHQUFHLEdBQUc7R0FDNUMsT0FBTyx3QkFBQyxNQUFEO0lBQVksV0FBVTtjQUFVLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztHQUFNLEdBQTdDOzs7O1VBQTZDO0VBQ2pFO0VBQ0EsT0FBTztDQUNYLENBQUM7QUFDTCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJGb3JtQW5hbHl0aWNzUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2ssIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQge1xuICAgIEFycm93TGVmdCxcbiAgICBVc2VycyxcbiAgICBGaWxlVGV4dCxcbiAgICBBd2FyZCxcbiAgICBUcmVuZGluZ1VwLFxuICAgIEV5ZSxcbiAgICBYLFxuICAgIENoZWNrQ2lyY2xlMixcbiAgICBYQ2lyY2xlLFxuICAgIE1pbnVzQ2lyY2xlLFxuICAgIENoZXZyb25MZWZ0LFxuICAgIENoZXZyb25SaWdodCxcbiAgICBMb2FkZXIyLFxuICAgIEJhckNoYXJ0MyxcbiAgICBDaGVjayxcbiAgICBBbGVydENpcmNsZSxcbiAgICBEb3dubG9hZCxcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW1wb3J0IFNpZGViYXIgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9sYXlvdXQvU2lkZWJhcic7XG5pbXBvcnQge1xuICAgIGdldEZvcm1CeUlkLFxuICAgIGdldEZvcm1BbmFseXRpY3MsXG4gICAgZXhwb3J0Rm9ybVJlc3BvbnNlcyxcbiAgICBjbGVhclNlc3Npb25cbn0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyBnZXRHZW1pbmlBcGlLZXksIGFuYWx5emVGb3JtQW5hbHl0aWNzV2l0aEFJLCBBVkFJTEFCTEVfTU9ERUxTIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYWlTZXJ2aWNlJztcbmltcG9ydCBSaWNoQ29udGVudFJlbmRlcmVyIGZyb20gJy4uLy4uL3V0aWxzL1JpY2hDb250ZW50UmVuZGVyZXInO1xuXG5jb25zdCBQQUdFX1NJWkUgPSAyNTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRm9ybUFuYWx5dGljc1BhZ2UoKSB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gICAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2FuYWx5dGljcywgc2V0QW5hbHl0aWNzXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtyZXNwb25kZW50cywgc2V0UmVzcG9uZGVudHNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICAgIGNvbnN0IFtsb2FkaW5nTW9yZSwgc2V0TG9hZGluZ01vcmVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtwYWdlLCBzZXRQYWdlXSA9IHVzZVN0YXRlKDEpO1xuICAgIGNvbnN0IFtoYXNNb3JlLCBzZXRIYXNNb3JlXSA9IHVzZVN0YXRlKHRydWUpO1xuICAgIGNvbnN0IFt0b3RhbENvdW50LCBzZXRUb3RhbENvdW50XSA9IHVzZVN0YXRlKDApO1xuICAgIGNvbnN0IFtzZWxlY3RlZFJlc3BvbmRlbnQsIHNldFNlbGVjdGVkUmVzcG9uZGVudF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbZXhwb3J0aW5nRm9ybWF0LCBzZXRFeHBvcnRpbmdGb3JtYXRdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2V4cG9ydEVycm9yLCBzZXRFeHBvcnRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbaW5jbHVkZUFuc3dlcktleSwgc2V0SW5jbHVkZUFuc3dlcktleV0gPSB1c2VTdGF0ZSh0cnVlKTtcblxuICAgIC8vIEFJLTM6IEFJIEFuYWx5c2lzIHN0YXRlXG4gICAgY29uc3QgW2FpQW5hbHl6aW5nLCBzZXRBaUFuYWx5emluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2FpSW5zaWdodCwgc2V0QWlJbnNpZ2h0XSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbYWlFcnJvciwgc2V0QWlFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2FpTW9kZWwsIHNldEFpTW9kZWxdID0gdXNlU3RhdGUoKCkgPT4geyBjb25zdCBtID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2Zvcm11cF9zZWxlY3RlZF9tb2RlbF9jaGF0Jyk7IHJldHVybiBtICYmICFtLmluY2x1ZGVzKCctcHJvJykgJiYgQVZBSUxBQkxFX01PREVMUy5zb21lKG1vZGVsID0+IG1vZGVsLmlkID09PSBtKSA/IG0gOiAnZ2VtaW5pLTMuNi1mbGFzaCc7IH0pO1xuXG4gICAgY29uc3QgaGFuZGxlRXhwb3J0ID0gYXN5bmMgKGZvcm1hdCkgPT4ge1xuICAgICAgICBpZiAoIWlkIHx8IGV4cG9ydGluZ0Zvcm1hdCAhPT0gbnVsbCkgcmV0dXJuO1xuICAgICAgICBzZXRFeHBvcnRpbmdGb3JtYXQoZm9ybWF0KTtcbiAgICAgICAgc2V0RXhwb3J0RXJyb3IobnVsbCk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGV4cG9ydEZvcm1SZXNwb25zZXMoaWQsIGZvcm1hdCwgaW5jbHVkZUFuc3dlcktleSk7XG4gICAgICAgICAgICBpZiAoIXJlcy5vaykge1xuICAgICAgICAgICAgICAgIHNldEV4cG9ydEVycm9yKHJlcy5tZXNzYWdlIHx8IGBHYWdhbCBtZW5nZWtzcG9yIGRhdGEga2UgZm9ybWF0ICR7Zm9ybWF0LnRvVXBwZXJDYXNlKCl9YCk7XG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRFeHBvcnRFcnJvcihudWxsKSwgNDAwMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgc2V0RXhwb3J0RXJyb3IoYFRlcmphZGkga2VzYWxhaGFuIHNhYXQgbWVuZ2Vrc3BvciBkYXRhICR7Zm9ybWF0LnRvVXBwZXJDYXNlKCl9YCk7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEV4cG9ydEVycm9yKG51bGwpLCA0MDAwKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldEV4cG9ydGluZ0Zvcm1hdChudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBBSS0zOiBBbmFseXplIGFuYWx5dGljcyB3aXRoIEdlbWluaVxuICAgIGNvbnN0IGhhbmRsZUFpQW5hbHl6ZSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0QWlBbmFseXppbmcodHJ1ZSk7XG4gICAgICAgIHNldEFpSW5zaWdodCgnJyk7XG4gICAgICAgIHNldEFpRXJyb3IoJycpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBzdW1tYXJ5ID0gYFxuRm9ybXVsaXI6ICR7Zm9ybT8udGl0bGUgfHwgJ1RpZGFrIGRpa2V0YWh1aSd9XG5Ub3RhbCBSZXNwb25zOiAke2FuYWx5dGljcz8udG90YWxSZXNwb25zZXMgPz8gcmVzcG9uZGVudHMubGVuZ3RofVxuVG90YWwgU29hbDogJHthbmFseXRpY3M/LnRvdGFsUXVlc3Rpb25zID8/IDB9XG5Tb2FsIERpbmlsYWk6ICR7YW5hbHl0aWNzPy5zY29yYWJsZVF1ZXN0aW9ucyA/PyAwfVxuUmF0YS1yYXRhIFNrb3I6ICR7YW5hbHl0aWNzPy5hdmVyYWdlU2NvcmUgIT0gbnVsbCA/IGFuYWx5dGljcy5hdmVyYWdlU2NvcmUgKyAnJScgOiAnTi9BJ31cblxuRGlzdHJpYnVzaSBQcmVkaWthdDpcbi0gU2FuZ2F0IEJhaWsgKEEsIDkwLTEwMCUpOiAke2dyYWRlRGlzdHJpYnV0aW9uLkF9IHNpc3dhXG4tIEJhaWsgKEIsIDc1LTg5JSk6ICR7Z3JhZGVEaXN0cmlidXRpb24uQn0gc2lzd2Fcbi0gQ3VrdXAgKEMsIDYwLTc0JSk6ICR7Z3JhZGVEaXN0cmlidXRpb24uQ30gc2lzd2Fcbi0gS3VyYW5nIChELCA0MC01OSUpOiAke2dyYWRlRGlzdHJpYnV0aW9uLkR9IHNpc3dhXG4tIFBlcmx1IFJlbWlkaSAoRSwgPDQwJSk6ICR7Z3JhZGVEaXN0cmlidXRpb24uRX0gc2lzd2FcblxuS3JpdGVyaWEgS2VsdWx1c2FuICg+PSA3MCUpOlxuLSBMdWx1czogJHtwYXNzUmF0ZU1ldHJpY3MucGFzc2VkfSBzaXN3YSAoJHtwYXNzUmF0ZU1ldHJpY3MucGFzc1BlcmNlbnR9JSlcbi0gQmVsdW0gTHVsdXM6ICR7cGFzc1JhdGVNZXRyaWNzLmZhaWxlZH0gc2lzd2EgKCR7cGFzc1JhdGVNZXRyaWNzLmZhaWxQZXJjZW50fSUpXG5cbkFuYWxpc2lzIEFrdXJhc2kgU29hbCAoZGl1cnV0a2FuIGRhcmkgdGVyc3VsaXQpOlxuJHtxdWVzdGlvbkFjY3VyYWN5TWFwLnNsaWNlKDAsIDEwKS5tYXAocSA9PiBgLSBcIiR7KHEucXVlc3Rpb24gfHwgJycpLnJlcGxhY2UoLzxbXj5dKj4vZywgJycpLnN1YnN0cmluZygwLCA4MCl9XCI6IGFrdXJhc2kgJHtxLmFjY3VyYWN5fSUgKCR7cS5jb3JyZWN0Q291bnR9LyR7cS50b3RhbEF0dGVtcHRzfSlgKS5qb2luKCdcXG4nKX1cbmAudHJpbSgpO1xuXG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhbmFseXplRm9ybUFuYWx5dGljc1dpdGhBSSh7IHN1bW1hcnksIHNlbGVjdGVkTW9kZWw6IGFpTW9kZWwsIGN1c3RvbUFwaUtleTogZ2V0R2VtaW5pQXBpS2V5KCkgfSk7XG4gICAgICAgICAgICBpZiAoIXJlcy5vaykge1xuICAgICAgICAgICAgICAgIHNldEFpRXJyb3IocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbmdhbmFsaXNpcyBkYXRhIGt1aXMuJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZXRBaUluc2lnaHQocmVzLmRhdGEpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHNldEFpRXJyb3IoJ0dhZ2FsIG1lbmdhbmFsaXNpczogJyArIGVyci5tZXNzYWdlKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldEFpQW5hbHl6aW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBsb2FkID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcblxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBbZm9ybVJlcywgYW5hbHl0aWNzUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgICAgICAgZ2V0Rm9ybUJ5SWQoaWQpLFxuICAgICAgICAgICAgICAgICAgICBnZXRGb3JtQW5hbHl0aWNzKGlkLCAxLCBQQUdFX1NJWkUpXG4gICAgICAgICAgICAgICAgXSk7XG5cbiAgICAgICAgICAgICAgICBpZiAoZm9ybVJlcy5zdGF0dXMgPT09IDQwMSkge1xuICAgICAgICAgICAgICAgICAgICBjbGVhclNlc3Npb24oKTtcbiAgICAgICAgICAgICAgICAgICAgbmF2aWdhdGUoJy9sb2dpbicpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKGZvcm1SZXMub2spIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybShmb3JtUmVzLmRhdGEpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChhbmFseXRpY3NSZXMub2sgJiYgYW5hbHl0aWNzUmVzLmRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0QW5hbHl0aWNzKGFuYWx5dGljc1Jlcy5kYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbGlzdCA9IGFuYWx5dGljc1Jlcy5kYXRhLnJlc3BvbmRlbnRzIHx8IFtdO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0b3RhbCA9IGFuYWx5dGljc1Jlcy5kYXRhLnRvdGFsUmVzcG9uc2VzID8/IGxpc3QubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICBzZXRSZXNwb25kZW50cyhsaXN0KTtcbiAgICAgICAgICAgICAgICAgICAgc2V0VG90YWxDb3VudCh0b3RhbCk7XG4gICAgICAgICAgICAgICAgICAgIHNldEhhc01vcmUobGlzdC5sZW5ndGggPj0gUEFHRV9TSVpFKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBsb2FkIGFuYWx5dGljczonLCBlcnJvcik7XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGxvYWQoKTtcbiAgICB9LCBbaWQsIG5hdmlnYXRlXSk7XG5cbiAgICBjb25zdCBoYW5kbGVMb2FkTW9yZSA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKGxvYWRpbmdNb3JlIHx8ICFoYXNNb3JlKSByZXR1cm47XG4gICAgICAgIHNldExvYWRpbmdNb3JlKHRydWUpO1xuXG4gICAgICAgIGNvbnN0IG5leHRQYWdlID0gcGFnZSArIDE7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdldEZvcm1BbmFseXRpY3MoaWQsIG5leHRQYWdlLCBQQUdFX1NJWkUpO1xuICAgICAgICBzZXRMb2FkaW5nTW9yZShmYWxzZSk7XG5cbiAgICAgICAgaWYgKHJlcy5vayAmJiByZXMuZGF0YSkge1xuICAgICAgICAgICAgY29uc3QgbmV3TGlzdCA9IHJlcy5kYXRhLnJlc3BvbmRlbnRzIHx8IFtdO1xuICAgICAgICAgICAgaWYgKG5ld0xpc3QubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIHNldFJlc3BvbmRlbnRzKHByZXYgPT4gWy4uLnByZXYsIC4uLm5ld0xpc3RdKTtcbiAgICAgICAgICAgICAgICBzZXRQYWdlKG5leHRQYWdlKTtcbiAgICAgICAgICAgICAgICBzZXRIYXNNb3JlKG5ld0xpc3QubGVuZ3RoID49IFBBR0VfU0laRSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHNldEhhc01vcmUoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW2lkLCBwYWdlLCBsb2FkaW5nTW9yZSwgaGFzTW9yZV0pO1xuXG4gICAgLy8g4pSA4pSAIEFuYWx5dGljYWwgQ2FsY3VsYXRpb25zIGZvciBEaWFncmFtcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBjb25zdCBncmFkZURpc3RyaWJ1dGlvbiA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCBjb3VudHMgPSB7IEE6IDAsIEI6IDAsIEM6IDAsIEQ6IDAsIEU6IDAsIHRvdGFsOiAwIH07XG4gICAgICAgIChyZXNwb25kZW50cyB8fCBbXSkuZm9yRWFjaChyID0+IHtcbiAgICAgICAgICAgIGlmIChyLnNjb3JlID09IG51bGwpIHJldHVybjtcbiAgICAgICAgICAgIGNvdW50cy50b3RhbCsrO1xuICAgICAgICAgICAgaWYgKHIuc2NvcmUgPj0gOTApIGNvdW50cy5BKys7XG4gICAgICAgICAgICBlbHNlIGlmIChyLnNjb3JlID49IDc1KSBjb3VudHMuQisrO1xuICAgICAgICAgICAgZWxzZSBpZiAoci5zY29yZSA+PSA2MCkgY291bnRzLkMrKztcbiAgICAgICAgICAgIGVsc2UgaWYgKHIuc2NvcmUgPj0gNDApIGNvdW50cy5EKys7XG4gICAgICAgICAgICBlbHNlIGNvdW50cy5FKys7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gY291bnRzO1xuICAgIH0sIFtyZXNwb25kZW50c10pO1xuXG4gICAgY29uc3QgcGFzc1JhdGVNZXRyaWNzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGxldCBwYXNzZWQgPSAwO1xuICAgICAgICBsZXQgZmFpbGVkID0gMDtcbiAgICAgICAgKHJlc3BvbmRlbnRzIHx8IFtdKS5mb3JFYWNoKHIgPT4ge1xuICAgICAgICAgICAgaWYgKHIuc2NvcmUgPT0gbnVsbCkgcmV0dXJuO1xuICAgICAgICAgICAgaWYgKHIuc2NvcmUgPj0gNzApIHBhc3NlZCsrO1xuICAgICAgICAgICAgZWxzZSBmYWlsZWQrKztcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHRvdGFsID0gcGFzc2VkICsgZmFpbGVkO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcGFzc2VkLFxuICAgICAgICAgICAgZmFpbGVkLFxuICAgICAgICAgICAgdG90YWwsXG4gICAgICAgICAgICBwYXNzUGVyY2VudDogdG90YWwgPiAwID8gTWF0aC5yb3VuZCgocGFzc2VkIC8gdG90YWwpICogMTAwKSA6IDAsXG4gICAgICAgICAgICBmYWlsUGVyY2VudDogdG90YWwgPiAwID8gTWF0aC5yb3VuZCgoZmFpbGVkIC8gdG90YWwpICogMTAwKSA6IDAsXG4gICAgICAgIH07XG4gICAgfSwgW3Jlc3BvbmRlbnRzXSk7XG5cbiAgICBjb25zdCBxdWVzdGlvbkFjY3VyYWN5TWFwID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHFNYXAgPSB7fTtcbiAgICAgICAgKHJlc3BvbmRlbnRzIHx8IFtdKS5mb3JFYWNoKHIgPT4ge1xuICAgICAgICAgICAgKHIuYW5zd2VycyB8fCBbXSkuZm9yRWFjaChhID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIWEucXVlc3Rpb25JZCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGlmICghcU1hcFthLnF1ZXN0aW9uSWRdKSB7XG4gICAgICAgICAgICAgICAgICAgIHFNYXBbYS5xdWVzdGlvbklkXSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IGEucXVlc3Rpb25JZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiBhLnF1ZXN0aW9uIHx8IGBTb2FsICMke2EucXVlc3Rpb25JZH1gLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25Gb3JtYXQ6IGEucXVlc3Rpb25Gb3JtYXQgfHwgJ3RleHQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29ycmVjdENvdW50OiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxBdHRlbXB0czogMCxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGEuaXNDb3JyZWN0ICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgcU1hcFthLnF1ZXN0aW9uSWRdLnRvdGFsQXR0ZW1wdHMrKztcbiAgICAgICAgICAgICAgICAgICAgaWYgKGEuaXNDb3JyZWN0ID09PSB0cnVlKSBxTWFwW2EucXVlc3Rpb25JZF0uY29ycmVjdENvdW50Kys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBPYmplY3QudmFsdWVzKHFNYXApLm1hcChxID0+ICh7XG4gICAgICAgICAgICAuLi5xLFxuICAgICAgICAgICAgYWNjdXJhY3k6IHEudG90YWxBdHRlbXB0cyA+IDAgPyBNYXRoLnJvdW5kKChxLmNvcnJlY3RDb3VudCAvIHEudG90YWxBdHRlbXB0cykgKiAxMDApIDogMCxcbiAgICAgICAgfSkpLnNvcnQoKGEsIGIpID0+IGEuYWNjdXJhY3kgLSBiLmFjY3VyYWN5KTtcbiAgICB9LCBbcmVzcG9uZGVudHNdKTtcblxuICAgIGlmIChsb2FkaW5nKSB7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLXNjcmVlbiBiZy1bI0Y0RjhGN10gZGFyazpiZy1zbGF0ZS05NTBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTggaC04IGFuaW1hdGUtc3BpbiBteC1hdXRvIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPk1lbXVhdCBhbmFsaXNpcyBmb3JtdWxpci4uLjwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGN1cnJlbnRJbmRleCA9IHNlbGVjdGVkUmVzcG9uZGVudFxuICAgICAgICA/IHJlc3BvbmRlbnRzLmZpbmRJbmRleChyID0+IHIucmVzcG9uc2VJZCA9PT0gc2VsZWN0ZWRSZXNwb25kZW50LnJlc3BvbnNlSWQpXG4gICAgICAgIDogLTE7XG5cbiAgICBjb25zdCBnb1ByZXZpb3VzID0gKCkgPT4ge1xuICAgICAgICBpZiAoY3VycmVudEluZGV4ID4gMCkge1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWRSZXNwb25kZW50KHJlc3BvbmRlbnRzW2N1cnJlbnRJbmRleCAtIDFdKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBnb05leHQgPSAoKSA9PiB7XG4gICAgICAgIGlmIChjdXJyZW50SW5kZXggPCByZXNwb25kZW50cy5sZW5ndGggLSAxKSB7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZFJlc3BvbmRlbnQocmVzcG9uZGVudHNbY3VycmVudEluZGV4ICsgMV0pO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGdldEFuc3dlclN0YXR1cyA9IChhbnN3ZXIpID0+IHtcbiAgICAgICAgaWYgKGFuc3dlci5pc0NvcnJlY3QgPT09IHRydWUpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgbGFiZWw6ICdCZW5hcicsXG4gICAgICAgICAgICAgICAgaWNvbjogPENoZWNrQ2lyY2xlMiBzaXplPXsxNn0gLz4sXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lOiAndGV4dC1lbWVyYWxkLTYwMCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNjAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMCdcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoYW5zd2VyLmlzQ29ycmVjdCA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgbGFiZWw6ICdTYWxhaCcsXG4gICAgICAgICAgICAgICAgaWNvbjogPFhDaXJjbGUgc2l6ZT17MTZ9IC8+LFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogJ3RleHQtcmVkLTYwMCBiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTUwLzYwIGRhcms6dGV4dC1yZWQtNDAwIGJvcmRlci1yZWQtMjAwIGRhcms6Ym9yZGVyLXJlZC04MDAnXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGxhYmVsOiAnVGlkYWsgRGluaWxhaScsXG4gICAgICAgICAgICBpY29uOiA8TWludXNDaXJjbGUgc2l6ZT17MTZ9IC8+LFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAndGV4dC1zbGF0ZS01MDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgfTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctWyNGNEY4RjddIGRhcms6Ymctc2xhdGUtOTUwIGZvbnQtc2FucyBhbnRpYWxpYXNlZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICA8U2lkZWJhciAvPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGZsZXgtY29sIG1pbi13LTAgb3ZlcmZsb3cteS1hdXRvXCI+XG5cbiAgICAgICAgICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcHgtNiBweS00IGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9mb3Jtcy8ke2lkfS9yZXNwb25zZXNgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFycm93TGVmdCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm0/LnRpdGxlIHx8ICdGb3JtdWxpcid9IOKAlCBBbmFsaXNpcyAmIERpYWdyYW1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSaW5na2FzYW4gcGVyZm9ybWEgJiBhbmFsaXNpcyBoYXNpbCAoe3Jlc3BvbmRlbnRzLmxlbmd0aH0gLyB7dG90YWxDb3VudCB8fCByZXNwb25kZW50cy5sZW5ndGh9IHJlc3BvbmRlbiBkaW11YXQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiAzIEV4cG9ydCBCdXR0b25zICsgQUkgQW5hbHlzaXMgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTbWFydCBhbmFseXNpcyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBaUFuYWx5emV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2FpQW5hbHl6aW5nIHx8IHJlc3BvbmRlbnRzLmxlbmd0aCA9PT0gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhckNoYXJ0MyBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57YWlBbmFseXppbmcgPyAnTWVuZ2FuYWxpc2lzLi4uJyA6ICdBbmFsaXNpcyBQaW50YXInfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBhcmlhLWxhYmVsPVwiTW9kZWwgQW5hbGlzaXMgUGludGFyXCIgdmFsdWU9e2FpTW9kZWx9IG9uQ2hhbmdlPXtlID0+IHsgc2V0QWlNb2RlbChlLnRhcmdldC52YWx1ZSk7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdmb3JtdXBfc2VsZWN0ZWRfbW9kZWxfY2hhdCcsIGUudGFyZ2V0LnZhbHVlKTsgfX0gY2xhc3NOYW1lPVwibWF4LXctMzYgcHgtMiBweS0xLjUgdGV4dC1bMTFweF0gZm9udC1ib2xkIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7QVZBSUxBQkxFX01PREVMUy5tYXAobW9kZWwgPT4gPG9wdGlvbiBrZXk9e21vZGVsLmlkfSB2YWx1ZT17bW9kZWwuaWR9Pnttb2RlbC5uYW1lfTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHNlbGVjdC1ub25lIGN1cnNvci1wb2ludGVyIGZvbnQtbWVkaXVtIHB4LTIgcHktMSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtpbmNsdWRlQW5zd2VyS2V5fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRJbmNsdWRlQW5zd2VyS2V5KGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1pbmRpZ28tNjAwIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5LdW5jaSBKYXdhYmFuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUV4cG9ydCgneGxzeCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtleHBvcnRpbmdGb3JtYXQgIT09IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMzAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtNTAvNzAgZGFyazpiZy1lbWVyYWxkLTk1MC80MCBob3ZlcjpiZy1lbWVyYWxkLTEwMCBkYXJrOmhvdmVyOmJnLWVtZXJhbGQtOTAwLzUwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFeHBvcnQga2UgRXhjZWwgKC54bHN4KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERvd25sb2FkIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntleHBvcnRpbmdGb3JtYXQgPT09ICd4bHN4JyA/ICdNZW5ndW5kdWguLi4nIDogJ0V4cG9ydCBYTFNYJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUV4cG9ydCgnY3N2Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2V4cG9ydGluZ0Zvcm1hdCAhPT0gbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRXhwb3J0IGtlIENTViAoLmNzdilcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57ZXhwb3J0aW5nRm9ybWF0ID09PSAnY3N2JyA/ICdNZW5ndW5kdWguLi4nIDogJ0V4cG9ydCBDU1YnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRXhwb3J0KCdwZGYnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZXhwb3J0aW5nRm9ybWF0ICE9PSBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1yZWQtMzAwIGRhcms6Ym9yZGVyLXJlZC04MDAgdGV4dC1yZWQtNzAwIGRhcms6dGV4dC1yZWQtNDAwIGJnLXJlZC01MC83MCBkYXJrOmJnLXJlZC05NTAvNDAgaG92ZXI6YmctcmVkLTEwMCBkYXJrOmhvdmVyOmJnLXJlZC05MDAvNTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkV4cG9ydCBrZSBQREYgKC5wZGYpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2V4cG9ydGluZ0Zvcm1hdCA9PT0gJ3BkZicgPyAnTWVuZ3VuZHVoLi4uJyA6ICdFeHBvcnQgUERGJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7ZXhwb3J0RXJyb3IgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNjAgYm9yZGVyLWIgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTgwMCBweC02IHB5LTIuNSB0ZXh0LXhzIHRleHQtcmVkLTYwMCBkYXJrOnRleHQtcmVkLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2V4cG9ydEVycm9yfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBBSS0zOiBJbnNpZ2h0IHBhbmVsICovfVxuICAgICAgICAgICAgICAgIHsoYWlJbnNpZ2h0IHx8IGFpRXJyb3IpICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC02IG10LTQgcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItcHVycGxlLTIwMCBkYXJrOmJvcmRlci1wdXJwbGUtODAwIGJnLXB1cnBsZS01MC82MCBkYXJrOmJnLXB1cnBsZS05NTAvMzAgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1wdXJwbGUtNzAwIGRhcms6dGV4dC1wdXJwbGUtMzAwIGZvbnQtZXh0cmFib2xkIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhckNoYXJ0MyBzaXplPXsxNn0gLz4gQW5hbGlzaXMgUGludGFyIOKAlCBIYXNpbCBVamlhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0QWlJbnNpZ2h0KCcnKTsgc2V0QWlFcnJvcignJyk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTQwMCBob3Zlcjp0ZXh0LXB1cnBsZS02MDAgY3Vyc29yLXBvaW50ZXJcIj48WCBzaXplPXsxNn0gLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAge2FpRXJyb3IgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDBcIj57YWlFcnJvcn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlckFpTWFya2Rvd24oYWlJbnNpZ2h0KVxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IG1heC13LTV4bCBteC1hdXRvIHctZnVsbCBzcGFjZS15LTZcIj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogU1VNTUFSWSBDQVJEUyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdUb3RhbCBSZXNwb25zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGFuYWx5dGljcz8udG90YWxSZXNwb25zZXMgPz8gMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPFVzZXJzIHNpemU9ezE4fSAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICd0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ1RvdGFsIFNvYWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogYW5hbHl0aWNzPy50b3RhbFF1ZXN0aW9ucyA/PyAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8RmlsZVRleHQgc2l6ZT17MTh9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJ3RleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwIGJnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTk1MC82MCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdTb2FsIERpbmlsYWknLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogYW5hbHl0aWNzPy5zY29yYWJsZVF1ZXN0aW9ucyA/PyAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8QXdhcmQgc2l6ZT17MTh9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJ3RleHQtaW5kaWdvLTYwMCBkYXJrOnRleHQtaW5kaWdvLTQwMCBiZy1pbmRpZ28tNTAgZGFyazpiZy1pbmRpZ28tOTUwLzYwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ1JhdGEtcmF0YSBTa29yJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3M/LmF2ZXJhZ2VTY29yZSAhPSBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgJHthbmFseXRpY3MuYXZlcmFnZVNjb3JlfSVgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnTi9BJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPFRyZW5kaW5nVXAgc2l6ZT17MTh9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJ3RleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC82MCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCgoeyBsYWJlbCwgdmFsdWUsIGljb24sIGNvbG9yIH0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17bGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC14bCAke2NvbG9yfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ljb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiDilIDilIAgUklDSCBBTkFMWVRJQ0FMIERJQUdSQU1TIOKUgOKUgCAqL31cbiAgICAgICAgICAgICAgICAgICAge3Jlc3BvbmRlbnRzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRGlhZ3JhbSAxOiBTY29yZSBHcmFkZSBEaXN0cmlidXRpb24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC02IHNwYWNlLXktNCBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCYXJDaGFydDMgc2l6ZT17MTh9IGNsYXNzTmFtZT1cInRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPkRpYWdyYW0gRGlzdHJpYnVzaSBQcmVkaWthdCBTa29yPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj57Z3JhZGVEaXN0cmlidXRpb24udG90YWx9IFJlc3BvbmRlbiBEaW5pbGFpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGdyYWRlOiAnU2FuZ2F0IEJhaWsgKEEpJywgcmFuZ2U6ICc5MCAtIDEwMCUnLCBjb3VudDogZ3JhZGVEaXN0cmlidXRpb24uQSwgY29sb3I6ICdiZy1lbWVyYWxkLTUwMCcsIGJnOiAnYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzQwIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgZ3JhZGU6ICdCYWlrIChCKScsIHJhbmdlOiAnNzUgLSA4OSUnLCBjb3VudDogZ3JhZGVEaXN0cmlidXRpb24uQiwgY29sb3I6ICdiZy10ZWFsLTUwMCcsIGJnOiAnYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgZ3JhZGU6ICdDdWt1cCAoQyknLCByYW5nZTogJzYwIC0gNzQlJywgY291bnQ6IGdyYWRlRGlzdHJpYnV0aW9uLkMsIGNvbG9yOiAnYmctYmx1ZS01MDAnLCBiZzogJ2JnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTk1MC80MCB0ZXh0LWJsdWUtNzAwIGRhcms6dGV4dC1ibHVlLTMwMCcgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGdyYWRlOiAnS3VyYW5nIChEKScsIHJhbmdlOiAnNDAgLSA1OSUnLCBjb3VudDogZ3JhZGVEaXN0cmlidXRpb24uRCwgY29sb3I6ICdiZy1hbWJlci01MDAnLCBiZzogJ2JnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzQwIHRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci0zMDAnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBncmFkZTogJ1Blcmx1IFJlbWlkaSAoRSknLCByYW5nZTogJzwgNDAlJywgY291bnQ6IGdyYWRlRGlzdHJpYnV0aW9uLkUsIGNvbG9yOiAnYmctcmVkLTUwMCcsIGJnOiAnYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC80MCB0ZXh0LXJlZC03MDAgZGFyazp0ZXh0LXJlZC0zMDAnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcChpdGVtID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwY3QgPSBncmFkZURpc3RyaWJ1dGlvbi50b3RhbCA+IDAgPyBNYXRoLnJvdW5kKChpdGVtLmNvdW50IC8gZ3JhZGVEaXN0cmlidXRpb24udG90YWwpICogMTAwKSA6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0uZ3JhZGV9IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+e2l0ZW0uZ3JhZGV9IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbm9ybWFsXCI+KHtpdGVtLnJhbmdlfSk8L3NwYW4+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj57aXRlbS5jb3VudH0gKHtwY3R9JSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtMi41IGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BoLWZ1bGwgJHtpdGVtLmNvbG9yfSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgcm91bmRlZC1mdWxsYH0gc3R5bGU9e3sgd2lkdGg6IGAke3BjdH0lYCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRGlhZ3JhbSAyOiBQYXNzL0ZhaWwgUmF0ZSBTdGF0dXMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC02IHNwYWNlLXktNCBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBd2FyZCBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5EaWFncmFtIEtyaXRlcmlhIEtlbHVsdXNhbiAoJmdlOyA3MCUpPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5UaHJlc2hvbGQgNzAlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNSBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU2VnbWVudGVkIERvbnV0IC8gUHJvZ3Jlc3MgQmFyICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgZm9udC1leHRyYWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj7inJMgTHVsdXM6IHtwYXNzUmF0ZU1ldHJpY3MucGFzc2VkfSAoe3Bhc3NSYXRlTWV0cmljcy5wYXNzUGVyY2VudH0lKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGRhcms6dGV4dC1yZWQtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+4pyXIEJlbHVtIEx1bHVzOiB7cGFzc1JhdGVNZXRyaWNzLmZhaWxlZH0gKHtwYXNzUmF0ZU1ldHJpY3MuZmFpbFBlcmNlbnR9JSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC00IGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIGZsZXhcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMCBoLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwXCIgc3R5bGU9e3sgd2lkdGg6IGAke3Bhc3NSYXRlTWV0cmljcy5wYXNzUGVyY2VudH0lYCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC00MDAgaC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMFwiIHN0eWxlPXt7IHdpZHRoOiBgJHtwYXNzUmF0ZU1ldHJpY3MuZmFpbFBlcmNlbnR9JWAgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLWVtZXJhbGQtNTAvNzAgZGFyazpiZy1lbWVyYWxkLTk1MC80MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMTAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtOTAwLzUwIHJvdW5kZWQteGwgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5SZXNwb25kZW4gTHVsdXM8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDBcIj57cGFzc1JhdGVNZXRyaWNzLnBhc3NlZH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctcmVkLTUwLzcwIGRhcms6YmctcmVkLTk1MC80MCBib3JkZXIgYm9yZGVyLXJlZC0xMDAgZGFyazpib3JkZXItcmVkLTkwMC81MCByb3VuZGVkLXhsIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtcmVkLTUwMCBkYXJrOnRleHQtcmVkLTQwMFwiPlBlcmx1IFBlbmdheWFhbjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC0zMDBcIj57cGFzc1JhdGVNZXRyaWNzLmZhaWxlZH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBEaWFncmFtIDM6IFF1ZXN0aW9uIEFjY3VyYWN5ICYgRGlmZmljdWx0eSBCcmVha2Rvd24gKi99XG4gICAgICAgICAgICAgICAgICAgIHtxdWVzdGlvbkFjY3VyYWN5TWFwLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC02IHNwYWNlLXktNCBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwYi0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmVuZGluZ1VwIHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgZGFyazp0ZXh0LWluZGlnby00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPkFuYWxpc2lzIFRpbmdrYXQgS2VzdWthcmFuICYgQWt1cmFzaSBQZXIgU29hbDwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPkRpdXJ1dGthbiBkYXJpIFNvYWwgVGVyc3VsaXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KHF1ZXN0aW9uQWNjdXJhY3lNYXAgfHwgW10pLm1hcCgocSwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0hhcmRlc3QgPSBpZHggPT09IDAgJiYgcS5hY2N1cmFjeSA8IDYwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNFYXNpZXN0ID0gaWR4ID09PSAocXVlc3Rpb25BY2N1cmFjeU1hcCB8fCBbXSkubGVuZ3RoIC0gMSAmJiBxLmFjY3VyYWN5ID4gODA7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3EucXVlc3Rpb25JZH0gY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzUwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNzAgZGFyazpib3JkZXItc2xhdGUtNzAwLzYwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXtxLnF1ZXN0aW9ufSBmb3JtYXQ9e3EucXVlc3Rpb25Gb3JtYXR9IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNIYXJkZXN0ICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtZXh0cmFib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1yZWQtMTAwIHRleHQtcmVkLTYwMCBkYXJrOmJnLXJlZC05NTAgZGFyazp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIHNocmluay0wXCI+4pqg77iPIFNvYWwgVGVyc3VsaXQ8L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0Vhc2llc3QgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC02MDAgZGFyazpiZy1lbWVyYWxkLTk1MCBkYXJrOnRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCBzaHJpbmstMFwiPuKtkCBTb2FsIFRlcm11ZGFoPC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFrdXJhc2kge3EuYWNjdXJhY3l9JSAoe3EuY29ycmVjdENvdW50fS97cS50b3RhbEF0dGVtcHRzfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtMiBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS03MDAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgcm91bmRlZC1mdWxsICR7cS5hY2N1cmFjeSA+PSA3NSA/ICdiZy1lbWVyYWxkLTUwMCcgOiBxLmFjY3VyYWN5ID49IDUwID8gJ2JnLWFtYmVyLTUwMCcgOiAnYmctcmVkLTUwMCd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7cS5hY2N1cmFjeX0lYCB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBSRVNQT05ERU5UUyBUQUJMRSAqL31cbiAgICAgICAgICAgICAgICAgICAge3Jlc3BvbmRlbnRzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIG92ZXJmbG93LWhpZGRlbiBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmluY2lhbiBSZXNwb25kZW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgS2xpayBSZXZpZXcgSmF3YWJhbiB1bnR1ayBtZWxpaGF0IGphd2FiYW4gbGVuZ2thcC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gdy1mdWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtc20gdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgdGV4dC1bMTFweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+IzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+UmVzcG9uZGVuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5EaWphd2FiPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5CZW5hcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+U2tvcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+V2FrdHUgU3VibWl0PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1yaWdodFwiPkFrc2k8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCBkYXJrOmRpdmlkZS1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhyZXNwb25kZW50cyB8fCBbXSkubWFwKChyLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3IucmVzcG9uc2VJZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpICsgMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3IucmVzcG9uZGVudE5hbWUgfHwgJ0Fub25pbSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlc3BvbnMgI3tyLnJlc3BvbnNlSWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ci5hbnN3ZXJlZENvdW50fS97ci50b3RhbFF1ZXN0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3IuY29ycmVjdENvdW50fS97ci5zY29yYWJsZVF1ZXN0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyLnNjb3JlICE9IG51bGwgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQteHMgZm9udC1ib2xkIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHIuc2NvcmUgPj0gNzBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctcmVkLTUwIHRleHQtcmVkLTYwMCBkYXJrOmJnLXJlZC05NTAvNjAgZGFyazp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIGRhcms6Ym9yZGVyLXJlZC04MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Iuc2NvcmV9JVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTi9BXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Iuc3VibWl0dGVkQXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUoci5zdWJtaXR0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdpZC1JRCcsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogJzItZGlnaXQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGg6ICdzaG9ydCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB5ZWFyOiAnbnVtZXJpYydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJy0nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFJlc3BvbmRlbnQocil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLXhsIGJnLVsjMDA4OTdCXSBob3ZlcjpiZy1bIzAwNzk2Ql0gdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIHNpemU9ezEzfSAvPiBSZXZpZXcgSmF3YWJhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIExvYWQgTW9yZSBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2hhc01vcmUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB0LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMb2FkTW9yZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ01vcmV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgbXgtYXV0byBkaXNhYmxlZDpvcGFjaXR5LTYwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZ01vcmUgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsxNH0gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNZW11YXQgcmVzcG9uZGVuLi4uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBNdWF0IExlYmloIEJhbnlhayAoJHtyZXNwb25kZW50cy5sZW5ndGh9IGRhcmkgJHt0b3RhbENvdW50IHx8ICdiYW55YWsnfSlgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTEyIHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBmb250LW1lZGl1bSBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBCZWx1bSBhZGEgcmVzcG9ucyB5YW5nIG1hc3VrIHVudHVrIGZvcm11bGlyIGluaS5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFJlc3BvbmRlbnQgRGV0YWlsIE1vZGFsICovfVxuICAgICAgICAgICAge3NlbGVjdGVkUmVzcG9uZGVudCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgYmctYmxhY2svNDAgYmFja2Ryb3AtYmx1ci1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBzaGFkb3cteGwgdy1mdWxsIG1heC13LTJ4bCBtYXgtaC1bODV2aF0gZmxleCBmbGV4LWNvbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZXRhaWwgUmVzcG9ucyDigJQge3NlbGVjdGVkUmVzcG9uZGVudC5yZXNwb25kZW50TmFtZSB8fCAnQW5vbmltJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVzcG9ucyAje3NlbGVjdGVkUmVzcG9uZGVudC5yZXNwb25zZUlkfSDigKIgU2tvcjoge3NlbGVjdGVkUmVzcG9uZGVudC5zY29yZSAhPSBudWxsID8gYCR7c2VsZWN0ZWRSZXNwb25kZW50LnNjb3JlfSVgIDogJ04vQSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Z29QcmV2aW91c31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50SW5kZXggPD0gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZGlzYWJsZWQ6b3BhY2l0eS0zMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlNlYmVsdW1ueWFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtnb05leHR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y3VycmVudEluZGV4ID49IHJlc3BvbmRlbnRzLmxlbmd0aCAtIDF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGRpc2FibGVkOm9wYWNpdHktMzAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJCZXJpa3V0bnlhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRSZXNwb25kZW50KG51bGwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDb250ZW50ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy15LWF1dG8gcC00IHNwYWNlLXktNCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgcC0zIHJvdW5kZWQteGwgdGV4dC1jZW50ZXIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtWzEwcHhdXCI+RGlqYXdhYjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgdGV4dC1zbSBtdC0wLjVcIj57c2VsZWN0ZWRSZXNwb25kZW50LmFuc3dlcmVkQ291bnR9L3tzZWxlY3RlZFJlc3BvbmRlbnQudG90YWxRdWVzdGlvbnN9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LVsxMHB4XVwiPkJlbmFyPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCB0ZXh0LXNtIG10LTAuNVwiPntzZWxlY3RlZFJlc3BvbmRlbnQuY29ycmVjdENvdW50fS97c2VsZWN0ZWRSZXNwb25kZW50LnNjb3JhYmxlUXVlc3Rpb25zfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgdGV4dC1bMTBweF1cIj5Ta29yPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwIHRleHQtc20gbXQtMC41XCI+e3NlbGVjdGVkUmVzcG9uZGVudC5zY29yZSAhPSBudWxsID8gYCR7c2VsZWN0ZWRSZXNwb25kZW50LnNjb3JlfSVgIDogJ04vQSd9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoc2VsZWN0ZWRSZXNwb25kZW50Py5hbnN3ZXJzIHx8IFtdKS5tYXAoKGEsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0YXR1cyA9IGdldEFuc3dlclN0YXR1cyhhKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgcm91bmRlZC14bCBwLTQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNjAgZGFyazpib3JkZXItc2xhdGUtNzAwLzYwIHNwYWNlLXktMlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHRleHQteHNcIj57aSArIDF9Ljwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXthLnF1ZXN0aW9ufSBmb3JtYXQ9e2EucXVlc3Rpb25Gb3JtYXR9IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxMHB4XSBmb250LWJvbGQgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgYm9yZGVyIHNocmluay0wICR7c3RhdHVzLmNsYXNzTmFtZX1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzLmljb259IHtzdGF0dXMubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtNCBzcGFjZS15LTEgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bVwiPkphd2FiYW46PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e2Eub3B0aW9uVGV4dCB8fCBhLmFuc3dlclRleHQgfHwgJ+KAlCd9IGZvcm1hdD1cInRleHRcIiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2EuY29ycmVjdEFuc3dlciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+S3VuY2k6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXthLmNvcnJlY3RBbnN3ZXJ9IGZvcm1hdD1cInRleHRcIiBjbGFzc05hbWU9XCJmb250LWJvbGRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFpTWFya2Rvd24odGV4dCkge1xuICAgIGlmICghdGV4dCkgcmV0dXJuIG51bGw7XG5cbiAgICAvLyBTcGxpdCBieSBjb2RlIGJsb2NrcyBmaXJzdFxuICAgIGNvbnN0IHBhcnRzID0gdGV4dC5zcGxpdCgvKGBgYFtcXHNcXFNdKj9gYGApL2cpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIuNSB0ZXh0LXhzIHNtOnRleHQtc20gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgIHtwYXJ0cy5tYXAoKHBhcnQsIHBJZHgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocGFydC5zdGFydHNXaXRoKCdgYGAnKSAmJiBwYXJ0LmVuZHNXaXRoKCdgYGAnKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaXJzdE5ld2xpbmUgPSBwYXJ0LmluZGV4T2YoJ1xcbicpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgbGFuZyA9ICcnO1xuICAgICAgICAgICAgICAgICAgICBsZXQgY29kZSA9ICcnO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3ROZXdsaW5lICE9PSAtMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGFuZyA9IHBhcnQuc2xpY2UoMywgZmlyc3ROZXdsaW5lKS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2RlID0gcGFydC5zbGljZShmaXJzdE5ld2xpbmUgKyAxLCAtMyk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2RlID0gcGFydC5zbGljZSgzLCAtMyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtwSWR4fSBjbGFzc05hbWU9XCJteS0yIHAtMyBiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0xMDAgcm91bmRlZC14bCBmb250LW1vbm8gdGV4dC14cyBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGFuZyAmJiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtcHVycGxlLTQwMCBmb250LWJvbGQgbWItMSB1cHBlcmNhc2VcIj57bGFuZ308L2Rpdj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLXByZSBmb250LW1vbm9cIj48Y29kZT57Y29kZX08L2NvZGU+PC9wcmU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBjb25zdCBsaW5lcyA9IHBhcnQuc3BsaXQoJ1xcbicpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVsZW1lbnRzID0gW107XG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRMaXN0ID0gW107XG4gICAgICAgICAgICAgICAgbGV0IGlzTnVtYmVyZWRMaXN0ID0gZmFsc2U7XG5cbiAgICAgICAgICAgICAgICBjb25zdCBmbHVzaExpc3QgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyZW50TGlzdC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNOdW1iZXJlZExpc3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50cy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b2wga2V5PXtgb2wtJHtlbGVtZW50cy5sZW5ndGh9YH0gY2xhc3NOYW1lPVwibGlzdC1kZWNpbWFsIGxpc3QtaW5zaWRlIHNwYWNlLXktMSBteS0xLjUgbWwtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRMaXN0Lm1hcCgobGksIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtpfT57cGFyc2VJbmxpbmVNYXJrZG93bihsaSl9PC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29sPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnRzLnB1c2goXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx1bCBrZXk9e2B1bC0ke2VsZW1lbnRzLmxlbmd0aH1gfSBjbGFzc05hbWU9XCJsaXN0LWRpc2MgbGlzdC1pbnNpZGUgc3BhY2UteS0xIG15LTEuNSBtbC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudExpc3QubWFwKChsaSwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l9PntwYXJzZUlubGluZU1hcmtkb3duKGxpKX08L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRMaXN0ID0gW107XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgbGluZXMuZm9yRWFjaCgobGluZSwgbElkeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0cmltbWVkID0gbGluZS50cmltKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0cmltbWVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmbHVzaExpc3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmICh0cmltbWVkLnN0YXJ0c1dpdGgoJyMjIyAnKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmx1c2hMaXN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50cy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBrZXk9e2BoNC0ke2xJZHh9YH0gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSBzbTp0ZXh0LWJhc2UgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIG10LTMgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGFyc2VJbmxpbmVNYXJrZG93bih0cmltbWVkLnNsaWNlKDQpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodHJpbW1lZC5zdGFydHNXaXRoKCcjIyAnKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmx1c2hMaXN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50cy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBrZXk9e2BoMy0ke2xJZHh9YH0gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1iYXNlIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBtdC00IG1iLTEuNSBwYi0xIGJvcmRlci1iIGJvcmRlci1wdXJwbGUtMjAwLzUwIGRhcms6Ym9yZGVyLXB1cnBsZS04MDAvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BhcnNlSW5saW5lTWFya2Rvd24odHJpbW1lZC5zbGljZSgzKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHRyaW1tZWQuc3RhcnRzV2l0aCgnIyAnKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmx1c2hMaXN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50cy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBrZXk9e2BoMi0ke2xJZHh9YH0gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbXQtNCBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXJzZUlubGluZU1hcmtkb3duKHRyaW1tZWQuc2xpY2UoMikpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKC9eWy0qXVxccysvLnRlc3QodHJpbW1lZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc051bWJlcmVkTGlzdCkgZmx1c2hMaXN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc051bWJlcmVkTGlzdCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudExpc3QucHVzaCh0cmltbWVkLnJlcGxhY2UoL15bLSpdXFxzKy8sICcnKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAoL15cXGQrXFwuXFxzKy8udGVzdCh0cmltbWVkKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpc051bWJlcmVkTGlzdCAmJiBjdXJyZW50TGlzdC5sZW5ndGggPiAwKSBmbHVzaExpc3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTnVtYmVyZWRMaXN0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRMaXN0LnB1c2godHJpbW1lZC5yZXBsYWNlKC9eXFxkK1xcLlxccysvLCAnJykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgZmx1c2hMaXN0KCk7XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnRzLnB1c2goXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBrZXk9e2BwLSR7bElkeH1gfSBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGFyc2VJbmxpbmVNYXJrZG93bih0cmltbWVkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIGZsdXNoTGlzdCgpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIDxkaXYga2V5PXtwSWR4fSBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPntlbGVtZW50c308L2Rpdj47XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cblxuZnVuY3Rpb24gcGFyc2VJbmxpbmVNYXJrZG93bih0ZXh0KSB7XG4gICAgaWYgKCF0ZXh0KSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHRva2VuUmVnZXggPSAvKFxcKlxcKi4qP1xcKlxcKnxgLio/YHxcXCouKj9cXCopL2c7XG4gICAgY29uc3QgcGFydHMgPSB0ZXh0LnNwbGl0KHRva2VuUmVnZXgpO1xuXG4gICAgcmV0dXJuIHBhcnRzLm1hcCgocGFydCwgaSkgPT4ge1xuICAgICAgICBpZiAocGFydC5zdGFydHNXaXRoKCcqKicpICYmIHBhcnQuZW5kc1dpdGgoJyoqJykpIHtcbiAgICAgICAgICAgIHJldHVybiA8c3Ryb25nIGtleT17aX0gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPntwYXJ0LnNsaWNlKDIsIC0yKX08L3N0cm9uZz47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBhcnQuc3RhcnRzV2l0aCgnYCcpICYmIHBhcnQuZW5kc1dpdGgoJ2AnKSkge1xuICAgICAgICAgICAgcmV0dXJuIDxjb2RlIGtleT17aX0gY2xhc3NOYW1lPVwicHgtMS41IHB5LTAuNSByb3VuZGVkIGJnLXB1cnBsZS0xMDAvNzAgZGFyazpiZy1wdXJwbGUtOTAwLzQwIHRleHQtcHVycGxlLTgwMCBkYXJrOnRleHQtcHVycGxlLTMwMCBmb250LW1vbm8gdGV4dC1bMTFweF1cIj57cGFydC5zbGljZSgxLCAtMSl9PC9jb2RlPjtcbiAgICAgICAgfVxuICAgICAgICBpZiAocGFydC5zdGFydHNXaXRoKCcqJykgJiYgcGFydC5lbmRzV2l0aCgnKicpKSB7XG4gICAgICAgICAgICByZXR1cm4gPGVtIGtleT17aX0gY2xhc3NOYW1lPVwiaXRhbGljXCI+e3BhcnQuc2xpY2UoMSwgLTEpfTwvZW0+O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwYXJ0O1xuICAgIH0pO1xufVxuIl19