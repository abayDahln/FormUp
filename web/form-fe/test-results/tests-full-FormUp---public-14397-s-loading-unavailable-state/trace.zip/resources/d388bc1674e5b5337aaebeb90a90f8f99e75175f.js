import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/utils/RichContentRenderer.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { Copy, Check, Code as CodeIcon } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/utils/RichContentRenderer.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export default function RichContentRenderer({ content, className = "" }) {
	_s();
	const [, setKatexLoaded] = useState(() => typeof window !== "undefined" && Boolean(window.katex));
	useEffect(() => {
		if (typeof window !== "undefined" && window.katex) {
			return;
		}
		const loadCSS = (url) => {
			if (document.querySelector(`link[href="${url}"]`)) return;
			const link = document.createElement("link");
			link.rel = "stylesheet";
			link.href = url;
			document.head.appendChild(link);
		};
		const loadScript = (url) => {
			return new Promise((resolve, reject) => {
				if (document.querySelector(`script[src="${url}"]`)) {
					resolve();
					return;
				}
				const script = document.createElement("script");
				script.src = url;
				script.async = true;
				script.onload = resolve;
				script.onerror = reject;
				document.body.appendChild(script);
			});
		};
		loadCSS("https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css");
		loadScript("https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js").then(() => setKatexLoaded(true)).catch(() => setKatexLoaded(false));
	}, []);
	if (!content) return null;
	let rawStr = String(content);
	// Visual formula blocks may contain a bare LaTeX expression while a
	// question is being edited. Treat it as math so Dual View and published
	// previews render it instead of showing `\\frac`, `\\sqrt`, etc.
	if (!/[\$]/.test(rawStr) && (/\\(?:frac|sqrt|int|sum|prod|lim|alpha|beta|gamma|theta|pi|pm|infty|rightarrow|rightleftharpoons|begin)\b/.test(rawStr) || /[A-Za-z][_^]\{[^}]+\}/.test(rawStr))) {
		rawStr = `$${rawStr}$`;
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `rich-text-content leading-relaxed break-words break-all [overflow-wrap:anywhere] ${className}`,
		children: parseMixedContent(rawStr)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 9
	}, this);
}
_s(RichContentRenderer, "kcCrSd0rE2suU83utBJ1bj+T4iI=");
_c = RichContentRenderer;
// Keep only presentation HTML emitted by the editor. In particular, preserve
// alignment/color styles so saved WYSIWYG content remains visually identical,
// while dropping event handlers and unsafe embedded elements.
function sanitizeRichHtml(html) {
	return String(html || "").replace(/<\/?(script|style|iframe|object|embed)[^>]*>/gi, "").replace(/\s(?:on\w+)\s*=\s*["'][^"']*["']/gi, "").replace(/\sstyle\s*=\s*["']([^"']*)["']/gi, (_, style) => {
		const safe = style.split(";").map((rule) => rule.trim()).filter((rule) => /^(text-align|color|background-color|font-size|font-weight|font-style|text-decoration)\s*:/i.test(rule));
		return safe.length ? ` style="${safe.join(";")}"` : "";
	});
}
// Helper to remove excessive leading tabs/spaces and blank lines from code blocks
function dedentCode(str) {
	if (!str) return "";
	let text = str.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, "\"").replace(/&#39;/g, "'");
	const lines = text.split(/\r?\n/);
	// Remove leading empty lines
	while (lines.length > 0 && lines[0].trim() === "") lines.shift();
	// Remove trailing empty lines
	while (lines.length > 0 && lines[lines.length - 1].trim() === "") lines.pop();
	if (lines.length === 0) return "";
	// Calculate common minimum indentation across non-empty lines
	let minIndent = Infinity;
	lines.forEach((line) => {
		if (line.trim().length > 0) {
			const match = line.match(/^[\s\t]+/);
			const indent = match ? match[0].length : 0;
			if (indent < minIndent) minIndent = indent;
		}
	});
	if (minIndent !== Infinity && minIndent > 0) {
		return lines.map((line) => line.length >= minIndent ? line.slice(minIndent) : line).join("\n");
	}
	return lines.join("\n");
}
/**
* Universal Parser that breaks down text into Code Blocks, Math Blocks, Headers, Lists, Quotes, Tables, and Formatted Text
*/
function parseMixedContent(text) {
	if (!text) return null;
	// Combined regex for Code Blocks (both markdown ```...``` and HTML <pre><code>...</code></pre>)
	const codeBlockRegex = /<pre><code(?: class="language-([a-zA-Z0-9_#-]+)")?>([\s\S]*?)<\/code><\/pre>|```([a-zA-Z0-9_#-]*)[ \t\r\n]*([\s\S]*?)```/gi;
	const sections = [];
	let lastIndex = 0;
	let match;
	while ((match = codeBlockRegex.exec(text)) !== null) {
		if (match.index > lastIndex) {
			const beforeText = text.substring(lastIndex, match.index);
			if (beforeText) {
				sections.push({
					type: "markdown",
					content: beforeText
				});
			}
		}
		const isHtmlPre = match[0].startsWith("<pre");
		const lang = (isHtmlPre ? match[1] : match[3]) || "code";
		const rawCode = (isHtmlPre ? match[2] : match[4]) || "";
		const cleanCode = rawCode.replace(/<[^>]+>/g, "").trim();
		sections.push({
			type: "code",
			code: cleanCode,
			language: lang.trim().toLowerCase() || "code",
			key: `code_${match.index}`
		});
		lastIndex = match.index + match[0].length;
	}
	if (lastIndex < text.length) {
		const remaining = text.substring(lastIndex);
		if (remaining) {
			sections.push({
				type: "markdown",
				content: remaining
			});
		}
	}
	return sections.map((sec, secIdx) => {
		if (sec.type === "code") {
			return /* @__PURE__ */ _jsxDEV(CodeBlock, {
				code: sec.code,
				language: sec.language
			}, sec.key || `sec_code_${secIdx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 20
			}, this);
		}
		return renderMarkdownBlocks(sec.content, `sec_md_${secIdx}`);
	});
}
/**
* Parses block-level markdown (headers, blockquotes, lists, hr, paragraphs)
*/
function renderMarkdownBlocks(text, keyPrefix) {
	if (!text) return null;
	// WYSIWYG content is already valid HTML. Do not wrap block elements such
	// as <h1> or <div> in a generated <p>; that invalid nesting makes the
	// heading look correct in contentEditable but disappear in previews and
	// the runner. Render the sanitized block tree as-is.
	if (/<(?:h[1-6]|p|div|ul|ol|li|blockquote|pre|table|hr)\b/i.test(text)) {
		return /* @__PURE__ */ _jsxDEV("div", { dangerouslySetInnerHTML: { __html: sanitizeRichHtml(text) } }, `${keyPrefix}_rich_html`, false, {
			fileName: _jsxFileName,
			lineNumber: 173,
			columnNumber: 13
		}, this);
	}
	const lines = text.split(/\r?\n/);
	const blocks = [];
	let currentList = null;
	const flushList = (blockIdx) => {
		if (currentList) {
			if (currentList.type === "ul") {
				blocks.push(/* @__PURE__ */ _jsxDEV("ul", {
					className: "list-disc list-inside space-y-1 my-2 pl-2",
					children: currentList.items.map((item, iIdx) => /* @__PURE__ */ _jsxDEV("li", {
						className: "leading-relaxed",
						children: renderInlineMarkdownAndMath(item, `${keyPrefix}_li_${blockIdx}_${iIdx}`)
					}, iIdx, false, {
						fileName: _jsxFileName,
						lineNumber: 187,
						columnNumber: 29
					}, this))
				}, `${keyPrefix}_ul_${blockIdx}`, false, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 21
				}, this));
			} else {
				blocks.push(/* @__PURE__ */ _jsxDEV("ol", {
					className: "list-decimal list-inside space-y-1 my-2 pl-2",
					children: currentList.items.map((item, iIdx) => /* @__PURE__ */ _jsxDEV("li", {
						className: "leading-relaxed",
						children: renderInlineMarkdownAndMath(item, `${keyPrefix}_oli_${blockIdx}_${iIdx}`)
					}, iIdx, false, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 29
					}, this))
				}, `${keyPrefix}_ol_${blockIdx}`, false, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 21
				}, this));
			}
			currentList = null;
		}
	};
	lines.forEach((line, lIdx) => {
		const trimmed = line.trim();
		// Empty line
		if (!trimmed) {
			flushList(lIdx);
			blocks.push(/* @__PURE__ */ _jsxDEV("div", { className: "h-2" }, `${keyPrefix}_sp_${lIdx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 214,
				columnNumber: 25
			}, this));
			return;
		}
		// Horizontal Rule --- or ***
		if (/^(\*{3,}|-{3,}|_{3,})$/.test(trimmed)) {
			flushList(lIdx);
			blocks.push(/* @__PURE__ */ _jsxDEV("hr", { className: "my-3 border-slate-200 dark:border-slate-800" }, `${keyPrefix}_hr_${lIdx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 221,
				columnNumber: 25
			}, this));
			return;
		}
		// Headers: #, ##, ###, ####
		const headerMatch = trimmed.match(/^(#{1,6})\s+(.+)$/);
		if (headerMatch) {
			flushList(lIdx);
			const level = headerMatch[1].length;
			const title = headerMatch[2];
			const sizeClass = level === 1 ? "text-lg sm:text-xl font-extrabold my-3 text-slate-900 dark:text-white" : level === 2 ? "text-base sm:text-lg font-bold my-2.5 text-slate-900 dark:text-white" : level === 3 ? "text-sm sm:text-base font-bold my-2 text-slate-800 dark:text-slate-100" : "text-xs sm:text-sm font-bold my-1.5 text-slate-800 dark:text-slate-200";
			blocks.push(/* @__PURE__ */ _jsxDEV("div", {
				className: sizeClass,
				children: renderInlineMarkdownAndMath(title, `${keyPrefix}_ht_${lIdx}`)
			}, `${keyPrefix}_h_${lIdx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 238,
				columnNumber: 17
			}, this));
			return;
		}
		// Blockquote: > quote
		if (trimmed.startsWith(">")) {
			flushList(lIdx);
			const quoteContent = trimmed.replace(/^>\s*/, "");
			blocks.push(/* @__PURE__ */ _jsxDEV("blockquote", {
				className: "border-l-4 border-teal-500 pl-3 my-2 text-slate-600 dark:text-slate-300 italic bg-teal-50/40 dark:bg-teal-950/20 py-1 rounded-r-xl",
				children: renderInlineMarkdownAndMath(quoteContent, `${keyPrefix}_bqt_${lIdx}`)
			}, `${keyPrefix}_bq_${lIdx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 250,
				columnNumber: 17
			}, this));
			return;
		}
		// Unordered List item: * item or - item
		const ulMatch = line.match(/^[\s]*[-*+]\s+(.+)$/);
		if (ulMatch) {
			if (!currentList || currentList.type !== "ul") {
				flushList(lIdx);
				currentList = {
					type: "ul",
					items: []
				};
			}
			currentList.items.push(ulMatch[1]);
			return;
		}
		// Ordered List item: 1. item
		const olMatch = line.match(/^[\s]*\d+\.\s+(.+)$/);
		if (olMatch) {
			if (!currentList || currentList.type !== "ol") {
				flushList(lIdx);
				currentList = {
					type: "ol",
					items: []
				};
			}
			currentList.items.push(olMatch[1]);
			return;
		}
		// Regular Paragraph Line
		flushList(lIdx);
		blocks.push(/* @__PURE__ */ _jsxDEV("p", {
			className: "my-1 leading-relaxed",
			children: renderInlineMarkdownAndMath(line, `${keyPrefix}_pt_${lIdx}`)
		}, `${keyPrefix}_p_${lIdx}`, false, {
			fileName: _jsxFileName,
			lineNumber: 282,
			columnNumber: 13
		}, this));
	});
	flushList(lines.length);
	return blocks;
}
/**
* Parses inline formatting: **bold**, *italic*, `code`, math ($...$, $$...$$), links [text](url)
*/
function renderInlineMarkdownAndMath(text, keyPrefix) {
	if (!text) return null;
	// WYSIWYG fields store real HTML (for example <strong>...</strong> and
	// <i>...</i>). Keep those tags as markup in every renderer (builder
	// preview, runner and result) instead of treating them as visible text.
	// The editor only emits formatting tags; links/scripts are deliberately
	// excluded from this path.
	if (/<\/?(strong|b|em|i|u|s|strike|span|p|div|br|h[1-6]|ul|ol|li|blockquote|a|font|mark|small|sub|sup)(?:\s[^>]*)?>/i.test(text)) {
		// HTML from the WYSIWYG can wrap a KaTeX token in <p>...</p>.
		// Strip only the presentation tags here so the math tokenizer still
		// gets a chance to create MathBlock instead of showing raw $$ text.
		if (/[\$]/.test(text) || /\\(?:frac|sqrt|int|sum|begin)\b/.test(text)) {
			return renderInlineMarkdownAndMath(text.replace(/<[^>]+>/g, ""), keyPrefix);
		}
		return /* @__PURE__ */ _jsxDEV("span", { dangerouslySetInnerHTML: { __html: text.replace(/<[^>]+>/g, (tag) => sanitizeRichHtml(tag)) } }, `${keyPrefix}_html`, false, {
			fileName: _jsxFileName,
			lineNumber: 311,
			columnNumber: 13
		}, this);
	}
	// Split by Math ($$formula$$ or $formula$) and Inline Code (`code`)
	const tokenRegex = /(\$\$[\s\S]+?\$\$|\$[^$\n]+?\$|`[^`\n]+?`)/g;
	const parts = text.split(tokenRegex);
	return parts.map((part, idx) => {
		if (!part) return null;
		// Block Math $$...$$
		if (part.startsWith("$$") && part.endsWith("$$") && part.length > 4) {
			const formula = part.slice(2, -2).trim();
			return /* @__PURE__ */ _jsxDEV(MathBlock, {
				formula,
				block: true
			}, `${keyPrefix}_m_${idx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 331,
				columnNumber: 20
			}, this);
		}
		// Inline Math $...$
		if (part.startsWith("$") && part.endsWith("$") && part.length > 2) {
			const formula = part.slice(1, -1).trim();
			return /* @__PURE__ */ _jsxDEV(MathBlock, {
				formula,
				block: false
			}, `${keyPrefix}_m_${idx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 337,
				columnNumber: 20
			}, this);
		}
		// Inline Code `...`
		if (part.startsWith("`") && part.endsWith("`") && part.length > 2) {
			const inlineCode = part.slice(1, -1);
			return /* @__PURE__ */ _jsxDEV("code", {
				className: "inline-block px-1.5 py-0.5 mx-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-teal-600 dark:text-teal-400 font-mono text-[11px] font-bold border border-slate-200 dark:border-slate-700",
				children: inlineCode
			}, `${keyPrefix}_c_${idx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 344,
				columnNumber: 17
			}, this);
		}
		// Format Markdown Bold (**text**), Italic (*text*), and Links ([text](url))
		return /* @__PURE__ */ _jsxDEV("span", { children: parseInlineMarkdownStyles(part, `${keyPrefix}_s_${idx}`) }, `${keyPrefix}_t_${idx}`, false, {
			fileName: _jsxFileName,
			lineNumber: 354,
			columnNumber: 16
		}, this);
	});
}
function parseInlineMarkdownStyles(text, keyPrefix) {
	if (!text) return null;
	// Tokenize bold (**bold**), italic (*italic* or _italic_), and markdown links [text](url)
	const styleRegex = /(\*\*[^*]+\*\*|\*[^*]+\*|_[^_]+_|\[[^\]]+\]\([^)]+\))/g;
	const pieces = text.split(styleRegex);
	return pieces.map((piece, pIdx) => {
		if (!piece) return null;
		// **Bold**
		if (piece.startsWith("**") && piece.endsWith("**") && piece.length >= 4) {
			return /* @__PURE__ */ _jsxDEV("strong", {
				className: "font-extrabold text-slate-900 dark:text-white",
				children: piece.slice(2, -2)
			}, `${keyPrefix}_b_${pIdx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 371,
				columnNumber: 17
			}, this);
		}
		// *Italic* or _Italic_
		if (piece.startsWith("*") && piece.endsWith("*") && piece.length >= 2 || piece.startsWith("_") && piece.endsWith("_") && piece.length >= 2) {
			return /* @__PURE__ */ _jsxDEV("em", {
				className: "italic",
				children: piece.slice(1, -1)
			}, `${keyPrefix}_i_${pIdx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 381,
				columnNumber: 17
			}, this);
		}
		// Link [label](url)
		const linkMatch = piece.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
		if (linkMatch) {
			return /* @__PURE__ */ _jsxDEV("a", {
				href: linkMatch[2],
				target: "_blank",
				rel: "noreferrer",
				className: "text-teal-600 dark:text-teal-400 font-bold underline hover:text-teal-700 inline-flex items-center gap-0.5",
				children: linkMatch[1]
			}, `${keyPrefix}_l_${pIdx}`, false, {
				fileName: _jsxFileName,
				lineNumber: 391,
				columnNumber: 17
			}, this);
		}
		return piece;
	});
}
// ── Code Block Component ──────────────────────────────────────────────────────
export function CodeBlock({ code, language = "code" }) {
	_s2();
	const [copied, setCopied] = useState(false);
	const cleanCode = dedentCode(code);
	const handleCopy = (e) => {
		if (e) e.stopPropagation();
		navigator.clipboard.writeText(cleanCode);
		setCopied(true);
		setTimeout(() => setCopied(false), 2e3);
	};
	const lines = cleanCode.split("\n");
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "my-3 rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-md font-mono text-xs text-slate-100 text-left",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between px-4 py-2 bg-slate-950/90 border-b border-slate-800/80 text-slate-400 text-[11px] font-semibold",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV(CodeIcon, {
					size: 14,
					className: "text-teal-400"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 426,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "uppercase tracking-wider font-bold text-slate-300",
					children: language || "code"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 427,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 425,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: handleCopy,
				className: "flex items-center gap-1.5 px-2.5 py-1 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-lg transition-all cursor-pointer font-sans",
				title: "Salin Kode",
				children: [copied ? /* @__PURE__ */ _jsxDEV(Check, {
					size: 13,
					className: "text-teal-400"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 437,
					columnNumber: 31
				}, this) : /* @__PURE__ */ _jsxDEV(Copy, { size: 13 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 437,
					columnNumber: 79
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[11px] font-bold",
					children: copied ? "Tersalin!" : "Salin"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 438,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 431,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 424,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "p-4 max-h-96 overflow-y-auto overflow-x-auto leading-relaxed flex gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "select-none text-slate-600 text-right pr-2 border-r border-slate-800 font-mono text-xs",
				children: lines.map((_, i) => /* @__PURE__ */ _jsxDEV("div", { children: i + 1 }, i, false, {
					fileName: _jsxFileName,
					lineNumber: 446,
					columnNumber: 25
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 444,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("pre", {
				className: "flex-1 font-mono text-slate-200 font-normal whitespace-pre border-0 p-0 m-0 bg-transparent text-xs",
				children: /* @__PURE__ */ _jsxDEV("code", { children: cleanCode }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 450,
					columnNumber: 21
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 449,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 443,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 422,
		columnNumber: 9
	}, this);
}
_s2(CodeBlock, "NE86rL3vg4NVcTTWDavsT0hUBJs=");
_c2 = CodeBlock;
// ── Math / Formula Component ──────────────────────────────────────────────────
export function MathBlock({ formula, block = false }) {
	const html = renderKaTeXHtml(formula, block);
	if (block) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "my-3 p-3 bg-teal-50/60 dark:bg-teal-950/40 border border-teal-200/80 dark:border-teal-800/80 rounded-2xl text-center font-serif text-base text-slate-800 dark:text-slate-100 shadow-xs overflow-x-auto",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "inline-block px-3 py-1 tracking-wide",
				dangerouslySetInnerHTML: { __html: html }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 464,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 463,
			columnNumber: 13
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "inline-block px-1.5 py-0.5 bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 rounded font-serif text-sm text-slate-800 dark:text-slate-100 mx-0.5",
		dangerouslySetInnerHTML: { __html: html }
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 470,
		columnNumber: 9
	}, this);
}
_c3 = MathBlock;
function renderKaTeXHtml(formula, block = false) {
	if (!formula) return "";
	const trimmed = formula.trim();
	if (window.katex) {
		try {
			return window.katex.renderToString(trimmed, {
				displayMode: block,
				throwOnError: false
			});
		} catch (_e) {}
	}
	return formatLaTeXFallback(trimmed, block);
}
function formatLaTeXFallback(expr, _block) {
	if (!expr) return "";
	let html = expr;
	html = html.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, "<span class=\"inline-flex flex-col text-center align-middle mx-1 font-serif\"><span class=\"border-b border-slate-700 dark:border-slate-300 px-1 text-xs font-semibold\">$1</span><span class=\"px-1 text-xs font-semibold\">$2</span></span>");
	html = html.replace(/\\sqrt\{([^}]+)\}/g, "<span class=\"font-serif\">√<span class=\"border-t border-slate-700 dark:border-slate-300 px-0.5\">$1</span></span>");
	html = html.replace(/\\sqrt\s*([a-zA-Z0-9]+)/g, "√$1");
	html = html.replace(/\^{([^}]+)\}/g, "<sup>$1</sup>");
	html = html.replace(/\^([0-9a-zA-Z]+)/g, "<sup>$1</sup>");
	html = html.replace(/_{([^}]+)\}/g, "<sub>$1</sub>");
	html = html.replace(/_([0-9a-zA-Z]+)/g, "<sub>$1</sub>");
	const symbols = {
		"\\alpha": "α",
		"\\beta": "β",
		"\\gamma": "γ",
		"\\delta": "δ",
		"\\epsilon": "ε",
		"\\theta": "θ",
		"\\lambda": "λ",
		"\\mu": "μ",
		"\\pi": "π",
		"\\sigma": "σ",
		"\\sum": "∑",
		"\\int": "∫",
		"\\infty": "∞",
		"\\pm": "±",
		"\\times": "×",
		"\\div": "÷",
		"\\neq": "≠",
		"\\leq": "≤",
		"\\geq": "≥",
		"\\approx": "≈"
	};
	Object.entries(symbols).forEach(([k, v]) => {
		html = html.replaceAll(k, v);
	});
	return html;
}
var _c, _c2, _c3;
$RefreshReg$(_c, "RichContentRenderer");
$RefreshReg$(_c2, "CodeBlock");
$RefreshReg$(_c3, "MathBlock");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/utils/RichContentRenderer.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/utils/RichContentRenderer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/utils/RichContentRenderer.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/utils/RichContentRenderer.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLE1BQU0sT0FBTyxRQUFRLGdCQUFnQjs7OztBQUU5QyxlQUFlLFNBQVMsb0JBQW9CLEVBQUUsU0FBUyxZQUFZLE1BQU07O0NBQ3JFLE1BQU0sR0FBRyxrQkFBa0IsZUFBZSxPQUFPLFdBQVcsZUFBZSxRQUFRLE9BQU8sS0FBSyxDQUFDO0NBRWhHLGdCQUFnQjtFQUNaLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxPQUFPO0dBQy9DO0VBQ0o7RUFFQSxNQUFNLFdBQVcsUUFBUTtHQUNyQixJQUFJLFNBQVMsY0FBYyxjQUFjLElBQUksR0FBRyxHQUFHO0dBQ25ELE1BQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtHQUMxQyxLQUFLLE1BQU07R0FDWCxLQUFLLE9BQU87R0FDWixTQUFTLEtBQUssWUFBWSxJQUFJO0VBQ2xDO0VBRUEsTUFBTSxjQUFjLFFBQVE7R0FDeEIsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0lBQ3BDLElBQUksU0FBUyxjQUFjLGVBQWUsSUFBSSxHQUFHLEdBQUc7S0FDaEQsUUFBUTtLQUNSO0lBQ0o7SUFDQSxNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7SUFDOUMsT0FBTyxNQUFNO0lBQ2IsT0FBTyxRQUFRO0lBQ2YsT0FBTyxTQUFTO0lBQ2hCLE9BQU8sVUFBVTtJQUNqQixTQUFTLEtBQUssWUFBWSxNQUFNO0dBQ3BDLENBQUM7RUFDTDtFQUVBLFFBQVEsOERBQThEO0VBQ3RFLFdBQVcsNkRBQTZELENBQUMsQ0FDcEUsV0FBVyxlQUFlLElBQUksQ0FBQyxDQUFDLENBQ2hDLFlBQVksZUFBZSxLQUFLLENBQUM7Q0FDMUMsR0FBRyxDQUFDLENBQUM7Q0FFTCxJQUFJLENBQUMsU0FBUyxPQUFPO0NBRXJCLElBQUksU0FBUyxPQUFPLE9BQU87Ozs7Q0FJM0IsSUFBSSxDQUFDLE9BQU8sS0FBSyxNQUFNLE1BQU0sMkdBQTJHLEtBQUssTUFBTSxLQUFLLHdCQUF3QixLQUFLLE1BQU0sSUFBSTtFQUMzTCxTQUFTLElBQUksT0FBTztDQUN4QjtDQUVBLE9BQ0ksd0JBQUMsT0FBRDtFQUFLLFdBQVcsb0ZBQW9GO1lBQy9GLGtCQUFrQixNQUFNO0NBQ3hCOzs7OztBQUViOzs7Ozs7QUFLQSxTQUFTLGlCQUFpQixNQUFNO0NBQzVCLE9BQU8sT0FBTyxRQUFRLEVBQUUsQ0FBQyxDQUNwQixRQUFRLGtEQUFrRCxFQUFFLENBQUMsQ0FDN0QsUUFBUSxzQ0FBc0MsRUFBRSxDQUFDLENBQ2pELFFBQVEscUNBQXFDLEdBQUcsVUFBVTtFQUN2RCxNQUFNLE9BQU8sTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUksU0FBUSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBTyxTQUMxRCw2RkFBNkYsS0FBSyxJQUFJLENBQzFHO0VBQ0EsT0FBTyxLQUFLLFNBQVMsV0FBVyxLQUFLLEtBQUssR0FBRyxFQUFFLEtBQUs7Q0FDeEQsQ0FBQztBQUNUOztBQUdBLFNBQVMsV0FBVyxLQUFLO0NBQ3JCLElBQUksQ0FBQyxLQUFLLE9BQU87Q0FFakIsSUFBSSxPQUFPLElBQ04sUUFBUSxTQUFTLEdBQUcsQ0FBQyxDQUNyQixRQUFRLFNBQVMsR0FBRyxDQUFDLENBQ3JCLFFBQVEsVUFBVSxHQUFHLENBQUMsQ0FDdEIsUUFBUSxXQUFXLElBQUcsQ0FBQyxDQUN2QixRQUFRLFVBQVUsR0FBRztDQUUxQixNQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU87O0NBR2hDLE9BQU8sTUFBTSxTQUFTLEtBQUssTUFBTSxFQUFFLENBQUMsS0FBSyxNQUFNLElBQUksTUFBTSxNQUFNOztDQUUvRCxPQUFPLE1BQU0sU0FBUyxLQUFLLE1BQU0sTUFBTSxTQUFTLEVBQUUsQ0FBQyxLQUFLLE1BQU0sSUFBSSxNQUFNLElBQUk7Q0FFNUUsSUFBSSxNQUFNLFdBQVcsR0FBRyxPQUFPOztDQUcvQixJQUFJLFlBQVk7Q0FDaEIsTUFBTSxTQUFRLFNBQVE7RUFDbEIsSUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDLFNBQVMsR0FBRztHQUN4QixNQUFNLFFBQVEsS0FBSyxNQUFNLFVBQVU7R0FDbkMsTUFBTSxTQUFTLFFBQVEsTUFBTSxFQUFFLENBQUMsU0FBUztHQUN6QyxJQUFJLFNBQVMsV0FBVyxZQUFZO0VBQ3hDO0NBQ0osQ0FBQztDQUVELElBQUksY0FBYyxZQUFZLFlBQVksR0FBRztFQUN6QyxPQUFPLE1BQU0sS0FBSSxTQUFRLEtBQUssVUFBVSxZQUFZLEtBQUssTUFBTSxTQUFTLElBQUksSUFBSSxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQy9GO0NBRUEsT0FBTyxNQUFNLEtBQUssSUFBSTtBQUMxQjs7OztBQUtBLFNBQVMsa0JBQWtCLE1BQU07Q0FDN0IsSUFBSSxDQUFDLE1BQU0sT0FBTzs7Q0FHbEIsTUFBTSxpQkFBaUI7Q0FFdkIsTUFBTSxXQUFXLENBQUM7Q0FDbEIsSUFBSSxZQUFZO0NBQ2hCLElBQUk7Q0FFSixRQUFRLFFBQVEsZUFBZSxLQUFLLElBQUksT0FBTyxNQUFNO0VBQ2pELElBQUksTUFBTSxRQUFRLFdBQVc7R0FDekIsTUFBTSxhQUFhLEtBQUssVUFBVSxXQUFXLE1BQU0sS0FBSztHQUN4RCxJQUFJLFlBQVk7SUFDWixTQUFTLEtBQUs7S0FBRSxNQUFNO0tBQVksU0FBUztJQUFXLENBQUM7R0FDM0Q7RUFDSjtFQUVBLE1BQU0sWUFBWSxNQUFNLEVBQUUsQ0FBQyxXQUFXLE1BQU07RUFDNUMsTUFBTSxRQUFRLFlBQVksTUFBTSxLQUFLLE1BQU0sT0FBTztFQUNsRCxNQUFNLFdBQVcsWUFBWSxNQUFNLEtBQUssTUFBTSxPQUFPO0VBQ3JELE1BQU0sWUFBWSxRQUFRLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FBQyxLQUFLO0VBRXZELFNBQVMsS0FBSztHQUNWLE1BQU07R0FDTixNQUFNO0dBQ04sVUFBVSxLQUFLLEtBQUssQ0FBQyxDQUFDLFlBQVksS0FBSztHQUN2QyxLQUFLLFFBQVEsTUFBTTtFQUN2QixDQUFDO0VBRUQsWUFBWSxNQUFNLFFBQVEsTUFBTSxFQUFFLENBQUM7Q0FDdkM7Q0FFQSxJQUFJLFlBQVksS0FBSyxRQUFRO0VBQ3pCLE1BQU0sWUFBWSxLQUFLLFVBQVUsU0FBUztFQUMxQyxJQUFJLFdBQVc7R0FDWCxTQUFTLEtBQUs7SUFBRSxNQUFNO0lBQVksU0FBUztHQUFVLENBQUM7RUFDMUQ7Q0FDSjtDQUVBLE9BQU8sU0FBUyxLQUFLLEtBQUssV0FBVztFQUNqQyxJQUFJLElBQUksU0FBUyxRQUFRO0dBQ3JCLE9BQU8sd0JBQUMsV0FBRDtJQUFpRCxNQUFNLElBQUk7SUFBTSxVQUFVLElBQUk7R0FBVyxHQUExRSxJQUFJLE9BQU8sWUFBWTs7OztVQUFtRDtFQUNyRztFQUNBLE9BQU8scUJBQXFCLElBQUksU0FBUyxVQUFVLFFBQVE7Q0FDL0QsQ0FBQztBQUNMOzs7O0FBS0EsU0FBUyxxQkFBcUIsTUFBTSxXQUFXO0NBQzNDLElBQUksQ0FBQyxNQUFNLE9BQU87Ozs7O0NBTWxCLElBQUksd0RBQXdELEtBQUssSUFBSSxHQUFHO0VBQ3BFLE9BQ0ksd0JBQUMsT0FBRCxFQUFvQyx5QkFBeUIsRUFBRSxRQUFRLGlCQUFpQixJQUFJLEVBQUUsRUFBSSxHQUF4RixHQUFHLFVBQVU7Ozs7U0FBMkU7Q0FFMUc7Q0FFQSxNQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU87Q0FDaEMsTUFBTSxTQUFTLENBQUM7Q0FDaEIsSUFBSSxjQUFjO0NBRWxCLE1BQU0sYUFBYSxhQUFhO0VBQzVCLElBQUksYUFBYTtHQUNiLElBQUksWUFBWSxTQUFTLE1BQU07SUFDM0IsT0FBTyxLQUNILHdCQUFDLE1BQUQ7S0FBd0MsV0FBVTtlQUM3QyxZQUFZLE1BQU0sS0FBSyxNQUFNLFNBQzFCLHdCQUFDLE1BQUQ7TUFBZSxXQUFVO2dCQUNwQiw0QkFBNEIsTUFBTSxHQUFHLFVBQVUsTUFBTSxTQUFTLEdBQUcsTUFBTTtLQUN4RSxHQUZLOzs7O1lBRUwsQ0FDUDtJQUNELEdBTkssR0FBRyxVQUFVLE1BQU07Ozs7V0FNeEIsQ0FDUjtHQUNKLE9BQU87SUFDSCxPQUFPLEtBQ0gsd0JBQUMsTUFBRDtLQUF3QyxXQUFVO2VBQzdDLFlBQVksTUFBTSxLQUFLLE1BQU0sU0FDMUIsd0JBQUMsTUFBRDtNQUFlLFdBQVU7Z0JBQ3BCLDRCQUE0QixNQUFNLEdBQUcsVUFBVSxPQUFPLFNBQVMsR0FBRyxNQUFNO0tBQ3pFLEdBRks7Ozs7WUFFTCxDQUNQO0lBQ0QsR0FOSyxHQUFHLFVBQVUsTUFBTTs7OztXQU14QixDQUNSO0dBQ0o7R0FDQSxjQUFjO0VBQ2xCO0NBQ0o7Q0FFQSxNQUFNLFNBQVMsTUFBTSxTQUFTO0VBQzFCLE1BQU0sVUFBVSxLQUFLLEtBQUs7O0VBRzFCLElBQUksQ0FBQyxTQUFTO0dBQ1YsVUFBVSxJQUFJO0dBQ2QsT0FBTyxLQUFLLHdCQUFDLE9BQUQsRUFBcUMsV0FBVSxNQUFPLEdBQTVDLEdBQUcsVUFBVSxNQUFNOzs7O1VBQXlCLENBQUM7R0FDbkU7RUFDSjs7RUFHQSxJQUFJLHlCQUF5QixLQUFLLE9BQU8sR0FBRztHQUN4QyxVQUFVLElBQUk7R0FDZCxPQUFPLEtBQUssd0JBQUMsTUFBRCxFQUFvQyxXQUFVLDhDQUErQyxHQUFwRixHQUFHLFVBQVUsTUFBTTs7OztVQUFpRSxDQUFDO0dBQzFHO0VBQ0o7O0VBR0EsTUFBTSxjQUFjLFFBQVEsTUFBTSxtQkFBbUI7RUFDckQsSUFBSSxhQUFhO0dBQ2IsVUFBVSxJQUFJO0dBQ2QsTUFBTSxRQUFRLFlBQVksRUFBRSxDQUFDO0dBQzdCLE1BQU0sUUFBUSxZQUFZO0dBQzFCLE1BQU0sWUFDRixVQUFVLElBQUksMEVBQ2QsVUFBVSxJQUFJLHlFQUNkLFVBQVUsSUFBSSwyRUFDZDtHQUVKLE9BQU8sS0FDSCx3QkFBQyxPQUFEO0lBQW9DLFdBQVc7Y0FDMUMsNEJBQTRCLE9BQU8sR0FBRyxVQUFVLE1BQU0sTUFBTTtHQUM1RCxHQUZLLEdBQUcsVUFBVSxLQUFLOzs7O1VBRXZCLENBQ1Q7R0FDQTtFQUNKOztFQUdBLElBQUksUUFBUSxXQUFXLEdBQUcsR0FBRztHQUN6QixVQUFVLElBQUk7R0FDZCxNQUFNLGVBQWUsUUFBUSxRQUFRLFNBQVMsRUFBRTtHQUNoRCxPQUFPLEtBQ0gsd0JBQUMsY0FBRDtJQUE0QyxXQUFVO2NBQ2pELDRCQUE0QixjQUFjLEdBQUcsVUFBVSxPQUFPLE1BQU07R0FDN0QsR0FGSyxHQUFHLFVBQVUsTUFBTTs7OztVQUV4QixDQUNoQjtHQUNBO0VBQ0o7O0VBR0EsTUFBTSxVQUFVLEtBQUssTUFBTSxxQkFBcUI7RUFDaEQsSUFBSSxTQUFTO0dBQ1QsSUFBSSxDQUFDLGVBQWUsWUFBWSxTQUFTLE1BQU07SUFDM0MsVUFBVSxJQUFJO0lBQ2QsY0FBYztLQUFFLE1BQU07S0FBTSxPQUFPLENBQUM7SUFBRTtHQUMxQztHQUNBLFlBQVksTUFBTSxLQUFLLFFBQVEsRUFBRTtHQUNqQztFQUNKOztFQUdBLE1BQU0sVUFBVSxLQUFLLE1BQU0scUJBQXFCO0VBQ2hELElBQUksU0FBUztHQUNULElBQUksQ0FBQyxlQUFlLFlBQVksU0FBUyxNQUFNO0lBQzNDLFVBQVUsSUFBSTtJQUNkLGNBQWM7S0FBRSxNQUFNO0tBQU0sT0FBTyxDQUFDO0lBQUU7R0FDMUM7R0FDQSxZQUFZLE1BQU0sS0FBSyxRQUFRLEVBQUU7R0FDakM7RUFDSjs7RUFHQSxVQUFVLElBQUk7RUFDZCxPQUFPLEtBQ0gsd0JBQUMsS0FBRDtHQUFrQyxXQUFVO2FBQ3ZDLDRCQUE0QixNQUFNLEdBQUcsVUFBVSxNQUFNLE1BQU07RUFDN0QsR0FGSyxHQUFHLFVBQVUsS0FBSzs7OztTQUV2QixDQUNQO0NBQ0osQ0FBQztDQUVELFVBQVUsTUFBTSxNQUFNO0NBQ3RCLE9BQU87QUFDWDs7OztBQUtBLFNBQVMsNEJBQTRCLE1BQU0sV0FBVztDQUNsRCxJQUFJLENBQUMsTUFBTSxPQUFPOzs7Ozs7Q0FPbEIsSUFBSSxrSEFBa0gsS0FBSyxJQUFJLEdBQUc7Ozs7RUFJOUgsSUFBSSxPQUFPLEtBQUssSUFBSSxLQUFLLGtDQUFrQyxLQUFLLElBQUksR0FBRztHQUNuRSxPQUFPLDRCQUE0QixLQUFLLFFBQVEsWUFBWSxFQUFFLEdBQUcsU0FBUztFQUM5RTtFQUNBLE9BQ0ksd0JBQUMsUUFBRCxFQUVJLHlCQUF5QixFQUNyQixRQUFRLEtBQ0gsUUFBUSxhQUFhLFFBQVEsaUJBQWlCLEdBQUcsQ0FBQyxFQUMzRCxFQUNILEdBTFEsR0FBRyxVQUFVOzs7O1NBS3JCO0NBRVQ7O0NBR0EsTUFBTSxhQUFhO0NBQ25CLE1BQU0sUUFBUSxLQUFLLE1BQU0sVUFBVTtDQUVuQyxPQUFPLE1BQU0sS0FBSyxNQUFNLFFBQVE7RUFDNUIsSUFBSSxDQUFDLE1BQU0sT0FBTzs7RUFHbEIsSUFBSSxLQUFLLFdBQVcsSUFBSSxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssS0FBSyxTQUFTLEdBQUc7R0FDakUsTUFBTSxVQUFVLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztHQUN2QyxPQUFPLHdCQUFDLFdBQUQ7SUFBa0Q7SUFBUyxPQUFPO0dBQU8sR0FBekQsR0FBRyxVQUFVLEtBQUs7Ozs7VUFBdUM7RUFDcEY7O0VBR0EsSUFBSSxLQUFLLFdBQVcsR0FBRyxLQUFLLEtBQUssU0FBUyxHQUFHLEtBQUssS0FBSyxTQUFTLEdBQUc7R0FDL0QsTUFBTSxVQUFVLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztHQUN2QyxPQUFPLHdCQUFDLFdBQUQ7SUFBa0Q7SUFBUyxPQUFPO0dBQVEsR0FBMUQsR0FBRyxVQUFVLEtBQUs7Ozs7VUFBd0M7RUFDckY7O0VBR0EsSUFBSSxLQUFLLFdBQVcsR0FBRyxLQUFLLEtBQUssU0FBUyxHQUFHLEtBQUssS0FBSyxTQUFTLEdBQUc7R0FDL0QsTUFBTSxhQUFhLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztHQUNuQyxPQUNJLHdCQUFDLFFBQUQ7SUFFSSxXQUFVO2NBRVQ7R0FDQyxHQUpHLEdBQUcsVUFBVSxLQUFLOzs7O1VBSXJCO0VBRWQ7O0VBR0EsT0FBTyx3QkFBQyxRQUFELFlBQXFDLDBCQUEwQixNQUFNLEdBQUcsVUFBVSxLQUFLLEtBQUssRUFBUSxHQUF6RixHQUFHLFVBQVUsS0FBSzs7OztTQUF1RTtDQUMvRyxDQUFDO0FBQ0w7QUFFQSxTQUFTLDBCQUEwQixNQUFNLFdBQVc7Q0FDaEQsSUFBSSxDQUFDLE1BQU0sT0FBTzs7Q0FHbEIsTUFBTSxhQUFhO0NBQ25CLE1BQU0sU0FBUyxLQUFLLE1BQU0sVUFBVTtDQUVwQyxPQUFPLE9BQU8sS0FBSyxPQUFPLFNBQVM7RUFDL0IsSUFBSSxDQUFDLE9BQU8sT0FBTzs7RUFHbkIsSUFBSSxNQUFNLFdBQVcsSUFBSSxLQUFLLE1BQU0sU0FBUyxJQUFJLEtBQUssTUFBTSxVQUFVLEdBQUc7R0FDckUsT0FDSSx3QkFBQyxVQUFEO0lBQXVDLFdBQVU7Y0FDNUMsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0dBQ2QsR0FGSyxHQUFHLFVBQVUsS0FBSzs7OztVQUV2QjtFQUVoQjs7RUFHQSxJQUFLLE1BQU0sV0FBVyxHQUFHLEtBQUssTUFBTSxTQUFTLEdBQUcsS0FBSyxNQUFNLFVBQVUsS0FDaEUsTUFBTSxXQUFXLEdBQUcsS0FBSyxNQUFNLFNBQVMsR0FBRyxLQUFLLE1BQU0sVUFBVSxHQUFJO0dBQ3JFLE9BQ0ksd0JBQUMsTUFBRDtJQUFtQyxXQUFVO2NBQ3hDLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQztHQUNsQixHQUZLLEdBQUcsVUFBVSxLQUFLOzs7O1VBRXZCO0VBRVo7O0VBR0EsTUFBTSxZQUFZLE1BQU0sTUFBTSwyQkFBMkI7RUFDekQsSUFBSSxXQUFXO0dBQ1gsT0FDSSx3QkFBQyxLQUFEO0lBRUksTUFBTSxVQUFVO0lBQ2hCLFFBQU87SUFDUCxLQUFJO0lBQ0osV0FBVTtjQUVULFVBQVU7R0FDWixHQVBNLEdBQUcsVUFBVSxLQUFLOzs7O1VBT3hCO0VBRVg7RUFFQSxPQUFPO0NBQ1gsQ0FBQztBQUNMOztBQUdBLE9BQU8sU0FBUyxVQUFVLEVBQUUsTUFBTSxXQUFXLFVBQVU7O0NBQ25ELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLO0NBQzFDLE1BQU0sWUFBWSxXQUFXLElBQUk7Q0FFakMsTUFBTSxjQUFjLE1BQU07RUFDdEIsSUFBSSxHQUFHLEVBQUUsZ0JBQWdCO0VBQ3pCLFVBQVUsVUFBVSxVQUFVLFNBQVM7RUFDdkMsVUFBVSxJQUFJO0VBQ2QsaUJBQWlCLFVBQVUsS0FBSyxHQUFHLEdBQUk7Q0FDM0M7Q0FFQSxNQUFNLFFBQVEsVUFBVSxNQUFNLElBQUk7Q0FFbEMsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBRUksd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxVQUFEO0tBQVUsTUFBTTtLQUFJLFdBQVU7SUFBaUI7Ozs7Y0FDL0Msd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFDWCxZQUFZO0lBQ1g7Ozs7WUFDTDs7Ozs7YUFDTCx3QkFBQyxVQUFEO0lBQ0ksTUFBSztJQUNMLFNBQVM7SUFDVCxXQUFVO0lBQ1YsT0FBTTtjQUpWLENBTUssU0FBUyx3QkFBQyxPQUFEO0tBQU8sTUFBTTtLQUFJLFdBQVU7SUFBaUI7Ozs7ZUFBSSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2NBQzNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXlCLFNBQVMsY0FBYztJQUFjOzs7O1lBQzFFOzs7OztXQUNQOzs7OztZQUdMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNWLE1BQU0sS0FBSyxHQUFHLE1BQ1gsd0JBQUMsT0FBRCxZQUFjLElBQUksRUFBTyxHQUFmOzs7O1dBQWUsQ0FDNUI7R0FDQTs7OzthQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1gsd0JBQUMsUUFBRCxZQUFPLFVBQWdCOzs7OztHQUN0Qjs7OztXQUNKOzs7OztVQUNKOzs7Ozs7QUFFYjs7OztBQUdBLE9BQU8sU0FBUyxVQUFVLEVBQUUsU0FBUyxRQUFRLFNBQVM7Q0FDbEQsTUFBTSxPQUFPLGdCQUFnQixTQUFTLEtBQUs7Q0FFM0MsSUFBSSxPQUFPO0VBQ1AsT0FDSSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNYLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQXVDLHlCQUF5QixFQUFFLFFBQVEsS0FBSztHQUFJOzs7OztFQUNqRzs7Ozs7Q0FFYjtDQUVBLE9BQ0ksd0JBQUMsUUFBRDtFQUNJLFdBQVU7RUFDVix5QkFBeUIsRUFBRSxRQUFRLEtBQUs7Q0FDM0M7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxnQkFBZ0IsU0FBUyxRQUFRLE9BQU87Q0FDN0MsSUFBSSxDQUFDLFNBQVMsT0FBTztDQUNyQixNQUFNLFVBQVUsUUFBUSxLQUFLO0NBRTdCLElBQUksT0FBTyxPQUFPO0VBQ2QsSUFBSTtHQUNBLE9BQU8sT0FBTyxNQUFNLGVBQWUsU0FBUztJQUN4QyxhQUFhO0lBQ2IsY0FBYztHQUNsQixDQUFDO0VBQ0wsU0FBUyxJQUFJLENBRWI7Q0FDSjtDQUVBLE9BQU8sb0JBQW9CLFNBQVMsS0FBSztBQUM3QztBQUVBLFNBQVMsb0JBQW9CLE1BQU0sUUFBUTtDQUN2QyxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLElBQUksT0FBTztDQUVYLE9BQU8sS0FBSyxRQUFRLGlDQUFpQywrT0FBeU87Q0FDOVIsT0FBTyxLQUFLLFFBQVEsc0JBQXNCLHFIQUFpSDtDQUMzSixPQUFPLEtBQUssUUFBUSw0QkFBNEIsS0FBSztDQUNyRCxPQUFPLEtBQUssUUFBUSxpQkFBaUIsZUFBZTtDQUNwRCxPQUFPLEtBQUssUUFBUSxxQkFBcUIsZUFBZTtDQUN4RCxPQUFPLEtBQUssUUFBUSxnQkFBZ0IsZUFBZTtDQUNuRCxPQUFPLEtBQUssUUFBUSxvQkFBb0IsZUFBZTtDQUV2RCxNQUFNLFVBQVU7RUFDWixXQUFXO0VBQUssVUFBVTtFQUFLLFdBQVc7RUFBSyxXQUFXO0VBQUssYUFBYTtFQUM1RSxXQUFXO0VBQUssWUFBWTtFQUFLLFFBQVE7RUFBSyxRQUFRO0VBQUssV0FBVztFQUN0RSxTQUFTO0VBQUssU0FBUztFQUFLLFdBQVc7RUFBSyxRQUFRO0VBQUssV0FBVztFQUNwRSxTQUFTO0VBQUssU0FBUztFQUFLLFNBQVM7RUFBSyxTQUFTO0VBQUssWUFBWTtDQUN4RTtDQUVBLE9BQU8sUUFBUSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxPQUFPO0VBQ3hDLE9BQU8sS0FBSyxXQUFXLEdBQUcsQ0FBQztDQUMvQixDQUFDO0NBRUQsT0FBTztBQUNYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJpY2hDb250ZW50UmVuZGVyZXIuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBDb3B5LCBDaGVjaywgQ29kZSBhcyBDb2RlSWNvbiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJpY2hDb250ZW50UmVuZGVyZXIoeyBjb250ZW50LCBjbGFzc05hbWUgPSAnJyB9KSB7XG4gICAgY29uc3QgWywgc2V0S2F0ZXhMb2FkZWRdID0gdXNlU3RhdGUoKCkgPT4gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgQm9vbGVhbih3aW5kb3cua2F0ZXgpKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cua2F0ZXgpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGxvYWRDU1MgPSAodXJsKSA9PiB7XG4gICAgICAgICAgICBpZiAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgbGlua1tocmVmPVwiJHt1cmx9XCJdYCkpIHJldHVybjtcbiAgICAgICAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaW5rJyk7XG4gICAgICAgICAgICBsaW5rLnJlbCA9ICdzdHlsZXNoZWV0JztcbiAgICAgICAgICAgIGxpbmsuaHJlZiA9IHVybDtcbiAgICAgICAgICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgbG9hZFNjcmlwdCA9ICh1cmwpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYHNjcmlwdFtzcmM9XCIke3VybH1cIl1gKSkge1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG4gICAgICAgICAgICAgICAgc2NyaXB0LnNyYyA9IHVybDtcbiAgICAgICAgICAgICAgICBzY3JpcHQuYXN5bmMgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHNjcmlwdC5vbmxvYWQgPSByZXNvbHZlO1xuICAgICAgICAgICAgICAgIHNjcmlwdC5vbmVycm9yID0gcmVqZWN0O1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuXG4gICAgICAgIGxvYWRDU1MoJ2h0dHBzOi8vY2RuLmpzZGVsaXZyLm5ldC9ucG0va2F0ZXhAMC4xNi45L2Rpc3Qva2F0ZXgubWluLmNzcycpO1xuICAgICAgICBsb2FkU2NyaXB0KCdodHRwczovL2Nkbi5qc2RlbGl2ci5uZXQvbnBtL2thdGV4QDAuMTYuOS9kaXN0L2thdGV4Lm1pbi5qcycpXG4gICAgICAgICAgICAudGhlbigoKSA9PiBzZXRLYXRleExvYWRlZCh0cnVlKSlcbiAgICAgICAgICAgIC5jYXRjaCgoKSA9PiBzZXRLYXRleExvYWRlZChmYWxzZSkpO1xuICAgIH0sIFtdKTtcblxuICAgIGlmICghY29udGVudCkgcmV0dXJuIG51bGw7XG5cbiAgICBsZXQgcmF3U3RyID0gU3RyaW5nKGNvbnRlbnQpO1xuICAgIC8vIFZpc3VhbCBmb3JtdWxhIGJsb2NrcyBtYXkgY29udGFpbiBhIGJhcmUgTGFUZVggZXhwcmVzc2lvbiB3aGlsZSBhXG4gICAgLy8gcXVlc3Rpb24gaXMgYmVpbmcgZWRpdGVkLiBUcmVhdCBpdCBhcyBtYXRoIHNvIER1YWwgVmlldyBhbmQgcHVibGlzaGVkXG4gICAgLy8gcHJldmlld3MgcmVuZGVyIGl0IGluc3RlYWQgb2Ygc2hvd2luZyBgXFxcXGZyYWNgLCBgXFxcXHNxcnRgLCBldGMuXG4gICAgaWYgKCEvW1xcJF0vLnRlc3QocmF3U3RyKSAmJiAoL1xcXFwoPzpmcmFjfHNxcnR8aW50fHN1bXxwcm9kfGxpbXxhbHBoYXxiZXRhfGdhbW1hfHRoZXRhfHBpfHBtfGluZnR5fHJpZ2h0YXJyb3d8cmlnaHRsZWZ0aGFycG9vbnN8YmVnaW4pXFxiLy50ZXN0KHJhd1N0cikgfHwgL1tBLVphLXpdW19eXVxce1tefV0rXFx9Ly50ZXN0KHJhd1N0cikpKSB7XG4gICAgICAgIHJhd1N0ciA9IGAkJHtyYXdTdHJ9JGA7XG4gICAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2ByaWNoLXRleHQtY29udGVudCBsZWFkaW5nLXJlbGF4ZWQgYnJlYWstd29yZHMgYnJlYWstYWxsIFtvdmVyZmxvdy13cmFwOmFueXdoZXJlXSAke2NsYXNzTmFtZX1gfT5cbiAgICAgICAgICAgIHtwYXJzZU1peGVkQ29udGVudChyYXdTdHIpfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuXG4vLyBLZWVwIG9ubHkgcHJlc2VudGF0aW9uIEhUTUwgZW1pdHRlZCBieSB0aGUgZWRpdG9yLiBJbiBwYXJ0aWN1bGFyLCBwcmVzZXJ2ZVxuLy8gYWxpZ25tZW50L2NvbG9yIHN0eWxlcyBzbyBzYXZlZCBXWVNJV1lHIGNvbnRlbnQgcmVtYWlucyB2aXN1YWxseSBpZGVudGljYWwsXG4vLyB3aGlsZSBkcm9wcGluZyBldmVudCBoYW5kbGVycyBhbmQgdW5zYWZlIGVtYmVkZGVkIGVsZW1lbnRzLlxuZnVuY3Rpb24gc2FuaXRpemVSaWNoSHRtbChodG1sKSB7XG4gICAgcmV0dXJuIFN0cmluZyhodG1sIHx8ICcnKVxuICAgICAgICAucmVwbGFjZSgvPFxcLz8oc2NyaXB0fHN0eWxlfGlmcmFtZXxvYmplY3R8ZW1iZWQpW14+XSo+L2dpLCAnJylcbiAgICAgICAgLnJlcGxhY2UoL1xccyg/Om9uXFx3KylcXHMqPVxccypbXCInXVteXCInXSpbXCInXS9naSwgJycpXG4gICAgICAgIC5yZXBsYWNlKC9cXHNzdHlsZVxccyo9XFxzKltcIiddKFteXCInXSopW1wiJ10vZ2ksIChfLCBzdHlsZSkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc2FmZSA9IHN0eWxlLnNwbGl0KCc7JykubWFwKHJ1bGUgPT4gcnVsZS50cmltKCkpLmZpbHRlcihydWxlID0+XG4gICAgICAgICAgICAgICAgL14odGV4dC1hbGlnbnxjb2xvcnxiYWNrZ3JvdW5kLWNvbG9yfGZvbnQtc2l6ZXxmb250LXdlaWdodHxmb250LXN0eWxlfHRleHQtZGVjb3JhdGlvbilcXHMqOi9pLnRlc3QocnVsZSlcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm4gc2FmZS5sZW5ndGggPyBgIHN0eWxlPVwiJHtzYWZlLmpvaW4oJzsnKX1cImAgOiAnJztcbiAgICAgICAgfSk7XG59XG5cbi8vIEhlbHBlciB0byByZW1vdmUgZXhjZXNzaXZlIGxlYWRpbmcgdGFicy9zcGFjZXMgYW5kIGJsYW5rIGxpbmVzIGZyb20gY29kZSBibG9ja3NcbmZ1bmN0aW9uIGRlZGVudENvZGUoc3RyKSB7XG4gICAgaWYgKCFzdHIpIHJldHVybiAnJztcblxuICAgIGxldCB0ZXh0ID0gc3RyXG4gICAgICAgIC5yZXBsYWNlKC8mbHQ7L2csICc8JylcbiAgICAgICAgLnJlcGxhY2UoLyZndDsvZywgJz4nKVxuICAgICAgICAucmVwbGFjZSgvJmFtcDsvZywgJyYnKVxuICAgICAgICAucmVwbGFjZSgvJnF1b3Q7L2csICdcIicpXG4gICAgICAgIC5yZXBsYWNlKC8mIzM5Oy9nLCBcIidcIik7XG5cbiAgICBjb25zdCBsaW5lcyA9IHRleHQuc3BsaXQoL1xccj9cXG4vKTtcblxuICAgIC8vIFJlbW92ZSBsZWFkaW5nIGVtcHR5IGxpbmVzXG4gICAgd2hpbGUgKGxpbmVzLmxlbmd0aCA+IDAgJiYgbGluZXNbMF0udHJpbSgpID09PSAnJykgbGluZXMuc2hpZnQoKTtcbiAgICAvLyBSZW1vdmUgdHJhaWxpbmcgZW1wdHkgbGluZXNcbiAgICB3aGlsZSAobGluZXMubGVuZ3RoID4gMCAmJiBsaW5lc1tsaW5lcy5sZW5ndGggLSAxXS50cmltKCkgPT09ICcnKSBsaW5lcy5wb3AoKTtcblxuICAgIGlmIChsaW5lcy5sZW5ndGggPT09IDApIHJldHVybiAnJztcblxuICAgIC8vIENhbGN1bGF0ZSBjb21tb24gbWluaW11bSBpbmRlbnRhdGlvbiBhY3Jvc3Mgbm9uLWVtcHR5IGxpbmVzXG4gICAgbGV0IG1pbkluZGVudCA9IEluZmluaXR5O1xuICAgIGxpbmVzLmZvckVhY2gobGluZSA9PiB7XG4gICAgICAgIGlmIChsaW5lLnRyaW0oKS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBtYXRjaCA9IGxpbmUubWF0Y2goL15bXFxzXFx0XSsvKTtcbiAgICAgICAgICAgIGNvbnN0IGluZGVudCA9IG1hdGNoID8gbWF0Y2hbMF0ubGVuZ3RoIDogMDtcbiAgICAgICAgICAgIGlmIChpbmRlbnQgPCBtaW5JbmRlbnQpIG1pbkluZGVudCA9IGluZGVudDtcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgaWYgKG1pbkluZGVudCAhPT0gSW5maW5pdHkgJiYgbWluSW5kZW50ID4gMCkge1xuICAgICAgICByZXR1cm4gbGluZXMubWFwKGxpbmUgPT4gbGluZS5sZW5ndGggPj0gbWluSW5kZW50ID8gbGluZS5zbGljZShtaW5JbmRlbnQpIDogbGluZSkuam9pbignXFxuJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGxpbmVzLmpvaW4oJ1xcbicpO1xufVxuXG4vKipcbiAqIFVuaXZlcnNhbCBQYXJzZXIgdGhhdCBicmVha3MgZG93biB0ZXh0IGludG8gQ29kZSBCbG9ja3MsIE1hdGggQmxvY2tzLCBIZWFkZXJzLCBMaXN0cywgUXVvdGVzLCBUYWJsZXMsIGFuZCBGb3JtYXR0ZWQgVGV4dFxuICovXG5mdW5jdGlvbiBwYXJzZU1peGVkQ29udGVudCh0ZXh0KSB7XG4gICAgaWYgKCF0ZXh0KSByZXR1cm4gbnVsbDtcblxuICAgIC8vIENvbWJpbmVkIHJlZ2V4IGZvciBDb2RlIEJsb2NrcyAoYm90aCBtYXJrZG93biBgYGAuLi5gYGAgYW5kIEhUTUwgPHByZT48Y29kZT4uLi48L2NvZGU+PC9wcmU+KVxuICAgIGNvbnN0IGNvZGVCbG9ja1JlZ2V4ID0gLzxwcmU+PGNvZGUoPzogY2xhc3M9XCJsYW5ndWFnZS0oW2EtekEtWjAtOV8jLV0rKVwiKT8+KFtcXHNcXFNdKj8pPFxcL2NvZGU+PFxcL3ByZT58YGBgKFthLXpBLVowLTlfIy1dKilbIFxcdFxcclxcbl0qKFtcXHNcXFNdKj8pYGBgL2dpO1xuXG4gICAgY29uc3Qgc2VjdGlvbnMgPSBbXTtcbiAgICBsZXQgbGFzdEluZGV4ID0gMDtcbiAgICBsZXQgbWF0Y2g7XG5cbiAgICB3aGlsZSAoKG1hdGNoID0gY29kZUJsb2NrUmVnZXguZXhlYyh0ZXh0KSkgIT09IG51bGwpIHtcbiAgICAgICAgaWYgKG1hdGNoLmluZGV4ID4gbGFzdEluZGV4KSB7XG4gICAgICAgICAgICBjb25zdCBiZWZvcmVUZXh0ID0gdGV4dC5zdWJzdHJpbmcobGFzdEluZGV4LCBtYXRjaC5pbmRleCk7XG4gICAgICAgICAgICBpZiAoYmVmb3JlVGV4dCkge1xuICAgICAgICAgICAgICAgIHNlY3Rpb25zLnB1c2goeyB0eXBlOiAnbWFya2Rvd24nLCBjb250ZW50OiBiZWZvcmVUZXh0IH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaXNIdG1sUHJlID0gbWF0Y2hbMF0uc3RhcnRzV2l0aCgnPHByZScpO1xuICAgICAgICBjb25zdCBsYW5nID0gKGlzSHRtbFByZSA/IG1hdGNoWzFdIDogbWF0Y2hbM10pIHx8ICdjb2RlJztcbiAgICAgICAgY29uc3QgcmF3Q29kZSA9IChpc0h0bWxQcmUgPyBtYXRjaFsyXSA6IG1hdGNoWzRdKSB8fCAnJztcbiAgICAgICAgY29uc3QgY2xlYW5Db2RlID0gcmF3Q29kZS5yZXBsYWNlKC88W14+XSs+L2csICcnKS50cmltKCk7XG5cbiAgICAgICAgc2VjdGlvbnMucHVzaCh7XG4gICAgICAgICAgICB0eXBlOiAnY29kZScsXG4gICAgICAgICAgICBjb2RlOiBjbGVhbkNvZGUsXG4gICAgICAgICAgICBsYW5ndWFnZTogbGFuZy50cmltKCkudG9Mb3dlckNhc2UoKSB8fCAnY29kZScsXG4gICAgICAgICAgICBrZXk6IGBjb2RlXyR7bWF0Y2guaW5kZXh9YFxuICAgICAgICB9KTtcblxuICAgICAgICBsYXN0SW5kZXggPSBtYXRjaC5pbmRleCArIG1hdGNoWzBdLmxlbmd0aDtcbiAgICB9XG5cbiAgICBpZiAobGFzdEluZGV4IDwgdGV4dC5sZW5ndGgpIHtcbiAgICAgICAgY29uc3QgcmVtYWluaW5nID0gdGV4dC5zdWJzdHJpbmcobGFzdEluZGV4KTtcbiAgICAgICAgaWYgKHJlbWFpbmluZykge1xuICAgICAgICAgICAgc2VjdGlvbnMucHVzaCh7IHR5cGU6ICdtYXJrZG93bicsIGNvbnRlbnQ6IHJlbWFpbmluZyB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBzZWN0aW9ucy5tYXAoKHNlYywgc2VjSWR4KSA9PiB7XG4gICAgICAgIGlmIChzZWMudHlwZSA9PT0gJ2NvZGUnKSB7XG4gICAgICAgICAgICByZXR1cm4gPENvZGVCbG9jayBrZXk9e3NlYy5rZXkgfHwgYHNlY19jb2RlXyR7c2VjSWR4fWB9IGNvZGU9e3NlYy5jb2RlfSBsYW5ndWFnZT17c2VjLmxhbmd1YWdlfSAvPjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVuZGVyTWFya2Rvd25CbG9ja3Moc2VjLmNvbnRlbnQsIGBzZWNfbWRfJHtzZWNJZHh9YCk7XG4gICAgfSk7XG59XG5cbi8qKlxuICogUGFyc2VzIGJsb2NrLWxldmVsIG1hcmtkb3duIChoZWFkZXJzLCBibG9ja3F1b3RlcywgbGlzdHMsIGhyLCBwYXJhZ3JhcGhzKVxuICovXG5mdW5jdGlvbiByZW5kZXJNYXJrZG93bkJsb2Nrcyh0ZXh0LCBrZXlQcmVmaXgpIHtcbiAgICBpZiAoIXRleHQpIHJldHVybiBudWxsO1xuXG4gICAgLy8gV1lTSVdZRyBjb250ZW50IGlzIGFscmVhZHkgdmFsaWQgSFRNTC4gRG8gbm90IHdyYXAgYmxvY2sgZWxlbWVudHMgc3VjaFxuICAgIC8vIGFzIDxoMT4gb3IgPGRpdj4gaW4gYSBnZW5lcmF0ZWQgPHA+OyB0aGF0IGludmFsaWQgbmVzdGluZyBtYWtlcyB0aGVcbiAgICAvLyBoZWFkaW5nIGxvb2sgY29ycmVjdCBpbiBjb250ZW50RWRpdGFibGUgYnV0IGRpc2FwcGVhciBpbiBwcmV2aWV3cyBhbmRcbiAgICAvLyB0aGUgcnVubmVyLiBSZW5kZXIgdGhlIHNhbml0aXplZCBibG9jayB0cmVlIGFzLWlzLlxuICAgIGlmICgvPCg/OmhbMS02XXxwfGRpdnx1bHxvbHxsaXxibG9ja3F1b3RlfHByZXx0YWJsZXxocilcXGIvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17YCR7a2V5UHJlZml4fV9yaWNoX2h0bWxgfSBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IHNhbml0aXplUmljaEh0bWwodGV4dCkgfX0gLz5cbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBsaW5lcyA9IHRleHQuc3BsaXQoL1xccj9cXG4vKTtcbiAgICBjb25zdCBibG9ja3MgPSBbXTtcbiAgICBsZXQgY3VycmVudExpc3QgPSBudWxsOyAvLyB7IHR5cGU6ICd1bCd8J29sJywgaXRlbXM6IFtdIH1cblxuICAgIGNvbnN0IGZsdXNoTGlzdCA9IChibG9ja0lkeCkgPT4ge1xuICAgICAgICBpZiAoY3VycmVudExpc3QpIHtcbiAgICAgICAgICAgIGlmIChjdXJyZW50TGlzdC50eXBlID09PSAndWwnKSB7XG4gICAgICAgICAgICAgICAgYmxvY2tzLnB1c2goXG4gICAgICAgICAgICAgICAgICAgIDx1bCBrZXk9e2Ake2tleVByZWZpeH1fdWxfJHtibG9ja0lkeH1gfSBjbGFzc05hbWU9XCJsaXN0LWRpc2MgbGlzdC1pbnNpZGUgc3BhY2UteS0xIG15LTIgcGwtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRMaXN0Lml0ZW1zLm1hcCgoaXRlbSwgaUlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2lJZHh9IGNsYXNzTmFtZT1cImxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVuZGVySW5saW5lTWFya2Rvd25BbmRNYXRoKGl0ZW0sIGAke2tleVByZWZpeH1fbGlfJHtibG9ja0lkeH1fJHtpSWR4fWApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBibG9ja3MucHVzaChcbiAgICAgICAgICAgICAgICAgICAgPG9sIGtleT17YCR7a2V5UHJlZml4fV9vbF8ke2Jsb2NrSWR4fWB9IGNsYXNzTmFtZT1cImxpc3QtZGVjaW1hbCBsaXN0LWluc2lkZSBzcGFjZS15LTEgbXktMiBwbC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudExpc3QuaXRlbXMubWFwKChpdGVtLCBpSWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17aUlkeH0gY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW5kZXJJbmxpbmVNYXJrZG93bkFuZE1hdGgoaXRlbSwgYCR7a2V5UHJlZml4fV9vbGlfJHtibG9ja0lkeH1fJHtpSWR4fWApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9vbD5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY3VycmVudExpc3QgPSBudWxsO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGxpbmVzLmZvckVhY2goKGxpbmUsIGxJZHgpID0+IHtcbiAgICAgICAgY29uc3QgdHJpbW1lZCA9IGxpbmUudHJpbSgpO1xuXG4gICAgICAgIC8vIEVtcHR5IGxpbmVcbiAgICAgICAgaWYgKCF0cmltbWVkKSB7XG4gICAgICAgICAgICBmbHVzaExpc3QobElkeCk7XG4gICAgICAgICAgICBibG9ja3MucHVzaCg8ZGl2IGtleT17YCR7a2V5UHJlZml4fV9zcF8ke2xJZHh9YH0gY2xhc3NOYW1lPVwiaC0yXCIgLz4pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gSG9yaXpvbnRhbCBSdWxlIC0tLSBvciAqKipcbiAgICAgICAgaWYgKC9eKFxcKnszLH18LXszLH18X3szLH0pJC8udGVzdCh0cmltbWVkKSkge1xuICAgICAgICAgICAgZmx1c2hMaXN0KGxJZHgpO1xuICAgICAgICAgICAgYmxvY2tzLnB1c2goPGhyIGtleT17YCR7a2V5UHJlZml4fV9ocl8ke2xJZHh9YH0gY2xhc3NOYW1lPVwibXktMyBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiIC8+KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEhlYWRlcnM6ICMsICMjLCAjIyMsICMjIyNcbiAgICAgICAgY29uc3QgaGVhZGVyTWF0Y2ggPSB0cmltbWVkLm1hdGNoKC9eKCN7MSw2fSlcXHMrKC4rKSQvKTtcbiAgICAgICAgaWYgKGhlYWRlck1hdGNoKSB7XG4gICAgICAgICAgICBmbHVzaExpc3QobElkeCk7XG4gICAgICAgICAgICBjb25zdCBsZXZlbCA9IGhlYWRlck1hdGNoWzFdLmxlbmd0aDtcbiAgICAgICAgICAgIGNvbnN0IHRpdGxlID0gaGVhZGVyTWF0Y2hbMl07XG4gICAgICAgICAgICBjb25zdCBzaXplQ2xhc3MgPVxuICAgICAgICAgICAgICAgIGxldmVsID09PSAxID8gJ3RleHQtbGcgc206dGV4dC14bCBmb250LWV4dHJhYm9sZCBteS0zIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZScgOlxuICAgICAgICAgICAgICAgIGxldmVsID09PSAyID8gJ3RleHQtYmFzZSBzbTp0ZXh0LWxnIGZvbnQtYm9sZCBteS0yLjUgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlJyA6XG4gICAgICAgICAgICAgICAgbGV2ZWwgPT09IDMgPyAndGV4dC1zbSBzbTp0ZXh0LWJhc2UgZm9udC1ib2xkIG15LTIgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCcgOlxuICAgICAgICAgICAgICAgICd0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1ib2xkIG15LTEuNSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwJztcblxuICAgICAgICAgICAgYmxvY2tzLnB1c2goXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2Ake2tleVByZWZpeH1faF8ke2xJZHh9YH0gY2xhc3NOYW1lPXtzaXplQ2xhc3N9PlxuICAgICAgICAgICAgICAgICAgICB7cmVuZGVySW5saW5lTWFya2Rvd25BbmRNYXRoKHRpdGxlLCBgJHtrZXlQcmVmaXh9X2h0XyR7bElkeH1gKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBCbG9ja3F1b3RlOiA+IHF1b3RlXG4gICAgICAgIGlmICh0cmltbWVkLnN0YXJ0c1dpdGgoJz4nKSkge1xuICAgICAgICAgICAgZmx1c2hMaXN0KGxJZHgpO1xuICAgICAgICAgICAgY29uc3QgcXVvdGVDb250ZW50ID0gdHJpbW1lZC5yZXBsYWNlKC9ePlxccyovLCAnJyk7XG4gICAgICAgICAgICBibG9ja3MucHVzaChcbiAgICAgICAgICAgICAgICA8YmxvY2txdW90ZSBrZXk9e2Ake2tleVByZWZpeH1fYnFfJHtsSWR4fWB9IGNsYXNzTmFtZT1cImJvcmRlci1sLTQgYm9yZGVyLXRlYWwtNTAwIHBsLTMgbXktMiB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGl0YWxpYyBiZy10ZWFsLTUwLzQwIGRhcms6YmctdGVhbC05NTAvMjAgcHktMSByb3VuZGVkLXIteGxcIj5cbiAgICAgICAgICAgICAgICAgICAge3JlbmRlcklubGluZU1hcmtkb3duQW5kTWF0aChxdW90ZUNvbnRlbnQsIGAke2tleVByZWZpeH1fYnF0XyR7bElkeH1gKX1cbiAgICAgICAgICAgICAgICA8L2Jsb2NrcXVvdGU+XG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVW5vcmRlcmVkIExpc3QgaXRlbTogKiBpdGVtIG9yIC0gaXRlbVxuICAgICAgICBjb25zdCB1bE1hdGNoID0gbGluZS5tYXRjaCgvXltcXHNdKlstKitdXFxzKyguKykkLyk7XG4gICAgICAgIGlmICh1bE1hdGNoKSB7XG4gICAgICAgICAgICBpZiAoIWN1cnJlbnRMaXN0IHx8IGN1cnJlbnRMaXN0LnR5cGUgIT09ICd1bCcpIHtcbiAgICAgICAgICAgICAgICBmbHVzaExpc3QobElkeCk7XG4gICAgICAgICAgICAgICAgY3VycmVudExpc3QgPSB7IHR5cGU6ICd1bCcsIGl0ZW1zOiBbXSB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY3VycmVudExpc3QuaXRlbXMucHVzaCh1bE1hdGNoWzFdKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIE9yZGVyZWQgTGlzdCBpdGVtOiAxLiBpdGVtXG4gICAgICAgIGNvbnN0IG9sTWF0Y2ggPSBsaW5lLm1hdGNoKC9eW1xcc10qXFxkK1xcLlxccysoLispJC8pO1xuICAgICAgICBpZiAob2xNYXRjaCkge1xuICAgICAgICAgICAgaWYgKCFjdXJyZW50TGlzdCB8fCBjdXJyZW50TGlzdC50eXBlICE9PSAnb2wnKSB7XG4gICAgICAgICAgICAgICAgZmx1c2hMaXN0KGxJZHgpO1xuICAgICAgICAgICAgICAgIGN1cnJlbnRMaXN0ID0geyB0eXBlOiAnb2wnLCBpdGVtczogW10gfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGN1cnJlbnRMaXN0Lml0ZW1zLnB1c2gob2xNYXRjaFsxXSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBSZWd1bGFyIFBhcmFncmFwaCBMaW5lXG4gICAgICAgIGZsdXNoTGlzdChsSWR4KTtcbiAgICAgICAgYmxvY2tzLnB1c2goXG4gICAgICAgICAgICA8cCBrZXk9e2Ake2tleVByZWZpeH1fcF8ke2xJZHh9YH0gY2xhc3NOYW1lPVwibXktMSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICB7cmVuZGVySW5saW5lTWFya2Rvd25BbmRNYXRoKGxpbmUsIGAke2tleVByZWZpeH1fcHRfJHtsSWR4fWApfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICApO1xuICAgIH0pO1xuXG4gICAgZmx1c2hMaXN0KGxpbmVzLmxlbmd0aCk7XG4gICAgcmV0dXJuIGJsb2Nrcztcbn1cblxuLyoqXG4gKiBQYXJzZXMgaW5saW5lIGZvcm1hdHRpbmc6ICoqYm9sZCoqLCAqaXRhbGljKiwgYGNvZGVgLCBtYXRoICgkLi4uJCwgJCQuLi4kJCksIGxpbmtzIFt0ZXh0XSh1cmwpXG4gKi9cbmZ1bmN0aW9uIHJlbmRlcklubGluZU1hcmtkb3duQW5kTWF0aCh0ZXh0LCBrZXlQcmVmaXgpIHtcbiAgICBpZiAoIXRleHQpIHJldHVybiBudWxsO1xuXG4gICAgLy8gV1lTSVdZRyBmaWVsZHMgc3RvcmUgcmVhbCBIVE1MIChmb3IgZXhhbXBsZSA8c3Ryb25nPi4uLjwvc3Ryb25nPiBhbmRcbiAgICAvLyA8aT4uLi48L2k+KS4gS2VlcCB0aG9zZSB0YWdzIGFzIG1hcmt1cCBpbiBldmVyeSByZW5kZXJlciAoYnVpbGRlclxuICAgIC8vIHByZXZpZXcsIHJ1bm5lciBhbmQgcmVzdWx0KSBpbnN0ZWFkIG9mIHRyZWF0aW5nIHRoZW0gYXMgdmlzaWJsZSB0ZXh0LlxuICAgIC8vIFRoZSBlZGl0b3Igb25seSBlbWl0cyBmb3JtYXR0aW5nIHRhZ3M7IGxpbmtzL3NjcmlwdHMgYXJlIGRlbGliZXJhdGVseVxuICAgIC8vIGV4Y2x1ZGVkIGZyb20gdGhpcyBwYXRoLlxuICAgIGlmICgvPFxcLz8oc3Ryb25nfGJ8ZW18aXx1fHN8c3RyaWtlfHNwYW58cHxkaXZ8YnJ8aFsxLTZdfHVsfG9sfGxpfGJsb2NrcXVvdGV8YXxmb250fG1hcmt8c21hbGx8c3VifHN1cCkoPzpcXHNbXj5dKik/Pi9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgLy8gSFRNTCBmcm9tIHRoZSBXWVNJV1lHIGNhbiB3cmFwIGEgS2FUZVggdG9rZW4gaW4gPHA+Li4uPC9wPi5cbiAgICAgICAgLy8gU3RyaXAgb25seSB0aGUgcHJlc2VudGF0aW9uIHRhZ3MgaGVyZSBzbyB0aGUgbWF0aCB0b2tlbml6ZXIgc3RpbGxcbiAgICAgICAgLy8gZ2V0cyBhIGNoYW5jZSB0byBjcmVhdGUgTWF0aEJsb2NrIGluc3RlYWQgb2Ygc2hvd2luZyByYXcgJCQgdGV4dC5cbiAgICAgICAgaWYgKC9bXFwkXS8udGVzdCh0ZXh0KSB8fCAvXFxcXCg/OmZyYWN8c3FydHxpbnR8c3VtfGJlZ2luKVxcYi8udGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcmV0dXJuIHJlbmRlcklubGluZU1hcmtkb3duQW5kTWF0aCh0ZXh0LnJlcGxhY2UoLzxbXj5dKz4vZywgJycpLCBrZXlQcmVmaXgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgIGtleT17YCR7a2V5UHJlZml4fV9odG1sYH1cbiAgICAgICAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17e1xuICAgICAgICAgICAgICAgICAgICBfX2h0bWw6IHRleHRcbiAgICAgICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC88W14+XSs+L2csICh0YWcpID0+IHNhbml0aXplUmljaEh0bWwodGFnKSlcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBTcGxpdCBieSBNYXRoICgkJGZvcm11bGEkJCBvciAkZm9ybXVsYSQpIGFuZCBJbmxpbmUgQ29kZSAoYGNvZGVgKVxuICAgIGNvbnN0IHRva2VuUmVnZXggPSAvKFxcJFxcJFtcXHNcXFNdKz9cXCRcXCR8XFwkW14kXFxuXSs/XFwkfGBbXmBcXG5dKz9gKS9nO1xuICAgIGNvbnN0IHBhcnRzID0gdGV4dC5zcGxpdCh0b2tlblJlZ2V4KTtcblxuICAgIHJldHVybiBwYXJ0cy5tYXAoKHBhcnQsIGlkeCkgPT4ge1xuICAgICAgICBpZiAoIXBhcnQpIHJldHVybiBudWxsO1xuXG4gICAgICAgIC8vIEJsb2NrIE1hdGggJCQuLi4kJFxuICAgICAgICBpZiAocGFydC5zdGFydHNXaXRoKCckJCcpICYmIHBhcnQuZW5kc1dpdGgoJyQkJykgJiYgcGFydC5sZW5ndGggPiA0KSB7XG4gICAgICAgICAgICBjb25zdCBmb3JtdWxhID0gcGFydC5zbGljZSgyLCAtMikudHJpbSgpO1xuICAgICAgICAgICAgcmV0dXJuIDxNYXRoQmxvY2sga2V5PXtgJHtrZXlQcmVmaXh9X21fJHtpZHh9YH0gZm9ybXVsYT17Zm9ybXVsYX0gYmxvY2s9e3RydWV9IC8+O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gSW5saW5lIE1hdGggJC4uLiRcbiAgICAgICAgaWYgKHBhcnQuc3RhcnRzV2l0aCgnJCcpICYmIHBhcnQuZW5kc1dpdGgoJyQnKSAmJiBwYXJ0Lmxlbmd0aCA+IDIpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm11bGEgPSBwYXJ0LnNsaWNlKDEsIC0xKS50cmltKCk7XG4gICAgICAgICAgICByZXR1cm4gPE1hdGhCbG9jayBrZXk9e2Ake2tleVByZWZpeH1fbV8ke2lkeH1gfSBmb3JtdWxhPXtmb3JtdWxhfSBibG9jaz17ZmFsc2V9IC8+O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gSW5saW5lIENvZGUgYC4uLmBcbiAgICAgICAgaWYgKHBhcnQuc3RhcnRzV2l0aCgnYCcpICYmIHBhcnQuZW5kc1dpdGgoJ2AnKSAmJiBwYXJ0Lmxlbmd0aCA+IDIpIHtcbiAgICAgICAgICAgIGNvbnN0IGlubGluZUNvZGUgPSBwYXJ0LnNsaWNlKDEsIC0xKTtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGNvZGVcbiAgICAgICAgICAgICAgICAgICAga2V5PXtgJHtrZXlQcmVmaXh9X2NfJHtpZHh9YH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTEuNSBweS0wLjUgbXgtMC41IHJvdW5kZWQtbWQgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XSBmb250LWJvbGQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtpbmxpbmVDb2RlfVxuICAgICAgICAgICAgICAgIDwvY29kZT5cbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBGb3JtYXQgTWFya2Rvd24gQm9sZCAoKip0ZXh0KiopLCBJdGFsaWMgKCp0ZXh0KiksIGFuZCBMaW5rcyAoW3RleHRdKHVybCkpXG4gICAgICAgIHJldHVybiA8c3BhbiBrZXk9e2Ake2tleVByZWZpeH1fdF8ke2lkeH1gfT57cGFyc2VJbmxpbmVNYXJrZG93blN0eWxlcyhwYXJ0LCBgJHtrZXlQcmVmaXh9X3NfJHtpZHh9YCl9PC9zcGFuPjtcbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gcGFyc2VJbmxpbmVNYXJrZG93blN0eWxlcyh0ZXh0LCBrZXlQcmVmaXgpIHtcbiAgICBpZiAoIXRleHQpIHJldHVybiBudWxsO1xuXG4gICAgLy8gVG9rZW5pemUgYm9sZCAoKipib2xkKiopLCBpdGFsaWMgKCppdGFsaWMqIG9yIF9pdGFsaWNfKSwgYW5kIG1hcmtkb3duIGxpbmtzIFt0ZXh0XSh1cmwpXG4gICAgY29uc3Qgc3R5bGVSZWdleCA9IC8oXFwqXFwqW14qXStcXCpcXCp8XFwqW14qXStcXCp8X1teX10rX3xcXFtbXlxcXV0rXFxdXFwoW14pXStcXCkpL2c7XG4gICAgY29uc3QgcGllY2VzID0gdGV4dC5zcGxpdChzdHlsZVJlZ2V4KTtcblxuICAgIHJldHVybiBwaWVjZXMubWFwKChwaWVjZSwgcElkeCkgPT4ge1xuICAgICAgICBpZiAoIXBpZWNlKSByZXR1cm4gbnVsbDtcblxuICAgICAgICAvLyAqKkJvbGQqKlxuICAgICAgICBpZiAocGllY2Uuc3RhcnRzV2l0aCgnKionKSAmJiBwaWVjZS5lbmRzV2l0aCgnKionKSAmJiBwaWVjZS5sZW5ndGggPj0gNCkge1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8c3Ryb25nIGtleT17YCR7a2V5UHJlZml4fV9iXyR7cElkeH1gfSBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge3BpZWNlLnNsaWNlKDIsIC0yKX1cbiAgICAgICAgICAgICAgICA8L3N0cm9uZz5cbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyAqSXRhbGljKiBvciBfSXRhbGljX1xuICAgICAgICBpZiAoKHBpZWNlLnN0YXJ0c1dpdGgoJyonKSAmJiBwaWVjZS5lbmRzV2l0aCgnKicpICYmIHBpZWNlLmxlbmd0aCA+PSAyKSB8fFxuICAgICAgICAgICAgKHBpZWNlLnN0YXJ0c1dpdGgoJ18nKSAmJiBwaWVjZS5lbmRzV2l0aCgnXycpICYmIHBpZWNlLmxlbmd0aCA+PSAyKSkge1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZW0ga2V5PXtgJHtrZXlQcmVmaXh9X2lfJHtwSWR4fWB9IGNsYXNzTmFtZT1cIml0YWxpY1wiPlxuICAgICAgICAgICAgICAgICAgICB7cGllY2Uuc2xpY2UoMSwgLTEpfVxuICAgICAgICAgICAgICAgIDwvZW0+XG4gICAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gTGluayBbbGFiZWxdKHVybClcbiAgICAgICAgY29uc3QgbGlua01hdGNoID0gcGllY2UubWF0Y2goL15cXFsoW15cXF1dKylcXF1cXCgoW14pXSspXFwpJC8pO1xuICAgICAgICBpZiAobGlua01hdGNoKSB7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgIGtleT17YCR7a2V5UHJlZml4fV9sXyR7cElkeH1gfVxuICAgICAgICAgICAgICAgICAgICBocmVmPXtsaW5rTWF0Y2hbMl19XG4gICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBmb250LWJvbGQgdW5kZXJsaW5lIGhvdmVyOnRleHQtdGVhbC03MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0wLjVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2xpbmtNYXRjaFsxXX1cbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHBpZWNlO1xuICAgIH0pO1xufVxuXG4vLyDilIDilIAgQ29kZSBCbG9jayBDb21wb25lbnQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgZnVuY3Rpb24gQ29kZUJsb2NrKHsgY29kZSwgbGFuZ3VhZ2UgPSAnY29kZScgfSkge1xuICAgIGNvbnN0IFtjb3BpZWQsIHNldENvcGllZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgY2xlYW5Db2RlID0gZGVkZW50Q29kZShjb2RlKTtcblxuICAgIGNvbnN0IGhhbmRsZUNvcHkgPSAoZSkgPT4ge1xuICAgICAgICBpZiAoZSkgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoY2xlYW5Db2RlKTtcbiAgICAgICAgc2V0Q29waWVkKHRydWUpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldENvcGllZChmYWxzZSksIDIwMDApO1xuICAgIH07XG5cbiAgICBjb25zdCBsaW5lcyA9IGNsZWFuQ29kZS5zcGxpdCgnXFxuJyk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTMgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctbWQgZm9udC1tb25vIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICB7LyogSGVhZGVyIGJhciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMiBiZy1zbGF0ZS05NTAvOTAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMC84MCB0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8Q29kZUljb24gc2l6ZT17MTR9IGNsYXNzTmFtZT1cInRleHQtdGVhbC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bGFuZ3VhZ2UgfHwgJ2NvZGUnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29weX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXNsYXRlLTgwMC84MCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGZvbnQtc2Fuc1wiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU2FsaW4gS29kZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7Y29waWVkID8gPENoZWNrIHNpemU9ezEzfSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNDAwXCIgLz4gOiA8Q29weSBzaXplPXsxM30gLz59XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZFwiPntjb3BpZWQgPyAnVGVyc2FsaW4hJyA6ICdTYWxpbid9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDb2RlIEJvZHkgd2l0aCBMaW5lIE51bWJlcnMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBtYXgtaC05NiBvdmVyZmxvdy15LWF1dG8gb3ZlcmZsb3cteC1hdXRvIGxlYWRpbmctcmVsYXhlZCBmbGV4IGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWxlY3Qtbm9uZSB0ZXh0LXNsYXRlLTYwMCB0ZXh0LXJpZ2h0IHByLTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBmb250LW1vbm8gdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICB7bGluZXMubWFwKChfLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0+e2kgKyAxfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8cHJlIGNsYXNzTmFtZT1cImZsZXgtMSBmb250LW1vbm8gdGV4dC1zbGF0ZS0yMDAgZm9udC1ub3JtYWwgd2hpdGVzcGFjZS1wcmUgYm9yZGVyLTAgcC0wIG0tMCBiZy10cmFuc3BhcmVudCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgIDxjb2RlPntjbGVhbkNvZGV9PC9jb2RlPlxuICAgICAgICAgICAgICAgIDwvcHJlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG5cbi8vIOKUgOKUgCBNYXRoIC8gRm9ybXVsYSBDb21wb25lbnQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgZnVuY3Rpb24gTWF0aEJsb2NrKHsgZm9ybXVsYSwgYmxvY2sgPSBmYWxzZSB9KSB7XG4gICAgY29uc3QgaHRtbCA9IHJlbmRlckthVGVYSHRtbChmb3JtdWxhLCBibG9jayk7XG5cbiAgICBpZiAoYmxvY2spIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktMyBwLTMgYmctdGVhbC01MC82MCBkYXJrOmJnLXRlYWwtOTUwLzQwIGJvcmRlciBib3JkZXItdGVhbC0yMDAvODAgZGFyazpib3JkZXItdGVhbC04MDAvODAgcm91bmRlZC0yeGwgdGV4dC1jZW50ZXIgZm9udC1zZXJpZiB0ZXh0LWJhc2UgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBzaGFkb3cteHMgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcHgtMyBweS0xIHRyYWNraW5nLXdpZGVcIiBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGh0bWwgfX0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcHgtMS41IHB5LTAuNSBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCByb3VuZGVkIGZvbnQtc2VyaWYgdGV4dC1zbSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIG14LTAuNVwiXG4gICAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGh0bWwgfX1cbiAgICAgICAgLz5cbiAgICApO1xufVxuXG5mdW5jdGlvbiByZW5kZXJLYVRlWEh0bWwoZm9ybXVsYSwgYmxvY2sgPSBmYWxzZSkge1xuICAgIGlmICghZm9ybXVsYSkgcmV0dXJuICcnO1xuICAgIGNvbnN0IHRyaW1tZWQgPSBmb3JtdWxhLnRyaW0oKTtcblxuICAgIGlmICh3aW5kb3cua2F0ZXgpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiB3aW5kb3cua2F0ZXgucmVuZGVyVG9TdHJpbmcodHJpbW1lZCwge1xuICAgICAgICAgICAgICAgIGRpc3BsYXlNb2RlOiBibG9jayxcbiAgICAgICAgICAgICAgICB0aHJvd09uRXJyb3I6IGZhbHNlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2ggKF9lKSB7XG4gICAgICAgICAgICAvLyBGYWxsYmFjayBpZiBLYVRlWCBmYWlsc1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGZvcm1hdExhVGVYRmFsbGJhY2sodHJpbW1lZCwgYmxvY2spO1xufVxuXG5mdW5jdGlvbiBmb3JtYXRMYVRlWEZhbGxiYWNrKGV4cHIsIF9ibG9jaykge1xuICAgIGlmICghZXhwcikgcmV0dXJuICcnO1xuICAgIGxldCBodG1sID0gZXhwcjtcblxuICAgIGh0bWwgPSBodG1sLnJlcGxhY2UoL1xcXFxmcmFjXFx7KFtefV0rKVxcfVxceyhbXn1dKylcXH0vZywgJzxzcGFuIGNsYXNzPVwiaW5saW5lLWZsZXggZmxleC1jb2wgdGV4dC1jZW50ZXIgYWxpZ24tbWlkZGxlIG14LTEgZm9udC1zZXJpZlwiPjxzcGFuIGNsYXNzPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTcwMCBkYXJrOmJvcmRlci1zbGF0ZS0zMDAgcHgtMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj4kMTwvc3Bhbj48c3BhbiBjbGFzcz1cInB4LTEgdGV4dC14cyBmb250LXNlbWlib2xkXCI+JDI8L3NwYW4+PC9zcGFuPicpO1xuICAgIGh0bWwgPSBodG1sLnJlcGxhY2UoL1xcXFxzcXJ0XFx7KFtefV0rKVxcfS9nLCAnPHNwYW4gY2xhc3M9XCJmb250LXNlcmlmXCI+4oiaPHNwYW4gY2xhc3M9XCJib3JkZXItdCBib3JkZXItc2xhdGUtNzAwIGRhcms6Ym9yZGVyLXNsYXRlLTMwMCBweC0wLjVcIj4kMTwvc3Bhbj48L3NwYW4+Jyk7XG4gICAgaHRtbCA9IGh0bWwucmVwbGFjZSgvXFxcXHNxcnRcXHMqKFthLXpBLVowLTldKykvZywgJ+KImiQxJyk7XG4gICAgaHRtbCA9IGh0bWwucmVwbGFjZSgvXFxeeyhbXn1dKylcXH0vZywgJzxzdXA+JDE8L3N1cD4nKTtcbiAgICBodG1sID0gaHRtbC5yZXBsYWNlKC9cXF4oWzAtOWEtekEtWl0rKS9nLCAnPHN1cD4kMTwvc3VwPicpO1xuICAgIGh0bWwgPSBodG1sLnJlcGxhY2UoL197KFtefV0rKVxcfS9nLCAnPHN1Yj4kMTwvc3ViPicpO1xuICAgIGh0bWwgPSBodG1sLnJlcGxhY2UoL18oWzAtOWEtekEtWl0rKS9nLCAnPHN1Yj4kMTwvc3ViPicpO1xuXG4gICAgY29uc3Qgc3ltYm9scyA9IHtcbiAgICAgICAgJ1xcXFxhbHBoYSc6ICfOsScsICdcXFxcYmV0YSc6ICfOsicsICdcXFxcZ2FtbWEnOiAnzrMnLCAnXFxcXGRlbHRhJzogJ860JywgJ1xcXFxlcHNpbG9uJzogJ861JyxcbiAgICAgICAgJ1xcXFx0aGV0YSc6ICfOuCcsICdcXFxcbGFtYmRhJzogJ867JywgJ1xcXFxtdSc6ICfOvCcsICdcXFxccGknOiAnz4AnLCAnXFxcXHNpZ21hJzogJ8+DJyxcbiAgICAgICAgJ1xcXFxzdW0nOiAn4oiRJywgJ1xcXFxpbnQnOiAn4oirJywgJ1xcXFxpbmZ0eSc6ICfiiJ4nLCAnXFxcXHBtJzogJ8KxJywgJ1xcXFx0aW1lcyc6ICfDlycsXG4gICAgICAgICdcXFxcZGl2JzogJ8O3JywgJ1xcXFxuZXEnOiAn4omgJywgJ1xcXFxsZXEnOiAn4omkJywgJ1xcXFxnZXEnOiAn4omlJywgJ1xcXFxhcHByb3gnOiAn4omIJ1xuICAgIH07XG5cbiAgICBPYmplY3QuZW50cmllcyhzeW1ib2xzKS5mb3JFYWNoKChbaywgdl0pID0+IHtcbiAgICAgICAgaHRtbCA9IGh0bWwucmVwbGFjZUFsbChrLCB2KTtcbiAgICB9KTtcblxuICAgIHJldHVybiBodG1sO1xufVxuIl19