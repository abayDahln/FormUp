import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboard/userDashboard/userHistory.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { FileText, Award, Eye, Edit3, BarChart2 } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import Topbar from "/src/components/layout/Topbar.jsx";
import { getMyForms, getMySubmittedResponses, clearSession } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/userHistory.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function History() {
	_s();
	const navigate = useNavigate();
	const [activeTab, setActiveTab] = useState("submitted");
	const [submittedForms, setSubmittedForms] = useState([]);
	const [createdForms, setCreatedForms] = useState([]);
	const [loading, setLoading] = useState(true);
	const [searchQuery, setSearchQuery] = useState("");
	useEffect(() => {
		const fetchHistory = async () => {
			try {
				setLoading(true);
				const [submittedResult, createdResult] = await Promise.all([getMySubmittedResponses(), getMyForms()]);
				if (submittedResult.status === 401 || createdResult.status === 401) {
					clearSession();
					navigate("/login");
					return;
				}
				if (submittedResult.ok && Array.isArray(submittedResult.data)) {
					setSubmittedForms(submittedResult.data);
				}
				if (createdResult.ok && Array.isArray(createdResult.data)) {
					setCreatedForms(createdResult.data);
				}
			} catch (err) {
				console.error("History fetch error:", err);
			} finally {
				setLoading(false);
			}
		};
		fetchHistory();
	}, [navigate]);
	const formatDate = (dateStr) => {
		if (!dateStr) return "—";
		return new Date(dateStr).toLocaleDateString("id-ID", {
			month: "short",
			day: "numeric",
			year: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		});
	};
	const getStatusBadge = (status) => {
		const s = status?.toLowerCase() ?? "";
		if (s === "submitted" || s === "reviewed" || s === "accepted" || s === "new") {
			return "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800";
		}
		if (s === "published") {
			return "bg-teal-50 text-[#00897B] dark:bg-teal-950/60 dark:text-teal-400 border border-teal-200 dark:border-teal-800";
		}
		if (s === "draft") {
			return "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 border border-slate-200 dark:border-slate-700";
		}
		return "bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800";
	};
	const getStatusLabel = (status) => {
		const s = status?.toLowerCase() ?? "";
		if (s === "submitted") return "Terkirim";
		if (s === "reviewed") return "Ditinjau";
		if (s === "accepted") return "Diterima";
		if (s === "rejected") return "Ditolak";
		if (s === "published") return "Dipublikasikan";
		if (s === "draft") return "Draf";
		if (s === "new") return "Baru";
		return status || "—";
	};
	// Filter list based on search
	const filteredSubmitted = submittedForms.filter((item) => {
		if (!searchQuery.trim()) return true;
		const q = searchQuery.toLowerCase();
		return item.formTitle && item.formTitle.toLowerCase().includes(q) || item.status && item.status.toLowerCase().includes(q);
	});
	const filteredCreated = createdForms.filter((item) => {
		if (!searchQuery.trim()) return true;
		const q = searchQuery.toLowerCase();
		return item.title && item.title.toLowerCase().includes(q) || item.status && item.status.toLowerCase().includes(q);
	});
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen w-full bg-[#F4F8F7] dark:bg-slate-950 font-sans text-slate-800 dark:text-slate-100 transition-colors",
		children: [/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 99,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex-1 flex flex-col min-w-0 min-h-screen overflow-y-auto",
			children: /* @__PURE__ */ _jsxDEV("main", {
				className: "p-4 sm:p-6 lg:p-8 space-y-6 w-full flex-1",
				children: [
					/* @__PURE__ */ _jsxDEV(Topbar, {
						searchQuery,
						onSearchChange: setSearchQuery,
						placeholder: "Cari riwayat formulir..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-2xl font-bold text-slate-900 dark:text-white",
						children: "Riwayat & Aktivitas"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-slate-500 dark:text-slate-400 mt-1",
						children: "Pantau pengiriman formulir Anda dan kelola riwayat aktivitas akun."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 25
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 md:grid-cols-2 gap-3 sm:gap-6 w-full",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1 sm:space-y-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-2 sm:p-2.5 bg-teal-50 dark:bg-teal-950/60 w-fit rounded-xl text-[#00897B] dark:text-teal-400",
										children: /* @__PURE__ */ _jsxDEV(FileText, {
											size: 18,
											className: "sm:w-[22px] sm:h-[22px]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 122,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 121,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] sm:text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider",
										children: "Formulir Terkirim"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 124,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white",
										children: submittedForms.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1 sm:space-y-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-2 sm:p-2.5 bg-indigo-50 dark:bg-indigo-950/60 w-fit rounded-xl text-indigo-500 dark:text-indigo-400",
										children: /* @__PURE__ */ _jsxDEV(Award, {
											size: 18,
											className: "sm:w-[22px] sm:h-[22px]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 132,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 131,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] sm:text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider",
										children: "Formulir Dibuat"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 134,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white",
										children: createdForms.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 135,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 29
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden w-full",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 pt-4 gap-4 sm:gap-8",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("submitted"),
								className: `pb-4 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${activeTab === "submitted" ? "border-[#00897B] text-[#00897B] dark:border-teal-400 dark:text-teal-400" : "border-transparent text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"}`,
								children: [
									"Formulir Terkirim (",
									submittedForms.length,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("created"),
								className: `pb-4 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${activeTab === "created" ? "border-[#00897B] text-[#00897B] dark:border-teal-400 dark:text-teal-400" : "border-transparent text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"}`,
								children: [
									"Formulir Dibuat (",
									createdForms.length,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 25
						}, this), loading ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-16 text-center text-slate-400 dark:text-slate-500 text-sm font-medium",
							children: "Memuat riwayat..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 29
						}, this) : activeTab === "submitted" ? filteredSubmitted.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-16 text-center text-slate-400 dark:text-slate-500 text-sm font-medium",
							children: searchQuery ? `Tidak ada pengiriman formulir yang cocok dengan "${searchQuery}".` : "Anda belum pernah mengirimkan formulir."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 33
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "divide-y divide-slate-100 dark:divide-slate-800 sm:hidden",
							children: filteredSubmitted.map((item) => /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3.5 flex items-center justify-between gap-3 active:bg-slate-50 dark:active:bg-slate-800/50",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3 min-w-0",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-2 bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-500 dark:text-slate-400 shrink-0",
										children: /* @__PURE__ */ _jsxDEV(FileText, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 180,
											columnNumber: 57
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 179,
										columnNumber: 53
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "font-bold text-slate-900 dark:text-white text-xs truncate",
											children: item.formTitle || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 183,
											columnNumber: 57
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 mt-0.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-slate-400 dark:text-slate-500",
												children: formatDate(item.submittedAt)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 61
											}, this), item.showScore && item.score != null && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-extrabold text-[#00897B] dark:text-teal-400",
												children: [
													"• ",
													item.score,
													"%"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 191,
												columnNumber: 65
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 186,
											columnNumber: 57
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 182,
										columnNumber: 53
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 178,
									columnNumber: 49
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 shrink-0",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: `inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${getStatusBadge(item.status)}`,
										children: getStatusLabel(item.status)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 53
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => navigate(`/f/${item.formLink}/result/${item.responseId}`),
										className: "p-1.5 text-[#00897B] dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/60 rounded-lg cursor-pointer",
										title: "Lihat Hasil",
										children: /* @__PURE__ */ _jsxDEV(Eye, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 208,
											columnNumber: 57
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 203,
										columnNumber: 53
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 199,
									columnNumber: 49
								}, this)]
							}, item.responseId, true, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 45
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 37
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:block overflow-x-auto w-full",
							children: /* @__PURE__ */ _jsxDEV("table", {
								className: "w-full text-left border-collapse text-sm",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6",
											children: "Judul Formulir"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 220,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6",
											children: "Waktu Pengiriman"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 221,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6",
											children: "Skor"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 222,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6",
											children: "Status"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 223,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6 text-right",
											children: "Aksi"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 224,
											columnNumber: 53
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 219,
									columnNumber: 49
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 45
								}, this), /* @__PURE__ */ _jsxDEV("tbody", {
									className: "divide-y divide-slate-100 dark:divide-slate-800",
									children: filteredSubmitted.map((item) => /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "p-2 bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-500 dark:text-slate-400",
														children: /* @__PURE__ */ _jsxDEV(FileText, { size: 18 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 233,
															columnNumber: 69
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 232,
														columnNumber: 65
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-bold text-slate-900 dark:text-white",
														children: item.formTitle || "—"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 235,
														columnNumber: 65
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 231,
													columnNumber: 61
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 230,
												columnNumber: 57
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6 text-slate-500 dark:text-slate-400 font-medium",
												children: formatDate(item.submittedAt)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 238,
												columnNumber: 57
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6",
												children: item.showScore && item.score != null ? /* @__PURE__ */ _jsxDEV("span", {
													className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400 border border-teal-200 dark:border-teal-800",
													children: [
														/* @__PURE__ */ _jsxDEV(Award, { size: 12 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 244,
															columnNumber: 69
														}, this),
														" ",
														item.score,
														"%"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 243,
													columnNumber: 65
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs text-slate-400 dark:text-slate-500 font-medium",
													children: "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 247,
													columnNumber: 65
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 241,
												columnNumber: 57
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: `inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold ${getStatusBadge(item.status)}`,
													children: getStatusLabel(item.status)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 251,
													columnNumber: 61
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 250,
												columnNumber: 57
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6 text-right",
												children: /* @__PURE__ */ _jsxDEV("button", {
													onClick: () => navigate(`/f/${item.formLink}/result/${item.responseId}`),
													className: "inline-flex items-center gap-1.5 text-xs font-bold text-[#00897B] dark:text-teal-400 hover:underline cursor-pointer",
													children: [/* @__PURE__ */ _jsxDEV(Eye, { size: 14 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 260,
														columnNumber: 65
													}, this), " Lihat Hasil"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 256,
													columnNumber: 61
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 255,
												columnNumber: 57
											}, this)
										]
									}, item.responseId, true, {
										fileName: _jsxFileName,
										lineNumber: 229,
										columnNumber: 53
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 45
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 41
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 216,
							columnNumber: 37
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 33
						}, this) : filteredCreated.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-16 text-center text-slate-400 dark:text-slate-500 text-sm font-medium",
							children: searchQuery ? `Tidak ada formulir yang cocok dengan "${searchQuery}".` : "Belum ada formulir yang dibuat."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 33
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "divide-y divide-slate-100 dark:divide-slate-800 sm:hidden",
							children: filteredCreated.map((form) => /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3.5 flex items-center justify-between gap-3 active:bg-slate-50 dark:active:bg-slate-800/50",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3 min-w-0",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-2 bg-teal-50 dark:bg-teal-950/60 rounded-xl text-[#00897B] dark:text-teal-400 shrink-0",
										children: /* @__PURE__ */ _jsxDEV(FileText, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 283,
											columnNumber: 57
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 282,
										columnNumber: 53
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "font-bold text-slate-900 dark:text-white text-xs truncate",
											children: form.title || "Formulir Tanpa Judul"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 286,
											columnNumber: 57
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 mt-0.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-slate-400 dark:text-slate-500",
												children: formatDate(form.createdAt)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 290,
												columnNumber: 61
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-bold text-slate-600 dark:text-slate-300",
												children: [
													"• ",
													form.responseCount ?? 0,
													" Resp"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 293,
												columnNumber: 61
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 289,
											columnNumber: 57
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 285,
										columnNumber: 53
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 49
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1 shrink-0",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: `inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${getStatusBadge(form.status)}`,
											children: getStatusLabel(form.status)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 301,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => navigate(`/forms/${form.id}/edit`),
											className: "p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer",
											title: "Edit Formulir",
											children: /* @__PURE__ */ _jsxDEV(Edit3, { size: 15 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 309,
												columnNumber: 57
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 304,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => navigate(`/forms/${form.id}/responses`),
											className: "p-1.5 text-slate-400 hover:text-[#00897B] dark:hover:text-teal-400 cursor-pointer",
											title: "Lihat Respons",
											children: /* @__PURE__ */ _jsxDEV(BarChart2, { size: 15 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 316,
												columnNumber: 57
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 311,
											columnNumber: 53
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 300,
									columnNumber: 49
								}, this)]
							}, form.id, true, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 45
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 278,
							columnNumber: 37
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:block overflow-x-auto w-full",
							children: /* @__PURE__ */ _jsxDEV("table", {
								className: "w-full text-left border-collapse text-sm",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "bg-slate-50 dark:bg-slate-800/60 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6",
											children: "Judul Formulir"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 328,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6",
											children: "Status"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 329,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6",
											children: "Dibuat"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 330,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6",
											children: "Total Respons"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 331,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-4 px-6 text-right",
											children: "Aksi"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 332,
											columnNumber: 53
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 49
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 326,
									columnNumber: 45
								}, this), /* @__PURE__ */ _jsxDEV("tbody", {
									className: "divide-y divide-slate-100 dark:divide-slate-800",
									children: filteredCreated.map((form) => /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "p-2 bg-teal-50 dark:bg-teal-950/60 rounded-xl text-[#00897B] dark:text-teal-400",
														children: /* @__PURE__ */ _jsxDEV(FileText, { size: 18 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 341,
															columnNumber: 69
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 340,
														columnNumber: 65
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-bold text-slate-900 dark:text-white",
														children: form.title || "Formulir Tanpa Judul"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 343,
														columnNumber: 65
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 339,
													columnNumber: 61
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 338,
												columnNumber: 57
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: `inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold ${getStatusBadge(form.status)}`,
													children: getStatusLabel(form.status)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 347,
													columnNumber: 61
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 346,
												columnNumber: 57
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6 text-slate-500 dark:text-slate-400 font-medium",
												children: formatDate(form.createdAt)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 351,
												columnNumber: 57
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6 font-bold text-slate-800 dark:text-slate-200",
												children: form.responseCount ?? 0
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 354,
												columnNumber: 57
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-4 px-6 text-right",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-end gap-2",
													children: [/* @__PURE__ */ _jsxDEV("button", {
														onClick: () => navigate(`/forms/${form.id}/edit`),
														className: "p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg transition-colors cursor-pointer",
														title: "Edit Formulir",
														children: /* @__PURE__ */ _jsxDEV(Edit3, { size: 16 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 364,
															columnNumber: 69
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 359,
														columnNumber: 65
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														onClick: () => navigate(`/forms/${form.id}/responses`),
														className: "p-1.5 text-slate-400 hover:text-[#00897B] dark:hover:text-teal-400 rounded-lg transition-colors cursor-pointer",
														title: "Lihat Respons",
														children: /* @__PURE__ */ _jsxDEV(BarChart2, { size: 16 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 371,
															columnNumber: 69
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 366,
														columnNumber: 65
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 358,
													columnNumber: 61
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 357,
												columnNumber: 57
											}, this)
										]
									}, form.id, true, {
										fileName: _jsxFileName,
										lineNumber: 337,
										columnNumber: 53
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 335,
									columnNumber: 45
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 41
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 37
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 276,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 98,
		columnNumber: 9
	}, this);
}
_s(History, "36bPIm+VC8I5PSXfJXBkldX3ADM=", false, function() {
	return [useNavigate];
});
_c = History;
var _c;
$RefreshReg$(_c, "History");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/dashboard/userDashboard/userHistory.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/userHistory.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/userHistory.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/userHistory.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLFVBQVUsT0FBTyxLQUFLLE9BQU8saUJBQWlCO0FBQ3ZELE9BQU8sYUFBYTtBQUNwQixPQUFPLFlBQVk7QUFDbkIsU0FBUyxZQUFZLHlCQUF5QixvQkFBb0I7Ozs7QUFFbEUsZUFBZSxTQUFTLFVBQVU7O0NBQzlCLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLFdBQVc7Q0FDdEQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxDQUFDLENBQUM7Q0FDdkQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsQ0FBQyxDQUFDO0NBQ25ELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FFakQsZ0JBQWdCO0VBQ1osTUFBTSxlQUFlLFlBQVk7R0FDN0IsSUFBSTtJQUNBLFdBQVcsSUFBSTtJQUNmLE1BQU0sQ0FBQyxpQkFBaUIsaUJBQWlCLE1BQU0sUUFBUSxJQUFJLENBQ3ZELHdCQUF3QixHQUN4QixXQUFXLENBQ2YsQ0FBQztJQUVELElBQUksZ0JBQWdCLFdBQVcsT0FBTyxjQUFjLFdBQVcsS0FBSztLQUNoRSxhQUFhO0tBQ2IsU0FBUyxRQUFRO0tBQ2pCO0lBQ0o7SUFFQSxJQUFJLGdCQUFnQixNQUFNLE1BQU0sUUFBUSxnQkFBZ0IsSUFBSSxHQUFHO0tBQzNELGtCQUFrQixnQkFBZ0IsSUFBSTtJQUMxQztJQUNBLElBQUksY0FBYyxNQUFNLE1BQU0sUUFBUSxjQUFjLElBQUksR0FBRztLQUN2RCxnQkFBZ0IsY0FBYyxJQUFJO0lBQ3RDO0dBQ0osU0FBUyxLQUFLO0lBQ1YsUUFBUSxNQUFNLHdCQUF3QixHQUFHO0dBQzdDLFVBQVU7SUFDTixXQUFXLEtBQUs7R0FDcEI7RUFDSjtFQUVBLGFBQWE7Q0FDakIsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUViLE1BQU0sY0FBYyxZQUFZO0VBQzVCLElBQUksQ0FBQyxTQUFTLE9BQU87RUFDckIsT0FBTyxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsbUJBQW1CLFNBQVM7R0FBRSxPQUFPO0dBQVMsS0FBSztHQUFXLE1BQU07R0FBVyxNQUFNO0dBQVcsUUFBUTtFQUFVLENBQUM7Q0FDaEo7Q0FFQSxNQUFNLGtCQUFrQixXQUFXO0VBQy9CLE1BQU0sSUFBSSxRQUFRLFlBQVksS0FBSztFQUNuQyxJQUFJLE1BQU0sZUFBZSxNQUFNLGNBQWMsTUFBTSxjQUFjLE1BQU0sT0FBTztHQUMxRSxPQUFPO0VBQ1g7RUFDQSxJQUFJLE1BQU0sYUFBYTtHQUNuQixPQUFPO0VBQ1g7RUFDQSxJQUFJLE1BQU0sU0FBUztHQUNmLE9BQU87RUFDWDtFQUNBLE9BQU87Q0FDWDtDQUVBLE1BQU0sa0JBQWtCLFdBQVc7RUFDL0IsTUFBTSxJQUFJLFFBQVEsWUFBWSxLQUFLO0VBQ25DLElBQUksTUFBTSxhQUFhLE9BQU87RUFDOUIsSUFBSSxNQUFNLFlBQVksT0FBTztFQUM3QixJQUFJLE1BQU0sWUFBWSxPQUFPO0VBQzdCLElBQUksTUFBTSxZQUFZLE9BQU87RUFDN0IsSUFBSSxNQUFNLGFBQWEsT0FBTztFQUM5QixJQUFJLE1BQU0sU0FBUyxPQUFPO0VBQzFCLElBQUksTUFBTSxPQUFPLE9BQU87RUFDeEIsT0FBTyxVQUFVO0NBQ3JCOztDQUdBLE1BQU0sb0JBQW9CLGVBQWUsUUFBTyxTQUFRO0VBQ3BELElBQUksQ0FBQyxZQUFZLEtBQUssR0FBRyxPQUFPO0VBQ2hDLE1BQU0sSUFBSSxZQUFZLFlBQVk7RUFDbEMsT0FDSyxLQUFLLGFBQWEsS0FBSyxVQUFVLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUN6RCxLQUFLLFVBQVUsS0FBSyxPQUFPLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQztDQUU1RCxDQUFDO0NBRUQsTUFBTSxrQkFBa0IsYUFBYSxRQUFPLFNBQVE7RUFDaEQsSUFBSSxDQUFDLFlBQVksS0FBSyxHQUFHLE9BQU87RUFDaEMsTUFBTSxJQUFJLFlBQVksWUFBWTtFQUNsQyxPQUNLLEtBQUssU0FBUyxLQUFLLE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQ2pELEtBQUssVUFBVSxLQUFLLE9BQU8sWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDO0NBRTVELENBQUM7Q0FFRCxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDSSx3QkFBQyxTQUFELENBQVU7Ozs7WUFFVix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNYLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCO0tBRUksd0JBQUMsUUFBRDtNQUNpQjtNQUNiLGdCQUFnQjtNQUNoQixhQUFZO0tBQ2Y7Ozs7O0tBRUQsd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFvRDtLQUF1Qjs7OztlQUN6Rix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBa0Q7S0FFNUQ7Ozs7YUFDRjs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNYLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0ksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1gsd0JBQUMsVUFBRDtXQUFVLE1BQU07V0FBSSxXQUFVO1VBQTJCOzs7OztTQUN4RDs7Ozs7U0FDTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBK0Y7U0FBb0I7Ozs7O1NBQ2hJLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFzRSxlQUFlO1NBQVc7Ozs7O1FBQzdHOzs7Ozs7TUFDSjs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNJLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNYLHdCQUFDLE9BQUQ7V0FBTyxNQUFNO1dBQUksV0FBVTtVQUEyQjs7Ozs7U0FDckQ7Ozs7O1NBQ0wsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQStGO1NBQWtCOzs7OztTQUM5SCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBc0UsYUFBYTtTQUFXOzs7OztRQUMzRzs7Ozs7O01BQ0o7Ozs7Y0FDSjs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FFSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFVBQUQ7UUFDSSxlQUFlLGFBQWEsV0FBVztRQUN2QyxXQUFXLDhFQUNQLGNBQWMsY0FDUiw0RUFDQTtrQkFMZDtTQU9DO1NBQ3VCLGVBQWU7U0FBTztRQUN0Qzs7Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNJLGVBQWUsYUFBYSxTQUFTO1FBQ3JDLFdBQVcsOEVBQ1AsY0FBYyxZQUNSLDRFQUNBO2tCQUxkO1NBT0M7U0FDcUIsYUFBYTtTQUFPO1FBQ2xDOzs7OztlQUNQOzs7OztnQkFFSixVQUNHLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUEyRTtNQUFzQjs7OztpQkFDaEgsY0FBYyxjQUNkLGtCQUFrQixXQUFXLElBQ3pCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNWLGNBQWMsb0RBQW9ELFlBQVksTUFBTTtNQUNwRjs7OztpQkFFTCxnREFFSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDVixrQkFBa0IsS0FBSyxTQUNwQix3QkFBQyxPQUFEO1FBQTJCLFdBQVU7a0JBQXJDLENBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWCx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztTQUNwQjs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUNSLEtBQUssYUFBYTtVQUNwQjs7OztvQkFDSCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUNYLFdBQVcsS0FBSyxXQUFXO1dBQzFCOzs7O3FCQUNMLEtBQUssYUFBYSxLQUFLLFNBQVMsUUFDN0Isd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCO2FBQStFO2FBQ3hFLEtBQUs7YUFBTTtZQUNaOzs7OzttQkFFVDs7Ozs7a0JBQ0o7Ozs7O2lCQUNKOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLFFBQUQ7VUFBTSxXQUFXLDJFQUEyRSxlQUFlLEtBQUssTUFBTTtvQkFDakgsZUFBZSxLQUFLLE1BQU07U0FDekI7Ozs7bUJBQ04sd0JBQUMsVUFBRDtVQUNJLGVBQWUsU0FBUyxNQUFNLEtBQUssU0FBUyxVQUFVLEtBQUssWUFBWTtVQUN2RSxXQUFVO1VBQ1YsT0FBTTtvQkFFTix3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OztTQUNaOzs7O2lCQUNQOzs7OztnQkFDSjtVQWxDSyxLQUFLOzs7O2NBa0NWLENBQ1I7TUFDQTs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FDSSx3QkFBQyxTQUFELFlBQ0ksd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFDSSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBWTtVQUFrQjs7Ozs7VUFDNUMsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQVk7VUFBb0I7Ozs7O1VBQzlDLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFZO1VBQVE7Ozs7O1VBQ2xDLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFZO1VBQVU7Ozs7O1VBQ3BDLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUF1QjtVQUFROzs7OztTQUM3Qzs7Ozs7aUJBQ0Q7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQ1osa0JBQWtCLEtBQUssU0FDcEIsd0JBQUMsTUFBRDtVQUEwQixXQUFVO29CQUFwQztXQUNJLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNWLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQ1gsd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7YUFDcEI7Ozs7dUJBQ0wsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQTRDLEtBQUssYUFBYTthQUFVOzs7O3FCQUN2Rjs7Ozs7O1dBQ0w7Ozs7O1dBQ0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1QsV0FBVyxLQUFLLFdBQVc7V0FDNUI7Ozs7O1dBQ0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1QsS0FBSyxhQUFhLEtBQUssU0FBUyxPQUM3Qix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FDSSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztjQUFDO2NBQUUsS0FBSztjQUFNO2FBQzlCOzs7Ozt1QkFFTix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBeUQ7WUFBTzs7Ozs7V0FFcEY7Ozs7O1dBQ0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1Ysd0JBQUMsUUFBRDthQUFNLFdBQVcsdUVBQXVFLGVBQWUsS0FBSyxNQUFNO3VCQUM3RyxlQUFlLEtBQUssTUFBTTtZQUN6Qjs7Ozs7V0FDTjs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDVix3QkFBQyxVQUFEO2FBQ0ksZUFBZSxTQUFTLE1BQU0sS0FBSyxTQUFTLFVBQVUsS0FBSyxZQUFZO2FBQ3ZFLFdBQVU7dUJBRmQsQ0FJSSx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7O3VCQUFDLGNBQ2I7Ozs7OztXQUNSOzs7OztVQUNKO1lBbENLLEtBQUs7Ozs7Z0JBa0NWLENBQ1A7UUFDRTs7OztnQkFDSjs7Ozs7O01BQ047Ozs7Y0FDUDs7OztpQkFHTixnQkFBZ0IsV0FBVyxJQUN2Qix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDVixjQUFjLHlDQUF5QyxZQUFZLE1BQU07TUFDekU7Ozs7aUJBRUwsZ0RBRUksd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1YsZ0JBQWdCLEtBQUssU0FDbEIsd0JBQUMsT0FBRDtRQUFtQixXQUFVO2tCQUE3QixDQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1gsd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7U0FDcEI7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDUixLQUFLLFNBQVM7VUFDaEI7Ozs7b0JBQ0gsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDWCxXQUFXLEtBQUssU0FBUztXQUN4Qjs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEI7YUFBMkU7YUFDcEUsS0FBSyxpQkFBaUI7YUFBRTtZQUN6Qjs7Ozs7bUJBQ0w7Ozs7O2tCQUNKOzs7OztpQkFDSjs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDSSx3QkFBQyxRQUFEO1dBQU0sV0FBVywyRUFBMkUsZUFBZSxLQUFLLE1BQU07cUJBQ2pILGVBQWUsS0FBSyxNQUFNO1VBQ3pCOzs7OztVQUNOLHdCQUFDLFVBQUQ7V0FDSSxlQUFlLFNBQVMsVUFBVSxLQUFLLEdBQUcsTUFBTTtXQUNoRCxXQUFVO1dBQ1YsT0FBTTtxQkFFTix3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztVQUNkOzs7OztVQUNSLHdCQUFDLFVBQUQ7V0FDSSxlQUFlLFNBQVMsVUFBVSxLQUFLLEdBQUcsV0FBVztXQUNyRCxXQUFVO1dBQ1YsT0FBTTtxQkFFTix3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7OztVQUNsQjs7Ozs7U0FDUDs7Ozs7Z0JBQ0o7VUF2Q0ssS0FBSzs7OztjQXVDVixDQUNSO01BQ0E7Ozs7Z0JBR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1gsd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQ0ksd0JBQUMsU0FBRCxZQUNJLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkO1VBQ0ksd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQVk7VUFBa0I7Ozs7O1VBQzVDLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFZO1VBQVU7Ozs7O1VBQ3BDLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFZO1VBQVU7Ozs7O1VBQ3BDLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFZO1VBQWlCOzs7OztVQUMzQyx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBdUI7VUFBUTs7Ozs7U0FDN0M7Ozs7O2lCQUNEOzs7O2tCQUNQLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUNaLGdCQUFnQixLQUFLLFNBQ2xCLHdCQUFDLE1BQUQ7VUFBa0IsV0FBVTtvQkFBNUI7V0FDSSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDVix3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNJLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUNYLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O2FBQ3BCOzs7O3VCQUNMLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUE0QyxLQUFLLFNBQVM7YUFBNkI7Ozs7cUJBQ3RHOzs7Ozs7V0FDTDs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDVix3QkFBQyxRQUFEO2FBQU0sV0FBVyx1RUFBdUUsZUFBZSxLQUFLLE1BQU07dUJBQzdHLGVBQWUsS0FBSyxNQUFNO1lBQ3pCOzs7OztXQUNOOzs7OztXQUNKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNULFdBQVcsS0FBSyxTQUFTO1dBQzFCOzs7OztXQUNKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNULEtBQUssaUJBQWlCO1dBQ3ZCOzs7OztXQUNKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNWLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsVUFBRDtjQUNJLGVBQWUsU0FBUyxVQUFVLEtBQUssR0FBRyxNQUFNO2NBQ2hELFdBQVU7Y0FDVixPQUFNO3dCQUVOLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7O2FBQ2Q7Ozs7dUJBQ1Isd0JBQUMsVUFBRDtjQUNJLGVBQWUsU0FBUyxVQUFVLEtBQUssR0FBRyxXQUFXO2NBQ3JELFdBQVU7Y0FDVixPQUFNO3dCQUVOLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O2FBQ2xCOzs7O3FCQUNQOzs7Ozs7V0FDTDs7Ozs7VUFDSjtZQXRDSyxLQUFLOzs7O2dCQXNDVixDQUNQO1FBQ0U7Ozs7Z0JBQ0o7Ozs7OztNQUNOOzs7O2NBQ1A7Ozs7Y0FJVDs7Ozs7O0lBRUg7Ozs7OztFQUNMOzs7O1VBQ0o7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInVzZXJIaXN0b3J5LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEZpbGVUZXh0LCBBd2FyZCwgRXllLCBFZGl0MywgQmFyQ2hhcnQyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBTaWRlYmFyIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvbGF5b3V0L1NpZGViYXInO1xuaW1wb3J0IFRvcGJhciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2xheW91dC9Ub3BiYXInO1xuaW1wb3J0IHsgZ2V0TXlGb3JtcywgZ2V0TXlTdWJtaXR0ZWRSZXNwb25zZXMsIGNsZWFyU2Vzc2lvbiB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIaXN0b3J5KCkge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUoJ3N1Ym1pdHRlZCcpO1xuICAgIGNvbnN0IFtzdWJtaXR0ZWRGb3Jtcywgc2V0U3VibWl0dGVkRm9ybXNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtjcmVhdGVkRm9ybXMsIHNldENyZWF0ZWRGb3Jtc10gPSB1c2VTdGF0ZShbXSk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBmZXRjaEhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgW3N1Ym1pdHRlZFJlc3VsdCwgY3JlYXRlZFJlc3VsdF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICAgICAgICAgIGdldE15U3VibWl0dGVkUmVzcG9uc2VzKCksXG4gICAgICAgICAgICAgICAgICAgIGdldE15Rm9ybXMoKSxcbiAgICAgICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgICAgIGlmIChzdWJtaXR0ZWRSZXN1bHQuc3RhdHVzID09PSA0MDEgfHwgY3JlYXRlZFJlc3VsdC5zdGF0dXMgPT09IDQwMSkge1xuICAgICAgICAgICAgICAgICAgICBjbGVhclNlc3Npb24oKTtcbiAgICAgICAgICAgICAgICAgICAgbmF2aWdhdGUoJy9sb2dpbicpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKHN1Ym1pdHRlZFJlc3VsdC5vayAmJiBBcnJheS5pc0FycmF5KHN1Ym1pdHRlZFJlc3VsdC5kYXRhKSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRTdWJtaXR0ZWRGb3JtcyhzdWJtaXR0ZWRSZXN1bHQuZGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChjcmVhdGVkUmVzdWx0Lm9rICYmIEFycmF5LmlzQXJyYXkoY3JlYXRlZFJlc3VsdC5kYXRhKSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRDcmVhdGVkRm9ybXMoY3JlYXRlZFJlc3VsdC5kYXRhKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdIaXN0b3J5IGZldGNoIGVycm9yOicsIGVycik7XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGZldGNoSGlzdG9yeSgpO1xuICAgIH0sIFtuYXZpZ2F0ZV0pO1xuXG4gICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlU3RyKSA9PiB7XG4gICAgICAgIGlmICghZGF0ZVN0cikgcmV0dXJuICfigJQnO1xuICAgICAgICByZXR1cm4gbmV3IERhdGUoZGF0ZVN0cikudG9Mb2NhbGVEYXRlU3RyaW5nKCdpZC1JRCcsIHsgbW9udGg6ICdzaG9ydCcsIGRheTogJ251bWVyaWMnLCB5ZWFyOiAnbnVtZXJpYycsIGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGdldFN0YXR1c0JhZGdlID0gKHN0YXR1cykgPT4ge1xuICAgICAgICBjb25zdCBzID0gc3RhdHVzPy50b0xvd2VyQ2FzZSgpID8/ICcnO1xuICAgICAgICBpZiAocyA9PT0gJ3N1Ym1pdHRlZCcgfHwgcyA9PT0gJ3Jldmlld2VkJyB8fCBzID09PSAnYWNjZXB0ZWQnIHx8IHMgPT09ICduZXcnKSB7XG4gICAgICAgICAgICByZXR1cm4gJ2JnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwJztcbiAgICAgICAgfVxuICAgICAgICBpZiAocyA9PT0gJ3B1Ymxpc2hlZCcpIHtcbiAgICAgICAgICAgIHJldHVybiAnYmctdGVhbC01MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOmJnLXRlYWwtOTUwLzYwIGRhcms6dGV4dC10ZWFsLTQwMCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwJztcbiAgICAgICAgfVxuICAgICAgICBpZiAocyA9PT0gJ2RyYWZ0Jykge1xuICAgICAgICAgICAgcmV0dXJuICdiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAnO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAnYmctYW1iZXItNTAgdGV4dC1hbWJlci02MDAgZGFyazpiZy1hbWJlci05NTAvNjAgZGFyazp0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAnO1xuICAgIH07XG5cbiAgICBjb25zdCBnZXRTdGF0dXNMYWJlbCA9IChzdGF0dXMpID0+IHtcbiAgICAgICAgY29uc3QgcyA9IHN0YXR1cz8udG9Mb3dlckNhc2UoKSA/PyAnJztcbiAgICAgICAgaWYgKHMgPT09ICdzdWJtaXR0ZWQnKSByZXR1cm4gJ1RlcmtpcmltJztcbiAgICAgICAgaWYgKHMgPT09ICdyZXZpZXdlZCcpIHJldHVybiAnRGl0aW5qYXUnO1xuICAgICAgICBpZiAocyA9PT0gJ2FjY2VwdGVkJykgcmV0dXJuICdEaXRlcmltYSc7XG4gICAgICAgIGlmIChzID09PSAncmVqZWN0ZWQnKSByZXR1cm4gJ0RpdG9sYWsnO1xuICAgICAgICBpZiAocyA9PT0gJ3B1Ymxpc2hlZCcpIHJldHVybiAnRGlwdWJsaWthc2lrYW4nO1xuICAgICAgICBpZiAocyA9PT0gJ2RyYWZ0JykgcmV0dXJuICdEcmFmJztcbiAgICAgICAgaWYgKHMgPT09ICduZXcnKSByZXR1cm4gJ0JhcnUnO1xuICAgICAgICByZXR1cm4gc3RhdHVzIHx8ICfigJQnO1xuICAgIH07XG5cbiAgICAvLyBGaWx0ZXIgbGlzdCBiYXNlZCBvbiBzZWFyY2hcbiAgICBjb25zdCBmaWx0ZXJlZFN1Ym1pdHRlZCA9IHN1Ym1pdHRlZEZvcm1zLmZpbHRlcihpdGVtID0+IHtcbiAgICAgICAgaWYgKCFzZWFyY2hRdWVyeS50cmltKCkpIHJldHVybiB0cnVlO1xuICAgICAgICBjb25zdCBxID0gc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIChpdGVtLmZvcm1UaXRsZSAmJiBpdGVtLmZvcm1UaXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKSB8fFxuICAgICAgICAgICAgKGl0ZW0uc3RhdHVzICYmIGl0ZW0uc3RhdHVzLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpXG4gICAgICAgICk7XG4gICAgfSk7XG5cbiAgICBjb25zdCBmaWx0ZXJlZENyZWF0ZWQgPSBjcmVhdGVkRm9ybXMuZmlsdGVyKGl0ZW0gPT4ge1xuICAgICAgICBpZiAoIXNlYXJjaFF1ZXJ5LnRyaW0oKSkgcmV0dXJuIHRydWU7XG4gICAgICAgIGNvbnN0IHEgPSBzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgKGl0ZW0udGl0bGUgJiYgaXRlbS50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKSB8fFxuICAgICAgICAgICAgKGl0ZW0uc3RhdHVzICYmIGl0ZW0uc3RhdHVzLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpXG4gICAgICAgICk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIHctZnVsbCBiZy1bI0Y0RjhGN10gZGFyazpiZy1zbGF0ZS05NTAgZm9udC1zYW5zIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgIDxTaWRlYmFyIC8+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgbWluLXctMCBtaW4taC1zY3JlZW4gb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwicC00IHNtOnAtNiBsZzpwLTggc3BhY2UteS02IHctZnVsbCBmbGV4LTFcIj5cblxuICAgICAgICAgICAgICAgICAgICA8VG9wYmFyIFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoUXVlcnk9e3NlYXJjaFF1ZXJ5fSBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2hhbmdlPXtzZXRTZWFyY2hRdWVyeX0gXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNhcmkgcml3YXlhdCBmb3JtdWxpci4uLlwiIFxuICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlJpd2F5YXQgJiBBa3Rpdml0YXM8L2gxPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYW50YXUgcGVuZ2lyaW1hbiBmb3JtdWxpciBBbmRhIGRhbiBrZWxvbGEgcml3YXlhdCBha3Rpdml0YXMgYWt1bi5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFN0YXQgY2FyZHMgZGlidWF0IHNlamFqYXIgMiBrb2xvbSBkaSBtb2JpbGUgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtMiBnYXAtMyBzbTpnYXAtNiB3LWZ1bGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC00IHNtOnAtNiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc2hhZG93LXNtIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIHNtOnNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBzbTpwLTIuNSBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgdy1maXQgcm91bmRlZC14bCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBzaXplPXsxOH0gY2xhc3NOYW1lPVwic206dy1bMjJweF0gc206aC1bMjJweF1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gc206dGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Gb3JtdWxpciBUZXJraXJpbTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIHNtOnRleHQtM3hsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPntzdWJtaXR0ZWRGb3Jtcy5sZW5ndGh9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHAtNCBzbTpwLTYgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMSBzbTpzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgc206cC0yLjUgYmctaW5kaWdvLTUwIGRhcms6YmctaW5kaWdvLTk1MC82MCB3LWZpdCByb3VuZGVkLXhsIHRleHQtaW5kaWdvLTUwMCBkYXJrOnRleHQtaW5kaWdvLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEF3YXJkIHNpemU9ezE4fSBjbGFzc05hbWU9XCJzbTp3LVsyMnB4XSBzbTpoLVsyMnB4XVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBzbTp0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkZvcm11bGlyIERpYnVhdDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIHNtOnRleHQtM3hsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPntjcmVhdGVkRm9ybXMubGVuZ3RofTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc2hhZG93LXNtIG92ZXJmbG93LWhpZGRlbiB3LWZ1bGxcIj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHB4LTQgc206cHgtNiBwdC00IGdhcC00IHNtOmdhcC04XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ3N1Ym1pdHRlZCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwYi00IHRleHQteHMgc206dGV4dC1zbSBmb250LWJvbGQgYm9yZGVyLWItMiB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnc3VibWl0dGVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1bIzAwODk3Ql0gdGV4dC1bIzAwODk3Ql0gZGFyazpib3JkZXItdGVhbC00MDAgZGFyazp0ZXh0LXRlYWwtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRm9ybXVsaXIgVGVya2lyaW0gKHtzdWJtaXR0ZWRGb3Jtcy5sZW5ndGh9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdjcmVhdGVkJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHBiLTQgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtYm9sZCBib3JkZXItYi0yIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdjcmVhdGVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1bIzAwODk3Ql0gdGV4dC1bIzAwODk3Ql0gZGFyazpib3JkZXItdGVhbC00MDAgZGFyazp0ZXh0LXRlYWwtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRm9ybXVsaXIgRGlidWF0ICh7Y3JlYXRlZEZvcm1zLmxlbmd0aH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xNiB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIHRleHQtc20gZm9udC1tZWRpdW1cIj5NZW11YXQgcml3YXlhdC4uLjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IGFjdGl2ZVRhYiA9PT0gJ3N1Ym1pdHRlZCcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRTdWJtaXR0ZWQubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTE2IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlYXJjaFF1ZXJ5ID8gYFRpZGFrIGFkYSBwZW5naXJpbWFuIGZvcm11bGlyIHlhbmcgY29jb2sgZGVuZ2FuIFwiJHtzZWFyY2hRdWVyeX1cIi5gIDogJ0FuZGEgYmVsdW0gcGVybmFoIG1lbmdpcmlta2FuIGZvcm11bGlyLid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTW9iaWxlIExpc3QgVmlldyAtIFJpbmdrYXMgJiBIZW1hdCBUZW1wYXQgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwIHNtOmhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFN1Ym1pdHRlZC5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0ucmVzcG9uc2VJZH0gY2xhc3NOYW1lPVwicC0zLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGFjdGl2ZTpiZy1zbGF0ZS01MCBkYXJrOmFjdGl2ZTpiZy1zbGF0ZS04MDAvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQteHMgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmZvcm1UaXRsZSB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKGl0ZW0uc3VibWl0dGVkQXQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uc2hvd1Njb3JlICYmIGl0ZW0uc2NvcmUgIT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKAoiB7aXRlbS5zY29yZX0lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkICR7Z2V0U3RhdHVzQmFkZ2UoaXRlbS5zdGF0dXMpfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzTGFiZWwoaXRlbS5zdGF0dXMpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvZi8ke2l0ZW0uZm9ybUxpbmt9L3Jlc3VsdC8ke2l0ZW0ucmVzcG9uc2VJZH1gKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwIGhvdmVyOmJnLXRlYWwtNTAgZGFyazpob3ZlcjpiZy10ZWFsLTk1MC82MCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMaWhhdCBIYXNpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEZXNrdG9wIFRhYmxlIFZpZXcgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpibG9jayBvdmVyZmxvdy14LWF1dG8gdy1mdWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIHRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS00IHB4LTZcIj5KdWR1bCBGb3JtdWxpcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTQgcHgtNlwiPldha3R1IFBlbmdpcmltYW48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS00IHB4LTZcIj5Ta29yPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktNCBweC02XCI+U3RhdHVzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktNCBweC02IHRleHQtcmlnaHRcIj5Ba3NpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkU3VibWl0dGVkLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0ucmVzcG9uc2VJZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj57aXRlbS5mb3JtVGl0bGUgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTYgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUoaXRlbS5zdWJtaXR0ZWRBdCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnNob3dTY29yZSAmJiBpdGVtLnNjb3JlICE9IG51bGwgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QXdhcmQgc2l6ZT17MTJ9IC8+IHtpdGVtLnNjb3JlfSVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bVwiPuKAlDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgJHtnZXRTdGF0dXNCYWRnZShpdGVtLnN0YXR1cyl9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldFN0YXR1c0xhYmVsKGl0ZW0uc3RhdHVzKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcHgtNiB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9mLyR7aXRlbS5mb3JtTGlua30vcmVzdWx0LyR7aXRlbS5yZXNwb25zZUlkfWApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBob3Zlcjp1bmRlcmxpbmUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFeWUgc2l6ZT17MTR9IC8+IExpaGF0IEhhc2lsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkQ3JlYXRlZC5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTYgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VhcmNoUXVlcnkgPyBgVGlkYWsgYWRhIGZvcm11bGlyIHlhbmcgY29jb2sgZGVuZ2FuIFwiJHtzZWFyY2hRdWVyeX1cIi5gIDogJ0JlbHVtIGFkYSBmb3JtdWxpciB5YW5nIGRpYnVhdC4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1vYmlsZSBMaXN0IFZpZXcgLSBSaW5na2FzICYgSGVtYXQgVGVtcGF0ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMCBzbTpoaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRDcmVhdGVkLm1hcCgoZm9ybSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17Zm9ybS5pZH0gY2xhc3NOYW1lPVwicC0zLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGFjdGl2ZTpiZy1zbGF0ZS01MCBkYXJrOmFjdGl2ZTpiZy1zbGF0ZS04MDAvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCByb3VuZGVkLXhsIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdGV4dC14cyB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm0udGl0bGUgfHwgJ0Zvcm11bGlyIFRhbnBhIEp1ZHVsJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKGZvcm0uY3JlYXRlZEF0KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oCiIHtmb3JtLnJlc3BvbnNlQ291bnQgPz8gMH0gUmVzcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgJHtnZXRTdGF0dXNCYWRnZShmb3JtLnN0YXR1cyl9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRTdGF0dXNMYWJlbChmb3JtLnN0YXR1cyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9mb3Jtcy8ke2Zvcm0uaWR9L2VkaXRgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRWRpdCBGb3JtdWxpclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RWRpdDMgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2Zvcm1zLyR7Zm9ybS5pZH0vcmVzcG9uc2VzYCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtWyMwMDg5N0JdIGRhcms6aG92ZXI6dGV4dC10ZWFsLTQwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTGloYXQgUmVzcG9uc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyQ2hhcnQyIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEZXNrdG9wIFRhYmxlIFZpZXcgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpibG9jayBvdmVyZmxvdy14LWF1dG8gdy1mdWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIHRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS00IHB4LTZcIj5KdWR1bCBGb3JtdWxpcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTQgcHgtNlwiPlN0YXR1czwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTQgcHgtNlwiPkRpYnVhdDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTQgcHgtNlwiPlRvdGFsIFJlc3BvbnM8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS00IHB4LTYgdGV4dC1yaWdodFwiPkFrc2k8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRDcmVhdGVkLm1hcCgoZm9ybSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2Zvcm0uaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzQwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgcm91bmRlZC14bCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Zm9ybS50aXRsZSB8fCAnRm9ybXVsaXIgVGFucGEgSnVkdWwnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkICR7Z2V0U3RhdHVzQmFkZ2UoZm9ybS5zdGF0dXMpfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRTdGF0dXNMYWJlbChmb3JtLnN0YXR1cyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTYgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUoZm9ybS5jcmVhdGVkQXQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC02IGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybS5yZXNwb25zZUNvdW50ID8/IDB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTYgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9mb3Jtcy8ke2Zvcm0uaWR9L2VkaXRgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFZGl0IEZvcm11bGlyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0MyBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvZm9ybXMvJHtmb3JtLmlkfS9yZXNwb25zZXNgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1bIzAwODk3Ql0gZGFyazpob3Zlcjp0ZXh0LXRlYWwtNDAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkxpaGF0IFJlc3BvbnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhckNoYXJ0MiBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8L21haW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==