import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/ProtectedRoute.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { isAuthenticated } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ProtectedRoute.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
/**
* ProtectedRoute
* Membungkus route yang membutuhkan autentikasi.
* Jika user belum login (tidak ada token), redirect ke /login.
*/
export default function ProtectedRoute({ children }) {
	if (!isAuthenticated()) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/login",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 16
		}, this);
	}
	return children;
}
_c = ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/ProtectedRoute.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ProtectedRoute.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ProtectedRoute.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/ProtectedRoute.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx1QkFBdUI7Ozs7Ozs7O0FBT2hDLGVBQWUsU0FBUyxlQUFlLEVBQUUsWUFBWTtDQUNqRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUc7RUFDcEIsT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBRztHQUFTO0VBQVM7Ozs7O0NBQzFDO0NBQ0EsT0FBTztBQUNYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb3RlY3RlZFJvdXRlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgaXNBdXRoZW50aWNhdGVkIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5cbi8qKlxuICogUHJvdGVjdGVkUm91dGVcbiAqIE1lbWJ1bmdrdXMgcm91dGUgeWFuZyBtZW1idXR1aGthbiBhdXRlbnRpa2FzaS5cbiAqIEppa2EgdXNlciBiZWx1bSBsb2dpbiAodGlkYWsgYWRhIHRva2VuKSwgcmVkaXJlY3Qga2UgL2xvZ2luLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm90ZWN0ZWRSb3V0ZSh7IGNoaWxkcmVuIH0pIHtcbiAgICBpZiAoIWlzQXV0aGVudGljYXRlZCgpKSB7XG4gICAgICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIC8+O1xuICAgIH1cbiAgICByZXR1cm4gY2hpbGRyZW47XG59XG4iXX0=