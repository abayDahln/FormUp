import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboard/userDashboard/userhome.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { Plus, FileText, Users, CheckCircle2, Clock, Edit3, BarChart2, Sparkles, SearchX, ArrowRight, BookOpen, Compass, HelpCircle, ChevronDown } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import Topbar from "/src/components/layout/Topbar.jsx";
import AIFormBuilderModal from "/src/components/ui/AIFormBuilderModal.jsx";
import OnboardingTour from "/src/components/ui/OnboardingTour.jsx";
import UserGuideModal from "/src/components/ui/UserGuideModal.jsx";
import { getMyForms, getMyStats, getLocalUser, clearSession, assetUrl, createForm } from "/src/services/apiService.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/userhome.jsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const getGreeting = () => {
	const hour = new Date().getHours();
	if (hour < 11) return "Selamat Pagi";
	if (hour < 15) return "Selamat Siang";
	if (hour < 18) return "Selamat Sore";
	return "Selamat Malam";
};
const UserHome = () => {
	_s();
	const navigate = useNavigate();
	const [myForms, setMyForms] = useState([]);
	const [stats, setStats] = useState(null);
	const [loading, setLoading] = useState(true);
	const [user] = useState(() => getLocalUser());
	const [searchQuery, setSearchQuery] = useState("");
	const [creatingForm, setCreatingForm] = useState(false);
	const [aiFormBuilderOpen, setAiFormBuilderOpen] = useState(false);
	const [onboardingTourOpen, setOnboardingTourOpen] = useState(false);
	const [userGuideOpen, setUserGuideOpen] = useState(false);
	const [createDropdownOpen, setCreateDropdownOpen] = useState(false);
	const createDropdownRef = useRef(null);
	useEffect(() => {
		const handleClickOutside = (e) => {
			if (createDropdownRef.current && !createDropdownRef.current.contains(e.target)) {
				setCreateDropdownOpen(false);
			}
		};
		document.addEventListener("mousedown", handleClickOutside);
		return () => document.removeEventListener("mousedown", handleClickOutside);
	}, []);
	// Register global trigger for manual tour launch from Sidebar/Topbar
	useEffect(() => {
		window.__startFormUpTour = () => {
			setOnboardingTourOpen(true);
		};
		return () => {
			delete window.__startFormUpTour;
		};
	}, []);
	useEffect(() => {
		const fetchData = async () => {
			try {
				setLoading(true);
				const [formsResult, statsResult] = await Promise.all([getMyForms(), getMyStats().catch(() => null)]);
				if (formsResult.status === 401) {
					clearSession();
					navigate("/login");
					return;
				}
				if (formsResult.ok && Array.isArray(formsResult.data)) {
					setMyForms(formsResult.data);
				}
				if (statsResult?.ok && statsResult?.data) {
					setStats(statsResult.data);
				}
				// Cek apakah user baru (belum pernah menyelesaikan onboarding)
				const storageKey = `onboarding_completed_${user?.id || user?.email || "default"}`;
				const hasCompletedOnboarding = localStorage.getItem(storageKey);
				if (!hasCompletedOnboarding) {
					// Berikan sedikit jeda waktu render halaman dashboard sebelum tour muncul
					setTimeout(() => {
						setOnboardingTourOpen(true);
					}, 500);
				}
			} catch (err) {
				console.error("Dashboard fetch error:", err);
			} finally {
				setLoading(false);
			}
		};
		fetchData();
	}, [
		navigate,
		user?.id,
		user?.email
	]);
	const handleOnboardingComplete = () => {
		const storageKey = `onboarding_completed_${user?.id || user?.email || "default"}`;
		localStorage.setItem(storageKey, "true");
	};
	const handleGoToBuilderTour = async () => {
		handleOnboardingComplete();
		setOnboardingTourOpen(false);
		if (myForms && myForms.length > 0) {
			navigate(`/forms/${myForms[0].id}/edit?tour=builder`);
		} else {
			// Jika belum ada formulir, buat formulir draf contoh lalu mulai tur di Form Builder
			try {
				const res = await createForm({
					title: "Formulir Pertama Saya",
					description: "Formulir latihan panduan FormUp"
				});
				if (res.ok && res.data?.id) {
					navigate(`/forms/${res.data.id}/edit?tour=builder`);
				} else {
					navigate("/create-form");
				}
			} catch (err) {
				console.error("Error creating tour form:", err);
				navigate("/create-form");
			}
		}
	};
	const handleCreateNewForm = async () => {
		if (creatingForm) return;
		setCreatingForm(true);
		try {
			const res = await createForm({
				title: "Formulir Tanpa Judul",
				description: ""
			});
			if (res.status === 401) {
				clearSession();
				navigate("/login");
				return;
			}
			if (res.ok && res.data?.id) {
				navigate(`/forms/${res.data.id}/edit`);
			} else {
				navigate("/create-form");
			}
		} catch (err) {
			console.error("Error creating form:", err);
			navigate("/create-form");
		} finally {
			setCreatingForm(false);
		}
	};
	const totalResponses = myForms.reduce((acc, f) => acc + (f.responseCount ?? 0), 0);
	const publishedCount = myForms.filter((f) => f.status?.toLowerCase() === "published").length;
	const draftCount = myForms.filter((f) => f.status?.toLowerCase() === "draft").length;
	const filteredForms = myForms.filter((form) => {
		if (!searchQuery.trim()) return true;
		const q = searchQuery.toLowerCase();
		return form.title && form.title.toLowerCase().includes(q) || form.description && form.description.toLowerCase().includes(q) || form.status && form.status.toLowerCase().includes(q);
	});
	const recentForms = [...filteredForms].sort((a, b) => new Date(b.updatedAt ?? b.createdAt) - new Date(a.updatedAt ?? a.createdAt)).slice(0, 10);
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "flex min-h-screen w-full bg-slate-50 dark:bg-slate-950 font-sans antialiased text-slate-800 dark:text-slate-100",
			children: [/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 170,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col min-w-0 overflow-y-auto",
				children: /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 w-full p-4 sm:p-6 lg:p-8 space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV(Topbar, {
							searchQuery,
							onSearchChange: setSearchQuery
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "animate-pulse space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("div", { className: "h-7 bg-slate-200 dark:bg-slate-800 rounded-md w-56" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", { className: "h-4 bg-slate-200 dark:bg-slate-800 rounded-md w-72" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4",
							children: [
								1,
								2,
								3,
								4
							].map((i) => /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex items-center justify-between animate-pulse",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("div", { className: "h-3 bg-slate-200 dark:bg-slate-800 rounded w-16 sm:w-20" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("div", { className: "h-6 sm:h-7 bg-slate-200 dark:bg-slate-800 rounded w-10 sm:w-12" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 41
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 186,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("div", { className: "w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-200 dark:bg-slate-800 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 37
								}, this)]
							}, i, true, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 33
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { className: "h-5 bg-slate-200 dark:bg-slate-800 rounded w-36 animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4",
								children: [
									1,
									2,
									3,
									4,
									5
								].map((i) => /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden animate-pulse h-48 sm:h-64 flex flex-col justify-between p-4",
									children: /* @__PURE__ */ _jsxDEV("div", { className: "h-full bg-slate-200 dark:bg-slate-800 rounded-xl w-full" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 201,
										columnNumber: 41
									}, this)
								}, i, false, {
									fileName: _jsxFileName,
									lineNumber: 200,
									columnNumber: 37
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 21
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 172,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 169,
			columnNumber: 13
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen w-full bg-slate-50 dark:bg-slate-950 font-sans antialiased text-slate-900 dark:text-slate-100 transition-colors",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 214,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col min-w-0 overflow-y-auto",
				children: /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 w-full p-4 sm:p-6 lg:p-8 space-y-6 sm:space-y-8",
					children: [
						/* @__PURE__ */ _jsxDEV(Topbar, {
							searchQuery,
							onSearchChange: setSearchQuery,
							placeholder: "Cari formulir, status, atau deskripsi..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 219,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("h1", {
									className: "text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-50",
									children: [
										getGreeting(),
										", ",
										user?.fullname ? user.fullname.split(" ")[0] : "Pengguna"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 229,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV(Sparkles, {
									size: 18,
									className: "text-teal-600 dark:text-teal-400"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
								children: "Berikut ringkasan aktivitas dan performa formulir Anda."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 29
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 227,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								ref: createDropdownRef,
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setCreateDropdownOpen((prev) => !prev),
									"data-tour": "create-form-btn",
									className: "inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 dark:bg-teal-600 dark:hover:bg-teal-500 text-white text-xs font-semibold rounded-xl shadow-xs transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 245,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "Buat Formulir" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 246,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV(ChevronDown, {
											size: 14,
											className: `transition-transform duration-200 ${createDropdownOpen ? "rotate-180" : ""}`
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 247,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 240,
									columnNumber: 29
								}, this), createDropdownOpen && /* @__PURE__ */ _jsxDEV("div", {
									className: "absolute right-0 top-full mt-1 w-52 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl z-50 overflow-hidden",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setCreateDropdownOpen(false);
											handleCreateNewForm();
										},
										disabled: creatingForm,
										className: "w-full flex items-center gap-3 px-4 py-3 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer text-left",
										children: [/* @__PURE__ */ _jsxDEV(Plus, {
											size: 15,
											className: "text-slate-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 256,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", { children: "Buat Manual" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 258,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] font-normal text-slate-400",
											children: "Mulai dari formulir kosong"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 259,
											columnNumber: 45
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 257,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 251,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setCreateDropdownOpen(false);
											setAiFormBuilderOpen(true);
										},
										"data-tour": "create-ai-btn",
										className: "w-full flex items-center gap-3 px-4 py-3 text-xs font-bold text-teal-700 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/30 transition-colors cursor-pointer text-left",
										children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
											size: 15,
											className: "text-teal-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 267,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", { children: "Buat dengan AI ✨" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 269,
											columnNumber: 45
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] font-normal text-slate-400",
											children: "Generate otomatis dengan AI"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 270,
											columnNumber: 45
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 268,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 262,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 250,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 239,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 21
						}, this),
						(() => {
							const totalFormCount = stats?.totalForms ?? stats?.formsCount ?? myForms.length;
							const totalResponses = stats?.totalResponses ?? stats?.responsesCount ?? myForms.reduce((acc, f) => acc + (f.responseCount || f.responsesCount || 0), 0);
							const publishedCount = stats?.publishedForms ?? stats?.publishedCount ?? myForms.filter((f) => (f.status || "").toLowerCase() === "published" || f.isPublished).length;
							const draftCount = stats?.draftForms ?? stats?.draftCount ?? myForms.filter((f) => (f.status || "").toLowerCase() === "draft" || !f.isPublished).length;
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4",
								"data-tour": "stats-overview",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 p-3.5 sm:p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-2xs flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] sm:text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-0.5",
											children: "Total Formulir"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 289,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("h3", {
											className: "text-xl sm:text-2xl font-bold text-slate-900 dark:text-white",
											children: totalFormCount
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 290,
											columnNumber: 41
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 288,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 sm:p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400",
											children: /* @__PURE__ */ _jsxDEV(FileText, {
												size: 18,
												className: "sm:w-5 sm:h-5"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 293,
												columnNumber: 41
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 292,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 287,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 p-3.5 sm:p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-2xs flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] sm:text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-0.5",
											children: "Total Respons"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 299,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("h3", {
											className: "text-xl sm:text-2xl font-bold text-slate-900 dark:text-white",
											children: totalResponses
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 300,
											columnNumber: 41
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 298,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 sm:p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400",
											children: /* @__PURE__ */ _jsxDEV(Users, {
												size: 18,
												className: "sm:w-5 sm:h-5"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 303,
												columnNumber: 41
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 302,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 297,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 p-3.5 sm:p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-2xs flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] sm:text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-0.5",
											children: "Dipublikasikan"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 309,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("h3", {
											className: "text-xl sm:text-2xl font-bold text-slate-900 dark:text-white",
											children: publishedCount
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 310,
											columnNumber: 41
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 308,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 sm:p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400",
											children: /* @__PURE__ */ _jsxDEV(CheckCircle2, {
												size: 18,
												className: "sm:w-5 sm:h-5"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 313,
												columnNumber: 41
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 312,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 33
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white dark:bg-slate-900 p-3.5 sm:p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-2xs flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] sm:text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-0.5",
											children: "Draf"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 319,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("h3", {
											className: "text-xl sm:text-2xl font-bold text-slate-900 dark:text-white",
											children: draftCount
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 320,
											columnNumber: 41
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 318,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 sm:p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400",
											children: /* @__PURE__ */ _jsxDEV(Clock, {
												size: 18,
												className: "sm:w-5 sm:h-5"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 323,
												columnNumber: 41
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 322,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 286,
								columnNumber: 29
							}, this);
						})(),
						/* @__PURE__ */ _jsxDEV("section", {
							className: "space-y-4",
							"data-tour": "recent-forms-section",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-base font-bold text-slate-900 dark:text-white",
										children: "Formulir Terbaru"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 334,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-500 dark:text-slate-400",
										children: searchQuery ? `Hasil pencarian untuk "${searchQuery}"` : "Formulir yang terakhir kali diubah"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 335,
										columnNumber: 33
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 333,
										columnNumber: 29
									}, this), myForms.length > 0 && /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => navigate("/my-forms"),
										className: "inline-flex items-center gap-1 text-xs font-semibold text-teal-600 dark:text-teal-400 hover:text-teal-700 dark:hover:text-teal-300 transition-colors cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Lihat semua" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 345,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 340,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 332,
									columnNumber: 25
								}, this),
								myForms.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 rounded-3xl border-2 border-dashed border-teal-200/80 dark:border-teal-900/40 p-8 sm:p-12 text-center flex flex-col items-center justify-center space-y-5 shadow-xs transition-all hover:border-teal-400",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-tr from-teal-500/20 via-emerald-500/10 to-teal-100 dark:from-teal-900/40 dark:to-slate-800 flex items-center justify-center text-[#00897B] dark:text-teal-400 shadow-inner",
												children: /* @__PURE__ */ _jsxDEV(FileText, {
													size: 36,
													className: "transform -rotate-6"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 356,
													columnNumber: 41
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 355,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "absolute -top-1.5 -right-1.5 w-7 h-7 rounded-full bg-gradient-to-r from-teal-600 to-emerald-500 text-white flex items-center justify-center shadow-md animate-bounce",
												children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 14 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 359,
													columnNumber: 41
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 358,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 354,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1.5 max-w-md",
											children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight",
												children: "Belum Ada Formulir Nih"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 365,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed font-medium",
												children: "Buat formulir atau kuis pertamamu sekarang! Anda bisa membuatnya secara manual atau gunakan kecerdasan AI untuk menyusunnya otomatis dalam sekejap."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 368,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 364,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto pt-2",
											children: [/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: handleCreateNewForm,
												disabled: creatingForm,
												className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 bg-teal-600 hover:bg-teal-700 dark:bg-teal-600 dark:hover:bg-teal-500 text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-95 cursor-pointer disabled:opacity-60",
												children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 381,
													columnNumber: 41
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: creatingForm ? "Membuat..." : "Buat Formulir Pertama" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 382,
													columnNumber: 41
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 375,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setAiFormBuilderOpen(true),
												className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 bg-gradient-to-r from-teal-500/10 to-emerald-500/10 hover:from-teal-500/20 hover:to-emerald-500/20 text-[#00897B] dark:text-teal-400 border border-teal-500/30 text-xs font-bold rounded-xl transition-all active:scale-95 cursor-pointer",
												children: [/* @__PURE__ */ _jsxDEV(Sparkles, { size: 15 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 390,
													columnNumber: 41
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Coba AI Form Builder" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 391,
													columnNumber: 41
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 385,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 374,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setUserGuideOpen(true),
											className: "inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 transition-colors cursor-pointer pt-2",
											children: [/* @__PURE__ */ _jsxDEV(BookOpen, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 401,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Butuh panduan? Pelajari cara pakai FormUp" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 402,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 396,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 352,
									columnNumber: 29
								}, this) : 
								/* Responsive Grid: Menyamping di HP, Grid fleksibel 3-5 kolom di Desktop */
/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4",
									children: recentForms.map((form) => {
										const status = typeof form.status === "string" ? form.status : "draft";
										const isPublished = status.toLowerCase() === "published";
										const responseCount = form.responseCount ?? 0;
										return /* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:border-slate-300 dark:hover:border-slate-700 transition-all duration-200 flex flex-row sm:flex-col justify-between overflow-hidden group hover:-translate-y-0.5",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "w-28 xs:w-32 sm:w-full h-auto sm:h-36 relative overflow-hidden bg-slate-100 dark:bg-slate-800/50 flex shrink-0 items-center justify-center border-r sm:border-r-0 sm:border-b border-slate-100 dark:border-slate-800",
												children: [form.bannerImage ? /* @__PURE__ */ _jsxDEV("img", {
													src: assetUrl(form.bannerImage),
													alt: form.title,
													className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 421,
													columnNumber: 53
												}, this) : /* @__PURE__ */ _jsxDEV("div", {
													className: "flex flex-col items-center justify-center gap-1 text-slate-400 dark:text-slate-600",
													children: /* @__PURE__ */ _jsxDEV(FileText, { size: 24 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 428,
														columnNumber: 57
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 427,
													columnNumber: 53
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: `absolute top-2.5 left-2.5 text-[9px] sm:text-[10px] font-semibold px-2 py-0.5 rounded-md uppercase tracking-wider backdrop-blur-md ${isPublished ? "bg-emerald-500/90 text-white" : "bg-slate-900/70 text-slate-200"}`,
													children: isPublished ? "Dipublikasikan" : "Draf"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 432,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 419,
												columnNumber: 45
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "p-3.5 sm:p-4 flex-1 flex flex-col justify-between space-y-3 min-w-0",
												children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
													className: "text-sm font-bold text-slate-900 dark:text-slate-100 truncate group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors",
													children: form.title || "Formulir Tanpa Judul"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 444,
													columnNumber: 53
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-between mt-1.5 text-xs text-slate-500 dark:text-slate-400",
													children: [/* @__PURE__ */ _jsxDEV("span", { children: [responseCount, " respons"] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 448,
														columnNumber: 57
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: form.createdAt ? new Date(form.createdAt).toLocaleDateString("id-ID", {
														month: "short",
														day: "numeric"
													}) : "" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 449,
														columnNumber: 57
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 447,
													columnNumber: 53
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 443,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2 pt-2.5 border-t border-slate-100 dark:border-slate-800/80",
													children: [/* @__PURE__ */ _jsxDEV("button", {
														onClick: () => navigate(`/forms/${form.id}/edit`),
														className: "flex-1 py-1.5 px-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 font-medium text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 border border-slate-200/60 dark:border-slate-700/60 cursor-pointer",
														children: [/* @__PURE__ */ _jsxDEV(Edit3, { size: 13 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 461,
															columnNumber: 57
														}, this), " Edit"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 457,
														columnNumber: 53
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														onClick: () => navigate(`/forms/${form.id}/responses`),
														className: "flex-1 py-1.5 px-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 font-medium text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 border border-slate-200/60 dark:border-slate-700/60 cursor-pointer",
														children: [/* @__PURE__ */ _jsxDEV(BarChart2, { size: 13 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 467,
															columnNumber: 57
														}, this), " Respons"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 463,
														columnNumber: 53
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 456,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 442,
												columnNumber: 45
											}, this)]
										}, form.id, true, {
											fileName: _jsxFileName,
											lineNumber: 414,
											columnNumber: 41
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 407,
									columnNumber: 29
								}, this),
								recentForms.length === 0 && searchQuery && myForms.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
									className: "py-12 text-center flex flex-col items-center justify-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800",
									children: [
										/* @__PURE__ */ _jsxDEV(SearchX, {
											size: 32,
											className: "text-slate-300 dark:text-slate-600 mb-2"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 480,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
											children: "Hasil tidak ditemukan"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 481,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400 dark:text-slate-500 mt-1",
											children: [
												"Tidak ada formulir yang cocok dengan kata kunci \"",
												searchQuery,
												"\"."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 482,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 479,
									columnNumber: 29
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 331,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 218,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 216,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(AIFormBuilderModal, {
				isOpen: aiFormBuilderOpen,
				onClose: () => setAiFormBuilderOpen(false),
				onFormCreated: (newId) => navigate(`/forms/${newId}/edit`)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 493,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(OnboardingTour, {
				isOpen: onboardingTourOpen,
				onClose: () => setOnboardingTourOpen(false),
				onComplete: handleOnboardingComplete,
				steps: [
					{
						selector: "[data-tour=\"create-form-btn\"]",
						title: "Buat Formulir Baru",
						description: "Klik di sini untuk langsung membuat formulir kosong. Anda dapat menambahkan aneka tipe soal pilihan ganda, essay, rumus matematika, dan kunci jawaban.",
						icon: /* @__PURE__ */ _jsxDEV(Plus, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 509,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Mulai Cepat"
					},
					{
						selector: "[data-tour=\"create-ai-btn\"]",
						title: "Kecerdasan Buat Form AI",
						description: "Cukup deskripsikan topik atau materi kuis Anda, AI FormUp akan otomatis merancang pertanyaan dan opsi kunci jawaban lengkap untuk Anda!",
						icon: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 517,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Kecerdasan AI",
						action: () => setCreateDropdownOpen(true)
					},
					{
						selector: "[data-tour=\"stats-overview\"]",
						title: "Ringkasan Aktivitas Real-Time",
						description: "Pantau total formulir, jumlah responden yang telah mengisi, serta status formulir aktif maupun draf Anda di sini.",
						icon: /* @__PURE__ */ _jsxDEV(BarChart2, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 526,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Statistik"
					},
					{
						selector: "[data-tour=\"recent-forms-section\"]",
						title: "Daftar Formulir & Aksi Cepat",
						description: "Kelola formulir Anda dengan mudah. Anda dapat langsung mengedit pertanyaan, menyalin link, atau memeriksa evaluasi respons masuk kapan saja.",
						icon: /* @__PURE__ */ _jsxDEV(FileText, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 534,
							columnNumber: 31
						}, this),
						placement: "top",
						badge: "Koleksi Form"
					},
					{
						selector: "[data-tour=\"create-form-btn\"]",
						title: "Lanjut ke Panduan Form Builder?",
						description: "Eksplorasi cara menyusun pertanyaan kuis, rumus matematika KaTeX, batasan timer pengerjaan, dan Mode Ujian Anti-Curang langsung di editor Form Builder.",
						icon: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 542,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Langkah Lanjutan",
						nextBtnText: "Selesai di Dashboard",
						actionButton: {
							text: "Buka Form Builder & Lanjut Panduan →",
							icon: /* @__PURE__ */ _jsxDEV(Compass, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 548,
								columnNumber: 35
							}, this),
							onClick: handleGoToBuilderTour
						}
					}
				]
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 500,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(UserGuideModal, {
				isOpen: userGuideOpen,
				onClose: () => setUserGuideOpen(false),
				onStartTour: () => {
					setUserGuideOpen(false);
					setOnboardingTourOpen(true);
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 556,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 213,
		columnNumber: 9
	}, this);
};
_s(UserHome, "1+HMsO4e7epD2QyKvf1ezsySQwI=", false, function() {
	return [useNavigate];
});
_c = UserHome;
export default UserHome;
var _c;
$RefreshReg$(_c, "UserHome");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/dashboard/userDashboard/userhome.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/userhome.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/userhome.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/userhome.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsY0FBYztBQUM1QyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLE1BQU0sVUFBVSxPQUFPLGNBQWMsT0FBTyxPQUFPLFdBQVcsVUFBVSxTQUFTLFlBQVksVUFBVSxTQUFTLFlBQVksbUJBQW1CO0FBQ3hKLE9BQU8sYUFBYTtBQUNwQixPQUFPLFlBQVk7QUFDbkIsT0FBTyx3QkFBd0I7QUFDL0IsT0FBTyxvQkFBb0I7QUFDM0IsT0FBTyxvQkFBb0I7QUFDM0IsU0FBUyxZQUFZLFlBQVksY0FBYyxjQUFjLFVBQVUsa0JBQWtCOzs7O0FBRXpGLE1BQU0sb0JBQW9CO0NBQ3RCLE1BQU0sT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLFNBQVM7Q0FDakMsSUFBSSxPQUFPLElBQUksT0FBTztDQUN0QixJQUFJLE9BQU8sSUFBSSxPQUFPO0NBQ3RCLElBQUksT0FBTyxJQUFJLE9BQU87Q0FDdEIsT0FBTztBQUNYO0FBRUEsTUFBTSxpQkFBaUI7O0NBQ25CLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxDQUFDLENBQUM7Q0FDekMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLFFBQVEsZUFBZSxhQUFhLENBQUM7Q0FDNUMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsS0FBSztDQUNoRSxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLEtBQUs7Q0FDbEUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUN4RCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLEtBQUs7Q0FDbEUsTUFBTSxvQkFBb0IsT0FBTyxJQUFJO0NBRXJDLGdCQUFnQjtFQUNaLE1BQU0sc0JBQXNCLE1BQU07R0FDOUIsSUFBSSxrQkFBa0IsV0FBVyxDQUFDLGtCQUFrQixRQUFRLFNBQVMsRUFBRSxNQUFNLEdBQUc7SUFDNUUsc0JBQXNCLEtBQUs7R0FDL0I7RUFDSjtFQUNBLFNBQVMsaUJBQWlCLGFBQWEsa0JBQWtCO0VBQ3pELGFBQWEsU0FBUyxvQkFBb0IsYUFBYSxrQkFBa0I7Q0FDN0UsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ1osT0FBTywwQkFBMEI7R0FDN0Isc0JBQXNCLElBQUk7RUFDOUI7RUFDQSxhQUFhO0dBQ1QsT0FBTyxPQUFPO0VBQ2xCO0NBQ0osR0FBRyxDQUFDLENBQUM7Q0FFTCxnQkFBZ0I7RUFDWixNQUFNLFlBQVksWUFBWTtHQUMxQixJQUFJO0lBQ0EsV0FBVyxJQUFJO0lBQ2YsTUFBTSxDQUFDLGFBQWEsZUFBZSxNQUFNLFFBQVEsSUFBSSxDQUNqRCxXQUFXLEdBQ1gsV0FBVyxDQUFDLENBQUMsWUFBWSxJQUFJLENBQ2pDLENBQUM7SUFFRCxJQUFJLFlBQVksV0FBVyxLQUFLO0tBQzVCLGFBQWE7S0FDYixTQUFTLFFBQVE7S0FDakI7SUFDSjtJQUVBLElBQUksWUFBWSxNQUFNLE1BQU0sUUFBUSxZQUFZLElBQUksR0FBRztLQUNuRCxXQUFXLFlBQVksSUFBSTtJQUMvQjtJQUNBLElBQUksYUFBYSxNQUFNLGFBQWEsTUFBTTtLQUN0QyxTQUFTLFlBQVksSUFBSTtJQUM3Qjs7SUFHQSxNQUFNLGFBQWEsd0JBQXdCLE1BQU0sTUFBTSxNQUFNLFNBQVM7SUFDdEUsTUFBTSx5QkFBeUIsYUFBYSxRQUFRLFVBQVU7SUFDOUQsSUFBSSxDQUFDLHdCQUF3Qjs7S0FFekIsaUJBQWlCO01BQ2Isc0JBQXNCLElBQUk7S0FDOUIsR0FBRyxHQUFHO0lBQ1Y7R0FDSixTQUFTLEtBQUs7SUFDVixRQUFRLE1BQU0sMEJBQTBCLEdBQUc7R0FDL0MsVUFBVTtJQUNOLFdBQVcsS0FBSztHQUNwQjtFQUNKO0VBRUEsVUFBVTtDQUNkLEdBQUc7RUFBQztFQUFVLE1BQU07RUFBSSxNQUFNO0NBQUssQ0FBQztDQUVwQyxNQUFNLGlDQUFpQztFQUNuQyxNQUFNLGFBQWEsd0JBQXdCLE1BQU0sTUFBTSxNQUFNLFNBQVM7RUFDdEUsYUFBYSxRQUFRLFlBQVksTUFBTTtDQUMzQztDQUVBLE1BQU0sd0JBQXdCLFlBQVk7RUFDdEMseUJBQXlCO0VBQ3pCLHNCQUFzQixLQUFLO0VBQzNCLElBQUksV0FBVyxRQUFRLFNBQVMsR0FBRztHQUMvQixTQUFTLFVBQVUsUUFBUSxFQUFFLENBQUMsR0FBRyxtQkFBbUI7RUFDeEQsT0FBTzs7R0FFSCxJQUFJO0lBQ0EsTUFBTSxNQUFNLE1BQU0sV0FBVztLQUN6QixPQUFPO0tBQ1AsYUFBYTtJQUNqQixDQUFDO0lBQ0QsSUFBSSxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUk7S0FDeEIsU0FBUyxVQUFVLElBQUksS0FBSyxHQUFHLG1CQUFtQjtJQUN0RCxPQUFPO0tBQ0gsU0FBUyxjQUFjO0lBQzNCO0dBQ0osU0FBUyxLQUFLO0lBQ1YsUUFBUSxNQUFNLDZCQUE2QixHQUFHO0lBQzlDLFNBQVMsY0FBYztHQUMzQjtFQUNKO0NBQ0o7Q0FFQSxNQUFNLHNCQUFzQixZQUFZO0VBQ3BDLElBQUksY0FBYztFQUNsQixnQkFBZ0IsSUFBSTtFQUNwQixJQUFJO0dBQ0EsTUFBTSxNQUFNLE1BQU0sV0FBVztJQUN6QixPQUFPO0lBQ1AsYUFBYTtHQUNqQixDQUFDO0dBQ0QsSUFBSSxJQUFJLFdBQVcsS0FBSztJQUNwQixhQUFhO0lBQ2IsU0FBUyxRQUFRO0lBQ2pCO0dBQ0o7R0FDQSxJQUFJLElBQUksTUFBTSxJQUFJLE1BQU0sSUFBSTtJQUN4QixTQUFTLFVBQVUsSUFBSSxLQUFLLEdBQUcsTUFBTTtHQUN6QyxPQUFPO0lBQ0gsU0FBUyxjQUFjO0dBQzNCO0VBQ0osU0FBUyxLQUFLO0dBQ1YsUUFBUSxNQUFNLHdCQUF3QixHQUFHO0dBQ3pDLFNBQVMsY0FBYztFQUMzQixVQUFVO0dBQ04sZ0JBQWdCLEtBQUs7RUFDekI7Q0FDSjtDQUVBLE1BQU0saUJBQWlCLFFBQVEsUUFBUSxLQUFLLE1BQU0sT0FBTyxFQUFFLGlCQUFpQixJQUFJLENBQUM7Q0FDakYsTUFBTSxpQkFBaUIsUUFBUSxRQUFPLE1BQUssRUFBRSxRQUFRLFlBQVksTUFBTSxXQUFXLENBQUMsQ0FBQztDQUNwRixNQUFNLGFBQWEsUUFBUSxRQUFPLE1BQUssRUFBRSxRQUFRLFlBQVksTUFBTSxPQUFPLENBQUMsQ0FBQztDQUU1RSxNQUFNLGdCQUFnQixRQUFRLFFBQU8sU0FBUTtFQUN6QyxJQUFJLENBQUMsWUFBWSxLQUFLLEdBQUcsT0FBTztFQUNoQyxNQUFNLElBQUksWUFBWSxZQUFZO0VBQ2xDLE9BQ0ssS0FBSyxTQUFTLEtBQUssTUFBTSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDakQsS0FBSyxlQUFlLEtBQUssWUFBWSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDN0QsS0FBSyxVQUFVLEtBQUssT0FBTyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUM7Q0FFNUQsQ0FBQztDQUVELE1BQU0sY0FBYyxDQUFDLEdBQUcsYUFBYSxDQUFDLENBQ2pDLE1BQU0sR0FBRyxNQUFNLElBQUksS0FBSyxFQUFFLGFBQWEsRUFBRSxTQUFTLElBQUksSUFBSSxLQUFLLEVBQUUsYUFBYSxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQzNGLE1BQU0sR0FBRyxFQUFFO0NBRWhCLElBQUksU0FBUztFQUNULE9BQ0ksd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNJLHdCQUFDLFNBQUQsQ0FBVTs7OzthQUVWLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1gsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEI7TUFDSSx3QkFBQyxRQUFEO09BQXFCO09BQWEsZ0JBQWdCO01BQWlCOzs7OztNQUduRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHFEQUEwRDs7OztpQkFDekUsd0JBQUMsT0FBRCxFQUFLLFdBQVUscURBQTBEOzs7O2VBQ3hFOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDVjtRQUFDO1FBQUc7UUFBRztRQUFHO09BQUMsQ0FBQyxDQUFDLEtBQUssTUFDZix3QkFBQyxPQUFEO1FBQWEsV0FBVTtrQkFBdkIsQ0FDSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDBEQUErRDs7OzttQkFDOUUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsaUVBQXNFOzs7O2lCQUNwRjs7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxFQUFLLFdBQVUsNkVBQWtGOzs7O2dCQUNoRztVQU5LOzs7O2NBTUwsQ0FDUjtNQUNBOzs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsT0FBRCxFQUFLLFdBQVUsZ0VBQXFFOzs7O2lCQUNwRix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDVjtTQUFDO1NBQUc7U0FBRztTQUFHO1NBQUc7UUFBQyxDQUFDLENBQUMsS0FBSyxNQUNsQix3QkFBQyxPQUFEO1NBQWEsV0FBVTttQkFDbkIsd0JBQUMsT0FBRCxFQUFLLFdBQVUsMERBQStEOzs7OztRQUM3RSxHQUZLOzs7O2VBRUwsQ0FDUjtPQUNBOzs7O2VBQ0o7Ozs7OztLQUNIOzs7Ozs7R0FDTDs7OztXQUNKOzs7Ozs7Q0FFYjtDQUVBLE9BQ0ksd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNJLHdCQUFDLFNBQUQsQ0FBVTs7Ozs7R0FFVix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUVYLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCO01BQ0ksd0JBQUMsUUFBRDtPQUNpQjtPQUNiLGdCQUFnQjtPQUNoQixhQUFZO01BQ2Y7Ozs7O01BR0Qsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZDtVQUNLLFlBQVk7VUFBRTtVQUFHLE1BQU0sV0FBVyxLQUFLLFNBQVMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLO1NBQ2pFOzs7OztrQkFDSix3QkFBQyxVQUFEO1NBQVUsTUFBTTtTQUFJLFdBQVU7UUFBb0M7Ozs7Z0JBQ2pFOzs7OztpQkFDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBb0Q7T0FFOUQ7Ozs7ZUFDRjs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFXLEtBQUs7a0JBQS9CLENBQ0ksd0JBQUMsVUFBRDtTQUNJLGVBQWUsdUJBQXNCLFNBQVEsQ0FBQyxJQUFJO1NBQ2xELGFBQVU7U0FDVixXQUFVO21CQUhkO1VBS0ksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7VUFDakIsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7Ozs7VUFDekIsd0JBQUMsYUFBRDtXQUFhLE1BQU07V0FBSSxXQUFXLHFDQUFxQyxxQkFBcUIsZUFBZTtVQUFPOzs7OztTQUM5Rzs7Ozs7a0JBQ1Asc0JBQ0csd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxVQUFEO1VBQ0ksZUFBZTtXQUFFLHNCQUFzQixLQUFLO1dBQUcsb0JBQW9CO1VBQUc7VUFDdEUsVUFBVTtVQUNWLFdBQVU7b0JBSGQsQ0FLSSx3QkFBQyxNQUFEO1dBQU0sTUFBTTtXQUFJLFdBQVU7VUFBa0I7Ozs7b0JBQzVDLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxPQUFELFlBQUssY0FBZ0I7Ozs7b0JBQ3JCLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUF5QztVQUErQjs7OztrQkFDdEY7Ozs7a0JBQ0Q7Ozs7O21CQUNSLHdCQUFDLFVBQUQ7VUFDSSxlQUFlO1dBQUUsc0JBQXNCLEtBQUs7V0FBRyxxQkFBcUIsSUFBSTtVQUFHO1VBQzNFLGFBQVU7VUFDVixXQUFVO29CQUhkLENBS0ksd0JBQUMsVUFBRDtXQUFVLE1BQU07V0FBSSxXQUFVO1VBQWlCOzs7O29CQUMvQyx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsT0FBRCxZQUFLLG1CQUFxQjs7OztvQkFDMUIsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQXlDO1VBQWdDOzs7O2tCQUN2Rjs7OztrQkFDRDs7Ozs7aUJBQ1A7Ozs7O2dCQUVSOzs7OztlQUNKOzs7Ozs7YUFHRztPQUNKLE1BQU0saUJBQWlCLE9BQU8sY0FBYyxPQUFPLGNBQWMsUUFBUTtPQUN6RSxNQUFNLGlCQUFpQixPQUFPLGtCQUFrQixPQUFPLGtCQUFrQixRQUFRLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxrQkFBa0IsSUFBSSxDQUFDO09BQ3ZKLE1BQU0saUJBQWlCLE9BQU8sa0JBQWtCLE9BQU8sa0JBQWtCLFFBQVEsUUFBTyxPQUFNLEVBQUUsVUFBVSxHQUFFLENBQUUsWUFBWSxNQUFNLGVBQWUsRUFBRSxXQUFXLENBQUMsQ0FBQztPQUM5SixNQUFNLGFBQWEsT0FBTyxjQUFjLE9BQU8sY0FBYyxRQUFRLFFBQU8sT0FBTSxFQUFFLFVBQVUsR0FBRSxDQUFFLFlBQVksTUFBTSxXQUFXLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztPQUUvSSxPQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQWlELGFBQVU7a0JBQTFFO1NBQ0ksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQThHO1VBQWlCOzs7O29CQUM1SSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBZ0U7VUFBbUI7Ozs7a0JBQ2hHOzs7O29CQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNYLHdCQUFDLFVBQUQ7WUFBVSxNQUFNO1lBQUksV0FBVTtXQUFpQjs7Ozs7VUFDOUM7Ozs7a0JBQ0o7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUE4RztVQUFnQjs7OztvQkFDM0ksd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWdFO1VBQW1COzs7O2tCQUNoRzs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWCx3QkFBQyxPQUFEO1lBQU8sTUFBTTtZQUFJLFdBQVU7V0FBaUI7Ozs7O1VBQzNDOzs7O2tCQUNKOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBOEc7VUFBaUI7Ozs7b0JBQzVJLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFnRTtVQUFtQjs7OztrQkFDaEc7Ozs7b0JBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1gsd0JBQUMsY0FBRDtZQUFjLE1BQU07WUFBSSxXQUFVO1dBQWlCOzs7OztVQUNsRDs7OztrQkFDSjs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQThHO1VBQU87Ozs7b0JBQ2xJLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFnRTtVQUFlOzs7O2tCQUM1Rjs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWCx3QkFBQyxPQUFEO1lBQU8sTUFBTTtZQUFJLFdBQVU7V0FBaUI7Ozs7O1VBQzNDOzs7O2tCQUNKOzs7Ozs7UUFDSjs7Ozs7O01BRWIsRUFBQyxDQUFFO01BR0gsd0JBQUMsV0FBRDtPQUFTLFdBQVU7T0FBWSxhQUFVO2lCQUF6QztRQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFxRDtTQUFvQjs7OzttQkFDdkYsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQ1IsY0FBYywwQkFBMEIsWUFBWSxLQUFLO1NBQzNEOzs7O2lCQUNGOzs7O21CQUNKLFFBQVEsU0FBUyxLQUNkLHdCQUFDLFVBQUQ7VUFDSSxlQUFlLFNBQVMsV0FBVztVQUNuQyxXQUFVO29CQUZkLENBSUksd0JBQUMsUUFBRCxZQUFNLGNBQWlCOzs7O29CQUN2Qix3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7O2tCQUNuQjs7Ozs7aUJBRVg7Ozs7OztRQUdKLFFBQVEsV0FBVyxJQUNoQix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUVJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ1gsd0JBQUMsVUFBRDthQUFVLE1BQU07YUFBSSxXQUFVO1lBQXVCOzs7OztXQUNwRDs7OztxQkFDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDWCx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztXQUNwQjs7OzttQkFDSjs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBa0Y7V0FFNUY7Ozs7cUJBQ0osd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQW9GO1dBRTlGOzs7O21CQUNGOzs7Ozs7VUFHTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLFVBQUQ7WUFDSSxNQUFLO1lBQ0wsU0FBUztZQUNULFVBQVU7WUFDVixXQUFVO3NCQUpkLENBTUksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OztzQkFDakIsd0JBQUMsUUFBRCxZQUFPLGVBQWUsZUFBZSx3QkFBOEI7Ozs7b0JBQy9EOzs7OztxQkFFUix3QkFBQyxVQUFEO1lBQ0ksTUFBSztZQUNMLGVBQWUscUJBQXFCLElBQUk7WUFDeEMsV0FBVTtzQkFIZCxDQUtJLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7c0JBQ3JCLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7b0JBQzVCOzs7OzttQkFDUDs7Ozs7O1VBR0wsd0JBQUMsVUFBRDtXQUNJLE1BQUs7V0FDTCxlQUFlLGlCQUFpQixJQUFJO1dBQ3BDLFdBQVU7cUJBSGQsQ0FLSSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7O3FCQUNyQix3QkFBQyxRQUFELFlBQU0sNENBQStDOzs7O21CQUNqRDs7Ozs7O1NBQ1A7Ozs7Ozs7QUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDVixZQUFZLEtBQUssU0FBUztVQUN2QixNQUFNLFNBQVMsT0FBTyxLQUFLLFdBQVcsV0FBVyxLQUFLLFNBQVM7VUFDL0QsTUFBTSxjQUFjLE9BQU8sWUFBWSxNQUFNO1VBQzdDLE1BQU0sZ0JBQWdCLEtBQUssaUJBQWlCO1VBRTVDLE9BQ0ksd0JBQUMsT0FBRDtXQUVJLFdBQVU7cUJBRmQsQ0FLSSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNLLEtBQUssY0FDRix3QkFBQyxPQUFEO2FBQ0ksS0FBSyxTQUFTLEtBQUssV0FBVzthQUM5QixLQUFLLEtBQUs7YUFDVixXQUFVO1lBQ2I7Ozs7dUJBRUQsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQ1gsd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7WUFDcEI7Ozs7c0JBR1Qsd0JBQUMsUUFBRDthQUFNLFdBQVcsc0lBQ2IsY0FDTSxpQ0FDQTt1QkFFTCxjQUFjLG1CQUFtQjtZQUNoQzs7OztvQkFDTDs7Ozs7cUJBR0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1QsS0FBSyxTQUFTO1lBQ2Y7Ozs7c0JBQ0osd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDSSx3QkFBQyxRQUFELGFBQU8sZUFBYyxVQUFjOzs7O3VCQUNuQyx3QkFBQyxRQUFELFlBQ0ssS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLG1CQUFtQixTQUFTO2NBQUUsT0FBTztjQUFTLEtBQUs7YUFBVSxDQUFDLElBQUksR0FDM0c7Ozs7cUJBQ0w7Ozs7O29CQUNKOzs7O3NCQUdMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsVUFBRDtjQUNJLGVBQWUsU0FBUyxVQUFVLEtBQUssR0FBRyxNQUFNO2NBQ2hELFdBQVU7d0JBRmQsQ0FJSSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7O3dCQUFDLE9BQ2Y7Ozs7O3VCQUNSLHdCQUFDLFVBQUQ7Y0FDSSxlQUFlLFNBQVMsVUFBVSxLQUFLLEdBQUcsV0FBVztjQUNyRCxXQUFVO3dCQUZkLENBSUksd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozt3QkFBQyxVQUNuQjs7Ozs7cUJBQ1A7Ozs7O29CQUNKOzs7OzttQkFDSjthQXhESSxLQUFLOzs7O2lCQXdEVDtTQUViLENBQUM7UUFDQTs7Ozs7UUFJUixZQUFZLFdBQVcsS0FBSyxlQUFlLFFBQVEsU0FBUyxLQUN6RCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNJLHdCQUFDLFNBQUQ7V0FBUyxNQUFNO1dBQUksV0FBVTtVQUEyQzs7Ozs7VUFDeEUsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQTJEO1VBQXdCOzs7OztVQUNoRyx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUErRDtZQUNUO1lBQVk7V0FDL0Q7Ozs7OztTQUNGOzs7Ozs7T0FFSjs7Ozs7O0tBRVA7Ozs7OztHQUNMOzs7OztHQUdMLHdCQUFDLG9CQUFEO0lBQ0ksUUFBUTtJQUNSLGVBQWUscUJBQXFCLEtBQUs7SUFDekMsZ0JBQWdCLFVBQVUsU0FBUyxVQUFVLE1BQU0sTUFBTTtHQUM1RDs7Ozs7R0FHRCx3QkFBQyxnQkFBRDtJQUNJLFFBQVE7SUFDUixlQUFlLHNCQUFzQixLQUFLO0lBQzFDLFlBQVk7SUFDWixPQUFPO0tBQ0g7TUFDSSxVQUFVO01BQ1YsT0FBTztNQUNQLGFBQWE7TUFDYixNQUFNLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O01BQ3ZCLFdBQVc7TUFDWCxPQUFPO0tBQ1g7S0FDQTtNQUNJLFVBQVU7TUFDVixPQUFPO01BQ1AsYUFBYTtNQUNiLE1BQU0sd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7TUFDM0IsV0FBVztNQUNYLE9BQU87TUFDUCxjQUFjLHNCQUFzQixJQUFJO0tBQzVDO0tBQ0E7TUFDSSxVQUFVO01BQ1YsT0FBTztNQUNQLGFBQWE7TUFDYixNQUFNLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O01BQzVCLFdBQVc7TUFDWCxPQUFPO0tBQ1g7S0FDQTtNQUNJLFVBQVU7TUFDVixPQUFPO01BQ1AsYUFBYTtNQUNiLE1BQU0sd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7TUFDM0IsV0FBVztNQUNYLE9BQU87S0FDWDtLQUNBO01BQ0ksVUFBVTtNQUNWLE9BQU87TUFDUCxhQUFhO01BQ2IsTUFBTSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztNQUMzQixXQUFXO01BQ1gsT0FBTztNQUNQLGFBQWE7TUFDYixjQUFjO09BQ1YsTUFBTTtPQUNOLE1BQU0sd0JBQUMsU0FBRCxFQUFTLE1BQU0sR0FBSzs7Ozs7T0FDMUIsU0FBUztNQUNiO0tBQ0o7SUFDSjtHQUNIOzs7OztHQUdELHdCQUFDLGdCQUFEO0lBQ0ksUUFBUTtJQUNSLGVBQWUsaUJBQWlCLEtBQUs7SUFDckMsbUJBQW1CO0tBQ2YsaUJBQWlCLEtBQUs7S0FDdEIsc0JBQXNCLElBQUk7SUFDOUI7R0FDSDs7Ozs7RUFDQTs7Ozs7O0FBRWI7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ1c2VyaG9tZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IFBsdXMsIEZpbGVUZXh0LCBVc2VycywgQ2hlY2tDaXJjbGUyLCBDbG9jaywgRWRpdDMsIEJhckNoYXJ0MiwgU3BhcmtsZXMsIFNlYXJjaFgsIEFycm93UmlnaHQsIEJvb2tPcGVuLCBDb21wYXNzLCBIZWxwQ2lyY2xlLCBDaGV2cm9uRG93biB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgU2lkZWJhciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2xheW91dC9TaWRlYmFyJztcbmltcG9ydCBUb3BiYXIgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9sYXlvdXQvVG9wYmFyJztcbmltcG9ydCBBSUZvcm1CdWlsZGVyTW9kYWwgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9BSUZvcm1CdWlsZGVyTW9kYWwnO1xuaW1wb3J0IE9uYm9hcmRpbmdUb3VyIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvT25ib2FyZGluZ1RvdXInO1xuaW1wb3J0IFVzZXJHdWlkZU1vZGFsIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvVXNlckd1aWRlTW9kYWwnO1xuaW1wb3J0IHsgZ2V0TXlGb3JtcywgZ2V0TXlTdGF0cywgZ2V0TG9jYWxVc2VyLCBjbGVhclNlc3Npb24sIGFzc2V0VXJsLCBjcmVhdGVGb3JtIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5cbmNvbnN0IGdldEdyZWV0aW5nID0gKCkgPT4ge1xuICAgIGNvbnN0IGhvdXIgPSBuZXcgRGF0ZSgpLmdldEhvdXJzKCk7XG4gICAgaWYgKGhvdXIgPCAxMSkgcmV0dXJuICdTZWxhbWF0IFBhZ2knO1xuICAgIGlmIChob3VyIDwgMTUpIHJldHVybiAnU2VsYW1hdCBTaWFuZyc7XG4gICAgaWYgKGhvdXIgPCAxOCkgcmV0dXJuICdTZWxhbWF0IFNvcmUnO1xuICAgIHJldHVybiAnU2VsYW1hdCBNYWxhbSc7XG59O1xuXG5jb25zdCBVc2VySG9tZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgW215Rm9ybXMsIHNldE15Rm9ybXNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtzdGF0cywgc2V0U3RhdHNdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW3VzZXJdID0gdXNlU3RhdGUoKCkgPT4gZ2V0TG9jYWxVc2VyKCkpO1xuICAgIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtjcmVhdGluZ0Zvcm0sIHNldENyZWF0aW5nRm9ybV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2FpRm9ybUJ1aWxkZXJPcGVuLCBzZXRBaUZvcm1CdWlsZGVyT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW29uYm9hcmRpbmdUb3VyT3Blbiwgc2V0T25ib2FyZGluZ1RvdXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbdXNlckd1aWRlT3Blbiwgc2V0VXNlckd1aWRlT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2NyZWF0ZURyb3Bkb3duT3Blbiwgc2V0Q3JlYXRlRHJvcGRvd25PcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBjcmVhdGVEcm9wZG93blJlZiA9IHVzZVJlZihudWxsKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGhhbmRsZUNsaWNrT3V0c2lkZSA9IChlKSA9PiB7XG4gICAgICAgICAgICBpZiAoY3JlYXRlRHJvcGRvd25SZWYuY3VycmVudCAmJiAhY3JlYXRlRHJvcGRvd25SZWYuY3VycmVudC5jb250YWlucyhlLnRhcmdldCkpIHtcbiAgICAgICAgICAgICAgICBzZXRDcmVhdGVEcm9wZG93bk9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xuICAgICAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcbiAgICB9LCBbXSk7XG5cbiAgICAvLyBSZWdpc3RlciBnbG9iYWwgdHJpZ2dlciBmb3IgbWFudWFsIHRvdXIgbGF1bmNoIGZyb20gU2lkZWJhci9Ub3BiYXJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICB3aW5kb3cuX19zdGFydEZvcm1VcFRvdXIgPSAoKSA9PiB7XG4gICAgICAgICAgICBzZXRPbmJvYXJkaW5nVG91ck9wZW4odHJ1ZSk7XG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBkZWxldGUgd2luZG93Ll9fc3RhcnRGb3JtVXBUb3VyO1xuICAgICAgICB9O1xuICAgIH0sIFtdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgICAgICAgICBjb25zdCBbZm9ybXNSZXN1bHQsIHN0YXRzUmVzdWx0XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgICAgICAgZ2V0TXlGb3JtcygpLFxuICAgICAgICAgICAgICAgICAgICBnZXRNeVN0YXRzKCkuY2F0Y2goKCkgPT4gbnVsbCksXG4gICAgICAgICAgICAgICAgXSk7XG5cbiAgICAgICAgICAgICAgICBpZiAoZm9ybXNSZXN1bHQuc3RhdHVzID09PSA0MDEpIHtcbiAgICAgICAgICAgICAgICAgICAgY2xlYXJTZXNzaW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChmb3Jtc1Jlc3VsdC5vayAmJiBBcnJheS5pc0FycmF5KGZvcm1zUmVzdWx0LmRhdGEpKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldE15Rm9ybXMoZm9ybXNSZXN1bHQuZGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChzdGF0c1Jlc3VsdD8ub2sgJiYgc3RhdHNSZXN1bHQ/LmRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0U3RhdHMoc3RhdHNSZXN1bHQuZGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLy8gQ2VrIGFwYWthaCB1c2VyIGJhcnUgKGJlbHVtIHBlcm5haCBtZW55ZWxlc2Fpa2FuIG9uYm9hcmRpbmcpXG4gICAgICAgICAgICAgICAgY29uc3Qgc3RvcmFnZUtleSA9IGBvbmJvYXJkaW5nX2NvbXBsZXRlZF8ke3VzZXI/LmlkIHx8IHVzZXI/LmVtYWlsIHx8ICdkZWZhdWx0J31gO1xuICAgICAgICAgICAgICAgIGNvbnN0IGhhc0NvbXBsZXRlZE9uYm9hcmRpbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShzdG9yYWdlS2V5KTtcbiAgICAgICAgICAgICAgICBpZiAoIWhhc0NvbXBsZXRlZE9uYm9hcmRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gQmVyaWthbiBzZWRpa2l0IGplZGEgd2FrdHUgcmVuZGVyIGhhbGFtYW4gZGFzaGJvYXJkIHNlYmVsdW0gdG91ciBtdW5jdWxcbiAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRPbmJvYXJkaW5nVG91ck9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH0sIDUwMCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRGFzaGJvYXJkIGZldGNoIGVycm9yOicsIGVycik7XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGZldGNoRGF0YSgpO1xuICAgIH0sIFtuYXZpZ2F0ZSwgdXNlcj8uaWQsIHVzZXI/LmVtYWlsXSk7XG5cbiAgICBjb25zdCBoYW5kbGVPbmJvYXJkaW5nQ29tcGxldGUgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHN0b3JhZ2VLZXkgPSBgb25ib2FyZGluZ19jb21wbGV0ZWRfJHt1c2VyPy5pZCB8fCB1c2VyPy5lbWFpbCB8fCAnZGVmYXVsdCd9YDtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oc3RvcmFnZUtleSwgJ3RydWUnKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlR29Ub0J1aWxkZXJUb3VyID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBoYW5kbGVPbmJvYXJkaW5nQ29tcGxldGUoKTtcbiAgICAgICAgc2V0T25ib2FyZGluZ1RvdXJPcGVuKGZhbHNlKTtcbiAgICAgICAgaWYgKG15Rm9ybXMgJiYgbXlGb3Jtcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBuYXZpZ2F0ZShgL2Zvcm1zLyR7bXlGb3Jtc1swXS5pZH0vZWRpdD90b3VyPWJ1aWxkZXJgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIEppa2EgYmVsdW0gYWRhIGZvcm11bGlyLCBidWF0IGZvcm11bGlyIGRyYWYgY29udG9oIGxhbHUgbXVsYWkgdHVyIGRpIEZvcm0gQnVpbGRlclxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjcmVhdGVGb3JtKHtcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdGb3JtdWxpciBQZXJ0YW1hIFNheWEnLFxuICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ0Zvcm11bGlyIGxhdGloYW4gcGFuZHVhbiBGb3JtVXAnLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmIChyZXMub2sgJiYgcmVzLmRhdGE/LmlkKSB7XG4gICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvZm9ybXMvJHtyZXMuZGF0YS5pZH0vZWRpdD90b3VyPWJ1aWxkZXJgKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZSgnL2NyZWF0ZS1mb3JtJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgY3JlYXRpbmcgdG91ciBmb3JtOicsIGVycik7XG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoJy9jcmVhdGUtZm9ybScpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNyZWF0ZU5ld0Zvcm0gPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmIChjcmVhdGluZ0Zvcm0pIHJldHVybjtcbiAgICAgICAgc2V0Q3JlYXRpbmdGb3JtKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY3JlYXRlRm9ybSh7XG4gICAgICAgICAgICAgICAgdGl0bGU6ICdGb3JtdWxpciBUYW5wYSBKdWR1bCcsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxKSB7XG4gICAgICAgICAgICAgICAgY2xlYXJTZXNzaW9uKCk7XG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoJy9sb2dpbicpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZXMub2sgJiYgcmVzLmRhdGE/LmlkKSB7XG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoYC9mb3Jtcy8ke3Jlcy5kYXRhLmlkfS9lZGl0YCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG5hdmlnYXRlKCcvY3JlYXRlLWZvcm0nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBjcmVhdGluZyBmb3JtOicsIGVycik7XG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL2NyZWF0ZS1mb3JtJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRDcmVhdGluZ0Zvcm0oZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHRvdGFsUmVzcG9uc2VzID0gbXlGb3Jtcy5yZWR1Y2UoKGFjYywgZikgPT4gYWNjICsgKGYucmVzcG9uc2VDb3VudCA/PyAwKSwgMCk7XG4gICAgY29uc3QgcHVibGlzaGVkQ291bnQgPSBteUZvcm1zLmZpbHRlcihmID0+IGYuc3RhdHVzPy50b0xvd2VyQ2FzZSgpID09PSAncHVibGlzaGVkJykubGVuZ3RoO1xuICAgIGNvbnN0IGRyYWZ0Q291bnQgPSBteUZvcm1zLmZpbHRlcihmID0+IGYuc3RhdHVzPy50b0xvd2VyQ2FzZSgpID09PSAnZHJhZnQnKS5sZW5ndGg7XG5cbiAgICBjb25zdCBmaWx0ZXJlZEZvcm1zID0gbXlGb3Jtcy5maWx0ZXIoZm9ybSA9PiB7XG4gICAgICAgIGlmICghc2VhcmNoUXVlcnkudHJpbSgpKSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgY29uc3QgcSA9IHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAoZm9ybS50aXRsZSAmJiBmb3JtLnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpIHx8XG4gICAgICAgICAgICAoZm9ybS5kZXNjcmlwdGlvbiAmJiBmb3JtLmRlc2NyaXB0aW9uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpIHx8XG4gICAgICAgICAgICAoZm9ybS5zdGF0dXMgJiYgZm9ybS5zdGF0dXMudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSlcbiAgICAgICAgKTtcbiAgICB9KTtcblxuICAgIGNvbnN0IHJlY2VudEZvcm1zID0gWy4uLmZpbHRlcmVkRm9ybXNdXG4gICAgICAgIC5zb3J0KChhLCBiKSA9PiBuZXcgRGF0ZShiLnVwZGF0ZWRBdCA/PyBiLmNyZWF0ZWRBdCkgLSBuZXcgRGF0ZShhLnVwZGF0ZWRBdCA/PyBhLmNyZWF0ZWRBdCkpXG4gICAgICAgIC5zbGljZSgwLCAxMCk7XG5cbiAgICBpZiAobG9hZGluZykge1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS05NTAgZm9udC1zYW5zIGFudGlhbGlhc2VkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICA8U2lkZWJhciAvPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBtaW4tdy0wIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTEgdy1mdWxsIHAtNCBzbTpwLTYgbGc6cC04IHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRvcGJhciBzZWFyY2hRdWVyeT17c2VhcmNoUXVlcnl9IG9uU2VhcmNoQ2hhbmdlPXtzZXRTZWFyY2hRdWVyeX0gLz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNrZWxldG9uIEhlYWRlciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1wdWxzZSBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNyBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZC1tZCB3LTU2XCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQgYmctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtODAwIHJvdW5kZWQtbWQgdy03MlwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTa2VsZXRvbiBTdGF0cyBHcmlkICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC0zIHNtOmdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1sxLCAyLCAzLCA0XS5tYXAoKGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHAtNCBzbTpwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBhbmltYXRlLXB1bHNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0zIGJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkIHctMTYgc206dy0yMFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC02IHNtOmgtNyBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZCB3LTEwIHNtOnctMTJcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IHNtOnctMTAgc206aC0xMCByb3VuZGVkLXhsIGJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCBzaHJpbmstMFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogU2tlbGV0b24gQ29udGVudCBHcmlkICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNSBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZCB3LTM2IGFuaW1hdGUtcHVsc2VcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTQgMnhsOmdyaWQtY29scy01IGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtbMSwgMiwgMywgNCwgNV0ubWFwKChpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLXB1bHNlIGgtNDggc206aC02NCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtZnVsbCBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCB3LWZ1bGxcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L21haW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIHctZnVsbCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTk1MCBmb250LXNhbnMgYW50aWFsaWFzZWQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgPFNpZGViYXIgLz5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBtaW4tdy0wIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICAgIHsvKiBNZW5naGFwdXMgbWF4LXctN3hsIG14LWF1dG8gYWdhciBsYXlvdXQgZnVsbCB3aWR0aCBtZW5naXNpIHNlbHVydWggbGF5YXIgKi99XG4gICAgICAgICAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIHctZnVsbCBwLTQgc206cC02IGxnOnAtOCBzcGFjZS15LTYgc206c3BhY2UteS04XCI+XG4gICAgICAgICAgICAgICAgICAgIDxUb3BiYXIgXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2hRdWVyeT17c2VhcmNoUXVlcnl9IFxuICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDaGFuZ2U9e3NldFNlYXJjaFF1ZXJ5fSBcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ2FyaSBmb3JtdWxpciwgc3RhdHVzLCBhdGF1IGRlc2tyaXBzaS4uLlwiIFxuICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgU2VjdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0R3JlZXRpbmcoKX0sIHt1c2VyPy5mdWxsbmFtZSA/IHVzZXIuZnVsbG5hbWUuc3BsaXQoJyAnKVswXSA6ICdQZW5nZ3VuYSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmVyaWt1dCByaW5na2FzYW4gYWt0aXZpdGFzIGRhbiBwZXJmb3JtYSBmb3JtdWxpciBBbmRhLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCIgcmVmPXtjcmVhdGVEcm9wZG93blJlZn0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDcmVhdGVEcm9wZG93bk9wZW4ocHJldiA9PiAhcHJldil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdG91cj1cImNyZWF0ZS1mb3JtLWJ0blwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweC00IHB5LTIuNSBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCBkYXJrOmJnLXRlYWwtNjAwIGRhcms6aG92ZXI6YmctdGVhbC01MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC14bCBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFBsdXMgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkJ1YXQgRm9ybXVsaXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uRG93biBzaXplPXsxNH0gY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwICR7Y3JlYXRlRHJvcGRvd25PcGVuID8gJ3JvdGF0ZS0xODAnIDogJyd9YH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3JlYXRlRHJvcGRvd25PcGVuICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIHRvcC1mdWxsIG10LTEgdy01MiBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBzaGFkb3cteGwgei01MCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldENyZWF0ZURyb3Bkb3duT3BlbihmYWxzZSk7IGhhbmRsZUNyZWF0ZU5ld0Zvcm0oKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y3JlYXRpbmdGb3JtfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC00IHB5LTMgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciB0ZXh0LWxlZnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIHNpemU9ezE1fSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5CdWF0IE1hbnVhbDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbm9ybWFsIHRleHQtc2xhdGUtNDAwXCI+TXVsYWkgZGFyaSBmb3JtdWxpciBrb3Nvbmc8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0Q3JlYXRlRHJvcGRvd25PcGVuKGZhbHNlKTsgc2V0QWlGb3JtQnVpbGRlck9wZW4odHJ1ZSk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS10b3VyPVwiY3JlYXRlLWFpLWJ0blwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTQgcHktMyB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTQwMCBob3ZlcjpiZy10ZWFsLTUwIGRhcms6aG92ZXI6YmctdGVhbC05NTAvMzAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgdGV4dC1sZWZ0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MTV9IGNsYXNzTmFtZT1cInRleHQtdGVhbC01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+QnVhdCBkZW5nYW4gQUkg4pyoPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ub3JtYWwgdGV4dC1zbGF0ZS00MDBcIj5HZW5lcmF0ZSBvdG9tYXRpcyBkZW5nYW4gQUk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBDb21wdXRlIHN0YXRzIG1ldHJpY3MgZnJvbSBzdGF0cyBBUEkgb3IgbXlGb3JtcyBmYWxsYmFjayAqL31cbiAgICAgICAgICAgICAgICAgICAgeygoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0b3RhbEZvcm1Db3VudCA9IHN0YXRzPy50b3RhbEZvcm1zID8/IHN0YXRzPy5mb3Jtc0NvdW50ID8/IG15Rm9ybXMubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWxSZXNwb25zZXMgPSBzdGF0cz8udG90YWxSZXNwb25zZXMgPz8gc3RhdHM/LnJlc3BvbnNlc0NvdW50ID8/IG15Rm9ybXMucmVkdWNlKChhY2MsIGYpID0+IGFjYyArIChmLnJlc3BvbnNlQ291bnQgfHwgZi5yZXNwb25zZXNDb3VudCB8fCAwKSwgMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwdWJsaXNoZWRDb3VudCA9IHN0YXRzPy5wdWJsaXNoZWRGb3JtcyA/PyBzdGF0cz8ucHVibGlzaGVkQ291bnQgPz8gbXlGb3Jtcy5maWx0ZXIoZiA9PiAoZi5zdGF0dXMgfHwgJycpLnRvTG93ZXJDYXNlKCkgPT09ICdwdWJsaXNoZWQnIHx8IGYuaXNQdWJsaXNoZWQpLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRyYWZ0Q291bnQgPSBzdGF0cz8uZHJhZnRGb3JtcyA/PyBzdGF0cz8uZHJhZnRDb3VudCA/PyBteUZvcm1zLmZpbHRlcihmID0+IChmLnN0YXR1cyB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gJ2RyYWZ0JyB8fCAhZi5pc1B1Ymxpc2hlZCkubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtMyBzbTpnYXAtNFwiIGRhdGEtdG91cj1cInN0YXRzLW92ZXJ2aWV3XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC0zLjUgc206cC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMC84MCBzaGFkb3ctMnhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBzbTp0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTAuNVwiPlRvdGFsIEZvcm11bGlyPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj57dG90YWxGb3JtQ291bnR9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgc206cC0yLjUgcm91bmRlZC14bCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNTAgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17MTh9IGNsYXNzTmFtZT1cInNtOnctNSBzbTpoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC0zLjUgc206cC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMC84MCBzaGFkb3ctMnhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBzbTp0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTAuNVwiPlRvdGFsIFJlc3BvbnM8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgc206dGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPnt0b3RhbFJlc3BvbnNlc308L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBzbTpwLTIuNSByb3VuZGVkLXhsIGJnLWluZGlnby01MCBkYXJrOmJnLWluZGlnby05NTAvNTAgdGV4dC1pbmRpZ28tNjAwIGRhcms6dGV4dC1pbmRpZ28tNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXJzIHNpemU9ezE4fSBjbGFzc05hbWU9XCJzbTp3LTUgc206aC01XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHAtMy41IHNtOnAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAvODAgc2hhZG93LTJ4cyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gc206dGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0wLjVcIj5EaXB1Ymxpa2FzaWthbjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3B1Ymxpc2hlZENvdW50fTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHNtOnAtMi41IHJvdW5kZWQteGwgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzUwIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxOH0gY2xhc3NOYW1lPVwic206dy01IHNtOmgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTMuNSBzbTpwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwLzgwIHNoYWRvdy0yeHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHNtOnRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMC41XCI+RHJhZjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e2RyYWZ0Q291bnR9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgc206cC0yLjUgcm91bmRlZC14bCBiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC81MCB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENsb2NrIHNpemU9ezE4fSBjbGFzc05hbWU9XCJzbTp3LTUgc206aC01XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH0pKCl9XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFJlY2VudCBGb3JtcyBTZWN0aW9uICovfVxuICAgICAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIiBkYXRhLXRvdXI9XCJyZWNlbnQtZm9ybXMtc2VjdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5Gb3JtdWxpciBUZXJiYXJ1PC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VhcmNoUXVlcnkgPyBgSGFzaWwgcGVuY2FyaWFuIHVudHVrIFwiJHtzZWFyY2hRdWVyeX1cImAgOiAnRm9ybXVsaXIgeWFuZyB0ZXJha2hpciBrYWxpIGRpdWJhaCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bXlGb3Jtcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9teS1mb3JtcycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBob3Zlcjp0ZXh0LXRlYWwtNzAwIGRhcms6aG92ZXI6dGV4dC10ZWFsLTMwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkxpaGF0IHNlbXVhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFycm93UmlnaHQgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZJVFVSIDE6IEVtcHR5IFN0YXRlIERhc2hib2FyZCAoVXNlciBiZWx1bSBwdW55YSBmb3JtIHNhbWEgc2VrYWxpKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtteUZvcm1zLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtM3hsIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXRlYWwtMjAwLzgwIGRhcms6Ym9yZGVyLXRlYWwtOTAwLzQwIHAtOCBzbTpwLTEyIHRleHQtY2VudGVyIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNwYWNlLXktNSBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgaG92ZXI6Ym9yZGVyLXRlYWwtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBWaXN1YWwgQmFkZ2UgLyBJY29uICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiBzbTp3LTIwIHNtOmgtMjAgcm91bmRlZC0zeGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS10ZWFsLTUwMC8yMCB2aWEtZW1lcmFsZC01MDAvMTAgdG8tdGVhbC0xMDAgZGFyazpmcm9tLXRlYWwtOTAwLzQwIGRhcms6dG8tc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtWyMwMDg5N0JdIGRhcms6dGV4dC10ZWFsLTQwMCBzaGFkb3ctaW5uZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17MzZ9IGNsYXNzTmFtZT1cInRyYW5zZm9ybSAtcm90YXRlLTZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMS41IC1yaWdodC0xLjUgdy03IGgtNyByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLXRlYWwtNjAwIHRvLWVtZXJhbGQtNTAwIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LW1kIGFuaW1hdGUtYm91bmNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkbGluZSAmIERlc2NyaXB0aW9uICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41IG1heC13LW1kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBzbTp0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJlbHVtIEFkYSBGb3JtdWxpciBOaWhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdWF0IGZvcm11bGlyIGF0YXUga3VpcyBwZXJ0YW1hbXUgc2VrYXJhbmchIEFuZGEgYmlzYSBtZW1idWF0bnlhIHNlY2FyYSBtYW51YWwgYXRhdSBndW5ha2FuIGtlY2VyZGFzYW4gQUkgdW50dWsgbWVueXVzdW5ueWEgb3RvbWF0aXMgZGFsYW0gc2VrZWphcC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGdhcC0zIHctZnVsbCBzbTp3LWF1dG8gcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNyZWF0ZU5ld0Zvcm19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NyZWF0aW5nRm9ybX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweC01IHB5LTMgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgZGFyazpiZy10ZWFsLTYwMCBkYXJrOmhvdmVyOmJnLXRlYWwtNTAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntjcmVhdGluZ0Zvcm0gPyAnTWVtYnVhdC4uLicgOiAnQnVhdCBGb3JtdWxpciBQZXJ0YW1hJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFpRm9ybUJ1aWxkZXJPcGVuKHRydWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB4LTUgcHktMyBiZy1ncmFkaWVudC10by1yIGZyb20tdGVhbC01MDAvMTAgdG8tZW1lcmFsZC01MDAvMTAgaG92ZXI6ZnJvbS10ZWFsLTUwMC8yMCBob3Zlcjp0by1lbWVyYWxkLTUwMC8yMCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgYm9yZGVyIGJvcmRlci10ZWFsLTUwMC8zMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGFjdGl2ZTpzY2FsZS05NSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNvYmEgQUkgRm9ybSBCdWlsZGVyPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdWJsaW5rIHRvIFVzZXIgR3VpZGUgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VXNlckd1aWRlT3Blbih0cnVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtdGVhbC02MDAgZGFyazpob3Zlcjp0ZXh0LXRlYWwtNDAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIHB0LTJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm9va09wZW4gc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CdXR1aCBwYW5kdWFuPyBQZWxhamFyaSBjYXJhIHBha2FpIEZvcm1VcDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8qIFJlc3BvbnNpdmUgR3JpZDogTWVueWFtcGluZyBkaSBIUCwgR3JpZCBmbGVrc2liZWwgMy01IGtvbG9tIGRpIERlc2t0b3AgKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTQgMnhsOmdyaWQtY29scy01IGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWNlbnRGb3Jtcy5tYXAoKGZvcm0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0YXR1cyA9IHR5cGVvZiBmb3JtLnN0YXR1cyA9PT0gJ3N0cmluZycgPyBmb3JtLnN0YXR1cyA6ICdkcmFmdCc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1B1Ymxpc2hlZCA9IHN0YXR1cy50b0xvd2VyQ2FzZSgpID09PSAncHVibGlzaGVkJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlQ291bnQgPSBmb3JtLnJlc3BvbnNlQ291bnQgPz8gMDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2Zvcm0uaWR9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc2hhZG93LTJ4cyBob3Zlcjpib3JkZXItc2xhdGUtMzAwIGRhcms6aG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZmxleCBmbGV4LXJvdyBzbTpmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gb3ZlcmZsb3ctaGlkZGVuIGdyb3VwIGhvdmVyOi10cmFuc2xhdGUteS0wLjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEJhbm5lcjogTWVueWFtcGluZyBkaSBIUCwgUGVudWggZGkgRGVza3RvcCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTI4IHhzOnctMzIgc206dy1mdWxsIGgtYXV0byBzbTpoLTM2IHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAvNTAgZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyLXIgc206Ym9yZGVyLXItMCBzbTpib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm0uYmFubmVySW1hZ2UgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Fzc2V0VXJsKGZvcm0uYmFubmVySW1hZ2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2Zvcm0udGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDAgZWFzZS1vdXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17MjR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMi41IGxlZnQtMi41IHRleHQtWzlweF0gc206dGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLW1kIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBiYWNrZHJvcC1ibHVyLW1kICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNQdWJsaXNoZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAwLzkwIHRleHQtd2hpdGUnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAvNzAgdGV4dC1zbGF0ZS0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzUHVibGlzaGVkID8gJ0RpcHVibGlrYXNpa2FuJyA6ICdEcmFmJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENvbnRlbnQgQXJlYSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBzbTpwLTQgZmxleC0xIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXktMyBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIHRydW5jYXRlIGdyb3VwLWhvdmVyOnRleHQtdGVhbC02MDAgZGFyazpncm91cC1ob3Zlcjp0ZXh0LXRlYWwtNDAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtLnRpdGxlIHx8ICdGb3JtdWxpciBUYW5wYSBKdWR1bCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC0xLjUgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntyZXNwb25zZUNvdW50fSByZXNwb25zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtLmNyZWF0ZWRBdCA/IG5ldyBEYXRlKGZvcm0uY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2lkLUlEJywgeyBtb250aDogJ3Nob3J0JywgZGF5OiAnbnVtZXJpYycgfSkgOiAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMi41IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwLzgwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2Zvcm1zLyR7Zm9ybS5pZH0vZWRpdGApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMS41IHB4LTIgYmctc2xhdGUtNTAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwLzgwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9udC1tZWRpdW0gdGV4dC14cyByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNjAgZGFyazpib3JkZXItc2xhdGUtNzAwLzYwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0MyBzaXplPXsxM30gLz4gRWRpdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9mb3Jtcy8ke2Zvcm0uaWR9L3Jlc3BvbnNlc2ApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMS41IHB4LTIgYmctc2xhdGUtNTAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwLzgwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9udC1tZWRpdW0gdGV4dC14cyByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNjAgZGFyazpib3JkZXItc2xhdGUtNzAwLzYwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCYXJDaGFydDIgc2l6ZT17MTN9IC8+IFJlc3BvbnNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEVtcHR5IFN0YXRlIFNlYXJjaCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZWNlbnRGb3Jtcy5sZW5ndGggPT09IDAgJiYgc2VhcmNoUXVlcnkgJiYgbXlGb3Jtcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTEyIHRleHQtY2VudGVyIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VhcmNoWCBzaXplPXszMn0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZGFyazp0ZXh0LXNsYXRlLTYwMCBtYi0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5IYXNpbCB0aWRhayBkaXRlbXVrYW48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaWRhayBhZGEgZm9ybXVsaXIgeWFuZyBjb2NvayBkZW5nYW4ga2F0YSBrdW5jaSBcIntzZWFyY2hRdWVyeX1cIi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgICAgICAgICAgPC9tYWluPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBBSS0xOiBBSSBGb3JtIEJ1aWxkZXIgTW9kYWwgKi99XG4gICAgICAgICAgICA8QUlGb3JtQnVpbGRlck1vZGFsXG4gICAgICAgICAgICAgICAgaXNPcGVuPXthaUZvcm1CdWlsZGVyT3Blbn1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBaUZvcm1CdWlsZGVyT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgb25Gb3JtQ3JlYXRlZD17KG5ld0lkKSA9PiBuYXZpZ2F0ZShgL2Zvcm1zLyR7bmV3SWR9L2VkaXRgKX1cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiBGSVRVUiAyOiBHdWlkZWQgT25ib2FyZGluZyBUb3VyIChTcG90bGlnaHQpICovfVxuICAgICAgICAgICAgPE9uYm9hcmRpbmdUb3VyXG4gICAgICAgICAgICAgICAgaXNPcGVuPXtvbmJvYXJkaW5nVG91ck9wZW59XG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0T25ib2FyZGluZ1RvdXJPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBvbkNvbXBsZXRlPXtoYW5kbGVPbmJvYXJkaW5nQ29tcGxldGV9XG4gICAgICAgICAgICAgICAgc3RlcHM9e1tcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0b3I6ICdbZGF0YS10b3VyPVwiY3JlYXRlLWZvcm0tYnRuXCJdJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnQnVhdCBGb3JtdWxpciBCYXJ1JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnS2xpayBkaSBzaW5pIHVudHVrIGxhbmdzdW5nIG1lbWJ1YXQgZm9ybXVsaXIga29zb25nLiBBbmRhIGRhcGF0IG1lbmFtYmFoa2FuIGFuZWthIHRpcGUgc29hbCBwaWxpaGFuIGdhbmRhLCBlc3NheSwgcnVtdXMgbWF0ZW1hdGlrYSwgZGFuIGt1bmNpIGphd2FiYW4uJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxQbHVzIHNpemU9ezE4fSAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudDogJ2JvdHRvbScsXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWRnZTogJ011bGFpIENlcGF0J1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RvcjogJ1tkYXRhLXRvdXI9XCJjcmVhdGUtYWktYnRuXCJdJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnS2VjZXJkYXNhbiBCdWF0IEZvcm0gQUknLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICdDdWt1cCBkZXNrcmlwc2lrYW4gdG9waWsgYXRhdSBtYXRlcmkga3VpcyBBbmRhLCBBSSBGb3JtVXAgYWthbiBvdG9tYXRpcyBtZXJhbmNhbmcgcGVydGFueWFhbiBkYW4gb3BzaSBrdW5jaSBqYXdhYmFuIGxlbmdrYXAgdW50dWsgQW5kYSEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPFNwYXJrbGVzIHNpemU9ezE4fSAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudDogJ2JvdHRvbScsXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWRnZTogJ0tlY2VyZGFzYW4gQUknLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uOiAoKSA9PiBzZXRDcmVhdGVEcm9wZG93bk9wZW4odHJ1ZSlcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0b3I6ICdbZGF0YS10b3VyPVwic3RhdHMtb3ZlcnZpZXdcIl0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdSaW5na2FzYW4gQWt0aXZpdGFzIFJlYWwtVGltZScsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1BhbnRhdSB0b3RhbCBmb3JtdWxpciwganVtbGFoIHJlc3BvbmRlbiB5YW5nIHRlbGFoIG1lbmdpc2ksIHNlcnRhIHN0YXR1cyBmb3JtdWxpciBha3RpZiBtYXVwdW4gZHJhZiBBbmRhIGRpIHNpbmkuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxCYXJDaGFydDIgc2l6ZT17MTh9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50OiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlOiAnU3RhdGlzdGlrJ1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RvcjogJ1tkYXRhLXRvdXI9XCJyZWNlbnQtZm9ybXMtc2VjdGlvblwiXScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0RhZnRhciBGb3JtdWxpciAmIEFrc2kgQ2VwYXQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICdLZWxvbGEgZm9ybXVsaXIgQW5kYSBkZW5nYW4gbXVkYWguIEFuZGEgZGFwYXQgbGFuZ3N1bmcgbWVuZ2VkaXQgcGVydGFueWFhbiwgbWVueWFsaW4gbGluaywgYXRhdSBtZW1lcmlrc2EgZXZhbHVhc2kgcmVzcG9ucyBtYXN1ayBrYXBhbiBzYWphLicsXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8RmlsZVRleHQgc2l6ZT17MTh9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50OiAndG9wJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlOiAnS29sZWtzaSBGb3JtJ1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RvcjogJ1tkYXRhLXRvdXI9XCJjcmVhdGUtZm9ybS1idG5cIl0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdMYW5qdXQga2UgUGFuZHVhbiBGb3JtIEJ1aWxkZXI/JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnRWtzcGxvcmFzaSBjYXJhIG1lbnl1c3VuIHBlcnRhbnlhYW4ga3VpcywgcnVtdXMgbWF0ZW1hdGlrYSBLYVRlWCwgYmF0YXNhbiB0aW1lciBwZW5nZXJqYWFuLCBkYW4gTW9kZSBVamlhbiBBbnRpLUN1cmFuZyBsYW5nc3VuZyBkaSBlZGl0b3IgRm9ybSBCdWlsZGVyLicsXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8U3BhcmtsZXMgc2l6ZT17MTh9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50OiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlOiAnTGFuZ2thaCBMYW5qdXRhbicsXG4gICAgICAgICAgICAgICAgICAgICAgICBuZXh0QnRuVGV4dDogJ1NlbGVzYWkgZGkgRGFzaGJvYXJkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbkJ1dHRvbjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6ICdCdWthIEZvcm0gQnVpbGRlciAmIExhbmp1dCBQYW5kdWFuIOKGkicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPENvbXBhc3Mgc2l6ZT17MTV9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6IGhhbmRsZUdvVG9CdWlsZGVyVG91clxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgXX1cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiBGSVRVUiAzOiBQb3B1cCBSaW5na2FzYW4gUGFuZHVhbiBQZW5nZ3VuYSAqL31cbiAgICAgICAgICAgIDxVc2VyR3VpZGVNb2RhbFxuICAgICAgICAgICAgICAgIGlzT3Blbj17dXNlckd1aWRlT3Blbn1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRVc2VyR3VpZGVPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBvblN0YXJ0VG91cj17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRVc2VyR3VpZGVPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0T25ib2FyZGluZ1RvdXJPcGVuKHRydWUpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgVXNlckhvbWU7XG4iXX0=