import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/form-builder/FormBuilder.jsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_BASE_URL": "https://api.formup.my.id"};const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useRef = __vite__cjsImport0_react["useRef"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport15_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { Save, Plus, Trash2, ChevronUp, ChevronDown, Globe, Lock, ArrowLeft, Upload, FileUp, Image, Music, Download, Code, Calculator, Eye, EyeOff, X, Sparkles, Copy, Undo2, Redo2, FileDown, Wand2, ToggleLeft, ToggleRight, ShieldAlert, Palette, CheckSquare, MoreHorizontal, MoreVertical, ChevronDown as ChevDown, Sliders, Share2, HelpCircle, Compass, Loader2, Columns } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import ConfirmModal from "/src/components/ui/ConfirmModal.jsx";
import OnboardingTour from "/src/components/ui/OnboardingTour.jsx";
import { getFormById, getQuestions, saveQuestions, updateForm, togglePublishForm, updateFormSettings, getFormShare, uploadFormBanner, clearSession, assetUrl, deleteQuestion, uploadQuestionImage, uploadQuestionAudio, uploadOptionImage, templateDownloadUrl, createForm, deleteAllQuestions, previewImportQuestions } from "/src/services/apiService.js";
import { getGeminiApiKey, AVAILABLE_MODELS, reviseQuestionWithAI, bulkReviseQuestionsWithAI } from "/src/services/aiService.js";
import RichContentRenderer from "/src/utils/RichContentRenderer.jsx";
import BlockQuestionEditor from "/src/components/ui/BlockQuestionEditor.jsx";
import MathAndCodeModal from "/src/components/ui/MathAndCodeModal.jsx";
import ImageLightboxModal from "/src/components/ui/ImageLightboxModal.jsx";
import AIGeneratorModal from "/src/components/ui/AIGeneratorModal.jsx";
import AIFormBuilderModal from "/src/components/ui/AIFormBuilderModal.jsx";
import ImportQuestionsModal from "/src/components/ui/ImportQuestionsModal.jsx";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-builder/FormBuilder.jsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const envUrl = import.meta.env.VITE_API_BASE_URL;
const API_BASE_URL = envUrl !== undefined && envUrl !== "" ? envUrl : import.meta.env.DEV ? "" : "https://api.formup.my.id";
const FRONTEND_BASE_URL = import.meta.env.VITE_FRONTEND_URL || (typeof window !== "undefined" ? window.location.origin : "https://formup.my.id");
const QUESTION_TYPES = [
	{
		id: 1,
		label: "Essay / Short Answer"
	},
	{
		id: 2,
		label: "Multiple Choice"
	},
	{
		id: 3,
		label: "Checkbox"
	},
	{
		id: 4,
		label: "Date Time"
	},
	{
		id: 5,
		label: "True / False"
	}
];
const newQuestion = (order) => ({
	_id: `q_new_${Date.now()}_${order}`,
	id: null,
	question: "",
	typeId: 2,
	questionOrder: order,
	isRequired: true,
	isScorable: true,
	points: null,
	correctAnswer: "",
	options: [{
		optionText: "",
		isCorrect: false,
		optionImage: null
	}, {
		optionText: "",
		isCorrect: false,
		optionImage: null
	}],
	questionImage: null,
	questionAudio: null
});
const needsOptions = (typeId) => [2, 3].includes(typeId);
// Helper: Normalize imported or loaded option (strips [BENAR] or * marker, preserves optionImage)
const normalizeImportedOption = (o) => {
	let text = (o.optionText || o.OptionText || "").trim();
	let isCorrect = o.isCorrect === true || o.IsCorrect === true;
	if (text.startsWith("[BENAR]")) {
		isCorrect = true;
		text = text.replace(/^\[BENAR\]\s*/i, "").trim();
	} else if (text.startsWith("*")) {
		isCorrect = true;
		text = text.replace(/^\*\s*/, "").trim();
	}
	return {
		...o,
		optionText: text,
		isCorrect,
		optionImage: o.optionImage || o.image || o.imageUrl || null
	};
};
const normalizeQuestionOptions = (q) => {
	const rawOptions = q.options || q.optionQuestions || [];
	let opts = rawOptions.map(normalizeImportedOption);
	// If PG (typeId 2) or Checkbox (typeId 3) and no option is marked correct, but correctAnswer matches
	const isChoice = q.typeId === 2 || q.typeId === 3 || q.type_id === 2 || q.type_id === 3;
	if (isChoice && q.correctAnswer && !opts.some((o) => o.isCorrect)) {
		const caList = String(q.correctAnswer).split(/[,;|]/).map((s) => s.trim().toLowerCase());
		opts = opts.map((o) => {
			if (caList.includes(o.optionText.trim().toLowerCase())) {
				return {
					...o,
					isCorrect: true
				};
			}
			return o;
		});
	}
	return opts.length > 0 ? opts : [{
		optionText: "",
		isCorrect: false,
		optionImage: null
	}];
};
export default function FormBuilder() {
	_s();
	const { id } = useParams();
	const navigate = useNavigate();
	const [form, setForm] = useState(null);
	const [questions, setQuestions] = useState([]);
	const [loading, setLoading] = useState(true);
	const [saving, setSaving] = useState(false);
	const [publishing, setPublishing] = useState(false);
	const [activeTab, setActiveTab] = useState("questions");
	const [shareInfo, setShareInfo] = useState(null);
	const [qrBlobUrl, setQrBlobUrl] = useState(null);
	const [toast, setToast] = useState(null);
	const [copiedLink, setCopiedLink] = useState(false);
	const [lightboxImage, setLightboxImage] = useState(null);
	// Modal state for Code & KaTeX Math insertion (for Question or Option)
	const [modalOpen, setModalOpen] = useState(false);
	const [modalMode, setModalMode] = useState("math");
	const [modalTarget, setModalTarget] = useState({
		type: "question",
		qIdx: null,
		oIdx: null
	});
	// AI Quiz Generator Modal state
	const [aiModalOpen, setAiModalOpen] = useState(false);
	// AI Form Builder Modal state
	const [aiFormBuilderOpen, setAiFormBuilderOpen] = useState(false);
	// A-2: Import Questions Modal (preview + commit)
	const [importModalOpen, setImportModalOpen] = useState(false);
	// C-2: Pagination & Search state for questions list
	const [currentPage, setCurrentPage] = useState(1);
	const [pageSize, setPageSize] = useState(25);
	const [searchTerm, setSearchTerm] = useState("");
	const [debouncedSearch, setDebouncedSearch] = useState("");
	const [totalQuestions, setTotalQuestions] = useState(0);
	// AI Revise per-question inline panel
	const [aiReviseOpenIdx, setAiReviseOpenIdx] = useState(null);
	const [aiReviseInstruction, setAiReviseInstruction] = useState("");
	const [aiRevising, setAiRevising] = useState(false);
	const [aiReviseError, setAiReviseError] = useState("");
	const [reviseModel, setReviseModel] = useState(() => {
		const m = localStorage.getItem("formup_selected_model_chat");
		return m && !m.includes("-pro") && AVAILABLE_MODELS.some((model) => model.id === m) ? m : "gemini-3.6-flash";
	});
	// A-7: Bulk AI revise
	const [bulkReviseMode, setBulkReviseMode] = useState(false);
	const [bulkReviseSelected, setBulkReviseSelected] = useState(new Set());
	const [bulkReviseInstruction, setBulkReviseInstruction] = useState("");
	const [bulkRevising, setBulkRevising] = useState(false);
	const [bulkRevisePreview, setBulkRevisePreview] = useState([]);
	const [bulkRevisePreviewOpen, setBulkRevisePreviewOpen] = useState(false);
	// Live preview toggle per question
	const [previewVisibility, setPreviewVisibility] = useState({});
	// Split-Screen Dual View (Side-by-side Editor & Live Preview)
	const [isSplitPreview, setIsSplitPreview] = useState(false);
	// A-2: Actions dropdown menu
	const [actionsMenuOpen, setActionsMenuOpen] = useState(false);
	const actionsMenuRef = useRef(null);
	// BUG-3: ConfirmModal state (replaces window.confirm)
	const [confirmModal, setConfirmModal] = useState({
		isOpen: false,
		title: "",
		message: "",
		onConfirm: null,
		variant: "danger"
	});
	// FEAT-11: Dirty state indicator
	const [isDirty, setIsDirty] = useState(false);
	// FEAT-12: Undo/Redo history
	const [history, setHistory] = useState([]);
	const [historyIndex, setHistoryIndex] = useState(-1);
	const historyUpdatingRef = useRef(false);
	// BUG-1/2/3 FIX: keep mirror refs so pushHistory / handleUndo / handleRedo
	// always read the *current* value without stale-closure issues.
	// Previously pushHistory closed over `historyIndex` from its useCallback deps,
	// which caused the wrong slice index when called before a re-render, and the
	// debounced text-edit path captured a stale pushHistory that used an old index.
	const historyRef = useRef([]);
	const historyIndexRef = useRef(-1);
	// Mirror ref so async handlers (upload gambar/audio) always read the
	// latest questions state without stale-closure issues.
	const questionsRef = useRef(questions);
	useEffect(() => {
		questionsRef.current = questions;
	}, [questions]);
	// BUG-3: debounce timer ref for text-edit history
	const textEditDebounceRef = useRef(null);
	// FEAT-14: Autosave
	const [autosaveEnabled, setAutosaveEnabled] = useState(() => {
		try {
			return localStorage.getItem("formup_autosave_pref") === "true";
		} catch {
			return false;
		}
	});
	const autosaveIntervalRef = useRef(null);
	const [autosaveToast, setAutosaveToast] = useState("");
	const [autosaveLastSaved, setAutosaveLastSaved] = useState("");
	// A-6: Floating quick-action button (FAB) on scroll
	const mainScrollRef = useRef(null);
	const [scrolledPastHeader, setScrolledPastHeader] = useState(false);
	const [fabMenuOpen, setFabMenuOpen] = useState(false);
	// Guided Onboarding Tour for Form Builder
	const [builderTourOpen, setBuilderTourOpen] = useState(false);
	// B1: Upload progress per question index { [idx]: 0-100 | null }
	const [uploadProgress, setUploadProgress] = useState({});
	// B9: Ref to store last AI generation params for FAB quick-generate
	const lastAIPromptRef = useRef(null);
	useEffect(() => {
		// Cek apakah ada query param ?tour=builder atau pemicu onboarding
		if (typeof window !== "undefined") {
			const urlParams = new URLSearchParams(window.location.search);
			if (urlParams.get("tour") === "builder") {
				setTimeout(() => setBuilderTourOpen(true), 600);
			}
			window.__startFormUpTour = () => setBuilderTourOpen(true);
		}
		return () => {
			if (typeof window !== "undefined" && window.__startFormUpTour) {
				delete window.__startFormUpTour;
			}
		};
	}, []);
	useEffect(() => {
		const scrollEl = mainScrollRef.current;
		const handleScroll = () => {
			const top = scrollEl ? scrollEl.scrollTop : window.scrollY;
			setScrolledPastHeader(top > 120);
		};
		if (scrollEl) {
			scrollEl.addEventListener("scroll", handleScroll, { passive: true });
		}
		window.addEventListener("scroll", handleScroll, { passive: true });
		return () => {
			if (scrollEl) scrollEl.removeEventListener("scroll", handleScroll);
			window.removeEventListener("scroll", handleScroll);
		};
	}, []);
	// Form settings state
	const [settings, setSettings] = useState({
		formTypeId: 1,
		showScore: false,
		randomizeQuestions: false,
		oneResponse: false,
		requiredLogin: false,
		formToken: "",
		timerDuration: "",
		openFormTime: "",
		closeFormTime: "",
		customFormLink: "",
		isExamMode: false,
		disableCopyPaste: false,
		detectTabSwitch: false,
		autoSubmitOnTabSwitch: false,
		maxTabSwitch: 3,
		themePrimaryColor: "",
		themeBackgroundColor: ""
	});
	// BUG-3: Helper functions for deterministic dirty check (ignoring transient _id timestamps)
	const serializeQuestionsForDirty = useCallback((qList) => {
		if (!Array.isArray(qList)) return "[]";
		return JSON.stringify(qList.map((q) => ({
			typeId: parseInt(q.typeId, 10) || 2,
			question: (q.question || "").trim(),
			questionFormat: q.questionFormat || "text",
			isRequired: !!q.isRequired,
			correctAnswer: (q.correctAnswer || "").trim(),
			points: q.points ?? null,
			questionImage: q.questionImage || null,
			questionAudio: q.questionAudio || null,
			options: (q.options || []).map((o) => ({
				optionText: (o.optionText || "").trim(),
				isCorrect: !!o.isCorrect,
				optionImage: o.optionImage || o.image || o.imageUrl || null
			}))
		})));
	}, []);
	const serializeSettingsForDirty = useCallback((s) => {
		if (!s || typeof s !== "object") return "{}";
		return JSON.stringify({
			formTypeId: parseInt(s.formTypeId, 10) || 1,
			showScore: !!s.showScore,
			randomizeQuestions: !!s.randomizeQuestions,
			oneResponse: !!s.oneResponse,
			requiredLogin: !!s.requiredLogin,
			formToken: (s.formToken || "").trim(),
			timerDuration: s.timerDuration ? String(s.timerDuration) : "",
			openFormTime: s.openFormTime || "",
			closeFormTime: s.closeFormTime || "",
			customFormLink: (s.customFormLink || "").trim(),
			isExamMode: !!s.isExamMode,
			disableCopyPaste: !!s.disableCopyPaste,
			detectTabSwitch: !!s.detectTabSwitch,
			autoSubmitOnTabSwitch: !!s.autoSubmitOnTabSwitch,
			maxTabSwitch: s.maxTabSwitch ? parseInt(s.maxTabSwitch, 10) : 3,
			themePrimaryColor: s.themePrimaryColor || "",
			themeBackgroundColor: s.themeBackgroundColor || ""
		});
	}, []);
	// Single source of truth baseline snapshot for dirty tracking
	const baselineRef = useRef({
		questions: "",
		settings: ""
	});
	// Mark dirty when questions or settings deviate from baseline snapshot
	useEffect(() => {
		if (loading) return;
		if (!baselineRef.current.questions && !baselineRef.current.settings) return;
		const currentQStr = serializeQuestionsForDirty(questions);
		const currentSStr = serializeSettingsForDirty(settings);
		const qDirty = currentQStr !== baselineRef.current.questions;
		const sDirty = currentSStr !== baselineRef.current.settings;
		setIsDirty(qDirty || sDirty);
	}, [
		questions,
		settings,
		loading,
		serializeQuestionsForDirty,
		serializeSettingsForDirty
	]);
	// FEAT-11: beforeunload guard
	useEffect(() => {
		const handler = (e) => {
			if (isDirty) {
				e.preventDefault();
				e.returnValue = "";
			}
		};
		window.addEventListener("beforeunload", handler);
		return () => window.removeEventListener("beforeunload", handler);
	}, [isDirty]);
	useEffect(() => {
		window.__formBuilderDirty = isDirty;
		return () => {
			window.__formBuilderDirty = false;
		};
	}, [isDirty]);
	// BUG-4 FIX: In-app navigation guard.
	// useBlocker intercepts client-side route changes (sidebar links, back button, etc.)
	// that beforeunload does NOT catch inside a SPA. When there are unsaved changes,
	// the blocker fires and we show a custom confirmation dialog instead of silently
	// leaving and losing edits.
	// const navBlocker = useBlocker(
	//     ({ currentLocation, nextLocation }) =>
	//         isDirty && currentLocation.pathname !== nextLocation.pathname
	// );
	// Dismiss the nav-blocker dialog on Escape
	// useEffect(() => {
	//     if (navBlocker.state !== 'blocked') return;
	//     const handler = (e) => { if (e.key === 'Escape') navBlocker.reset(); };
	//     document.addEventListener('keydown', handler);
	//     return () => document.removeEventListener('keydown', handler);
	// }, [navBlocker]);
	// A-2: Close actions menu on outside click
	useEffect(() => {
		const handler = (e) => {
			if (actionsMenuRef.current && !actionsMenuRef.current.contains(e.target)) {
				setActionsMenuOpen(false);
			}
		};
		document.addEventListener("mousedown", handler);
		return () => document.removeEventListener("mousedown", handler);
	}, []);
	// FEAT-11: document.title indicator
	useEffect(() => {
		if (form?.title) {
			document.title = isDirty ? `• ${form.title} — FormUp` : `${form.title} — FormUp`;
		}
		return () => {
			document.title = "FormUp";
		};
	}, [isDirty, form?.title]);
	// FEAT-12: Push to history when questions change due to structural ops.
	// BUG-1/2/3 FIX: Read historyIndexRef.current (always current) instead of
	// the closure-captured historyIndex state value. This eliminates:
	//   • the off-by-one that required 2 actions before undo worked (Bug 1)
	//   • the wrong snapshot being restored because slicing used a stale index (Bug 2)
	//   • the debounced text-edit path firing with a stale pushHistory ref (Bug 3)
	// pushHistory is now stable (no deps) so it is safe to capture in setTimeout.
	const pushHistory = useCallback((snapshotBeforeMutation) => {
		if (historyUpdatingRef.current) return;
		// FIX: Cancel any pending debounced text-edit history push before
		// committing this snapshot. Without this, a debounce timer from an
		// earlier optionText/question edit (e.g. adding an image to an option)
		// can fire AFTER a structural action (remove option, delete question, etc.)
		// has already pushed its own checkpoint — inserting a stale, out-of-order
		// snapshot into history and corrupting undo/redo sequencing.
		if (textEditDebounceRef.current) {
			clearTimeout(textEditDebounceRef.current);
			textEditDebounceRef.current = null;
		}
		const snapshot = JSON.parse(JSON.stringify(snapshotBeforeMutation));
		const currentIdx = historyIndexRef.current;
		const newHistory = [...historyRef.current.slice(0, currentIdx + 1), snapshot].slice(-20);
		const newIndex = newHistory.length - 1;
		historyRef.current = newHistory;
		historyIndexRef.current = newIndex;
		setHistory(newHistory);
		setHistoryIndex(newIndex);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	// FEAT-12: Keyboard listener for Ctrl+Z / Ctrl+Y
	// BUG-1 FIX: handleUndo/Redo are stable (read refs, not closed-over state) so
	// the keyboard effect needs no deps and never re-registers stale handlers.
	useEffect(() => {
		const handler = (e) => {
			if ((e.ctrlKey || e.metaKey) && e.key === "z" && !e.shiftKey) {
				e.preventDefault();
				handleUndo();
			} else if ((e.ctrlKey || e.metaKey) && (e.key === "y" || e.key === "z" && e.shiftKey)) {
				e.preventDefault();
				handleRedo();
			}
		};
		window.addEventListener("keydown", handler);
		return () => window.removeEventListener("keydown", handler);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const handleUndo = () => {
		const idx = historyIndexRef.current;
		if (idx <= 0) return;
		const newIdx = idx - 1;
		historyUpdatingRef.current = true;
		historyIndexRef.current = newIdx;
		setHistoryIndex(newIdx);
		setQuestions(JSON.parse(JSON.stringify(historyRef.current[newIdx])));
		setTimeout(() => {
			historyUpdatingRef.current = false;
		}, 0);
	};
	const handleRedo = () => {
		const idx = historyIndexRef.current;
		if (idx >= historyRef.current.length - 1) return;
		const newIdx = idx + 1;
		historyUpdatingRef.current = true;
		historyIndexRef.current = newIdx;
		setHistoryIndex(newIdx);
		setQuestions(JSON.parse(JSON.stringify(historyRef.current[newIdx])));
		setTimeout(() => {
			historyUpdatingRef.current = false;
		}, 0);
	};
	// FEAT-14: Autosave interval
	useEffect(() => {
		localStorage.setItem("formup_autosave_pref", String(autosaveEnabled));
		if (autosaveIntervalRef.current) clearInterval(autosaveIntervalRef.current);
		if (autosaveEnabled) {
			autosaveIntervalRef.current = setInterval(async () => {
				if (!isDirty) return;
				const ok = await handleSaveAll();
				if (ok) {
					const now = new Date();
					const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
					setAutosaveToast(`Tersimpan otomatis pukul ${hhmm}`);
					setAutosaveLastSaved(`Tersimpan ${new Date().toLocaleTimeString("id-ID", {
						hour: "2-digit",
						minute: "2-digit"
					})}`);
					setTimeout(() => setAutosaveToast(""), 2500);
				}
			}, 15e3);
		}
		return () => {
			if (autosaveIntervalRef.current) clearInterval(autosaveIntervalRef.current);
		};
	}, [
		autosaveEnabled,
		isDirty,
		activeTab
	]);
	const toLocalDatetimeInput = (dateVal) => {
		if (!dateVal) return "";
		const d = new Date(dateVal);
		if (isNaN(d.getTime())) return "";
		const year = d.getFullYear();
		const month = String(d.getMonth() + 1).padStart(2, "0");
		const day = String(d.getDate()).padStart(2, "0");
		const hours = String(d.getHours()).padStart(2, "0");
		const minutes = String(d.getMinutes()).padStart(2, "0");
		return `${year}-${month}-${day}T${hours}:${minutes}`;
	};
	const showToast = (msg, type = "success") => {
		setToast({
			msg,
			type
		});
		setTimeout(() => setToast(null), 3e3);
	};
	// B-1: Total Maksimal Skor (sum of all scorable question points)
	const totalMaxScore = useMemo(() => {
		if (!Array.isArray(questions)) return 0;
		return questions.reduce((total, q) => {
			if (q.isScorable === false) return total;
			const p = Number(q.points);
			return total + (!isNaN(p) && p > 0 ? p : 1);
		}, 0);
	}, [questions]);
	// C-2: Debounce search term 250ms
	useEffect(() => {
		const t = setTimeout(() => {
			setDebouncedSearch(searchTerm);
			setCurrentPage(1);
		}, 250);
		return () => clearTimeout(t);
	}, [searchTerm]);
	// Helper: load questions list with pagination + search params
	const fetchQuestions = useCallback(async ({ page = 1, pageSizeVal = pageSize, search = debouncedSearch, resetTotal = false } = {}) => {
		const qRes = await getQuestions(id, {
			page,
			pageSize: pageSizeVal,
			search
		});
		if (!qRes.ok) {
			showToast(qRes.message || "Gagal memuat daftar soal", "error");
			return null;
		}
		let loadedQuestions = [];
		let total = 0;
		if (Array.isArray(qRes.data)) {
			loadedQuestions = qRes.data;
			total = qRes.data.length;
		} else if (qRes.data && typeof qRes.data === "object") {
			loadedQuestions = qRes.data.questions || qRes.data.items || qRes.data.list || [];
			total = qRes.data.total || qRes.data.totalItems || qRes.data.count || loadedQuestions.length;
		}
		setTotalQuestions(resetTotal || page === 1 ? total : (n) => Math.max(n, total));
		setCurrentPage(page);
		setPageSize(pageSizeVal);
		return loadedQuestions;
	}, [
		id,
		pageSize,
		debouncedSearch
	]);
	// C-2: Re-fetch questions whenever debouncedSearch, currentPage, or pageSize changes
	useEffect(() => {
		if (loading || !id) return;
		const doFetch = async () => {
			const loadedQuestions = await fetchQuestions({ page: currentPage });
			if (loadedQuestions == null) return;
			let final = [];
			if (Array.isArray(loadedQuestions) && loadedQuestions.length > 0) {
				final = loadedQuestions.map((q) => {
					const normalizedOptions = normalizeQuestionOptions(q);
					const hasCorrectOption = normalizedOptions.some((o) => o.isCorrect === true);
					const hasCorrectAnswer = !!(q.correctAnswer && q.correctAnswer.trim());
					const isScorable = q.isScorable !== undefined ? q.isScorable : hasCorrectOption || hasCorrectAnswer;
					return {
						...q,
						_id: `q_${q.id}`,
						isScorable,
						options: normalizedOptions
					};
				});
			} else if (currentPage === 1 && !debouncedSearch) {
				final = [newQuestion(1)];
				setTotalQuestions(0);
			}
			setQuestions(final);
		};
		doFetch();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [
		currentPage,
		debouncedSearch,
		pageSize,
		id
	]);
	useEffect(() => {
		const load = async () => {
			setLoading(true);
			const formRes = await getFormById(id);
			const loadedQuestionsRaw = await fetchQuestions({
				page: 1,
				resetTotal: true
			});
			if (formRes.status === 401) {
				clearSession();
				navigate("/login");
				return;
			}
			let loadedSettings = { ...settings };
			if (formRes.ok && formRes.data) {
				const f = formRes.data;
				setForm(f);
				const s = f.settings || {};
				loadedSettings = {
					formTypeId: s.formTypeId ?? 1,
					showScore: s.showScore ?? false,
					randomizeQuestions: s.randomizeQuestions ?? false,
					oneResponse: s.oneResponse ?? false,
					requiredLogin: s.requiredLogin ?? false,
					formToken: s.formToken ?? "",
					timerDuration: s.timerDuration ? Math.round(s.timerDuration / 60) : "",
					openFormTime: toLocalDatetimeInput(s.openFormTime),
					closeFormTime: toLocalDatetimeInput(s.closeFormTime),
					customFormLink: f.formLink || "",
					isExamMode: s.isExamMode ?? false,
					disableCopyPaste: s.disableCopyPaste ?? false,
					detectTabSwitch: s.detectTabSwitch ?? false,
					autoSubmitOnTabSwitch: s.autoSubmitOnTabSwitch ?? false,
					maxTabSwitch: s.maxTabSwitch ?? 3,
					themePrimaryColor: s.themePrimaryColor ?? "",
					themeBackgroundColor: s.themeBackgroundColor ?? ""
				};
				setSettings(loadedSettings);
			}
			let loadedQuestions = [];
			if (Array.isArray(loadedQuestionsRaw) && loadedQuestionsRaw.length > 0) {
				loadedQuestions = loadedQuestionsRaw.map((q) => {
					const normalizedOptions = normalizeQuestionOptions(q);
					const hasCorrectOption = normalizedOptions.some((o) => o.isCorrect === true);
					const hasCorrectAnswer = !!(q.correctAnswer && q.correctAnswer.trim());
					const isScorable = q.isScorable !== undefined ? q.isScorable : hasCorrectOption || hasCorrectAnswer;
					return {
						...q,
						_id: `q_${q.id}`,
						isScorable,
						options: normalizedOptions
					};
				});
			} else {
				loadedQuestions = [newQuestion(1)];
			}
			setQuestions(loadedQuestions);
			// BUG-3 FIX: Seed undo/redo history with the initial loaded state so
			// the first Ctrl+Z always has a valid snapshot to return to.
			// Also seed the mirror refs so pushHistory reads a consistent initial index.
			const seedSnapshot = JSON.parse(JSON.stringify(loadedQuestions));
			historyRef.current = [seedSnapshot];
			historyIndexRef.current = 0;
			setHistory([seedSnapshot]);
			setHistoryIndex(0);
			// Establish clean baseline snapshot for new/loaded form
			baselineRef.current = {
				questions: serializeQuestionsForDirty(loadedQuestions),
				settings: serializeSettingsForDirty(loadedSettings)
			};
			setIsDirty(false);
			setLoading(false);
		};
		load();
	}, [
		id,
		navigate,
		serializeQuestionsForDirty,
		serializeSettingsForDirty
	]);
	const handleSaveQuestions = async () => {
		setSaving(true);
		// 0 soal diperbolehkan: kirim array kosong -> backend hapus semua soal
		const payloadQuestions = questions.map((q, i) => {
			const scorable = q.isScorable !== false;
			return {
				id: q.id ?? undefined,
				typeId: parseInt(q.typeId),
				question: q.question || "",
				questionFormat: q.questionFormat || "text",
				questionOrder: i + 1,
				isRequired: !!q.isRequired,
				correctAnswer: scorable ? q.correctAnswer || null : null,
				points: scorable && q.points ? parseInt(q.points, 10) : null,
				questionImage: q.questionImage || null,
				questionAudio: q.questionAudio || null,
				options: (q.options || []).map((opt) => ({
					optionText: opt.optionText || "",
					isCorrect: scorable ? !!opt.isCorrect : false,
					optionImage: opt.optionImage || opt.image || opt.imageUrl || null
				}))
			};
		});
		const res = await saveQuestions(id, payloadQuestions);
		setSaving(false);
		if (res.ok) {
			showToast(payloadQuestions.length === 0 ? "Semua soal berhasil dihapus!" : "Soal berhasil disimpan!");
			let freshQuestions = [];
			const qRes = await getQuestions(id);
			if (qRes.ok && Array.isArray(qRes.data)) {
				if (qRes.data.length === 0) {
					freshQuestions = [];
				} else {
					freshQuestions = qRes.data.map((q, i) => {
						const normalizedOptions = normalizeQuestionOptions(q);
						return {
							...q,
							_id: questions[i]?._id || `q_${q.id}`,
							isScorable: questions[i]?.isScorable ?? (normalizedOptions.some((o) => o.isCorrect === true) || !!(q.correctAnswer && q.correctAnswer.trim())),
							points: q.points ?? null,
							options: normalizedOptions
						};
					});
				}
				setQuestions(freshQuestions);
				// Jika form kehabisan soal, status otomatis kembali draft
				const refreshed = await getFormById(id);
				if (refreshed.ok && refreshed.data) setForm(refreshed.data);
			} else {
				freshQuestions = questions;
			}
			baselineRef.current.questions = serializeQuestionsForDirty(freshQuestions);
			const sDirty = serializeSettingsForDirty(settings) !== baselineRef.current.settings;
			setIsDirty(sDirty);
			return true;
		} else {
			showToast(res.message || "Gagal menyimpan soal.", "error");
			return false;
		}
	};
	const handleClearAllQuestions = () => {
		if (questions.length === 0) return;
		setConfirmModal({
			isOpen: true,
			title: "Hapus Semua Soal?",
			message: "Hapus semua soal? Perubahan berlaku setelah Simpan.",
			variant: "danger",
			onConfirm: () => {
				pushHistory(questions);
				setQuestions([]);
				showToast("Semua soal dihapus dari draf. Tekan Simpan untuk menyimpan perubahan.", "success");
				setConfirmModal((prev) => ({
					...prev,
					isOpen: false
				}));
			}
		});
	};
	const handleSaveSettings = async () => {
		setSaving(true);
		if (settings.customFormLink && settings.customFormLink !== form.formLink) {
			const formRes = await updateForm(id, {
				title: form.title,
				description: form.description,
				formLink: settings.customFormLink
			});
			if (!formRes.ok) {
				showToast(formRes.message || "Gagal memperbarui slug tautan formulir", "error");
				setSaving(false);
				return false;
			}
			setForm((prev) => ({
				...prev,
				formLink: settings.customFormLink
			}));
		}
		const parsedTimer = parseInt(settings.timerDuration, 10);
		const timerValue = !isNaN(parsedTimer) && parsedTimer > 0 ? parsedTimer * 60 : null;
		const res = await updateFormSettings(id, {
			formTypeId: parseInt(settings.formTypeId, 10) || 1,
			showScore: !!settings.showScore,
			randomizeQuestions: !!settings.randomizeQuestions,
			oneResponse: !!settings.oneResponse,
			requiredLogin: !!settings.requiredLogin,
			formToken: settings.formToken ? settings.formToken.trim() : null,
			timerDuration: timerValue,
			openFormTime: settings.openFormTime ? new Date(settings.openFormTime).toISOString() : null,
			closeFormTime: settings.closeFormTime ? new Date(settings.closeFormTime).toISOString() : null,
			isExamMode: !!settings.isExamMode,
			disableCopyPaste: !!settings.disableCopyPaste,
			detectTabSwitch: !!settings.detectTabSwitch,
			autoSubmitOnTabSwitch: !!settings.autoSubmitOnTabSwitch,
			maxTabSwitch: settings.maxTabSwitch ? parseInt(settings.maxTabSwitch, 10) : null,
			themePrimaryColor: settings.themePrimaryColor || null,
			themeBackgroundColor: settings.themeBackgroundColor || null
		});
		setSaving(false);
		if (res.ok) {
			let nextSettings = { ...settings };
			const refreshed = await getFormById(id);
			if (refreshed.ok && refreshed.data) {
				const f = refreshed.data;
				setForm(f);
				const s = f.settings || {};
				nextSettings = {
					formTypeId: s.formTypeId ?? 1,
					showScore: s.showScore ?? false,
					randomizeQuestions: s.randomizeQuestions ?? false,
					oneResponse: s.oneResponse ?? false,
					requiredLogin: s.requiredLogin ?? false,
					formToken: s.formToken ?? "",
					timerDuration: s.timerDuration ? Math.round(s.timerDuration / 60) : "",
					openFormTime: toLocalDatetimeInput(s.openFormTime),
					closeFormTime: toLocalDatetimeInput(s.closeFormTime),
					customFormLink: f.formLink || "",
					isExamMode: s.isExamMode ?? false,
					disableCopyPaste: s.disableCopyPaste ?? false,
					detectTabSwitch: s.detectTabSwitch ?? false,
					autoSubmitOnTabSwitch: s.autoSubmitOnTabSwitch ?? false,
					maxTabSwitch: s.maxTabSwitch ?? 3,
					themePrimaryColor: s.themePrimaryColor ?? "",
					themeBackgroundColor: s.themeBackgroundColor ?? ""
				};
				setSettings(nextSettings);
			}
			baselineRef.current.settings = serializeSettingsForDirty(nextSettings);
			const qDirty = serializeQuestionsForDirty(questions) !== baselineRef.current.questions;
			setIsDirty(qDirty);
			showToast("Pengaturan formulir berhasil disimpan!");
			return true;
		} else {
			showToast(res.message || "Gagal menyimpan pengaturan", "error");
			return false;
		}
	};
	// BUG-3: Unified save handler that saves questions, settings, or both based on dirty state
	const handleSaveAll = async () => {
		const qDirty = serializeQuestionsForDirty(questions) !== baselineRef.current.questions;
		const sDirty = serializeSettingsForDirty(settings) !== baselineRef.current.settings;
		let okQ = true;
		let okS = true;
		if (qDirty || activeTab === "questions") {
			okQ = await handleSaveQuestions();
		}
		if (sDirty || activeTab === "settings") {
			okS = await handleSaveSettings();
		}
		return okQ && okS;
	};
	const handleTogglePublish = async () => {
		setPublishing(true);
		const res = await togglePublishForm(id);
		if (res.ok) {
			const updated = await getFormById(id);
			if (updated.ok) setForm(updated.data);
			showToast(res.message || "Status publikasi formulir berhasil diubah!");
		} else {
			showToast(res.message || "Gagal mengubah status publikasi", "error");
		}
		setPublishing(false);
	};
	const handleLoadShare = useCallback(async () => {
		const res = await getFormShare(id);
		if (res.ok) {
			setShareInfo(res.data);
			const token = localStorage.getItem("token");
			const qrRes = await fetch(`${API_BASE_URL}/api/forms/${id}/share/qr?frontendUrl=${encodeURIComponent(FRONTEND_BASE_URL)}`, { headers: { Authorization: `Bearer ${token}` } });
			if (qrRes.ok) {
				const blob = await qrRes.blob();
				setQrBlobUrl(URL.createObjectURL(blob));
			}
		}
	}, [id]);
	const handleBannerUpload = async (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const res = await uploadFormBanner(id, file);
		if (res.ok) {
			const updated = await getFormById(id);
			if (updated.ok) setForm(updated.data);
			showToast("Banner formulir berhasil diunggah!");
		} else {
			showToast(res.message || "Gagal mengunggah banner", "error");
		}
	};
	// Helper: refresh question list from API (post-import, post-clear)
	const refreshQuestionsList = async (opts = {}) => {
		const qRes = await fetchQuestions({
			page: 1,
			resetTotal: true,
			...opts
		});
		if (qRes == null) return;
		let fresh = [];
		if (Array.isArray(qRes) && qRes.length > 0) {
			fresh = qRes.map((q, i) => {
				const normalizedOptions = normalizeQuestionOptions(q);
				const hasCorrectOption = normalizedOptions.some((o) => o.isCorrect === true);
				const hasCorrectAnswer = !!(q.correctAnswer && q.correctAnswer.trim());
				const isScorable = q.isScorable !== undefined ? q.isScorable : hasCorrectOption || hasCorrectAnswer;
				return {
					...q,
					_id: `q_${q.id}`,
					question: q.question || "",
					typeId: q.typeId || 2,
					questionOrder: q.questionOrder ?? i + 1,
					isRequired: q.isRequired ?? false,
					isScorable,
					correctAnswer: q.correctAnswer ?? "",
					questionImage: q.questionImage ?? null,
					questionAudio: q.questionAudio ?? null,
					options: normalizedOptions
				};
			});
		} else if (!opts.search || opts.search === "") {
			fresh = [newQuestion(1)];
			setTotalQuestions(0);
		}
		setQuestions(fresh);
		pushHistory(fresh);
	};
	// A-2: Callback after ImportQuestionsModal successfully commits import
	const handleOnImported = async (data = {}) => {
		showToast(`Berhasil mengimpor ${data.totalImported ?? 0} soal!`);
		const imported = Array.isArray(data.questions) ? data.questions : [];
		if (imported.length === 0) return;
		pushHistory(questions);
		const mapped = imported.map((q, index) => {
			const normalizedOptions = normalizeQuestionOptions(q);
			return {
				...q,
				id: null,
				_id: `q_import_${Date.now()}_${index}`,
				questionOrder: questions.length + index + 1,
				question: q.question || q.questionText || "",
				typeId: parseInt(q.typeId, 10) || 2,
				isRequired: q.isRequired ?? false,
				isScorable: q.isScorable ?? (normalizedOptions.some((o) => o.isCorrect) || Boolean(q.correctAnswer)),
				options: normalizedOptions
			};
		});
		setQuestions((prev) => [...prev, ...mapped]);
	};
	// BUG-2 FIX: Stage deletion locally; only committed on "Simpan Perubahan".
	// Previously called the delete API immediately, which caused permanent deletion
	// even when the user left without saving. Now matches the same pattern used by
	// handleClearAllQuestions (local-only until save).
	const handleDeleteQuestion = (idx) => {
		const next = questions.filter((_, i) => i !== idx);
		pushHistory(questions);
		setQuestions(next);
		showToast("Soal dihapus dari draf. Tekan Simpan untuk menyimpan perubahan.", "success");
	};
	// FEAT-10a: Duplicate question
	const handleDuplicateQuestion = (idx) => {
		const orig = questions[idx];
		const dupe = {
			...JSON.parse(JSON.stringify(orig)),
			_id: `q_dup_${Date.now()}`,
			id: null
		};
		// BUG-3 FIX: push snapshot BEFORE mutation
		pushHistory(questions);
		setQuestions((prev) => {
			const next = [...prev];
			next.splice(idx + 1, 0, dupe);
			return next;
		});
		showToast("Soal berhasil diduplikasi");
	};
	// FEAT-8: Export questions as CSV
	const handleExportQuestions = () => {
		if (questions.length === 0) {
			showToast("Tidak ada soal untuk diekspor.", "error");
			return;
		}
		const rows = [[
			"question",
			"type_id",
			"order",
			"is_required",
			"correct_answer",
			"options"
		]];
		questions.forEach((q, i) => {
			const isChoice = q.typeId === 2 || q.typeId === 3;
			const optionsStr = (q.options || []).map((o) => o.isCorrect ? `[BENAR] ${o.optionText}` : o.optionText).join("|");
			const cleanQ = (q.question || "").replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
			const correctCa = isChoice ? (q.options || []).filter((o) => o.isCorrect).map((o) => o.optionText).join(",") : q.correctAnswer || "";
			rows.push([
				`"${cleanQ.replace(/"/g, "\"\"")}"`,
				q.typeId || 2,
				i + 1,
				q.isRequired ? "true" : "false",
				`"${(correctCa || "").replace(/"/g, "\"\"")}"`,
				`"${optionsStr.replace(/"/g, "\"\"")}"`
			]);
		});
		const csv = "﻿" + rows.map((r) => r.join(",")).join("\r\n");
		const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `soal-${(form?.title || "formulir").replace(/\s+/g, "_")}-${Date.now()}.csv`;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		URL.revokeObjectURL(url);
		showToast("File soal CSV berhasil diunduh!");
	};
	// AI-2: Revise question with AI
	const handleAiRevise = async (idx) => {
		const q = questions[idx];
		if (!aiReviseInstruction.trim()) {
			setAiReviseError("Masukkan instruksi revisi.");
			return;
		}
		setAiRevising(true);
		setAiReviseError("");
		try {
			const res = await reviseQuestionWithAI({
				question: q.question,
				options: q.options || [],
				correctAnswer: q.correctAnswer,
				typeId: q.typeId,
				isRequired: q.isRequired,
				isScorable: q.isScorable,
				instruction: aiReviseInstruction,
				selectedModel: reviseModel,
				customApiKey: getGeminiApiKey()
			});
			if (!res.ok) {
				setAiReviseError(res.message || "Gagal merevisi soal.");
				return;
			}
			const revised = res.data;
			updateQuestion(idx, "question", revised.question || q.question);
			if (revised.options && revised.options.length > 0) {
				setQuestions((prev) => prev.map((qq, qi) => qi === idx ? {
					...qq,
					question: revised.question || qq.question,
					options: revised.options,
					correctAnswer: revised.correctAnswer || qq.correctAnswer
				} : qq));
			} else {
				updateQuestion(idx, "correctAnswer", revised.correctAnswer || q.correctAnswer);
			}
			setAiReviseOpenIdx(null);
			setAiReviseInstruction("");
			showToast("Soal berhasil direvisi oleh AI!");
		} catch (err) {
			setAiReviseError("Gagal merevisi soal: " + err.message);
		} finally {
			setAiRevising(false);
		}
	};
	// A-7: Bulk AI Revise handler
	const handleBulkAiRevise = async () => {
		if (!bulkReviseInstruction.trim()) {
			showToast("Masukkan instruksi revisi.", "error");
			return;
		}
		if (bulkReviseSelected.size === 0) {
			showToast("Pilih minimal 1 soal untuk direvisi.", "error");
			return;
		}
		setBulkRevising(true);
		try {
			const res = await bulkReviseQuestionsWithAI({
				questions,
				selectedIndices: Array.from(bulkReviseSelected),
				instruction: bulkReviseInstruction,
				selectedModel: reviseModel,
				customApiKey: getGeminiApiKey()
			});
			if (!res.ok) {
				showToast(res.message || "Gagal merevisi soal massal.", "error");
				return;
			}
			const results = res.data || [];
			if (results.length > 0) {
				setBulkRevisePreview(results);
				setBulkRevisePreviewOpen(true);
			} else {
				showToast("Tidak ada soal yang berhasil direvisi.", "error");
			}
		} catch (err) {
			showToast("Gagal merevisi: " + err.message, "error");
		} finally {
			setBulkRevising(false);
		}
	};
	const applyBulkReviseItem = (idx, revised) => {
		setQuestions((prev) => prev.map((q, qi) => qi === idx ? {
			...q,
			question: revised.question || q.question,
			options: revised.options?.length > 0 ? revised.options : q.options,
			correctAnswer: revised.correctAnswer || q.correctAnswer
		} : q));
	};
	// Auto-save questions helper for unsaved questions before uploading image/audio
	const autoSaveBeforeUpload = async (idx) => {
		let currentQ = questions[idx];
		if (!currentQ.id) {
			const success = await handleSaveQuestions();
			if (!success) return null;
			const updatedList = await getQuestions(id);
			if (updatedList.ok && Array.isArray(updatedList.data) && updatedList.data[idx]) {
				return updatedList.data[idx].id;
			}
		}
		return currentQ.id;
	};
	// Pastikan soal DAN opsi sudah punya id asli dari backend sebelum upload gambar opsi
	const ensureOptionSaved = async (idx, oIdx) => {
		const currentOpt = questions[idx]?.options?.[oIdx];
		if (questions[idx]?.id && currentOpt?.id) {
			return {
				questionId: questions[idx].id,
				optionId: currentOpt.id
			};
		}
		// Simpan dulu supaya backend assign id untuk soal & opsinya
		const success = await handleSaveQuestions();
		if (!success) return null;
		const updatedList = await getQuestions(id);
		if (updatedList.ok && Array.isArray(updatedList.data)) {
			const freshQ = updatedList.data[idx];
			const freshOpt = freshQ?.options?.[oIdx] ?? freshQ?.optionQuestions?.[oIdx];
			if (freshQ?.id && freshOpt?.id) {
				return {
					questionId: freshQ.id,
					optionId: freshOpt.id
				};
			}
		}
		return null;
	};
	const handleUploadQuestionImage = async (idx, file) => {
		try {
			const snapshotBeforeUpload = JSON.parse(JSON.stringify(questionsRef.current));
			const qId = await autoSaveBeforeUpload(idx);
			if (!qId) {
				showToast("Gagal memproses soal sebelum mengunggah gambar", "error");
				return;
			}
			const res = await uploadQuestionImage(id, qId, file, (pct) => {
				setUploadProgress((prev) => ({
					...prev,
					[idx]: pct
				}));
			});
			if (res.ok) {
				pushHistory(snapshotBeforeUpload);
				updateQuestion(idx, "questionImage", res.data?.questionImage ?? null);
				showToast("Gambar soal berhasil diunggah!");
			} else {
				showToast(res.message || "Gagal mengunggah gambar", "error");
			}
		} catch (err) {
			console.error("[Upload Image Error]:", err);
			showToast("Terjadi kesalahan saat mengunggah gambar", "error");
		} finally {
			setUploadProgress((prev) => ({
				...prev,
				[idx]: null
			}));
		}
	};
	const handleUploadQuestionAudio = async (idx, file) => {
		try {
			const snapshotBeforeUpload = JSON.parse(JSON.stringify(questionsRef.current));
			const qId = await autoSaveBeforeUpload(idx);
			if (!qId) {
				showToast("Gagal memproses soal sebelum mengunggah audio", "error");
				return;
			}
			const res = await uploadQuestionAudio(id, qId, file, (pct) => {
				setUploadProgress((prev) => ({
					...prev,
					[idx]: pct
				}));
			});
			if (res.ok) {
				pushHistory(snapshotBeforeUpload);
				updateQuestion(idx, "questionAudio", res.data?.questionAudio ?? null);
				showToast("Audio soal berhasil diunggah!");
			} else {
				showToast(res.message || "Gagal mengunggah audio", "error");
			}
		} catch (err) {
			console.error("[Upload Audio Error]:", err);
			showToast("Terjadi kesalahan saat mengunggah audio", "error");
		} finally {
			setUploadProgress((prev) => ({
				...prev,
				[idx]: null
			}));
		}
	};
	const handleRemoveQuestionImage = (idx) => {
		pushHistory(questions);
		updateQuestion(idx, "questionImage", null);
	};
	const handleRemoveQuestionAudio = (idx) => {
		pushHistory(questions);
		updateQuestion(idx, "questionAudio", null);
	};
	const addQuestion = () => {
		// BUG-3 FIX: push snapshot BEFORE mutation so undo restores the previous state
		pushHistory(questions);
		setQuestions((prev) => [...prev, newQuestion(prev.length + 1)]);
	};
	const handleAddAIQuestions = (newGeneratedQuestions) => {
		if (!newGeneratedQuestions || newGeneratedQuestions.length === 0) return;
		setQuestions((prev) => {
			const startOrder = prev.length + 1;
			const mapped = newGeneratedQuestions.map((q, idx) => ({
				...q,
				_id: `q_ai_${Date.now()}_${idx}`,
				questionOrder: startOrder + idx
			}));
			return [...prev, ...mapped];
		});
		showToast(`Berhasil menambahkan ${newGeneratedQuestions.length} butir soal dari AI!`, "success");
	};
	const moveQuestion = (idx, dir) => {
		// BUG-3 FIX: push snapshot BEFORE mutation
		pushHistory(questions);
		setQuestions((prev) => {
			const arr = [...prev];
			const target = idx + dir;
			if (target < 0 || target >= arr.length) return arr;
			[arr[idx], arr[target]] = [arr[target], arr[idx]];
			return arr;
		});
	};
	const updateQuestion = (idx, field, value) => {
		// BUG-3 FIX: track text edits in undo/redo history with a 500ms debounce.
		// Only text-type fields trigger history; structural fields (typeId, isRequired,
		// isScorable, points) are intentionally excluded — those changes are rarely undone
		// and fire on single interactions (toggles/selects), not continuous typing.
		const isTextField = ["question", "correctAnswer"].includes(field);
		if (isTextField) {
			if (textEditDebounceRef.current) clearTimeout(textEditDebounceRef.current);
			// Capture the CURRENT questions state (before this keystroke) for the snapshot.
			// We store it in the timeout closure so sequential keystrokes reuse the same
			// pre-edit snapshot until the user pauses.
			const snapshotBeforeEditing = JSON.parse(JSON.stringify(questions));
			textEditDebounceRef.current = setTimeout(() => {
				if (!historyUpdatingRef.current) {
					pushHistory(snapshotBeforeEditing);
				}
				textEditDebounceRef.current = null;
			}, 500);
		}
		setQuestions((prev) => prev.map((q, i) => i === idx ? {
			...q,
			[field]: value
		} : q));
	};
	const openInsertModal = (qIdx, mode, targetType = "question", oIdx = null) => {
		setModalTarget({
			type: targetType,
			qIdx,
			oIdx
		});
		setModalMode(mode);
		setModalOpen(true);
	};
	const handleInsertFromModal = (snippetHtml) => {
		const { type, qIdx, oIdx } = modalTarget;
		if (qIdx === null) return;
		if (type === "option" && oIdx !== null) {
			const current = questions[qIdx]?.options?.[oIdx]?.optionText || "";
			updateOption(qIdx, oIdx, "optionText", current + (current ? " " : "") + snippetHtml);
		} else {
			const current = questions[qIdx]?.question || "";
			updateQuestion(qIdx, "question", current + snippetHtml);
		}
	};
	const togglePreview = (idx) => {
		setPreviewVisibility((prev) => ({
			...prev,
			[idx]: !prev[idx]
		}));
	};
	const addOption = (qIdx) => {
		pushHistory(questions);
		setQuestions((prev) => prev.map((q, i) => i === qIdx ? {
			...q,
			options: [...q.options, {
				optionText: "",
				isCorrect: false
			}]
		} : q));
	};
	const removeOption = (qIdx, oIdx) => {
		pushHistory(questions);
		setQuestions((prev) => prev.map((q, i) => i === qIdx ? {
			...q,
			options: q.options.filter((_, oi) => oi !== oIdx)
		} : q));
	};
	const updateOption = (qIdx, oIdx, field, val) => {
		// BUG-3 FIX: debounced history for option text edits
		if (field === "optionText") {
			if (textEditDebounceRef.current) clearTimeout(textEditDebounceRef.current);
			const snapshotBeforeEditing = JSON.parse(JSON.stringify(questions));
			textEditDebounceRef.current = setTimeout(() => {
				if (!historyUpdatingRef.current) {
					pushHistory(snapshotBeforeEditing);
				}
				textEditDebounceRef.current = null;
			}, 500);
		}
		setQuestions((prev) => prev.map((q, i) => {
			if (i !== qIdx) return q;
			const opts = q.options.map((opt, oi) => {
				if (oi !== oIdx) return opt;
				return {
					...opt,
					[field]: val
				};
			});
			return {
				...q,
				options: opts
			};
		}));
	};
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-center min-h-screen bg-[#F4F8F7] dark:bg-slate-950",
			children: /* @__PURE__ */ _jsxDEV("p", {
				className: "text-slate-400 dark:text-slate-500 text-sm font-medium",
				children: "Memuat builder formulir..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1273,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 1272,
			columnNumber: 13
		}, this);
	}
	const isPublished = form?.status?.toLowerCase() === "published";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen w-full bg-[#F4F8F7] dark:bg-slate-950 font-sans text-slate-800 dark:text-slate-100 transition-colors",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1282,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				ref: mainScrollRef,
				className: `flex-1 flex flex-col min-w-0 ${isSplitPreview && activeTab === "questions" ? "h-screen overflow-hidden" : "min-h-screen overflow-y-auto"}`,
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 px-4 sm:px-6 py-3 flex items-center justify-between gap-4 shadow-xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3 min-w-0",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									if (isDirty) {
										setConfirmModal({
											isOpen: true,
											title: "Perubahan Belum Disimpan",
											message: "Ada perubahan yang belum disimpan. Yakin ingin meninggalkan halaman ini?",
											variant: "danger",
											confirmText: "Ya, Tinggalkan",
											onConfirm: () => {
												setConfirmModal((prev) => ({
													...prev,
													isOpen: false
												}));
												navigate("/my-forms");
											}
										});
										return;
									}
									navigate("/my-forms");
								},
								className: "p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl transition-all cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1306,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1289,
								columnNumber: 45
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("h1", {
										className: "text-sm sm:text-base font-extrabold text-slate-900 dark:text-white truncate",
										children: form?.title || "Formulir Tanpa Judul"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1310,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: `text-[10px] font-extrabold px-2 py-0.5 rounded-full ${isPublished ? "bg-teal-50 text-[#00897B] dark:bg-teal-950/60 dark:text-teal-400 border border-teal-200 dark:border-teal-800" : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400"}`,
										children: isPublished ? "Publik" : "Draf"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1311,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1309,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400 dark:text-slate-500 font-mono",
									children: ["/f/", form?.formLink]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1315,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1308,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1288,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 shrink-0",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleTogglePublish,
									disabled: publishing,
									"data-tour": "builder-publish-btn",
									className: `flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${isPublished ? "bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800 hover:bg-amber-100" : "bg-[#00897B] hover:bg-[#00796B] text-white shadow-xs"}`,
									children: [isPublished ? /* @__PURE__ */ _jsxDEV(Lock, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1326,
										columnNumber: 44
									}, this) : /* @__PURE__ */ _jsxDEV(Globe, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1326,
										columnNumber: 65
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "hidden sm:inline",
										children: publishing ? "Memproses..." : isPublished ? "Jadikan Draf" : "Publikasikan"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1327,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1320,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									title: "Lihat sebagai Responden (Preview Tab Baru)",
									"data-tour": "builder-preview-btn",
									onClick: () => window.open(`/f/${form?.formLink}?preview=true&formId=${form?.id}`, "_blank"),
									className: "hidden sm:flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-all cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(Eye, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1338,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Preview" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1339,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1331,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									title: "Dual View: Tampilkan Editor dan Live Preview Berdampingan",
									onClick: () => setIsSplitPreview((prev) => !prev),
									className: `hidden lg:flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${isSplitPreview ? "bg-teal-600 text-white border-teal-600 shadow-xs" : "bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700"}`,
									children: [/* @__PURE__ */ _jsxDEV(Columns, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1353,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Dual View ", isSplitPreview ? "ON" : "OFF"] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1354,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1343,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "hidden lg:flex items-center gap-2 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setAutosaveEnabled((prev) => !prev),
										className: `flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${autosaveEnabled ? "text-teal-600 dark:text-teal-400" : "text-slate-400 dark:text-slate-500"}`,
										title: "Simpan perubahan otomatis setiap 15 detik saat ada perubahan",
										children: [autosaveEnabled ? /* @__PURE__ */ _jsxDEV(ToggleRight, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1365,
											columnNumber: 52
										}, this) : /* @__PURE__ */ _jsxDEV(ToggleLeft, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1365,
											columnNumber: 80
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Auto-Save ", autosaveEnabled ? "ON" : "OFF"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1366,
											columnNumber: 33
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1359,
										columnNumber: 29
									}, this), autosaveEnabled && autosaveLastSaved && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 dark:text-slate-500 font-medium",
										children: autosaveLastSaved
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1369,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1358,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSaveAll,
									disabled: saving,
									"data-tour": "builder-save-btn",
									className: `relative flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer disabled:opacity-60 ${isDirty ? "bg-orange-500 hover:bg-orange-600 text-white animate-pulse" : "bg-slate-900 hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 text-white"}`,
									children: [/* @__PURE__ */ _jsxDEV(Save, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1385,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: saving ? "Menyimpan..." : isDirty ? "⚠ Simpan Sekarang" : "Simpan Perubahan" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1386,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1375,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setBuilderTourOpen(true),
									className: "flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-[#00897B] dark:text-teal-400 hover:bg-teal-100 transition-all cursor-pointer",
									title: "Panduan Form Builder",
									children: [/* @__PURE__ */ _jsxDEV(HelpCircle, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1396,
										columnNumber: 29
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "hidden md:inline",
										children: "Panduan"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1397,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1390,
									columnNumber: 25
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1319,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1287,
						columnNumber: 17
					}, this),
					toast && /* @__PURE__ */ _jsxDEV("div", {
						className: `fixed top-16 right-6 z-50 px-4 py-3 rounded-2xl shadow-xl text-xs font-bold text-white transition-all ${toast.type === "error" ? "bg-red-500" : "bg-[#00897B]"}`,
						children: toast.msg
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1403,
						columnNumber: 21
					}, this),
					autosaveToast && /* @__PURE__ */ _jsxDEV("div", {
						className: "fixed top-16 right-6 z-50 px-4 py-3 rounded-2xl shadow-xl text-xs font-bold text-white bg-teal-600 flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV(Save, { size: 13 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1410,
								columnNumber: 25
							}, this),
							" ",
							autosaveToast
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1409,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex border-b border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 px-6",
						"data-tour": "builder-tabs",
						children: [
							{
								key: "questions",
								label: "Pertanyaan & Soal",
								tourId: "tab-questions"
							},
							{
								key: "settings",
								label: "Pengaturan & Aturan",
								tourId: "tab-settings"
							},
							{
								key: "share",
								label: "Bagikan & Kode QR",
								tourId: "tab-share"
							}
						].map((t) => /* @__PURE__ */ _jsxDEV("button", {
							"data-tour": t.tourId,
							onClick: () => {
								setActiveTab(t.key);
								if (t.key === "share") handleLoadShare();
							},
							className: `py-3.5 px-5 text-xs font-extrabold border-b-2 transition-all cursor-pointer whitespace-nowrap ${activeTab === t.key ? "border-[#00897B] text-[#00897B] dark:border-teal-400 dark:text-teal-400" : "border-transparent text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"}`,
							children: t.label
						}, t.key, false, {
							fileName: _jsxFileName,
							lineNumber: 1421,
							columnNumber: 25
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1415,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: `p-4 sm:p-6 lg:p-8 mx-auto w-full transition-all ${isSplitPreview && activeTab === "questions" ? "max-w-[1700px] flex-1 h-[calc(100vh-120px)] overflow-hidden flex flex-col" : "max-w-4xl space-y-6 flex-1"}`,
						children: [
							activeTab === "questions" && /* @__PURE__ */ _jsxDEV("div", {
								className: `flex flex-col ${isSplitPreview ? "lg:flex-row gap-6 items-start h-full overflow-hidden" : "gap-6"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `w-full space-y-6 flex-1 ${isSplitPreview ? "lg:w-[54%] h-full overflow-y-auto pr-2 pb-24" : ""}`,
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 space-y-4 shadow-xs",
											children: [
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "text-xs font-bold text-slate-500 dark:text-slate-400 block mb-1",
													children: "Judul Formulir"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1445,
													columnNumber: 37
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													value: form?.title || "",
													onChange: (e) => setForm((f) => ({
														...f,
														title: e.target.value
													})),
													onBlur: () => updateForm(id, {
														title: form.title,
														description: form.description
													}),
													placeholder: "Judul Formulir...",
													className: "w-full text-xl font-extrabold bg-transparent text-slate-900 dark:text-white border-b border-transparent hover:border-slate-200 dark:hover:border-slate-700 focus:border-[#00897B] focus:outline-none py-1 transition-all"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1446,
													columnNumber: 37
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1444,
													columnNumber: 33
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "text-xs font-bold text-slate-500 dark:text-slate-400 block mb-1",
													children: "Deskripsi Formulir"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1457,
													columnNumber: 37
												}, this), /* @__PURE__ */ _jsxDEV(BlockQuestionEditor, {
													value: form?.description || "",
													onChange: (newHtml) => setForm((f) => ({
														...f,
														description: newHtml
													})),
													placeholder: "Tuliskan petunjuk atau deskripsi umum formulir..."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1458,
													columnNumber: 37
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1456,
													columnNumber: 33
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-3",
														children: [form?.bannerImage && /* @__PURE__ */ _jsxDEV("img", {
															src: assetUrl(form.bannerImage),
															alt: "Banner",
															className: "w-16 h-10 object-cover rounded-lg border border-slate-200 dark:border-slate-700"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1469,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs font-bold text-slate-600 dark:text-slate-300",
															children: form?.bannerImage ? "Gambar Banner Terpasang" : "Belum Ada Gambar Banner"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1471,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1467,
														columnNumber: 37
													}, this), /* @__PURE__ */ _jsxDEV("label", {
														className: "flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold cursor-pointer transition-all",
														children: [
															/* @__PURE__ */ _jsxDEV(Upload, { size: 13 }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1476,
																columnNumber: 41
															}, this),
															" ",
															form?.bannerImage ? "Ubah Banner" : "Unggah Banner",
															/* @__PURE__ */ _jsxDEV("input", {
																type: "file",
																accept: "image/*",
																className: "hidden",
																onChange: handleBannerUpload
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1477,
																columnNumber: 41
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1475,
														columnNumber: 37
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1466,
													columnNumber: 33
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "mt-3 p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-3",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2.5",
														children: [/* @__PURE__ */ _jsxDEV("div", {
															className: "w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center border border-slate-200 dark:border-slate-700",
															children: /* @__PURE__ */ _jsxDEV(Sliders, { size: 15 }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1485,
																columnNumber: 45
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1484,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
															className: "text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-tight",
															children: "Total Maksimal Skor"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1488,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV("p", {
															className: "text-base font-extrabold text-slate-900 dark:text-white leading-tight",
															children: [totalMaxScore, " poin"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1489,
															columnNumber: 45
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1487,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1483,
														columnNumber: 37
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "text-right",
														children: [/* @__PURE__ */ _jsxDEV("p", {
															className: "text-[10px] text-slate-500 dark:text-slate-400 font-medium uppercase tracking-wider",
															children: "Jumlah Soal"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1493,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV("p", {
															className: "text-sm font-bold text-slate-800 dark:text-slate-200",
															children: [totalQuestions > 0 ? totalQuestions : questions.length, " soal"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1494,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1492,
														columnNumber: 37
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1482,
													columnNumber: 33
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3",
														"data-tour": "builder-ai-generator",
														children: [/* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-3",
															children: [/* @__PURE__ */ _jsxDEV("div", {
																className: "w-8 h-8 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400 flex items-center justify-center border border-teal-100 dark:border-teal-900/40",
																children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 16 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1509,
																	columnNumber: 49
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1508,
																columnNumber: 45
															}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xs font-extrabold text-slate-900 dark:text-white",
																children: "Buat Soal Otomatis dengan AI"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1512,
																columnNumber: 49
															}, this), /* @__PURE__ */ _jsxDEV("p", {
																className: "text-[11px] text-slate-500 dark:text-slate-400",
																children: "Ketik topik atau paste materi, AI menyusun soal, opsi, dan kunci jawaban instan."
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1515,
																columnNumber: 49
															}, this)] }, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1511,
																columnNumber: 45
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1507,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => setAiModalOpen(true),
															className: "px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer",
															children: [/* @__PURE__ */ _jsxDEV(Sparkles, { size: 13 }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1525,
																columnNumber: 45
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Generate Soal AI" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1526,
																columnNumber: 45
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1520,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1503,
														columnNumber: 37
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "flex flex-wrap items-center justify-between gap-3 pt-1",
														children: [/* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-2",
															children: [/* @__PURE__ */ _jsxDEV("span", {
																className: "text-[11px] text-slate-400 dark:text-slate-500 font-medium",
																children: "Template:"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1533,
																columnNumber: 45
															}, this), [
																"csv",
																"xlsx",
																"docx"
															].map((fmt) => /* @__PURE__ */ _jsxDEV("a", {
																href: templateDownloadUrl(fmt),
																download: true,
																className: "inline-flex items-center gap-1 px-2 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg text-[11px] font-bold transition-all",
																children: [
																	/* @__PURE__ */ _jsxDEV(Download, { size: 11 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1541,
																		columnNumber: 53
																	}, this),
																	" .",
																	fmt.toUpperCase()
																]
															}, fmt, true, {
																fileName: _jsxFileName,
																lineNumber: 1535,
																columnNumber: 49
															}, this))]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1532,
															columnNumber: 41
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-2",
															children: /* @__PURE__ */ _jsxDEV("button", {
																type: "button",
																onClick: () => setImportModalOpen(true),
																className: "flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-all shrink-0 shadow-xs",
																children: [/* @__PURE__ */ _jsxDEV(FileUp, { size: 13 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1551,
																	columnNumber: 49
																}, this), " Impor File (Preview Dulu)"]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1546,
																columnNumber: 45
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1545,
															columnNumber: 41
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1531,
														columnNumber: 37
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1501,
													columnNumber: 33
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1443,
											columnNumber: 29
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mb-5 flex flex-wrap items-center justify-between gap-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "relative flex-1 min-w-[240px] max-w-md",
												children: [
													/* @__PURE__ */ _jsxDEV("input", {
														type: "text",
														value: searchTerm,
														onChange: (e) => setSearchTerm(e.target.value),
														placeholder: "Cari soal berdasarkan teks...",
														className: "w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500/60 placeholder:text-slate-400"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1561,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("svg", {
														className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400",
														fill: "none",
														stroke: "currentColor",
														viewBox: "0 0 24 24",
														strokeWidth: "2",
														children: /* @__PURE__ */ _jsxDEV("path", {
															strokeLinecap: "round",
															strokeLinejoin: "round",
															d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1569,
															columnNumber: 41
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1568,
														columnNumber: 37
													}, this),
													searchTerm && /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => {
															setSearchTerm("");
															setDebouncedSearch("");
															setCurrentPage(1);
														},
														className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200",
														children: /* @__PURE__ */ _jsxDEV(X, { size: 14 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1577,
															columnNumber: 45
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1572,
														columnNumber: 41
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1560,
												columnNumber: 33
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs text-slate-500 dark:text-slate-400 font-medium",
												children: searchTerm || totalQuestions > 0 ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
													"Menampilkan halaman ",
													/* @__PURE__ */ _jsxDEV("b", { children: currentPage }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1583,
														columnNumber: 63
													}, this),
													" dari ",
													/* @__PURE__ */ _jsxDEV("b", { children: Math.max(1, Math.ceil(totalQuestions / pageSize)) }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1583,
														columnNumber: 89
													}, this),
													" · Total ",
													totalQuestions,
													" soal"
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1583,
													columnNumber: 41
												}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: "Belum ada soal · Tambahkan soal atau impor dari file" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1585,
													columnNumber: 41
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1581,
												columnNumber: 33
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1559,
											columnNumber: 29
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-5",
											children: questions.map((q, idx) => /* @__PURE__ */ _jsxDEV("div", {
												"data-tour": idx === 0 ? "builder-first-question" : undefined,
												className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 space-y-4 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3",
														children: [/* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-2",
															children: [bulkReviseMode && /* @__PURE__ */ _jsxDEV("input", {
																type: "checkbox",
																checked: bulkReviseSelected.has(idx),
																onChange: (e) => {
																	setBulkReviseSelected((prev) => {
																		const next = new Set(prev);
																		if (e.target.checked) next.add(idx);
																		else next.delete(idx);
																		return next;
																	});
																},
																className: "w-4 h-4 text-purple-600 rounded cursor-pointer"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1602,
																columnNumber: 53
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																className: "text-xs font-extrabold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg",
																children: ["Soal #", idx + 1]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1615,
																columnNumber: 49
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1600,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-1",
															children: [
																/* @__PURE__ */ _jsxDEV("button", {
																	type: "button",
																	onClick: () => togglePreview(idx),
																	className: `p-1.5 rounded-lg transition-all cursor-pointer ${previewVisibility[idx] ? "bg-teal-50 dark:bg-teal-950/60 text-[#00897B] dark:text-teal-400" : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"}`,
																	title: "Toggle Live Preview",
																	children: previewVisibility[idx] ? /* @__PURE__ */ _jsxDEV(EyeOff, { size: 15 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1627,
																		columnNumber: 79
																	}, this) : /* @__PURE__ */ _jsxDEV(Eye, { size: 15 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1627,
																		columnNumber: 102
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1621,
																	columnNumber: 49
																}, this),
																/* @__PURE__ */ _jsxDEV("button", {
																	type: "button",
																	"data-tour": idx === 0 ? "builder-question-revise" : undefined,
																	onClick: () => {
																		setAiReviseOpenIdx(aiReviseOpenIdx === idx ? null : idx);
																		setAiReviseInstruction("");
																		setAiReviseError("");
																	},
																	className: `p-1.5 rounded-lg transition-all cursor-pointer ${aiReviseOpenIdx === idx ? "bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400" : "text-slate-400 hover:text-purple-500 dark:hover:text-purple-400"}`,
																	title: "Revisi soal dengan AI",
																	children: /* @__PURE__ */ _jsxDEV(Wand2, { size: 15 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1638,
																		columnNumber: 53
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1631,
																	columnNumber: 49
																}, this),
																/* @__PURE__ */ _jsxDEV("div", { className: "h-4 w-px bg-slate-200 dark:bg-slate-700 mx-1" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1641,
																	columnNumber: 49
																}, this),
																/* @__PURE__ */ _jsxDEV("button", {
																	onClick: () => moveQuestion(idx, -1),
																	disabled: idx === 0,
																	className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 disabled:opacity-30 cursor-pointer",
																	title: "Pindah Naik",
																	children: /* @__PURE__ */ _jsxDEV(ChevronUp, { size: 16 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1644,
																		columnNumber: 53
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1643,
																	columnNumber: 49
																}, this),
																/* @__PURE__ */ _jsxDEV("button", {
																	onClick: () => moveQuestion(idx, 1),
																	disabled: idx === questions.length - 1,
																	className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 disabled:opacity-30 cursor-pointer",
																	title: "Pindah Turun",
																	children: /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 16 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1647,
																		columnNumber: 53
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1646,
																	columnNumber: 49
																}, this),
																/* @__PURE__ */ _jsxDEV("button", {
																	onClick: () => handleDuplicateQuestion(idx),
																	className: "p-1 text-blue-400 hover:text-blue-600 cursor-pointer",
																	title: "Duplikat Soal",
																	children: /* @__PURE__ */ _jsxDEV(Copy, { size: 15 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1651,
																		columnNumber: 53
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1650,
																	columnNumber: 49
																}, this),
																/* @__PURE__ */ _jsxDEV("button", {
																	onClick: () => handleDeleteQuestion(idx),
																	className: "p-1 text-red-400 hover:text-red-600 cursor-pointer",
																	title: "Hapus Soal",
																	children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 16 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1654,
																		columnNumber: 53
																	}, this)
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1653,
																	columnNumber: 49
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1620,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1599,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "pb-3 border-b border-slate-100 dark:border-slate-800 space-y-2",
														children: [uploadProgress[idx] != null && /* @__PURE__ */ _jsxDEV("div", {
															className: "w-full bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 rounded-xl p-2.5 space-y-1.5 animate-fadeIn",
															children: [/* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center justify-between text-[11px] font-bold text-teal-800 dark:text-teal-300",
																children: [/* @__PURE__ */ _jsxDEV("span", {
																	className: "flex items-center gap-1.5",
																	children: [
																		/* @__PURE__ */ _jsxDEV(Loader2, {
																			size: 12,
																			className: "animate-spin text-teal-600"
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 1666,
																			columnNumber: 61
																		}, this),
																		"Mengunggah media ke server (",
																		uploadProgress[idx],
																		"%)..."
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 1665,
																	columnNumber: 57
																}, this), /* @__PURE__ */ _jsxDEV("span", { children: [uploadProgress[idx], "%"] }, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 1669,
																	columnNumber: 57
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1664,
																columnNumber: 53
															}, this), /* @__PURE__ */ _jsxDEV("div", {
																className: "w-full bg-teal-200/60 dark:bg-teal-900/60 h-1.5 rounded-full overflow-hidden",
																children: /* @__PURE__ */ _jsxDEV("div", {
																	className: "bg-teal-600 h-full transition-all duration-200 rounded-full",
																	style: { width: `${uploadProgress[idx]}%` }
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1672,
																	columnNumber: 57
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1671,
																columnNumber: 53
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1663,
															columnNumber: 49
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "flex flex-wrap items-center gap-3",
															children: [q.questionImage ? /* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center gap-2 bg-slate-50 dark:bg-slate-800 p-2 rounded-xl border border-slate-200 dark:border-slate-700",
																children: [/* @__PURE__ */ _jsxDEV("img", {
																	src: assetUrl(q.questionImage),
																	alt: "Soal",
																	className: "h-14 w-24 object-cover rounded-lg cursor-zoom-in hover:opacity-90 transition-opacity",
																	onClick: () => setLightboxImage({
																		src: assetUrl(q.questionImage),
																		alt: "Gambar Soal"
																	}),
																	title: "Klik untuk memperbesar gambar"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1684,
																	columnNumber: 57
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "flex flex-col gap-1",
																	children: [/* @__PURE__ */ _jsxDEV("label", {
																		className: "text-[11px] font-bold text-[#00897B] dark:text-teal-400 cursor-pointer hover:underline",
																		children: ["Ganti Gambar", /* @__PURE__ */ _jsxDEV("input", {
																			type: "file",
																			accept: "image/*",
																			className: "hidden",
																			onChange: (e) => e.target.files?.[0] && handleUploadQuestionImage(idx, e.target.files[0])
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 1694,
																			columnNumber: 65
																		}, this)]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 1692,
																		columnNumber: 61
																	}, this), /* @__PURE__ */ _jsxDEV("button", {
																		type: "button",
																		onClick: () => handleRemoveQuestionImage(idx),
																		className: "text-[10px] font-bold text-red-500 hover:underline flex items-center gap-1 cursor-pointer",
																		children: [/* @__PURE__ */ _jsxDEV(X, { size: 11 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 1701,
																			columnNumber: 65
																		}, this), " Hapus Gambar"]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 1696,
																		columnNumber: 61
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 1691,
																	columnNumber: 57
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1683,
																columnNumber: 53
															}, this) : /* @__PURE__ */ _jsxDEV("label", {
																className: "flex items-center gap-1.5 px-3 py-1.5 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 cursor-pointer hover:border-[#00897B] hover:text-[#00897B] transition-all",
																children: [
																	/* @__PURE__ */ _jsxDEV(Image, { size: 13 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1707,
																		columnNumber: 57
																	}, this),
																	" Tambah Gambar Soal",
																	/* @__PURE__ */ _jsxDEV("input", {
																		type: "file",
																		accept: "image/*",
																		className: "hidden",
																		onChange: (e) => e.target.files?.[0] && handleUploadQuestionImage(idx, e.target.files[0])
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1708,
																		columnNumber: 57
																	}, this)
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1706,
																columnNumber: 53
															}, this), q.questionAudio ? /* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center gap-2 bg-slate-50 dark:bg-slate-800 p-2 rounded-xl border border-slate-200 dark:border-slate-700",
																children: [/* @__PURE__ */ _jsxDEV("audio", {
																	controls: true,
																	src: assetUrl(q.questionAudio),
																	className: "h-8 max-w-[200px]"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1715,
																	columnNumber: 57
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "flex flex-col gap-1",
																	children: [/* @__PURE__ */ _jsxDEV("label", {
																		className: "text-[11px] font-bold text-[#00897B] dark:text-teal-400 cursor-pointer hover:underline",
																		children: ["Ganti Audio", /* @__PURE__ */ _jsxDEV("input", {
																			type: "file",
																			accept: "audio/*",
																			className: "hidden",
																			onChange: (e) => e.target.files?.[0] && handleUploadQuestionAudio(idx, e.target.files[0])
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 1719,
																			columnNumber: 65
																		}, this)]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 1717,
																		columnNumber: 61
																	}, this), /* @__PURE__ */ _jsxDEV("button", {
																		type: "button",
																		onClick: () => handleRemoveQuestionAudio(idx),
																		className: "text-[10px] font-bold text-red-500 hover:underline flex items-center gap-1 cursor-pointer",
																		children: [/* @__PURE__ */ _jsxDEV(X, { size: 11 }, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 1726,
																			columnNumber: 65
																		}, this), " Hapus Audio"]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 1721,
																		columnNumber: 61
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 1716,
																	columnNumber: 57
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1714,
																columnNumber: 53
															}, this) : /* @__PURE__ */ _jsxDEV("label", {
																className: "flex items-center gap-1.5 px-3 py-1.5 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 cursor-pointer hover:border-[#00897B] hover:text-[#00897B] transition-all",
																children: [
																	/* @__PURE__ */ _jsxDEV(Music, { size: 13 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1732,
																		columnNumber: 57
																	}, this),
																	" Tambah Audio Soal",
																	/* @__PURE__ */ _jsxDEV("input", {
																		type: "file",
																		accept: "audio/*",
																		className: "hidden",
																		onChange: (e) => e.target.files?.[0] && handleUploadQuestionAudio(idx, e.target.files[0])
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1733,
																		columnNumber: 57
																	}, this)
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1731,
																columnNumber: 53
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1680,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1660,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "space-y-2",
														children: [/* @__PURE__ */ _jsxDEV("label", {
															className: "text-xs font-bold text-slate-700 dark:text-slate-300 block",
															children: "Isi Pertanyaan Soal"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1741,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV(BlockQuestionEditor, {
															value: q.question || "",
															onChange: (newHtml) => updateQuestion(idx, "question", newHtml),
															placeholder: "Tuliskan teks pertanyaan soal, kode program, atau rumus..."
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1742,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1740,
														columnNumber: 41
													}, this),
													previewVisibility[idx] && /* @__PURE__ */ _jsxDEV("div", {
														className: "p-4 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200/80 dark:border-slate-700 space-y-2 overflow-hidden",
														children: [/* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center justify-between text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider",
															children: /* @__PURE__ */ _jsxDEV("span", { children: "Live Preview" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1753,
																columnNumber: 53
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1752,
															columnNumber: 49
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "break-words break-all [overflow-wrap:anywhere]",
															children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
																content: q.question,
																format: q.questionFormat,
																className: "text-sm font-semibold text-slate-800 dark:text-slate-100"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1756,
																columnNumber: 53
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1755,
															columnNumber: 49
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1751,
														columnNumber: 45
													}, this),
													aiReviseOpenIdx === idx && /* @__PURE__ */ _jsxDEV("div", {
														className: "p-3.5 bg-purple-50 dark:bg-purple-950/40 rounded-xl border border-purple-200 dark:border-purple-800 space-y-2",
														children: [
															/* @__PURE__ */ _jsxDEV("p", {
																className: "text-xs font-bold text-purple-700 dark:text-purple-300 flex items-center gap-1.5",
																children: [/* @__PURE__ */ _jsxDEV(Wand2, { size: 13 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1765,
																	columnNumber: 53
																}, this), " Revisi Soal dengan AI"]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1764,
																columnNumber: 49
															}, this),
															/* @__PURE__ */ _jsxDEV("select", {
																value: reviseModel,
																onChange: (e) => {
																	setReviseModel(e.target.value);
																	localStorage.setItem("formup_selected_model_chat", e.target.value);
																},
																className: "w-full px-3 py-1.5 text-xs border border-purple-200 dark:border-purple-700 rounded-xl bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200",
																children: AVAILABLE_MODELS.map((model) => /* @__PURE__ */ _jsxDEV("option", {
																	value: model.id || model.name,
																	children: model.name || model.id
																}, model.id || model.name, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1768,
																	columnNumber: 84
																}, this))
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1767,
																columnNumber: 49
															}, this),
															aiReviseError && /* @__PURE__ */ _jsxDEV("p", {
																className: "text-[11px] text-red-500",
																children: aiReviseError
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1770,
																columnNumber: 67
															}, this),
															/* @__PURE__ */ _jsxDEV("div", {
																className: "flex gap-2",
																children: [/* @__PURE__ */ _jsxDEV("input", {
																	type: "text",
																	value: aiReviseInstruction,
																	onChange: (e) => setAiReviseInstruction(e.target.value),
																	placeholder: "Instruksi: Buat lebih sulit, ganti konteks ke ekosistem laut...",
																	className: "flex-1 px-3 py-1.5 text-xs border border-purple-200 dark:border-purple-700 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-purple-500",
																	disabled: aiRevising
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1772,
																	columnNumber: 53
																}, this), /* @__PURE__ */ _jsxDEV("button", {
																	type: "button",
																	onClick: () => handleAiRevise(idx),
																	disabled: aiRevising || !aiReviseInstruction.trim(),
																	className: "px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl transition-all cursor-pointer disabled:opacity-50 flex items-center gap-1",
																	children: [aiRevising ? /* @__PURE__ */ _jsxDEV("span", {
																		className: "animate-spin",
																		children: "⋯"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1786,
																		columnNumber: 71
																	}, this) : /* @__PURE__ */ _jsxDEV(Wand2, { size: 13 }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1786,
																		columnNumber: 113
																	}, this), "Revisi"]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 1780,
																	columnNumber: 53
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1771,
																columnNumber: 49
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1763,
														columnNumber: 45
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
														children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
															className: "text-xs font-bold text-slate-500 dark:text-slate-400 block mb-1",
															children: "Tipe Soal"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1796,
															columnNumber: 49
														}, this), /* @__PURE__ */ _jsxDEV("select", {
															value: q.typeId,
															onChange: (e) => updateQuestion(idx, "typeId", parseInt(e.target.value)),
															className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]",
															children: QUESTION_TYPES.map((t) => /* @__PURE__ */ _jsxDEV("option", {
																value: t.id,
																children: t.label
															}, t.id, false, {
																fileName: _jsxFileName,
																lineNumber: 1803,
																columnNumber: 57
															}, this))
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1797,
															columnNumber: 49
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1795,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "flex flex-col sm:flex-row items-start sm:items-center justify-end gap-4 pt-1 sm:pt-5",
															children: [/* @__PURE__ */ _jsxDEV("label", {
																className: "flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer",
																children: [/* @__PURE__ */ _jsxDEV("input", {
																	type: "checkbox",
																	checked: q.isScorable !== false,
																	onChange: (e) => updateQuestion(idx, "isScorable", e.target.checked),
																	className: "w-4 h-4 text-[#00897B] rounded cursor-pointer"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1810,
																	columnNumber: 53
																}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Hitung ke Skor (Dinilai)" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1816,
																	columnNumber: 53
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1809,
																columnNumber: 49
															}, this), /* @__PURE__ */ _jsxDEV("label", {
																className: "flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer",
																children: [/* @__PURE__ */ _jsxDEV("input", {
																	type: "checkbox",
																	checked: !!q.isRequired,
																	onChange: (e) => updateQuestion(idx, "isRequired", e.target.checked),
																	className: "w-4 h-4 text-[#00897B] rounded cursor-pointer"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1820,
																	columnNumber: 53
																}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Soal Wajib Diisi" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1826,
																	columnNumber: 53
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1819,
																columnNumber: 49
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1808,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1794,
														columnNumber: 41
													}, this),
													q.isScorable !== false && /* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-3",
														children: [
															/* @__PURE__ */ _jsxDEV("label", {
																className: "text-xs font-bold text-slate-500 dark:text-slate-400 whitespace-nowrap",
																children: "Poin Soal"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1834,
																columnNumber: 49
															}, this),
															/* @__PURE__ */ _jsxDEV("input", {
																type: "number",
																min: "0",
																step: "1",
																placeholder: "Kosongi = bobot sama rata",
																value: q.points ?? "",
																onChange: (e) => updateQuestion(idx, "points", e.target.value === "" ? null : parseInt(e.target.value, 10)),
																className: "w-40 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1835,
																columnNumber: 49
															}, this),
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-[10px] text-slate-400 dark:text-slate-500 italic",
																children: "opsional — biarkan kosong untuk bobot sama rata"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1844,
																columnNumber: 49
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1833,
														columnNumber: 45
													}, this),
													q.isScorable === false ? /* @__PURE__ */ _jsxDEV("div", {
														className: "p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 rounded-xl flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400",
														children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-slate-400 shrink-0" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1851,
															columnNumber: 49
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
															"Soal ini ",
															/* @__PURE__ */ _jsxDEV("b", { children: "Tidak Dinilai" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1852,
																columnNumber: 64
															}, this),
															" (digunakan untuk pengumpulan data seperti Nama, Email, NIM, atau survei umum). Tidak memerlukan kunci jawaban dan tidak memengaruhi skor."
														] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1852,
															columnNumber: 49
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1850,
														columnNumber: 45
													}, this) : null,
													needsOptions(q.typeId) && /* @__PURE__ */ _jsxDEV("div", {
														className: "space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800",
														children: [
															/* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center justify-between",
																children: [/* @__PURE__ */ _jsxDEV("label", {
																	className: "text-xs font-bold text-slate-700 dark:text-slate-300 block",
																	children: "Pilihan Jawaban:"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1859,
																	columnNumber: 53
																}, this), q.isScorable !== false && /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-[11px] text-slate-400 dark:text-slate-500",
																	children: q.typeId === 2 ? "● Pilih 1 jawaban benar (radio)" : "☑ Centang semua jawaban benar"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1861,
																	columnNumber: 57
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 1858,
																columnNumber: 49
															}, this),
															q.options.map((opt, oIdx) => /* @__PURE__ */ _jsxDEV("div", {
																className: "space-y-1",
																children: [
																	/* @__PURE__ */ _jsxDEV("div", {
																		className: "flex items-center gap-2",
																		children: [
																			q.isScorable !== false ? /* @__PURE__ */ _jsxDEV("label", {
																				className: "flex items-center gap-1 cursor-pointer",
																				children: [q.typeId === 2 ? /* @__PURE__ */ _jsxDEV(
																					"input",
																					// TASK 3: Multiple Choice → radio (single-select)
																					{
																						type: "radio",
																						name: `correct_q${idx}`,
																						checked: !!opt.isCorrect,
																						onChange: () => {
																							setQuestions((prev) => prev.map((qq, qi) => {
																								if (qi !== idx) return qq;
																								return {
																									...qq,
																									options: qq.options.map((o, oi) => ({
																										...o,
																										isCorrect: oi === oIdx
																									}))
																								};
																							}));
																						},
																						className: "w-4 h-4 shrink-0 cursor-pointer accent-[#00897B]",
																						title: "Tandai sebagai satu-satunya jawaban benar"
																					},
																					void 0,
																					false,
																					{
																						fileName: _jsxFileName,
																						lineNumber: 1875,
																						columnNumber: 73
																					},
																					this
																				) : 
																				// TASK 3: Checkbox type → checkbox (multi-select unchanged)
/* @__PURE__ */ _jsxDEV("input", {
																					type: "checkbox",
																					checked: !!opt.isCorrect,
																					onChange: (e) => updateOption(idx, oIdx, "isCorrect", e.target.checked),
																					className: "w-4 h-4 text-[#00897B] rounded shrink-0 cursor-pointer",
																					title: "Tandai sebagai jawaban benar"
																				}, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 1896,
																					columnNumber: 73
																				}, this), opt.isCorrect && /* @__PURE__ */ _jsxDEV("span", {
																					className: "text-[10px] font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded",
																					children: "✓ Benar"
																				}, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 1904,
																					columnNumber: 87
																				}, this)]
																			}, void 0, true, {
																				fileName: _jsxFileName,
																				lineNumber: 1872,
																				columnNumber: 65
																			}, this) : /* @__PURE__ */ _jsxDEV("span", {
																				className: "w-5 h-5 flex items-center justify-center text-[10px] font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 rounded-full shrink-0",
																				children: String.fromCharCode(65 + oIdx)
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 1907,
																				columnNumber: 65
																			}, this),
																			/* @__PURE__ */ _jsxDEV("div", {
																				className: "flex-1 flex items-center gap-1",
																				children: [
																					/* @__PURE__ */ _jsxDEV("input", {
																						placeholder: `Pilihan ${oIdx + 1}`,
																						value: opt.optionText,
																						onChange: (e) => updateOption(idx, oIdx, "optionText", e.target.value),
																						className: "flex-1 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
																					}, void 0, false, {
																						fileName: _jsxFileName,
																						lineNumber: 1913,
																						columnNumber: 65
																					}, this),
																					/* @__PURE__ */ _jsxDEV("button", {
																						type: "button",
																						onClick: () => openInsertModal(idx, "math", "option", oIdx),
																						className: "p-1 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 rounded cursor-pointer",
																						title: "Sisipkan Rumus (KaTeX)",
																						children: /* @__PURE__ */ _jsxDEV(Calculator, { size: 14 }, void 0, false, {
																							fileName: _jsxFileName,
																							lineNumber: 1925,
																							columnNumber: 69
																						}, this)
																					}, void 0, false, {
																						fileName: _jsxFileName,
																						lineNumber: 1919,
																						columnNumber: 65
																					}, this),
																					/* @__PURE__ */ _jsxDEV("button", {
																						type: "button",
																						onClick: () => openInsertModal(idx, "code", "option", oIdx),
																						className: "p-1 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 rounded cursor-pointer",
																						title: "Sisipkan Kode Block",
																						children: /* @__PURE__ */ _jsxDEV(Code, { size: 14 }, void 0, false, {
																							fileName: _jsxFileName,
																							lineNumber: 1933,
																							columnNumber: 69
																						}, this)
																					}, void 0, false, {
																						fileName: _jsxFileName,
																						lineNumber: 1927,
																						columnNumber: 65
																					}, this),
																					/* @__PURE__ */ _jsxDEV("label", {
																						className: "p-1 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 rounded cursor-pointer",
																						title: "Tambah Gambar Opsi (maks 500KB)",
																						children: [/* @__PURE__ */ _jsxDEV(Image, { size: 14 }, void 0, false, {
																							fileName: _jsxFileName,
																							lineNumber: 1941,
																							columnNumber: 65
																						}, this), /* @__PURE__ */ _jsxDEV("input", {
																							type: "file",
																							accept: "image/*",
																							className: "hidden",
																							disabled: uploadProgress[`option-${idx}-${oIdx}`] != null,
																							onChange: async (e) => {
																								const file = e.target.files?.[0];
																								if (!file) return;
																								if (file.size > 500 * 1024) {
																									showToast("Gambar opsi terlalu besar (maks 500KB).", "error");
																									return;
																								}
																								const uploadKey = `option-${idx}-${oIdx}`;
																								setUploadProgress((prev) => ({
																									...prev,
																									[uploadKey]: 0
																								}));
																								const ids = await ensureOptionSaved(idx, oIdx);
																								if (!ids) {
																									showToast("Gagal memproses opsi sebelum mengunggah gambar", "error");
																									e.target.value = "";
																									setUploadProgress((prev) => ({
																										...prev,
																										[uploadKey]: null
																									}));
																									return;
																								}
																								try {
																									const res = await uploadOptionImage(id, ids.questionId, ids.optionId, file, (pct) => {
																										setUploadProgress((prev) => ({
																											...prev,
																											[uploadKey]: pct
																										}));
																									});
																									if (res.ok) {
																										pushHistory(questions);
																										updateOption(idx, oIdx, "optionImage", res.data?.optionImage ?? res.data?.url ?? null);
																										showToast("Gambar opsi berhasil diunggah!");
																									} else {
																										showToast(res.message || "Gagal mengunggah gambar opsi", "error");
																									}
																								} catch (err) {
																									console.error("[Upload Option Image Error]:", err);
																									showToast("Terjadi kesalahan saat mengunggah gambar opsi", "error");
																								} finally {
																									setUploadProgress((prev) => ({
																										...prev,
																										[uploadKey]: null
																									}));
																								}
																								e.target.value = "";
																							}
																						}, void 0, false, {
																							fileName: _jsxFileName,
																							lineNumber: 1942,
																							columnNumber: 65
																						}, this)]
																					}, void 0, true, {
																						fileName: _jsxFileName,
																						lineNumber: 1937,
																						columnNumber: 65
																					}, this),
																					uploadProgress[`option-${idx}-${oIdx}`] != null && /* @__PURE__ */ _jsxDEV("span", {
																						className: "inline-flex items-center gap-1.5 text-[10px] font-bold text-teal-600 dark:text-teal-400",
																						title: "Mengunggah gambar opsi",
																						children: [
																							/* @__PURE__ */ _jsxDEV(Loader2, {
																								size: 12,
																								className: "animate-spin"
																							}, void 0, false, {
																								fileName: _jsxFileName,
																								lineNumber: 1986,
																								columnNumber: 69
																							}, this),
																							/* @__PURE__ */ _jsxDEV("span", {
																								className: "w-16 h-1.5 rounded-full overflow-hidden bg-teal-100 dark:bg-teal-950/60",
																								children: /* @__PURE__ */ _jsxDEV("span", {
																									className: "block h-full rounded-full bg-teal-600 transition-all duration-200",
																									style: { width: `${uploadProgress[`option-${idx}-${oIdx}`]}%` }
																								}, void 0, false, {
																									fileName: _jsxFileName,
																									lineNumber: 1988,
																									columnNumber: 73
																								}, this)
																							}, void 0, false, {
																								fileName: _jsxFileName,
																								lineNumber: 1987,
																								columnNumber: 69
																							}, this),
																							uploadProgress[`option-${idx}-${oIdx}`],
																							"%"
																						]
																					}, void 0, true, {
																						fileName: _jsxFileName,
																						lineNumber: 1985,
																						columnNumber: 65
																					}, this)
																				]
																			}, void 0, true, {
																				fileName: _jsxFileName,
																				lineNumber: 1912,
																				columnNumber: 61
																			}, this),
																			/* @__PURE__ */ _jsxDEV("button", {
																				onClick: () => removeOption(idx, oIdx),
																				className: "text-red-400 hover:text-red-600 p-1 shrink-0 cursor-pointer",
																				children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
																					fileName: _jsxFileName,
																					lineNumber: 1996,
																					columnNumber: 65
																				}, this)
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 1995,
																				columnNumber: 61
																			}, this)
																		]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 1870,
																		columnNumber: 57
																	}, this),
																	(opt.optionText?.includes("$") || opt.optionText?.includes("<pre") || opt.optionText?.includes("<code")) && /* @__PURE__ */ _jsxDEV("div", {
																		className: "ml-6 p-2 bg-slate-50 dark:bg-slate-800/60 rounded-lg text-xs border border-slate-200/60 dark:border-slate-700",
																		children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, {
																			content: opt.optionText,
																			format: "text",
																			className: "text-xs"
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 2003,
																			columnNumber: 65
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 2002,
																		columnNumber: 61
																	}, this),
																	opt.optionImage && /* @__PURE__ */ _jsxDEV("div", {
																		className: "ml-6 flex items-center gap-2 mt-1",
																		children: [/* @__PURE__ */ _jsxDEV("img", {
																			src: assetUrl(opt.optionImage),
																			alt: "Gambar opsi",
																			className: "max-h-16 rounded-lg border border-slate-200 dark:border-slate-700 cursor-zoom-in",
																			onClick: () => setLightboxImage({
																				src: assetUrl(opt.optionImage),
																				alt: "Gambar Opsi"
																			})
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 2010,
																			columnNumber: 61
																		}, this), /* @__PURE__ */ _jsxDEV("button", {
																			type: "button",
																			onClick: () => updateOption(idx, oIdx, "optionImage", null),
																			className: "text-red-400 hover:text-red-600 p-1",
																			title: "Hapus gambar opsi",
																			children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 2022,
																				columnNumber: 69
																			}, this)
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 2016,
																			columnNumber: 65
																		}, this)]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 2009,
																		columnNumber: 57
																	}, this)
																]
															}, opt._id || opt.id || `opt_${idx}_${oIdx}`, true, {
																fileName: _jsxFileName,
																lineNumber: 1869,
																columnNumber: 53
															}, this)),
															/* @__PURE__ */ _jsxDEV("button", {
																onClick: () => addOption(idx),
																className: "text-xs font-bold text-[#00897B] dark:text-teal-400 hover:underline mt-1 cursor-pointer",
																children: "+ Tambah Pilihan"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2028,
																columnNumber: 49
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1857,
														columnNumber: 45
													}, this),
													q.isScorable !== false && [
														1,
														4,
														5
													].includes(q.typeId) && /* @__PURE__ */ _jsxDEV("div", {
														className: "pt-2 border-t border-slate-100 dark:border-slate-800",
														children: [/* @__PURE__ */ _jsxDEV("label", {
															className: "text-xs font-bold text-slate-500 dark:text-slate-400 block mb-1",
															children: "Jawaban Benar yang Diharapkan (untuk penilaian otomatis & skor):"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2037,
															columnNumber: 49
														}, this), q.typeId === 5 ? /* @__PURE__ */ _jsxDEV("select", {
															value: (() => {
																const v = q.correctAnswer || "Benar";
																return v === "True" || v === "true" ? "Benar" : v === "False" || v === "false" ? "Salah" : v;
															})(),
															onChange: (e) => updateQuestion(idx, "correctAnswer", e.target.value),
															className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-[#00897B] bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100",
															children: [/* @__PURE__ */ _jsxDEV("option", {
																value: "Benar",
																children: "Benar"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2049,
																columnNumber: 57
															}, this), /* @__PURE__ */ _jsxDEV("option", {
																value: "Salah",
																children: "Salah"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2050,
																columnNumber: 57
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2041,
															columnNumber: 53
														}, this) : q.typeId === 4 ? /* @__PURE__ */ _jsxDEV("input", {
															type: "datetime-local",
															value: q.correctAnswer || "",
															onChange: (e) => updateQuestion(idx, "correctAnswer", e.target.value),
															className: "w-full max-w-xs border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2053,
															columnNumber: 53
														}, this) : /* @__PURE__ */ _jsxDEV("input", {
															placeholder: "contoh: 4 atau Soekarno",
															value: q.correctAnswer,
															onChange: (e) => updateQuestion(idx, "correctAnswer", e.target.value),
															className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2060,
															columnNumber: 53
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2036,
														columnNumber: 45
													}, this)
												]
											}, q._id || idx, true, {
												fileName: _jsxFileName,
												lineNumber: 1593,
												columnNumber: 37
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1591,
											columnNumber: 29
										}, this),
										questions.length === 0 && /* @__PURE__ */ _jsxDEV("div", {
											className: "py-8 text-center border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl bg-white/60 dark:bg-slate-900/60",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-sm font-bold text-slate-500 dark:text-slate-400",
												children: "Belum ada soal"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2075,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-400 dark:text-slate-500 mt-1",
												children: "Form tanpa soal akan tersimpan kosong (0 soal) dan otomatis kembali menjadi draf."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2076,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2074,
											columnNumber: 33
										}, this),
										(totalQuestions > pageSize || searchTerm) && /* @__PURE__ */ _jsxDEV("div", {
											className: "mt-6 mb-2 flex flex-wrap items-center justify-between gap-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2",
												children: [
													/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => setCurrentPage((p) => Math.max(1, p - 1)),
														disabled: currentPage === 1,
														className: "flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer",
														children: [/* @__PURE__ */ _jsxDEV(ChevronUp, {
															size: 13,
															className: "rotate-90"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2090,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Sebelumnya" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2091,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2084,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-1.5 px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60",
														children: [
															/* @__PURE__ */ _jsxDEV("span", {
																className: "font-bold text-slate-800 dark:text-slate-100",
																children: ["Halaman ", currentPage]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 2094,
																columnNumber: 45
															}, this),
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-slate-400",
																children: "/"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2095,
																columnNumber: 45
															}, this),
															/* @__PURE__ */ _jsxDEV("span", {
																className: "font-bold text-slate-500 dark:text-slate-400",
																children: Math.max(1, Math.ceil(totalQuestions / pageSize))
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2096,
																columnNumber: 45
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2093,
														columnNumber: 41
													}, this),
													/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => setCurrentPage((p) => p + 1),
														disabled: currentPage >= Math.ceil(totalQuestions / pageSize),
														className: "flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer",
														children: [/* @__PURE__ */ _jsxDEV("span", { children: "Berikutnya" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2104,
															columnNumber: 45
														}, this), /* @__PURE__ */ _jsxDEV(ChevronUp, {
															size: 13,
															className: "-rotate-90"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2105,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2098,
														columnNumber: 41
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2083,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "text-xs font-medium text-slate-500 dark:text-slate-400",
													children: "Per halaman:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2109,
													columnNumber: 41
												}, this), /* @__PURE__ */ _jsxDEV("select", {
													value: pageSize,
													onChange: (e) => {
														setPageSize(Number(e.target.value));
														setCurrentPage(1);
													},
													className: "px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500/40 cursor-pointer",
													children: [
														/* @__PURE__ */ _jsxDEV("option", {
															value: 10,
															children: "10 soal"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2115,
															columnNumber: 45
														}, this),
														/* @__PURE__ */ _jsxDEV("option", {
															value: 25,
															children: "25 soal"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2116,
															columnNumber: 45
														}, this),
														/* @__PURE__ */ _jsxDEV("option", {
															value: 50,
															children: "50 soal"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2117,
															columnNumber: 45
														}, this),
														/* @__PURE__ */ _jsxDEV("option", {
															value: 100,
															children: "100 soal"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2118,
															columnNumber: 45
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2110,
													columnNumber: 41
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2108,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2082,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-wrap gap-2 items-center",
											children: /* @__PURE__ */ _jsxDEV("button", {
												onClick: addQuestion,
												"data-tour": "builder-add-question",
												className: "flex-1 min-w-[180px] py-3.5 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl text-xs font-extrabold text-slate-600 dark:text-slate-400 hover:border-[#00897B] dark:hover:border-teal-400 hover:text-[#00897B] dark:hover:text-teal-400 transition-all flex items-center justify-center gap-2 bg-white/60 dark:bg-slate-900/60 cursor-pointer",
												children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 18 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2131,
													columnNumber: 37
												}, this), " Tambah Soal Manual"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2126,
												columnNumber: 33
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2125,
											columnNumber: 29
										}, this),
										bulkReviseMode && /* @__PURE__ */ _jsxDEV("div", {
											className: "fixed right-5 top-24 z-40 w-[min(430px,calc(100vw-2rem))] bg-white dark:bg-slate-900 border border-purple-200 dark:border-purple-800 rounded-2xl shadow-2xl p-4 space-y-3",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2 text-xs font-bold text-purple-700 dark:text-purple-300",
													children: [
														/* @__PURE__ */ _jsxDEV(Wand2, { size: 14 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2137,
															columnNumber: 41
														}, this),
														/* @__PURE__ */ _jsxDEV("span", {
															className: "flex-1",
															children: [
																"Revisi Massal AI · ",
																bulkReviseSelected.size,
																" soal dipilih"
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2138,
															columnNumber: 41
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => setBulkReviseSelected(new Set(questions.map((_, i) => i))),
															className: "text-purple-500 underline cursor-pointer",
															children: "Pilih Semua"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2139,
															columnNumber: 41
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2136,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("select", {
													value: reviseModel,
													onChange: (e) => {
														setReviseModel(e.target.value);
														localStorage.setItem("formup_selected_model_chat", e.target.value);
													},
													className: "w-full px-3 py-2 text-xs border border-purple-200 dark:border-purple-700 rounded-xl bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200",
													children: AVAILABLE_MODELS.map((model) => /* @__PURE__ */ _jsxDEV("option", {
														value: model.id || model.name,
														children: model.name || model.id
													}, model.id || model.name, false, {
														fileName: _jsxFileName,
														lineNumber: 2142,
														columnNumber: 72
													}, this))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2141,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													value: bulkReviseInstruction,
													onChange: (e) => setBulkReviseInstruction(e.target.value),
													placeholder: "Instruksi revisi untuk semua soal terpilih...",
													className: "w-full px-3 py-2 text-xs border border-purple-200 dark:border-purple-700 rounded-xl bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-purple-500"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2144,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: handleBulkAiRevise,
													disabled: bulkRevising || bulkReviseSelected.size === 0 || !bulkReviseInstruction.trim(),
													className: "w-full justify-center px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl cursor-pointer disabled:opacity-50 flex items-center gap-1.5",
													children: [bulkRevising ? /* @__PURE__ */ _jsxDEV("span", {
														className: "animate-spin",
														children: "⋯"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2157,
														columnNumber: 57
													}, this) : /* @__PURE__ */ _jsxDEV(Wand2, { size: 13 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2157,
														columnNumber: 99
													}, this), bulkRevising ? "Merevisi..." : "Revisi Sekarang"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2151,
													columnNumber: 37
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2135,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1441,
									columnNumber: 29
								}, this), isSplitPreview && /* @__PURE__ */ _jsxDEV("div", {
									className: "hidden lg:flex flex-col w-full lg:w-[46%] h-full overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-3xl p-6 shadow-xl space-y-6",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 shrink-0",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2",
												children: /* @__PURE__ */ _jsxDEV("h3", {
													className: "text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider",
													children: "Pratinjau"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2169,
													columnNumber: 45
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2168,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] px-2 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 font-bold border border-teal-200 dark:border-teal-800",
													children: [questions.length, " Butir Soal"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2172,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setIsSplitPreview(false),
													className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg cursor-pointer",
													title: "Tutup Dual View",
													children: /* @__PURE__ */ _jsxDEV(X, { size: 15 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2181,
														columnNumber: 49
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2175,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2171,
												columnNumber: 41
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2167,
											columnNumber: 37
										}, this),
										form?.bannerImage && /* @__PURE__ */ _jsxDEV("div", {
											className: "w-full h-36 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 shrink-0",
											children: /* @__PURE__ */ _jsxDEV("img", {
												src: assetUrl(form.bannerImage),
												alt: "Banner",
												className: "w-full h-full object-cover"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2189,
												columnNumber: 45
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2188,
											columnNumber: 41
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-2 shrink-0",
											children: [/* @__PURE__ */ _jsxDEV("h1", {
												className: "text-xl font-extrabold text-slate-900 dark:text-white",
												children: form?.title || "Judul Formulir"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2195,
												columnNumber: 41
											}, this), form?.description && /* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs text-slate-600 dark:text-slate-400 prose dark:prose-invert max-w-none",
												children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: form.description }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2200,
													columnNumber: 49
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2199,
												columnNumber: 45
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2194,
											columnNumber: 37
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-4 flex-1",
											children: questions.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
												className: "p-8 text-center text-xs text-slate-400 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800",
												children: "Belum ada butir pertanyaan pada formulir ini."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2208,
												columnNumber: 45
											}, this) : questions.map((q, qIdx) => /* @__PURE__ */ _jsxDEV("div", {
												className: "p-4 rounded-2xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-800/40 space-y-3 shadow-2xs",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-start justify-between gap-2",
														children: [/* @__PURE__ */ _jsxDEV("div", {
															className: "text-xs font-bold text-slate-800 dark:text-slate-200 flex items-start gap-2",
															children: [/* @__PURE__ */ _jsxDEV("span", {
																className: "text-teal-600 dark:text-teal-400 font-mono",
																children: [qIdx + 1, "."]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 2216,
																columnNumber: 61
															}, this), /* @__PURE__ */ _jsxDEV("div", {
																className: "flex-1",
																children: /* @__PURE__ */ _jsxDEV(RichContentRenderer, { content: q.question || "Pertanyaan belum diisi" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2218,
																	columnNumber: 65
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2217,
																columnNumber: 61
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2215,
															columnNumber: 57
														}, this), q.isScorable !== false && /* @__PURE__ */ _jsxDEV("span", {
															className: "text-[10px] font-bold px-2 py-0.5 rounded-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 shrink-0",
															children: [q.points || 1, " Poin"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2222,
															columnNumber: 61
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2214,
														columnNumber: 53
													}, this),
													q.questionImage && /* @__PURE__ */ _jsxDEV("div", {
														className: "max-w-xs rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 my-1",
														children: /* @__PURE__ */ _jsxDEV("img", {
															src: assetUrl(q.questionImage),
															alt: "Soal",
															className: "w-full h-auto object-contain max-h-48"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2231,
															columnNumber: 61
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2230,
														columnNumber: 57
													}, this),
													q.typeId === 2 && /* @__PURE__ */ _jsxDEV("div", {
														className: "space-y-1.5 pl-4",
														children: q.options?.map((opt, oIdx) => /* @__PURE__ */ _jsxDEV("label", {
															className: "flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer",
															children: [/* @__PURE__ */ _jsxDEV("input", {
																type: "radio",
																name: `preview_live_q_${qIdx}`,
																disabled: true,
																className: "text-teal-600"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2240,
																columnNumber: 69
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: opt.optionText || `Pilihan ${String.fromCharCode(65 + oIdx)}` }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2241,
																columnNumber: 69
															}, this)]
														}, oIdx, true, {
															fileName: _jsxFileName,
															lineNumber: 2239,
															columnNumber: 65
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2237,
														columnNumber: 57
													}, this),
													q.typeId === 3 && /* @__PURE__ */ _jsxDEV("div", {
														className: "space-y-1.5 pl-4",
														children: q.options?.map((opt, oIdx) => /* @__PURE__ */ _jsxDEV("label", {
															className: "flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer",
															children: [/* @__PURE__ */ _jsxDEV("input", {
																type: "checkbox",
																disabled: true,
																className: "rounded text-teal-600"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2251,
																columnNumber: 69
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: opt.optionText || `Pilihan ${String.fromCharCode(65 + oIdx)}` }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2252,
																columnNumber: 69
															}, this)]
														}, oIdx, true, {
															fileName: _jsxFileName,
															lineNumber: 2250,
															columnNumber: 65
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2248,
														columnNumber: 57
													}, this),
													q.typeId === 5 && /* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-4 pl-4 text-xs",
														children: [/* @__PURE__ */ _jsxDEV("label", {
															className: "flex items-center gap-1.5 cursor-pointer text-slate-700 dark:text-slate-300",
															children: [/* @__PURE__ */ _jsxDEV("input", {
																type: "radio",
																name: `preview_live_q_${qIdx}`,
																disabled: true,
																className: "text-teal-600"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2261,
																columnNumber: 65
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Benar" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2262,
																columnNumber: 65
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2260,
															columnNumber: 61
														}, this), /* @__PURE__ */ _jsxDEV("label", {
															className: "flex items-center gap-1.5 cursor-pointer text-slate-700 dark:text-slate-300",
															children: [/* @__PURE__ */ _jsxDEV("input", {
																type: "radio",
																name: `preview_live_q_${qIdx}`,
																disabled: true,
																className: "text-teal-600"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2265,
																columnNumber: 65
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Salah" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2266,
																columnNumber: 65
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2264,
															columnNumber: 61
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2259,
														columnNumber: 57
													}, this),
													q.typeId === 1 && /* @__PURE__ */ _jsxDEV("div", {
														className: "pl-4",
														children: /* @__PURE__ */ _jsxDEV("input", {
															type: "text",
															disabled: true,
															placeholder: "Tuliskan jawaban di sini...",
															className: "w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-400 cursor-not-allowed"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2273,
															columnNumber: 61
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2272,
														columnNumber: 57
													}, this)
												]
											}, q._id || q.id || qIdx, true, {
												fileName: _jsxFileName,
												lineNumber: 2213,
												columnNumber: 49
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2206,
											columnNumber: 37
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2166,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1439,
								columnNumber: 25
							}, this),
							activeTab === "settings" && /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 space-y-6 shadow-xs",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-sm font-extrabold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3",
									children: "Konfigurasi & Aturan Formulir"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2288,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-4",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
												children: "Slug Tautan Khusus"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2294,
												columnNumber: 37
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-mono text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700",
													children: [FRONTEND_BASE_URL, "/f/"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2296,
													columnNumber: 41
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													value: settings.customFormLink,
													onChange: (e) => setSettings((s) => ({
														...s,
														customFormLink: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "")
													})),
													placeholder: "tautan-khusus-saya",
													className: "flex-1 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-mono font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2299,
													columnNumber: 41
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2295,
												columnNumber: 37
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[11px] text-slate-400 dark:text-slate-500 mt-1",
												children: "Hanya huruf kecil, angka, dan tanda hubung (-)."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2306,
												columnNumber: 37
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2293,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
													children: "Tipe Tata Letak Formulir"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2311,
													columnNumber: 41
												}, this),
												/* @__PURE__ */ _jsxDEV("select", {
													value: settings.formTypeId,
													onChange: (e) => setSettings((s) => ({
														...s,
														formTypeId: parseInt(e.target.value)
													})),
													className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]",
													children: [/* @__PURE__ */ _jsxDEV("option", {
														value: 1,
														children: "Semua Soal dalam Satu Halaman"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2317,
														columnNumber: 45
													}, this), /* @__PURE__ */ _jsxDEV("option", {
														value: 2,
														children: "Satu Soal per Halaman (Langkah)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2318,
														columnNumber: 45
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2312,
													columnNumber: 41
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[11px] text-slate-400 dark:text-slate-500 mt-1",
													children: "Pilihan tampilan — bebas dikombinasikan dengan Mode Ujian."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2321,
													columnNumber: 41
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2310,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
												children: "Durasi Timer (Menit, Opsional)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2325,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "number",
												min: "0",
												value: settings.timerDuration,
												onChange: (e) => setSettings((s) => ({
													...s,
													timerDuration: e.target.value
												})),
												placeholder: "contoh: 30",
												className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2326,
												columnNumber: 41
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2324,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2309,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
												children: "Waktu Buka Formulir (Opsional)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2339,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "datetime-local",
												value: settings.openFormTime,
												onChange: (e) => setSettings((s) => ({
													...s,
													openFormTime: e.target.value
												})),
												className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2340,
												columnNumber: 41
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2338,
												columnNumber: 37
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
												children: "Waktu Tutup Formulir (Opsional)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2349,
												columnNumber: 41
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "datetime-local",
												value: settings.closeFormTime,
												onChange: (e) => setSettings((s) => ({
													...s,
													closeFormTime: e.target.value
												})),
												className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2350,
												columnNumber: 41
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2348,
												columnNumber: 37
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2337,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
											children: "Token Kata Sandi Formulir (Opsional)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2360,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: settings.formToken,
											onChange: (e) => setSettings((s) => ({
												...s,
												formToken: e.target.value
											})),
											placeholder: "contoh: RAHASIA123",
											className: "w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs font-mono font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2361,
											columnNumber: 37
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2359,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-3 pt-2",
											children: [
												{
													key: "showScore",
													label: "Tampilkan Skor & Kunci Jawaban setelah Pengisian"
												},
												{
													key: "randomizeQuestions",
													label: "Acak Urutan Soal untuk Setiap Responden"
												},
												{
													key: "oneResponse",
													label: "Batasi 1 Kali Pengisian per Responden/Sesi"
												},
												{
													key: "requiredLogin",
													label: "Wajib Login Akun FormUp sebelum Mengisi"
												}
											].map(({ key, label }) => /* @__PURE__ */ _jsxDEV("label", {
												className: "flex items-center gap-3 cursor-pointer",
												children: [/* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: settings[key],
													onChange: (e) => setSettings((s) => ({
														...s,
														[key]: e.target.checked
													})),
													className: "w-4 h-4 text-[#00897B] rounded cursor-pointer"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2378,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-bold text-slate-700 dark:text-slate-300",
													children: label
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2384,
													columnNumber: 45
												}, this)]
											}, key, true, {
												fileName: _jsxFileName,
												lineNumber: 2377,
												columnNumber: 41
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2370,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2 mb-2",
													children: [
														/* @__PURE__ */ _jsxDEV(ShieldAlert, {
															size: 15,
															className: "text-red-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2392,
															columnNumber: 41
														}, this),
														/* @__PURE__ */ _jsxDEV("h3", {
															className: "text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider",
															children: "Mode Ujian"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2393,
															columnNumber: 41
														}, this),
														/* @__PURE__ */ _jsxDEV("span", {
															className: "text-[10px] px-1.5 py-0.5 bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400 rounded font-bold",
															children: "Experimental"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2394,
															columnNumber: 41
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2391,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("label", {
													className: "flex items-center gap-3 cursor-pointer",
													children: [/* @__PURE__ */ _jsxDEV("input", {
														type: "checkbox",
														checked: settings.isExamMode,
														onChange: (e) => setSettings((s) => ({
															...s,
															isExamMode: e.target.checked
														})),
														className: "w-4 h-4 text-red-500 rounded cursor-pointer"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2397,
														columnNumber: 41
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-xs font-bold text-slate-700 dark:text-slate-300",
														children: "Aktifkan Mode Ujian"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2398,
														columnNumber: 41
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2396,
													columnNumber: 37
												}, this),
												settings.isExamMode && /* @__PURE__ */ _jsxDEV("div", {
													className: "ml-7 space-y-2.5 p-3 bg-red-50/60 dark:bg-red-950/20 rounded-xl border border-red-100 dark:border-red-900/40",
													children: [
														/* @__PURE__ */ _jsxDEV("label", {
															className: "flex items-center gap-3 cursor-pointer",
															children: [/* @__PURE__ */ _jsxDEV("input", {
																type: "checkbox",
																checked: settings.disableCopyPaste,
																onChange: (e) => setSettings((s) => ({
																	...s,
																	disableCopyPaste: e.target.checked
																})),
																className: "w-4 h-4 text-red-500 rounded cursor-pointer"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2403,
																columnNumber: 49
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																className: "text-xs font-medium text-slate-700 dark:text-slate-300",
																children: "Nonaktifkan Copy-Paste & Klik Kanan"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2404,
																columnNumber: 49
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2402,
															columnNumber: 45
														}, this),
														/* @__PURE__ */ _jsxDEV("label", {
															className: "flex items-center gap-3 cursor-pointer",
															children: [/* @__PURE__ */ _jsxDEV("input", {
																type: "checkbox",
																checked: settings.detectTabSwitch,
																onChange: (e) => setSettings((s) => ({
																	...s,
																	detectTabSwitch: e.target.checked
																})),
																className: "w-4 h-4 text-red-500 rounded cursor-pointer"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2407,
																columnNumber: 49
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																className: "text-xs font-medium text-slate-700 dark:text-slate-300",
																children: "Deteksi Pindah Tab / Minimize"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2408,
																columnNumber: 49
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2406,
															columnNumber: 45
														}, this),
														settings.detectTabSwitch && /* @__PURE__ */ _jsxDEV("div", {
															className: "space-y-2 ml-7",
															children: [/* @__PURE__ */ _jsxDEV("label", {
																className: "flex items-center gap-3 cursor-pointer",
																children: [/* @__PURE__ */ _jsxDEV("input", {
																	type: "checkbox",
																	checked: settings.autoSubmitOnTabSwitch,
																	onChange: (e) => setSettings((s) => ({
																		...s,
																		autoSubmitOnTabSwitch: e.target.checked
																	})),
																	className: "w-4 h-4 text-red-500 rounded cursor-pointer"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2413,
																	columnNumber: 57
																}, this), /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-xs font-medium text-slate-700 dark:text-slate-300",
																	children: "Auto-Submit Saat Melewati Batas Pelanggaran"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2414,
																	columnNumber: 57
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 2412,
																columnNumber: 53
															}, this), /* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center gap-2",
																children: [
																	/* @__PURE__ */ _jsxDEV("label", {
																		className: "text-xs font-medium text-slate-600 dark:text-slate-400 whitespace-nowrap",
																		children: "Maks. Pelanggaran:"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 2417,
																		columnNumber: 57
																	}, this),
																	/* @__PURE__ */ _jsxDEV("input", {
																		type: "number",
																		min: "1",
																		max: "20",
																		value: settings.maxTabSwitch,
																		onChange: (e) => setSettings((s) => ({
																			...s,
																			maxTabSwitch: parseInt(e.target.value) || 3
																		})),
																		className: "w-16 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1 text-xs font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-red-400"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 2418,
																		columnNumber: 57
																	}, this),
																	/* @__PURE__ */ _jsxDEV("span", {
																		className: "text-xs text-slate-400",
																		children: "kali sebelum otomatis dikumpulkan"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 2419,
																		columnNumber: 57
																	}, this)
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 2416,
																columnNumber: 53
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 2411,
															columnNumber: 49
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2401,
													columnNumber: 41
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2390,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2 mb-2",
													children: [/* @__PURE__ */ _jsxDEV(Palette, {
														size: 15,
														className: "text-indigo-500"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2430,
														columnNumber: 41
													}, this), /* @__PURE__ */ _jsxDEV("h3", {
														className: "text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider",
														children: "Tema Form (Warna Kustom)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2431,
														columnNumber: 41
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2429,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[11px] text-slate-400 dark:text-slate-500",
													children: "Warna ini diterapkan pada tampilan form saat diisi oleh responden."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2433,
													columnNumber: 37
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
													children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
														className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
														children: "Warna Utama (Tombol, Aksen)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2436,
														columnNumber: 45
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2",
														children: [
															/* @__PURE__ */ _jsxDEV("input", {
																type: "color",
																value: settings.themePrimaryColor || "#00897B",
																onChange: (e) => setSettings((s) => ({
																	...s,
																	themePrimaryColor: e.target.value
																})),
																className: "w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer p-0.5 bg-white dark:bg-slate-800"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2438,
																columnNumber: 49
															}, this),
															/* @__PURE__ */ _jsxDEV("input", {
																type: "text",
																value: settings.themePrimaryColor,
																onChange: (e) => setSettings((s) => ({
																	...s,
																	themePrimaryColor: e.target.value
																})),
																placeholder: "#00897B",
																maxLength: 7,
																className: "flex-1 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2439,
																columnNumber: 49
															}, this),
															settings.themePrimaryColor && /* @__PURE__ */ _jsxDEV("button", {
																type: "button",
																onClick: () => setSettings((s) => ({
																	...s,
																	themePrimaryColor: ""
																})),
																className: "text-slate-400 hover:text-red-500 cursor-pointer",
																children: /* @__PURE__ */ _jsxDEV(X, { size: 14 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2440,
																	columnNumber: 231
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2440,
																columnNumber: 80
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2437,
														columnNumber: 45
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2435,
														columnNumber: 41
													}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
														className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
														children: "Warna Latar Belakang Form"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2444,
														columnNumber: 45
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2",
														children: [
															/* @__PURE__ */ _jsxDEV("input", {
																type: "color",
																value: settings.themeBackgroundColor || "#F4F8F7",
																onChange: (e) => setSettings((s) => ({
																	...s,
																	themeBackgroundColor: e.target.value
																})),
																className: "w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer p-0.5 bg-white dark:bg-slate-800"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2446,
																columnNumber: 49
															}, this),
															/* @__PURE__ */ _jsxDEV("input", {
																type: "text",
																value: settings.themeBackgroundColor,
																onChange: (e) => setSettings((s) => ({
																	...s,
																	themeBackgroundColor: e.target.value
																})),
																placeholder: "#F4F8F7",
																maxLength: 7,
																className: "flex-1 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-bold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#00897B]"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2447,
																columnNumber: 49
															}, this),
															settings.themeBackgroundColor && /* @__PURE__ */ _jsxDEV("button", {
																type: "button",
																onClick: () => setSettings((s) => ({
																	...s,
																	themeBackgroundColor: ""
																})),
																className: "text-slate-400 hover:text-red-500 cursor-pointer",
																children: /* @__PURE__ */ _jsxDEV(X, { size: 14 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2448,
																	columnNumber: 237
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 2448,
																columnNumber: 83
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2445,
														columnNumber: 45
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2443,
														columnNumber: 41
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2434,
													columnNumber: 37
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2428,
											columnNumber: 33
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end",
											children: /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: handleSaveSettings,
												disabled: saving,
												className: "px-5 py-2.5 bg-[#00897B] hover:bg-[#00796B] text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer disabled:opacity-60",
												children: [/* @__PURE__ */ _jsxDEV(Save, { size: 14 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2461,
													columnNumber: 41
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: saving ? "Menyimpan..." : "Simpan Pengaturan" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2462,
													columnNumber: 41
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2455,
												columnNumber: 37
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2454,
											columnNumber: 33
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2292,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2287,
								columnNumber: 25
							}, this),
							activeTab === "share" && /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 space-y-6 shadow-xs",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-sm font-extrabold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3",
									children: "Bagikan Tautan & Kode QR Formulir"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2472,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-4",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-xs font-bold text-slate-600 dark:text-slate-400 block mb-1",
										children: "Tautan Publik Formulir"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2478,
										columnNumber: 37
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											readOnly: true,
											value: `${FRONTEND_BASE_URL}/f/${form?.formLink}`,
											className: "flex-1 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono font-bold bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2480,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												navigator.clipboard.writeText(`${FRONTEND_BASE_URL}/f/${form?.formLink}`);
												setCopiedLink(true);
												setTimeout(() => setCopiedLink(false), 2e3);
											},
											className: "px-4 py-2.5 bg-[#00897B] hover:bg-[#00796B] text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer",
											children: copiedLink ? "✓ Tersalin!" : "Salin Tautan"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2486,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2479,
										columnNumber: 37
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2477,
										columnNumber: 33
									}, this), qrBlobUrl && /* @__PURE__ */ _jsxDEV("div", {
										className: "pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col items-center gap-3",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "text-xs font-bold text-slate-600 dark:text-slate-400 block",
												children: "Kode QR Gambar PNG"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2501,
												columnNumber: 41
											}, this),
											/* @__PURE__ */ _jsxDEV("img", {
												src: qrBlobUrl,
												alt: "Kode QR",
												className: "w-44 h-44 border border-slate-200 dark:border-slate-700 rounded-2xl p-2 bg-white shadow-xs"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2502,
												columnNumber: 41
											}, this),
											/* @__PURE__ */ _jsxDEV("a", {
												href: qrBlobUrl,
												download: `qr-${form?.formLink}.png`,
												className: "px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs transition-all",
												children: [/* @__PURE__ */ _jsxDEV(Download, { size: 13 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2508,
													columnNumber: 45
												}, this), " Unduh Kode QR PNG"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2503,
												columnNumber: 41
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2500,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2476,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2471,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1435,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1284,
				columnNumber: 13
			}, this),
			bulkRevisePreviewOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 bg-black/50 backdrop-blur-xs",
					onClick: () => setBulkRevisePreviewOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 2522,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative bg-white dark:bg-slate-900 w-full max-w-2xl max-h-[85vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 z-10",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV(Wand2, {
										size: 16,
										className: "text-purple-600"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2525,
										columnNumber: 123
									}, this),
									" Preview Hasil Revisi AI (",
									bulkRevisePreview.length,
									" soal)"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2525,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setBulkRevisePreviewOpen(false),
								className: "p-1 text-slate-400 hover:text-slate-700 cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2526,
									columnNumber: 166
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2526,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2524,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 overflow-y-auto p-5 space-y-4",
							children: bulkRevisePreview.map(({ idx, original, revised }) => /* @__PURE__ */ _jsxDEV("div", {
								className: "border border-slate-200 dark:border-slate-700 rounded-2xl overflow-hidden",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 bg-slate-50 dark:bg-slate-800 text-xs text-slate-500",
										children: [
											"Soal #",
											idx + 1,
											" — Original"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2531,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 text-xs text-slate-700 dark:text-slate-300",
										children: (original.question || "").replace(/<[^>]*>/g, "")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2532,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 bg-purple-50 dark:bg-purple-950/30 text-xs text-slate-500 border-t border-slate-100 dark:border-slate-700",
										children: "Hasil Revisi AI"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2533,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 text-xs font-bold text-slate-900 dark:text-white",
										children: (revised.question || "").replace(/<[^>]*>/g, "")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2534,
										columnNumber: 37
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 border-t border-slate-100 dark:border-slate-700 flex gap-2",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												applyBulkReviseItem(idx, revised);
												setBulkRevisePreview((prev) => prev.filter((p) => p.idx !== idx));
												if (bulkRevisePreview.length <= 1) {
													setBulkRevisePreviewOpen(false);
													setBulkReviseMode(false);
													showToast("Revisi berhasil diterapkan!");
												}
											},
											className: "px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl cursor-pointer",
											children: "Terapkan"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2536,
											columnNumber: 41
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setBulkRevisePreview((prev) => prev.filter((p) => p.idx !== idx)),
											className: "px-3 py-1.5 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-xs font-bold rounded-xl cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800",
											children: "Lewati"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2537,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2535,
										columnNumber: 37
									}, this)
								]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 2530,
								columnNumber: 33
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2528,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 border-t border-slate-100 dark:border-slate-800 flex justify-between",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									bulkRevisePreview.forEach(({ idx, revised }) => applyBulkReviseItem(idx, revised));
									setBulkRevisePreviewOpen(false);
									setBulkReviseMode(false);
									showToast(`${bulkRevisePreview.length} soal berhasil direvisi!`);
								},
								className: "px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl cursor-pointer",
								children: "Terapkan Semua"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2543,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setBulkRevisePreviewOpen(false),
								className: "px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-xs font-bold rounded-xl cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800",
								children: "Tutup"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2544,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2542,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2523,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2521,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV(ConfirmModal, {
				isOpen: confirmModal.isOpen,
				onClose: () => setConfirmModal((prev) => ({
					...prev,
					isOpen: false
				})),
				onConfirm: confirmModal.onConfirm,
				title: confirmModal.title,
				message: confirmModal.message,
				variant: confirmModal.variant || "danger",
				confirmText: confirmModal.confirmText || "Ya, Hapus"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2604,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(MathAndCodeModal, {
				isOpen: modalOpen,
				mode: modalMode,
				onClose: () => setModalOpen(false),
				onInsert: handleInsertFromModal
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2615,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(AIGeneratorModal, {
				isOpen: aiModalOpen,
				onClose: () => setAiModalOpen(false),
				onAddQuestions: handleAddAIQuestions,
				formTitle: form?.title || ""
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2623,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(AIFormBuilderModal, {
				isOpen: aiFormBuilderOpen,
				onClose: () => setAiFormBuilderOpen(false),
				onFormCreated: (newId) => navigate(`/forms/${newId}/builder`)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2631,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(ImportQuestionsModal, {
				isOpen: importModalOpen,
				onClose: () => setImportModalOpen(false),
				formId: id,
				hasResponses: (form?.responseCount ?? form?.totalResponses ?? 0) > 0 ? form?.responseCount ?? form?.totalResponses ?? 0 : null,
				onImported: handleOnImported
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2638,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(ImageLightboxModal, {
				isOpen: !!lightboxImage,
				src: lightboxImage?.src,
				alt: lightboxImage?.alt,
				onClose: () => setLightboxImage(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2647,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: `fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2 transition-all duration-300 ease-out transform ${scrolledPastHeader ? "opacity-100 translate-y-0 scale-100 pointer-events-auto" : "opacity-0 translate-y-6 scale-90 pointer-events-none"}`,
				children: [fabMenuOpen && /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-2.5 flex flex-col gap-1.5 w-56 animate-in zoom-in-95 duration-150",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => {
								setFabMenuOpen(false);
								handleSaveAll();
							},
							disabled: saving,
							className: `flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${isDirty ? "bg-orange-500 hover:bg-orange-600 text-white animate-pulse" : "bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV(Save, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2676,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: saving ? "Menyimpan..." : isDirty ? "⚠ Simpan Sekarang" : "Simpan Perubahan" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2677,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2663,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => {
								setFabMenuOpen(false);
								window.open(`/f/${form?.formLink}?preview=true&formId=${form?.id}`, "_blank");
							},
							className: "flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(Eye, {
								size: 14,
								className: "text-teal-600 dark:text-teal-400"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2689,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Preview Responden" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2690,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2681,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => {
								setFabMenuOpen(false);
								handleTogglePublish();
							},
							disabled: publishing,
							className: "flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer",
							children: [isPublished ? /* @__PURE__ */ _jsxDEV(Lock, {
								size: 14,
								className: "text-amber-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2703,
								columnNumber: 48
							}, this) : /* @__PURE__ */ _jsxDEV(Globe, {
								size: 14,
								className: "text-teal-600 dark:text-teal-400"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2703,
								columnNumber: 96
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: publishing ? "Memproses..." : isPublished ? "Jadikan Draf" : "Publikasikan" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2704,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2694,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setAutosaveEnabled((prev) => !prev),
							className: "flex items-center justify-between px-3 py-2 text-xs font-bold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [autosaveEnabled ? /* @__PURE__ */ _jsxDEV(ToggleRight, {
									size: 14,
									className: "text-teal-600 dark:text-teal-400"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2714,
									columnNumber: 56
								}, this) : /* @__PURE__ */ _jsxDEV(ToggleLeft, {
									size: 14,
									className: "text-slate-400"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2714,
									columnNumber: 129
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Auto-Save" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2715,
									columnNumber: 37
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2713,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: `text-[10px] px-1.5 py-0.5 rounded font-extrabold ${autosaveEnabled ? "bg-teal-50 text-teal-700 dark:bg-teal-950 dark:text-teal-300" : "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400"}`,
								children: autosaveEnabled ? "ON" : "OFF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2717,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2708,
							columnNumber: 29
						}, this),
						activeTab === "questions" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							/* @__PURE__ */ _jsxDEV("div", { className: "h-px bg-slate-100 dark:bg-slate-800 my-0.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2725,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setFabMenuOpen(false);
									setAiModalOpen(true);
								},
								className: "flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:text-teal-700 dark:hover:text-teal-300 transition-colors cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
									size: 14,
									className: "text-teal-600 dark:text-teal-400 shrink-0"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2732,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Buat dengan AI" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2733,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2727,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								"data-tour": "builder-ai-revise",
								onClick: () => {
									setFabMenuOpen(false);
									setBulkReviseMode((prev) => !prev);
									setBulkReviseSelected(new Set());
								},
								className: "flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-purple-50 dark:hover:bg-purple-950/40 hover:text-purple-700 dark:hover:text-purple-300 transition-colors cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(Wand2, {
									size: 14,
									className: "text-purple-600 dark:text-purple-400 shrink-0"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2742,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: bulkReviseMode ? "Selesai Pilih (Revisi)" : "Revisi Massal AI" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2743,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2736,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setFabMenuOpen(false);
									handleUndo();
								},
								disabled: historyIndex <= 0,
								className: "flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed",
								children: [
									/* @__PURE__ */ _jsxDEV(Undo2, {
										size: 14,
										className: "text-slate-500 shrink-0"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2752,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Undo" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2753,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "ml-auto text-[10px] font-normal text-slate-400",
										children: "Ctrl+Z"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2754,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2746,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setFabMenuOpen(false);
									handleRedo();
								},
								disabled: historyIndex >= history.length - 1,
								className: "flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed",
								children: [
									/* @__PURE__ */ _jsxDEV(Redo2, {
										size: 14,
										className: "text-slate-500 shrink-0"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2763,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Redo" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2764,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "ml-auto text-[10px] font-normal text-slate-400",
										children: "Ctrl+Y"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2765,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2757,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setFabMenuOpen(false);
									handleExportQuestions();
								},
								disabled: questions.length === 0,
								className: "flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:text-blue-700 dark:hover:text-blue-300 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed",
								children: [/* @__PURE__ */ _jsxDEV(FileDown, {
									size: 14,
									className: "text-blue-600 dark:text-blue-400 shrink-0"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2774,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Export Soal (CSV)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2775,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2768,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setFabMenuOpen(false);
									handleClearAllQuestions();
								},
								disabled: questions.length === 0,
								className: "flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed",
								children: [/* @__PURE__ */ _jsxDEV(Trash2, {
									size: 14,
									className: "shrink-0"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2784,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Hapus Semua Soal" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2785,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2778,
								columnNumber: 9
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2724,
							columnNumber: 5
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { className: "h-px bg-slate-100 dark:bg-slate-800 my-0.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2790,
							columnNumber: 1
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { className: "h-px bg-slate-100 dark:bg-slate-800 my-0.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2793,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => {
								setFabMenuOpen(false);
								if (mainScrollRef.current) {
									mainScrollRef.current.scrollTo({
										top: 0,
										behavior: "smooth"
									});
								}
								window.scrollTo({
									top: 0,
									behavior: "smooth"
								});
							},
							className: "flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(ChevronUp, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2807,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Scroll ke Atas" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2808,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2796,
							columnNumber: 29
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2661,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setFabMenuOpen((prev) => !prev),
					title: "Menu Tindakan Cepat",
					className: `relative w-12 h-12 rounded-full shadow-xl flex items-center justify-center transition-all transform hover:scale-105 active:scale-95 cursor-pointer ${isDirty ? "bg-orange-500 text-white shadow-orange-500/30" : "bg-teal-600 hover:bg-teal-700 text-white shadow-teal-600/30"}`,
					children: [
						isDirty && /* @__PURE__ */ _jsxDEV("span", { className: "absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-red-500 border-2 border-white dark:border-slate-900 animate-ping" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2825,
							columnNumber: 29
						}, this),
						isDirty && /* @__PURE__ */ _jsxDEV("span", { className: "absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-red-500 border-2 border-white dark:border-slate-900" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2828,
							columnNumber: 29
						}, this),
						fabMenuOpen ? /* @__PURE__ */ _jsxDEV(X, { size: 20 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2830,
							columnNumber: 40
						}, this) : /* @__PURE__ */ _jsxDEV(MoreVertical, { size: 20 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2830,
							columnNumber: 58
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2814,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2655,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(OnboardingTour, {
				isOpen: builderTourOpen,
				onClose: () => {
					setBuilderTourOpen(false);
					setActiveTab("questions");
				},
				onComplete: () => {
					setBuilderTourOpen(false);
					setActiveTab("questions");
					try {
						localStorage.setItem("formup_builder_tour_completed", "true");
					} catch (e) {}
				},
				steps: [
					{
						selector: "[data-tour=\"builder-tabs\"]",
						title: "Navigasi Tab Form Builder",
						description: "Kelola formulir melalui 3 tab utama: \"Pertanyaan\" untuk menyusun soal, \"Pengaturan\" untuk batas waktu dan aturan mode ujian, serta \"Bagikan\" untuk link dan QR Code.",
						icon: /* @__PURE__ */ _jsxDEV(Sliders, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2853,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Navigasi Utama",
						action: () => setActiveTab("questions")
					},
					{
						selector: "[data-tour=\"builder-ai-generator\"]",
						title: "Buat Soal Otomatis dengan AI",
						description: "Hemat waktu Anda! Ketik materi ujian, topik pembelajaran, atau silabus — AI Gemini FormUp akan langsung merancang soal, pilihan ganda, dan kunci jawaban secara instan.",
						icon: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2862,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Kecerdasan AI",
						action: () => setActiveTab("questions")
					},
					{
						selector: "[data-tour=\"builder-add-question\"]",
						title: "Tambah & Desain Soal Fleksibel",
						description: "Tambahkan soal secara manual. Anda dapat memilih tipe Pilihan Ganda, Esai, Kotak Centang, Benar/Salah, menyisipkan gambar & audio soal, hingga rumus matematika KaTeX.",
						icon: /* @__PURE__ */ _jsxDEV(Plus, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2871,
							columnNumber: 31
						}, this),
						placement: "top",
						badge: "Editor Soal",
						action: () => setActiveTab("questions")
					},
					{
						selector: "[data-tour=\"builder-question-revise\"]",
						title: "Revisi Soal dengan AI",
						description: "Gunakan ikon Wand untuk merevisi satu soal atau aktifkan Revisi Massal AI. Model dan instruksi revisi sekarang tersedia langsung di panel floating kanan.",
						icon: /* @__PURE__ */ _jsxDEV(Wand2, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2880,
							columnNumber: 31
						}, this),
						placement: "left",
						badge: "Revisi AI",
						action: () => setActiveTab("questions")
					},
					{
						selector: "[data-tour=\"tab-settings\"]",
						title: "Pengaturan Waktu & Mode Ujian Anti-Curang",
						description: "Di tab ini, Anda dapat mengaktifkan Mode Ujian (kamera proctoring & peringatan ganti tab), menyetel batas waktu pengerjaan (timer otomatis), dan mengacak urutan soal.",
						icon: /* @__PURE__ */ _jsxDEV(ShieldAlert, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2889,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Keamanan Ujian",
						action: () => setActiveTab("settings")
					},
					{
						selector: "[data-tour=\"tab-share\"]",
						title: "Bagikan Link & Unduh QR Code",
						description: "Dapatkan tautan publik unik untuk responden atau unduh lembar QR Code resmi berkualitas tinggi untuk dicetak di ruang kelas dan ujian offline.",
						icon: /* @__PURE__ */ _jsxDEV(Share2, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2898,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Distribusi",
						action: () => {
							setActiveTab("share");
							handleLoadShare();
						}
					},
					{
						selector: "[data-tour=\"builder-preview-btn\"]",
						title: "Pratinjau Tampilan Responden",
						description: "Uji dan pastikan tampilan kuis Anda nyaman dilihat baik di layar smartphone maupun komputer desktop sebelum disebarkan ke siswa atau responden.",
						icon: /* @__PURE__ */ _jsxDEV(Eye, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2910,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Simulasi"
					},
					{
						selector: "[data-tour=\"builder-save-btn\"]",
						title: "Penyimpanan & Fitur Auto-Save",
						description: "Simpan perubahan kapan saja. Anda juga bisa mengaktifkan opsi Auto-Save agar progres pengetikan tersimpan secara otomatis setiap kali Anda mengedit.",
						icon: /* @__PURE__ */ _jsxDEV(Save, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2918,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Cloud Sync"
					},
					{
						selector: "[data-tour=\"builder-publish-btn\"]",
						title: "Publikasikan Formulir Anda",
						description: "Setelah semua soal dan aturan siap, klik tombol Publikasikan agar form langsung aktif dan dapat diisi oleh siapa saja yang menerima link!",
						icon: /* @__PURE__ */ _jsxDEV(Globe, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2926,
							columnNumber: 31
						}, this),
						placement: "bottom",
						badge: "Go Live"
					}
				]
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2835,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 1281,
		columnNumber: 9
	}, this);
}
_s(FormBuilder, "eHNFUADqr2m77IOtxLTZY4QMpIM=", false, function() {
	return [useParams, useNavigate];
});
_c = FormBuilder;
var _c;
$RefreshReg$(_c, "FormBuilder");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/form-builder/FormBuilder.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-builder/FormBuilder.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/form-builder/FormBuilder.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/form-builder/FormBuilder.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsYUFBYSxRQUFRLGVBQWU7QUFDbEUsU0FBUyxhQUFhLGlCQUFpQjtBQUN2QyxTQUNJLE1BQU0sTUFBTSxRQUFRLFdBQVcsYUFDL0IsT0FBTyxNQUFNLFdBQVcsUUFBUSxRQUFRLE9BQU8sT0FBTyxVQUN0RCxNQUFNLFlBQVksS0FBSyxRQUFRLEdBQUcsVUFDbEMsTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLFlBQVksYUFDakQsYUFBYSxTQUFTLGFBQWEsZ0JBQWdCLGNBQWMsZUFBZSxVQUNoRixTQUFTLFFBQVEsWUFBWSxTQUFTLFNBQVMsZUFDNUM7QUFDUCxPQUFPLGFBQWE7QUFDcEIsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyxvQkFBb0I7QUFDM0IsU0FDSSxhQUFhLGNBQWMsZUFBZSxZQUMxQyxtQkFBbUIsb0JBQW9CLGNBQ3ZDLGtCQUFrQixjQUFjLFVBQ2hDLGdCQUFnQixxQkFBcUIscUJBQ3JDLG1CQUNBLHFCQUFxQixZQUFZLG9CQUFvQiw4QkFDbEQ7QUFDUCxTQUFTLGlCQUFpQixrQkFBa0Isc0JBQXNCLGlDQUFpQztBQUNuRyxPQUFPLHlCQUF5QjtBQUNoQyxPQUFPLHlCQUF5QjtBQUNoQyxPQUFPLHNCQUFzQjtBQUM3QixPQUFPLHdCQUF3QjtBQUMvQixPQUFPLHNCQUFzQjtBQUM3QixPQUFPLHdCQUF3QjtBQUMvQixPQUFPLDBCQUEwQjs7OztBQUVqQyxNQUFNLFNBQVMsT0FBTyxLQUFLLElBQUk7QUFDL0IsTUFBTSxlQUFnQixXQUFXLGFBQWEsV0FBVyxLQUNuRCxTQUNDLE9BQU8sS0FBSyxJQUFJLE1BQU0sS0FBSztBQUNsQyxNQUFNLG9CQUFvQixPQUFPLEtBQUssSUFBSSxzQkFBc0IsT0FBTyxXQUFXLGNBQWMsT0FBTyxTQUFTLFNBQVM7QUFFekgsTUFBTSxpQkFBaUI7Q0FDbkI7RUFBRSxJQUFJO0VBQUcsT0FBTztDQUF1QjtDQUN2QztFQUFFLElBQUk7RUFBRyxPQUFPO0NBQWtCO0NBQ2xDO0VBQUUsSUFBSTtFQUFHLE9BQU87Q0FBVztDQUMzQjtFQUFFLElBQUk7RUFBRyxPQUFPO0NBQVk7Q0FDNUI7RUFBRSxJQUFJO0VBQUcsT0FBTztDQUFlO0FBQ25DO0FBRUEsTUFBTSxlQUFlLFdBQVc7Q0FDNUIsS0FBSyxTQUFTLEtBQUssSUFBSSxFQUFFLEdBQUc7Q0FDNUIsSUFBSTtDQUNKLFVBQVU7Q0FDVixRQUFRO0NBQ1IsZUFBZTtDQUNmLFlBQVk7Q0FDWixZQUFZO0NBQ1osUUFBUTtDQUNSLGVBQWU7Q0FDZixTQUFTLENBQ0w7RUFBRSxZQUFZO0VBQUksV0FBVztFQUFPLGFBQWE7Q0FBSyxHQUN0RDtFQUFFLFlBQVk7RUFBSSxXQUFXO0VBQU8sYUFBYTtDQUFLLENBQzFEO0NBQ0EsZUFBZTtDQUNmLGVBQWU7QUFDbkI7QUFFQSxNQUFNLGdCQUFnQixXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxTQUFTLE1BQU07O0FBR3ZELE1BQU0sMkJBQTJCLE1BQU07Q0FDbkMsSUFBSSxRQUFRLEVBQUUsY0FBYyxFQUFFLGNBQWMsR0FBRSxDQUFFLEtBQUs7Q0FDckQsSUFBSSxZQUFZLEVBQUUsY0FBYyxRQUFRLEVBQUUsY0FBYztDQUV4RCxJQUFJLEtBQUssV0FBVyxTQUFTLEdBQUc7RUFDNUIsWUFBWTtFQUNaLE9BQU8sS0FBSyxRQUFRLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxLQUFLO0NBQ25ELE9BQU8sSUFBSSxLQUFLLFdBQVcsR0FBRyxHQUFHO0VBQzdCLFlBQVk7RUFDWixPQUFPLEtBQUssUUFBUSxVQUFVLEVBQUUsQ0FBQyxDQUFDLEtBQUs7Q0FDM0M7Q0FFQSxPQUFPO0VBQ0gsR0FBRztFQUNILFlBQVk7RUFDWjtFQUNBLGFBQWEsRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLFlBQVk7Q0FDM0Q7QUFDSjtBQUVBLE1BQU0sNEJBQTRCLE1BQU07Q0FDcEMsTUFBTSxhQUFhLEVBQUUsV0FBVyxFQUFFLG1CQUFtQixDQUFDO0NBQ3RELElBQUksT0FBTyxXQUFXLElBQUksdUJBQXVCOztDQUdqRCxNQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssRUFBRSxXQUFXLEtBQUssRUFBRSxZQUFZLEtBQUssRUFBRSxZQUFZO0NBQ3RGLElBQUksWUFBWSxFQUFFLGlCQUFpQixDQUFDLEtBQUssTUFBSyxNQUFLLEVBQUUsU0FBUyxHQUFHO0VBQzdELE1BQU0sU0FBUyxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUMsTUFBTSxPQUFPLENBQUMsQ0FBQyxLQUFJLE1BQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUM7RUFDckYsT0FBTyxLQUFLLEtBQUksTUFBSztHQUNqQixJQUFJLE9BQU8sU0FBUyxFQUFFLFdBQVcsS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLEdBQUc7SUFDcEQsT0FBTztLQUFFLEdBQUc7S0FBRyxXQUFXO0lBQUs7R0FDbkM7R0FDQSxPQUFPO0VBQ1gsQ0FBQztDQUNMO0NBRUEsT0FBTyxLQUFLLFNBQVMsSUFBSSxPQUFPLENBQUM7RUFBRSxZQUFZO0VBQUksV0FBVztFQUFPLGFBQWE7Q0FBSyxDQUFDO0FBQzVGO0FBRUEsZUFBZSxTQUFTLGNBQWM7O0NBQ2xDLE1BQU0sRUFBRSxPQUFPLFVBQVU7Q0FDekIsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLElBQUk7Q0FDckMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsQ0FBQyxDQUFDO0NBQzdDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLO0NBQzFDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsV0FBVztDQUN0RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxJQUFJO0NBQy9DLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLElBQUk7Q0FDL0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxJQUFJOztDQUd2RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLE1BQU07Q0FDakQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVM7RUFBRSxNQUFNO0VBQVksTUFBTTtFQUFNLE1BQU07Q0FBSyxDQUFDOztDQUczRixNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLOztDQUdwRCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7O0NBR2hFLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsS0FBSzs7Q0FHNUQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsQ0FBQztDQUNoRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLENBQUM7O0NBR3RELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsSUFBSTtDQUMzRCxNQUFNLENBQUMscUJBQXFCLDBCQUEwQixTQUFTLEVBQUU7Q0FDakUsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixlQUFlO0VBQUUsTUFBTSxJQUFJLGFBQWEsUUFBUSw0QkFBNEI7RUFBRyxPQUFPLEtBQUssQ0FBQyxFQUFFLFNBQVMsTUFBTSxLQUFLLGlCQUFpQixNQUFLLFVBQVMsTUFBTSxPQUFPLENBQUMsSUFBSSxJQUFJO0NBQW9CLENBQUM7O0NBR2xPLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsS0FBSztDQUMxRCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLElBQUksSUFBSSxDQUFDO0NBQ3RFLE1BQU0sQ0FBQyx1QkFBdUIsNEJBQTRCLFNBQVMsRUFBRTtDQUNyRSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsQ0FBQyxDQUFDO0NBQzdELE1BQU0sQ0FBQyx1QkFBdUIsNEJBQTRCLFNBQVMsS0FBSzs7Q0FHeEUsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxDQUFDLENBQUM7O0NBRzdELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsS0FBSzs7Q0FHMUQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBQzVELE1BQU0saUJBQWlCLE9BQU8sSUFBSTs7Q0FHbEMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVM7RUFBRSxRQUFRO0VBQU8sT0FBTztFQUFJLFNBQVM7RUFBSSxXQUFXO0VBQU0sU0FBUztDQUFTLENBQUM7O0NBRzlILE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLOztDQUc1QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsQ0FBQyxDQUFDO0NBQ3pDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLENBQUMsQ0FBQztDQUNuRCxNQUFNLHFCQUFxQixPQUFPLEtBQUs7Ozs7OztDQU12QyxNQUFNLGFBQWEsT0FBTyxDQUFDLENBQUM7Q0FDNUIsTUFBTSxrQkFBa0IsT0FBTyxDQUFDLENBQUM7OztDQUdqQyxNQUFNLGVBQWUsT0FBTyxTQUFTO0NBQ3JDLGdCQUFnQjtFQUFFLGFBQWEsVUFBVTtDQUFXLEdBQUcsQ0FBQyxTQUFTLENBQUM7O0NBRWxFLE1BQU0sc0JBQXNCLE9BQU8sSUFBSTs7Q0FHdkMsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsZUFBZTtFQUN6RCxJQUFJO0dBQUUsT0FBTyxhQUFhLFFBQVEsc0JBQXNCLE1BQU07RUFBUSxRQUFRO0dBQUUsT0FBTztFQUFPO0NBQ2xHLENBQUM7Q0FDRCxNQUFNLHNCQUFzQixPQUFPLElBQUk7Q0FDdkMsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsRUFBRTtDQUNyRCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEVBQUU7O0NBRzdELE1BQU0sZ0JBQWdCLE9BQU8sSUFBSTtDQUNqQyxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLEtBQUs7Q0FDbEUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSzs7Q0FHcEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLOztDQUc1RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLENBQUMsQ0FBQzs7Q0FHdkQsTUFBTSxrQkFBa0IsT0FBTyxJQUFJO0NBRW5DLGdCQUFnQjs7RUFFWixJQUFJLE9BQU8sV0FBVyxhQUFhO0dBQy9CLE1BQU0sWUFBWSxJQUFJLGdCQUFnQixPQUFPLFNBQVMsTUFBTTtHQUM1RCxJQUFJLFVBQVUsSUFBSSxNQUFNLE1BQU0sV0FBVztJQUNyQyxpQkFBaUIsbUJBQW1CLElBQUksR0FBRyxHQUFHO0dBQ2xEO0dBQ0EsT0FBTywwQkFBMEIsbUJBQW1CLElBQUk7RUFDNUQ7RUFDQSxhQUFhO0dBQ1QsSUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLG1CQUFtQjtJQUMzRCxPQUFPLE9BQU87R0FDbEI7RUFDSjtDQUNKLEdBQUcsQ0FBQyxDQUFDO0NBRUwsZ0JBQWdCO0VBQ1osTUFBTSxXQUFXLGNBQWM7RUFDL0IsTUFBTSxxQkFBcUI7R0FDdkIsTUFBTSxNQUFNLFdBQVcsU0FBUyxZQUFZLE9BQU87R0FDbkQsc0JBQXNCLE1BQU0sR0FBRztFQUNuQztFQUNBLElBQUksVUFBVTtHQUNWLFNBQVMsaUJBQWlCLFVBQVUsY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDO0VBQ3ZFO0VBQ0EsT0FBTyxpQkFBaUIsVUFBVSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUM7RUFDakUsYUFBYTtHQUNULElBQUksVUFBVSxTQUFTLG9CQUFvQixVQUFVLFlBQVk7R0FDakUsT0FBTyxvQkFBb0IsVUFBVSxZQUFZO0VBQ3JEO0NBQ0osR0FBRyxDQUFDLENBQUM7O0NBR0wsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTO0VBQ3JDLFlBQVk7RUFDWixXQUFXO0VBQ1gsb0JBQW9CO0VBQ3BCLGFBQWE7RUFDYixlQUFlO0VBQ2YsV0FBVztFQUNYLGVBQWU7RUFDZixjQUFjO0VBQ2QsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQix1QkFBdUI7RUFDdkIsY0FBYztFQUNkLG1CQUFtQjtFQUNuQixzQkFBc0I7Q0FDMUIsQ0FBQzs7Q0FHRCxNQUFNLDZCQUE2QixhQUFhLFVBQVU7RUFDdEQsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUcsT0FBTztFQUNsQyxPQUFPLEtBQUssVUFBVSxNQUFNLEtBQUksT0FBTTtHQUNsQyxRQUFRLFNBQVMsRUFBRSxRQUFRLEVBQUUsS0FBSztHQUNsQyxXQUFXLEVBQUUsWUFBWSxHQUFFLENBQUUsS0FBSztHQUNsQyxnQkFBZ0IsRUFBRSxrQkFBa0I7R0FDcEMsWUFBWSxDQUFDLENBQUMsRUFBRTtHQUNoQixnQkFBZ0IsRUFBRSxpQkFBaUIsR0FBRSxDQUFFLEtBQUs7R0FDNUMsUUFBUSxFQUFFLFVBQVU7R0FDcEIsZUFBZSxFQUFFLGlCQUFpQjtHQUNsQyxlQUFlLEVBQUUsaUJBQWlCO0dBQ2xDLFVBQVUsRUFBRSxXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUksT0FBTTtJQUNqQyxhQUFhLEVBQUUsY0FBYyxHQUFFLENBQUUsS0FBSztJQUN0QyxXQUFXLENBQUMsQ0FBQyxFQUFFO0lBQ2YsYUFBYSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsWUFBWTtHQUMzRCxFQUFFO0VBQ04sRUFBRSxDQUFDO0NBQ1AsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLDRCQUE0QixhQUFhLE1BQU07RUFDakQsSUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFVBQVUsT0FBTztFQUN4QyxPQUFPLEtBQUssVUFBVTtHQUNsQixZQUFZLFNBQVMsRUFBRSxZQUFZLEVBQUUsS0FBSztHQUMxQyxXQUFXLENBQUMsQ0FBQyxFQUFFO0dBQ2Ysb0JBQW9CLENBQUMsQ0FBQyxFQUFFO0dBQ3hCLGFBQWEsQ0FBQyxDQUFDLEVBQUU7R0FDakIsZUFBZSxDQUFDLENBQUMsRUFBRTtHQUNuQixZQUFZLEVBQUUsYUFBYSxHQUFFLENBQUUsS0FBSztHQUNwQyxlQUFlLEVBQUUsZ0JBQWdCLE9BQU8sRUFBRSxhQUFhLElBQUk7R0FDM0QsY0FBYyxFQUFFLGdCQUFnQjtHQUNoQyxlQUFlLEVBQUUsaUJBQWlCO0dBQ2xDLGlCQUFpQixFQUFFLGtCQUFrQixHQUFFLENBQUUsS0FBSztHQUM5QyxZQUFZLENBQUMsQ0FBQyxFQUFFO0dBQ2hCLGtCQUFrQixDQUFDLENBQUMsRUFBRTtHQUN0QixpQkFBaUIsQ0FBQyxDQUFDLEVBQUU7R0FDckIsdUJBQXVCLENBQUMsQ0FBQyxFQUFFO0dBQzNCLGNBQWMsRUFBRSxlQUFlLFNBQVMsRUFBRSxjQUFjLEVBQUUsSUFBSTtHQUM5RCxtQkFBbUIsRUFBRSxxQkFBcUI7R0FDMUMsc0JBQXNCLEVBQUUsd0JBQXdCO0VBQ3BELENBQUM7Q0FDTCxHQUFHLENBQUMsQ0FBQzs7Q0FHTCxNQUFNLGNBQWMsT0FBTztFQUFFLFdBQVc7RUFBSSxVQUFVO0NBQUcsQ0FBQzs7Q0FHMUQsZ0JBQWdCO0VBQ1osSUFBSSxTQUFTO0VBQ2IsSUFBSSxDQUFDLFlBQVksUUFBUSxhQUFhLENBQUMsWUFBWSxRQUFRLFVBQVU7RUFFckUsTUFBTSxjQUFjLDJCQUEyQixTQUFTO0VBQ3hELE1BQU0sY0FBYywwQkFBMEIsUUFBUTtFQUV0RCxNQUFNLFNBQVMsZ0JBQWdCLFlBQVksUUFBUTtFQUNuRCxNQUFNLFNBQVMsZ0JBQWdCLFlBQVksUUFBUTtFQUVuRCxXQUFXLFVBQVUsTUFBTTtDQUMvQixHQUFHO0VBQUM7RUFBVztFQUFVO0VBQVM7RUFBNEI7Q0FBeUIsQ0FBQzs7Q0FHeEYsZ0JBQWdCO0VBQ1osTUFBTSxXQUFXLE1BQU07R0FDbkIsSUFBSSxTQUFTO0lBQ1QsRUFBRSxlQUFlO0lBQ2pCLEVBQUUsY0FBYztHQUNwQjtFQUNKO0VBQ0EsT0FBTyxpQkFBaUIsZ0JBQWdCLE9BQU87RUFDL0MsYUFBYSxPQUFPLG9CQUFvQixnQkFBZ0IsT0FBTztDQUNuRSxHQUFHLENBQUMsT0FBTyxDQUFDO0NBRVosZ0JBQWdCO0VBQ2hCLE9BQU8scUJBQXFCO0VBRTVCLGFBQWE7R0FDVCxPQUFPLHFCQUFxQjtFQUNoQztDQUNKLEdBQUcsQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCUixnQkFBZ0I7RUFDWixNQUFNLFdBQVcsTUFBTTtHQUNuQixJQUFJLGVBQWUsV0FBVyxDQUFDLGVBQWUsUUFBUSxTQUFTLEVBQUUsTUFBTSxHQUFHO0lBQ3RFLG1CQUFtQixLQUFLO0dBQzVCO0VBQ0o7RUFDQSxTQUFTLGlCQUFpQixhQUFhLE9BQU87RUFDOUMsYUFBYSxTQUFTLG9CQUFvQixhQUFhLE9BQU87Q0FDbEUsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ1osSUFBSSxNQUFNLE9BQU87R0FDYixTQUFTLFFBQVEsVUFBVSxLQUFLLEtBQUssTUFBTSxhQUFhLEdBQUcsS0FBSyxNQUFNO0VBQzFFO0VBQ0EsYUFBYTtHQUFFLFNBQVMsUUFBUTtFQUFVO0NBQzlDLEdBQUcsQ0FBQyxTQUFTLE1BQU0sS0FBSyxDQUFDOzs7Ozs7OztDQVNyQixNQUFNLGNBQWMsYUFBYSwyQkFBMkI7RUFDNUQsSUFBSSxtQkFBbUIsU0FBUzs7Ozs7OztFQU9oQyxJQUFJLG9CQUFvQixTQUFTO0dBQzdCLGFBQWEsb0JBQW9CLE9BQU87R0FDeEMsb0JBQW9CLFVBQVU7RUFDbEM7RUFDQSxNQUFNLFdBQVcsS0FBSyxNQUFNLEtBQUssVUFBVSxzQkFBc0IsQ0FBQztFQUNsRSxNQUFNLGFBQWEsZ0JBQWdCO0VBQ25DLE1BQU0sYUFBYSxDQUFDLEdBQUcsV0FBVyxRQUFRLE1BQU0sR0FBRyxhQUFhLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRTtFQUN2RixNQUFNLFdBQVcsV0FBVyxTQUFTO0VBQ3JDLFdBQVcsVUFBVTtFQUNyQixnQkFBZ0IsVUFBVTtFQUMxQixXQUFXLFVBQVU7RUFDckIsZ0JBQWdCLFFBQVE7O0NBRTVCLEdBQUcsQ0FBQyxDQUFDOzs7O0NBS0wsZ0JBQWdCO0VBQ1osTUFBTSxXQUFXLE1BQU07R0FDbkIsS0FBSyxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsUUFBUSxPQUFPLENBQUMsRUFBRSxVQUFVO0lBQzFELEVBQUUsZUFBZTtJQUNqQixXQUFXO0dBQ2YsT0FBTyxLQUFLLEVBQUUsV0FBVyxFQUFFLGFBQWEsRUFBRSxRQUFRLE9BQVEsRUFBRSxRQUFRLE9BQU8sRUFBRSxXQUFZO0lBQ3JGLEVBQUUsZUFBZTtJQUNqQixXQUFXO0dBQ2Y7RUFDSjtFQUNBLE9BQU8saUJBQWlCLFdBQVcsT0FBTztFQUMxQyxhQUFhLE9BQU8sb0JBQW9CLFdBQVcsT0FBTzs7Q0FFOUQsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLG1CQUFtQjtFQUNyQixNQUFNLE1BQU0sZ0JBQWdCO0VBQzVCLElBQUksT0FBTyxHQUFHO0VBQ2QsTUFBTSxTQUFTLE1BQU07RUFDckIsbUJBQW1CLFVBQVU7RUFDN0IsZ0JBQWdCLFVBQVU7RUFDMUIsZ0JBQWdCLE1BQU07RUFDdEIsYUFBYSxLQUFLLE1BQU0sS0FBSyxVQUFVLFdBQVcsUUFBUSxPQUFPLENBQUMsQ0FBQztFQUNuRSxpQkFBaUI7R0FBRSxtQkFBbUIsVUFBVTtFQUFPLEdBQUcsQ0FBQztDQUMvRDtDQUVBLE1BQU0sbUJBQW1CO0VBQ3JCLE1BQU0sTUFBTSxnQkFBZ0I7RUFDNUIsSUFBSSxPQUFPLFdBQVcsUUFBUSxTQUFTLEdBQUc7RUFDMUMsTUFBTSxTQUFTLE1BQU07RUFDckIsbUJBQW1CLFVBQVU7RUFDN0IsZ0JBQWdCLFVBQVU7RUFDMUIsZ0JBQWdCLE1BQU07RUFDdEIsYUFBYSxLQUFLLE1BQU0sS0FBSyxVQUFVLFdBQVcsUUFBUSxPQUFPLENBQUMsQ0FBQztFQUNuRSxpQkFBaUI7R0FBRSxtQkFBbUIsVUFBVTtFQUFPLEdBQUcsQ0FBQztDQUMvRDs7Q0FHQSxnQkFBZ0I7RUFDWixhQUFhLFFBQVEsd0JBQXdCLE9BQU8sZUFBZSxDQUFDO0VBQ3BFLElBQUksb0JBQW9CLFNBQVMsY0FBYyxvQkFBb0IsT0FBTztFQUMxRSxJQUFJLGlCQUFpQjtHQUNqQixvQkFBb0IsVUFBVSxZQUFZLFlBQVk7SUFDbEQsSUFBSSxDQUFDLFNBQVM7SUFDZCxNQUFNLEtBQUssTUFBTSxjQUFjO0lBQy9CLElBQUksSUFBSTtLQUNKLE1BQU0sTUFBTSxJQUFJLEtBQUs7S0FDckIsTUFBTSxPQUFPLEdBQUcsT0FBTyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFFLEdBQUcsRUFBRSxHQUFHLE9BQU8sSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRSxHQUFHO0tBQ2pHLGlCQUFpQiw0QkFBNEIsTUFBTTtLQUNuRCxxQkFBcUIsYUFBYSxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixTQUFTO01BQUUsTUFBTTtNQUFXLFFBQVE7S0FBVSxDQUFDLEdBQUc7S0FDbEgsaUJBQWlCLGlCQUFpQixFQUFFLEdBQUcsSUFBSTtJQUMvQztHQUNKLEdBQUcsSUFBSztFQUNaO0VBQ0EsYUFBYTtHQUFFLElBQUksb0JBQW9CLFNBQVMsY0FBYyxvQkFBb0IsT0FBTztFQUFHO0NBQ2hHLEdBQUc7RUFBQztFQUFpQjtFQUFTO0NBQVMsQ0FBQztDQUV4QyxNQUFNLHdCQUF3QixZQUFZO0VBQ3RDLElBQUksQ0FBQyxTQUFTLE9BQU87RUFDckIsTUFBTSxJQUFJLElBQUksS0FBSyxPQUFPO0VBQzFCLElBQUksTUFBTSxFQUFFLFFBQVEsQ0FBQyxHQUFHLE9BQU87RUFDL0IsTUFBTSxPQUFPLEVBQUUsWUFBWTtFQUMzQixNQUFNLFFBQVEsT0FBTyxFQUFFLFNBQVMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztFQUN0RCxNQUFNLE1BQU0sT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7RUFDL0MsTUFBTSxRQUFRLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0VBQ2xELE1BQU0sVUFBVSxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztFQUN0RCxPQUFPLEdBQUcsS0FBSyxHQUFHLE1BQU0sR0FBRyxJQUFJLEdBQUcsTUFBTSxHQUFHO0NBQy9DO0NBRUEsTUFBTSxhQUFhLEtBQUssT0FBTyxjQUFjO0VBQ3pDLFNBQVM7R0FBRTtHQUFLO0VBQUssQ0FBQztFQUN0QixpQkFBaUIsU0FBUyxJQUFJLEdBQUcsR0FBSTtDQUN6Qzs7Q0FHQSxNQUFNLGdCQUFnQixjQUFjO0VBQ2hDLElBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUyxHQUFHLE9BQU87RUFDdEMsT0FBTyxVQUFVLFFBQVEsT0FBTyxNQUFNO0dBQ2xDLElBQUksRUFBRSxlQUFlLE9BQU8sT0FBTztHQUNuQyxNQUFNLElBQUksT0FBTyxFQUFFLE1BQU07R0FDekIsT0FBTyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxJQUFJLElBQUk7RUFDN0MsR0FBRyxDQUFDO0NBQ1IsR0FBRyxDQUFDLFNBQVMsQ0FBQzs7Q0FHZCxnQkFBZ0I7RUFDWixNQUFNLElBQUksaUJBQWlCO0dBQ3ZCLG1CQUFtQixVQUFVO0dBQzdCLGVBQWUsQ0FBQztFQUNwQixHQUFHLEdBQUc7RUFDTixhQUFhLGFBQWEsQ0FBQztDQUMvQixHQUFHLENBQUMsVUFBVSxDQUFDOztDQUdmLE1BQU0saUJBQWlCLFlBQVksT0FBTyxFQUFFLE9BQU8sR0FBRyxjQUFjLFVBQVUsU0FBUyxpQkFBaUIsYUFBYSxVQUFVLENBQUMsTUFBTTtFQUNsSSxNQUFNLE9BQU8sTUFBTSxhQUFhLElBQUk7R0FDaEM7R0FDQSxVQUFVO0dBQ1Y7RUFDSixDQUFDO0VBQ0QsSUFBSSxDQUFDLEtBQUssSUFBSTtHQUNWLFVBQVUsS0FBSyxXQUFXLDRCQUE0QixPQUFPO0dBQzdELE9BQU87RUFDWDtFQUVBLElBQUksa0JBQWtCLENBQUM7RUFDdkIsSUFBSSxRQUFRO0VBRVosSUFBSSxNQUFNLFFBQVEsS0FBSyxJQUFJLEdBQUc7R0FDMUIsa0JBQWtCLEtBQUs7R0FDdkIsUUFBUSxLQUFLLEtBQUs7RUFDdEIsT0FBTyxJQUFJLEtBQUssUUFBUSxPQUFPLEtBQUssU0FBUyxVQUFVO0dBQ25ELGtCQUFrQixLQUFLLEtBQUssYUFBYSxLQUFLLEtBQUssU0FBUyxLQUFLLEtBQUssUUFBUSxDQUFDO0dBQy9FLFFBQVEsS0FBSyxLQUFLLFNBQVMsS0FBSyxLQUFLLGNBQWMsS0FBSyxLQUFLLFNBQVMsZ0JBQWdCO0VBQzFGO0VBRUEsa0JBQWtCLGNBQWMsU0FBUyxJQUFJLFNBQVMsTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLENBQUM7RUFDOUUsZUFBZSxJQUFJO0VBQ25CLFlBQVksV0FBVztFQUV2QixPQUFPO0NBQ1gsR0FBRztFQUFDO0VBQUk7RUFBVTtDQUFlLENBQUM7O0NBR2xDLGdCQUFnQjtFQUNaLElBQUksV0FBVyxDQUFDLElBQUk7RUFDcEIsTUFBTSxVQUFVLFlBQVk7R0FDeEIsTUFBTSxrQkFBa0IsTUFBTSxlQUFlLEVBQUUsTUFBTSxZQUFZLENBQUM7R0FDbEUsSUFBSSxtQkFBbUIsTUFBTTtHQUM3QixJQUFJLFFBQVEsQ0FBQztHQUNiLElBQUksTUFBTSxRQUFRLGVBQWUsS0FBSyxnQkFBZ0IsU0FBUyxHQUFHO0lBQzlELFFBQVEsZ0JBQWdCLEtBQUssTUFBTTtLQUMvQixNQUFNLG9CQUFvQix5QkFBeUIsQ0FBQztLQUNwRCxNQUFNLG1CQUFtQixrQkFBa0IsTUFBSyxNQUFLLEVBQUUsY0FBYyxJQUFJO0tBQ3pFLE1BQU0sbUJBQW1CLENBQUMsRUFBRSxFQUFFLGlCQUFpQixFQUFFLGNBQWMsS0FBSztLQUNwRSxNQUFNLGFBQWEsRUFBRSxlQUFlLFlBQVksRUFBRSxhQUFjLG9CQUFvQjtLQUNwRixPQUFPO01BQ0gsR0FBRztNQUNILEtBQUssS0FBSyxFQUFFO01BQ0E7TUFDWixTQUFTO0tBQ2I7SUFDSixDQUFDO0dBQ0wsT0FBTyxJQUFJLGdCQUFnQixLQUFLLENBQUMsaUJBQWlCO0lBQzlDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN2QixrQkFBa0IsQ0FBQztHQUN2QjtHQUNBLGFBQWEsS0FBSztFQUN0QjtFQUNBLFFBQVE7O0NBRVosR0FBRztFQUFDO0VBQWE7RUFBaUI7RUFBVTtDQUFFLENBQUM7Q0FHL0MsZ0JBQWdCO0VBQ1osTUFBTSxPQUFPLFlBQVk7R0FDckIsV0FBVyxJQUFJO0dBQ2YsTUFBTSxVQUFVLE1BQU0sWUFBWSxFQUFFO0dBQ3BDLE1BQU0scUJBQXFCLE1BQU0sZUFBZTtJQUFFLE1BQU07SUFBRyxZQUFZO0dBQUssQ0FBQztHQUU3RSxJQUFJLFFBQVEsV0FBVyxLQUFLO0lBQUUsYUFBYTtJQUFHLFNBQVMsUUFBUTtJQUFHO0dBQVE7R0FFMUUsSUFBSSxpQkFBaUIsRUFBRSxHQUFHLFNBQVM7R0FDbkMsSUFBSSxRQUFRLE1BQU0sUUFBUSxNQUFNO0lBQzVCLE1BQU0sSUFBSSxRQUFRO0lBQ2xCLFFBQVEsQ0FBQztJQUNULE1BQU0sSUFBSSxFQUFFLFlBQVksQ0FBQztJQUN6QixpQkFBaUI7S0FDYixZQUFZLEVBQUUsY0FBYztLQUM1QixXQUFXLEVBQUUsYUFBYTtLQUMxQixvQkFBb0IsRUFBRSxzQkFBc0I7S0FDNUMsYUFBYSxFQUFFLGVBQWU7S0FDOUIsZUFBZSxFQUFFLGlCQUFpQjtLQUNsQyxXQUFXLEVBQUUsYUFBYTtLQUMxQixlQUFlLEVBQUUsZ0JBQWdCLEtBQUssTUFBTSxFQUFFLGdCQUFnQixFQUFFLElBQUk7S0FDcEUsY0FBYyxxQkFBcUIsRUFBRSxZQUFZO0tBQ2pELGVBQWUscUJBQXFCLEVBQUUsYUFBYTtLQUNuRCxnQkFBZ0IsRUFBRSxZQUFZO0tBQzlCLFlBQVksRUFBRSxjQUFjO0tBQzVCLGtCQUFrQixFQUFFLG9CQUFvQjtLQUN4QyxpQkFBaUIsRUFBRSxtQkFBbUI7S0FDdEMsdUJBQXVCLEVBQUUseUJBQXlCO0tBQ2xELGNBQWMsRUFBRSxnQkFBZ0I7S0FDaEMsbUJBQW1CLEVBQUUscUJBQXFCO0tBQzFDLHNCQUFzQixFQUFFLHdCQUF3QjtJQUNwRDtJQUNBLFlBQVksY0FBYztHQUM5QjtHQUVBLElBQUksa0JBQWtCLENBQUM7R0FDdkIsSUFBSSxNQUFNLFFBQVEsa0JBQWtCLEtBQUssbUJBQW1CLFNBQVMsR0FBRztJQUNwRSxrQkFBa0IsbUJBQW1CLEtBQUssTUFBTTtLQUM1QyxNQUFNLG9CQUFvQix5QkFBeUIsQ0FBQztLQUNwRCxNQUFNLG1CQUFtQixrQkFBa0IsTUFBSyxNQUFLLEVBQUUsY0FBYyxJQUFJO0tBQ3pFLE1BQU0sbUJBQW1CLENBQUMsRUFBRSxFQUFFLGlCQUFpQixFQUFFLGNBQWMsS0FBSztLQUNwRSxNQUFNLGFBQWEsRUFBRSxlQUFlLFlBQVksRUFBRSxhQUFjLG9CQUFvQjtLQUVwRixPQUFPO01BQ0gsR0FBRztNQUNILEtBQUssS0FBSyxFQUFFO01BQ0E7TUFDWixTQUFTO0tBQ2I7SUFDSixDQUFDO0dBQ0wsT0FBTztJQUNILGtCQUFrQixDQUFDLFlBQVksQ0FBQyxDQUFDO0dBQ3JDO0dBQ0EsYUFBYSxlQUFlOzs7O0dBSzVCLE1BQU0sZUFBZSxLQUFLLE1BQU0sS0FBSyxVQUFVLGVBQWUsQ0FBQztHQUMvRCxXQUFXLFVBQVUsQ0FBQyxZQUFZO0dBQ2xDLGdCQUFnQixVQUFVO0dBQzFCLFdBQVcsQ0FBQyxZQUFZLENBQUM7R0FDekIsZ0JBQWdCLENBQUM7O0dBR2pCLFlBQVksVUFBVTtJQUNsQixXQUFXLDJCQUEyQixlQUFlO0lBQ3JELFVBQVUsMEJBQTBCLGNBQWM7R0FDdEQ7R0FDQSxXQUFXLEtBQUs7R0FDaEIsV0FBVyxLQUFLO0VBQ3BCO0VBQ0EsS0FBSztDQUNULEdBQUc7RUFBQztFQUFJO0VBQVU7RUFBNEI7Q0FBeUIsQ0FBQztDQUV4RSxNQUFNLHNCQUFzQixZQUFZO0VBQ3BDLFVBQVUsSUFBSTs7RUFFZCxNQUFNLG1CQUFtQixVQUFVLEtBQUssR0FBRyxNQUFNO0dBQzdDLE1BQU0sV0FBVyxFQUFFLGVBQWU7R0FDbEMsT0FBTztJQUNILElBQUksRUFBRSxNQUFNO0lBQ1osUUFBUSxTQUFTLEVBQUUsTUFBTTtJQUN6QixVQUFVLEVBQUUsWUFBWTtJQUN4QixnQkFBZ0IsRUFBRSxrQkFBa0I7SUFDcEMsZUFBZSxJQUFJO0lBQ25CLFlBQVksQ0FBQyxDQUFDLEVBQUU7SUFDaEIsZUFBZSxXQUFZLEVBQUUsaUJBQWlCLE9BQVE7SUFDdEQsUUFBUSxZQUFZLEVBQUUsU0FBUyxTQUFTLEVBQUUsUUFBUSxFQUFFLElBQUk7SUFDeEQsZUFBZSxFQUFFLGlCQUFpQjtJQUNsQyxlQUFlLEVBQUUsaUJBQWlCO0lBQ2xDLFVBQVUsRUFBRSxXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUksU0FBUTtLQUNuQyxZQUFZLElBQUksY0FBYztLQUM5QixXQUFXLFdBQVcsQ0FBQyxDQUFDLElBQUksWUFBWTtLQUN4QyxhQUFhLElBQUksZUFBZSxJQUFJLFNBQVMsSUFBSSxZQUFZO0lBQ2pFLEVBQUU7R0FDTjtFQUNKLENBQUM7RUFFRCxNQUFNLE1BQU0sTUFBTSxjQUFjLElBQUksZ0JBQWdCO0VBQ3BELFVBQVUsS0FBSztFQUVmLElBQUksSUFBSSxJQUFJO0dBQ1IsVUFBVSxpQkFBaUIsV0FBVyxJQUFJLGlDQUFpQyx5QkFBeUI7R0FDcEcsSUFBSSxpQkFBaUIsQ0FBQztHQUN0QixNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7R0FDbEMsSUFBSSxLQUFLLE1BQU0sTUFBTSxRQUFRLEtBQUssSUFBSSxHQUFHO0lBQ3JDLElBQUksS0FBSyxLQUFLLFdBQVcsR0FBRztLQUN4QixpQkFBaUIsQ0FBQztJQUN0QixPQUFPO0tBQ0gsaUJBQWlCLEtBQUssS0FBSyxLQUFLLEdBQUcsTUFBTTtNQUNyQyxNQUFNLG9CQUFvQix5QkFBeUIsQ0FBQztNQUNwRCxPQUFPO09BQ0gsR0FBRztPQUNILEtBQUssVUFBVSxFQUFFLEVBQUUsT0FBTyxLQUFLLEVBQUU7T0FDakMsWUFBWSxVQUFVLEVBQUUsRUFBRSxlQUFlLGtCQUFrQixNQUFLLE1BQUssRUFBRSxjQUFjLElBQUksS0FBSyxDQUFDLEVBQUUsRUFBRSxpQkFBaUIsRUFBRSxjQUFjLEtBQUs7T0FDekksUUFBUSxFQUFFLFVBQVU7T0FDcEIsU0FBUztNQUNiO0tBQ0osQ0FBQztJQUNMO0lBQ0EsYUFBYSxjQUFjOztJQUUzQixNQUFNLFlBQVksTUFBTSxZQUFZLEVBQUU7SUFDdEMsSUFBSSxVQUFVLE1BQU0sVUFBVSxNQUFNLFFBQVEsVUFBVSxJQUFJO0dBQzlELE9BQU87SUFDSCxpQkFBaUI7R0FDckI7R0FFQSxZQUFZLFFBQVEsWUFBWSwyQkFBMkIsY0FBYztHQUN6RSxNQUFNLFNBQVMsMEJBQTBCLFFBQVEsTUFBTSxZQUFZLFFBQVE7R0FDM0UsV0FBVyxNQUFNO0dBQ2pCLE9BQU87RUFDWCxPQUFPO0dBQ0gsVUFBVSxJQUFJLFdBQVcseUJBQXlCLE9BQU87R0FDekQsT0FBTztFQUNYO0NBQ0o7Q0FFQSxNQUFNLGdDQUFnQztFQUNsQyxJQUFJLFVBQVUsV0FBVyxHQUFHO0VBQzVCLGdCQUFnQjtHQUNaLFFBQVE7R0FDUixPQUFPO0dBQ1AsU0FBUztHQUNULFNBQVM7R0FDVCxpQkFBaUI7SUFDYixZQUFZLFNBQVM7SUFDckIsYUFBYSxDQUFDLENBQUM7SUFDZixVQUFVLHlFQUF5RSxTQUFTO0lBQzVGLGlCQUFnQixVQUFTO0tBQUUsR0FBRztLQUFNLFFBQVE7SUFBTSxFQUFFO0dBQ3hEO0VBQ0osQ0FBQztDQUNMO0NBRUEsTUFBTSxxQkFBcUIsWUFBWTtFQUNuQyxVQUFVLElBQUk7RUFDZCxJQUFJLFNBQVMsa0JBQWtCLFNBQVMsbUJBQW1CLEtBQUssVUFBVTtHQUN0RSxNQUFNLFVBQVUsTUFBTSxXQUFXLElBQUk7SUFDakMsT0FBTyxLQUFLO0lBQ1osYUFBYSxLQUFLO0lBQ2xCLFVBQVUsU0FBUztHQUN2QixDQUFDO0dBQ0QsSUFBSSxDQUFDLFFBQVEsSUFBSTtJQUNiLFVBQVUsUUFBUSxXQUFXLDBDQUEwQyxPQUFPO0lBQzlFLFVBQVUsS0FBSztJQUNmLE9BQU87R0FDWDtHQUNBLFNBQVEsVUFBUztJQUFFLEdBQUc7SUFBTSxVQUFVLFNBQVM7R0FBZSxFQUFFO0VBQ3BFO0VBRUEsTUFBTSxjQUFjLFNBQVMsU0FBUyxlQUFlLEVBQUU7RUFDdkQsTUFBTSxhQUFhLENBQUMsTUFBTSxXQUFXLEtBQUssY0FBYyxJQUFJLGNBQWMsS0FBSztFQUUvRSxNQUFNLE1BQU0sTUFBTSxtQkFBbUIsSUFBSTtHQUNyQyxZQUFZLFNBQVMsU0FBUyxZQUFZLEVBQUUsS0FBSztHQUNqRCxXQUFXLENBQUMsQ0FBQyxTQUFTO0dBQ3RCLG9CQUFvQixDQUFDLENBQUMsU0FBUztHQUMvQixhQUFhLENBQUMsQ0FBQyxTQUFTO0dBQ3hCLGVBQWUsQ0FBQyxDQUFDLFNBQVM7R0FDMUIsV0FBVyxTQUFTLFlBQVksU0FBUyxVQUFVLEtBQUssSUFBSTtHQUM1RCxlQUFlO0dBQ2YsY0FBYyxTQUFTLGVBQWUsSUFBSSxLQUFLLFNBQVMsWUFBWSxDQUFDLENBQUMsWUFBWSxJQUFJO0dBQ3RGLGVBQWUsU0FBUyxnQkFBZ0IsSUFBSSxLQUFLLFNBQVMsYUFBYSxDQUFDLENBQUMsWUFBWSxJQUFJO0dBQ3pGLFlBQVksQ0FBQyxDQUFDLFNBQVM7R0FDdkIsa0JBQWtCLENBQUMsQ0FBQyxTQUFTO0dBQzdCLGlCQUFpQixDQUFDLENBQUMsU0FBUztHQUM1Qix1QkFBdUIsQ0FBQyxDQUFDLFNBQVM7R0FDbEMsY0FBYyxTQUFTLGVBQWUsU0FBUyxTQUFTLGNBQWMsRUFBRSxJQUFJO0dBQzVFLG1CQUFtQixTQUFTLHFCQUFxQjtHQUNqRCxzQkFBc0IsU0FBUyx3QkFBd0I7RUFDM0QsQ0FBQztFQUVELFVBQVUsS0FBSztFQUVmLElBQUksSUFBSSxJQUFJO0dBQ1IsSUFBSSxlQUFlLEVBQUUsR0FBRyxTQUFTO0dBQ2pDLE1BQU0sWUFBWSxNQUFNLFlBQVksRUFBRTtHQUN0QyxJQUFJLFVBQVUsTUFBTSxVQUFVLE1BQU07SUFDaEMsTUFBTSxJQUFJLFVBQVU7SUFDcEIsUUFBUSxDQUFDO0lBQ1QsTUFBTSxJQUFJLEVBQUUsWUFBWSxDQUFDO0lBQ3pCLGVBQWU7S0FDWCxZQUFZLEVBQUUsY0FBYztLQUM1QixXQUFXLEVBQUUsYUFBYTtLQUMxQixvQkFBb0IsRUFBRSxzQkFBc0I7S0FDNUMsYUFBYSxFQUFFLGVBQWU7S0FDOUIsZUFBZSxFQUFFLGlCQUFpQjtLQUNsQyxXQUFXLEVBQUUsYUFBYTtLQUMxQixlQUFlLEVBQUUsZ0JBQWdCLEtBQUssTUFBTSxFQUFFLGdCQUFnQixFQUFFLElBQUk7S0FDcEUsY0FBYyxxQkFBcUIsRUFBRSxZQUFZO0tBQ2pELGVBQWUscUJBQXFCLEVBQUUsYUFBYTtLQUNuRCxnQkFBZ0IsRUFBRSxZQUFZO0tBQzlCLFlBQVksRUFBRSxjQUFjO0tBQzVCLGtCQUFrQixFQUFFLG9CQUFvQjtLQUN4QyxpQkFBaUIsRUFBRSxtQkFBbUI7S0FDdEMsdUJBQXVCLEVBQUUseUJBQXlCO0tBQ2xELGNBQWMsRUFBRSxnQkFBZ0I7S0FDaEMsbUJBQW1CLEVBQUUscUJBQXFCO0tBQzFDLHNCQUFzQixFQUFFLHdCQUF3QjtJQUNwRDtJQUNBLFlBQVksWUFBWTtHQUM1QjtHQUVBLFlBQVksUUFBUSxXQUFXLDBCQUEwQixZQUFZO0dBQ3JFLE1BQU0sU0FBUywyQkFBMkIsU0FBUyxNQUFNLFlBQVksUUFBUTtHQUM3RSxXQUFXLE1BQU07R0FDakIsVUFBVSx3Q0FBd0M7R0FDbEQsT0FBTztFQUNYLE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyw4QkFBOEIsT0FBTztHQUM5RCxPQUFPO0VBQ1g7Q0FDSjs7Q0FHQSxNQUFNLGdCQUFnQixZQUFZO0VBQzlCLE1BQU0sU0FBUywyQkFBMkIsU0FBUyxNQUFNLFlBQVksUUFBUTtFQUM3RSxNQUFNLFNBQVMsMEJBQTBCLFFBQVEsTUFBTSxZQUFZLFFBQVE7RUFFM0UsSUFBSSxNQUFNO0VBQ1YsSUFBSSxNQUFNO0VBRVYsSUFBSSxVQUFVLGNBQWMsYUFBYTtHQUNyQyxNQUFNLE1BQU0sb0JBQW9CO0VBQ3BDO0VBRUEsSUFBSSxVQUFVLGNBQWMsWUFBWTtHQUNwQyxNQUFNLE1BQU0sbUJBQW1CO0VBQ25DO0VBRUEsT0FBTyxPQUFPO0NBQ2xCO0NBRUEsTUFBTSxzQkFBc0IsWUFBWTtFQUNwQyxjQUFjLElBQUk7RUFDbEIsTUFBTSxNQUFNLE1BQU0sa0JBQWtCLEVBQUU7RUFDdEMsSUFBSSxJQUFJLElBQUk7R0FDUixNQUFNLFVBQVUsTUFBTSxZQUFZLEVBQUU7R0FDcEMsSUFBSSxRQUFRLElBQUksUUFBUSxRQUFRLElBQUk7R0FDcEMsVUFBVSxJQUFJLFdBQVcsNENBQTRDO0VBQ3pFLE9BQU87R0FDSCxVQUFVLElBQUksV0FBVyxtQ0FBbUMsT0FBTztFQUN2RTtFQUNBLGNBQWMsS0FBSztDQUN2QjtDQUVBLE1BQU0sa0JBQWtCLFlBQVksWUFBWTtFQUM1QyxNQUFNLE1BQU0sTUFBTSxhQUFhLEVBQUU7RUFDakMsSUFBSSxJQUFJLElBQUk7R0FDUixhQUFhLElBQUksSUFBSTtHQUNyQixNQUFNLFFBQVEsYUFBYSxRQUFRLE9BQU87R0FDMUMsTUFBTSxRQUFRLE1BQU0sTUFDaEIsR0FBRyxhQUFhLGFBQWEsR0FBRyx3QkFBd0IsbUJBQW1CLGlCQUFpQixLQUM1RixFQUFFLFNBQVMsRUFBRSxlQUFlLFVBQVUsUUFBUSxFQUFFLENBQ3BEO0dBQ0EsSUFBSSxNQUFNLElBQUk7SUFDVixNQUFNLE9BQU8sTUFBTSxNQUFNLEtBQUs7SUFDOUIsYUFBYSxJQUFJLGdCQUFnQixJQUFJLENBQUM7R0FDMUM7RUFDSjtDQUNKLEdBQUcsQ0FBQyxFQUFFLENBQUM7Q0FFUCxNQUFNLHFCQUFxQixPQUFPLE1BQU07RUFDcEMsTUFBTSxPQUFPLEVBQUUsT0FBTyxRQUFRO0VBQzlCLElBQUksQ0FBQyxNQUFNO0VBQ1gsTUFBTSxNQUFNLE1BQU0saUJBQWlCLElBQUksSUFBSTtFQUMzQyxJQUFJLElBQUksSUFBSTtHQUNSLE1BQU0sVUFBVSxNQUFNLFlBQVksRUFBRTtHQUNwQyxJQUFJLFFBQVEsSUFBSSxRQUFRLFFBQVEsSUFBSTtHQUNwQyxVQUFVLG9DQUFvQztFQUNsRCxPQUFPO0dBQ0gsVUFBVSxJQUFJLFdBQVcsMkJBQTJCLE9BQU87RUFDL0Q7Q0FDSjs7Q0FHQSxNQUFNLHVCQUF1QixPQUFPLE9BQU8sQ0FBQyxNQUFNO0VBQzlDLE1BQU0sT0FBTyxNQUFNLGVBQWU7R0FBRSxNQUFNO0dBQUcsWUFBWTtHQUFNLEdBQUc7RUFBSyxDQUFDO0VBQ3hFLElBQUksUUFBUSxNQUFNO0VBQ2xCLElBQUksUUFBUSxDQUFDO0VBQ2IsSUFBSSxNQUFNLFFBQVEsSUFBSSxLQUFLLEtBQUssU0FBUyxHQUFHO0dBQ3hDLFFBQVEsS0FBSyxLQUFLLEdBQUcsTUFBTTtJQUN2QixNQUFNLG9CQUFvQix5QkFBeUIsQ0FBQztJQUNwRCxNQUFNLG1CQUFtQixrQkFBa0IsTUFBSyxNQUFLLEVBQUUsY0FBYyxJQUFJO0lBQ3pFLE1BQU0sbUJBQW1CLENBQUMsRUFBRSxFQUFFLGlCQUFpQixFQUFFLGNBQWMsS0FBSztJQUNwRSxNQUFNLGFBQWEsRUFBRSxlQUFlLFlBQVksRUFBRSxhQUFjLG9CQUFvQjtJQUNwRixPQUFPO0tBQ0gsR0FBRztLQUNILEtBQUssS0FBSyxFQUFFO0tBQ1osVUFBVSxFQUFFLFlBQVk7S0FDeEIsUUFBUSxFQUFFLFVBQVU7S0FDcEIsZUFBZSxFQUFFLGlCQUFpQixJQUFJO0tBQ3RDLFlBQVksRUFBRSxjQUFjO0tBQ2hCO0tBQ1osZUFBZSxFQUFFLGlCQUFpQjtLQUNsQyxlQUFlLEVBQUUsaUJBQWlCO0tBQ2xDLGVBQWUsRUFBRSxpQkFBaUI7S0FDbEMsU0FBUztJQUNiO0dBQ0osQ0FBQztFQUNMLE9BQU8sSUFBSSxDQUFDLEtBQUssVUFBVSxLQUFLLFdBQVcsSUFBSTtHQUMzQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7R0FDdkIsa0JBQWtCLENBQUM7RUFDdkI7RUFDQSxhQUFhLEtBQUs7RUFDbEIsWUFBWSxLQUFLO0NBQ3JCOztDQUdBLE1BQU0sbUJBQW1CLE9BQU8sT0FBTyxDQUFDLE1BQU07RUFDMUMsVUFBVSxzQkFBc0IsS0FBSyxpQkFBaUIsRUFBRSxPQUFPO0VBQy9ELE1BQU0sV0FBVyxNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUM7RUFDbkUsSUFBSSxTQUFTLFdBQVcsR0FBRztFQUMzQixZQUFZLFNBQVM7RUFDckIsTUFBTSxTQUFTLFNBQVMsS0FBSyxHQUFHLFVBQVU7R0FDdEMsTUFBTSxvQkFBb0IseUJBQXlCLENBQUM7R0FDcEQsT0FBTztJQUNILEdBQUc7SUFDSCxJQUFJO0lBQ0osS0FBSyxZQUFZLEtBQUssSUFBSSxFQUFFLEdBQUc7SUFDL0IsZUFBZSxVQUFVLFNBQVMsUUFBUTtJQUMxQyxVQUFVLEVBQUUsWUFBWSxFQUFFLGdCQUFnQjtJQUMxQyxRQUFRLFNBQVMsRUFBRSxRQUFRLEVBQUUsS0FBSztJQUNsQyxZQUFZLEVBQUUsY0FBYztJQUM1QixZQUFZLEVBQUUsZUFBZSxrQkFBa0IsTUFBSyxNQUFLLEVBQUUsU0FBUyxLQUFLLFFBQVEsRUFBRSxhQUFhO0lBQ2hHLFNBQVM7R0FDYjtFQUNKLENBQUM7RUFDRCxjQUFhLFNBQVEsQ0FBQyxHQUFHLE1BQU0sR0FBRyxNQUFNLENBQUM7Q0FDN0M7Ozs7O0NBTUEsTUFBTSx3QkFBd0IsUUFBUTtFQUNsQyxNQUFNLE9BQU8sVUFBVSxRQUFRLEdBQUcsTUFBTSxNQUFNLEdBQUc7RUFDakQsWUFBWSxTQUFTO0VBQ3JCLGFBQWEsSUFBSTtFQUNqQixVQUFVLG1FQUFtRSxTQUFTO0NBQzFGOztDQUdBLE1BQU0sMkJBQTJCLFFBQVE7RUFDckMsTUFBTSxPQUFPLFVBQVU7RUFDdkIsTUFBTSxPQUFPO0dBQ1QsR0FBRyxLQUFLLE1BQU0sS0FBSyxVQUFVLElBQUksQ0FBQztHQUNsQyxLQUFLLFNBQVMsS0FBSyxJQUFJO0dBQ3ZCLElBQUk7RUFDUjs7RUFFQSxZQUFZLFNBQVM7RUFDckIsY0FBYSxTQUFRO0dBQ2pCLE1BQU0sT0FBTyxDQUFDLEdBQUcsSUFBSTtHQUNyQixLQUFLLE9BQU8sTUFBTSxHQUFHLEdBQUcsSUFBSTtHQUM1QixPQUFPO0VBQ1gsQ0FBQztFQUNELFVBQVUsMkJBQTJCO0NBQ3pDOztDQUdBLE1BQU0sOEJBQThCO0VBQ2hDLElBQUksVUFBVSxXQUFXLEdBQUc7R0FBRSxVQUFVLGtDQUFrQyxPQUFPO0dBQUc7RUFBUTtFQUM1RixNQUFNLE9BQU8sQ0FDVDtHQUFDO0dBQVk7R0FBVztHQUFTO0dBQWU7R0FBa0I7RUFBUyxDQUMvRTtFQUNBLFVBQVUsU0FBUyxHQUFHLE1BQU07R0FDeEIsTUFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLEVBQUUsV0FBVztHQUNoRCxNQUFNLGNBQWMsRUFBRSxXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUksTUFBTSxFQUFFLFlBQVksV0FBVyxFQUFFLGVBQWUsRUFBRSxVQUFXLENBQUMsQ0FBQyxLQUFLLEdBQUc7R0FDaEgsTUFBTSxVQUFVLEVBQUUsWUFBWSxHQUFFLENBQUUsUUFBUSxZQUFZLEVBQUUsQ0FBQyxDQUFDLFFBQVEsUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLO0dBQ3BGLE1BQU0sWUFBWSxZQUNYLEVBQUUsV0FBVyxDQUFDLEVBQUMsQ0FBRSxRQUFPLE1BQUssRUFBRSxTQUFTLENBQUMsQ0FBQyxLQUFJLE1BQUssRUFBRSxVQUFVLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFDekUsRUFBRSxpQkFBaUI7R0FDMUIsS0FBSyxLQUFLO0lBQ04sSUFBSSxPQUFPLFFBQVEsTUFBTSxNQUFJLEVBQUU7SUFDL0IsRUFBRSxVQUFVO0lBQ1osSUFBSTtJQUNKLEVBQUUsYUFBYSxTQUFTO0lBQ3hCLEtBQUssYUFBYSxHQUFFLENBQUUsUUFBUSxNQUFNLE1BQUksRUFBRTtJQUMxQyxJQUFJLFdBQVcsUUFBUSxNQUFNLE1BQUksRUFBRTtHQUN2QyxDQUFDO0VBQ0wsQ0FBQztFQUNELE1BQU0sTUFBTSxNQUFXLEtBQUssS0FBSSxNQUFLLEVBQUUsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTTtFQUM3RCxNQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztFQUNoRSxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtFQUNwQyxNQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7RUFDcEMsRUFBRSxPQUFPO0VBQ1QsRUFBRSxXQUFXLFNBQVMsTUFBTSxTQUFTLFdBQVUsQ0FBRSxRQUFRLFFBQVEsR0FBRyxFQUFFLEdBQUcsS0FBSyxJQUFJLEVBQUU7RUFDcEYsU0FBUyxLQUFLLFlBQVksQ0FBQztFQUMzQixFQUFFLE1BQU07RUFDUixTQUFTLEtBQUssWUFBWSxDQUFDO0VBQzNCLElBQUksZ0JBQWdCLEdBQUc7RUFDdkIsVUFBVSxpQ0FBaUM7Q0FDL0M7O0NBR0EsTUFBTSxpQkFBaUIsT0FBTyxRQUFRO0VBQ2xDLE1BQU0sSUFBSSxVQUFVO0VBQ3BCLElBQUksQ0FBQyxvQkFBb0IsS0FBSyxHQUFHO0dBQUUsaUJBQWlCLDRCQUE0QjtHQUFHO0VBQVE7RUFDM0YsY0FBYyxJQUFJO0VBQ2xCLGlCQUFpQixFQUFFO0VBQ25CLElBQUk7R0FDQSxNQUFNLE1BQU0sTUFBTSxxQkFBcUI7SUFDbkMsVUFBVSxFQUFFO0lBQ1osU0FBUyxFQUFFLFdBQVcsQ0FBQztJQUN2QixlQUFlLEVBQUU7SUFDakIsUUFBUSxFQUFFO0lBQ1YsWUFBWSxFQUFFO0lBQ2QsWUFBWSxFQUFFO0lBQ2QsYUFBYTtJQUNiLGVBQWU7SUFDZixjQUFjLGdCQUFnQjtHQUNsQyxDQUFDO0dBRUQsSUFBSSxDQUFDLElBQUksSUFBSTtJQUNULGlCQUFpQixJQUFJLFdBQVcsc0JBQXNCO0lBQ3REO0dBQ0o7R0FFQSxNQUFNLFVBQVUsSUFBSTtHQUNwQixlQUFlLEtBQUssWUFBWSxRQUFRLFlBQVksRUFBRSxRQUFRO0dBQzlELElBQUksUUFBUSxXQUFXLFFBQVEsUUFBUSxTQUFTLEdBQUc7SUFDL0MsY0FBYSxTQUFRLEtBQUssS0FBSyxJQUFJLE9BQU8sT0FBTyxNQUFNO0tBQUUsR0FBRztLQUFJLFVBQVUsUUFBUSxZQUFZLEdBQUc7S0FBVSxTQUFTLFFBQVE7S0FBUyxlQUFlLFFBQVEsaUJBQWlCLEdBQUc7SUFBYyxJQUFJLEVBQUUsQ0FBQztHQUN6TSxPQUFPO0lBQ0gsZUFBZSxLQUFLLGlCQUFpQixRQUFRLGlCQUFpQixFQUFFLGFBQWE7R0FDakY7R0FDQSxtQkFBbUIsSUFBSTtHQUN2Qix1QkFBdUIsRUFBRTtHQUN6QixVQUFVLGlDQUFpQztFQUMvQyxTQUFTLEtBQUs7R0FDVixpQkFBaUIsMEJBQTBCLElBQUksT0FBTztFQUMxRCxVQUFVO0dBQ04sY0FBYyxLQUFLO0VBQ3ZCO0NBQ0o7O0NBR0EsTUFBTSxxQkFBcUIsWUFBWTtFQUNuQyxJQUFJLENBQUMsc0JBQXNCLEtBQUssR0FBRztHQUFFLFVBQVUsOEJBQThCLE9BQU87R0FBRztFQUFRO0VBQy9GLElBQUksbUJBQW1CLFNBQVMsR0FBRztHQUFFLFVBQVUsd0NBQXdDLE9BQU87R0FBRztFQUFRO0VBQ3pHLGdCQUFnQixJQUFJO0VBQ3BCLElBQUk7R0FDQSxNQUFNLE1BQU0sTUFBTSwwQkFBMEI7SUFDeEM7SUFDQSxpQkFBaUIsTUFBTSxLQUFLLGtCQUFrQjtJQUM5QyxhQUFhO0lBQ2IsZUFBZTtJQUNmLGNBQWMsZ0JBQWdCO0dBQ2xDLENBQUM7R0FFRCxJQUFJLENBQUMsSUFBSSxJQUFJO0lBQ1QsVUFBVSxJQUFJLFdBQVcsK0JBQStCLE9BQU87SUFDL0Q7R0FDSjtHQUVBLE1BQU0sVUFBVSxJQUFJLFFBQVEsQ0FBQztHQUM3QixJQUFJLFFBQVEsU0FBUyxHQUFHO0lBQ3BCLHFCQUFxQixPQUFPO0lBQzVCLHlCQUF5QixJQUFJO0dBQ2pDLE9BQU87SUFDSCxVQUFVLDBDQUEwQyxPQUFPO0dBQy9EO0VBQ0osU0FBUyxLQUFLO0dBQ1YsVUFBVSxxQkFBcUIsSUFBSSxTQUFTLE9BQU87RUFDdkQsVUFBVTtHQUNOLGdCQUFnQixLQUFLO0VBQ3pCO0NBQ0o7Q0FFQSxNQUFNLHVCQUF1QixLQUFLLFlBQVk7RUFDMUMsY0FBYSxTQUFRLEtBQUssS0FBSyxHQUFHLE9BQU8sT0FBTyxNQUFNO0dBQUUsR0FBRztHQUFHLFVBQVUsUUFBUSxZQUFZLEVBQUU7R0FBVSxTQUFTLFFBQVEsU0FBUyxTQUFTLElBQUksUUFBUSxVQUFVLEVBQUU7R0FBUyxlQUFlLFFBQVEsaUJBQWlCLEVBQUU7RUFBYyxJQUFJLENBQUMsQ0FBQztDQUM5Tzs7Q0FHQSxNQUFNLHVCQUF1QixPQUFPLFFBQVE7RUFDeEMsSUFBSSxXQUFXLFVBQVU7RUFDekIsSUFBSSxDQUFDLFNBQVMsSUFBSTtHQUNkLE1BQU0sVUFBVSxNQUFNLG9CQUFvQjtHQUMxQyxJQUFJLENBQUMsU0FBUyxPQUFPO0dBQ3JCLE1BQU0sY0FBYyxNQUFNLGFBQWEsRUFBRTtHQUN6QyxJQUFJLFlBQVksTUFBTSxNQUFNLFFBQVEsWUFBWSxJQUFJLEtBQUssWUFBWSxLQUFLLE1BQU07SUFDNUUsT0FBTyxZQUFZLEtBQUssSUFBSSxDQUFDO0dBQ2pDO0VBQ0o7RUFDQSxPQUFPLFNBQVM7Q0FDcEI7O0NBR0osTUFBTSxvQkFBb0IsT0FBTyxLQUFLLFNBQVM7RUFDM0MsTUFBTSxhQUFhLFVBQVUsSUFBSSxFQUFFLFVBQVU7RUFDN0MsSUFBSSxVQUFVLElBQUksRUFBRSxNQUFNLFlBQVksSUFBSTtHQUN0QyxPQUFPO0lBQUUsWUFBWSxVQUFVLElBQUksQ0FBQztJQUFJLFVBQVUsV0FBVztHQUFHO0VBQ3BFOztFQUVBLE1BQU0sVUFBVSxNQUFNLG9CQUFvQjtFQUMxQyxJQUFJLENBQUMsU0FBUyxPQUFPO0VBRXJCLE1BQU0sY0FBYyxNQUFNLGFBQWEsRUFBRTtFQUN6QyxJQUFJLFlBQVksTUFBTSxNQUFNLFFBQVEsWUFBWSxJQUFJLEdBQUc7R0FDbkQsTUFBTSxTQUFTLFlBQVksS0FBSztHQUNoQyxNQUFNLFdBQVcsUUFBUSxVQUFVLFNBQVMsUUFBUSxrQkFBa0I7R0FDdEUsSUFBSSxRQUFRLE1BQU0sVUFBVSxJQUFJO0lBQzVCLE9BQU87S0FBRSxZQUFZLE9BQU87S0FBSSxVQUFVLFNBQVM7SUFBRztHQUMxRDtFQUNKO0VBQ0EsT0FBTztDQUNYO0NBRUksTUFBTSw0QkFBNEIsT0FBTyxLQUFLLFNBQVM7RUFDbkQsSUFBSTtHQUNBLE1BQU0sdUJBQXVCLEtBQUssTUFBTSxLQUFLLFVBQVUsYUFBYSxPQUFPLENBQUM7R0FDNUUsTUFBTSxNQUFNLE1BQU0scUJBQXFCLEdBQUc7R0FDMUMsSUFBSSxDQUFDLEtBQUs7SUFBRSxVQUFVLGtEQUFrRCxPQUFPO0lBQUc7R0FBUTtHQUUxRixNQUFNLE1BQU0sTUFBTSxvQkFBb0IsSUFBSSxLQUFLLE9BQU8sUUFBUTtJQUMxRCxtQkFBa0IsVUFBUztLQUFFLEdBQUc7TUFBTyxNQUFNO0lBQUksRUFBRTtHQUN2RCxDQUFDO0dBQ0QsSUFBSSxJQUFJLElBQUk7SUFDUixZQUFZLG9CQUFvQjtJQUNoQyxlQUFlLEtBQUssaUJBQWlCLElBQUksTUFBTSxpQkFBaUIsSUFBSTtJQUNwRSxVQUFVLGdDQUFnQztHQUM5QyxPQUFPO0lBQ0gsVUFBVSxJQUFJLFdBQVcsMkJBQTJCLE9BQU87R0FDL0Q7RUFDSixTQUFTLEtBQUs7R0FDVixRQUFRLE1BQU0seUJBQXlCLEdBQUc7R0FDMUMsVUFBVSw0Q0FBNEMsT0FBTztFQUNqRSxVQUFVO0dBQ04sbUJBQWtCLFVBQVM7SUFBRSxHQUFHO0tBQU8sTUFBTTtHQUFLLEVBQUU7RUFDeEQ7Q0FDSjtDQUVBLE1BQU0sNEJBQTRCLE9BQU8sS0FBSyxTQUFTO0VBQ25ELElBQUk7R0FDQSxNQUFNLHVCQUF1QixLQUFLLE1BQU0sS0FBSyxVQUFVLGFBQWEsT0FBTyxDQUFDO0dBQzVFLE1BQU0sTUFBTSxNQUFNLHFCQUFxQixHQUFHO0dBQzFDLElBQUksQ0FBQyxLQUFLO0lBQUUsVUFBVSxpREFBaUQsT0FBTztJQUFHO0dBQVE7R0FFekYsTUFBTSxNQUFNLE1BQU0sb0JBQW9CLElBQUksS0FBSyxPQUFPLFFBQVE7SUFDMUQsbUJBQWtCLFVBQVM7S0FBRSxHQUFHO01BQU8sTUFBTTtJQUFJLEVBQUU7R0FDdkQsQ0FBQztHQUNELElBQUksSUFBSSxJQUFJO0lBQ1IsWUFBWSxvQkFBb0I7SUFDaEMsZUFBZSxLQUFLLGlCQUFpQixJQUFJLE1BQU0saUJBQWlCLElBQUk7SUFDcEUsVUFBVSwrQkFBK0I7R0FDN0MsT0FBTztJQUNILFVBQVUsSUFBSSxXQUFXLDBCQUEwQixPQUFPO0dBQzlEO0VBQ0osU0FBUyxLQUFLO0dBQ1YsUUFBUSxNQUFNLHlCQUF5QixHQUFHO0dBQzFDLFVBQVUsMkNBQTJDLE9BQU87RUFDaEUsVUFBVTtHQUNOLG1CQUFrQixVQUFTO0lBQUUsR0FBRztLQUFPLE1BQU07R0FBSyxFQUFFO0VBQ3hEO0NBQ0o7Q0FFSSxNQUFNLDZCQUE2QixRQUFRO0VBQzNDLFlBQVksU0FBUztFQUNyQixlQUFlLEtBQUssaUJBQWlCLElBQUk7Q0FDN0M7Q0FFQSxNQUFNLDZCQUE2QixRQUFRO0VBQ3ZDLFlBQVksU0FBUztFQUNyQixlQUFlLEtBQUssaUJBQWlCLElBQUk7Q0FDN0M7Q0FFQSxNQUFNLG9CQUFvQjs7RUFFdEIsWUFBWSxTQUFTO0VBQ3JCLGNBQWEsU0FBUSxDQUFDLEdBQUcsTUFBTSxZQUFZLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztDQUNoRTtDQUVBLE1BQU0sd0JBQXdCLDBCQUEwQjtFQUNwRCxJQUFJLENBQUMseUJBQXlCLHNCQUFzQixXQUFXLEdBQUc7RUFDbEUsY0FBYSxTQUFRO0dBQ2pCLE1BQU0sYUFBYSxLQUFLLFNBQVM7R0FDakMsTUFBTSxTQUFTLHNCQUFzQixLQUFLLEdBQUcsU0FBUztJQUNsRCxHQUFHO0lBQ0gsS0FBSyxRQUFRLEtBQUssSUFBSSxFQUFFLEdBQUc7SUFDM0IsZUFBZSxhQUFhO0dBQ2hDLEVBQUU7R0FDRixPQUFPLENBQUMsR0FBRyxNQUFNLEdBQUcsTUFBTTtFQUM5QixDQUFDO0VBQ0QsVUFBVSx3QkFBd0Isc0JBQXNCLE9BQU8sdUJBQXVCLFNBQVM7Q0FDbkc7Q0FFQSxNQUFNLGdCQUFnQixLQUFLLFFBQVE7O0VBRS9CLFlBQVksU0FBUztFQUNyQixjQUFhLFNBQVE7R0FDakIsTUFBTSxNQUFNLENBQUMsR0FBRyxJQUFJO0dBQ3BCLE1BQU0sU0FBUyxNQUFNO0dBQ3JCLElBQUksU0FBUyxLQUFLLFVBQVUsSUFBSSxRQUFRLE9BQU87R0FDL0MsQ0FBQyxJQUFJLE1BQU0sSUFBSSxXQUFXLENBQUMsSUFBSSxTQUFTLElBQUksSUFBSTtHQUNoRCxPQUFPO0VBQ1gsQ0FBQztDQUNMO0NBRUEsTUFBTSxrQkFBa0IsS0FBSyxPQUFPLFVBQVU7Ozs7O0VBSzFDLE1BQU0sY0FBYyxDQUFDLFlBQVksZUFBZSxDQUFDLENBQUMsU0FBUyxLQUFLO0VBQ2hFLElBQUksYUFBYTtHQUNiLElBQUksb0JBQW9CLFNBQVMsYUFBYSxvQkFBb0IsT0FBTzs7OztHQUl6RSxNQUFNLHdCQUF3QixLQUFLLE1BQU0sS0FBSyxVQUFVLFNBQVMsQ0FBQztHQUNsRSxvQkFBb0IsVUFBVSxpQkFBaUI7SUFDM0MsSUFBSSxDQUFDLG1CQUFtQixTQUFTO0tBQzdCLFlBQVkscUJBQXFCO0lBQ3JDO0lBQ0Esb0JBQW9CLFVBQVU7R0FDbEMsR0FBRyxHQUFHO0VBQ1Y7RUFDQSxjQUFhLFNBQVEsS0FBSyxLQUFLLEdBQUcsTUFBTSxNQUFNLE1BQU07R0FBRSxHQUFHO0lBQUksUUFBUTtFQUFNLElBQUksQ0FBQyxDQUFDO0NBQ3JGO0NBRUEsTUFBTSxtQkFBbUIsTUFBTSxNQUFNLGFBQWEsWUFBWSxPQUFPLFNBQVM7RUFDMUUsZUFBZTtHQUFFLE1BQU07R0FBWTtHQUFNO0VBQUssQ0FBQztFQUMvQyxhQUFhLElBQUk7RUFDakIsYUFBYSxJQUFJO0NBQ3JCO0NBRUEsTUFBTSx5QkFBeUIsZ0JBQWdCO0VBQzNDLE1BQU0sRUFBRSxNQUFNLE1BQU0sU0FBUztFQUM3QixJQUFJLFNBQVMsTUFBTTtFQUVuQixJQUFJLFNBQVMsWUFBWSxTQUFTLE1BQU07R0FDcEMsTUFBTSxVQUFVLFVBQVUsS0FBSyxFQUFFLFVBQVUsS0FBSyxFQUFFLGNBQWM7R0FDaEUsYUFBYSxNQUFNLE1BQU0sY0FBYyxXQUFXLFVBQVUsTUFBTSxNQUFNLFdBQVc7RUFDdkYsT0FBTztHQUNILE1BQU0sVUFBVSxVQUFVLEtBQUssRUFBRSxZQUFZO0dBQzdDLGVBQWUsTUFBTSxZQUFZLFVBQVUsV0FBVztFQUMxRDtDQUNKO0NBRUEsTUFBTSxpQkFBaUIsUUFBUTtFQUMzQixzQkFBcUIsVUFBUztHQUFFLEdBQUc7SUFBTyxNQUFNLENBQUMsS0FBSztFQUFLLEVBQUU7Q0FDakU7Q0FFQSxNQUFNLGFBQWEsU0FBUztFQUN4QixZQUFZLFNBQVM7RUFDckIsY0FBYSxTQUFRLEtBQUssS0FBSyxHQUFHLE1BQzlCLE1BQU0sT0FBTztHQUFFLEdBQUc7R0FBRyxTQUFTLENBQUMsR0FBRyxFQUFFLFNBQVM7SUFBRSxZQUFZO0lBQUksV0FBVztHQUFNLENBQUM7RUFBRSxJQUFJLENBQzNGLENBQUM7Q0FDTDtDQUVBLE1BQU0sZ0JBQWdCLE1BQU0sU0FBUztFQUNqQyxZQUFZLFNBQVM7RUFDckIsY0FBYSxTQUFRLEtBQUssS0FBSyxHQUFHLE1BQzlCLE1BQU0sT0FBTztHQUFFLEdBQUc7R0FBRyxTQUFTLEVBQUUsUUFBUSxRQUFRLEdBQUcsT0FBTyxPQUFPLElBQUk7RUFBRSxJQUFJLENBQy9FLENBQUM7Q0FDTDtDQUVBLE1BQU0sZ0JBQWdCLE1BQU0sTUFBTSxPQUFPLFFBQVE7O0VBRTdDLElBQUksVUFBVSxjQUFjO0dBQ3hCLElBQUksb0JBQW9CLFNBQVMsYUFBYSxvQkFBb0IsT0FBTztHQUN6RSxNQUFNLHdCQUF3QixLQUFLLE1BQU0sS0FBSyxVQUFVLFNBQVMsQ0FBQztHQUNsRSxvQkFBb0IsVUFBVSxpQkFBaUI7SUFDM0MsSUFBSSxDQUFDLG1CQUFtQixTQUFTO0tBQzdCLFlBQVkscUJBQXFCO0lBQ3JDO0lBQ0Esb0JBQW9CLFVBQVU7R0FDbEMsR0FBRyxHQUFHO0VBQ1Y7RUFDQSxjQUFhLFNBQVEsS0FBSyxLQUFLLEdBQUcsTUFBTTtHQUNwQyxJQUFJLE1BQU0sTUFBTSxPQUFPO0dBQ3ZCLE1BQU0sT0FBTyxFQUFFLFFBQVEsS0FBSyxLQUFLLE9BQU87SUFDcEMsSUFBSSxPQUFPLE1BQU0sT0FBTztJQUN4QixPQUFPO0tBQUUsR0FBRztNQUFNLFFBQVE7SUFBSTtHQUNsQyxDQUFDO0dBQ0QsT0FBTztJQUFFLEdBQUc7SUFBRyxTQUFTO0dBQUs7RUFDakMsQ0FBQyxDQUFDO0NBQ047Q0FFQSxJQUFJLFNBQVM7RUFDVCxPQUNJLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1gsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBeUQ7R0FBNkI7Ozs7O0VBQ2xHOzs7OztDQUViO0NBRUEsTUFBTSxjQUFjLE1BQU0sUUFBUSxZQUFZLE1BQU07Q0FFcEQsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0ksd0JBQUMsU0FBRCxDQUFVOzs7OztHQUVWLHdCQUFDLE9BQUQ7SUFBSyxLQUFLO0lBQWUsV0FBVyxnQ0FBZ0Msa0JBQWtCLGNBQWMsY0FBYyw2QkFBNkI7Y0FBL0k7S0FHSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ3dCLHdCQUFDLFVBQUQ7UUFBUSxlQUFlO1NBQ3ZDLElBQUksU0FBUztVQUNULGdCQUFnQjtXQUNaLFFBQVE7V0FDUixPQUFPO1dBQ1AsU0FBUztXQUNULFNBQVM7V0FDVCxhQUFhO1dBQ2IsaUJBQWlCO1lBQ2IsaUJBQWdCLFVBQVM7YUFBRSxHQUFHO2FBQU0sUUFBUTtZQUFNLEVBQUU7WUFDcEQsU0FBUyxXQUFXO1dBQ3hCO1VBQ0osQ0FBQztVQUNEO1NBQ0o7U0FDQSxTQUFTLFdBQVc7UUFDeEI7UUFBRyxXQUFVO2tCQUNULHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O09BQ2xCOzs7O2lCQUNSLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBK0UsTUFBTSxTQUFTO1NBQTJCOzs7O21CQUN2SSx3QkFBQyxRQUFEO1VBQU0sV0FBVyx1REFBdUQsY0FBYyxpSEFBaUg7b0JBQ2xNLGNBQWMsV0FBVztTQUN4Qjs7OztpQkFDTDs7Ozs7a0JBQ0wsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWIsQ0FBd0UsT0FBSSxNQUFNLFFBQVk7Ozs7O2dCQUM3Rjs7Ozs7ZUFDSjs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDSSx3QkFBQyxVQUFEO1NBQ0ksU0FBUztTQUNULFVBQVU7U0FDVixhQUFVO1NBQ1YsV0FBVyxrR0FBa0csY0FBYyx5SUFBeUk7bUJBSnhRLENBTUssY0FBYyx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O29CQUFJLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7bUJBQ3RELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFvQixhQUFhLGlCQUFpQixjQUFjLGlCQUFpQjtTQUFxQjs7OztpQkFDbEg7Ozs7OztRQUdSLHdCQUFDLFVBQUQ7U0FDSSxNQUFLO1NBQ0wsT0FBTTtTQUNOLGFBQVU7U0FDVixlQUFlLE9BQU8sS0FBSyxNQUFNLE1BQU0sU0FBUyx1QkFBdUIsTUFBTSxNQUFNLFFBQVE7U0FDM0YsV0FBVTttQkFMZCxDQU9JLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7bUJBQ2hCLHdCQUFDLFFBQUQsWUFBTSxVQUFhOzs7O2lCQUNmOzs7Ozs7UUFHUix3QkFBQyxVQUFEO1NBQ0ksTUFBSztTQUNMLE9BQU07U0FDTixlQUFlLG1CQUFrQixTQUFRLENBQUMsSUFBSTtTQUM5QyxXQUFXLG1IQUNQLGlCQUNNLHFEQUNBO21CQVBkLENBVUksd0JBQUMsU0FBRCxFQUFTLE1BQU0sR0FBSzs7OzttQkFDcEIsd0JBQUMsUUFBRCxhQUFNLGNBQVcsaUJBQWlCLE9BQU8sS0FBWTs7OztpQkFDakQ7Ozs7OztRQUdSLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0ksd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxlQUFlLG9CQUFtQixTQUFRLENBQUMsSUFBSTtVQUMvQyxXQUFXLDZFQUE2RSxrQkFBa0IscUNBQXFDO1VBQy9JLE9BQU07b0JBSlYsQ0FNSyxrQkFBa0Isd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7OztxQkFBSSx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7O29CQUN0RSx3QkFBQyxRQUFELGFBQU0sY0FBVyxrQkFBa0IsT0FBTyxLQUFZOzs7O2tCQUNsRDs7Ozs7bUJBQ1AsbUJBQW1CLHFCQUNoQix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDWDtTQUNDOzs7O2lCQUVUOzs7Ozs7UUFFTCx3QkFBQyxVQUFEO1NBQ0ksU0FBUztTQUNULFVBQVU7U0FDVixhQUFVO1NBQ1YsV0FBVyx5SUFDUCxVQUNNLCtEQUNBO21CQVBkLENBVUksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OzttQkFDakIsd0JBQUMsUUFBRCxZQUFPLFNBQVMsaUJBQWlCLFVBQVUsc0JBQXNCLG1CQUF5Qjs7OztpQkFDdEY7Ozs7OztRQUdSLHdCQUFDLFVBQUQ7U0FDSSxNQUFLO1NBQ0wsZUFBZSxtQkFBbUIsSUFBSTtTQUN0QyxXQUFVO1NBQ1YsT0FBTTttQkFKVixDQU1JLHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7bUJBQ3ZCLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFtQjtTQUFhOzs7O2lCQUM1Qzs7Ozs7O09BQ1A7Ozs7O2NBQ0o7Ozs7OztLQUVKLFNBQ0csd0JBQUMsT0FBRDtNQUFLLFdBQVcseUdBQXlHLE1BQU0sU0FBUyxVQUFVLGVBQWU7Z0JBQzVKLE1BQU07S0FDTjs7Ozs7S0FHUixpQkFDRyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNJLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O09BQUM7T0FBRTtNQUNuQjs7Ozs7O0tBSVQsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBMEYsYUFBVTtnQkFDOUc7T0FDRztRQUFFLEtBQUs7UUFBYSxPQUFPO1FBQXFCLFFBQVE7T0FBZ0I7T0FDeEU7UUFBRSxLQUFLO1FBQVksT0FBTztRQUF1QixRQUFRO09BQWU7T0FDeEU7UUFBRSxLQUFLO1FBQVMsT0FBTztRQUFxQixRQUFRO09BQVk7TUFDcEUsQ0FBQyxDQUFDLEtBQUksTUFDRix3QkFBQyxVQUFEO09BRUksYUFBVyxFQUFFO09BQ2IsZUFBZTtRQUNYLGFBQWEsRUFBRSxHQUFHO1FBQ2xCLElBQUksRUFBRSxRQUFRLFNBQVMsZ0JBQWdCO09BQzNDO09BQ0EsV0FBVyxpR0FBaUcsY0FBYyxFQUFFLE1BQU0sNEVBQTRFO2lCQUU3TSxFQUFFO01BQ0MsR0FUQyxFQUFFOzs7O2FBU0gsQ0FDWDtLQUNBOzs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFXLG1EQUFtRCxrQkFBa0IsY0FBYyxjQUFjLDhFQUE4RTtnQkFBL0w7T0FHSyxjQUFjLGVBQ1gsd0JBQUMsT0FBRDtRQUFLLFdBQVcsaUJBQWlCLGlCQUFpQix5REFBeUQ7a0JBQTNHLENBRUksd0JBQUMsT0FBRDtTQUFLLFdBQVcsMkJBQTJCLGlCQUFpQixpREFBaUQ7bUJBQTdHO1VBRUEsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDthQUFPLFdBQVU7dUJBQWtFO1lBQXFCOzs7O3NCQUN4Ryx3QkFBQyxTQUFEO2FBQ0ksTUFBSzthQUNMLE9BQU8sTUFBTSxTQUFTO2FBQ3RCLFdBQVUsTUFBSyxTQUFRLE9BQU07Y0FBRSxHQUFHO2NBQUcsT0FBTyxFQUFFLE9BQU87YUFBTSxFQUFFO2FBQzdELGNBQWMsV0FBVyxJQUFJO2NBQUUsT0FBTyxLQUFLO2NBQU8sYUFBYSxLQUFLO2FBQVksQ0FBQzthQUNqRixhQUFZO2FBQ1osV0FBVTtZQUNiOzs7O29CQUNBOzs7OztZQUVMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBa0U7WUFBeUI7Ozs7c0JBQzVHLHdCQUFDLHFCQUFEO2FBQ0ksT0FBTyxNQUFNLGVBQWU7YUFDNUIsV0FBVyxZQUFZLFNBQVEsT0FBTTtjQUFFLEdBQUc7Y0FBRyxhQUFhO2FBQVEsRUFBRTthQUNwRSxhQUFZO1lBQ2Y7Ozs7b0JBQ0E7Ozs7O1lBR0wsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDSSx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNLLE1BQU0sZUFDSCx3QkFBQyxPQUFEO2VBQUssS0FBSyxTQUFTLEtBQUssV0FBVztlQUFHLEtBQUk7ZUFBUyxXQUFVO2NBQW1GOzs7O3dCQUVwSix3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFDWCxNQUFNLGNBQWMsNEJBQTRCO2NBQy9DOzs7O3NCQUNMOzs7Ozt1QkFDTCx3QkFBQyxTQUFEO2NBQU8sV0FBVTt3QkFBakI7ZUFDSSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztlQUFDO2VBQUUsTUFBTSxjQUFjLGdCQUFnQjtlQUMxRCx3QkFBQyxTQUFEO2dCQUFPLE1BQUs7Z0JBQU8sUUFBTztnQkFBVSxXQUFVO2dCQUFTLFVBQVU7ZUFBcUI7Ozs7O2NBQ25GOzs7OztxQkFDTjs7Ozs7O1lBR0wsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDSSx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUNYLHdCQUFDLFNBQUQsRUFBUyxNQUFNLEdBQUs7Ozs7O2NBQ25COzs7O3dCQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxLQUFEO2VBQUcsV0FBVTt5QkFBMkU7Y0FBc0I7Ozs7d0JBQzlHLHdCQUFDLEtBQUQ7ZUFBRyxXQUFVO3lCQUFiLENBQXNGLGVBQWMsT0FBUTs7Ozs7c0JBQzNHOzs7O3NCQUNKOzs7Ozt1QkFDTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLEtBQUQ7ZUFBRyxXQUFVO3lCQUFzRjtjQUFjOzs7O3dCQUNqSCx3QkFBQyxLQUFEO2VBQUcsV0FBVTt5QkFBYixDQUNLLGlCQUFpQixJQUFJLGlCQUFpQixVQUFVLFFBQU8sT0FDekQ7Ozs7O3NCQUNGOzs7OztxQkFDSjs7Ozs7O1lBR0wsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FFSSx3QkFBQyxPQUFEO2NBQ0ksV0FBVTtjQUNWLGFBQVU7d0JBRmQsQ0FJSSx3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFBZixDQUNJLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFDWCx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztlQUNwQjs7Ozt5QkFDTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsS0FBRDtnQkFBRyxXQUFVOzBCQUF3RDtlQUVsRTs7Ozt5QkFDSCx3QkFBQyxLQUFEO2dCQUFHLFdBQVU7MEJBQWlEO2VBRTNEOzs7O3VCQUNGOzs7O3VCQUNKOzs7Ozt3QkFDTCx3QkFBQyxVQUFEO2VBQ0ksTUFBSztlQUNMLGVBQWUsZUFBZSxJQUFJO2VBQ2xDLFdBQVU7eUJBSGQsQ0FLSSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7O3lCQUNyQix3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O3VCQUN4Qjs7Ozs7c0JBQ1A7Ozs7O3VCQUdMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQWYsQ0FDSSx3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQTZEO2VBQWU7Ozs7eUJBQzNGO2dCQUFDO2dCQUFPO2dCQUFRO2VBQU0sQ0FBQyxDQUFDLEtBQUksUUFDekIsd0JBQUMsS0FBRDtnQkFFSSxNQUFNLG9CQUFvQixHQUFHO2dCQUM3QjtnQkFDQSxXQUFVOzBCQUpkO2lCQU1JLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O2lCQUFDO2lCQUFHLElBQUksWUFBWTtnQkFDMUM7a0JBTk07Ozs7c0JBTU4sQ0FDTixDQUNBOzs7Ozt3QkFDTCx3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFDWCx3QkFBQyxVQUFEO2dCQUNJLE1BQUs7Z0JBQ0wsZUFBZSxtQkFBbUIsSUFBSTtnQkFDdEMsV0FBVTswQkFIZCxDQUtJLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7MEJBQUMsNEJBQ2hCOzs7Ozs7Y0FDUDs7OztzQkFDSjs7Ozs7cUJBQ0o7Ozs7OztXQUNKOzs7Ozs7VUFHTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQ0ksd0JBQUMsU0FBRDtjQUNJLE1BQUs7Y0FDTCxPQUFPO2NBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7Y0FDN0MsYUFBWTtjQUNaLFdBQVU7YUFDYjs7Ozs7YUFDRCx3QkFBQyxPQUFEO2NBQUssV0FBVTtjQUFrRSxNQUFLO2NBQU8sUUFBTztjQUFlLFNBQVE7Y0FBWSxhQUFZO3dCQUMvSSx3QkFBQyxRQUFEO2VBQU0sZUFBYztlQUFRLGdCQUFlO2VBQVEsR0FBRTtjQUErQzs7Ozs7YUFDbkc7Ozs7O2FBQ0osY0FDRyx3QkFBQyxVQUFEO2NBQ0ksTUFBSztjQUNMLGVBQWU7ZUFBRSxjQUFjLEVBQUU7ZUFBRyxtQkFBbUIsRUFBRTtlQUFHLGVBQWUsQ0FBQztjQUFHO2NBQy9FLFdBQVU7d0JBRVYsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7YUFDVjs7Ozs7WUFFWDs7Ozs7cUJBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ1YsY0FBYyxpQkFBaUIsSUFDNUI7YUFBRTthQUFvQix3QkFBQyxLQUFELFlBQUksWUFBZTs7Ozs7YUFBQzthQUFNLHdCQUFDLEtBQUQsWUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssaUJBQWlCLFFBQVEsQ0FBQyxFQUFLOzs7OzthQUFDO2FBQVU7YUFBZTtZQUFPOzs7O3VCQUUxSSwrQ0FBRSx1REFBc0Q7Ozs7O1dBRTNEOzs7O21CQUNKOzs7Ozs7VUFHTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDVixVQUFVLEtBQUssR0FBRyxRQUNmLHdCQUFDLE9BQUQ7WUFFSSxhQUFXLFFBQVEsSUFBSSwyQkFBMkI7WUFDbEQsV0FBVTtzQkFIZDthQU1JLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQWYsQ0FDSyxrQkFDRyx3QkFBQyxTQUFEO2dCQUNJLE1BQUs7Z0JBQ0wsU0FBUyxtQkFBbUIsSUFBSSxHQUFHO2dCQUNuQyxXQUFVLE1BQUs7aUJBQ1gsdUJBQXNCLFNBQVE7a0JBQzFCLE1BQU0sT0FBTyxJQUFJLElBQUksSUFBSTtrQkFDekIsSUFBSSxFQUFFLE9BQU8sU0FBUyxLQUFLLElBQUksR0FBRzt1QkFBUSxLQUFLLE9BQU8sR0FBRztrQkFDekQsT0FBTztpQkFDWCxDQUFDO2dCQUNMO2dCQUNBLFdBQVU7ZUFDYjs7Ozt5QkFFTCx3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQWhCLENBQWtJLFVBQ3ZILE1BQU0sQ0FDWDs7Ozs7dUJBQ0w7Ozs7O3dCQUVMLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFmO2dCQUNJLHdCQUFDLFVBQUQ7aUJBQ0ksTUFBSztpQkFDTCxlQUFlLGNBQWMsR0FBRztpQkFDaEMsV0FBVyxrREFBa0Qsa0JBQWtCLE9BQU8scUVBQXFFO2lCQUMzSixPQUFNOzJCQUVMLGtCQUFrQixPQUFPLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7NEJBQUksd0JBQUMsS0FBRCxFQUFLLE1BQU0sR0FBSzs7Ozs7Z0JBQzdEOzs7OztnQkFHUix3QkFBQyxVQUFEO2lCQUNJLE1BQUs7aUJBQ0wsYUFBVyxRQUFRLElBQUksNEJBQTRCO2lCQUNuRCxlQUFlO2tCQUFFLG1CQUFtQixvQkFBb0IsTUFBTSxPQUFPLEdBQUc7a0JBQUcsdUJBQXVCLEVBQUU7a0JBQUcsaUJBQWlCLEVBQUU7aUJBQUc7aUJBQzdILFdBQVcsa0RBQWtELG9CQUFvQixNQUFNLDRFQUE0RTtpQkFDbkssT0FBTTsyQkFFTix3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztnQkFDZDs7Ozs7Z0JBRVIsd0JBQUMsT0FBRCxFQUFLLFdBQVUsK0NBQWdEOzs7OztnQkFFL0Qsd0JBQUMsVUFBRDtpQkFBUSxlQUFlLGFBQWEsS0FBSyxDQUFDLENBQUM7aUJBQUcsVUFBVSxRQUFRO2lCQUFHLFdBQVU7aUJBQXVHLE9BQU07MkJBQ3RMLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O2dCQUNsQjs7Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtpQkFBUSxlQUFlLGFBQWEsS0FBSyxDQUFDO2lCQUFHLFVBQVUsUUFBUSxVQUFVLFNBQVM7aUJBQUcsV0FBVTtpQkFBdUcsT0FBTTsyQkFDeE0sd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7Ozs7Z0JBQ3BCOzs7OztnQkFFUix3QkFBQyxVQUFEO2lCQUFRLGVBQWUsd0JBQXdCLEdBQUc7aUJBQUcsV0FBVTtpQkFBdUQsT0FBTTsyQkFDeEgsd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7Z0JBQ2I7Ozs7O2dCQUNSLHdCQUFDLFVBQUQ7aUJBQVEsZUFBZSxxQkFBcUIsR0FBRztpQkFBRyxXQUFVO2lCQUFxRCxPQUFNOzJCQUNuSCx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztnQkFDZjs7Ozs7ZUFDUDs7Ozs7c0JBQ0o7Ozs7OzthQUdMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBRUssZUFBZSxRQUFRLFFBQ3BCLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFmLENBQ0ksd0JBQUMsT0FBRDtnQkFBSyxXQUFVOzBCQUFmLENBQ0ksd0JBQUMsUUFBRDtpQkFBTSxXQUFVOzJCQUFoQjtrQkFDSSx3QkFBQyxTQUFEO21CQUFTLE1BQU07bUJBQUksV0FBVTtrQkFBOEI7Ozs7O2tCQUFDO2tCQUMvQixlQUFlO2tCQUFLO2lCQUMvQzs7Ozs7MEJBQ04sd0JBQUMsUUFBRCxhQUFPLGVBQWUsTUFBSyxHQUFPOzs7O3dCQUNqQzs7Ozs7eUJBQ0wsd0JBQUMsT0FBRDtnQkFBSyxXQUFVOzBCQUNYLHdCQUFDLE9BQUQ7aUJBQ0ksV0FBVTtpQkFDVixPQUFPLEVBQUUsT0FBTyxHQUFHLGVBQWUsS0FBSyxHQUFHO2dCQUM3Qzs7Ozs7ZUFDQTs7Ozt1QkFDSjs7Ozs7d0JBR1Qsd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQWYsQ0FFSyxFQUFFLGdCQUNDLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFBZixDQUNJLHdCQUFDLE9BQUQ7aUJBQ0ksS0FBSyxTQUFTLEVBQUUsYUFBYTtpQkFDN0IsS0FBSTtpQkFDSixXQUFVO2lCQUNWLGVBQWUsaUJBQWlCO2tCQUFFLEtBQUssU0FBUyxFQUFFLGFBQWE7a0JBQUcsS0FBSztpQkFBYyxDQUFDO2lCQUN0RixPQUFNO2dCQUNUOzs7OzBCQUNELHdCQUFDLE9BQUQ7aUJBQUssV0FBVTsyQkFBZixDQUNJLHdCQUFDLFNBQUQ7a0JBQU8sV0FBVTs0QkFBakIsQ0FBMEcsZ0JBRXRHLHdCQUFDLFNBQUQ7bUJBQU8sTUFBSzttQkFBTyxRQUFPO21CQUFVLFdBQVU7bUJBQVMsV0FBVSxNQUFLLEVBQUUsT0FBTyxRQUFRLE1BQU0sMEJBQTBCLEtBQUssRUFBRSxPQUFPLE1BQU0sRUFBRTtrQkFBSTs7OzswQkFDOUk7Ozs7OzJCQUNQLHdCQUFDLFVBQUQ7a0JBQ0ksTUFBSztrQkFDTCxlQUFlLDBCQUEwQixHQUFHO2tCQUM1QyxXQUFVOzRCQUhkLENBS0ksd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs0QkFBQyxlQUNYOzs7Ozt5QkFDUDs7Ozs7d0JBQ0o7Ozs7OzBCQUVMLHdCQUFDLFNBQUQ7Z0JBQU8sV0FBVTswQkFBakI7aUJBQ0ksd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7Ozs7aUJBQUM7aUJBQ25CLHdCQUFDLFNBQUQ7a0JBQU8sTUFBSztrQkFBTyxRQUFPO2tCQUFVLFdBQVU7a0JBQVMsV0FBVSxNQUFLLEVBQUUsT0FBTyxRQUFRLE1BQU0sMEJBQTBCLEtBQUssRUFBRSxPQUFPLE1BQU0sRUFBRTtpQkFBSTs7Ozs7Z0JBQzlJOzs7Ozt5QkFJVixFQUFFLGdCQUNDLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFBZixDQUNJLHdCQUFDLFNBQUQ7aUJBQU87aUJBQVMsS0FBSyxTQUFTLEVBQUUsYUFBYTtpQkFBRyxXQUFVO2dCQUFxQjs7OzswQkFDL0Usd0JBQUMsT0FBRDtpQkFBSyxXQUFVOzJCQUFmLENBQ0ksd0JBQUMsU0FBRDtrQkFBTyxXQUFVOzRCQUFqQixDQUEwRyxlQUV0Ryx3QkFBQyxTQUFEO21CQUFPLE1BQUs7bUJBQU8sUUFBTzttQkFBVSxXQUFVO21CQUFTLFdBQVUsTUFBSyxFQUFFLE9BQU8sUUFBUSxNQUFNLDBCQUEwQixLQUFLLEVBQUUsT0FBTyxNQUFNLEVBQUU7a0JBQUk7Ozs7MEJBQzlJOzs7OzsyQkFDUCx3QkFBQyxVQUFEO2tCQUNJLE1BQUs7a0JBQ0wsZUFBZSwwQkFBMEIsR0FBRztrQkFDNUMsV0FBVTs0QkFIZCxDQUtJLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7NEJBQUMsY0FDWDs7Ozs7eUJBQ1A7Ozs7O3dCQUNKOzs7OzswQkFFTCx3QkFBQyxTQUFEO2dCQUFPLFdBQVU7MEJBQWpCO2lCQUNJLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7O2lCQUFDO2lCQUNuQix3QkFBQyxTQUFEO2tCQUFPLE1BQUs7a0JBQU8sUUFBTztrQkFBVSxXQUFVO2tCQUFTLFdBQVUsTUFBSyxFQUFFLE9BQU8sUUFBUSxNQUFNLDBCQUEwQixLQUFLLEVBQUUsT0FBTyxNQUFNLEVBQUU7aUJBQUk7Ozs7O2dCQUM5STs7Ozs7dUJBRVY7Ozs7O3NCQUNKOzs7Ozs7YUFHTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLFNBQUQ7ZUFBTyxXQUFVO3lCQUE2RDtjQUEwQjs7Ozt3QkFDeEcsd0JBQUMscUJBQUQ7ZUFDSSxPQUFPLEVBQUUsWUFBWTtlQUNyQixXQUFXLFlBQVksZUFBZSxLQUFLLFlBQVksT0FBTztlQUM5RCxhQUFZO2NBQ2Y7Ozs7c0JBQ0E7Ozs7OzthQUdKLGtCQUFrQixRQUNmLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQ1gsd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7OztjQUN2Qjs7Ozt3QkFDTCx3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFDWCx3QkFBQyxxQkFBRDtnQkFBcUIsU0FBUyxFQUFFO2dCQUFVLFFBQVEsRUFBRTtnQkFBZ0IsV0FBVTtlQUE0RDs7Ozs7Y0FDekk7Ozs7c0JBQ0o7Ozs7OzthQUlSLG9CQUFvQixPQUNqQix3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZjtlQUNJLHdCQUFDLEtBQUQ7Z0JBQUcsV0FBVTswQkFBYixDQUNJLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7MEJBQUMsd0JBQ3BCOzs7Ozs7ZUFDSCx3QkFBQyxVQUFEO2dCQUFRLE9BQU87Z0JBQWEsV0FBVSxNQUFLO2lCQUFFLGVBQWUsRUFBRSxPQUFPLEtBQUs7aUJBQUcsYUFBYSxRQUFRLDhCQUE4QixFQUFFLE9BQU8sS0FBSztnQkFBRztnQkFBRyxXQUFVOzBCQUN6SixpQkFBaUIsS0FBSSxVQUFTLHdCQUFDLFVBQUQ7aUJBQXFDLE9BQU8sTUFBTSxNQUFNLE1BQU07MkJBQU8sTUFBTSxRQUFRLE1BQU07Z0JBQVcsR0FBdkYsTUFBTSxNQUFNLE1BQU07Ozs7dUJBQXFFLENBQUM7ZUFDaEk7Ozs7O2VBQ1AsaUJBQWlCLHdCQUFDLEtBQUQ7Z0JBQUcsV0FBVTswQkFBNEI7ZUFBaUI7Ozs7O2VBQzVFLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFBZixDQUNJLHdCQUFDLFNBQUQ7aUJBQ0ksTUFBSztpQkFDTCxPQUFPO2lCQUNQLFdBQVUsTUFBSyx1QkFBdUIsRUFBRSxPQUFPLEtBQUs7aUJBQ3BELGFBQVk7aUJBQ1osV0FBVTtpQkFDVixVQUFVO2dCQUNiOzs7OzBCQUNELHdCQUFDLFVBQUQ7aUJBQ0ksTUFBSztpQkFDTCxlQUFlLGVBQWUsR0FBRztpQkFDakMsVUFBVSxjQUFjLENBQUMsb0JBQW9CLEtBQUs7aUJBQ2xELFdBQVU7MkJBSmQsQ0FNSyxhQUFhLHdCQUFDLFFBQUQ7a0JBQU0sV0FBVTs0QkFBZTtpQkFBTzs7Ozs0QkFBSSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OzJCQUFFLFFBRXhFOzs7Ozt3QkFDUDs7Ozs7O2NBQ0o7Ozs7OzthQUlULHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7ZUFBTyxXQUFVO3lCQUFrRTtjQUFnQjs7Ozt3QkFDbkcsd0JBQUMsVUFBRDtlQUNJLE9BQU8sRUFBRTtlQUNULFdBQVUsTUFBSyxlQUFlLEtBQUssVUFBVSxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUM7ZUFDckUsV0FBVTt5QkFFVCxlQUFlLEtBQUksTUFDaEIsd0JBQUMsVUFBRDtnQkFBbUIsT0FBTyxFQUFFOzBCQUFLLEVBQUU7ZUFBYyxHQUFwQyxFQUFFOzs7O3NCQUFrQyxDQUNwRDtjQUNHOzs7O3NCQUNQOzs7O3dCQUVMLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFmLENBQ0ksd0JBQUMsU0FBRDtnQkFBTyxXQUFVOzBCQUFqQixDQUNJLHdCQUFDLFNBQUQ7aUJBQ0ksTUFBSztpQkFDTCxTQUFTLEVBQUUsZUFBZTtpQkFDMUIsV0FBVSxNQUFLLGVBQWUsS0FBSyxjQUFjLEVBQUUsT0FBTyxPQUFPO2lCQUNqRSxXQUFVO2dCQUNiOzs7OzBCQUNELHdCQUFDLFFBQUQsWUFBTSwyQkFBOEI7Ozs7d0JBQ2pDOzs7Ozt5QkFFUCx3QkFBQyxTQUFEO2dCQUFPLFdBQVU7MEJBQWpCLENBQ0ksd0JBQUMsU0FBRDtpQkFDSSxNQUFLO2lCQUNMLFNBQVMsQ0FBQyxDQUFDLEVBQUU7aUJBQ2IsV0FBVSxNQUFLLGVBQWUsS0FBSyxjQUFjLEVBQUUsT0FBTyxPQUFPO2lCQUNqRSxXQUFVO2dCQUNiOzs7OzBCQUNELHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7d0JBQ3pCOzs7Ozt1QkFDTjs7Ozs7c0JBQ0o7Ozs7OzthQUdKLEVBQUUsZUFBZSxTQUNkLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmO2VBQ0ksd0JBQUMsU0FBRDtnQkFBTyxXQUFVOzBCQUF5RTtlQUFnQjs7Ozs7ZUFDMUcsd0JBQUMsU0FBRDtnQkFDSSxNQUFLO2dCQUNMLEtBQUk7Z0JBQ0osTUFBSztnQkFDTCxhQUFZO2dCQUNaLE9BQU8sRUFBRSxVQUFVO2dCQUNuQixXQUFVLE1BQUssZUFBZSxLQUFLLFVBQVUsRUFBRSxPQUFPLFVBQVUsS0FBSyxPQUFPLFNBQVMsRUFBRSxPQUFPLE9BQU8sRUFBRSxDQUFDO2dCQUN4RyxXQUFVO2VBQ2I7Ozs7O2VBQ0Qsd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUF3RDtlQUFxRDs7Ozs7Y0FDNUg7Ozs7OzthQUlSLEVBQUUsZUFBZSxRQUNkLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsUUFBRCxFQUFNLFdBQVUsNkNBQThDOzs7O3dCQUM5RCx3QkFBQyxRQUFEO2VBQU07ZUFBUyx3QkFBQyxLQUFELFlBQUcsZ0JBQWdCOzs7OztlQUFDO2NBQWdKOzs7O3NCQUNsTDs7Ozs7d0JBQ0w7YUFFSyxhQUFhLEVBQUUsTUFBTSxLQUMxQix3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZjtlQUNJLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFBZixDQUNJLHdCQUFDLFNBQUQ7aUJBQU8sV0FBVTsyQkFBNkQ7Z0JBQXVCOzs7OzBCQUNwRyxFQUFFLGVBQWUsU0FDZCx3QkFBQyxRQUFEO2lCQUFNLFdBQVU7MkJBQ1gsRUFBRSxXQUFXLElBQ1Isb0NBQ0E7Z0JBQ0o7Ozs7d0JBRVQ7Ozs7OztlQUNKLEVBQUUsUUFBUSxLQUFLLEtBQUssU0FDakIsd0JBQUMsT0FBRDtnQkFBcUQsV0FBVTswQkFBL0Q7aUJBQ0ksd0JBQUMsT0FBRDtrQkFBSyxXQUFVOzRCQUFmO21CQUNLLEVBQUUsZUFBZSxRQUNkLHdCQUFDLFNBQUQ7b0JBQU8sV0FBVTs4QkFBakIsQ0FDSyxFQUFFLFdBQVcsSUFFVjtxQkFBQzs7cUJBQUQ7c0JBQ0ksTUFBSztzQkFDTCxNQUFNLFlBQVk7c0JBQ2xCLFNBQVMsQ0FBQyxDQUFDLElBQUk7c0JBQ2YsZ0JBQWdCO3VCQUNaLGNBQWEsU0FBUSxLQUFLLEtBQUssSUFBSSxPQUFPO3dCQUN0QyxJQUFJLE9BQU8sS0FBSyxPQUFPO3dCQUN2QixPQUFPO3lCQUNILEdBQUc7eUJBQ0gsU0FBUyxHQUFHLFFBQVEsS0FBSyxHQUFHLFFBQVE7MEJBQ2hDLEdBQUc7MEJBQ0gsV0FBVyxPQUFPO3lCQUN0QixFQUFFO3dCQUNOO3VCQUNKLENBQUMsQ0FBQztzQkFDTjtzQkFDQSxXQUFVO3NCQUNWLE9BQU07cUJBQ1Q7Ozs7Ozs7Ozs7O0FBR0Qsd0JBQUMsU0FBRDtxQkFDSSxNQUFLO3FCQUNMLFNBQVMsQ0FBQyxDQUFDLElBQUk7cUJBQ2YsV0FBVSxNQUFLLGFBQWEsS0FBSyxNQUFNLGFBQWEsRUFBRSxPQUFPLE9BQU87cUJBQ3BFLFdBQVU7cUJBQ1YsT0FBTTtvQkFDVDs7Ozs4QkFFSixJQUFJLGFBQWEsd0JBQUMsUUFBRDtxQkFBTSxXQUFVOytCQUErSDtvQkFBYTs7Ozs0QkFDM0s7Ozs7OzhCQUVQLHdCQUFDLFFBQUQ7b0JBQU0sV0FBVTs4QkFDWCxPQUFPLGFBQWEsS0FBSyxJQUFJO21CQUM1Qjs7Ozs7bUJBR1Ysd0JBQUMsT0FBRDtvQkFBSyxXQUFVOzhCQUFmO3FCQUNJLHdCQUFDLFNBQUQ7c0JBQ0ksYUFBYSxXQUFXLE9BQU87c0JBQy9CLE9BQU8sSUFBSTtzQkFDWCxXQUFVLE1BQUssYUFBYSxLQUFLLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztzQkFDbkUsV0FBVTtxQkFDYjs7Ozs7cUJBQ0Qsd0JBQUMsVUFBRDtzQkFDSSxNQUFLO3NCQUNMLGVBQWUsZ0JBQWdCLEtBQUssUUFBUSxVQUFVLElBQUk7c0JBQzFELFdBQVU7c0JBQ1YsT0FBTTtnQ0FFTix3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztxQkFDbkI7Ozs7O3FCQUNSLHdCQUFDLFVBQUQ7c0JBQ0ksTUFBSztzQkFDTCxlQUFlLGdCQUFnQixLQUFLLFFBQVEsVUFBVSxJQUFJO3NCQUMxRCxXQUFVO3NCQUNWLE9BQU07Z0NBRU4sd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7cUJBQ2I7Ozs7O3FCQUdSLHdCQUFDLFNBQUQ7c0JBQ0EsV0FBVTtzQkFDVixPQUFNO2dDQUZOLENBSUEsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7OztnQ0FDbEIsd0JBQUMsU0FBRDt1QkFDSSxNQUFLO3VCQUNMLFFBQU87dUJBQ1AsV0FBVTt1QkFDVixVQUFVLGVBQWUsVUFBVSxJQUFJLEdBQUcsV0FBVzt1QkFDckQsVUFBVSxPQUFNLE1BQUs7d0JBQ2pCLE1BQU0sT0FBTyxFQUFFLE9BQU8sUUFBUTt3QkFDOUIsSUFBSSxDQUFDLE1BQU07d0JBQ1gsSUFBSSxLQUFLLE9BQU8sTUFBTSxNQUFNO3lCQUN4QixVQUFVLDJDQUEyQyxPQUFPO3lCQUM1RDt3QkFDSjt3QkFDQSxNQUFNLFlBQVksVUFBVSxJQUFJLEdBQUc7d0JBQ25DLG1CQUFrQixVQUFTO3lCQUFFLEdBQUc7MEJBQU8sWUFBWTt3QkFBRSxFQUFFO3dCQUN2RCxNQUFNLE1BQU0sTUFBTSxrQkFBa0IsS0FBSyxJQUFJO3dCQUM3QyxJQUFJLENBQUMsS0FBSzt5QkFDTixVQUFVLGtEQUFrRCxPQUFPO3lCQUNuRSxFQUFFLE9BQU8sUUFBUTt5QkFDakIsbUJBQWtCLFVBQVM7MEJBQUUsR0FBRzsyQkFBTyxZQUFZO3lCQUFLLEVBQUU7eUJBQzFEO3dCQUNKO3dCQUNBLElBQUk7eUJBQ0EsTUFBTSxNQUFNLE1BQU0sa0JBQWtCLElBQUksSUFBSSxZQUFZLElBQUksVUFBVSxPQUFPLFFBQVE7MEJBQ2pGLG1CQUFrQixVQUFTOzJCQUFFLEdBQUc7NEJBQU8sWUFBWTswQkFBSSxFQUFFO3lCQUM3RCxDQUFDO3lCQUNELElBQUksSUFBSSxJQUFJOzBCQUNSLFlBQVksU0FBUzswQkFDckIsYUFBYSxLQUFLLE1BQU0sZUFBZSxJQUFJLE1BQU0sZUFBZSxJQUFJLE1BQU0sT0FBTyxJQUFJOzBCQUNyRixVQUFVLGdDQUFnQzt5QkFDOUMsT0FBTzswQkFDSCxVQUFVLElBQUksV0FBVyxnQ0FBZ0MsT0FBTzt5QkFDcEU7d0JBQ0osU0FBUyxLQUFLO3lCQUNWLFFBQVEsTUFBTSxnQ0FBZ0MsR0FBRzt5QkFDakQsVUFBVSxpREFBaUQsT0FBTzt3QkFDdEUsVUFBVTt5QkFDTixtQkFBa0IsVUFBUzswQkFBRSxHQUFHOzJCQUFPLFlBQVk7eUJBQUssRUFBRTt3QkFDOUQ7d0JBQ0EsRUFBRSxPQUFPLFFBQVE7dUJBQ3JCO3NCQUNIOzs7OzhCQUNFOzs7Ozs7cUJBQ04sZUFBZSxVQUFVLElBQUksR0FBRyxXQUFXLFFBQ3hDLHdCQUFDLFFBQUQ7c0JBQU0sV0FBVTtzQkFBMEYsT0FBTTtnQ0FBaEg7dUJBQ0ksd0JBQUMsU0FBRDt3QkFBUyxNQUFNO3dCQUFJLFdBQVU7dUJBQWdCOzs7Ozt1QkFDN0Msd0JBQUMsUUFBRDt3QkFBTSxXQUFVO2tDQUNaLHdCQUFDLFFBQUQ7eUJBQU0sV0FBVTt5QkFBb0UsT0FBTyxFQUFFLE9BQU8sR0FBRyxlQUFlLFVBQVUsSUFBSSxHQUFHLFFBQVEsR0FBRzt3QkFBSTs7Ozs7dUJBQ3BKOzs7Ozt1QkFDTCxlQUFlLFVBQVUsSUFBSSxHQUFHO3VCQUFRO3NCQUN2Qzs7Ozs7O29CQUVMOzs7Ozs7bUJBRUwsd0JBQUMsVUFBRDtvQkFBUSxlQUFlLGFBQWEsS0FBSyxJQUFJO29CQUFHLFdBQVU7OEJBQ3RELHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7O21CQUNmOzs7OztrQkFDUDs7Ozs7O2tCQUdILElBQUksWUFBWSxTQUFTLEdBQUcsS0FBSyxJQUFJLFlBQVksU0FBUyxNQUFNLEtBQUssSUFBSSxZQUFZLFNBQVMsT0FBTyxNQUNuRyx3QkFBQyxPQUFEO2tCQUFLLFdBQVU7NEJBQ1gsd0JBQUMscUJBQUQ7bUJBQXFCLFNBQVMsSUFBSTttQkFBWSxRQUFPO21CQUFPLFdBQVU7a0JBQVc7Ozs7O2lCQUNoRjs7Ozs7aUJBSVIsSUFBSSxlQUNMLHdCQUFDLE9BQUQ7a0JBQUssV0FBVTs0QkFBZixDQUNJLHdCQUFDLE9BQUQ7bUJBQ0ksS0FBSyxTQUFTLElBQUksV0FBVzttQkFDN0IsS0FBSTttQkFDSixXQUFVO21CQUNWLGVBQWUsaUJBQWlCO29CQUFFLEtBQUssU0FBUyxJQUFJLFdBQVc7b0JBQUcsS0FBSzttQkFBYyxDQUFDO2tCQUN6Rjs7Ozs0QkFDRyx3QkFBQyxVQUFEO21CQUNJLE1BQUs7bUJBQ0wsZUFBZSxhQUFhLEtBQUssTUFBTSxlQUFlLElBQUk7bUJBQzFELFdBQVU7bUJBQ1YsT0FBTTs2QkFFTix3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztrQkFDZjs7OzswQkFDUDs7Ozs7O2dCQUVSO2tCQTdKSyxJQUFJLE9BQU8sSUFBSSxNQUFNLE9BQU8sSUFBSSxHQUFHOzs7O3NCQTZKeEMsQ0FDUjtlQUNELHdCQUFDLFVBQUQ7Z0JBQVEsZUFBZSxVQUFVLEdBQUc7Z0JBQUcsV0FBVTswQkFBMEY7ZUFFbkk7Ozs7O2NBQ1A7Ozs7OzthQUlSLEVBQUUsZUFBZSxTQUFTO2NBQUM7Y0FBRztjQUFHO2FBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxNQUFNLEtBQ2xELHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0ksd0JBQUMsU0FBRDtlQUFPLFdBQVU7eUJBQWtFO2NBRTVFOzs7O3dCQUNOLEVBQUUsV0FBVyxJQUNWLHdCQUFDLFVBQUQ7ZUFDSSxjQUFjO2dCQUNWLE1BQU0sSUFBSSxFQUFFLGlCQUFpQjtnQkFDN0IsT0FBUSxNQUFNLFVBQVUsTUFBTSxTQUFVLFVBQVcsTUFBTSxXQUFXLE1BQU0sVUFBVyxVQUFVO2VBQ25HLEVBQUMsQ0FBRTtlQUNILFdBQVUsTUFBSyxlQUFlLEtBQUssaUJBQWlCLEVBQUUsT0FBTyxLQUFLO2VBQ2xFLFdBQVU7eUJBTmQsQ0FRSSx3QkFBQyxVQUFEO2dCQUFRLE9BQU07MEJBQVE7ZUFBYTs7Ozt5QkFDbkMsd0JBQUMsVUFBRDtnQkFBUSxPQUFNOzBCQUFRO2VBQWE7Ozs7dUJBQy9COzs7Ozt5QkFDUixFQUFFLFdBQVcsSUFDYix3QkFBQyxTQUFEO2VBQ0ksTUFBSztlQUNMLE9BQU8sRUFBRSxpQkFBaUI7ZUFDMUIsV0FBVSxNQUFLLGVBQWUsS0FBSyxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7ZUFDbEUsV0FBVTtjQUNiOzs7O3lCQUVELHdCQUFDLFNBQUQ7ZUFDSSxhQUFZO2VBQ1osT0FBTyxFQUFFO2VBQ1QsV0FBVSxNQUFLLGVBQWUsS0FBSyxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7ZUFDbEUsV0FBVTtjQUNiOzs7O3NCQUVKOzs7Ozs7WUFFUjtjQTNkSSxFQUFFLE9BQU87Ozs7a0JBMmRiLENBQ1I7VUFDQTs7Ozs7VUFFSixVQUFVLFdBQVcsS0FDbEIsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBdUQ7V0FBaUI7Ozs7cUJBQ3JGLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFrRDtXQUFvRjs7OzttQkFDbEo7Ozs7OztXQUlQLGlCQUFpQixZQUFZLGVBQzNCLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0ksd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDSSx3QkFBQyxVQUFEO2NBQ0ksTUFBSztjQUNMLGVBQWUsZ0JBQWUsTUFBSyxLQUFLLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQztjQUNyRCxVQUFVLGdCQUFnQjtjQUMxQixXQUFVO3dCQUpkLENBTUksd0JBQUMsV0FBRDtlQUFXLE1BQU07ZUFBSSxXQUFVO2NBQWE7Ozs7d0JBQzVDLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztzQkFDbEI7Ozs7OzthQUNSLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmO2VBQ0ksd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUFoQixDQUErRCxZQUFTLFdBQWtCOzs7Ozs7ZUFDMUYsd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUFpQjtlQUFPOzs7OztlQUN4Qyx3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQWdELEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxpQkFBaUIsUUFBUSxDQUFDO2VBQVE7Ozs7O2NBQ3ZIOzs7Ozs7YUFDTCx3QkFBQyxVQUFEO2NBQ0ksTUFBSztjQUNMLGVBQWUsZ0JBQWUsTUFBSyxJQUFJLENBQUM7Y0FDeEMsVUFBVSxlQUFlLEtBQUssS0FBSyxpQkFBaUIsUUFBUTtjQUM1RCxXQUFVO3dCQUpkLENBTUksd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O3dCQUN0Qix3QkFBQyxXQUFEO2VBQVcsTUFBTTtlQUFJLFdBQVU7Y0FBYzs7OztzQkFDekM7Ozs7OztZQUNQOzs7OztxQkFDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUF5RDtZQUFtQjs7OztzQkFDN0Ysd0JBQUMsVUFBRDthQUNJLE9BQU87YUFDUCxXQUFXLE1BQU07Y0FBRSxZQUFZLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztjQUFHLGVBQWUsQ0FBQzthQUFHO2FBQzNFLFdBQVU7dUJBSGQ7Y0FLSSx3QkFBQyxVQUFEO2VBQVEsT0FBTzt5QkFBSTtjQUFlOzs7OztjQUNsQyx3QkFBQyxVQUFEO2VBQVEsT0FBTzt5QkFBSTtjQUFlOzs7OztjQUNsQyx3QkFBQyxVQUFEO2VBQVEsT0FBTzt5QkFBSTtjQUFlOzs7OztjQUNsQyx3QkFBQyxVQUFEO2VBQVEsT0FBTzt5QkFBSztjQUFnQjs7Ozs7YUFDaEM7Ozs7O29CQUNQOzs7OzttQkFDSjs7Ozs7O1VBSVQsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1gsd0JBQUMsVUFBRDtZQUNJLFNBQVM7WUFDVCxhQUFVO1lBQ1YsV0FBVTtzQkFIZCxDQUtJLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7c0JBQUMscUJBQ2Q7Ozs7OztVQUNQOzs7OztVQUNKLGtCQUNHLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0ksd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDSSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztjQUNsQix3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBaEI7Z0JBQXlCO2dCQUFvQixtQkFBbUI7Z0JBQUs7ZUFBbUI7Ozs7OztjQUN4Rix3QkFBQyxVQUFEO2VBQVEsTUFBSztlQUFTLGVBQWUsc0JBQXNCLElBQUksSUFBSSxVQUFVLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDO2VBQUcsV0FBVTt5QkFBMkM7Y0FBbUI7Ozs7O2FBQ3hLOzs7Ozs7WUFDTCx3QkFBQyxVQUFEO2FBQVEsT0FBTzthQUFhLFdBQVUsTUFBSztjQUFFLGVBQWUsRUFBRSxPQUFPLEtBQUs7Y0FBRyxhQUFhLFFBQVEsOEJBQThCLEVBQUUsT0FBTyxLQUFLO2FBQUc7YUFBRyxXQUFVO3VCQUN6SixpQkFBaUIsS0FBSSxVQUFTLHdCQUFDLFVBQUQ7Y0FBcUMsT0FBTyxNQUFNLE1BQU0sTUFBTTt3QkFBTyxNQUFNLFFBQVEsTUFBTTthQUFXLEdBQXZGLE1BQU0sTUFBTSxNQUFNOzs7O29CQUFxRSxDQUFDO1lBQ2hJOzs7OztZQUNSLHdCQUFDLFNBQUQ7YUFDSSxNQUFLO2FBQ0wsT0FBTzthQUNQLFdBQVUsTUFBSyx5QkFBeUIsRUFBRSxPQUFPLEtBQUs7YUFDdEQsYUFBWTthQUNaLFdBQVU7WUFDYjs7Ozs7WUFDRCx3QkFBQyxVQUFEO2FBQ0ksTUFBSzthQUNMLFNBQVM7YUFDVCxVQUFVLGdCQUFnQixtQkFBbUIsU0FBUyxLQUFLLENBQUMsc0JBQXNCLEtBQUs7YUFDdkYsV0FBVTt1QkFKZCxDQU1LLGVBQWUsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWU7YUFBTzs7Ozt3QkFBSSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7O3VCQUMzRSxlQUFlLGdCQUFnQixpQkFDNUI7Ozs7OztXQUNQOzs7Ozs7U0FFUjs7Ozs7a0JBR0Esa0JBQ0csd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNYLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFnRjtZQUFhOzs7OztXQUMxRzs7OztxQkFDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUNLLFVBQVUsUUFBTyxhQUNoQjs7Ozs7c0JBQ04sd0JBQUMsVUFBRDthQUNJLE1BQUs7YUFDTCxlQUFlLGtCQUFrQixLQUFLO2FBQ3RDLFdBQVU7YUFDVixPQUFNO3VCQUVOLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O1lBQ1Y7Ozs7b0JBQ1A7Ozs7O21CQUNKOzs7Ozs7VUFHSixNQUFNLGVBQ0gsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1gsd0JBQUMsT0FBRDtZQUFLLEtBQUssU0FBUyxLQUFLLFdBQVc7WUFBRyxLQUFJO1lBQVMsV0FBVTtXQUE4Qjs7Ozs7VUFDMUY7Ozs7O1VBSVQsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDSSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDVCxNQUFNLFNBQVM7V0FDaEI7Ozs7cUJBQ0gsTUFBTSxlQUNILHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNYLHdCQUFDLHFCQUFELEVBQXFCLFNBQVMsS0FBSyxZQUFjOzs7OztXQUNoRDs7OzttQkFFUjs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1YsVUFBVSxXQUFXLElBQ2xCLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFrSjtXQUU1Sjs7OztzQkFFTCxVQUFVLEtBQUssR0FBRyxTQUNkLHdCQUFDLE9BQUQ7WUFBaUMsV0FBVTtzQkFBM0M7YUFDSSx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNJLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFmLENBQ0ksd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUFoQixDQUE4RCxPQUFPLEdBQUUsR0FBTzs7Ozs7eUJBQzlFLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFDWCx3QkFBQyxxQkFBRCxFQUFxQixTQUFTLEVBQUUsWUFBWSx5QkFBMkI7Ozs7O2VBQ3RFOzs7O3VCQUNKOzs7Ozt3QkFDSixFQUFFLGVBQWUsU0FDZCx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBaEIsQ0FDSyxFQUFFLFVBQVUsR0FBRSxPQUNiOzs7OztzQkFFVDs7Ozs7O2FBR0osRUFBRSxpQkFDQyx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFDWCx3QkFBQyxPQUFEO2VBQUssS0FBSyxTQUFTLEVBQUUsYUFBYTtlQUFHLEtBQUk7ZUFBTyxXQUFVO2NBQXlDOzs7OzthQUNsRzs7Ozs7YUFJUixFQUFFLFdBQVcsS0FDVix3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFDVixFQUFFLFNBQVMsS0FBSyxLQUFLLFNBQ2xCLHdCQUFDLFNBQUQ7ZUFBa0IsV0FBVTt5QkFBNUIsQ0FDSSx3QkFBQyxTQUFEO2dCQUFPLE1BQUs7Z0JBQVEsTUFBTSxrQkFBa0I7Z0JBQVE7Z0JBQVMsV0FBVTtlQUFpQjs7Ozt5QkFDeEYsd0JBQUMsUUFBRCxZQUFPLElBQUksY0FBYyxXQUFXLE9BQU8sYUFBYSxLQUFLLElBQUksSUFBVTs7Ozt1QkFDeEU7aUJBSEs7Ozs7cUJBR0wsQ0FDVjthQUNBOzs7OzthQUdSLEVBQUUsV0FBVyxLQUNWLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUNWLEVBQUUsU0FBUyxLQUFLLEtBQUssU0FDbEIsd0JBQUMsU0FBRDtlQUFrQixXQUFVO3lCQUE1QixDQUNJLHdCQUFDLFNBQUQ7Z0JBQU8sTUFBSztnQkFBVztnQkFBUyxXQUFVO2VBQXlCOzs7O3lCQUNuRSx3QkFBQyxRQUFELFlBQU8sSUFBSSxjQUFjLFdBQVcsT0FBTyxhQUFhLEtBQUssSUFBSSxJQUFVOzs7O3VCQUN4RTtpQkFISzs7OztxQkFHTCxDQUNWO2FBQ0E7Ozs7O2FBR1IsRUFBRSxXQUFXLEtBQ1Ysd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDSSx3QkFBQyxTQUFEO2VBQU8sV0FBVTt5QkFBakIsQ0FDSSx3QkFBQyxTQUFEO2dCQUFPLE1BQUs7Z0JBQVEsTUFBTSxrQkFBa0I7Z0JBQVE7Z0JBQVMsV0FBVTtlQUFpQjs7Ozt5QkFDeEYsd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7dUJBQ2Q7Ozs7O3dCQUNQLHdCQUFDLFNBQUQ7ZUFBTyxXQUFVO3lCQUFqQixDQUNJLHdCQUFDLFNBQUQ7Z0JBQU8sTUFBSztnQkFBUSxNQUFNLGtCQUFrQjtnQkFBUTtnQkFBUyxXQUFVO2VBQWlCOzs7O3lCQUN4Rix3QkFBQyxRQUFELFlBQU0sUUFBVzs7Ozt1QkFDZDs7Ozs7c0JBQ047Ozs7OzthQUdSLEVBQUUsV0FBVyxLQUNWLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUNYLHdCQUFDLFNBQUQ7ZUFBTyxNQUFLO2VBQU87ZUFBUyxhQUFZO2VBQThCLFdBQVU7Y0FBa0o7Ozs7O2FBQ2pPOzs7OztZQUVSO2NBL0RLLEVBQUUsT0FBTyxFQUFFLE1BQU07Ozs7a0JBK0R0QixDQUNSO1VBRUo7Ozs7O1NBQ0o7Ozs7O2dCQUVSOzs7Ozs7T0FJUixjQUFjLGNBQ1gsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBNkc7UUFFdkg7Ozs7a0JBRUosd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDSSx3QkFBQyxPQUFEO1dBQ0ksd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQWtFO1dBQXlCOzs7OztXQUM1Ryx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUNLLG1CQUFrQixLQUNqQjs7Ozs7c0JBQ04sd0JBQUMsU0FBRDthQUNJLE9BQU8sU0FBUzthQUNoQixXQUFVLE1BQUssYUFBWSxPQUFNO2NBQUUsR0FBRztjQUFHLGdCQUFnQixFQUFFLE9BQU8sTUFBTSxZQUFZLENBQUMsQ0FBQyxRQUFRLGVBQWUsRUFBRTthQUFFLEVBQUU7YUFDbkgsYUFBWTthQUNaLFdBQVU7WUFDYjs7OztvQkFDQTs7Ozs7O1dBQ0wsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQXNEO1dBQWtEOzs7OztVQUNwSDs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLE9BQUQ7WUFDSSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBa0U7WUFBK0I7Ozs7O1lBQ2xILHdCQUFDLFVBQUQ7YUFDSSxPQUFPLFNBQVM7YUFDaEIsV0FBVSxNQUFLLGFBQVksT0FBTTtjQUFFLEdBQUc7Y0FBRyxZQUFZLFNBQVMsRUFBRSxPQUFPLEtBQUs7YUFBRSxFQUFFO2FBQ2hGLFdBQVU7dUJBSGQsQ0FLSSx3QkFBQyxVQUFEO2NBQVEsT0FBTzt3QkFBRzthQUFxQzs7Ozt1QkFDdkQsd0JBQUMsVUFBRDtjQUFRLE9BQU87d0JBQUc7YUFBdUM7Ozs7cUJBQ3JEOzs7Ozs7WUFFUix3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBc0Q7WUFBNkQ7Ozs7O1dBQy9IOzs7O3FCQUVMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBa0U7V0FBcUM7Ozs7cUJBQ3hILHdCQUFDLFNBQUQ7WUFDSSxNQUFLO1lBQ0wsS0FBSTtZQUNKLE9BQU8sU0FBUztZQUNoQixXQUFVLE1BQUssYUFBWSxPQUFNO2FBQUUsR0FBRzthQUFHLGVBQWUsRUFBRSxPQUFPO1lBQU0sRUFBRTtZQUN6RSxhQUFZO1lBQ1osV0FBVTtXQUNiOzs7O21CQUNBOzs7O21CQUNKOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBa0U7V0FBcUM7Ozs7cUJBQ3hILHdCQUFDLFNBQUQ7WUFDSSxNQUFLO1lBQ0wsT0FBTyxTQUFTO1lBQ2hCLFdBQVUsTUFBSyxhQUFZLE9BQU07YUFBRSxHQUFHO2FBQUcsY0FBYyxFQUFFLE9BQU87WUFBTSxFQUFFO1lBQ3hFLFdBQVU7V0FDYjs7OzttQkFDQTs7OztxQkFFTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQWtFO1dBQXNDOzs7O3FCQUN6SCx3QkFBQyxTQUFEO1lBQ0ksTUFBSztZQUNMLE9BQU8sU0FBUztZQUNoQixXQUFVLE1BQUssYUFBWSxPQUFNO2FBQUUsR0FBRzthQUFHLGVBQWUsRUFBRSxPQUFPO1lBQU0sRUFBRTtZQUN6RSxXQUFVO1dBQ2I7Ozs7bUJBQ0E7Ozs7bUJBQ0o7Ozs7OztVQUVMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBa0U7VUFBMkM7Ozs7b0JBQzlILHdCQUFDLFNBQUQ7V0FDSSxNQUFLO1dBQ0wsT0FBTyxTQUFTO1dBQ2hCLFdBQVUsTUFBSyxhQUFZLE9BQU07WUFBRSxHQUFHO1lBQUcsV0FBVyxFQUFFLE9BQU87V0FBTSxFQUFFO1dBQ3JFLGFBQVk7V0FDWixXQUFVO1VBQ2I7Ozs7a0JBQ0E7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1Y7WUFDRzthQUFFLEtBQUs7YUFBYSxPQUFPO1lBQW1EO1lBQzlFO2FBQUUsS0FBSzthQUFzQixPQUFPO1lBQTBDO1lBQzlFO2FBQUUsS0FBSzthQUFlLE9BQU87WUFBNkM7WUFDMUU7YUFBRSxLQUFLO2FBQWlCLE9BQU87WUFBMEM7V0FDN0UsQ0FBQyxDQUFDLEtBQUssRUFBRSxLQUFLLFlBQ1Ysd0JBQUMsU0FBRDtZQUFpQixXQUFVO3NCQUEzQixDQUNJLHdCQUFDLFNBQUQ7YUFDSSxNQUFLO2FBQ0wsU0FBUyxTQUFTO2FBQ2xCLFdBQVUsTUFBSyxhQUFZLE9BQU07Y0FBRSxHQUFHO2VBQUksTUFBTSxFQUFFLE9BQU87YUFBUSxFQUFFO2FBQ25FLFdBQVU7WUFDYjs7OztzQkFDRCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBd0Q7WUFBWTs7OztvQkFDakY7Y0FSSzs7OztrQkFRTCxDQUNWO1VBQ0E7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDSSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZjtjQUNJLHdCQUFDLGFBQUQ7ZUFBYSxNQUFNO2VBQUksV0FBVTtjQUFnQjs7Ozs7Y0FDakQsd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQWlGO2NBQWM7Ozs7O2NBQzdHLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUEwRztjQUFrQjs7Ozs7YUFDM0k7Ozs7OztZQUNMLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUFqQixDQUNJLHdCQUFDLFNBQUQ7Y0FBTyxNQUFLO2NBQVcsU0FBUyxTQUFTO2NBQVksV0FBVSxNQUFLLGFBQVksT0FBTTtlQUFFLEdBQUc7ZUFBRyxZQUFZLEVBQUUsT0FBTztjQUFRLEVBQUU7Y0FBRyxXQUFVO2FBQStDOzs7O3VCQUN6TCx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBdUQ7YUFBeUI7Ozs7cUJBQzdGOzs7Ozs7WUFDTixTQUFTLGNBQ04sd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDSSx3QkFBQyxTQUFEO2VBQU8sV0FBVTt5QkFBakIsQ0FDSSx3QkFBQyxTQUFEO2dCQUFPLE1BQUs7Z0JBQVcsU0FBUyxTQUFTO2dCQUFrQixXQUFVLE1BQUssYUFBWSxPQUFNO2lCQUFFLEdBQUc7aUJBQUcsa0JBQWtCLEVBQUUsT0FBTztnQkFBUSxFQUFFO2dCQUFHLFdBQVU7ZUFBK0M7Ozs7eUJBQ3JNLHdCQUFDLFFBQUQ7Z0JBQU0sV0FBVTswQkFBeUQ7ZUFBeUM7Ozs7dUJBQy9HOzs7Ozs7Y0FDUCx3QkFBQyxTQUFEO2VBQU8sV0FBVTt5QkFBakIsQ0FDSSx3QkFBQyxTQUFEO2dCQUFPLE1BQUs7Z0JBQVcsU0FBUyxTQUFTO2dCQUFpQixXQUFVLE1BQUssYUFBWSxPQUFNO2lCQUFFLEdBQUc7aUJBQUcsaUJBQWlCLEVBQUUsT0FBTztnQkFBUSxFQUFFO2dCQUFHLFdBQVU7ZUFBK0M7Ozs7eUJBQ25NLHdCQUFDLFFBQUQ7Z0JBQU0sV0FBVTswQkFBeUQ7ZUFBbUM7Ozs7dUJBQ3pHOzs7Ozs7Y0FDTixTQUFTLG1CQUNOLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFmLENBQ0ksd0JBQUMsU0FBRDtnQkFBTyxXQUFVOzBCQUFqQixDQUNJLHdCQUFDLFNBQUQ7aUJBQU8sTUFBSztpQkFBVyxTQUFTLFNBQVM7aUJBQXVCLFdBQVUsTUFBSyxhQUFZLE9BQU07a0JBQUUsR0FBRztrQkFBRyx1QkFBdUIsRUFBRSxPQUFPO2lCQUFRLEVBQUU7aUJBQUcsV0FBVTtnQkFBK0M7Ozs7MEJBQy9NLHdCQUFDLFFBQUQ7aUJBQU0sV0FBVTsyQkFBeUQ7Z0JBQWlEOzs7O3dCQUN2SDs7Ozs7eUJBQ1Asd0JBQUMsT0FBRDtnQkFBSyxXQUFVOzBCQUFmO2lCQUNJLHdCQUFDLFNBQUQ7a0JBQU8sV0FBVTs0QkFBMkU7aUJBQXlCOzs7OztpQkFDckgsd0JBQUMsU0FBRDtrQkFBTyxNQUFLO2tCQUFTLEtBQUk7a0JBQUksS0FBSTtrQkFBSyxPQUFPLFNBQVM7a0JBQWMsV0FBVSxNQUFLLGFBQVksT0FBTTttQkFBRSxHQUFHO21CQUFHLGNBQWMsU0FBUyxFQUFFLE9BQU8sS0FBSyxLQUFLO2tCQUFFLEVBQUU7a0JBQUcsV0FBVTtpQkFBOE07Ozs7O2lCQUN0WCx3QkFBQyxRQUFEO2tCQUFNLFdBQVU7NEJBQXlCO2lCQUF1Qzs7Ozs7Z0JBQy9FOzs7Ozt1QkFDSjs7Ozs7O2FBRVI7Ozs7OztXQUVSOzs7Ozs7VUFHTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNJLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsU0FBRDtjQUFTLE1BQU07Y0FBSSxXQUFVO2FBQW1COzs7O3VCQUNoRCx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBaUY7YUFBNEI7Ozs7cUJBQzFIOzs7Ozs7WUFDTCx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBaUQ7WUFBcUU7Ozs7O1lBQ25JLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLFNBQUQ7Y0FBTyxXQUFVO3dCQUFrRTthQUFrQzs7Ozt1QkFDckgsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWY7ZUFDSSx3QkFBQyxTQUFEO2dCQUFPLE1BQUs7Z0JBQVEsT0FBTyxTQUFTLHFCQUFxQjtnQkFBVyxXQUFVLE1BQUssYUFBWSxPQUFNO2lCQUFFLEdBQUc7aUJBQUcsbUJBQW1CLEVBQUUsT0FBTztnQkFBTSxFQUFFO2dCQUFHLFdBQVU7ZUFBc0g7Ozs7O2VBQ3BSLHdCQUFDLFNBQUQ7Z0JBQU8sTUFBSztnQkFBTyxPQUFPLFNBQVM7Z0JBQW1CLFdBQVUsTUFBSyxhQUFZLE9BQU07aUJBQUUsR0FBRztpQkFBRyxtQkFBbUIsRUFBRSxPQUFPO2dCQUFNLEVBQUU7Z0JBQUcsYUFBWTtnQkFBVSxXQUFXO2dCQUFHLFdBQVU7ZUFBNE47Ozs7O2VBQy9ZLFNBQVMscUJBQXFCLHdCQUFDLFVBQUQ7Z0JBQVEsTUFBSztnQkFBUyxlQUFlLGFBQVksT0FBTTtpQkFBRSxHQUFHO2lCQUFHLG1CQUFtQjtnQkFBRyxFQUFFO2dCQUFHLFdBQVU7MEJBQW1ELHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O2VBQVM7Ozs7O2NBQzVNOzs7OztxQkFDSjs7Ozt1QkFDTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtjQUFPLFdBQVU7d0JBQWtFO2FBQWdDOzs7O3VCQUNuSCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZjtlQUNJLHdCQUFDLFNBQUQ7Z0JBQU8sTUFBSztnQkFBUSxPQUFPLFNBQVMsd0JBQXdCO2dCQUFXLFdBQVUsTUFBSyxhQUFZLE9BQU07aUJBQUUsR0FBRztpQkFBRyxzQkFBc0IsRUFBRSxPQUFPO2dCQUFNLEVBQUU7Z0JBQUcsV0FBVTtlQUFzSDs7Ozs7ZUFDMVIsd0JBQUMsU0FBRDtnQkFBTyxNQUFLO2dCQUFPLE9BQU8sU0FBUztnQkFBc0IsV0FBVSxNQUFLLGFBQVksT0FBTTtpQkFBRSxHQUFHO2lCQUFHLHNCQUFzQixFQUFFLE9BQU87Z0JBQU0sRUFBRTtnQkFBRyxhQUFZO2dCQUFVLFdBQVc7Z0JBQUcsV0FBVTtlQUE0Tjs7Ozs7ZUFDclosU0FBUyx3QkFBd0Isd0JBQUMsVUFBRDtnQkFBUSxNQUFLO2dCQUFTLGVBQWUsYUFBWSxPQUFNO2lCQUFFLEdBQUc7aUJBQUcsc0JBQXNCO2dCQUFHLEVBQUU7Z0JBQUcsV0FBVTswQkFBbUQsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7ZUFBUzs7Ozs7Y0FDbE47Ozs7O3FCQUNKOzs7O3FCQUNKOzs7Ozs7V0FDSjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1gsd0JBQUMsVUFBRDtZQUNJLE1BQUs7WUFDTCxTQUFTO1lBQ1QsVUFBVTtZQUNWLFdBQVU7c0JBSmQsQ0FNSSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O3NCQUNqQix3QkFBQyxRQUFELFlBQU8sU0FBUyxpQkFBaUIsb0JBQTBCOzs7O29CQUN2RDs7Ozs7O1VBQ1A7Ozs7O1NBQ0o7Ozs7O2dCQUNKOzs7Ozs7T0FJUixjQUFjLFdBQ1gsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBNkc7UUFFdkg7Ozs7a0JBRUosd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWtFO1NBQTZCOzs7O21CQUNoSCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLFNBQUQ7V0FDSSxNQUFLO1dBQ0w7V0FDQSxPQUFPLEdBQUcsa0JBQWtCLEtBQUssTUFBTTtXQUN2QyxXQUFVO1VBQ2I7Ozs7b0JBQ0Qsd0JBQUMsVUFBRDtXQUNJLGVBQWU7WUFDWCxVQUFVLFVBQVUsVUFBVSxHQUFHLGtCQUFrQixLQUFLLE1BQU0sVUFBVTtZQUN4RSxjQUFjLElBQUk7WUFDbEIsaUJBQWlCLGNBQWMsS0FBSyxHQUFHLEdBQUk7V0FDL0M7V0FDQSxXQUFVO3FCQUVULGFBQWEsZ0JBQWdCO1VBQzFCOzs7O2tCQUNQOzs7OztpQkFDSjs7OzttQkFFSixhQUNHLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0ksd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQTZEO1dBQXlCOzs7OztXQUN2Ryx3QkFBQyxPQUFEO1lBQUssS0FBSztZQUFXLEtBQUk7WUFBVSxXQUFVO1dBQThGOzs7OztXQUMzSSx3QkFBQyxLQUFEO1lBQ0ksTUFBTTtZQUNOLFVBQVUsTUFBTSxNQUFNLFNBQVM7WUFDL0IsV0FBVTtzQkFIZCxDQUtJLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7c0JBQUMsb0JBQ3ZCOzs7Ozs7VUFDRjs7Ozs7aUJBRVI7Ozs7O2dCQUNKOzs7Ozs7TUFHUjs7Ozs7O0lBQ0o7Ozs7OztHQUdKLHlCQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUE2QyxlQUFlLHlCQUF5QixLQUFLO0lBQUk7Ozs7Y0FDN0csd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FBOEYsd0JBQUMsT0FBRDtVQUFPLE1BQU07VUFBSSxXQUFVO1NBQW1COzs7OztTQUFDO1NBQTJCLGtCQUFrQjtTQUFPO1FBQVU7Ozs7O2lCQUMzTSx3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLGVBQWUseUJBQXlCLEtBQUs7UUFBRyxXQUFVO2tCQUF5RCx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztPQUFTOzs7O2VBQy9KOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDVixrQkFBa0IsS0FBSyxFQUFFLEtBQUssVUFBVSxjQUNyQyx3QkFBQyxPQUFEO1FBQWUsV0FBVTtrQkFBekI7U0FDSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUEwRTtXQUFPLE1BQU07V0FBRTtVQUFnQjs7Ozs7O1NBQ3pHLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO3FCQUFtRCxTQUFTLFlBQVksR0FBRSxDQUFFLFFBQVEsWUFBVyxFQUFFO1NBQU87Ozs7O1NBQ3ZILHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFnSDtTQUFvQjs7Ozs7U0FDbkosd0JBQUMsT0FBRDtVQUFLLFdBQVU7cUJBQXlELFFBQVEsWUFBWSxHQUFFLENBQUUsUUFBUSxZQUFXLEVBQUU7U0FBTzs7Ozs7U0FDNUgsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDSSx3QkFBQyxVQUFEO1dBQVEsTUFBSztXQUFTLGVBQWU7WUFBRSxvQkFBb0IsS0FBSyxPQUFPO1lBQUcsc0JBQXFCLFNBQVEsS0FBSyxRQUFPLE1BQUssRUFBRSxRQUFRLEdBQUcsQ0FBQztZQUFHLElBQUksa0JBQWtCLFVBQVUsR0FBRzthQUFFLHlCQUF5QixLQUFLO2FBQUcsa0JBQWtCLEtBQUs7YUFBRyxVQUFVLDZCQUE2QjtZQUFHO1dBQUU7V0FBRyxXQUFVO3FCQUF1RztVQUFnQjs7OztvQkFDelosd0JBQUMsVUFBRDtXQUFRLE1BQUs7V0FBUyxlQUFlLHNCQUFxQixTQUFRLEtBQUssUUFBTyxNQUFLLEVBQUUsUUFBUSxHQUFHLENBQUM7V0FBRyxXQUFVO3FCQUFxTDtVQUFjOzs7O2tCQUNoVDs7Ozs7O1FBQ0o7VUFUSzs7OztjQVNMLENBQ1I7TUFDQTs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsZUFBZTtTQUFFLGtCQUFrQixTQUFTLEVBQUUsS0FBSyxjQUFjLG9CQUFvQixLQUFLLE9BQU8sQ0FBQztTQUFHLHlCQUF5QixLQUFLO1NBQUcsa0JBQWtCLEtBQUs7U0FBRyxVQUFVLEdBQUcsa0JBQWtCLE9BQU8seUJBQXlCO1FBQUc7UUFBRyxXQUFVO2tCQUFxRztPQUFzQjs7OztpQkFDaFksd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxlQUFlLHlCQUF5QixLQUFLO1FBQUcsV0FBVTtrQkFBbUw7T0FBYTs7OztlQUMvUTs7Ozs7O0tBQ0o7Ozs7O1lBQ0o7Ozs7OztHQXlEVCx3QkFBQyxjQUFEO0lBQ0EsUUFBUSxhQUFhO0lBQ3JCLGVBQWUsaUJBQWdCLFVBQVM7S0FBRSxHQUFHO0tBQU0sUUFBUTtJQUFNLEVBQUU7SUFDbkUsV0FBVyxhQUFhO0lBQ3hCLE9BQU8sYUFBYTtJQUNwQixTQUFTLGFBQWE7SUFDdEIsU0FBUyxhQUFhLFdBQVc7SUFDakMsYUFBYSxhQUFhLGVBQWU7R0FDNUM7Ozs7O0dBR0csd0JBQUMsa0JBQUQ7SUFDSSxRQUFRO0lBQ1IsTUFBTTtJQUNOLGVBQWUsYUFBYSxLQUFLO0lBQ2pDLFVBQVU7R0FDYjs7Ozs7R0FHRCx3QkFBQyxrQkFBRDtJQUNJLFFBQVE7SUFDUixlQUFlLGVBQWUsS0FBSztJQUNuQyxnQkFBZ0I7SUFDaEIsV0FBVyxNQUFNLFNBQVM7R0FDN0I7Ozs7O0dBR0Qsd0JBQUMsb0JBQUQ7SUFDSSxRQUFRO0lBQ1IsZUFBZSxxQkFBcUIsS0FBSztJQUN6QyxnQkFBZ0IsVUFBVSxTQUFTLFVBQVUsTUFBTSxTQUFTO0dBQy9EOzs7OztHQUdELHdCQUFDLHNCQUFEO0lBQ0ksUUFBUTtJQUNSLGVBQWUsbUJBQW1CLEtBQUs7SUFDdkMsUUFBUTtJQUNSLGVBQWUsTUFBTSxpQkFBaUIsTUFBTSxrQkFBa0IsS0FBSyxJQUFLLE1BQU0saUJBQWlCLE1BQU0sa0JBQWtCLElBQUs7SUFDNUgsWUFBWTtHQUNmOzs7OztHQUdELHdCQUFDLG9CQUFEO0lBQ0ksUUFBUSxDQUFDLENBQUM7SUFDVixLQUFLLGVBQWU7SUFDcEIsS0FBSyxlQUFlO0lBQ3BCLGVBQWUsaUJBQWlCLElBQUk7R0FDdkM7Ozs7O0dBR0Qsd0JBQUMsT0FBRDtJQUFLLFdBQVcsNEdBQ1oscUJBQ00sNERBQ0E7Y0FIVixDQUtTLGVBQ0csd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVJLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsZUFBZTtRQUNYLGVBQWUsS0FBSztRQUNwQixjQUFjO09BQ2xCO09BQ0EsVUFBVTtPQUNWLFdBQVcsa0dBQ1AsVUFDTSwrREFDQTtpQkFWZCxDQWFJLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7aUJBQ2pCLHdCQUFDLFFBQUQsWUFBTyxTQUFTLGlCQUFpQixVQUFVLHNCQUFzQixtQkFBeUI7Ozs7ZUFDdEY7Ozs7OztNQUdSLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsZUFBZTtRQUNYLGVBQWUsS0FBSztRQUNwQixPQUFPLEtBQUssTUFBTSxNQUFNLFNBQVMsdUJBQXVCLE1BQU0sTUFBTSxRQUFRO09BQ2hGO09BQ0EsV0FBVTtpQkFOZCxDQVFJLHdCQUFDLEtBQUQ7UUFBSyxNQUFNO1FBQUksV0FBVTtPQUFvQzs7OztpQkFDN0Qsd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztlQUN6Qjs7Ozs7O01BR1Isd0JBQUMsVUFBRDtPQUNJLE1BQUs7T0FDTCxlQUFlO1FBQ1gsZUFBZSxLQUFLO1FBQ3BCLG9CQUFvQjtPQUN4QjtPQUNBLFVBQVU7T0FDVixXQUFVO2lCQVBkLENBU0ssY0FBYyx3QkFBQyxNQUFEO1FBQU0sTUFBTTtRQUFJLFdBQVU7T0FBa0I7Ozs7a0JBQUksd0JBQUMsT0FBRDtRQUFPLE1BQU07UUFBSSxXQUFVO09BQW9DOzs7O2lCQUM5SCx3QkFBQyxRQUFELFlBQU8sYUFBYSxpQkFBaUIsY0FBYyxpQkFBaUIsZUFBcUI7Ozs7ZUFDckY7Ozs7OztNQUdSLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsZUFBZSxvQkFBbUIsU0FBUSxDQUFDLElBQUk7T0FDL0MsV0FBVTtpQkFIZCxDQUtJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ssa0JBQWtCLHdCQUFDLGFBQUQ7U0FBYSxNQUFNO1NBQUksV0FBVTtRQUFvQzs7OzttQkFBSSx3QkFBQyxZQUFEO1NBQVksTUFBTTtTQUFJLFdBQVU7UUFBa0I7Ozs7a0JBQzlJLHdCQUFDLFFBQUQsWUFBTSxZQUFlOzs7O2dCQUNwQjs7Ozs7aUJBQ0wsd0JBQUMsUUFBRDtRQUFNLFdBQVcsb0RBQW9ELGtCQUFrQixpRUFBaUU7a0JBQ25KLGtCQUFrQixPQUFPO09BQ3hCOzs7O2VBQ0Y7Ozs7OztNQUduQyxjQUFjLGVBQ1g7T0FDSSx3QkFBQyxPQUFELEVBQUssV0FBVSw2Q0FBOEM7Ozs7O09BRTdELHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsZUFBZTtTQUFFLGVBQWUsS0FBSztTQUFHLGVBQWUsSUFBSTtRQUFHO1FBQzlELFdBQVU7a0JBSGQsQ0FLSSx3QkFBQyxVQUFEO1NBQVUsTUFBTTtTQUFJLFdBQVU7UUFBNkM7Ozs7a0JBQzNFLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7Z0JBQ3RCOzs7Ozs7T0FFUix3QkFBQyxVQUFEO1FBQ0ksTUFBSztRQUNMLGFBQVU7UUFDVixlQUFlO1NBQUUsZUFBZSxLQUFLO1NBQUcsbUJBQWtCLFNBQVEsQ0FBQyxJQUFJO1NBQUcsc0JBQXNCLElBQUksSUFBSSxDQUFDO1FBQUc7UUFDNUcsV0FBVTtrQkFKZCxDQU1JLHdCQUFDLE9BQUQ7U0FBTyxNQUFNO1NBQUksV0FBVTtRQUFpRDs7OztrQkFDNUUsd0JBQUMsUUFBRCxZQUFPLGlCQUFpQiwyQkFBMkIsbUJBQXlCOzs7O2dCQUN4RTs7Ozs7O09BRVIsd0JBQUMsVUFBRDtRQUNJLE1BQUs7UUFDTCxlQUFlO1NBQUUsZUFBZSxLQUFLO1NBQUcsV0FBVztRQUFHO1FBQ3RELFVBQVUsZ0JBQWdCO1FBQzFCLFdBQVU7a0JBSmQ7U0FNSSx3QkFBQyxPQUFEO1VBQU8sTUFBTTtVQUFJLFdBQVU7U0FBMkI7Ozs7O1NBQ3RELHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7OztTQUNoQix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUQ7U0FBWTs7Ozs7UUFDekU7Ozs7OztPQUVSLHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsZUFBZTtTQUFFLGVBQWUsS0FBSztTQUFHLFdBQVc7UUFBRztRQUN0RCxVQUFVLGdCQUFnQixRQUFRLFNBQVM7UUFDM0MsV0FBVTtrQkFKZDtTQU1JLHdCQUFDLE9BQUQ7VUFBTyxNQUFNO1VBQUksV0FBVTtTQUEyQjs7Ozs7U0FDdEQsd0JBQUMsUUFBRCxZQUFNLE9BQVU7Ozs7O1NBQ2hCLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpRDtTQUFZOzs7OztRQUN6RTs7Ozs7O09BRVIsd0JBQUMsVUFBRDtRQUNJLE1BQUs7UUFDTCxlQUFlO1NBQUUsZUFBZSxLQUFLO1NBQUcsc0JBQXNCO1FBQUc7UUFDakUsVUFBVSxVQUFVLFdBQVc7UUFDL0IsV0FBVTtrQkFKZCxDQU1JLHdCQUFDLFVBQUQ7U0FBVSxNQUFNO1NBQUksV0FBVTtRQUE2Qzs7OztrQkFDM0Usd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztnQkFDekI7Ozs7OztPQUVSLHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsZUFBZTtTQUFFLGVBQWUsS0FBSztTQUFHLHdCQUF3QjtRQUFHO1FBQ25FLFVBQVUsVUFBVSxXQUFXO1FBQy9CLFdBQVU7a0JBSmQsQ0FNSSx3QkFBQyxRQUFEO1NBQVEsTUFBTTtTQUFJLFdBQVU7UUFBWTs7OztrQkFDeEMsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztnQkFDeEI7Ozs7OztNQUNWOzs7OztNQUdOLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDZDQUE4Qzs7Ozs7TUFHakMsd0JBQUMsT0FBRCxFQUFLLFdBQVUsNkNBQThDOzs7OztNQUc3RCx3QkFBQyxVQUFEO09BQ0ksTUFBSztPQUNMLGVBQWU7UUFDWCxlQUFlLEtBQUs7UUFDcEIsSUFBSSxjQUFjLFNBQVM7U0FDdkIsY0FBYyxRQUFRLFNBQVM7VUFBRSxLQUFLO1VBQUcsVUFBVTtTQUFTLENBQUM7UUFDakU7UUFDQSxPQUFPLFNBQVM7U0FBRSxLQUFLO1NBQUcsVUFBVTtRQUFTLENBQUM7T0FDbEQ7T0FDQSxXQUFVO2lCQVRkLENBV0ksd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OztpQkFDdEIsd0JBQUMsUUFBRCxZQUFNLGlCQUFvQjs7OztlQUN0Qjs7Ozs7O0tBQ1A7Ozs7O2NBSVQsd0JBQUMsVUFBRDtLQUNJLE1BQUs7S0FDTCxlQUFlLGdCQUFlLFNBQVEsQ0FBQyxJQUFJO0tBQzNDLE9BQU07S0FDTixXQUFXLHNKQUNQLFVBQ00sa0RBQ0E7ZUFQZDtNQVVLLFdBQ0csd0JBQUMsUUFBRCxFQUFNLFdBQVUsd0hBQXlIOzs7OztNQUU1SSxXQUNHLHdCQUFDLFFBQUQsRUFBTSxXQUFVLDJHQUE0Rzs7Ozs7TUFFL0gsY0FBYyx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7O2lCQUFJLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O0tBQ3REOzs7OztZQUNQOzs7Ozs7R0FHVCx3QkFBQyxnQkFBRDtJQUNJLFFBQVE7SUFDUixlQUFlO0tBQ1gsbUJBQW1CLEtBQUs7S0FDeEIsYUFBYSxXQUFXO0lBQzVCO0lBQ0Esa0JBQWtCO0tBQ2QsbUJBQW1CLEtBQUs7S0FDeEIsYUFBYSxXQUFXO0tBQ3hCLElBQUk7TUFDQSxhQUFhLFFBQVEsaUNBQWlDLE1BQU07S0FDaEUsU0FBUyxHQUFHLENBQUM7SUFDakI7SUFDQSxPQUFPO0tBQ0g7TUFDSSxVQUFVO01BQ1YsT0FBTztNQUNQLGFBQWE7TUFDYixNQUFNLHdCQUFDLFNBQUQsRUFBUyxNQUFNLEdBQUs7Ozs7O01BQzFCLFdBQVc7TUFDWCxPQUFPO01BQ1AsY0FBYyxhQUFhLFdBQVc7S0FDMUM7S0FDQTtNQUNJLFVBQVU7TUFDVixPQUFPO01BQ1AsYUFBYTtNQUNiLE1BQU0sd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7TUFDM0IsV0FBVztNQUNYLE9BQU87TUFDUCxjQUFjLGFBQWEsV0FBVztLQUMxQztLQUNBO01BQ0ksVUFBVTtNQUNWLE9BQU87TUFDUCxhQUFhO01BQ2IsTUFBTSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztNQUN2QixXQUFXO01BQ1gsT0FBTztNQUNQLGNBQWMsYUFBYSxXQUFXO0tBQzFDO0tBQ0E7TUFDSSxVQUFVO01BQ1YsT0FBTztNQUNQLGFBQWE7TUFDYixNQUFNLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7O01BQ3hCLFdBQVc7TUFDWCxPQUFPO01BQ1AsY0FBYyxhQUFhLFdBQVc7S0FDMUM7S0FDQTtNQUNJLFVBQVU7TUFDVixPQUFPO01BQ1AsYUFBYTtNQUNiLE1BQU0sd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7Ozs7TUFDOUIsV0FBVztNQUNYLE9BQU87TUFDUCxjQUFjLGFBQWEsVUFBVTtLQUN6QztLQUNBO01BQ0ksVUFBVTtNQUNWLE9BQU87TUFDUCxhQUFhO01BQ2IsTUFBTSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztNQUN6QixXQUFXO01BQ1gsT0FBTztNQUNQLGNBQWM7T0FDVixhQUFhLE9BQU87T0FDcEIsZ0JBQWdCO01BQ3BCO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixPQUFPO01BQ1AsYUFBYTtNQUNiLE1BQU0sd0JBQUMsS0FBRCxFQUFLLE1BQU0sR0FBSzs7Ozs7TUFDdEIsV0FBVztNQUNYLE9BQU87S0FDWDtLQUNBO01BQ0ksVUFBVTtNQUNWLE9BQU87TUFDUCxhQUFhO01BQ2IsTUFBTSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztNQUN2QixXQUFXO01BQ1gsT0FBTztLQUNYO0tBQ0E7TUFDSSxVQUFVO01BQ1YsT0FBTztNQUNQLGFBQWE7TUFDYixNQUFNLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7O01BQ3hCLFdBQVc7TUFDWCxPQUFPO0tBQ1g7SUFDSjtHQUNIOzs7OztFQUNBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJGb3JtQnVpbGRlci5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2ssIHVzZVJlZiwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7XG4gICAgU2F2ZSwgUGx1cywgVHJhc2gyLCBDaGV2cm9uVXAsIENoZXZyb25Eb3duLFxuICAgIEdsb2JlLCBMb2NrLCBBcnJvd0xlZnQsIFVwbG9hZCwgRmlsZVVwLCBJbWFnZSwgTXVzaWMsIERvd25sb2FkLFxuICAgIENvZGUsIENhbGN1bGF0b3IsIEV5ZSwgRXllT2ZmLCBYLCBTcGFya2xlcyxcbiAgICBDb3B5LCBVbmRvMiwgUmVkbzIsIEZpbGVEb3duLCBXYW5kMiwgVG9nZ2xlTGVmdCwgVG9nZ2xlUmlnaHQsXG4gICAgU2hpZWxkQWxlcnQsIFBhbGV0dGUsIENoZWNrU3F1YXJlLCBNb3JlSG9yaXpvbnRhbCwgTW9yZVZlcnRpY2FsLCBDaGV2cm9uRG93biBhcyBDaGV2RG93bixcbiAgICBTbGlkZXJzLCBTaGFyZTIsIEhlbHBDaXJjbGUsIENvbXBhc3MsIExvYWRlcjIsIENvbHVtbnNcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBTaWRlYmFyIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvbGF5b3V0L1NpZGViYXInO1xuaW1wb3J0IENvbmZpcm1Nb2RhbCBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpL0NvbmZpcm1Nb2RhbCc7XG5pbXBvcnQgT25ib2FyZGluZ1RvdXIgZnJvbSAnLi4vLi4vY29tcG9uZW50cy91aS9PbmJvYXJkaW5nVG91cic7XG5pbXBvcnQge1xuICAgIGdldEZvcm1CeUlkLCBnZXRRdWVzdGlvbnMsIHNhdmVRdWVzdGlvbnMsIHVwZGF0ZUZvcm0sXG4gICAgdG9nZ2xlUHVibGlzaEZvcm0sIHVwZGF0ZUZvcm1TZXR0aW5ncywgZ2V0Rm9ybVNoYXJlLFxuICAgIHVwbG9hZEZvcm1CYW5uZXIsIGNsZWFyU2Vzc2lvbiwgYXNzZXRVcmwsXG4gICAgZGVsZXRlUXVlc3Rpb24sIHVwbG9hZFF1ZXN0aW9uSW1hZ2UsIHVwbG9hZFF1ZXN0aW9uQXVkaW8sXG4gICAgdXBsb2FkT3B0aW9uSW1hZ2UsXG4gICAgdGVtcGxhdGVEb3dubG9hZFVybCwgY3JlYXRlRm9ybSwgZGVsZXRlQWxsUXVlc3Rpb25zLCBwcmV2aWV3SW1wb3J0UXVlc3Rpb25zXG59IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgZ2V0R2VtaW5pQXBpS2V5LCBBVkFJTEFCTEVfTU9ERUxTLCByZXZpc2VRdWVzdGlvbldpdGhBSSwgYnVsa1JldmlzZVF1ZXN0aW9uc1dpdGhBSSB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FpU2VydmljZSc7XG5pbXBvcnQgUmljaENvbnRlbnRSZW5kZXJlciBmcm9tICcuLi8uLi91dGlscy9SaWNoQ29udGVudFJlbmRlcmVyJztcbmltcG9ydCBCbG9ja1F1ZXN0aW9uRWRpdG9yIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdWkvQmxvY2tRdWVzdGlvbkVkaXRvcic7XG5pbXBvcnQgTWF0aEFuZENvZGVNb2RhbCBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpL01hdGhBbmRDb2RlTW9kYWwnO1xuaW1wb3J0IEltYWdlTGlnaHRib3hNb2RhbCBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpL0ltYWdlTGlnaHRib3hNb2RhbCc7XG5pbXBvcnQgQUlHZW5lcmF0b3JNb2RhbCBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpL0FJR2VuZXJhdG9yTW9kYWwnO1xuaW1wb3J0IEFJRm9ybUJ1aWxkZXJNb2RhbCBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VpL0FJRm9ybUJ1aWxkZXJNb2RhbCc7XG5pbXBvcnQgSW1wb3J0UXVlc3Rpb25zTW9kYWwgZnJvbSAnLi4vLi4vY29tcG9uZW50cy91aS9JbXBvcnRRdWVzdGlvbnNNb2RhbCc7XG5cbmNvbnN0IGVudlVybCA9IGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9CQVNFX1VSTDtcbmNvbnN0IEFQSV9CQVNFX1VSTCA9IChlbnZVcmwgIT09IHVuZGVmaW5lZCAmJiBlbnZVcmwgIT09ICcnKVxuICAgID8gZW52VXJsIFxuICAgIDogKGltcG9ydC5tZXRhLmVudi5ERVYgPyAnJyA6ICdodHRwczovL2FwaS5mb3JtdXAubXkuaWQnKTtcbmNvbnN0IEZST05URU5EX0JBU0VfVVJMID0gaW1wb3J0Lm1ldGEuZW52LlZJVEVfRlJPTlRFTkRfVVJMIHx8ICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gOiAnaHR0cHM6Ly9mb3JtdXAubXkuaWQnKTtcblxuY29uc3QgUVVFU1RJT05fVFlQRVMgPSBbXG4gICAgeyBpZDogMSwgbGFiZWw6ICdFc3NheSAvIFNob3J0IEFuc3dlcicgfSxcbiAgICB7IGlkOiAyLCBsYWJlbDogJ011bHRpcGxlIENob2ljZScgfSxcbiAgICB7IGlkOiAzLCBsYWJlbDogJ0NoZWNrYm94JyB9LFxuICAgIHsgaWQ6IDQsIGxhYmVsOiAnRGF0ZSBUaW1lJyB9LFxuICAgIHsgaWQ6IDUsIGxhYmVsOiAnVHJ1ZSAvIEZhbHNlJyB9LFxuXTtcblxuY29uc3QgbmV3UXVlc3Rpb24gPSAob3JkZXIpID0+ICh7XG4gICAgX2lkOiBgcV9uZXdfJHtEYXRlLm5vdygpfV8ke29yZGVyfWAsXG4gICAgaWQ6IG51bGwsXG4gICAgcXVlc3Rpb246ICcnLFxuICAgIHR5cGVJZDogMixcbiAgICBxdWVzdGlvbk9yZGVyOiBvcmRlcixcbiAgICBpc1JlcXVpcmVkOiB0cnVlLFxuICAgIGlzU2NvcmFibGU6IHRydWUsXG4gICAgcG9pbnRzOiBudWxsLFxuICAgIGNvcnJlY3RBbnN3ZXI6ICcnLFxuICAgIG9wdGlvbnM6IFtcbiAgICAgICAgeyBvcHRpb25UZXh0OiAnJywgaXNDb3JyZWN0OiBmYWxzZSwgb3B0aW9uSW1hZ2U6IG51bGwgfSxcbiAgICAgICAgeyBvcHRpb25UZXh0OiAnJywgaXNDb3JyZWN0OiBmYWxzZSwgb3B0aW9uSW1hZ2U6IG51bGwgfVxuICAgIF0sXG4gICAgcXVlc3Rpb25JbWFnZTogbnVsbCxcbiAgICBxdWVzdGlvbkF1ZGlvOiBudWxsLFxufSk7XG5cbmNvbnN0IG5lZWRzT3B0aW9ucyA9ICh0eXBlSWQpID0+IFsyLCAzXS5pbmNsdWRlcyh0eXBlSWQpO1xuXG4vLyBIZWxwZXI6IE5vcm1hbGl6ZSBpbXBvcnRlZCBvciBsb2FkZWQgb3B0aW9uIChzdHJpcHMgW0JFTkFSXSBvciAqIG1hcmtlciwgcHJlc2VydmVzIG9wdGlvbkltYWdlKVxuY29uc3Qgbm9ybWFsaXplSW1wb3J0ZWRPcHRpb24gPSAobykgPT4ge1xuICAgIGxldCB0ZXh0ID0gKG8ub3B0aW9uVGV4dCB8fCBvLk9wdGlvblRleHQgfHwgJycpLnRyaW0oKTtcbiAgICBsZXQgaXNDb3JyZWN0ID0gby5pc0NvcnJlY3QgPT09IHRydWUgfHwgby5Jc0NvcnJlY3QgPT09IHRydWU7XG5cbiAgICBpZiAodGV4dC5zdGFydHNXaXRoKCdbQkVOQVJdJykpIHtcbiAgICAgICAgaXNDb3JyZWN0ID0gdHJ1ZTtcbiAgICAgICAgdGV4dCA9IHRleHQucmVwbGFjZSgvXlxcW0JFTkFSXFxdXFxzKi9pLCAnJykudHJpbSgpO1xuICAgIH0gZWxzZSBpZiAodGV4dC5zdGFydHNXaXRoKCcqJykpIHtcbiAgICAgICAgaXNDb3JyZWN0ID0gdHJ1ZTtcbiAgICAgICAgdGV4dCA9IHRleHQucmVwbGFjZSgvXlxcKlxccyovLCAnJykudHJpbSgpO1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICAgIC4uLm8sXG4gICAgICAgIG9wdGlvblRleHQ6IHRleHQsXG4gICAgICAgIGlzQ29ycmVjdCxcbiAgICAgICAgb3B0aW9uSW1hZ2U6IG8ub3B0aW9uSW1hZ2UgfHwgby5pbWFnZSB8fCBvLmltYWdlVXJsIHx8IG51bGwsXG4gICAgfTtcbn07XG5cbmNvbnN0IG5vcm1hbGl6ZVF1ZXN0aW9uT3B0aW9ucyA9IChxKSA9PiB7XG4gICAgY29uc3QgcmF3T3B0aW9ucyA9IHEub3B0aW9ucyB8fCBxLm9wdGlvblF1ZXN0aW9ucyB8fCBbXTtcbiAgICBsZXQgb3B0cyA9IHJhd09wdGlvbnMubWFwKG5vcm1hbGl6ZUltcG9ydGVkT3B0aW9uKTtcblxuICAgIC8vIElmIFBHICh0eXBlSWQgMikgb3IgQ2hlY2tib3ggKHR5cGVJZCAzKSBhbmQgbm8gb3B0aW9uIGlzIG1hcmtlZCBjb3JyZWN0LCBidXQgY29ycmVjdEFuc3dlciBtYXRjaGVzXG4gICAgY29uc3QgaXNDaG9pY2UgPSBxLnR5cGVJZCA9PT0gMiB8fCBxLnR5cGVJZCA9PT0gMyB8fCBxLnR5cGVfaWQgPT09IDIgfHwgcS50eXBlX2lkID09PSAzO1xuICAgIGlmIChpc0Nob2ljZSAmJiBxLmNvcnJlY3RBbnN3ZXIgJiYgIW9wdHMuc29tZShvID0+IG8uaXNDb3JyZWN0KSkge1xuICAgICAgICBjb25zdCBjYUxpc3QgPSBTdHJpbmcocS5jb3JyZWN0QW5zd2VyKS5zcGxpdCgvWyw7fF0vKS5tYXAocyA9PiBzLnRyaW0oKS50b0xvd2VyQ2FzZSgpKTtcbiAgICAgICAgb3B0cyA9IG9wdHMubWFwKG8gPT4ge1xuICAgICAgICAgICAgaWYgKGNhTGlzdC5pbmNsdWRlcyhvLm9wdGlvblRleHQudHJpbSgpLnRvTG93ZXJDYXNlKCkpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgLi4ubywgaXNDb3JyZWN0OiB0cnVlIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbztcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG9wdHMubGVuZ3RoID4gMCA/IG9wdHMgOiBbeyBvcHRpb25UZXh0OiAnJywgaXNDb3JyZWN0OiBmYWxzZSwgb3B0aW9uSW1hZ2U6IG51bGwgfV07XG59O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBGb3JtQnVpbGRlcigpIHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXMoKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgICBjb25zdCBbZm9ybSwgc2V0Rm9ybV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbcXVlc3Rpb25zLCBzZXRRdWVzdGlvbnNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICAgIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3B1Ymxpc2hpbmcsIHNldFB1Ymxpc2hpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZSgncXVlc3Rpb25zJyk7XG4gICAgY29uc3QgW3NoYXJlSW5mbywgc2V0U2hhcmVJbmZvXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtxckJsb2JVcmwsIHNldFFyQmxvYlVybF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbdG9hc3QsIHNldFRvYXN0XSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtjb3BpZWRMaW5rLCBzZXRDb3BpZWRMaW5rXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbbGlnaHRib3hJbWFnZSwgc2V0TGlnaHRib3hJbWFnZV0gPSB1c2VTdGF0ZShudWxsKTtcblxuICAgIC8vIE1vZGFsIHN0YXRlIGZvciBDb2RlICYgS2FUZVggTWF0aCBpbnNlcnRpb24gKGZvciBRdWVzdGlvbiBvciBPcHRpb24pXG4gICAgY29uc3QgW21vZGFsT3Blbiwgc2V0TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbbW9kYWxNb2RlLCBzZXRNb2RhbE1vZGVdID0gdXNlU3RhdGUoJ21hdGgnKTtcbiAgICBjb25zdCBbbW9kYWxUYXJnZXQsIHNldE1vZGFsVGFyZ2V0XSA9IHVzZVN0YXRlKHsgdHlwZTogJ3F1ZXN0aW9uJywgcUlkeDogbnVsbCwgb0lkeDogbnVsbCB9KTtcblxuICAgIC8vIEFJIFF1aXogR2VuZXJhdG9yIE1vZGFsIHN0YXRlXG4gICAgY29uc3QgW2FpTW9kYWxPcGVuLCBzZXRBaU1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICAvLyBBSSBGb3JtIEJ1aWxkZXIgTW9kYWwgc3RhdGVcbiAgICBjb25zdCBbYWlGb3JtQnVpbGRlck9wZW4sIHNldEFpRm9ybUJ1aWxkZXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIC8vIEEtMjogSW1wb3J0IFF1ZXN0aW9ucyBNb2RhbCAocHJldmlldyArIGNvbW1pdClcbiAgICBjb25zdCBbaW1wb3J0TW9kYWxPcGVuLCBzZXRJbXBvcnRNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgLy8gQy0yOiBQYWdpbmF0aW9uICYgU2VhcmNoIHN0YXRlIGZvciBxdWVzdGlvbnMgbGlzdFxuICAgIGNvbnN0IFtjdXJyZW50UGFnZSwgc2V0Q3VycmVudFBhZ2VdID0gdXNlU3RhdGUoMSk7XG4gICAgY29uc3QgW3BhZ2VTaXplLCBzZXRQYWdlU2l6ZV0gPSB1c2VTdGF0ZSgyNSk7XG4gICAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtkZWJvdW5jZWRTZWFyY2gsIHNldERlYm91bmNlZFNlYXJjaF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW3RvdGFsUXVlc3Rpb25zLCBzZXRUb3RhbFF1ZXN0aW9uc10gPSB1c2VTdGF0ZSgwKTtcblxuICAgIC8vIEFJIFJldmlzZSBwZXItcXVlc3Rpb24gaW5saW5lIHBhbmVsXG4gICAgY29uc3QgW2FpUmV2aXNlT3BlbklkeCwgc2V0QWlSZXZpc2VPcGVuSWR4XSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFthaVJldmlzZUluc3RydWN0aW9uLCBzZXRBaVJldmlzZUluc3RydWN0aW9uXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbYWlSZXZpc2luZywgc2V0QWlSZXZpc2luZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2FpUmV2aXNlRXJyb3IsIHNldEFpUmV2aXNlRXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtyZXZpc2VNb2RlbCwgc2V0UmV2aXNlTW9kZWxdID0gdXNlU3RhdGUoKCkgPT4geyBjb25zdCBtID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2Zvcm11cF9zZWxlY3RlZF9tb2RlbF9jaGF0Jyk7IHJldHVybiBtICYmICFtLmluY2x1ZGVzKCctcHJvJykgJiYgQVZBSUxBQkxFX01PREVMUy5zb21lKG1vZGVsID0+IG1vZGVsLmlkID09PSBtKSA/IG0gOiAnZ2VtaW5pLTMuNi1mbGFzaCc7IH0pO1xuXG4gICAgLy8gQS03OiBCdWxrIEFJIHJldmlzZVxuICAgIGNvbnN0IFtidWxrUmV2aXNlTW9kZSwgc2V0QnVsa1JldmlzZU1vZGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtidWxrUmV2aXNlU2VsZWN0ZWQsIHNldEJ1bGtSZXZpc2VTZWxlY3RlZF0gPSB1c2VTdGF0ZShuZXcgU2V0KCkpO1xuICAgIGNvbnN0IFtidWxrUmV2aXNlSW5zdHJ1Y3Rpb24sIHNldEJ1bGtSZXZpc2VJbnN0cnVjdGlvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2J1bGtSZXZpc2luZywgc2V0QnVsa1JldmlzaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbYnVsa1JldmlzZVByZXZpZXcsIHNldEJ1bGtSZXZpc2VQcmV2aWV3XSA9IHVzZVN0YXRlKFtdKTsgLy8gW3tpZHgsIG9yaWdpbmFsLCByZXZpc2VkfV1cbiAgICBjb25zdCBbYnVsa1JldmlzZVByZXZpZXdPcGVuLCBzZXRCdWxrUmV2aXNlUHJldmlld09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgLy8gTGl2ZSBwcmV2aWV3IHRvZ2dsZSBwZXIgcXVlc3Rpb25cbiAgICBjb25zdCBbcHJldmlld1Zpc2liaWxpdHksIHNldFByZXZpZXdWaXNpYmlsaXR5XSA9IHVzZVN0YXRlKHt9KTtcblxuICAgIC8vIFNwbGl0LVNjcmVlbiBEdWFsIFZpZXcgKFNpZGUtYnktc2lkZSBFZGl0b3IgJiBMaXZlIFByZXZpZXcpXG4gICAgY29uc3QgW2lzU3BsaXRQcmV2aWV3LCBzZXRJc1NwbGl0UHJldmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICAvLyBBLTI6IEFjdGlvbnMgZHJvcGRvd24gbWVudVxuICAgIGNvbnN0IFthY3Rpb25zTWVudU9wZW4sIHNldEFjdGlvbnNNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgYWN0aW9uc01lbnVSZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgICAvLyBCVUctMzogQ29uZmlybU1vZGFsIHN0YXRlIChyZXBsYWNlcyB3aW5kb3cuY29uZmlybSlcbiAgICBjb25zdCBbY29uZmlybU1vZGFsLCBzZXRDb25maXJtTW9kYWxdID0gdXNlU3RhdGUoeyBpc09wZW46IGZhbHNlLCB0aXRsZTogJycsIG1lc3NhZ2U6ICcnLCBvbkNvbmZpcm06IG51bGwsIHZhcmlhbnQ6ICdkYW5nZXInIH0pO1xuXG4gICAgLy8gRkVBVC0xMTogRGlydHkgc3RhdGUgaW5kaWNhdG9yXG4gICAgY29uc3QgW2lzRGlydHksIHNldElzRGlydHldID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgLy8gRkVBVC0xMjogVW5kby9SZWRvIGhpc3RvcnlcbiAgICBjb25zdCBbaGlzdG9yeSwgc2V0SGlzdG9yeV0gPSB1c2VTdGF0ZShbXSk7XG4gICAgY29uc3QgW2hpc3RvcnlJbmRleCwgc2V0SGlzdG9yeUluZGV4XSA9IHVzZVN0YXRlKC0xKTtcbiAgICBjb25zdCBoaXN0b3J5VXBkYXRpbmdSZWYgPSB1c2VSZWYoZmFsc2UpO1xuICAgIC8vIEJVRy0xLzIvMyBGSVg6IGtlZXAgbWlycm9yIHJlZnMgc28gcHVzaEhpc3RvcnkgLyBoYW5kbGVVbmRvIC8gaGFuZGxlUmVkb1xuICAgIC8vIGFsd2F5cyByZWFkIHRoZSAqY3VycmVudCogdmFsdWUgd2l0aG91dCBzdGFsZS1jbG9zdXJlIGlzc3Vlcy5cbiAgICAvLyBQcmV2aW91c2x5IHB1c2hIaXN0b3J5IGNsb3NlZCBvdmVyIGBoaXN0b3J5SW5kZXhgIGZyb20gaXRzIHVzZUNhbGxiYWNrIGRlcHMsXG4gICAgLy8gd2hpY2ggY2F1c2VkIHRoZSB3cm9uZyBzbGljZSBpbmRleCB3aGVuIGNhbGxlZCBiZWZvcmUgYSByZS1yZW5kZXIsIGFuZCB0aGVcbiAgICAvLyBkZWJvdW5jZWQgdGV4dC1lZGl0IHBhdGggY2FwdHVyZWQgYSBzdGFsZSBwdXNoSGlzdG9yeSB0aGF0IHVzZWQgYW4gb2xkIGluZGV4LlxuICAgIGNvbnN0IGhpc3RvcnlSZWYgPSB1c2VSZWYoW10pO1xuICAgIGNvbnN0IGhpc3RvcnlJbmRleFJlZiA9IHVzZVJlZigtMSk7XG4gICAgLy8gTWlycm9yIHJlZiBzbyBhc3luYyBoYW5kbGVycyAodXBsb2FkIGdhbWJhci9hdWRpbykgYWx3YXlzIHJlYWQgdGhlXG4gICAgLy8gbGF0ZXN0IHF1ZXN0aW9ucyBzdGF0ZSB3aXRob3V0IHN0YWxlLWNsb3N1cmUgaXNzdWVzLlxuICAgIGNvbnN0IHF1ZXN0aW9uc1JlZiA9IHVzZVJlZihxdWVzdGlvbnMpO1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7IHF1ZXN0aW9uc1JlZi5jdXJyZW50ID0gcXVlc3Rpb25zOyB9LCBbcXVlc3Rpb25zXSk7XG4gICAgLy8gQlVHLTM6IGRlYm91bmNlIHRpbWVyIHJlZiBmb3IgdGV4dC1lZGl0IGhpc3RvcnlcbiAgICBjb25zdCB0ZXh0RWRpdERlYm91bmNlUmVmID0gdXNlUmVmKG51bGwpO1xuXG4gICAgLy8gRkVBVC0xNDogQXV0b3NhdmVcbiAgICBjb25zdCBbYXV0b3NhdmVFbmFibGVkLCBzZXRBdXRvc2F2ZUVuYWJsZWRdID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgICAgICB0cnkgeyByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2Zvcm11cF9hdXRvc2F2ZV9wcmVmJykgPT09ICd0cnVlJzsgfSBjYXRjaCB7IHJldHVybiBmYWxzZTsgfVxuICAgIH0pO1xuICAgIGNvbnN0IGF1dG9zYXZlSW50ZXJ2YWxSZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgY29uc3QgW2F1dG9zYXZlVG9hc3QsIHNldEF1dG9zYXZlVG9hc3RdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFthdXRvc2F2ZUxhc3RTYXZlZCwgc2V0QXV0b3NhdmVMYXN0U2F2ZWRdID0gdXNlU3RhdGUoJycpO1xuXG4gICAgLy8gQS02OiBGbG9hdGluZyBxdWljay1hY3Rpb24gYnV0dG9uIChGQUIpIG9uIHNjcm9sbFxuICAgIGNvbnN0IG1haW5TY3JvbGxSZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgY29uc3QgW3Njcm9sbGVkUGFzdEhlYWRlciwgc2V0U2Nyb2xsZWRQYXN0SGVhZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZmFiTWVudU9wZW4sIHNldEZhYk1lbnVPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIC8vIEd1aWRlZCBPbmJvYXJkaW5nIFRvdXIgZm9yIEZvcm0gQnVpbGRlclxuICAgIGNvbnN0IFtidWlsZGVyVG91ck9wZW4sIHNldEJ1aWxkZXJUb3VyT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICAvLyBCMTogVXBsb2FkIHByb2dyZXNzIHBlciBxdWVzdGlvbiBpbmRleCB7IFtpZHhdOiAwLTEwMCB8IG51bGwgfVxuICAgIGNvbnN0IFt1cGxvYWRQcm9ncmVzcywgc2V0VXBsb2FkUHJvZ3Jlc3NdID0gdXNlU3RhdGUoe30pO1xuXG4gICAgLy8gQjk6IFJlZiB0byBzdG9yZSBsYXN0IEFJIGdlbmVyYXRpb24gcGFyYW1zIGZvciBGQUIgcXVpY2stZ2VuZXJhdGVcbiAgICBjb25zdCBsYXN0QUlQcm9tcHRSZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICAvLyBDZWsgYXBha2FoIGFkYSBxdWVyeSBwYXJhbSA/dG91cj1idWlsZGVyIGF0YXUgcGVtaWN1IG9uYm9hcmRpbmdcbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICBjb25zdCB1cmxQYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gpO1xuICAgICAgICAgICAgaWYgKHVybFBhcmFtcy5nZXQoJ3RvdXInKSA9PT0gJ2J1aWxkZXInKSB7XG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRCdWlsZGVyVG91ck9wZW4odHJ1ZSksIDYwMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB3aW5kb3cuX19zdGFydEZvcm1VcFRvdXIgPSAoKSA9PiBzZXRCdWlsZGVyVG91ck9wZW4odHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cuX19zdGFydEZvcm1VcFRvdXIpIHtcbiAgICAgICAgICAgICAgICBkZWxldGUgd2luZG93Ll9fc3RhcnRGb3JtVXBUb3VyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0sIFtdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IHNjcm9sbEVsID0gbWFpblNjcm9sbFJlZi5jdXJyZW50O1xuICAgICAgICBjb25zdCBoYW5kbGVTY3JvbGwgPSAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0b3AgPSBzY3JvbGxFbCA/IHNjcm9sbEVsLnNjcm9sbFRvcCA6IHdpbmRvdy5zY3JvbGxZO1xuICAgICAgICAgICAgc2V0U2Nyb2xsZWRQYXN0SGVhZGVyKHRvcCA+IDEyMCk7XG4gICAgICAgIH07XG4gICAgICAgIGlmIChzY3JvbGxFbCkge1xuICAgICAgICAgICAgc2Nyb2xsRWwuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgaGFuZGxlU2Nyb2xsLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gICAgICAgIH1cbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGhhbmRsZVNjcm9sbCwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHNjcm9sbEVsKSBzY3JvbGxFbC5yZW1vdmVFdmVudExpc3RlbmVyKCdzY3JvbGwnLCBoYW5kbGVTY3JvbGwpO1xuICAgICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGhhbmRsZVNjcm9sbCk7XG4gICAgICAgIH07XG4gICAgfSwgW10pO1xuXG4gICAgLy8gRm9ybSBzZXR0aW5ncyBzdGF0ZVxuICAgIGNvbnN0IFtzZXR0aW5ncywgc2V0U2V0dGluZ3NdID0gdXNlU3RhdGUoe1xuICAgICAgICBmb3JtVHlwZUlkOiAxLFxuICAgICAgICBzaG93U2NvcmU6IGZhbHNlLFxuICAgICAgICByYW5kb21pemVRdWVzdGlvbnM6IGZhbHNlLFxuICAgICAgICBvbmVSZXNwb25zZTogZmFsc2UsXG4gICAgICAgIHJlcXVpcmVkTG9naW46IGZhbHNlLFxuICAgICAgICBmb3JtVG9rZW46ICcnLFxuICAgICAgICB0aW1lckR1cmF0aW9uOiAnJyxcbiAgICAgICAgb3BlbkZvcm1UaW1lOiAnJyxcbiAgICAgICAgY2xvc2VGb3JtVGltZTogJycsXG4gICAgICAgIGN1c3RvbUZvcm1MaW5rOiAnJyxcbiAgICAgICAgaXNFeGFtTW9kZTogZmFsc2UsXG4gICAgICAgIGRpc2FibGVDb3B5UGFzdGU6IGZhbHNlLFxuICAgICAgICBkZXRlY3RUYWJTd2l0Y2g6IGZhbHNlLFxuICAgICAgICBhdXRvU3VibWl0T25UYWJTd2l0Y2g6IGZhbHNlLFxuICAgICAgICBtYXhUYWJTd2l0Y2g6IDMsXG4gICAgICAgIHRoZW1lUHJpbWFyeUNvbG9yOiAnJyxcbiAgICAgICAgdGhlbWVCYWNrZ3JvdW5kQ29sb3I6ICcnLFxuICAgIH0pO1xuXG4gICAgLy8gQlVHLTM6IEhlbHBlciBmdW5jdGlvbnMgZm9yIGRldGVybWluaXN0aWMgZGlydHkgY2hlY2sgKGlnbm9yaW5nIHRyYW5zaWVudCBfaWQgdGltZXN0YW1wcylcbiAgICBjb25zdCBzZXJpYWxpemVRdWVzdGlvbnNGb3JEaXJ0eSA9IHVzZUNhbGxiYWNrKChxTGlzdCkgPT4ge1xuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkocUxpc3QpKSByZXR1cm4gJ1tdJztcbiAgICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHFMaXN0Lm1hcChxID0+ICh7XG4gICAgICAgICAgICB0eXBlSWQ6IHBhcnNlSW50KHEudHlwZUlkLCAxMCkgfHwgMixcbiAgICAgICAgICAgIHF1ZXN0aW9uOiAocS5xdWVzdGlvbiB8fCAnJykudHJpbSgpLFxuICAgICAgICAgICAgcXVlc3Rpb25Gb3JtYXQ6IHEucXVlc3Rpb25Gb3JtYXQgfHwgJ3RleHQnLFxuICAgICAgICAgICAgaXNSZXF1aXJlZDogISFxLmlzUmVxdWlyZWQsXG4gICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiAocS5jb3JyZWN0QW5zd2VyIHx8ICcnKS50cmltKCksXG4gICAgICAgICAgICBwb2ludHM6IHEucG9pbnRzID8/IG51bGwsXG4gICAgICAgICAgICBxdWVzdGlvbkltYWdlOiBxLnF1ZXN0aW9uSW1hZ2UgfHwgbnVsbCxcbiAgICAgICAgICAgIHF1ZXN0aW9uQXVkaW86IHEucXVlc3Rpb25BdWRpbyB8fCBudWxsLFxuICAgICAgICAgICAgb3B0aW9uczogKHEub3B0aW9ucyB8fCBbXSkubWFwKG8gPT4gKHtcbiAgICAgICAgICAgICAgICBvcHRpb25UZXh0OiAoby5vcHRpb25UZXh0IHx8ICcnKS50cmltKCksXG4gICAgICAgICAgICAgICAgaXNDb3JyZWN0OiAhIW8uaXNDb3JyZWN0LFxuICAgICAgICAgICAgICAgIG9wdGlvbkltYWdlOiBvLm9wdGlvbkltYWdlIHx8IG8uaW1hZ2UgfHwgby5pbWFnZVVybCB8fCBudWxsLFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICB9KSkpO1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IHNlcmlhbGl6ZVNldHRpbmdzRm9yRGlydHkgPSB1c2VDYWxsYmFjaygocykgPT4ge1xuICAgICAgICBpZiAoIXMgfHwgdHlwZW9mIHMgIT09ICdvYmplY3QnKSByZXR1cm4gJ3t9JztcbiAgICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgIGZvcm1UeXBlSWQ6IHBhcnNlSW50KHMuZm9ybVR5cGVJZCwgMTApIHx8IDEsXG4gICAgICAgICAgICBzaG93U2NvcmU6ICEhcy5zaG93U2NvcmUsXG4gICAgICAgICAgICByYW5kb21pemVRdWVzdGlvbnM6ICEhcy5yYW5kb21pemVRdWVzdGlvbnMsXG4gICAgICAgICAgICBvbmVSZXNwb25zZTogISFzLm9uZVJlc3BvbnNlLFxuICAgICAgICAgICAgcmVxdWlyZWRMb2dpbjogISFzLnJlcXVpcmVkTG9naW4sXG4gICAgICAgICAgICBmb3JtVG9rZW46IChzLmZvcm1Ub2tlbiB8fCAnJykudHJpbSgpLFxuICAgICAgICAgICAgdGltZXJEdXJhdGlvbjogcy50aW1lckR1cmF0aW9uID8gU3RyaW5nKHMudGltZXJEdXJhdGlvbikgOiAnJyxcbiAgICAgICAgICAgIG9wZW5Gb3JtVGltZTogcy5vcGVuRm9ybVRpbWUgfHwgJycsXG4gICAgICAgICAgICBjbG9zZUZvcm1UaW1lOiBzLmNsb3NlRm9ybVRpbWUgfHwgJycsXG4gICAgICAgICAgICBjdXN0b21Gb3JtTGluazogKHMuY3VzdG9tRm9ybUxpbmsgfHwgJycpLnRyaW0oKSxcbiAgICAgICAgICAgIGlzRXhhbU1vZGU6ICEhcy5pc0V4YW1Nb2RlLFxuICAgICAgICAgICAgZGlzYWJsZUNvcHlQYXN0ZTogISFzLmRpc2FibGVDb3B5UGFzdGUsXG4gICAgICAgICAgICBkZXRlY3RUYWJTd2l0Y2g6ICEhcy5kZXRlY3RUYWJTd2l0Y2gsXG4gICAgICAgICAgICBhdXRvU3VibWl0T25UYWJTd2l0Y2g6ICEhcy5hdXRvU3VibWl0T25UYWJTd2l0Y2gsXG4gICAgICAgICAgICBtYXhUYWJTd2l0Y2g6IHMubWF4VGFiU3dpdGNoID8gcGFyc2VJbnQocy5tYXhUYWJTd2l0Y2gsIDEwKSA6IDMsXG4gICAgICAgICAgICB0aGVtZVByaW1hcnlDb2xvcjogcy50aGVtZVByaW1hcnlDb2xvciB8fCAnJyxcbiAgICAgICAgICAgIHRoZW1lQmFja2dyb3VuZENvbG9yOiBzLnRoZW1lQmFja2dyb3VuZENvbG9yIHx8ICcnLFxuICAgICAgICB9KTtcbiAgICB9LCBbXSk7XG5cbiAgICAvLyBTaW5nbGUgc291cmNlIG9mIHRydXRoIGJhc2VsaW5lIHNuYXBzaG90IGZvciBkaXJ0eSB0cmFja2luZ1xuICAgIGNvbnN0IGJhc2VsaW5lUmVmID0gdXNlUmVmKHsgcXVlc3Rpb25zOiAnJywgc2V0dGluZ3M6ICcnIH0pO1xuXG4gICAgLy8gTWFyayBkaXJ0eSB3aGVuIHF1ZXN0aW9ucyBvciBzZXR0aW5ncyBkZXZpYXRlIGZyb20gYmFzZWxpbmUgc25hcHNob3RcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAobG9hZGluZykgcmV0dXJuO1xuICAgICAgICBpZiAoIWJhc2VsaW5lUmVmLmN1cnJlbnQucXVlc3Rpb25zICYmICFiYXNlbGluZVJlZi5jdXJyZW50LnNldHRpbmdzKSByZXR1cm47XG5cbiAgICAgICAgY29uc3QgY3VycmVudFFTdHIgPSBzZXJpYWxpemVRdWVzdGlvbnNGb3JEaXJ0eShxdWVzdGlvbnMpO1xuICAgICAgICBjb25zdCBjdXJyZW50U1N0ciA9IHNlcmlhbGl6ZVNldHRpbmdzRm9yRGlydHkoc2V0dGluZ3MpO1xuXG4gICAgICAgIGNvbnN0IHFEaXJ0eSA9IGN1cnJlbnRRU3RyICE9PSBiYXNlbGluZVJlZi5jdXJyZW50LnF1ZXN0aW9ucztcbiAgICAgICAgY29uc3Qgc0RpcnR5ID0gY3VycmVudFNTdHIgIT09IGJhc2VsaW5lUmVmLmN1cnJlbnQuc2V0dGluZ3M7XG5cbiAgICAgICAgc2V0SXNEaXJ0eShxRGlydHkgfHwgc0RpcnR5KTtcbiAgICB9LCBbcXVlc3Rpb25zLCBzZXR0aW5ncywgbG9hZGluZywgc2VyaWFsaXplUXVlc3Rpb25zRm9yRGlydHksIHNlcmlhbGl6ZVNldHRpbmdzRm9yRGlydHldKTtcblxuICAgIC8vIEZFQVQtMTE6IGJlZm9yZXVubG9hZCBndWFyZFxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGhhbmRsZXIgPSAoZSkgPT4ge1xuICAgICAgICAgICAgaWYgKGlzRGlydHkpIHtcbiAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICAgICAgZS5yZXR1cm5WYWx1ZSA9ICcnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYmVmb3JldW5sb2FkJywgaGFuZGxlcik7XG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignYmVmb3JldW5sb2FkJywgaGFuZGxlcik7XG4gICAgfSwgW2lzRGlydHldKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgd2luZG93Ll9fZm9ybUJ1aWxkZXJEaXJ0eSA9IGlzRGlydHk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICB3aW5kb3cuX19mb3JtQnVpbGRlckRpcnR5ID0gZmFsc2U7XG4gICAgfTtcbn0sIFtpc0RpcnR5XSk7XG5cbiAgICAvLyBCVUctNCBGSVg6IEluLWFwcCBuYXZpZ2F0aW9uIGd1YXJkLlxuICAgIC8vIHVzZUJsb2NrZXIgaW50ZXJjZXB0cyBjbGllbnQtc2lkZSByb3V0ZSBjaGFuZ2VzIChzaWRlYmFyIGxpbmtzLCBiYWNrIGJ1dHRvbiwgZXRjLilcbiAgICAvLyB0aGF0IGJlZm9yZXVubG9hZCBkb2VzIE5PVCBjYXRjaCBpbnNpZGUgYSBTUEEuIFdoZW4gdGhlcmUgYXJlIHVuc2F2ZWQgY2hhbmdlcyxcbiAgICAvLyB0aGUgYmxvY2tlciBmaXJlcyBhbmQgd2Ugc2hvdyBhIGN1c3RvbSBjb25maXJtYXRpb24gZGlhbG9nIGluc3RlYWQgb2Ygc2lsZW50bHlcbiAgICAvLyBsZWF2aW5nIGFuZCBsb3NpbmcgZWRpdHMuXG4gICAgLy8gY29uc3QgbmF2QmxvY2tlciA9IHVzZUJsb2NrZXIoXG4gICAgLy8gICAgICh7IGN1cnJlbnRMb2NhdGlvbiwgbmV4dExvY2F0aW9uIH0pID0+XG4gICAgLy8gICAgICAgICBpc0RpcnR5ICYmIGN1cnJlbnRMb2NhdGlvbi5wYXRobmFtZSAhPT0gbmV4dExvY2F0aW9uLnBhdGhuYW1lXG4gICAgLy8gKTtcblxuICAgIC8vIERpc21pc3MgdGhlIG5hdi1ibG9ja2VyIGRpYWxvZyBvbiBFc2NhcGVcbiAgICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIC8vICAgICBpZiAobmF2QmxvY2tlci5zdGF0ZSAhPT0gJ2Jsb2NrZWQnKSByZXR1cm47XG4gICAgLy8gICAgIGNvbnN0IGhhbmRsZXIgPSAoZSkgPT4geyBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSBuYXZCbG9ja2VyLnJlc2V0KCk7IH07XG4gICAgLy8gICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVyKTtcbiAgICAvLyAgICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVyKTtcbiAgICAvLyB9LCBbbmF2QmxvY2tlcl0pO1xuXG4gICAgLy8gQS0yOiBDbG9zZSBhY3Rpb25zIG1lbnUgb24gb3V0c2lkZSBjbGlja1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGhhbmRsZXIgPSAoZSkgPT4ge1xuICAgICAgICAgICAgaWYgKGFjdGlvbnNNZW51UmVmLmN1cnJlbnQgJiYgIWFjdGlvbnNNZW51UmVmLmN1cnJlbnQuY29udGFpbnMoZS50YXJnZXQpKSB7XG4gICAgICAgICAgICAgICAgc2V0QWN0aW9uc01lbnVPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlcik7XG4gICAgICAgIHJldHVybiAoKSA9PiBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVyKTtcbiAgICB9LCBbXSk7XG5cbiAgICAvLyBGRUFULTExOiBkb2N1bWVudC50aXRsZSBpbmRpY2F0b3JcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoZm9ybT8udGl0bGUpIHtcbiAgICAgICAgICAgIGRvY3VtZW50LnRpdGxlID0gaXNEaXJ0eSA/IGDigKIgJHtmb3JtLnRpdGxlfSDigJQgRm9ybVVwYCA6IGAke2Zvcm0udGl0bGV9IOKAlCBGb3JtVXBgO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoKSA9PiB7IGRvY3VtZW50LnRpdGxlID0gJ0Zvcm1VcCc7IH07XG4gICAgfSwgW2lzRGlydHksIGZvcm0/LnRpdGxlXSk7XG5cbiAgICAvLyBGRUFULTEyOiBQdXNoIHRvIGhpc3Rvcnkgd2hlbiBxdWVzdGlvbnMgY2hhbmdlIGR1ZSB0byBzdHJ1Y3R1cmFsIG9wcy5cbiAgICAvLyBCVUctMS8yLzMgRklYOiBSZWFkIGhpc3RvcnlJbmRleFJlZi5jdXJyZW50IChhbHdheXMgY3VycmVudCkgaW5zdGVhZCBvZlxuICAgIC8vIHRoZSBjbG9zdXJlLWNhcHR1cmVkIGhpc3RvcnlJbmRleCBzdGF0ZSB2YWx1ZS4gVGhpcyBlbGltaW5hdGVzOlxuICAgIC8vICAg4oCiIHRoZSBvZmYtYnktb25lIHRoYXQgcmVxdWlyZWQgMiBhY3Rpb25zIGJlZm9yZSB1bmRvIHdvcmtlZCAoQnVnIDEpXG4gICAgLy8gICDigKIgdGhlIHdyb25nIHNuYXBzaG90IGJlaW5nIHJlc3RvcmVkIGJlY2F1c2Ugc2xpY2luZyB1c2VkIGEgc3RhbGUgaW5kZXggKEJ1ZyAyKVxuICAgIC8vICAg4oCiIHRoZSBkZWJvdW5jZWQgdGV4dC1lZGl0IHBhdGggZmlyaW5nIHdpdGggYSBzdGFsZSBwdXNoSGlzdG9yeSByZWYgKEJ1ZyAzKVxuICAgIC8vIHB1c2hIaXN0b3J5IGlzIG5vdyBzdGFibGUgKG5vIGRlcHMpIHNvIGl0IGlzIHNhZmUgdG8gY2FwdHVyZSBpbiBzZXRUaW1lb3V0LlxuICAgICAgICBjb25zdCBwdXNoSGlzdG9yeSA9IHVzZUNhbGxiYWNrKChzbmFwc2hvdEJlZm9yZU11dGF0aW9uKSA9PiB7XG4gICAgICAgIGlmIChoaXN0b3J5VXBkYXRpbmdSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgICAvLyBGSVg6IENhbmNlbCBhbnkgcGVuZGluZyBkZWJvdW5jZWQgdGV4dC1lZGl0IGhpc3RvcnkgcHVzaCBiZWZvcmVcbiAgICAgICAgLy8gY29tbWl0dGluZyB0aGlzIHNuYXBzaG90LiBXaXRob3V0IHRoaXMsIGEgZGVib3VuY2UgdGltZXIgZnJvbSBhblxuICAgICAgICAvLyBlYXJsaWVyIG9wdGlvblRleHQvcXVlc3Rpb24gZWRpdCAoZS5nLiBhZGRpbmcgYW4gaW1hZ2UgdG8gYW4gb3B0aW9uKVxuICAgICAgICAvLyBjYW4gZmlyZSBBRlRFUiBhIHN0cnVjdHVyYWwgYWN0aW9uIChyZW1vdmUgb3B0aW9uLCBkZWxldGUgcXVlc3Rpb24sIGV0Yy4pXG4gICAgICAgIC8vIGhhcyBhbHJlYWR5IHB1c2hlZCBpdHMgb3duIGNoZWNrcG9pbnQg4oCUIGluc2VydGluZyBhIHN0YWxlLCBvdXQtb2Ytb3JkZXJcbiAgICAgICAgLy8gc25hcHNob3QgaW50byBoaXN0b3J5IGFuZCBjb3JydXB0aW5nIHVuZG8vcmVkbyBzZXF1ZW5jaW5nLlxuICAgICAgICBpZiAodGV4dEVkaXREZWJvdW5jZVJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGV4dEVkaXREZWJvdW5jZVJlZi5jdXJyZW50KTtcbiAgICAgICAgICAgIHRleHRFZGl0RGVib3VuY2VSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc25hcHNob3QgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHNuYXBzaG90QmVmb3JlTXV0YXRpb24pKTtcbiAgICAgICAgY29uc3QgY3VycmVudElkeCA9IGhpc3RvcnlJbmRleFJlZi5jdXJyZW50O1xuICAgICAgICBjb25zdCBuZXdIaXN0b3J5ID0gWy4uLmhpc3RvcnlSZWYuY3VycmVudC5zbGljZSgwLCBjdXJyZW50SWR4ICsgMSksIHNuYXBzaG90XS5zbGljZSgtMjApO1xuICAgICAgICBjb25zdCBuZXdJbmRleCA9IG5ld0hpc3RvcnkubGVuZ3RoIC0gMTtcbiAgICAgICAgaGlzdG9yeVJlZi5jdXJyZW50ID0gbmV3SGlzdG9yeTtcbiAgICAgICAgaGlzdG9yeUluZGV4UmVmLmN1cnJlbnQgPSBuZXdJbmRleDtcbiAgICAgICAgc2V0SGlzdG9yeShuZXdIaXN0b3J5KTtcbiAgICAgICAgc2V0SGlzdG9yeUluZGV4KG5ld0luZGV4KTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gICAgfSwgW10pO1xuXG4gICAgLy8gRkVBVC0xMjogS2V5Ym9hcmQgbGlzdGVuZXIgZm9yIEN0cmwrWiAvIEN0cmwrWVxuICAgIC8vIEJVRy0xIEZJWDogaGFuZGxlVW5kby9SZWRvIGFyZSBzdGFibGUgKHJlYWQgcmVmcywgbm90IGNsb3NlZC1vdmVyIHN0YXRlKSBzb1xuICAgIC8vIHRoZSBrZXlib2FyZCBlZmZlY3QgbmVlZHMgbm8gZGVwcyBhbmQgbmV2ZXIgcmUtcmVnaXN0ZXJzIHN0YWxlIGhhbmRsZXJzLlxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGhhbmRsZXIgPSAoZSkgPT4ge1xuICAgICAgICAgICAgaWYgKChlLmN0cmxLZXkgfHwgZS5tZXRhS2V5KSAmJiBlLmtleSA9PT0gJ3onICYmICFlLnNoaWZ0S2V5KSB7XG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgIGhhbmRsZVVuZG8oKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoKGUuY3RybEtleSB8fCBlLm1ldGFLZXkpICYmIChlLmtleSA9PT0gJ3knIHx8IChlLmtleSA9PT0gJ3onICYmIGUuc2hpZnRLZXkpKSkge1xuICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICBoYW5kbGVSZWRvKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlcik7XG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZXIpO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgICB9LCBbXSk7XG5cbiAgICBjb25zdCBoYW5kbGVVbmRvID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBpZHggPSBoaXN0b3J5SW5kZXhSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKGlkeCA8PSAwKSByZXR1cm47XG4gICAgICAgIGNvbnN0IG5ld0lkeCA9IGlkeCAtIDE7XG4gICAgICAgIGhpc3RvcnlVcGRhdGluZ1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgaGlzdG9yeUluZGV4UmVmLmN1cnJlbnQgPSBuZXdJZHg7XG4gICAgICAgIHNldEhpc3RvcnlJbmRleChuZXdJZHgpO1xuICAgICAgICBzZXRRdWVzdGlvbnMoSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShoaXN0b3J5UmVmLmN1cnJlbnRbbmV3SWR4XSkpKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7IGhpc3RvcnlVcGRhdGluZ1JlZi5jdXJyZW50ID0gZmFsc2U7IH0sIDApO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVSZWRvID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBpZHggPSBoaXN0b3J5SW5kZXhSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKGlkeCA+PSBoaXN0b3J5UmVmLmN1cnJlbnQubGVuZ3RoIC0gMSkgcmV0dXJuO1xuICAgICAgICBjb25zdCBuZXdJZHggPSBpZHggKyAxO1xuICAgICAgICBoaXN0b3J5VXBkYXRpbmdSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGhpc3RvcnlJbmRleFJlZi5jdXJyZW50ID0gbmV3SWR4O1xuICAgICAgICBzZXRIaXN0b3J5SW5kZXgobmV3SWR4KTtcbiAgICAgICAgc2V0UXVlc3Rpb25zKEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoaGlzdG9yeVJlZi5jdXJyZW50W25ld0lkeF0pKSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4geyBoaXN0b3J5VXBkYXRpbmdSZWYuY3VycmVudCA9IGZhbHNlOyB9LCAwKTtcbiAgICB9O1xuXG4gICAgLy8gRkVBVC0xNDogQXV0b3NhdmUgaW50ZXJ2YWxcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZm9ybXVwX2F1dG9zYXZlX3ByZWYnLCBTdHJpbmcoYXV0b3NhdmVFbmFibGVkKSk7XG4gICAgICAgIGlmIChhdXRvc2F2ZUludGVydmFsUmVmLmN1cnJlbnQpIGNsZWFySW50ZXJ2YWwoYXV0b3NhdmVJbnRlcnZhbFJlZi5jdXJyZW50KTtcbiAgICAgICAgaWYgKGF1dG9zYXZlRW5hYmxlZCkge1xuICAgICAgICAgICAgYXV0b3NhdmVJbnRlcnZhbFJlZi5jdXJyZW50ID0gc2V0SW50ZXJ2YWwoYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICghaXNEaXJ0eSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGNvbnN0IG9rID0gYXdhaXQgaGFuZGxlU2F2ZUFsbCgpO1xuICAgICAgICAgICAgICAgIGlmIChvaykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBoaG1tID0gYCR7U3RyaW5nKG5vdy5nZXRIb3VycygpKS5wYWRTdGFydCgyLCcwJyl9OiR7U3RyaW5nKG5vdy5nZXRNaW51dGVzKCkpLnBhZFN0YXJ0KDIsJzAnKX1gO1xuICAgICAgICAgICAgICAgICAgICBzZXRBdXRvc2F2ZVRvYXN0KGBUZXJzaW1wYW4gb3RvbWF0aXMgcHVrdWwgJHtoaG1tfWApO1xuICAgICAgICAgICAgICAgICAgICBzZXRBdXRvc2F2ZUxhc3RTYXZlZChgVGVyc2ltcGFuICR7bmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2lkLUlEJywgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pfWApO1xuICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEF1dG9zYXZlVG9hc3QoJycpLCAyNTAwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCAxNTAwMCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICgpID0+IHsgaWYgKGF1dG9zYXZlSW50ZXJ2YWxSZWYuY3VycmVudCkgY2xlYXJJbnRlcnZhbChhdXRvc2F2ZUludGVydmFsUmVmLmN1cnJlbnQpOyB9O1xuICAgIH0sIFthdXRvc2F2ZUVuYWJsZWQsIGlzRGlydHksIGFjdGl2ZVRhYl0pO1xuXG4gICAgY29uc3QgdG9Mb2NhbERhdGV0aW1lSW5wdXQgPSAoZGF0ZVZhbCkgPT4ge1xuICAgICAgICBpZiAoIWRhdGVWYWwpIHJldHVybiAnJztcbiAgICAgICAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGVWYWwpO1xuICAgICAgICBpZiAoaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gJyc7XG4gICAgICAgIGNvbnN0IHllYXIgPSBkLmdldEZ1bGxZZWFyKCk7XG4gICAgICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGQuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJyk7XG4gICAgICAgIGNvbnN0IGRheSA9IFN0cmluZyhkLmdldERhdGUoKSkucGFkU3RhcnQoMiwgJzAnKTtcbiAgICAgICAgY29uc3QgaG91cnMgPSBTdHJpbmcoZC5nZXRIb3VycygpKS5wYWRTdGFydCgyLCAnMCcpO1xuICAgICAgICBjb25zdCBtaW51dGVzID0gU3RyaW5nKGQuZ2V0TWludXRlcygpKS5wYWRTdGFydCgyLCAnMCcpO1xuICAgICAgICByZXR1cm4gYCR7eWVhcn0tJHttb250aH0tJHtkYXl9VCR7aG91cnN9OiR7bWludXRlc31gO1xuICAgIH07XG5cbiAgICBjb25zdCBzaG93VG9hc3QgPSAobXNnLCB0eXBlID0gJ3N1Y2Nlc3MnKSA9PiB7XG4gICAgICAgIHNldFRvYXN0KHsgbXNnLCB0eXBlIH0pO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFRvYXN0KG51bGwpLCAzMDAwKTtcbiAgICB9O1xuXG4gICAgLy8gQi0xOiBUb3RhbCBNYWtzaW1hbCBTa29yIChzdW0gb2YgYWxsIHNjb3JhYmxlIHF1ZXN0aW9uIHBvaW50cylcbiAgICBjb25zdCB0b3RhbE1heFNjb3JlID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShxdWVzdGlvbnMpKSByZXR1cm4gMDtcbiAgICAgICAgcmV0dXJuIHF1ZXN0aW9ucy5yZWR1Y2UoKHRvdGFsLCBxKSA9PiB7XG4gICAgICAgICAgICBpZiAocS5pc1Njb3JhYmxlID09PSBmYWxzZSkgcmV0dXJuIHRvdGFsO1xuICAgICAgICAgICAgY29uc3QgcCA9IE51bWJlcihxLnBvaW50cyk7XG4gICAgICAgICAgICByZXR1cm4gdG90YWwgKyAoIWlzTmFOKHApICYmIHAgPiAwID8gcCA6IDEpO1xuICAgICAgICB9LCAwKTtcbiAgICB9LCBbcXVlc3Rpb25zXSk7XG5cbiAgICAvLyBDLTI6IERlYm91bmNlIHNlYXJjaCB0ZXJtIDI1MG1zXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgdCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgc2V0RGVib3VuY2VkU2VhcmNoKHNlYXJjaFRlcm0pO1xuICAgICAgICAgICAgc2V0Q3VycmVudFBhZ2UoMSk7XG4gICAgICAgIH0sIDI1MCk7XG4gICAgICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodCk7XG4gICAgfSwgW3NlYXJjaFRlcm1dKTtcblxuICAgIC8vIEhlbHBlcjogbG9hZCBxdWVzdGlvbnMgbGlzdCB3aXRoIHBhZ2luYXRpb24gKyBzZWFyY2ggcGFyYW1zXG4gICAgY29uc3QgZmV0Y2hRdWVzdGlvbnMgPSB1c2VDYWxsYmFjayhhc3luYyAoeyBwYWdlID0gMSwgcGFnZVNpemVWYWwgPSBwYWdlU2l6ZSwgc2VhcmNoID0gZGVib3VuY2VkU2VhcmNoLCByZXNldFRvdGFsID0gZmFsc2UgfSA9IHt9KSA9PiB7XG4gICAgICAgIGNvbnN0IHFSZXMgPSBhd2FpdCBnZXRRdWVzdGlvbnMoaWQsIHtcbiAgICAgICAgICAgIHBhZ2UsXG4gICAgICAgICAgICBwYWdlU2l6ZTogcGFnZVNpemVWYWwsXG4gICAgICAgICAgICBzZWFyY2hcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICghcVJlcy5vaykge1xuICAgICAgICAgICAgc2hvd1RvYXN0KHFSZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVtdWF0IGRhZnRhciBzb2FsJywgJ2Vycm9yJyk7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBsb2FkZWRRdWVzdGlvbnMgPSBbXTtcbiAgICAgICAgbGV0IHRvdGFsID0gMDtcblxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShxUmVzLmRhdGEpKSB7XG4gICAgICAgICAgICBsb2FkZWRRdWVzdGlvbnMgPSBxUmVzLmRhdGE7XG4gICAgICAgICAgICB0b3RhbCA9IHFSZXMuZGF0YS5sZW5ndGg7XG4gICAgICAgIH0gZWxzZSBpZiAocVJlcy5kYXRhICYmIHR5cGVvZiBxUmVzLmRhdGEgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICBsb2FkZWRRdWVzdGlvbnMgPSBxUmVzLmRhdGEucXVlc3Rpb25zIHx8IHFSZXMuZGF0YS5pdGVtcyB8fCBxUmVzLmRhdGEubGlzdCB8fCBbXTtcbiAgICAgICAgICAgIHRvdGFsID0gcVJlcy5kYXRhLnRvdGFsIHx8IHFSZXMuZGF0YS50b3RhbEl0ZW1zIHx8IHFSZXMuZGF0YS5jb3VudCB8fCBsb2FkZWRRdWVzdGlvbnMubGVuZ3RoO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0VG90YWxRdWVzdGlvbnMocmVzZXRUb3RhbCB8fCBwYWdlID09PSAxID8gdG90YWwgOiAobikgPT4gTWF0aC5tYXgobiwgdG90YWwpKTtcbiAgICAgICAgc2V0Q3VycmVudFBhZ2UocGFnZSk7XG4gICAgICAgIHNldFBhZ2VTaXplKHBhZ2VTaXplVmFsKTtcblxuICAgICAgICByZXR1cm4gbG9hZGVkUXVlc3Rpb25zO1xuICAgIH0sIFtpZCwgcGFnZVNpemUsIGRlYm91bmNlZFNlYXJjaF0pO1xuXG4gICAgLy8gQy0yOiBSZS1mZXRjaCBxdWVzdGlvbnMgd2hlbmV2ZXIgZGVib3VuY2VkU2VhcmNoLCBjdXJyZW50UGFnZSwgb3IgcGFnZVNpemUgY2hhbmdlc1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChsb2FkaW5nIHx8ICFpZCkgcmV0dXJuO1xuICAgICAgICBjb25zdCBkb0ZldGNoID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbG9hZGVkUXVlc3Rpb25zID0gYXdhaXQgZmV0Y2hRdWVzdGlvbnMoeyBwYWdlOiBjdXJyZW50UGFnZSB9KTtcbiAgICAgICAgICAgIGlmIChsb2FkZWRRdWVzdGlvbnMgPT0gbnVsbCkgcmV0dXJuO1xuICAgICAgICAgICAgbGV0IGZpbmFsID0gW107XG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShsb2FkZWRRdWVzdGlvbnMpICYmIGxvYWRlZFF1ZXN0aW9ucy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgZmluYWwgPSBsb2FkZWRRdWVzdGlvbnMubWFwKChxKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRPcHRpb25zID0gbm9ybWFsaXplUXVlc3Rpb25PcHRpb25zKHEpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBoYXNDb3JyZWN0T3B0aW9uID0gbm9ybWFsaXplZE9wdGlvbnMuc29tZShvID0+IG8uaXNDb3JyZWN0ID09PSB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaGFzQ29ycmVjdEFuc3dlciA9ICEhKHEuY29ycmVjdEFuc3dlciAmJiBxLmNvcnJlY3RBbnN3ZXIudHJpbSgpKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTY29yYWJsZSA9IHEuaXNTY29yYWJsZSAhPT0gdW5kZWZpbmVkID8gcS5pc1Njb3JhYmxlIDogKGhhc0NvcnJlY3RPcHRpb24gfHwgaGFzQ29ycmVjdEFuc3dlcik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5xLFxuICAgICAgICAgICAgICAgICAgICAgICAgX2lkOiBgcV8ke3EuaWR9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzU2NvcmFibGU6IGlzU2NvcmFibGUsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zOiBub3JtYWxpemVkT3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoY3VycmVudFBhZ2UgPT09IDEgJiYgIWRlYm91bmNlZFNlYXJjaCkge1xuICAgICAgICAgICAgICAgIGZpbmFsID0gW25ld1F1ZXN0aW9uKDEpXTtcbiAgICAgICAgICAgICAgICBzZXRUb3RhbFF1ZXN0aW9ucygwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNldFF1ZXN0aW9ucyhmaW5hbCk7XG4gICAgICAgIH07XG4gICAgICAgIGRvRmV0Y2goKTtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICAgIH0sIFtjdXJyZW50UGFnZSwgZGVib3VuY2VkU2VhcmNoLCBwYWdlU2l6ZSwgaWRdKTtcblxuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgbG9hZCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICBjb25zdCBmb3JtUmVzID0gYXdhaXQgZ2V0Rm9ybUJ5SWQoaWQpO1xuICAgICAgICAgICAgY29uc3QgbG9hZGVkUXVlc3Rpb25zUmF3ID0gYXdhaXQgZmV0Y2hRdWVzdGlvbnMoeyBwYWdlOiAxLCByZXNldFRvdGFsOiB0cnVlIH0pO1xuXG4gICAgICAgICAgICBpZiAoZm9ybVJlcy5zdGF0dXMgPT09IDQwMSkgeyBjbGVhclNlc3Npb24oKTsgbmF2aWdhdGUoJy9sb2dpbicpOyByZXR1cm47IH1cblxuICAgICAgICAgICAgbGV0IGxvYWRlZFNldHRpbmdzID0geyAuLi5zZXR0aW5ncyB9O1xuICAgICAgICAgICAgaWYgKGZvcm1SZXMub2sgJiYgZm9ybVJlcy5kYXRhKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZiA9IGZvcm1SZXMuZGF0YTtcbiAgICAgICAgICAgICAgICBzZXRGb3JtKGYpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHMgPSBmLnNldHRpbmdzIHx8IHt9O1xuICAgICAgICAgICAgICAgIGxvYWRlZFNldHRpbmdzID0ge1xuICAgICAgICAgICAgICAgICAgICBmb3JtVHlwZUlkOiBzLmZvcm1UeXBlSWQgPz8gMSxcbiAgICAgICAgICAgICAgICAgICAgc2hvd1Njb3JlOiBzLnNob3dTY29yZSA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgcmFuZG9taXplUXVlc3Rpb25zOiBzLnJhbmRvbWl6ZVF1ZXN0aW9ucyA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgb25lUmVzcG9uc2U6IHMub25lUmVzcG9uc2UgPz8gZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkTG9naW46IHMucmVxdWlyZWRMb2dpbiA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgZm9ybVRva2VuOiBzLmZvcm1Ub2tlbiA/PyAnJyxcbiAgICAgICAgICAgICAgICAgICAgdGltZXJEdXJhdGlvbjogcy50aW1lckR1cmF0aW9uID8gTWF0aC5yb3VuZChzLnRpbWVyRHVyYXRpb24gLyA2MCkgOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgb3BlbkZvcm1UaW1lOiB0b0xvY2FsRGF0ZXRpbWVJbnB1dChzLm9wZW5Gb3JtVGltZSksXG4gICAgICAgICAgICAgICAgICAgIGNsb3NlRm9ybVRpbWU6IHRvTG9jYWxEYXRldGltZUlucHV0KHMuY2xvc2VGb3JtVGltZSksXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbUZvcm1MaW5rOiBmLmZvcm1MaW5rIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICBpc0V4YW1Nb2RlOiBzLmlzRXhhbU1vZGUgPz8gZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVDb3B5UGFzdGU6IHMuZGlzYWJsZUNvcHlQYXN0ZSA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgZGV0ZWN0VGFiU3dpdGNoOiBzLmRldGVjdFRhYlN3aXRjaCA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgYXV0b1N1Ym1pdE9uVGFiU3dpdGNoOiBzLmF1dG9TdWJtaXRPblRhYlN3aXRjaCA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgbWF4VGFiU3dpdGNoOiBzLm1heFRhYlN3aXRjaCA/PyAzLFxuICAgICAgICAgICAgICAgICAgICB0aGVtZVByaW1hcnlDb2xvcjogcy50aGVtZVByaW1hcnlDb2xvciA/PyAnJyxcbiAgICAgICAgICAgICAgICAgICAgdGhlbWVCYWNrZ3JvdW5kQ29sb3I6IHMudGhlbWVCYWNrZ3JvdW5kQ29sb3IgPz8gJycsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBzZXRTZXR0aW5ncyhsb2FkZWRTZXR0aW5ncyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxldCBsb2FkZWRRdWVzdGlvbnMgPSBbXTtcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGxvYWRlZFF1ZXN0aW9uc1JhdykgJiYgbG9hZGVkUXVlc3Rpb25zUmF3Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBsb2FkZWRRdWVzdGlvbnMgPSBsb2FkZWRRdWVzdGlvbnNSYXcubWFwKChxKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRPcHRpb25zID0gbm9ybWFsaXplUXVlc3Rpb25PcHRpb25zKHEpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBoYXNDb3JyZWN0T3B0aW9uID0gbm9ybWFsaXplZE9wdGlvbnMuc29tZShvID0+IG8uaXNDb3JyZWN0ID09PSB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaGFzQ29ycmVjdEFuc3dlciA9ICEhKHEuY29ycmVjdEFuc3dlciAmJiBxLmNvcnJlY3RBbnN3ZXIudHJpbSgpKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTY29yYWJsZSA9IHEuaXNTY29yYWJsZSAhPT0gdW5kZWZpbmVkID8gcS5pc1Njb3JhYmxlIDogKGhhc0NvcnJlY3RPcHRpb24gfHwgaGFzQ29ycmVjdEFuc3dlcik7XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnEsXG4gICAgICAgICAgICAgICAgICAgICAgICBfaWQ6IGBxXyR7cS5pZH1gLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNTY29yYWJsZTogaXNTY29yYWJsZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IG5vcm1hbGl6ZWRPcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBsb2FkZWRRdWVzdGlvbnMgPSBbbmV3UXVlc3Rpb24oMSldO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0UXVlc3Rpb25zKGxvYWRlZFF1ZXN0aW9ucyk7XG5cbiAgICAgICAgICAgIC8vIEJVRy0zIEZJWDogU2VlZCB1bmRvL3JlZG8gaGlzdG9yeSB3aXRoIHRoZSBpbml0aWFsIGxvYWRlZCBzdGF0ZSBzb1xuICAgICAgICAgICAgLy8gdGhlIGZpcnN0IEN0cmwrWiBhbHdheXMgaGFzIGEgdmFsaWQgc25hcHNob3QgdG8gcmV0dXJuIHRvLlxuICAgICAgICAgICAgLy8gQWxzbyBzZWVkIHRoZSBtaXJyb3IgcmVmcyBzbyBwdXNoSGlzdG9yeSByZWFkcyBhIGNvbnNpc3RlbnQgaW5pdGlhbCBpbmRleC5cbiAgICAgICAgICAgIGNvbnN0IHNlZWRTbmFwc2hvdCA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkobG9hZGVkUXVlc3Rpb25zKSk7XG4gICAgICAgICAgICBoaXN0b3J5UmVmLmN1cnJlbnQgPSBbc2VlZFNuYXBzaG90XTtcbiAgICAgICAgICAgIGhpc3RvcnlJbmRleFJlZi5jdXJyZW50ID0gMDtcbiAgICAgICAgICAgIHNldEhpc3RvcnkoW3NlZWRTbmFwc2hvdF0pO1xuICAgICAgICAgICAgc2V0SGlzdG9yeUluZGV4KDApO1xuXG4gICAgICAgICAgICAvLyBFc3RhYmxpc2ggY2xlYW4gYmFzZWxpbmUgc25hcHNob3QgZm9yIG5ldy9sb2FkZWQgZm9ybVxuICAgICAgICAgICAgYmFzZWxpbmVSZWYuY3VycmVudCA9IHtcbiAgICAgICAgICAgICAgICBxdWVzdGlvbnM6IHNlcmlhbGl6ZVF1ZXN0aW9uc0ZvckRpcnR5KGxvYWRlZFF1ZXN0aW9ucyksXG4gICAgICAgICAgICAgICAgc2V0dGluZ3M6IHNlcmlhbGl6ZVNldHRpbmdzRm9yRGlydHkobG9hZGVkU2V0dGluZ3MpLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNldElzRGlydHkoZmFsc2UpO1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH07XG4gICAgICAgIGxvYWQoKTtcbiAgICB9LCBbaWQsIG5hdmlnYXRlLCBzZXJpYWxpemVRdWVzdGlvbnNGb3JEaXJ0eSwgc2VyaWFsaXplU2V0dGluZ3NGb3JEaXJ0eV0pO1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZVF1ZXN0aW9ucyA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0U2F2aW5nKHRydWUpO1xuICAgICAgICAvLyAwIHNvYWwgZGlwZXJib2xlaGthbjoga2lyaW0gYXJyYXkga29zb25nIC0+IGJhY2tlbmQgaGFwdXMgc2VtdWEgc29hbFxuICAgICAgICBjb25zdCBwYXlsb2FkUXVlc3Rpb25zID0gcXVlc3Rpb25zLm1hcCgocSwgaSkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc2NvcmFibGUgPSBxLmlzU2NvcmFibGUgIT09IGZhbHNlO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBpZDogcS5pZCA/PyB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgdHlwZUlkOiBwYXJzZUludChxLnR5cGVJZCksXG4gICAgICAgICAgICAgICAgcXVlc3Rpb246IHEucXVlc3Rpb24gfHwgJycsXG4gICAgICAgICAgICAgICAgcXVlc3Rpb25Gb3JtYXQ6IHEucXVlc3Rpb25Gb3JtYXQgfHwgJ3RleHQnLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uT3JkZXI6IGkgKyAxLFxuICAgICAgICAgICAgICAgIGlzUmVxdWlyZWQ6ICEhcS5pc1JlcXVpcmVkLFxuICAgICAgICAgICAgICAgIGNvcnJlY3RBbnN3ZXI6IHNjb3JhYmxlID8gKHEuY29ycmVjdEFuc3dlciB8fCBudWxsKSA6IG51bGwsXG4gICAgICAgICAgICAgICAgcG9pbnRzOiBzY29yYWJsZSAmJiBxLnBvaW50cyA/IHBhcnNlSW50KHEucG9pbnRzLCAxMCkgOiBudWxsLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uSW1hZ2U6IHEucXVlc3Rpb25JbWFnZSB8fCBudWxsLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uQXVkaW86IHEucXVlc3Rpb25BdWRpbyB8fCBudWxsLFxuICAgICAgICAgICAgICAgIG9wdGlvbnM6IChxLm9wdGlvbnMgfHwgW10pLm1hcChvcHQgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uVGV4dDogb3B0Lm9wdGlvblRleHQgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIGlzQ29ycmVjdDogc2NvcmFibGUgPyAhIW9wdC5pc0NvcnJlY3QgOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uSW1hZ2U6IG9wdC5vcHRpb25JbWFnZSB8fCBvcHQuaW1hZ2UgfHwgb3B0LmltYWdlVXJsIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgc2F2ZVF1ZXN0aW9ucyhpZCwgcGF5bG9hZFF1ZXN0aW9ucyk7XG4gICAgICAgIHNldFNhdmluZyhmYWxzZSk7XG5cbiAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgc2hvd1RvYXN0KHBheWxvYWRRdWVzdGlvbnMubGVuZ3RoID09PSAwID8gJ1NlbXVhIHNvYWwgYmVyaGFzaWwgZGloYXB1cyEnIDogJ1NvYWwgYmVyaGFzaWwgZGlzaW1wYW4hJyk7XG4gICAgICAgICAgICBsZXQgZnJlc2hRdWVzdGlvbnMgPSBbXTtcbiAgICAgICAgICAgIGNvbnN0IHFSZXMgPSBhd2FpdCBnZXRRdWVzdGlvbnMoaWQpO1xuICAgICAgICAgICAgaWYgKHFSZXMub2sgJiYgQXJyYXkuaXNBcnJheShxUmVzLmRhdGEpKSB7XG4gICAgICAgICAgICAgICAgaWYgKHFSZXMuZGF0YS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgZnJlc2hRdWVzdGlvbnMgPSBbXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmcmVzaFF1ZXN0aW9ucyA9IHFSZXMuZGF0YS5tYXAoKHEsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRPcHRpb25zID0gbm9ybWFsaXplUXVlc3Rpb25PcHRpb25zKHEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5xLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9pZDogcXVlc3Rpb25zW2ldPy5faWQgfHwgYHFfJHtxLmlkfWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNTY29yYWJsZTogcXVlc3Rpb25zW2ldPy5pc1Njb3JhYmxlID8/IChub3JtYWxpemVkT3B0aW9ucy5zb21lKG8gPT4gby5pc0NvcnJlY3QgPT09IHRydWUpIHx8ICEhKHEuY29ycmVjdEFuc3dlciAmJiBxLmNvcnJlY3RBbnN3ZXIudHJpbSgpKSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9pbnRzOiBxLnBvaW50cyA/PyBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IG5vcm1hbGl6ZWRPcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHNldFF1ZXN0aW9ucyhmcmVzaFF1ZXN0aW9ucyk7XG4gICAgICAgICAgICAgICAgLy8gSmlrYSBmb3JtIGtlaGFiaXNhbiBzb2FsLCBzdGF0dXMgb3RvbWF0aXMga2VtYmFsaSBkcmFmdFxuICAgICAgICAgICAgICAgIGNvbnN0IHJlZnJlc2hlZCA9IGF3YWl0IGdldEZvcm1CeUlkKGlkKTtcbiAgICAgICAgICAgICAgICBpZiAocmVmcmVzaGVkLm9rICYmIHJlZnJlc2hlZC5kYXRhKSBzZXRGb3JtKHJlZnJlc2hlZC5kYXRhKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZnJlc2hRdWVzdGlvbnMgPSBxdWVzdGlvbnM7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGJhc2VsaW5lUmVmLmN1cnJlbnQucXVlc3Rpb25zID0gc2VyaWFsaXplUXVlc3Rpb25zRm9yRGlydHkoZnJlc2hRdWVzdGlvbnMpO1xuICAgICAgICAgICAgY29uc3Qgc0RpcnR5ID0gc2VyaWFsaXplU2V0dGluZ3NGb3JEaXJ0eShzZXR0aW5ncykgIT09IGJhc2VsaW5lUmVmLmN1cnJlbnQuc2V0dGluZ3M7XG4gICAgICAgICAgICBzZXRJc0RpcnR5KHNEaXJ0eSk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNob3dUb2FzdChyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVueWltcGFuIHNvYWwuJywgJ2Vycm9yJyk7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQ2xlYXJBbGxRdWVzdGlvbnMgPSAoKSA9PiB7XG4gICAgICAgIGlmIChxdWVzdGlvbnMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gICAgICAgIHNldENvbmZpcm1Nb2RhbCh7XG4gICAgICAgICAgICBpc09wZW46IHRydWUsXG4gICAgICAgICAgICB0aXRsZTogJ0hhcHVzIFNlbXVhIFNvYWw/JyxcbiAgICAgICAgICAgIG1lc3NhZ2U6ICdIYXB1cyBzZW11YSBzb2FsPyBQZXJ1YmFoYW4gYmVybGFrdSBzZXRlbGFoIFNpbXBhbi4nLFxuICAgICAgICAgICAgdmFyaWFudDogJ2RhbmdlcicsXG4gICAgICAgICAgICBvbkNvbmZpcm06ICgpID0+IHtcbiAgICAgICAgICAgICAgICBwdXNoSGlzdG9yeShxdWVzdGlvbnMpO1xuICAgICAgICAgICAgICAgIHNldFF1ZXN0aW9ucyhbXSk7XG4gICAgICAgICAgICAgICAgc2hvd1RvYXN0KCdTZW11YSBzb2FsIGRpaGFwdXMgZGFyaSBkcmFmLiBUZWthbiBTaW1wYW4gdW50dWsgbWVueWltcGFuIHBlcnViYWhhbi4nLCAnc3VjY2VzcycpO1xuICAgICAgICAgICAgICAgIHNldENvbmZpcm1Nb2RhbChwcmV2ID0+ICh7IC4uLnByZXYsIGlzT3BlbjogZmFsc2UgfSkpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmVTZXR0aW5ncyA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0U2F2aW5nKHRydWUpO1xuICAgICAgICBpZiAoc2V0dGluZ3MuY3VzdG9tRm9ybUxpbmsgJiYgc2V0dGluZ3MuY3VzdG9tRm9ybUxpbmsgIT09IGZvcm0uZm9ybUxpbmspIHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm1SZXMgPSBhd2FpdCB1cGRhdGVGb3JtKGlkLCB7XG4gICAgICAgICAgICAgICAgdGl0bGU6IGZvcm0udGl0bGUsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGZvcm0uZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgZm9ybUxpbms6IHNldHRpbmdzLmN1c3RvbUZvcm1MaW5rLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoIWZvcm1SZXMub2spIHtcbiAgICAgICAgICAgICAgICBzaG93VG9hc3QoZm9ybVJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW1wZXJiYXJ1aSBzbHVnIHRhdXRhbiBmb3JtdWxpcicsICdlcnJvcicpO1xuICAgICAgICAgICAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0Rm9ybShwcmV2ID0+ICh7IC4uLnByZXYsIGZvcm1MaW5rOiBzZXR0aW5ncy5jdXN0b21Gb3JtTGluayB9KSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBwYXJzZWRUaW1lciA9IHBhcnNlSW50KHNldHRpbmdzLnRpbWVyRHVyYXRpb24sIDEwKTtcbiAgICAgICAgY29uc3QgdGltZXJWYWx1ZSA9ICFpc05hTihwYXJzZWRUaW1lcikgJiYgcGFyc2VkVGltZXIgPiAwID8gcGFyc2VkVGltZXIgKiA2MCA6IG51bGw7XG5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdXBkYXRlRm9ybVNldHRpbmdzKGlkLCB7XG4gICAgICAgICAgICBmb3JtVHlwZUlkOiBwYXJzZUludChzZXR0aW5ncy5mb3JtVHlwZUlkLCAxMCkgfHwgMSxcbiAgICAgICAgICAgIHNob3dTY29yZTogISFzZXR0aW5ncy5zaG93U2NvcmUsXG4gICAgICAgICAgICByYW5kb21pemVRdWVzdGlvbnM6ICEhc2V0dGluZ3MucmFuZG9taXplUXVlc3Rpb25zLFxuICAgICAgICAgICAgb25lUmVzcG9uc2U6ICEhc2V0dGluZ3Mub25lUmVzcG9uc2UsXG4gICAgICAgICAgICByZXF1aXJlZExvZ2luOiAhIXNldHRpbmdzLnJlcXVpcmVkTG9naW4sXG4gICAgICAgICAgICBmb3JtVG9rZW46IHNldHRpbmdzLmZvcm1Ub2tlbiA/IHNldHRpbmdzLmZvcm1Ub2tlbi50cmltKCkgOiBudWxsLFxuICAgICAgICAgICAgdGltZXJEdXJhdGlvbjogdGltZXJWYWx1ZSxcbiAgICAgICAgICAgIG9wZW5Gb3JtVGltZTogc2V0dGluZ3Mub3BlbkZvcm1UaW1lID8gbmV3IERhdGUoc2V0dGluZ3Mub3BlbkZvcm1UaW1lKS50b0lTT1N0cmluZygpIDogbnVsbCxcbiAgICAgICAgICAgIGNsb3NlRm9ybVRpbWU6IHNldHRpbmdzLmNsb3NlRm9ybVRpbWUgPyBuZXcgRGF0ZShzZXR0aW5ncy5jbG9zZUZvcm1UaW1lKS50b0lTT1N0cmluZygpIDogbnVsbCxcbiAgICAgICAgICAgIGlzRXhhbU1vZGU6ICEhc2V0dGluZ3MuaXNFeGFtTW9kZSxcbiAgICAgICAgICAgIGRpc2FibGVDb3B5UGFzdGU6ICEhc2V0dGluZ3MuZGlzYWJsZUNvcHlQYXN0ZSxcbiAgICAgICAgICAgIGRldGVjdFRhYlN3aXRjaDogISFzZXR0aW5ncy5kZXRlY3RUYWJTd2l0Y2gsXG4gICAgICAgICAgICBhdXRvU3VibWl0T25UYWJTd2l0Y2g6ICEhc2V0dGluZ3MuYXV0b1N1Ym1pdE9uVGFiU3dpdGNoLFxuICAgICAgICAgICAgbWF4VGFiU3dpdGNoOiBzZXR0aW5ncy5tYXhUYWJTd2l0Y2ggPyBwYXJzZUludChzZXR0aW5ncy5tYXhUYWJTd2l0Y2gsIDEwKSA6IG51bGwsXG4gICAgICAgICAgICB0aGVtZVByaW1hcnlDb2xvcjogc2V0dGluZ3MudGhlbWVQcmltYXJ5Q29sb3IgfHwgbnVsbCxcbiAgICAgICAgICAgIHRoZW1lQmFja2dyb3VuZENvbG9yOiBzZXR0aW5ncy50aGVtZUJhY2tncm91bmRDb2xvciB8fCBudWxsLFxuICAgICAgICB9KTtcblxuICAgICAgICBzZXRTYXZpbmcoZmFsc2UpO1xuXG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIGxldCBuZXh0U2V0dGluZ3MgPSB7IC4uLnNldHRpbmdzIH07XG4gICAgICAgICAgICBjb25zdCByZWZyZXNoZWQgPSBhd2FpdCBnZXRGb3JtQnlJZChpZCk7XG4gICAgICAgICAgICBpZiAocmVmcmVzaGVkLm9rICYmIHJlZnJlc2hlZC5kYXRhKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZiA9IHJlZnJlc2hlZC5kYXRhO1xuICAgICAgICAgICAgICAgIHNldEZvcm0oZik7XG4gICAgICAgICAgICAgICAgY29uc3QgcyA9IGYuc2V0dGluZ3MgfHwge307XG4gICAgICAgICAgICAgICAgbmV4dFNldHRpbmdzID0ge1xuICAgICAgICAgICAgICAgICAgICBmb3JtVHlwZUlkOiBzLmZvcm1UeXBlSWQgPz8gMSxcbiAgICAgICAgICAgICAgICAgICAgc2hvd1Njb3JlOiBzLnNob3dTY29yZSA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgcmFuZG9taXplUXVlc3Rpb25zOiBzLnJhbmRvbWl6ZVF1ZXN0aW9ucyA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgb25lUmVzcG9uc2U6IHMub25lUmVzcG9uc2UgPz8gZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkTG9naW46IHMucmVxdWlyZWRMb2dpbiA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgZm9ybVRva2VuOiBzLmZvcm1Ub2tlbiA/PyAnJyxcbiAgICAgICAgICAgICAgICAgICAgdGltZXJEdXJhdGlvbjogcy50aW1lckR1cmF0aW9uID8gTWF0aC5yb3VuZChzLnRpbWVyRHVyYXRpb24gLyA2MCkgOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgb3BlbkZvcm1UaW1lOiB0b0xvY2FsRGF0ZXRpbWVJbnB1dChzLm9wZW5Gb3JtVGltZSksXG4gICAgICAgICAgICAgICAgICAgIGNsb3NlRm9ybVRpbWU6IHRvTG9jYWxEYXRldGltZUlucHV0KHMuY2xvc2VGb3JtVGltZSksXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbUZvcm1MaW5rOiBmLmZvcm1MaW5rIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICBpc0V4YW1Nb2RlOiBzLmlzRXhhbU1vZGUgPz8gZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVDb3B5UGFzdGU6IHMuZGlzYWJsZUNvcHlQYXN0ZSA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgZGV0ZWN0VGFiU3dpdGNoOiBzLmRldGVjdFRhYlN3aXRjaCA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgYXV0b1N1Ym1pdE9uVGFiU3dpdGNoOiBzLmF1dG9TdWJtaXRPblRhYlN3aXRjaCA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgbWF4VGFiU3dpdGNoOiBzLm1heFRhYlN3aXRjaCA/PyAzLFxuICAgICAgICAgICAgICAgICAgICB0aGVtZVByaW1hcnlDb2xvcjogcy50aGVtZVByaW1hcnlDb2xvciA/PyAnJyxcbiAgICAgICAgICAgICAgICAgICAgdGhlbWVCYWNrZ3JvdW5kQ29sb3I6IHMudGhlbWVCYWNrZ3JvdW5kQ29sb3IgPz8gJycsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBzZXRTZXR0aW5ncyhuZXh0U2V0dGluZ3MpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBiYXNlbGluZVJlZi5jdXJyZW50LnNldHRpbmdzID0gc2VyaWFsaXplU2V0dGluZ3NGb3JEaXJ0eShuZXh0U2V0dGluZ3MpO1xuICAgICAgICAgICAgY29uc3QgcURpcnR5ID0gc2VyaWFsaXplUXVlc3Rpb25zRm9yRGlydHkocXVlc3Rpb25zKSAhPT0gYmFzZWxpbmVSZWYuY3VycmVudC5xdWVzdGlvbnM7XG4gICAgICAgICAgICBzZXRJc0RpcnR5KHFEaXJ0eSk7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ1BlbmdhdHVyYW4gZm9ybXVsaXIgYmVyaGFzaWwgZGlzaW1wYW4hJyk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNob3dUb2FzdChyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVueWltcGFuIHBlbmdhdHVyYW4nLCAnZXJyb3InKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBCVUctMzogVW5pZmllZCBzYXZlIGhhbmRsZXIgdGhhdCBzYXZlcyBxdWVzdGlvbnMsIHNldHRpbmdzLCBvciBib3RoIGJhc2VkIG9uIGRpcnR5IHN0YXRlXG4gICAgY29uc3QgaGFuZGxlU2F2ZUFsbCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgcURpcnR5ID0gc2VyaWFsaXplUXVlc3Rpb25zRm9yRGlydHkocXVlc3Rpb25zKSAhPT0gYmFzZWxpbmVSZWYuY3VycmVudC5xdWVzdGlvbnM7XG4gICAgICAgIGNvbnN0IHNEaXJ0eSA9IHNlcmlhbGl6ZVNldHRpbmdzRm9yRGlydHkoc2V0dGluZ3MpICE9PSBiYXNlbGluZVJlZi5jdXJyZW50LnNldHRpbmdzO1xuXG4gICAgICAgIGxldCBva1EgPSB0cnVlO1xuICAgICAgICBsZXQgb2tTID0gdHJ1ZTtcblxuICAgICAgICBpZiAocURpcnR5IHx8IGFjdGl2ZVRhYiA9PT0gJ3F1ZXN0aW9ucycpIHtcbiAgICAgICAgICAgIG9rUSA9IGF3YWl0IGhhbmRsZVNhdmVRdWVzdGlvbnMoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzRGlydHkgfHwgYWN0aXZlVGFiID09PSAnc2V0dGluZ3MnKSB7XG4gICAgICAgICAgICBva1MgPSBhd2FpdCBoYW5kbGVTYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBva1EgJiYgb2tTO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVUb2dnbGVQdWJsaXNoID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBzZXRQdWJsaXNoaW5nKHRydWUpO1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB0b2dnbGVQdWJsaXNoRm9ybShpZCk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCBnZXRGb3JtQnlJZChpZCk7XG4gICAgICAgICAgICBpZiAodXBkYXRlZC5vaykgc2V0Rm9ybSh1cGRhdGVkLmRhdGEpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdTdGF0dXMgcHVibGlrYXNpIGZvcm11bGlyIGJlcmhhc2lsIGRpdWJhaCEnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNob3dUb2FzdChyZXMubWVzc2FnZSB8fCAnR2FnYWwgbWVuZ3ViYWggc3RhdHVzIHB1Ymxpa2FzaScsICdlcnJvcicpO1xuICAgICAgICB9XG4gICAgICAgIHNldFB1Ymxpc2hpbmcoZmFsc2UpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVMb2FkU2hhcmUgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdldEZvcm1TaGFyZShpZCk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIHNldFNoYXJlSW5mbyhyZXMuZGF0YSk7XG4gICAgICAgICAgICBjb25zdCB0b2tlbiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0b2tlbicpO1xuICAgICAgICAgICAgY29uc3QgcXJSZXMgPSBhd2FpdCBmZXRjaChcbiAgICAgICAgICAgICAgICBgJHtBUElfQkFTRV9VUkx9L2FwaS9mb3Jtcy8ke2lkfS9zaGFyZS9xcj9mcm9udGVuZFVybD0ke2VuY29kZVVSSUNvbXBvbmVudChGUk9OVEVORF9CQVNFX1VSTCl9YCxcbiAgICAgICAgICAgICAgICB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAgfSB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgaWYgKHFyUmVzLm9rKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IHFyUmVzLmJsb2IoKTtcbiAgICAgICAgICAgICAgICBzZXRRckJsb2JVcmwoVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbaWRdKTtcblxuICAgIGNvbnN0IGhhbmRsZUJhbm5lclVwbG9hZCA9IGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgICAgICBpZiAoIWZpbGUpIHJldHVybjtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdXBsb2FkRm9ybUJhbm5lcihpZCwgZmlsZSk7XG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCBnZXRGb3JtQnlJZChpZCk7XG4gICAgICAgICAgICBpZiAodXBkYXRlZC5vaykgc2V0Rm9ybSh1cGRhdGVkLmRhdGEpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KCdCYW5uZXIgZm9ybXVsaXIgYmVyaGFzaWwgZGl1bmdnYWghJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbmd1bmdnYWggYmFubmVyJywgJ2Vycm9yJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gSGVscGVyOiByZWZyZXNoIHF1ZXN0aW9uIGxpc3QgZnJvbSBBUEkgKHBvc3QtaW1wb3J0LCBwb3N0LWNsZWFyKVxuICAgIGNvbnN0IHJlZnJlc2hRdWVzdGlvbnNMaXN0ID0gYXN5bmMgKG9wdHMgPSB7fSkgPT4ge1xuICAgICAgICBjb25zdCBxUmVzID0gYXdhaXQgZmV0Y2hRdWVzdGlvbnMoeyBwYWdlOiAxLCByZXNldFRvdGFsOiB0cnVlLCAuLi5vcHRzIH0pO1xuICAgICAgICBpZiAocVJlcyA9PSBudWxsKSByZXR1cm47XG4gICAgICAgIGxldCBmcmVzaCA9IFtdO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShxUmVzKSAmJiBxUmVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGZyZXNoID0gcVJlcy5tYXAoKHEsIGkpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBub3JtYWxpemVkT3B0aW9ucyA9IG5vcm1hbGl6ZVF1ZXN0aW9uT3B0aW9ucyhxKTtcbiAgICAgICAgICAgICAgICBjb25zdCBoYXNDb3JyZWN0T3B0aW9uID0gbm9ybWFsaXplZE9wdGlvbnMuc29tZShvID0+IG8uaXNDb3JyZWN0ID09PSB0cnVlKTtcbiAgICAgICAgICAgICAgICBjb25zdCBoYXNDb3JyZWN0QW5zd2VyID0gISEocS5jb3JyZWN0QW5zd2VyICYmIHEuY29ycmVjdEFuc3dlci50cmltKCkpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzU2NvcmFibGUgPSBxLmlzU2NvcmFibGUgIT09IHVuZGVmaW5lZCA/IHEuaXNTY29yYWJsZSA6IChoYXNDb3JyZWN0T3B0aW9uIHx8IGhhc0NvcnJlY3RBbnN3ZXIpO1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIC4uLnEsXG4gICAgICAgICAgICAgICAgICAgIF9pZDogYHFfJHtxLmlkfWAsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiBxLnF1ZXN0aW9uIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICB0eXBlSWQ6IHEudHlwZUlkIHx8IDIsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uT3JkZXI6IHEucXVlc3Rpb25PcmRlciA/PyBpICsgMSxcbiAgICAgICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogcS5pc1JlcXVpcmVkID8/IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICBpc1Njb3JhYmxlOiBpc1Njb3JhYmxlLFxuICAgICAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiBxLmNvcnJlY3RBbnN3ZXIgPz8gJycsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uSW1hZ2U6IHEucXVlc3Rpb25JbWFnZSA/PyBudWxsLFxuICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbkF1ZGlvOiBxLnF1ZXN0aW9uQXVkaW8gPz8gbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uczogbm9ybWFsaXplZE9wdGlvbnMsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKCFvcHRzLnNlYXJjaCB8fCBvcHRzLnNlYXJjaCA9PT0gJycpIHtcbiAgICAgICAgICAgIGZyZXNoID0gW25ld1F1ZXN0aW9uKDEpXTtcbiAgICAgICAgICAgIHNldFRvdGFsUXVlc3Rpb25zKDApO1xuICAgICAgICB9XG4gICAgICAgIHNldFF1ZXN0aW9ucyhmcmVzaCk7XG4gICAgICAgIHB1c2hIaXN0b3J5KGZyZXNoKTtcbiAgICB9O1xuXG4gICAgLy8gQS0yOiBDYWxsYmFjayBhZnRlciBJbXBvcnRRdWVzdGlvbnNNb2RhbCBzdWNjZXNzZnVsbHkgY29tbWl0cyBpbXBvcnRcbiAgICBjb25zdCBoYW5kbGVPbkltcG9ydGVkID0gYXN5bmMgKGRhdGEgPSB7fSkgPT4ge1xuICAgICAgICBzaG93VG9hc3QoYEJlcmhhc2lsIG1lbmdpbXBvciAke2RhdGEudG90YWxJbXBvcnRlZCA/PyAwfSBzb2FsIWApO1xuICAgICAgICBjb25zdCBpbXBvcnRlZCA9IEFycmF5LmlzQXJyYXkoZGF0YS5xdWVzdGlvbnMpID8gZGF0YS5xdWVzdGlvbnMgOiBbXTtcbiAgICAgICAgaWYgKGltcG9ydGVkLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAgICAgICBwdXNoSGlzdG9yeShxdWVzdGlvbnMpO1xuICAgICAgICBjb25zdCBtYXBwZWQgPSBpbXBvcnRlZC5tYXAoKHEsIGluZGV4KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBub3JtYWxpemVkT3B0aW9ucyA9IG5vcm1hbGl6ZVF1ZXN0aW9uT3B0aW9ucyhxKTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4ucSxcbiAgICAgICAgICAgICAgICBpZDogbnVsbCxcbiAgICAgICAgICAgICAgICBfaWQ6IGBxX2ltcG9ydF8ke0RhdGUubm93KCl9XyR7aW5kZXh9YCxcbiAgICAgICAgICAgICAgICBxdWVzdGlvbk9yZGVyOiBxdWVzdGlvbnMubGVuZ3RoICsgaW5kZXggKyAxLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiBxLnF1ZXN0aW9uIHx8IHEucXVlc3Rpb25UZXh0IHx8ICcnLFxuICAgICAgICAgICAgICAgIHR5cGVJZDogcGFyc2VJbnQocS50eXBlSWQsIDEwKSB8fCAyLFxuICAgICAgICAgICAgICAgIGlzUmVxdWlyZWQ6IHEuaXNSZXF1aXJlZCA/PyBmYWxzZSxcbiAgICAgICAgICAgICAgICBpc1Njb3JhYmxlOiBxLmlzU2NvcmFibGUgPz8gKG5vcm1hbGl6ZWRPcHRpb25zLnNvbWUobyA9PiBvLmlzQ29ycmVjdCkgfHwgQm9vbGVhbihxLmNvcnJlY3RBbnN3ZXIpKSxcbiAgICAgICAgICAgICAgICBvcHRpb25zOiBub3JtYWxpemVkT3B0aW9ucyxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgICAgICBzZXRRdWVzdGlvbnMocHJldiA9PiBbLi4ucHJldiwgLi4ubWFwcGVkXSk7XG4gICAgfTtcblxuICAgIC8vIEJVRy0yIEZJWDogU3RhZ2UgZGVsZXRpb24gbG9jYWxseTsgb25seSBjb21taXR0ZWQgb24gXCJTaW1wYW4gUGVydWJhaGFuXCIuXG4gICAgLy8gUHJldmlvdXNseSBjYWxsZWQgdGhlIGRlbGV0ZSBBUEkgaW1tZWRpYXRlbHksIHdoaWNoIGNhdXNlZCBwZXJtYW5lbnQgZGVsZXRpb25cbiAgICAvLyBldmVuIHdoZW4gdGhlIHVzZXIgbGVmdCB3aXRob3V0IHNhdmluZy4gTm93IG1hdGNoZXMgdGhlIHNhbWUgcGF0dGVybiB1c2VkIGJ5XG4gICAgLy8gaGFuZGxlQ2xlYXJBbGxRdWVzdGlvbnMgKGxvY2FsLW9ubHkgdW50aWwgc2F2ZSkuXG4gICAgY29uc3QgaGFuZGxlRGVsZXRlUXVlc3Rpb24gPSAoaWR4KSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHQgPSBxdWVzdGlvbnMuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpZHgpO1xuICAgICAgICBwdXNoSGlzdG9yeShxdWVzdGlvbnMpOyAvLyBzYXZlIEJFRk9SRSBtdXRhdGlvbiAoZml4ZXMgQnVnIDMgb2ZmLWJ5LW9uZSB0b28pXG4gICAgICAgIHNldFF1ZXN0aW9ucyhuZXh0KTtcbiAgICAgICAgc2hvd1RvYXN0KCdTb2FsIGRpaGFwdXMgZGFyaSBkcmFmLiBUZWthbiBTaW1wYW4gdW50dWsgbWVueWltcGFuIHBlcnViYWhhbi4nLCAnc3VjY2VzcycpO1xuICAgIH07XG5cbiAgICAvLyBGRUFULTEwYTogRHVwbGljYXRlIHF1ZXN0aW9uXG4gICAgY29uc3QgaGFuZGxlRHVwbGljYXRlUXVlc3Rpb24gPSAoaWR4KSA9PiB7XG4gICAgICAgIGNvbnN0IG9yaWcgPSBxdWVzdGlvbnNbaWR4XTtcbiAgICAgICAgY29uc3QgZHVwZSA9IHtcbiAgICAgICAgICAgIC4uLkpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkob3JpZykpLFxuICAgICAgICAgICAgX2lkOiBgcV9kdXBfJHtEYXRlLm5vdygpfWAsXG4gICAgICAgICAgICBpZDogbnVsbCxcbiAgICAgICAgfTtcbiAgICAgICAgLy8gQlVHLTMgRklYOiBwdXNoIHNuYXBzaG90IEJFRk9SRSBtdXRhdGlvblxuICAgICAgICBwdXNoSGlzdG9yeShxdWVzdGlvbnMpO1xuICAgICAgICBzZXRRdWVzdGlvbnMocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gWy4uLnByZXZdO1xuICAgICAgICAgICAgbmV4dC5zcGxpY2UoaWR4ICsgMSwgMCwgZHVwZSk7XG4gICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgfSk7XG4gICAgICAgIHNob3dUb2FzdCgnU29hbCBiZXJoYXNpbCBkaWR1cGxpa2FzaScpO1xuICAgIH07XG5cbiAgICAvLyBGRUFULTg6IEV4cG9ydCBxdWVzdGlvbnMgYXMgQ1NWXG4gICAgY29uc3QgaGFuZGxlRXhwb3J0UXVlc3Rpb25zID0gKCkgPT4ge1xuICAgICAgICBpZiAocXVlc3Rpb25zLmxlbmd0aCA9PT0gMCkgeyBzaG93VG9hc3QoJ1RpZGFrIGFkYSBzb2FsIHVudHVrIGRpZWtzcG9yLicsICdlcnJvcicpOyByZXR1cm47IH1cbiAgICAgICAgY29uc3Qgcm93cyA9IFtcbiAgICAgICAgICAgIFsncXVlc3Rpb24nLCAndHlwZV9pZCcsICdvcmRlcicsICdpc19yZXF1aXJlZCcsICdjb3JyZWN0X2Fuc3dlcicsICdvcHRpb25zJ11cbiAgICAgICAgXTtcbiAgICAgICAgcXVlc3Rpb25zLmZvckVhY2goKHEsIGkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlzQ2hvaWNlID0gcS50eXBlSWQgPT09IDIgfHwgcS50eXBlSWQgPT09IDM7XG4gICAgICAgICAgICBjb25zdCBvcHRpb25zU3RyID0gKHEub3B0aW9ucyB8fCBbXSkubWFwKG8gPT4gKG8uaXNDb3JyZWN0ID8gYFtCRU5BUl0gJHtvLm9wdGlvblRleHR9YCA6IG8ub3B0aW9uVGV4dCkpLmpvaW4oJ3wnKTtcbiAgICAgICAgICAgIGNvbnN0IGNsZWFuUSA9IChxLnF1ZXN0aW9uIHx8ICcnKS5yZXBsYWNlKC88W14+XSo+L2csICcnKS5yZXBsYWNlKC9cXHMrL2csICcgJykudHJpbSgpO1xuICAgICAgICAgICAgY29uc3QgY29ycmVjdENhID0gaXNDaG9pY2VcbiAgICAgICAgICAgICAgICA/IChxLm9wdGlvbnMgfHwgW10pLmZpbHRlcihvID0+IG8uaXNDb3JyZWN0KS5tYXAobyA9PiBvLm9wdGlvblRleHQpLmpvaW4oJywnKVxuICAgICAgICAgICAgICAgIDogKHEuY29ycmVjdEFuc3dlciB8fCAnJyk7XG4gICAgICAgICAgICByb3dzLnB1c2goW1xuICAgICAgICAgICAgICAgIGBcIiR7Y2xlYW5RLnJlcGxhY2UoL1wiL2csICdcIlwiJyl9XCJgLFxuICAgICAgICAgICAgICAgIHEudHlwZUlkIHx8IDIsXG4gICAgICAgICAgICAgICAgaSArIDEsXG4gICAgICAgICAgICAgICAgcS5pc1JlcXVpcmVkID8gJ3RydWUnIDogJ2ZhbHNlJyxcbiAgICAgICAgICAgICAgICBgXCIkeyhjb3JyZWN0Q2EgfHwgJycpLnJlcGxhY2UoL1wiL2csICdcIlwiJyl9XCJgLFxuICAgICAgICAgICAgICAgIGBcIiR7b3B0aW9uc1N0ci5yZXBsYWNlKC9cIi9nLCAnXCJcIicpfVwiYCxcbiAgICAgICAgICAgIF0pO1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgY3N2ID0gJ1xcdUZFRkYnICsgcm93cy5tYXAociA9PiByLmpvaW4oJywnKSkuam9pbignXFxyXFxuJyk7XG4gICAgICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbY3N2XSwgeyB0eXBlOiAndGV4dC9jc3Y7Y2hhcnNldD11dGYtODsnIH0pO1xuICAgICAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgICBhLmhyZWYgPSB1cmw7XG4gICAgICAgIGEuZG93bmxvYWQgPSBgc29hbC0keyhmb3JtPy50aXRsZSB8fCAnZm9ybXVsaXInKS5yZXBsYWNlKC9cXHMrL2csICdfJyl9LSR7RGF0ZS5ub3coKX0uY3N2YDtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChhKTtcbiAgICAgICAgYS5jbGljaygpO1xuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGEpO1xuICAgICAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG4gICAgICAgIHNob3dUb2FzdCgnRmlsZSBzb2FsIENTViBiZXJoYXNpbCBkaXVuZHVoIScpO1xuICAgIH07XG5cbiAgICAvLyBBSS0yOiBSZXZpc2UgcXVlc3Rpb24gd2l0aCBBSVxuICAgIGNvbnN0IGhhbmRsZUFpUmV2aXNlID0gYXN5bmMgKGlkeCkgPT4ge1xuICAgICAgICBjb25zdCBxID0gcXVlc3Rpb25zW2lkeF07XG4gICAgICAgIGlmICghYWlSZXZpc2VJbnN0cnVjdGlvbi50cmltKCkpIHsgc2V0QWlSZXZpc2VFcnJvcignTWFzdWtrYW4gaW5zdHJ1a3NpIHJldmlzaS4nKTsgcmV0dXJuOyB9XG4gICAgICAgIHNldEFpUmV2aXNpbmcodHJ1ZSk7XG4gICAgICAgIHNldEFpUmV2aXNlRXJyb3IoJycpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgcmV2aXNlUXVlc3Rpb25XaXRoQUkoe1xuICAgICAgICAgICAgICAgIHF1ZXN0aW9uOiBxLnF1ZXN0aW9uLFxuICAgICAgICAgICAgICAgIG9wdGlvbnM6IHEub3B0aW9ucyB8fCBbXSxcbiAgICAgICAgICAgICAgICBjb3JyZWN0QW5zd2VyOiBxLmNvcnJlY3RBbnN3ZXIsXG4gICAgICAgICAgICAgICAgdHlwZUlkOiBxLnR5cGVJZCxcbiAgICAgICAgICAgICAgICBpc1JlcXVpcmVkOiBxLmlzUmVxdWlyZWQsXG4gICAgICAgICAgICAgICAgaXNTY29yYWJsZTogcS5pc1Njb3JhYmxlLFxuICAgICAgICAgICAgICAgIGluc3RydWN0aW9uOiBhaVJldmlzZUluc3RydWN0aW9uLFxuICAgICAgICAgICAgICAgIHNlbGVjdGVkTW9kZWw6IHJldmlzZU1vZGVsLFxuICAgICAgICAgICAgICAgIGN1c3RvbUFwaUtleTogZ2V0R2VtaW5pQXBpS2V5KCksXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgaWYgKCFyZXMub2spIHtcbiAgICAgICAgICAgICAgICBzZXRBaVJldmlzZUVycm9yKHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZXJldmlzaSBzb2FsLicpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgcmV2aXNlZCA9IHJlcy5kYXRhO1xuICAgICAgICAgICAgdXBkYXRlUXVlc3Rpb24oaWR4LCAncXVlc3Rpb24nLCByZXZpc2VkLnF1ZXN0aW9uIHx8IHEucXVlc3Rpb24pO1xuICAgICAgICAgICAgaWYgKHJldmlzZWQub3B0aW9ucyAmJiByZXZpc2VkLm9wdGlvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIHNldFF1ZXN0aW9ucyhwcmV2ID0+IHByZXYubWFwKChxcSwgcWkpID0+IHFpID09PSBpZHggPyB7IC4uLnFxLCBxdWVzdGlvbjogcmV2aXNlZC5xdWVzdGlvbiB8fCBxcS5xdWVzdGlvbiwgb3B0aW9uczogcmV2aXNlZC5vcHRpb25zLCBjb3JyZWN0QW5zd2VyOiByZXZpc2VkLmNvcnJlY3RBbnN3ZXIgfHwgcXEuY29ycmVjdEFuc3dlciB9IDogcXEpKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdXBkYXRlUXVlc3Rpb24oaWR4LCAnY29ycmVjdEFuc3dlcicsIHJldmlzZWQuY29ycmVjdEFuc3dlciB8fCBxLmNvcnJlY3RBbnN3ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0QWlSZXZpc2VPcGVuSWR4KG51bGwpO1xuICAgICAgICAgICAgc2V0QWlSZXZpc2VJbnN0cnVjdGlvbignJyk7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ1NvYWwgYmVyaGFzaWwgZGlyZXZpc2kgb2xlaCBBSSEnKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBzZXRBaVJldmlzZUVycm9yKCdHYWdhbCBtZXJldmlzaSBzb2FsOiAnICsgZXJyLm1lc3NhZ2UpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0QWlSZXZpc2luZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gQS03OiBCdWxrIEFJIFJldmlzZSBoYW5kbGVyXG4gICAgY29uc3QgaGFuZGxlQnVsa0FpUmV2aXNlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWJ1bGtSZXZpc2VJbnN0cnVjdGlvbi50cmltKCkpIHsgc2hvd1RvYXN0KCdNYXN1a2thbiBpbnN0cnVrc2kgcmV2aXNpLicsICdlcnJvcicpOyByZXR1cm47IH1cbiAgICAgICAgaWYgKGJ1bGtSZXZpc2VTZWxlY3RlZC5zaXplID09PSAwKSB7IHNob3dUb2FzdCgnUGlsaWggbWluaW1hbCAxIHNvYWwgdW50dWsgZGlyZXZpc2kuJywgJ2Vycm9yJyk7IHJldHVybjsgfVxuICAgICAgICBzZXRCdWxrUmV2aXNpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBidWxrUmV2aXNlUXVlc3Rpb25zV2l0aEFJKHtcbiAgICAgICAgICAgICAgICBxdWVzdGlvbnMsXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRJbmRpY2VzOiBBcnJheS5mcm9tKGJ1bGtSZXZpc2VTZWxlY3RlZCksXG4gICAgICAgICAgICAgICAgaW5zdHJ1Y3Rpb246IGJ1bGtSZXZpc2VJbnN0cnVjdGlvbixcbiAgICAgICAgICAgICAgICBzZWxlY3RlZE1vZGVsOiByZXZpc2VNb2RlbCxcbiAgICAgICAgICAgICAgICBjdXN0b21BcGlLZXk6IGdldEdlbWluaUFwaUtleSgpLFxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZXJldmlzaSBzb2FsIG1hc3NhbC4nLCAnZXJyb3InKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdHMgPSByZXMuZGF0YSB8fCBbXTtcbiAgICAgICAgICAgIGlmIChyZXN1bHRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBzZXRCdWxrUmV2aXNlUHJldmlldyhyZXN1bHRzKTtcbiAgICAgICAgICAgICAgICBzZXRCdWxrUmV2aXNlUHJldmlld09wZW4odHJ1ZSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHNob3dUb2FzdCgnVGlkYWsgYWRhIHNvYWwgeWFuZyBiZXJoYXNpbCBkaXJldmlzaS4nLCAnZXJyb3InKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ0dhZ2FsIG1lcmV2aXNpOiAnICsgZXJyLm1lc3NhZ2UsICdlcnJvcicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0QnVsa1JldmlzaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBhcHBseUJ1bGtSZXZpc2VJdGVtID0gKGlkeCwgcmV2aXNlZCkgPT4ge1xuICAgICAgICBzZXRRdWVzdGlvbnMocHJldiA9PiBwcmV2Lm1hcCgocSwgcWkpID0+IHFpID09PSBpZHggPyB7IC4uLnEsIHF1ZXN0aW9uOiByZXZpc2VkLnF1ZXN0aW9uIHx8IHEucXVlc3Rpb24sIG9wdGlvbnM6IHJldmlzZWQub3B0aW9ucz8ubGVuZ3RoID4gMCA/IHJldmlzZWQub3B0aW9ucyA6IHEub3B0aW9ucywgY29ycmVjdEFuc3dlcjogcmV2aXNlZC5jb3JyZWN0QW5zd2VyIHx8IHEuY29ycmVjdEFuc3dlciB9IDogcSkpO1xuICAgIH07XG5cbiAgICAvLyBBdXRvLXNhdmUgcXVlc3Rpb25zIGhlbHBlciBmb3IgdW5zYXZlZCBxdWVzdGlvbnMgYmVmb3JlIHVwbG9hZGluZyBpbWFnZS9hdWRpb1xuICAgIGNvbnN0IGF1dG9TYXZlQmVmb3JlVXBsb2FkID0gYXN5bmMgKGlkeCkgPT4ge1xuICAgICAgICBsZXQgY3VycmVudFEgPSBxdWVzdGlvbnNbaWR4XTtcbiAgICAgICAgaWYgKCFjdXJyZW50US5pZCkge1xuICAgICAgICAgICAgY29uc3Qgc3VjY2VzcyA9IGF3YWl0IGhhbmRsZVNhdmVRdWVzdGlvbnMoKTtcbiAgICAgICAgICAgIGlmICghc3VjY2VzcykgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkTGlzdCA9IGF3YWl0IGdldFF1ZXN0aW9ucyhpZCk7XG4gICAgICAgICAgICBpZiAodXBkYXRlZExpc3Qub2sgJiYgQXJyYXkuaXNBcnJheSh1cGRhdGVkTGlzdC5kYXRhKSAmJiB1cGRhdGVkTGlzdC5kYXRhW2lkeF0pIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdXBkYXRlZExpc3QuZGF0YVtpZHhdLmlkO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjdXJyZW50US5pZDtcbiAgICB9O1xuXG4gICAgLy8gUGFzdGlrYW4gc29hbCBEQU4gb3BzaSBzdWRhaCBwdW55YSBpZCBhc2xpIGRhcmkgYmFja2VuZCBzZWJlbHVtIHVwbG9hZCBnYW1iYXIgb3BzaVxuY29uc3QgZW5zdXJlT3B0aW9uU2F2ZWQgPSBhc3luYyAoaWR4LCBvSWR4KSA9PiB7XG4gICAgY29uc3QgY3VycmVudE9wdCA9IHF1ZXN0aW9uc1tpZHhdPy5vcHRpb25zPy5bb0lkeF07XG4gICAgaWYgKHF1ZXN0aW9uc1tpZHhdPy5pZCAmJiBjdXJyZW50T3B0Py5pZCkge1xuICAgICAgICByZXR1cm4geyBxdWVzdGlvbklkOiBxdWVzdGlvbnNbaWR4XS5pZCwgb3B0aW9uSWQ6IGN1cnJlbnRPcHQuaWQgfTtcbiAgICB9XG4gICAgLy8gU2ltcGFuIGR1bHUgc3VwYXlhIGJhY2tlbmQgYXNzaWduIGlkIHVudHVrIHNvYWwgJiBvcHNpbnlhXG4gICAgY29uc3Qgc3VjY2VzcyA9IGF3YWl0IGhhbmRsZVNhdmVRdWVzdGlvbnMoKTtcbiAgICBpZiAoIXN1Y2Nlc3MpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgdXBkYXRlZExpc3QgPSBhd2FpdCBnZXRRdWVzdGlvbnMoaWQpO1xuICAgIGlmICh1cGRhdGVkTGlzdC5vayAmJiBBcnJheS5pc0FycmF5KHVwZGF0ZWRMaXN0LmRhdGEpKSB7XG4gICAgICAgIGNvbnN0IGZyZXNoUSA9IHVwZGF0ZWRMaXN0LmRhdGFbaWR4XTtcbiAgICAgICAgY29uc3QgZnJlc2hPcHQgPSBmcmVzaFE/Lm9wdGlvbnM/LltvSWR4XSA/PyBmcmVzaFE/Lm9wdGlvblF1ZXN0aW9ucz8uW29JZHhdO1xuICAgICAgICBpZiAoZnJlc2hRPy5pZCAmJiBmcmVzaE9wdD8uaWQpIHtcbiAgICAgICAgICAgIHJldHVybiB7IHF1ZXN0aW9uSWQ6IGZyZXNoUS5pZCwgb3B0aW9uSWQ6IGZyZXNoT3B0LmlkIH07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59O1xuXG4gICAgY29uc3QgaGFuZGxlVXBsb2FkUXVlc3Rpb25JbWFnZSA9IGFzeW5jIChpZHgsIGZpbGUpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHNuYXBzaG90QmVmb3JlVXBsb2FkID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShxdWVzdGlvbnNSZWYuY3VycmVudCkpO1xuICAgICAgICAgICAgY29uc3QgcUlkID0gYXdhaXQgYXV0b1NhdmVCZWZvcmVVcGxvYWQoaWR4KTtcbiAgICAgICAgICAgIGlmICghcUlkKSB7IHNob3dUb2FzdCgnR2FnYWwgbWVtcHJvc2VzIHNvYWwgc2ViZWx1bSBtZW5ndW5nZ2FoIGdhbWJhcicsICdlcnJvcicpOyByZXR1cm47IH1cblxuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdXBsb2FkUXVlc3Rpb25JbWFnZShpZCwgcUlkLCBmaWxlLCAocGN0KSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0VXBsb2FkUHJvZ3Jlc3MocHJldiA9PiAoeyAuLi5wcmV2LCBbaWR4XTogcGN0IH0pKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgICAgIHB1c2hIaXN0b3J5KHNuYXBzaG90QmVmb3JlVXBsb2FkKTtcbiAgICAgICAgICAgICAgICB1cGRhdGVRdWVzdGlvbihpZHgsICdxdWVzdGlvbkltYWdlJywgcmVzLmRhdGE/LnF1ZXN0aW9uSW1hZ2UgPz8gbnVsbCk7XG4gICAgICAgICAgICAgICAgc2hvd1RvYXN0KCdHYW1iYXIgc29hbCBiZXJoYXNpbCBkaXVuZ2dhaCEnKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW5ndW5nZ2FoIGdhbWJhcicsICdlcnJvcicpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tVcGxvYWQgSW1hZ2UgRXJyb3JdOicsIGVycik7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ1RlcmphZGkga2VzYWxhaGFuIHNhYXQgbWVuZ3VuZ2dhaCBnYW1iYXInLCAnZXJyb3InKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldFVwbG9hZFByb2dyZXNzKHByZXYgPT4gKHsgLi4ucHJldiwgW2lkeF06IG51bGwgfSkpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVVwbG9hZFF1ZXN0aW9uQXVkaW8gPSBhc3luYyAoaWR4LCBmaWxlKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBzbmFwc2hvdEJlZm9yZVVwbG9hZCA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocXVlc3Rpb25zUmVmLmN1cnJlbnQpKTtcbiAgICAgICAgICAgIGNvbnN0IHFJZCA9IGF3YWl0IGF1dG9TYXZlQmVmb3JlVXBsb2FkKGlkeCk7XG4gICAgICAgICAgICBpZiAoIXFJZCkgeyBzaG93VG9hc3QoJ0dhZ2FsIG1lbXByb3NlcyBzb2FsIHNlYmVsdW0gbWVuZ3VuZ2dhaCBhdWRpbycsICdlcnJvcicpOyByZXR1cm47IH1cblxuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdXBsb2FkUXVlc3Rpb25BdWRpbyhpZCwgcUlkLCBmaWxlLCAocGN0KSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0VXBsb2FkUHJvZ3Jlc3MocHJldiA9PiAoeyAuLi5wcmV2LCBbaWR4XTogcGN0IH0pKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgICAgIHB1c2hIaXN0b3J5KHNuYXBzaG90QmVmb3JlVXBsb2FkKTtcbiAgICAgICAgICAgICAgICB1cGRhdGVRdWVzdGlvbihpZHgsICdxdWVzdGlvbkF1ZGlvJywgcmVzLmRhdGE/LnF1ZXN0aW9uQXVkaW8gPz8gbnVsbCk7XG4gICAgICAgICAgICAgICAgc2hvd1RvYXN0KCdBdWRpbyBzb2FsIGJlcmhhc2lsIGRpdW5nZ2FoIScpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzaG93VG9hc3QocmVzLm1lc3NhZ2UgfHwgJ0dhZ2FsIG1lbmd1bmdnYWggYXVkaW8nLCAnZXJyb3InKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbVXBsb2FkIEF1ZGlvIEVycm9yXTonLCBlcnIpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KCdUZXJqYWRpIGtlc2FsYWhhbiBzYWF0IG1lbmd1bmdnYWggYXVkaW8nLCAnZXJyb3InKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldFVwbG9hZFByb2dyZXNzKHByZXYgPT4gKHsgLi4ucHJldiwgW2lkeF06IG51bGwgfSkpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgICAgICBjb25zdCBoYW5kbGVSZW1vdmVRdWVzdGlvbkltYWdlID0gKGlkeCkgPT4ge1xuICAgICAgICBwdXNoSGlzdG9yeShxdWVzdGlvbnMpO1xuICAgICAgICB1cGRhdGVRdWVzdGlvbihpZHgsICdxdWVzdGlvbkltYWdlJywgbnVsbCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlbW92ZVF1ZXN0aW9uQXVkaW8gPSAoaWR4KSA9PiB7XG4gICAgICAgIHB1c2hIaXN0b3J5KHF1ZXN0aW9ucyk7XG4gICAgICAgIHVwZGF0ZVF1ZXN0aW9uKGlkeCwgJ3F1ZXN0aW9uQXVkaW8nLCBudWxsKTtcbiAgICB9O1xuXG4gICAgY29uc3QgYWRkUXVlc3Rpb24gPSAoKSA9PiB7XG4gICAgICAgIC8vIEJVRy0zIEZJWDogcHVzaCBzbmFwc2hvdCBCRUZPUkUgbXV0YXRpb24gc28gdW5kbyByZXN0b3JlcyB0aGUgcHJldmlvdXMgc3RhdGVcbiAgICAgICAgcHVzaEhpc3RvcnkocXVlc3Rpb25zKTtcbiAgICAgICAgc2V0UXVlc3Rpb25zKHByZXYgPT4gWy4uLnByZXYsIG5ld1F1ZXN0aW9uKHByZXYubGVuZ3RoICsgMSldKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQWRkQUlRdWVzdGlvbnMgPSAobmV3R2VuZXJhdGVkUXVlc3Rpb25zKSA9PiB7XG4gICAgICAgIGlmICghbmV3R2VuZXJhdGVkUXVlc3Rpb25zIHx8IG5ld0dlbmVyYXRlZFF1ZXN0aW9ucy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgICAgICAgc2V0UXVlc3Rpb25zKHByZXYgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc3RhcnRPcmRlciA9IHByZXYubGVuZ3RoICsgMTtcbiAgICAgICAgICAgIGNvbnN0IG1hcHBlZCA9IG5ld0dlbmVyYXRlZFF1ZXN0aW9ucy5tYXAoKHEsIGlkeCkgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5xLFxuICAgICAgICAgICAgICAgIF9pZDogYHFfYWlfJHtEYXRlLm5vdygpfV8ke2lkeH1gLFxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uT3JkZXI6IHN0YXJ0T3JkZXIgKyBpZHgsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICByZXR1cm4gWy4uLnByZXYsIC4uLm1hcHBlZF07XG4gICAgICAgIH0pO1xuICAgICAgICBzaG93VG9hc3QoYEJlcmhhc2lsIG1lbmFtYmFoa2FuICR7bmV3R2VuZXJhdGVkUXVlc3Rpb25zLmxlbmd0aH0gYnV0aXIgc29hbCBkYXJpIEFJIWAsICdzdWNjZXNzJyk7XG4gICAgfTtcblxuICAgIGNvbnN0IG1vdmVRdWVzdGlvbiA9IChpZHgsIGRpcikgPT4ge1xuICAgICAgICAvLyBCVUctMyBGSVg6IHB1c2ggc25hcHNob3QgQkVGT1JFIG11dGF0aW9uXG4gICAgICAgIHB1c2hIaXN0b3J5KHF1ZXN0aW9ucyk7XG4gICAgICAgIHNldFF1ZXN0aW9ucyhwcmV2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGFyciA9IFsuLi5wcmV2XTtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGlkeCArIGRpcjtcbiAgICAgICAgICAgIGlmICh0YXJnZXQgPCAwIHx8IHRhcmdldCA+PSBhcnIubGVuZ3RoKSByZXR1cm4gYXJyO1xuICAgICAgICAgICAgW2FycltpZHhdLCBhcnJbdGFyZ2V0XV0gPSBbYXJyW3RhcmdldF0sIGFycltpZHhdXTtcbiAgICAgICAgICAgIHJldHVybiBhcnI7XG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCB1cGRhdGVRdWVzdGlvbiA9IChpZHgsIGZpZWxkLCB2YWx1ZSkgPT4ge1xuICAgICAgICAvLyBCVUctMyBGSVg6IHRyYWNrIHRleHQgZWRpdHMgaW4gdW5kby9yZWRvIGhpc3Rvcnkgd2l0aCBhIDUwMG1zIGRlYm91bmNlLlxuICAgICAgICAvLyBPbmx5IHRleHQtdHlwZSBmaWVsZHMgdHJpZ2dlciBoaXN0b3J5OyBzdHJ1Y3R1cmFsIGZpZWxkcyAodHlwZUlkLCBpc1JlcXVpcmVkLFxuICAgICAgICAvLyBpc1Njb3JhYmxlLCBwb2ludHMpIGFyZSBpbnRlbnRpb25hbGx5IGV4Y2x1ZGVkIOKAlCB0aG9zZSBjaGFuZ2VzIGFyZSByYXJlbHkgdW5kb25lXG4gICAgICAgIC8vIGFuZCBmaXJlIG9uIHNpbmdsZSBpbnRlcmFjdGlvbnMgKHRvZ2dsZXMvc2VsZWN0cyksIG5vdCBjb250aW51b3VzIHR5cGluZy5cbiAgICAgICAgY29uc3QgaXNUZXh0RmllbGQgPSBbJ3F1ZXN0aW9uJywgJ2NvcnJlY3RBbnN3ZXInXS5pbmNsdWRlcyhmaWVsZCk7XG4gICAgICAgIGlmIChpc1RleHRGaWVsZCkge1xuICAgICAgICAgICAgaWYgKHRleHRFZGl0RGVib3VuY2VSZWYuY3VycmVudCkgY2xlYXJUaW1lb3V0KHRleHRFZGl0RGVib3VuY2VSZWYuY3VycmVudCk7XG4gICAgICAgICAgICAvLyBDYXB0dXJlIHRoZSBDVVJSRU5UIHF1ZXN0aW9ucyBzdGF0ZSAoYmVmb3JlIHRoaXMga2V5c3Ryb2tlKSBmb3IgdGhlIHNuYXBzaG90LlxuICAgICAgICAgICAgLy8gV2Ugc3RvcmUgaXQgaW4gdGhlIHRpbWVvdXQgY2xvc3VyZSBzbyBzZXF1ZW50aWFsIGtleXN0cm9rZXMgcmV1c2UgdGhlIHNhbWVcbiAgICAgICAgICAgIC8vIHByZS1lZGl0IHNuYXBzaG90IHVudGlsIHRoZSB1c2VyIHBhdXNlcy5cbiAgICAgICAgICAgIGNvbnN0IHNuYXBzaG90QmVmb3JlRWRpdGluZyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocXVlc3Rpb25zKSk7XG4gICAgICAgICAgICB0ZXh0RWRpdERlYm91bmNlUmVmLmN1cnJlbnQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIWhpc3RvcnlVcGRhdGluZ1JlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIHB1c2hIaXN0b3J5KHNuYXBzaG90QmVmb3JlRWRpdGluZyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRleHRFZGl0RGVib3VuY2VSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgICAgICB9LCA1MDApO1xuICAgICAgICB9XG4gICAgICAgIHNldFF1ZXN0aW9ucyhwcmV2ID0+IHByZXYubWFwKChxLCBpKSA9PiBpID09PSBpZHggPyB7IC4uLnEsIFtmaWVsZF06IHZhbHVlIH0gOiBxKSk7XG4gICAgfTtcblxuICAgIGNvbnN0IG9wZW5JbnNlcnRNb2RhbCA9IChxSWR4LCBtb2RlLCB0YXJnZXRUeXBlID0gJ3F1ZXN0aW9uJywgb0lkeCA9IG51bGwpID0+IHtcbiAgICAgICAgc2V0TW9kYWxUYXJnZXQoeyB0eXBlOiB0YXJnZXRUeXBlLCBxSWR4LCBvSWR4IH0pO1xuICAgICAgICBzZXRNb2RhbE1vZGUobW9kZSk7XG4gICAgICAgIHNldE1vZGFsT3Blbih0cnVlKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlSW5zZXJ0RnJvbU1vZGFsID0gKHNuaXBwZXRIdG1sKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgdHlwZSwgcUlkeCwgb0lkeCB9ID0gbW9kYWxUYXJnZXQ7XG4gICAgICAgIGlmIChxSWR4ID09PSBudWxsKSByZXR1cm47XG5cbiAgICAgICAgaWYgKHR5cGUgPT09ICdvcHRpb24nICYmIG9JZHggIT09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnQgPSBxdWVzdGlvbnNbcUlkeF0/Lm9wdGlvbnM/LltvSWR4XT8ub3B0aW9uVGV4dCB8fCAnJztcbiAgICAgICAgICAgIHVwZGF0ZU9wdGlvbihxSWR4LCBvSWR4LCAnb3B0aW9uVGV4dCcsIGN1cnJlbnQgKyAoY3VycmVudCA/ICcgJyA6ICcnKSArIHNuaXBwZXRIdG1sKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnQgPSBxdWVzdGlvbnNbcUlkeF0/LnF1ZXN0aW9uIHx8ICcnO1xuICAgICAgICAgICAgdXBkYXRlUXVlc3Rpb24ocUlkeCwgJ3F1ZXN0aW9uJywgY3VycmVudCArIHNuaXBwZXRIdG1sKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCB0b2dnbGVQcmV2aWV3ID0gKGlkeCkgPT4ge1xuICAgICAgICBzZXRQcmV2aWV3VmlzaWJpbGl0eShwcmV2ID0+ICh7IC4uLnByZXYsIFtpZHhdOiAhcHJldltpZHhdIH0pKTtcbiAgICB9O1xuXG4gICAgY29uc3QgYWRkT3B0aW9uID0gKHFJZHgpID0+IHtcbiAgICAgICAgcHVzaEhpc3RvcnkocXVlc3Rpb25zKTtcbiAgICAgICAgc2V0UXVlc3Rpb25zKHByZXYgPT4gcHJldi5tYXAoKHEsIGkpID0+XG4gICAgICAgICAgICBpID09PSBxSWR4ID8geyAuLi5xLCBvcHRpb25zOiBbLi4ucS5vcHRpb25zLCB7IG9wdGlvblRleHQ6ICcnLCBpc0NvcnJlY3Q6IGZhbHNlIH1dIH0gOiBxXG4gICAgICAgICkpO1xuICAgIH07XG5cbiAgICBjb25zdCByZW1vdmVPcHRpb24gPSAocUlkeCwgb0lkeCkgPT4ge1xuICAgICAgICBwdXNoSGlzdG9yeShxdWVzdGlvbnMpO1xuICAgICAgICBzZXRRdWVzdGlvbnMocHJldiA9PiBwcmV2Lm1hcCgocSwgaSkgPT5cbiAgICAgICAgICAgIGkgPT09IHFJZHggPyB7IC4uLnEsIG9wdGlvbnM6IHEub3B0aW9ucy5maWx0ZXIoKF8sIG9pKSA9PiBvaSAhPT0gb0lkeCkgfSA6IHFcbiAgICAgICAgKSk7XG4gICAgfTtcblxuICAgIGNvbnN0IHVwZGF0ZU9wdGlvbiA9IChxSWR4LCBvSWR4LCBmaWVsZCwgdmFsKSA9PiB7XG4gICAgICAgIC8vIEJVRy0zIEZJWDogZGVib3VuY2VkIGhpc3RvcnkgZm9yIG9wdGlvbiB0ZXh0IGVkaXRzXG4gICAgICAgIGlmIChmaWVsZCA9PT0gJ29wdGlvblRleHQnKSB7XG4gICAgICAgICAgICBpZiAodGV4dEVkaXREZWJvdW5jZVJlZi5jdXJyZW50KSBjbGVhclRpbWVvdXQodGV4dEVkaXREZWJvdW5jZVJlZi5jdXJyZW50KTtcbiAgICAgICAgICAgIGNvbnN0IHNuYXBzaG90QmVmb3JlRWRpdGluZyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocXVlc3Rpb25zKSk7XG4gICAgICAgICAgICB0ZXh0RWRpdERlYm91bmNlUmVmLmN1cnJlbnQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIWhpc3RvcnlVcGRhdGluZ1JlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIHB1c2hIaXN0b3J5KHNuYXBzaG90QmVmb3JlRWRpdGluZyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRleHRFZGl0RGVib3VuY2VSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgICAgICB9LCA1MDApO1xuICAgICAgICB9XG4gICAgICAgIHNldFF1ZXN0aW9ucyhwcmV2ID0+IHByZXYubWFwKChxLCBpKSA9PiB7XG4gICAgICAgICAgICBpZiAoaSAhPT0gcUlkeCkgcmV0dXJuIHE7XG4gICAgICAgICAgICBjb25zdCBvcHRzID0gcS5vcHRpb25zLm1hcCgob3B0LCBvaSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChvaSAhPT0gb0lkeCkgcmV0dXJuIG9wdDtcbiAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5vcHQsIFtmaWVsZF06IHZhbCB9O1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm4geyAuLi5xLCBvcHRpb25zOiBvcHRzIH07XG4gICAgICAgIH0pKTtcbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmcpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWluLWgtc2NyZWVuIGJnLVsjRjRGOEY3XSBkYXJrOmJnLXNsYXRlLTk1MFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPk1lbXVhdCBidWlsZGVyIGZvcm11bGlyLi4uPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgaXNQdWJsaXNoZWQgPSBmb3JtPy5zdGF0dXM/LnRvTG93ZXJDYXNlKCkgPT09ICdwdWJsaXNoZWQnO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctWyNGNEY4RjddIGRhcms6Ymctc2xhdGUtOTUwIGZvbnQtc2FucyB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICA8U2lkZWJhciAvPlxuXG4gICAgICAgICAgICA8ZGl2IHJlZj17bWFpblNjcm9sbFJlZn0gY2xhc3NOYW1lPXtgZmxleC0xIGZsZXggZmxleC1jb2wgbWluLXctMCAke2lzU3BsaXRQcmV2aWV3ICYmIGFjdGl2ZVRhYiA9PT0gJ3F1ZXN0aW9ucycgPyAnaC1zY3JlZW4gb3ZlcmZsb3ctaGlkZGVuJyA6ICdtaW4taC1zY3JlZW4gb3ZlcmZsb3cteS1hdXRvJ31gfT5cblxuICAgICAgICAgICAgICAgIHsvKiBUb3AgSGVhZGVyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIHotMzAgYmctd2hpdGUvOTAgZGFyazpiZy1zbGF0ZS05MDAvOTAgYmFja2Ryb3AtYmx1ci1tZCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBweC00IHNtOnB4LTYgcHktMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNEaXJ0eSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDb25maXJtTW9kYWwoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNPcGVuOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdQZXJ1YmFoYW4gQmVsdW0gRGlzaW1wYW4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogJ0FkYSBwZXJ1YmFoYW4geWFuZyBiZWx1bSBkaXNpbXBhbi4gWWFraW4gaW5naW4gbWVuaW5nZ2Fsa2FuIGhhbGFtYW4gaW5pPycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50OiAnZGFuZ2VyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1UZXh0OiAnWWEsIFRpbmdnYWxrYW4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db25maXJtOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29uZmlybU1vZGFsKHByZXYgPT4gKHsgLi4ucHJldiwgaXNPcGVuOiBmYWxzZSB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmF2aWdhdGUoJy9teS1mb3JtcycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmF2aWdhdGUoJy9teS1mb3JtcycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX0gY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFycm93TGVmdCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1zbSBzbTp0ZXh0LWJhc2UgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+e2Zvcm0/LnRpdGxlIHx8ICdGb3JtdWxpciBUYW5wYSBKdWR1bCd9PC9oMT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsICR7aXNQdWJsaXNoZWQgPyAnYmctdGVhbC01MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOmJnLXRlYWwtOTUwLzYwIGRhcms6dGV4dC10ZWFsLTQwMCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwJyA6ICdiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNQdWJsaXNoZWQgPyAnUHVibGlrJyA6ICdEcmFmJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgZm9udC1tb25vXCI+L2Yve2Zvcm0/LmZvcm1MaW5rfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlVG9nZ2xlUHVibGlzaH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cHVibGlzaGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRvdXI9XCJidWlsZGVyLXB1Ymxpc2gtYnRuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7aXNQdWJsaXNoZWQgPyAnYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNjAgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAgaG92ZXI6YmctYW1iZXItMTAwJyA6ICdiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIHRleHQtd2hpdGUgc2hhZG93LXhzJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1B1Ymxpc2hlZCA/IDxMb2NrIHNpemU9ezE0fSAvPiA6IDxHbG9iZSBzaXplPXsxNH0gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPntwdWJsaXNoaW5nID8gJ01lbXByb3Nlcy4uLicgOiBpc1B1Ymxpc2hlZCA/ICdKYWRpa2FuIERyYWYnIDogJ1B1Ymxpa2FzaWthbid9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGRUFULTEzOiBQcmV2aWV3IGJ1dHRvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkxpaGF0IHNlYmFnYWkgUmVzcG9uZGVuIChQcmV2aWV3IFRhYiBCYXJ1KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS10b3VyPVwiYnVpbGRlci1wcmV2aWV3LWJ0blwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93Lm9wZW4oYC9mLyR7Zm9ybT8uZm9ybUxpbmt9P3ByZXZpZXc9dHJ1ZSZmb3JtSWQ9JHtmb3JtPy5pZH1gLCAnX2JsYW5rJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0yIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV5ZSBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QcmV2aWV3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTcGxpdC1TY3JlZW4gRHVhbCBWaWV3IEJ1dHRvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkR1YWwgVmlldzogVGFtcGlsa2FuIEVkaXRvciBkYW4gTGl2ZSBQcmV2aWV3IEJlcmRhbXBpbmdhblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNTcGxpdFByZXZpZXcocHJldiA9PiAhcHJldil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaGlkZGVuIGxnOmZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0yIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgYm9yZGVyIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzU3BsaXRQcmV2aWV3XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy10ZWFsLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci10ZWFsLTYwMCBzaGFkb3cteHMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbHVtbnMgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RHVhbCBWaWV3IHtpc1NwbGl0UHJldmlldyA/ICdPTicgOiAnT0ZGJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZFQVQtMTQ6IEF1dG9zYXZlIHRvZ2dsZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEF1dG9zYXZlRW5hYmxlZChwcmV2ID0+ICFwcmV2KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke2F1dG9zYXZlRW5hYmxlZCA/ICd0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCcgOiAndGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJTaW1wYW4gcGVydWJhaGFuIG90b21hdGlzIHNldGlhcCAxNSBkZXRpayBzYWF0IGFkYSBwZXJ1YmFoYW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2F1dG9zYXZlRW5hYmxlZCA/IDxUb2dnbGVSaWdodCBzaXplPXsxNn0gLz4gOiA8VG9nZ2xlTGVmdCBzaXplPXsxNn0gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkF1dG8tU2F2ZSB7YXV0b3NhdmVFbmFibGVkID8gJ09OJyA6ICdPRkYnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXV0b3NhdmVFbmFibGVkICYmIGF1dG9zYXZlTGFzdFNhdmVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2F1dG9zYXZlTGFzdFNhdmVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZUFsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdG91cj1cImJ1aWxkZXItc2F2ZS1idG5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNEaXJ0eVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctb3JhbmdlLTUwMCBob3ZlcjpiZy1vcmFuZ2UtNjAwIHRleHQtd2hpdGUgYW5pbWF0ZS1wdWxzZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgZGFyazpiZy1zbGF0ZS03MDAgZGFyazpob3ZlcjpiZy1zbGF0ZS02MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2F2ZSBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57c2F2aW5nID8gJ01lbnlpbXBhbi4uLicgOiBpc0RpcnR5ID8gJ+KaoCBTaW1wYW4gU2VrYXJhbmcnIDogJ1NpbXBhbiBQZXJ1YmFoYW4nfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogVG9tYm9sIFBhbmR1YW4gQnVpbGRlciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRCdWlsZGVyVG91ck9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNjAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgaG92ZXI6YmctdGVhbC0xMDAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUGFuZHVhbiBGb3JtIEJ1aWxkZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxIZWxwQ2lyY2xlIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBtZDppbmxpbmVcIj5QYW5kdWFuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAge3RvYXN0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BmaXhlZCB0b3AtMTYgcmlnaHQtNiB6LTUwIHB4LTQgcHktMyByb3VuZGVkLTJ4bCBzaGFkb3cteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSB0cmFuc2l0aW9uLWFsbCAke3RvYXN0LnR5cGUgPT09ICdlcnJvcicgPyAnYmctcmVkLTUwMCcgOiAnYmctWyMwMDg5N0JdJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0b2FzdC5tc2d9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7YXV0b3NhdmVUb2FzdCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgdG9wLTE2IHJpZ2h0LTYgei01MCBweC00IHB5LTMgcm91bmRlZC0yeGwgc2hhZG93LXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctdGVhbC02MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTYXZlIHNpemU9ezEzfSAvPiB7YXV0b3NhdmVUb2FzdH1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBTdWItSGVhZGVyIFRhYnMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHB4LTZcIiBkYXRhLXRvdXI9XCJidWlsZGVyLXRhYnNcIj5cbiAgICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAncXVlc3Rpb25zJywgbGFiZWw6ICdQZXJ0YW55YWFuICYgU29hbCcsIHRvdXJJZDogJ3RhYi1xdWVzdGlvbnMnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3NldHRpbmdzJywgbGFiZWw6ICdQZW5nYXR1cmFuICYgQXR1cmFuJywgdG91cklkOiAndGFiLXNldHRpbmdzJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdzaGFyZScsIGxhYmVsOiAnQmFnaWthbiAmIEtvZGUgUVInLCB0b3VySWQ6ICd0YWItc2hhcmUnIH0sXG4gICAgICAgICAgICAgICAgICAgIF0ubWFwKHQgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dC5rZXl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS10b3VyPXt0LnRvdXJJZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYih0LmtleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0LmtleSA9PT0gJ3NoYXJlJykgaGFuZGxlTG9hZFNoYXJlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0zLjUgcHgtNSB0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgJHthY3RpdmVUYWIgPT09IHQua2V5ID8gJ2JvcmRlci1bIzAwODk3Ql0gdGV4dC1bIzAwODk3Ql0gZGFyazpib3JkZXItdGVhbC00MDAgZGFyazp0ZXh0LXRlYWwtNDAwJyA6ICdib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0LmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BwLTQgc206cC02IGxnOnAtOCBteC1hdXRvIHctZnVsbCB0cmFuc2l0aW9uLWFsbCAke2lzU3BsaXRQcmV2aWV3ICYmIGFjdGl2ZVRhYiA9PT0gJ3F1ZXN0aW9ucycgPyAnbWF4LXctWzE3MDBweF0gZmxleC0xIGgtW2NhbGMoMTAwdmgtMTIwcHgpXSBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCcgOiAnbWF4LXctNHhsIHNwYWNlLXktNiBmbGV4LTEnfWB9PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiDilIDilIAgUVVFU1RJT05TIFRBQiDilIDilIAgKi99XG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdxdWVzdGlvbnMnICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBmbGV4LWNvbCAke2lzU3BsaXRQcmV2aWV3ID8gJ2xnOmZsZXgtcm93IGdhcC02IGl0ZW1zLXN0YXJ0IGgtZnVsbCBvdmVyZmxvdy1oaWRkZW4nIDogJ2dhcC02J31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTGVmdCBDb2x1bW46IEZvcm0gRWRpdG9yICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy1mdWxsIHNwYWNlLXktNiBmbGV4LTEgJHtpc1NwbGl0UHJldmlldyA/ICdsZzp3LVs1NCVdIGgtZnVsbCBvdmVyZmxvdy15LWF1dG8gcHItMiBwYi0yNCcgOiAnJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZvcm0gSGVhZGVyIEluZm8gQ2FyZCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTYgc3BhY2UteS00IHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPkp1ZHVsIEZvcm11bGlyPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybT8udGl0bGUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybShmID0+ICh7IC4uLmYsIHRpdGxlOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25CbHVyPXsoKSA9PiB1cGRhdGVGb3JtKGlkLCB7IHRpdGxlOiBmb3JtLnRpdGxlLCBkZXNjcmlwdGlvbjogZm9ybS5kZXNjcmlwdGlvbiB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkp1ZHVsIEZvcm11bGlyLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14bCBmb250LWV4dHJhYm9sZCBiZy10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgYm9yZGVyLWIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1zbGF0ZS0yMDAgZGFyazpob3Zlcjpib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1bIzAwODk3Ql0gZm9jdXM6b3V0bGluZS1ub25lIHB5LTEgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5EZXNrcmlwc2kgRm9ybXVsaXI8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJsb2NrUXVlc3Rpb25FZGl0b3JcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybT8uZGVzY3JpcHRpb24gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhuZXdIdG1sKSA9PiBzZXRGb3JtKGYgPT4gKHsgLi4uZiwgZGVzY3JpcHRpb246IG5ld0h0bWwgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVHVsaXNrYW4gcGV0dW5qdWsgYXRhdSBkZXNrcmlwc2kgdW11bSBmb3JtdWxpci4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQmFubmVyIEltYWdlIFVwbG9hZCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtPy5iYW5uZXJJbWFnZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXthc3NldFVybChmb3JtLmJhbm5lckltYWdlKX0gYWx0PVwiQmFubmVyXCIgY2xhc3NOYW1lPVwidy0xNiBoLTEwIG9iamVjdC1jb3ZlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtPy5iYW5uZXJJbWFnZSA/ICdHYW1iYXIgQmFubmVyIFRlcnBhc2FuZycgOiAnQmVsdW0gQWRhIEdhbWJhciBCYW5uZXInfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXBsb2FkIHNpemU9ezEzfSAvPiB7Zm9ybT8uYmFubmVySW1hZ2UgPyAnVWJhaCBCYW5uZXInIDogJ1VuZ2dhaCBCYW5uZXInfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlLypcIiBjbGFzc05hbWU9XCJoaWRkZW5cIiBvbkNoYW5nZT17aGFuZGxlQmFubmVyVXBsb2FkfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEItMTogVG90YWwgTWFrc2ltYWwgU2tvciBJbmZvIENhcmQgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwLTMgcm91bmRlZC0yeGwgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQteGwgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTbGlkZXJzIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW0gbGVhZGluZy10aWdodFwiPlRvdGFsIE1ha3NpbWFsIFNrb3I8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy10aWdodFwiPnt0b3RhbE1heFNjb3JlfSBwb2luPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkp1bWxhaCBTb2FsPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RvdGFsUXVlc3Rpb25zID4gMCA/IHRvdGFsUXVlc3Rpb25zIDogcXVlc3Rpb25zLmxlbmd0aH0gc29hbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQUkgR2VuZXJhdG9yICYgRmlsZSBJbXBvcnQgQmFyICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQUkgR2VuZXJhdG9yIEJhbm5lciBDYXJkICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLTJ4bCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS10b3VyPVwiYnVpbGRlci1haS1nZW5lcmF0b3JcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQteGwgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciBib3JkZXItdGVhbC0xMDAgZGFyazpib3JkZXItdGVhbC05MDAvNDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJ1YXQgU29hbCBPdG9tYXRpcyBkZW5nYW4gQUlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBLZXRpayB0b3BpayBhdGF1IHBhc3RlIG1hdGVyaSwgQUkgbWVueXVzdW4gc29hbCwgb3BzaSwgZGFuIGt1bmNpIGphd2FiYW4gaW5zdGFuLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBaU1vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+R2VuZXJhdGUgU29hbCBBSTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUXVlc3Rpb24gSW1wb3J0IEJhciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtXCI+VGVtcGxhdGU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Wydjc3YnLCAneGxzeCcsICdkb2N4J10ubWFwKGZtdCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Zm10fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3RlbXBsYXRlRG93bmxvYWRVcmwoZm10KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yIHB5LTEgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHJvdW5kZWQtbGcgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgc2l6ZT17MTF9IC8+IC57Zm10LnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJbXBvcnRNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCBzaHJpbmstMCBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVVwIHNpemU9ezEzfSAvPiBJbXBvciBGaWxlIChQcmV2aWV3IER1bHUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEMtMjogU2VhcmNoIEJveCArIFN0YXRzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNSBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xIG1pbi13LVsyNDBweF0gbWF4LXctbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoVGVybX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFRlcm0oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ2FyaSBzb2FsIGJlcmRhc2Fya2FuIHRla3MuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC0xMCBwci00IHB5LTIuNSB0ZXh0LXNtIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwLzUwIGZvY3VzOmJvcmRlci10ZWFsLTUwMC82MCBwbGFjZWhvbGRlcjp0ZXh0LXNsYXRlLTQwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHctNCBoLTQgdGV4dC1zbGF0ZS00MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2VXaWR0aD1cIjJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgZD1cIk0yMSAyMWwtNi02bTItNWE3IDcgMCAxMS0xNCAwIDcgNyAwIDAxMTQgMHpcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VhcmNoVGVybSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRTZWFyY2hUZXJtKCcnKTsgc2V0RGVib3VuY2VkU2VhcmNoKCcnKTsgc2V0Q3VycmVudFBhZ2UoMSk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWFyY2hUZXJtIHx8IHRvdGFsUXVlc3Rpb25zID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Pk1lbmFtcGlsa2FuIGhhbGFtYW4gPGI+e2N1cnJlbnRQYWdlfTwvYj4gZGFyaSA8Yj57TWF0aC5tYXgoMSwgTWF0aC5jZWlsKHRvdGFsUXVlc3Rpb25zIC8gcGFnZVNpemUpKX08L2I+IMK3IFRvdGFsIHt0b3RhbFF1ZXN0aW9uc30gc29hbDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PkJlbHVtIGFkYSBzb2FsIMK3IFRhbWJhaGthbiBzb2FsIGF0YXUgaW1wb3IgZGFyaSBmaWxlPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBRdWVzdGlvbiBDYXJkcyBMaXN0ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtxdWVzdGlvbnMubWFwKChxLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3EuX2lkIHx8IGlkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRvdXI9e2lkeCA9PT0gMCA/IFwiYnVpbGRlci1maXJzdC1xdWVzdGlvblwiIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTYgc3BhY2UteS00IHNoYWRvdy14cyBob3Zlcjpib3JkZXItc2xhdGUtMzAwIGRhcms6aG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENhcmQgSGVhZGVyIENvbnRyb2xzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2J1bGtSZXZpc2VNb2RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17YnVsa1JldmlzZVNlbGVjdGVkLmhhcyhpZHgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRCdWxrUmV2aXNlU2VsZWN0ZWQocHJldiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBTZXQocHJldik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGUudGFyZ2V0LmNoZWNrZWQpIG5leHQuYWRkKGlkeCk7IGVsc2UgbmV4dC5kZWxldGUoaWR4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcHVycGxlLTYwMCByb3VuZGVkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcHgtMi41IHB5LTEgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNvYWwgI3tpZHggKyAxfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlUHJldmlldyhpZHgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtwcmV2aWV3VmlzaWJpbGl0eVtpZHhdID8gJ2JnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAnIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDAnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJUb2dnbGUgTGl2ZSBQcmV2aWV3XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJldmlld1Zpc2liaWxpdHlbaWR4XSA/IDxFeWVPZmYgc2l6ZT17MTV9IC8+IDogPEV5ZSBzaXplPXsxNX0gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFJLTI6IFJldmlzaSBBSSBwZXIgc29hbCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRvdXI9e2lkeCA9PT0gMCA/ICdidWlsZGVyLXF1ZXN0aW9uLXJldmlzZScgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRBaVJldmlzZU9wZW5JZHgoYWlSZXZpc2VPcGVuSWR4ID09PSBpZHggPyBudWxsIDogaWR4KTsgc2V0QWlSZXZpc2VJbnN0cnVjdGlvbignJyk7IHNldEFpUmV2aXNlRXJyb3IoJycpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHthaVJldmlzZU9wZW5JZHggPT09IGlkeCA/ICdiZy1wdXJwbGUtNTAgZGFyazpiZy1wdXJwbGUtOTUwLzYwIHRleHQtcHVycGxlLTYwMCBkYXJrOnRleHQtcHVycGxlLTQwMCcgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1wdXJwbGUtNTAwIGRhcms6aG92ZXI6dGV4dC1wdXJwbGUtNDAwJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmV2aXNpIHNvYWwgZGVuZ2FuIEFJXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8V2FuZDIgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQgdy1weCBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS03MDAgbXgtMVwiIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbW92ZVF1ZXN0aW9uKGlkeCwgLTEpfSBkaXNhYmxlZD17aWR4ID09PSAwfSBjbGFzc05hbWU9XCJwLTEgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBkaXNhYmxlZDpvcGFjaXR5LTMwIGN1cnNvci1wb2ludGVyXCIgdGl0bGU9XCJQaW5kYWggTmFpa1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uVXAgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbW92ZVF1ZXN0aW9uKGlkeCwgMSl9IGRpc2FibGVkPXtpZHggPT09IHF1ZXN0aW9ucy5sZW5ndGggLSAxfSBjbGFzc05hbWU9XCJwLTEgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBkaXNhYmxlZDpvcGFjaXR5LTMwIGN1cnNvci1wb2ludGVyXCIgdGl0bGU9XCJQaW5kYWggVHVydW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGRUFULTEwYTogRHVwbGlrYXQgc29hbCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlRHVwbGljYXRlUXVlc3Rpb24oaWR4KX0gY2xhc3NOYW1lPVwicC0xIHRleHQtYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTYwMCBjdXJzb3ItcG9pbnRlclwiIHRpdGxlPVwiRHVwbGlrYXQgU29hbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDb3B5IHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZVF1ZXN0aW9uKGlkeCl9IGNsYXNzTmFtZT1cInAtMSB0ZXh0LXJlZC00MDAgaG92ZXI6dGV4dC1yZWQtNjAwIGN1cnNvci1wb2ludGVyXCIgdGl0bGU9XCJIYXB1cyBTb2FsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBNZWRpYSBBdHRhY2htZW50cyBhdCB0aGUgVE9QIG9mIHRoZSBRdWVzdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCMTogTGl2ZSBVcGxvYWQgUHJvZ3Jlc3MgQmFyIFVJICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXBsb2FkUHJvZ3Jlc3NbaWR4XSAhPSBudWxsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC82MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIHJvdW5kZWQteGwgcC0yLjUgc3BhY2UteS0xLjUgYW5pbWF0ZS1mYWRlSW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC10ZWFsLTgwMCBkYXJrOnRleHQtdGVhbC0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgc2l6ZT17MTJ9IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiB0ZXh0LXRlYWwtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1lbmd1bmdnYWggbWVkaWEga2Ugc2VydmVyICh7dXBsb2FkUHJvZ3Jlc3NbaWR4XX0lKS4uLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt1cGxvYWRQcm9ncmVzc1tpZHhdfSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdGVhbC0yMDAvNjAgZGFyazpiZy10ZWFsLTkwMC82MCBoLTEuNSByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXRlYWwtNjAwIGgtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHt1cGxvYWRQcm9ncmVzc1tpZHhdfSVgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEltYWdlIGF0dGFjaG1lbnQgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS5xdWVzdGlvbkltYWdlID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgcC0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17YXNzZXRVcmwocS5xdWVzdGlvbkltYWdlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIlNvYWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCB3LTI0IG9iamVjdC1jb3ZlciByb3VuZGVkLWxnIGN1cnNvci16b29tLWluIGhvdmVyOm9wYWNpdHktOTAgdHJhbnNpdGlvbi1vcGFjaXR5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExpZ2h0Ym94SW1hZ2UoeyBzcmM6IGFzc2V0VXJsKHEucXVlc3Rpb25JbWFnZSksIGFsdDogJ0dhbWJhciBTb2FsJyB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiS2xpayB1bnR1ayBtZW1wZXJiZXNhciBnYW1iYXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwIGN1cnNvci1wb2ludGVyIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdhbnRpIEdhbWJhclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlLypcIiBjbGFzc05hbWU9XCJoaWRkZW5cIiBvbkNoYW5nZT17ZSA9PiBlLnRhcmdldC5maWxlcz8uWzBdICYmIGhhbmRsZVVwbG9hZFF1ZXN0aW9uSW1hZ2UoaWR4LCBlLnRhcmdldC5maWxlc1swXSl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZVF1ZXN0aW9uSW1hZ2UoaWR4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1yZWQtNTAwIGhvdmVyOnVuZGVybGluZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTF9IC8+IEhhcHVzIEdhbWJhclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgY3Vyc29yLXBvaW50ZXIgaG92ZXI6Ym9yZGVyLVsjMDA4OTdCXSBob3Zlcjp0ZXh0LVsjMDA4OTdCXSB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc2l6ZT17MTN9IC8+IFRhbWJhaCBHYW1iYXIgU29hbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qXCIgY2xhc3NOYW1lPVwiaGlkZGVuXCIgb25DaGFuZ2U9e2UgPT4gZS50YXJnZXQuZmlsZXM/LlswXSAmJiBoYW5kbGVVcGxvYWRRdWVzdGlvbkltYWdlKGlkeCwgZS50YXJnZXQuZmlsZXNbMF0pfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQXVkaW8gYXR0YWNobWVudCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtxLnF1ZXN0aW9uQXVkaW8gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBwLTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGF1ZGlvIGNvbnRyb2xzIHNyYz17YXNzZXRVcmwocS5xdWVzdGlvbkF1ZGlvKX0gY2xhc3NOYW1lPVwiaC04IG1heC13LVsyMDBweF1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwIGN1cnNvci1wb2ludGVyIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdhbnRpIEF1ZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgYWNjZXB0PVwiYXVkaW8vKlwiIGNsYXNzTmFtZT1cImhpZGRlblwiIG9uQ2hhbmdlPXtlID0+IGUudGFyZ2V0LmZpbGVzPy5bMF0gJiYgaGFuZGxlVXBsb2FkUXVlc3Rpb25BdWRpbyhpZHgsIGUudGFyZ2V0LmZpbGVzWzBdKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlUXVlc3Rpb25BdWRpbyhpZHgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXJlZC01MDAgaG92ZXI6dW5kZXJsaW5lIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBzaXplPXsxMX0gLz4gSGFwdXMgQXVkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGN1cnNvci1wb2ludGVyIGhvdmVyOmJvcmRlci1bIzAwODk3Ql0gaG92ZXI6dGV4dC1bIzAwODk3Ql0gdHJhbnNpdGlvbi1hbGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE11c2ljIHNpemU9ezEzfSAvPiBUYW1iYWggQXVkaW8gU29hbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJhdWRpby8qXCIgY2xhc3NOYW1lPVwiaGlkZGVuXCIgb25DaGFuZ2U9e2UgPT4gZS50YXJnZXQuZmlsZXM/LlswXSAmJiBoYW5kbGVVcGxvYWRRdWVzdGlvbkF1ZGlvKGlkeCwgZS50YXJnZXQuZmlsZXNbMF0pfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBRdWVzdGlvbiBCbG9jayBFZGl0b3IgKE1vZHVsYXIgTm90aW9uLXN0eWxlKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBibG9ja1wiPklzaSBQZXJ0YW55YWFuIFNvYWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmxvY2tRdWVzdGlvbkVkaXRvclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3EucXVlc3Rpb24gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KG5ld0h0bWwpID0+IHVwZGF0ZVF1ZXN0aW9uKGlkeCwgJ3F1ZXN0aW9uJywgbmV3SHRtbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlR1bGlza2FuIHRla3MgcGVydGFueWFhbiBzb2FsLCBrb2RlIHByb2dyYW0sIGF0YXUgcnVtdXMuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIExpdmUgUHJldmlldyBCb3ggd2l0aCBXb3JkIFdyYXAgRml4ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcmV2aWV3VmlzaWJpbGl0eVtpZHhdICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvODAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgc3BhY2UteS0yIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+TGl2ZSBQcmV2aWV3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyZWFrLXdvcmRzIGJyZWFrLWFsbCBbb3ZlcmZsb3ctd3JhcDphbnl3aGVyZV1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmljaENvbnRlbnRSZW5kZXJlciBjb250ZW50PXtxLnF1ZXN0aW9ufSBmb3JtYXQ9e3EucXVlc3Rpb25Gb3JtYXR9IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFJLTI6IElubGluZSBBSSBSZXZpc2UgUGFuZWwgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FpUmV2aXNlT3BlbklkeCA9PT0gaWR4ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1wdXJwbGUtNTAgZGFyazpiZy1wdXJwbGUtOTUwLzQwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIGRhcms6Ym9yZGVyLXB1cnBsZS04MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS03MDAgZGFyazp0ZXh0LXB1cnBsZS0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxXYW5kMiBzaXplPXsxM30gLz4gUmV2aXNpIFNvYWwgZGVuZ2FuIEFJXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtyZXZpc2VNb2RlbH0gb25DaGFuZ2U9e2UgPT4geyBzZXRSZXZpc2VNb2RlbChlLnRhcmdldC52YWx1ZSk7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdmb3JtdXBfc2VsZWN0ZWRfbW9kZWxfY2hhdCcsIGUudGFyZ2V0LnZhbHVlKTsgfX0gY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMS41IHRleHQteHMgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIGRhcms6Ym9yZGVyLXB1cnBsZS03MDAgcm91bmRlZC14bCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge0FWQUlMQUJMRV9NT0RFTFMubWFwKG1vZGVsID0+IDxvcHRpb24ga2V5PXttb2RlbC5pZCB8fCBtb2RlbC5uYW1lfSB2YWx1ZT17bW9kZWwuaWQgfHwgbW9kZWwubmFtZX0+e21vZGVsLm5hbWUgfHwgbW9kZWwuaWR9PC9vcHRpb24+KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FpUmV2aXNlRXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yZWQtNTAwXCI+e2FpUmV2aXNlRXJyb3J9PC9wPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXthaVJldmlzZUluc3RydWN0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRBaVJldmlzZUluc3RydWN0aW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJJbnN0cnVrc2k6IEJ1YXQgbGViaWggc3VsaXQsIGdhbnRpIGtvbnRla3Mga2UgZWtvc2lzdGVtIGxhdXQuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtMyBweS0xLjUgdGV4dC14cyBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDAgZGFyazpib3JkZXItcHVycGxlLTcwMCByb3VuZGVkLXhsIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLXB1cnBsZS01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17YWlSZXZpc2luZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFpUmV2aXNlKGlkeCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXthaVJldmlzaW5nIHx8ICFhaVJldmlzZUluc3RydWN0aW9uLnRyaW0oKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtNzAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthaVJldmlzaW5nID8gPHNwYW4gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCI+4ouvPC9zcGFuPiA6IDxXYW5kMiBzaXplPXsxM30gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJldmlzaVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUXVlc3Rpb24gVHlwZSAmIFNldHRpbmdzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPlRpcGUgU29hbDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3EudHlwZUlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHVwZGF0ZVF1ZXN0aW9uKGlkeCwgJ3R5cGVJZCcsIHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1ib2xkIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1FVRVNUSU9OX1RZUEVTLm1hcCh0ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3QuaWR9IHZhbHVlPXt0LmlkfT57dC5sYWJlbH08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC00IHB0LTEgc206cHQtNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cS5pc1Njb3JhYmxlICE9PSBmYWxzZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gdXBkYXRlUXVlc3Rpb24oaWR4LCAnaXNTY29yYWJsZScsIGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyMwMDg5N0JdIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+SGl0dW5nIGtlIFNrb3IgKERpbmlsYWkpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17ISFxLmlzUmVxdWlyZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHVwZGF0ZVF1ZXN0aW9uKGlkeCwgJ2lzUmVxdWlyZWQnLCBlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjMDA4OTdCXSByb3VuZGVkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNvYWwgV2FqaWIgRGlpc2k8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQb2ludHMgaW5wdXQg4oCUIHZpc2libGUgb25seSB3aGVuIHNjb3JhYmxlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtxLmlzU2NvcmFibGUgIT09IGZhbHNlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgd2hpdGVzcGFjZS1ub3dyYXBcIj5Qb2luIFNvYWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiS29zb25naSA9IGJvYm90IHNhbWEgcmF0YVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3EucG9pbnRzID8/ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHVwZGF0ZVF1ZXN0aW9uKGlkeCwgJ3BvaW50cycsIGUudGFyZ2V0LnZhbHVlID09PSAnJyA/IG51bGwgOiBwYXJzZUludChlLnRhcmdldC52YWx1ZSwgMTApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1ib2xkIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBpdGFsaWNcIj5vcHNpb25hbCDigJQgYmlhcmthbiBrb3NvbmcgdW50dWsgYm9ib3Qgc2FtYSByYXRhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE5vbi1TY29yYWJsZSBOb3RpY2UgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EuaXNTY29yYWJsZSA9PT0gZmFsc2UgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMC84MCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctc2xhdGUtNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNvYWwgaW5pIDxiPlRpZGFrIERpbmlsYWk8L2I+IChkaWd1bmFrYW4gdW50dWsgcGVuZ3VtcHVsYW4gZGF0YSBzZXBlcnRpIE5hbWEsIEVtYWlsLCBOSU0sIGF0YXUgc3VydmVpIHVtdW0pLiBUaWRhayBtZW1lcmx1a2FuIGt1bmNpIGphd2FiYW4gZGFuIHRpZGFrIG1lbWVuZ2FydWhpIHNrb3IuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25lZWRzT3B0aW9ucyhxLnR5cGVJZCkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJsb2NrXCI+UGlsaWhhbiBKYXdhYmFuOjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EuaXNTY29yYWJsZSAhPT0gZmFsc2UgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS50eXBlSWQgPT09IDJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICfil48gUGlsaWggMSBqYXdhYmFuIGJlbmFyIChyYWRpbyknXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAn4piRIENlbnRhbmcgc2VtdWEgamF3YWJhbiBiZW5hcid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS5vcHRpb25zLm1hcCgob3B0LCBvSWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e29wdC5faWQgfHwgb3B0LmlkIHx8IGBvcHRfJHtpZHh9XyR7b0lkeH1gfSBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EuaXNTY29yYWJsZSAhPT0gZmFsc2UgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtxLnR5cGVJZCA9PT0gMiA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRBU0sgMzogTXVsdGlwbGUgQ2hvaWNlIOKGkiByYWRpbyAoc2luZ2xlLXNlbGVjdClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17YGNvcnJlY3RfcSR7aWR4fWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17ISFvcHQuaXNDb3JyZWN0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFF1ZXN0aW9ucyhwcmV2ID0+IHByZXYubWFwKChxcSwgcWkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChxaSAhPT0gaWR4KSByZXR1cm4gcXE7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnFxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IHFxLm9wdGlvbnMubWFwKChvLCBvaSkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ubyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0OiBvaSA9PT0gb0lkeCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wIGN1cnNvci1wb2ludGVyIGFjY2VudC1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVGFuZGFpIHNlYmFnYWkgc2F0dS1zYXR1bnlhIGphd2FiYW4gYmVuYXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRBU0sgMzogQ2hlY2tib3ggdHlwZSDihpIgY2hlY2tib3ggKG11bHRpLXNlbGVjdCB1bmNoYW5nZWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9eyEhb3B0LmlzQ29ycmVjdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiB1cGRhdGVPcHRpb24oaWR4LCBvSWR4LCAnaXNDb3JyZWN0JywgZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjMDA4OTdCXSByb3VuZGVkIHNocmluay0wIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlRhbmRhaSBzZWJhZ2FpIGphd2FiYW4gYmVuYXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdC5pc0NvcnJlY3QgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIHB4LTEuNSBweS0wLjUgcm91bmRlZFwiPuKckyBCZW5hcjwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHJvdW5kZWQtZnVsbCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7U3RyaW5nLmZyb21DaGFyQ29kZSg2NSArIG9JZHgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtgUGlsaWhhbiAke29JZHggKyAxfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvcHQub3B0aW9uVGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gdXBkYXRlT3B0aW9uKGlkeCwgb0lkeCwgJ29wdGlvblRleHQnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXhzIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuSW5zZXJ0TW9kYWwoaWR4LCAnbWF0aCcsICdvcHRpb24nLCBvSWR4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtdGVhbC02MDAgZGFyazpob3Zlcjp0ZXh0LXRlYWwtNDAwIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlNpc2lwa2FuIFJ1bXVzIChLYVRlWClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhbGN1bGF0b3Igc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3Blbkluc2VydE1vZGFsKGlkeCwgJ2NvZGUnLCAnb3B0aW9uJywgb0lkeCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIGRhcms6aG92ZXI6dGV4dC10ZWFsLTQwMCByb3VuZGVkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJTaXNpcGthbiBLb2RlIEJsb2NrXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDb2RlIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGRUFULTc6IEltYWdlIHVwbG9hZCBwZXIgb3B0aW9uICovfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtdGVhbC02MDAgZGFyazpob3Zlcjp0ZXh0LXRlYWwtNDAwIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVGFtYmFoIEdhbWJhciBPcHNpIChtYWtzIDUwMEtCKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dXBsb2FkUHJvZ3Jlc3NbYG9wdGlvbi0ke2lkeH0tJHtvSWR4fWBdICE9IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXthc3luYyBlID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFmaWxlKSByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlsZS5zaXplID4gNTAwICogMTAyNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dUb2FzdCgnR2FtYmFyIG9wc2kgdGVybGFsdSBiZXNhciAobWFrcyA1MDBLQikuJywgJ2Vycm9yJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBsb2FkS2V5ID0gYG9wdGlvbi0ke2lkeH0tJHtvSWR4fWA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRVcGxvYWRQcm9ncmVzcyhwcmV2ID0+ICh7IC4uLnByZXYsIFt1cGxvYWRLZXldOiAwIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlkcyA9IGF3YWl0IGVuc3VyZU9wdGlvblNhdmVkKGlkeCwgb0lkeCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlkcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dUb2FzdCgnR2FnYWwgbWVtcHJvc2VzIG9wc2kgc2ViZWx1bSBtZW5ndW5nZ2FoIGdhbWJhcicsICdlcnJvcicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID0gJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VXBsb2FkUHJvZ3Jlc3MocHJldiA9PiAoeyAuLi5wcmV2LCBbdXBsb2FkS2V5XTogbnVsbCB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB1cGxvYWRPcHRpb25JbWFnZShpZCwgaWRzLnF1ZXN0aW9uSWQsIGlkcy5vcHRpb25JZCwgZmlsZSwgKHBjdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRVcGxvYWRQcm9ncmVzcyhwcmV2ID0+ICh7IC4uLnByZXYsIFt1cGxvYWRLZXldOiBwY3QgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVzaEhpc3RvcnkocXVlc3Rpb25zKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlT3B0aW9uKGlkeCwgb0lkeCwgJ29wdGlvbkltYWdlJywgcmVzLmRhdGE/Lm9wdGlvbkltYWdlID8/IHJlcy5kYXRhPy51cmwgPz8gbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dUb2FzdCgnR2FtYmFyIG9wc2kgYmVyaGFzaWwgZGl1bmdnYWghJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1RvYXN0KHJlcy5tZXNzYWdlIHx8ICdHYWdhbCBtZW5ndW5nZ2FoIGdhbWJhciBvcHNpJywgJ2Vycm9yJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignW1VwbG9hZCBPcHRpb24gSW1hZ2UgRXJyb3JdOicsIGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1RvYXN0KCdUZXJqYWRpIGtlc2FsYWhhbiBzYWF0IG1lbmd1bmdnYWggZ2FtYmFyIG9wc2knLCAnZXJyb3InKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VXBsb2FkUHJvZ3Jlc3MocHJldiA9PiAoeyAuLi5wcmV2LCBbdXBsb2FkS2V5XTogbnVsbCB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSA9ICcnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3VwbG9hZFByb2dyZXNzW2BvcHRpb24tJHtpZHh9LSR7b0lkeH1gXSAhPSBudWxsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIiB0aXRsZT1cIk1lbmd1bmdnYWggZ2FtYmFyIG9wc2lcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgc2l6ZT17MTJ9IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMTYgaC0xLjUgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlbiBiZy10ZWFsLTEwMCBkYXJrOmJnLXRlYWwtOTUwLzYwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBoLWZ1bGwgcm91bmRlZC1mdWxsIGJnLXRlYWwtNjAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiIHN0eWxlPXt7IHdpZHRoOiBgJHt1cGxvYWRQcm9ncmVzc1tgb3B0aW9uLSR7aWR4fS0ke29JZHh9YF19JWAgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXBsb2FkUHJvZ3Jlc3NbYG9wdGlvbi0ke2lkeH0tJHtvSWR4fWBdfSVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVtb3ZlT3B0aW9uKGlkeCwgb0lkeCl9IGNsYXNzTmFtZT1cInRleHQtcmVkLTQwMCBob3Zlcjp0ZXh0LXJlZC02MDAgcC0xIHNocmluay0wIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUHJldmlldyBmb3JtdWxhL2NvZGUgKGJ1a2FuIGltYWdlLCBrYXJlbmEgaW1hZ2Ugc2VrYXJhbmcgZGkgZmllbGQgdGVycGlzYWgpICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KG9wdC5vcHRpb25UZXh0Py5pbmNsdWRlcygnJCcpIHx8IG9wdC5vcHRpb25UZXh0Py5pbmNsdWRlcygnPHByZScpIHx8IG9wdC5vcHRpb25UZXh0Py5pbmNsdWRlcygnPGNvZGUnKSkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC02IHAtMiBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCByb3VuZGVkLWxnIHRleHQteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNjAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17b3B0Lm9wdGlvblRleHR9IGZvcm1hdD1cInRleHRcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQcmV2aWV3IGdhbWJhciBvcHNpICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0Lm9wdGlvbkltYWdlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC02IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Fzc2V0VXJsKG9wdC5vcHRpb25JbWFnZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiR2FtYmFyIG9wc2lcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1heC1oLTE2IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGN1cnNvci16b29tLWluXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRMaWdodGJveEltYWdlKHsgc3JjOiBhc3NldFVybChvcHQub3B0aW9uSW1hZ2UpLCBhbHQ6ICdHYW1iYXIgT3BzaScgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZU9wdGlvbihpZHgsIG9JZHgsICdvcHRpb25JbWFnZScsIG51bGwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC00MDAgaG92ZXI6dGV4dC1yZWQtNjAwIHAtMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiSGFwdXMgZ2FtYmFyIG9wc2lcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGFkZE9wdGlvbihpZHgpfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjMDA4OTdCXSBkYXJrOnRleHQtdGVhbC00MDAgaG92ZXI6dW5kZXJsaW5lIG10LTEgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICArIFRhbWJhaCBQaWxpaGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBbnN3ZXIgS2V5IGZvciBFc3NheSAvIERhdGUgLyBUcnVlLUZhbHNlIChPbmx5IGlmIGlzU2NvcmFibGUgIT09IGZhbHNlKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS5pc1Njb3JhYmxlICE9PSBmYWxzZSAmJiBbMSwgNCwgNV0uaW5jbHVkZXMocS50eXBlSWQpICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSmF3YWJhbiBCZW5hciB5YW5nIERpaGFyYXBrYW4gKHVudHVrIHBlbmlsYWlhbiBvdG9tYXRpcyAmIHNrb3IpOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtxLnR5cGVJZCA9PT0gNSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXsoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdiA9IHEuY29ycmVjdEFuc3dlciB8fCAnQmVuYXInO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICh2ID09PSAnVHJ1ZScgfHwgdiA9PT0gJ3RydWUnKSA/ICdCZW5hcicgOiAodiA9PT0gJ0ZhbHNlJyB8fCB2ID09PSAnZmFsc2UnKSA/ICdTYWxhaCcgOiB2O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiB1cGRhdGVRdWVzdGlvbihpZHgsICdjb3JyZWN0QW5zd2VyJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJCZW5hclwiPkJlbmFyPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTYWxhaFwiPlNhbGFoPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogcS50eXBlSWQgPT09IDQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtxLmNvcnJlY3RBbnN3ZXIgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHVwZGF0ZVF1ZXN0aW9uKGlkeCwgJ2NvcnJlY3RBbnN3ZXInLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14cyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXhzIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiY29udG9oOiA0IGF0YXUgU29la2Fybm9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cS5jb3JyZWN0QW5zd2VyfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiB1cGRhdGVRdWVzdGlvbihpZHgsICdjb3JyZWN0QW5zd2VyJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0xLjUgdGV4dC14cyBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3F1ZXN0aW9ucy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTggdGV4dC1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBiZy13aGl0ZS82MCBkYXJrOmJnLXNsYXRlLTkwMC82MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPkJlbHVtIGFkYSBzb2FsPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIG10LTFcIj5Gb3JtIHRhbnBhIHNvYWwgYWthbiB0ZXJzaW1wYW4ga29zb25nICgwIHNvYWwpIGRhbiBvdG9tYXRpcyBrZW1iYWxpIG1lbmphZGkgZHJhZi48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQy0yOiBQYWdpbmF0aW9uIENvbnRyb2xzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsodG90YWxRdWVzdGlvbnMgPiBwYWdlU2l6ZSB8fCBzZWFyY2hUZXJtKSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi0yIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50UGFnZShwID0+IE1hdGgubWF4KDEsIHAgLSAxKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50UGFnZSA9PT0gMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblVwIHNpemU9ezEzfSBjbGFzc05hbWU9XCJyb3RhdGUtOTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TZWJlbHVtbnlhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgdGV4dC14cyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPkhhbGFtYW4ge2N1cnJlbnRQYWdlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj4vPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPntNYXRoLm1heCgxLCBNYXRoLmNlaWwodG90YWxRdWVzdGlvbnMgLyBwYWdlU2l6ZSkpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50UGFnZShwID0+IHAgKyAxKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRQYWdlID49IE1hdGguY2VpbCh0b3RhbFF1ZXN0aW9ucyAvIHBhZ2VTaXplKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CZXJpa3V0bnlhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblVwIHNpemU9ezEzfSBjbGFzc05hbWU9XCItcm90YXRlLTkwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5QZXIgaGFsYW1hbjo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BhZ2VTaXplfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHsgc2V0UGFnZVNpemUoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSk7IHNldEN1cnJlbnRQYWdlKDEpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMC80MCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXsxMH0+MTAgc29hbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXsyNX0+MjUgc29hbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs1MH0+NTAgc29hbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXsxMDB9PjEwMCBzb2FsPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRhbWJhaCBTb2FsIE1hbnVhbCDigJQgQWtzaSBMYWlubnlhIGRpcGluZGFoIGtlIEZBQiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthZGRRdWVzdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdG91cj1cImJ1aWxkZXItYWRkLXF1ZXN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy1bMTgwcHhdIHB5LTMuNSBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtMnhsIHRleHQteHMgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBob3Zlcjpib3JkZXItWyMwMDg5N0JdIGRhcms6aG92ZXI6Ym9yZGVyLXRlYWwtNDAwIGhvdmVyOnRleHQtWyMwMDg5N0JdIGRhcms6aG92ZXI6dGV4dC10ZWFsLTQwMCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBiZy13aGl0ZS82MCBkYXJrOmJnLXNsYXRlLTkwMC82MCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIHNpemU9ezE4fSAvPiBUYW1iYWggU29hbCBNYW51YWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2J1bGtSZXZpc2VNb2RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCByaWdodC01IHRvcC0yNCB6LTQwIHctW21pbig0MzBweCxjYWxjKDEwMHZ3LTJyZW0pKV0gYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIGRhcms6Ym9yZGVyLXB1cnBsZS04MDAgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBwLTQgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMCBkYXJrOnRleHQtcHVycGxlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxXYW5kMiBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4LTFcIj5SZXZpc2kgTWFzc2FsIEFJIMK3IHtidWxrUmV2aXNlU2VsZWN0ZWQuc2l6ZX0gc29hbCBkaXBpbGloPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldEJ1bGtSZXZpc2VTZWxlY3RlZChuZXcgU2V0KHF1ZXN0aW9ucy5tYXAoKF8sIGkpID0+IGkpKSl9IGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTUwMCB1bmRlcmxpbmUgY3Vyc29yLXBvaW50ZXJcIj5QaWxpaCBTZW11YTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtyZXZpc2VNb2RlbH0gb25DaGFuZ2U9e2UgPT4geyBzZXRSZXZpc2VNb2RlbChlLnRhcmdldC52YWx1ZSk7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdmb3JtdXBfc2VsZWN0ZWRfbW9kZWxfY2hhdCcsIGUudGFyZ2V0LnZhbHVlKTsgfX0gY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJvcmRlciBib3JkZXItcHVycGxlLTIwMCBkYXJrOmJvcmRlci1wdXJwbGUtNzAwIHJvdW5kZWQteGwgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtBVkFJTEFCTEVfTU9ERUxTLm1hcChtb2RlbCA9PiA8b3B0aW9uIGtleT17bW9kZWwuaWQgfHwgbW9kZWwubmFtZX0gdmFsdWU9e21vZGVsLmlkIHx8IG1vZGVsLm5hbWV9Pnttb2RlbC5uYW1lIHx8IG1vZGVsLmlkfTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnVsa1JldmlzZUluc3RydWN0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEJ1bGtSZXZpc2VJbnN0cnVjdGlvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJJbnN0cnVrc2kgcmV2aXNpIHVudHVrIHNlbXVhIHNvYWwgdGVycGlsaWguLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDAgZGFyazpib3JkZXItcHVycGxlLTcwMCByb3VuZGVkLXhsIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLXB1cnBsZS01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVCdWxrQWlSZXZpc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2J1bGtSZXZpc2luZyB8fCBidWxrUmV2aXNlU2VsZWN0ZWQuc2l6ZSA9PT0gMCB8fCAhYnVsa1JldmlzZUluc3RydWN0aW9uLnRyaW0oKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwganVzdGlmeS1jZW50ZXIgcHgtNCBweS0yIGJnLXB1cnBsZS02MDAgaG92ZXI6YmctcHVycGxlLTcwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YnVsa1JldmlzaW5nID8gPHNwYW4gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCI+4ouvPC9zcGFuPiA6IDxXYW5kMiBzaXplPXsxM30gLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2J1bGtSZXZpc2luZyA/ICdNZXJldmlzaS4uLicgOiAnUmV2aXNpIFNla2FyYW5nJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUmlnaHQgQ29sdW1uOiBJbnRlcmFjdGl2ZSBMaXZlIFByZXZpZXcgKFNwbGl0IFZpZXcpICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1NwbGl0UHJldmlldyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmZsZXggZmxleC1jb2wgdy1mdWxsIGxnOnctWzQ2JV0gaC1mdWxsIG92ZXJmbG93LXktYXV0byBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC85MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IHNoYWRvdy14bCBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlByYXRpbmphdTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIGZvbnQtYm9sZCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cXVlc3Rpb25zLmxlbmd0aH0gQnV0aXIgU29hbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNTcGxpdFByZXZpZXcoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlR1dHVwIER1YWwgVmlld1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUHJldmlldyBGb3JtIEJhbm5lciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtPy5iYW5uZXJJbWFnZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0zNiByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXthc3NldFVybChmb3JtLmJhbm5lckltYWdlKX0gYWx0PVwiQmFubmVyXCIgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFByZXZpZXcgRm9ybSBIZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybT8udGl0bGUgfHwgJ0p1ZHVsIEZvcm11bGlyJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtPy5kZXNjcmlwdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHByb3NlIGRhcms6cHJvc2UtaW52ZXJ0IG1heC13LW5vbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSaWNoQ29udGVudFJlbmRlcmVyIGNvbnRlbnQ9e2Zvcm0uZGVzY3JpcHRpb259IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFByZXZpZXcgUXVlc3Rpb25zIExpc3QgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cXVlc3Rpb25zLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTggdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmVsdW0gYWRhIGJ1dGlyIHBlcnRhbnlhYW4gcGFkYSBmb3JtdWxpciBpbmkuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9ucy5tYXAoKHEsIHFJZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtxLl9pZCB8fCBxLmlkIHx8IHFJZHh9IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAvODAgYmctc2xhdGUtNTAvNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgc3BhY2UteS0zIHNoYWRvdy0yeHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBmb250LW1vbm9cIj57cUlkeCArIDF9Ljwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hDb250ZW50UmVuZGVyZXIgY29udGVudD17cS5xdWVzdGlvbiB8fCAnUGVydGFueWFhbiBiZWx1bSBkaWlzaSd9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtxLmlzU2NvcmFibGUgIT09IGZhbHNlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLW1kIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EucG9pbnRzIHx8IDF9IFBvaW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBRdWVzdGlvbiBNZWRpYSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS5xdWVzdGlvbkltYWdlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy14cyByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgbXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2Fzc2V0VXJsKHEucXVlc3Rpb25JbWFnZSl9IGFsdD1cIlNvYWxcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1hdXRvIG9iamVjdC1jb250YWluIG1heC1oLTQ4XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBPcHRpb25zIERpc3BsYXkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3EudHlwZUlkID09PSAyICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSBwbC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS5vcHRpb25zPy5tYXAoKG9wdCwgb0lkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBrZXk9e29JZHh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT17YHByZXZpZXdfbGl2ZV9xXyR7cUlkeH1gfSBkaXNhYmxlZCBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e29wdC5vcHRpb25UZXh0IHx8IGBQaWxpaGFuICR7U3RyaW5nLmZyb21DaGFyQ29kZSg2NSArIG9JZHgpfWB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtxLnR5cGVJZCA9PT0gMyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgcGwtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Eub3B0aW9ucz8ubWFwKChvcHQsIG9JZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwga2V5PXtvSWR4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGRpc2FibGVkIGNsYXNzTmFtZT1cInJvdW5kZWQgdGV4dC10ZWFsLTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntvcHQub3B0aW9uVGV4dCB8fCBgUGlsaWhhbiAke1N0cmluZy5mcm9tQ2hhckNvZGUoNjUgKyBvSWR4KX1gfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS50eXBlSWQgPT09IDUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHBsLTQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicmFkaW9cIiBuYW1lPXtgcHJldmlld19saXZlX3FfJHtxSWR4fWB9IGRpc2FibGVkIGNsYXNzTmFtZT1cInRleHQtdGVhbC02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkJlbmFyPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT17YHByZXZpZXdfbGl2ZV9xXyR7cUlkeH1gfSBkaXNhYmxlZCBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TYWxhaDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cS50eXBlSWQgPT09IDEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGRpc2FibGVkIHBsYWNlaG9sZGVyPVwiVHVsaXNrYW4gamF3YWJhbiBkaSBzaW5pLi4uXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGN1cnNvci1ub3QtYWxsb3dlZFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7Lyog4pSA4pSAIFNFVFRJTkdTIFRBQiDilIDilIAgKi99XG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdzZXR0aW5ncycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC02IHNwYWNlLXktNiBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBLb25maWd1cmFzaSAmIEF0dXJhbiBGb3JtdWxpclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPlNsdWcgVGF1dGFuIEtodXN1czwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcHgtMyBweS0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtGUk9OVEVORF9CQVNFX1VSTH0vZi9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZXR0aW5ncy5jdXN0b21Gb3JtTGlua31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCBjdXN0b21Gb3JtTGluazogZS50YXJnZXQudmFsdWUudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bXmEtejAtOS1dL2csICcnKSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwidGF1dGFuLWtodXN1cy1zYXlhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1tb25vIGZvbnQtYm9sZCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgbXQtMVwiPkhhbnlhIGh1cnVmIGtlY2lsLCBhbmdrYSwgZGFuIHRhbmRhIGh1YnVuZyAoLSkuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPlRpcGUgVGF0YSBMZXRhayBGb3JtdWxpcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2V0dGluZ3MuZm9ybVR5cGVJZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCBmb3JtVHlwZUlkOiBwYXJzZUludChlLnRhcmdldC52YWx1ZSkgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LWJvbGQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezF9PlNlbXVhIFNvYWwgZGFsYW0gU2F0dSBIYWxhbWFuPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezJ9PlNhdHUgU29hbCBwZXIgSGFsYW1hbiAoTGFuZ2thaCk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQS01OiBDbGFyaWZ5IGluZGVwZW5kZW5jZSBmcm9tIGV4YW0gbW9kZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIG10LTFcIj5QaWxpaGFuIHRhbXBpbGFuIOKAlCBiZWJhcyBkaWtvbWJpbmFzaWthbiBkZW5nYW4gTW9kZSBVamlhbi48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBibG9jayBtYi0xXCI+RHVyYXNpIFRpbWVyIChNZW5pdCwgT3BzaW9uYWwpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2V0dGluZ3MudGltZXJEdXJhdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCB0aW1lckR1cmF0aW9uOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiY29udG9oOiAzMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJsb2NrIG1iLTFcIj5XYWt0dSBCdWthIEZvcm11bGlyIChPcHNpb25hbCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZXRpbWUtbG9jYWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2V0dGluZ3Mub3BlbkZvcm1UaW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRTZXR0aW5ncyhzID0+ICh7IC4uLnMsIG9wZW5Gb3JtVGltZTogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LWJvbGQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDg5N0JdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPldha3R1IFR1dHVwIEZvcm11bGlyIChPcHNpb25hbCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZXRpbWUtbG9jYWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2V0dGluZ3MuY2xvc2VGb3JtVGltZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCBjbG9zZUZvcm1UaW1lOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJsb2NrIG1iLTFcIj5Ub2tlbiBLYXRhIFNhbmRpIEZvcm11bGlyIChPcHNpb25hbCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZXR0aW5ncy5mb3JtVG9rZW59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCBmb3JtVG9rZW46IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImNvbnRvaDogUkFIQVNJQTEyM1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1tb25vIGZvbnQtYm9sZCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwODk3Ql1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3Nob3dTY29yZScsIGxhYmVsOiAnVGFtcGlsa2FuIFNrb3IgJiBLdW5jaSBKYXdhYmFuIHNldGVsYWggUGVuZ2lzaWFuJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAncmFuZG9taXplUXVlc3Rpb25zJywgbGFiZWw6ICdBY2FrIFVydXRhbiBTb2FsIHVudHVrIFNldGlhcCBSZXNwb25kZW4nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdvbmVSZXNwb25zZScsIGxhYmVsOiAnQmF0YXNpIDEgS2FsaSBQZW5naXNpYW4gcGVyIFJlc3BvbmRlbi9TZXNpJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAncmVxdWlyZWRMb2dpbicsIGxhYmVsOiAnV2FqaWIgTG9naW4gQWt1biBGb3JtVXAgc2ViZWx1bSBNZW5naXNpJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXS5tYXAoKHsga2V5LCBsYWJlbCB9KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGtleT17a2V5fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZXR0aW5nc1trZXldfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCBba2V5XTogZS50YXJnZXQuY2hlY2tlZCB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyMwMDg5N0JdIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+e2xhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCLTE6IEV4YW0gTW9kZSBTZXR0aW5ncyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IHNpemU9ezE1fSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Nb2RlIFVqaWFuPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBweC0xLjUgcHktMC41IGJnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNjAgdGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwIHJvdW5kZWQgZm9udC1ib2xkXCI+RXhwZXJpbWVudGFsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17c2V0dGluZ3MuaXNFeGFtTW9kZX0gb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCBpc0V4YW1Nb2RlOiBlLnRhcmdldC5jaGVja2VkIH0pKX0gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJlZC01MDAgcm91bmRlZCBjdXJzb3ItcG9pbnRlclwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPkFrdGlma2FuIE1vZGUgVWppYW48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NldHRpbmdzLmlzRXhhbU1vZGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtNyBzcGFjZS15LTIuNSBwLTMgYmctcmVkLTUwLzYwIGRhcms6YmctcmVkLTk1MC8yMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItcmVkLTEwMCBkYXJrOmJvcmRlci1yZWQtOTAwLzQwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e3NldHRpbmdzLmRpc2FibGVDb3B5UGFzdGV9IG9uQ2hhbmdlPXtlID0+IHNldFNldHRpbmdzKHMgPT4gKHsgLi4ucywgZGlzYWJsZUNvcHlQYXN0ZTogZS50YXJnZXQuY2hlY2tlZCB9KSl9IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNTAwIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+Tm9uYWt0aWZrYW4gQ29weS1QYXN0ZSAmIEtsaWsgS2FuYW48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e3NldHRpbmdzLmRldGVjdFRhYlN3aXRjaH0gb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCBkZXRlY3RUYWJTd2l0Y2g6IGUudGFyZ2V0LmNoZWNrZWQgfSkpfSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcmVkLTUwMCByb3VuZGVkIGN1cnNvci1wb2ludGVyXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPkRldGVrc2kgUGluZGFoIFRhYiAvIE1pbmltaXplPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2V0dGluZ3MuZGV0ZWN0VGFiU3dpdGNoICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1sLTdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e3NldHRpbmdzLmF1dG9TdWJtaXRPblRhYlN3aXRjaH0gb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCBhdXRvU3VibWl0T25UYWJTd2l0Y2g6IGUudGFyZ2V0LmNoZWNrZWQgfSkpfSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcmVkLTUwMCByb3VuZGVkIGN1cnNvci1wb2ludGVyXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+QXV0by1TdWJtaXQgU2FhdCBNZWxld2F0aSBCYXRhcyBQZWxhbmdnYXJhbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPk1ha3MuIFBlbGFuZ2dhcmFuOjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMVwiIG1heD1cIjIwXCIgdmFsdWU9e3NldHRpbmdzLm1heFRhYlN3aXRjaH0gb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCBtYXhUYWJTd2l0Y2g6IHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSB8fCAzIH0pKX0gY2xhc3NOYW1lPVwidy0xNiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBweC0yIHB5LTEgdGV4dC14cyBmb250LWJvbGQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctcmVkLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5rYWxpIHNlYmVsdW0gb3RvbWF0aXMgZGlrdW1wdWxrYW48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCLTI6IEN1c3RvbSBUaGVtZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFBhbGV0dGUgc2l6ZT17MTV9IGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlRlbWEgRm9ybSAoV2FybmEgS3VzdG9tKTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDBcIj5XYXJuYSBpbmkgZGl0ZXJhcGthbiBwYWRhIHRhbXBpbGFuIGZvcm0gc2FhdCBkaWlzaSBvbGVoIHJlc3BvbmRlbi48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBibG9jayBtYi0xXCI+V2FybmEgVXRhbWEgKFRvbWJvbCwgQWtzZW4pPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjb2xvclwiIHZhbHVlPXtzZXR0aW5ncy50aGVtZVByaW1hcnlDb2xvciB8fCAnIzAwODk3Qid9IG9uQ2hhbmdlPXtlID0+IHNldFNldHRpbmdzKHMgPT4gKHsgLi4ucywgdGhlbWVQcmltYXJ5Q29sb3I6IGUudGFyZ2V0LnZhbHVlIH0pKX0gY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGN1cnNvci1wb2ludGVyIHAtMC41IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtzZXR0aW5ncy50aGVtZVByaW1hcnlDb2xvcn0gb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCB0aGVtZVByaW1hcnlDb2xvcjogZS50YXJnZXQudmFsdWUgfSkpfSBwbGFjZWhvbGRlcj1cIiMwMDg5N0JcIiBtYXhMZW5ndGg9ezd9IGNsYXNzTmFtZT1cImZsZXgtMSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyBmb250LW1vbm8gZm9udC1ib2xkIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2V0dGluZ3MudGhlbWVQcmltYXJ5Q29sb3IgJiYgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCB0aGVtZVByaW1hcnlDb2xvcjogJycgfSkpfSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXJlZC01MDAgY3Vyc29yLXBvaW50ZXJcIj48WCBzaXplPXsxNH0gLz48L2J1dHRvbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJsb2NrIG1iLTFcIj5XYXJuYSBMYXRhciBCZWxha2FuZyBGb3JtPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjb2xvclwiIHZhbHVlPXtzZXR0aW5ncy50aGVtZUJhY2tncm91bmRDb2xvciB8fCAnI0Y0RjhGNyd9IG9uQ2hhbmdlPXtlID0+IHNldFNldHRpbmdzKHMgPT4gKHsgLi4ucywgdGhlbWVCYWNrZ3JvdW5kQ29sb3I6IGUudGFyZ2V0LnZhbHVlIH0pKX0gY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGN1cnNvci1wb2ludGVyIHAtMC41IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtzZXR0aW5ncy50aGVtZUJhY2tncm91bmRDb2xvcn0gb25DaGFuZ2U9e2UgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCB0aGVtZUJhY2tncm91bmRDb2xvcjogZS50YXJnZXQudmFsdWUgfSkpfSBwbGFjZWhvbGRlcj1cIiNGNEY4RjdcIiBtYXhMZW5ndGg9ezd9IGNsYXNzTmFtZT1cImZsZXgtMSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyBmb250LW1vbm8gZm9udC1ib2xkIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA4OTdCXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2V0dGluZ3MudGhlbWVCYWNrZ3JvdW5kQ29sb3IgJiYgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2V0dGluZ3MocyA9PiAoeyAuLi5zLCB0aGVtZUJhY2tncm91bmRDb2xvcjogJycgfSkpfSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXJlZC01MDAgY3Vyc29yLXBvaW50ZXJcIj48WCBzaXplPXsxNH0gLz48L2J1dHRvbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZVNldHRpbmdzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgYmctWyMwMDg5N0JdIGhvdmVyOmJnLVsjMDA3OTZCXSB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTYXZlIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntzYXZpbmcgPyAnTWVueWltcGFuLi4uJyA6ICdTaW1wYW4gUGVuZ2F0dXJhbid9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIOKUgOKUgCBTSEFSRSBUQUIg4pSA4pSAICovfVxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnc2hhcmUnICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtNiBzcGFjZS15LTYgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmFnaWthbiBUYXV0YW4gJiBLb2RlIFFSIEZvcm11bGlyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+VGF1dGFuIFB1YmxpayBGb3JtdWxpcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake0ZST05URU5EX0JBU0VfVVJMfS9mLyR7Zm9ybT8uZm9ybUxpbmt9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yLjUgdGV4dC14cyBmb250LW1vbm8gZm9udC1ib2xkIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChgJHtGUk9OVEVORF9CQVNFX1VSTH0vZi8ke2Zvcm0/LmZvcm1MaW5rfWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29waWVkTGluayh0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkTGluayhmYWxzZSksIDIwMDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBiZy1bIzAwODk3Ql0gaG92ZXI6YmctWyMwMDc5NkJdIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcm91bmRlZC14bCBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvcGllZExpbmsgPyAn4pyTIFRlcnNhbGluIScgOiAnU2FsaW4gVGF1dGFuJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cXJCbG9iVXJsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGJsb2NrXCI+S29kZSBRUiBHYW1iYXIgUE5HPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17cXJCbG9iVXJsfSBhbHQ9XCJLb2RlIFFSXCIgY2xhc3NOYW1lPVwidy00NCBoLTQ0IGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBwLTIgYmctd2hpdGUgc2hhZG93LXhzXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXtxckJsb2JVcmx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRvd25sb2FkPXtgcXItJHtmb3JtPy5mb3JtTGlua30ucG5nYH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgZGFyazpiZy1zbGF0ZS03MDAgZGFyazpob3ZlcjpiZy1zbGF0ZS02MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxM30gLz4gVW5kdWggS29kZSBRUiBQTkdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEEtNzogQnVsayBSZXZpc2UgUHJldmlldyBNb2RhbCAqL31cbiAgICAgICAgICAgIHtidWxrUmV2aXNlUHJldmlld09wZW4gJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci14c1wiIG9uQ2xpY2s9eygpID0+IHNldEJ1bGtSZXZpc2VQcmV2aWV3T3BlbihmYWxzZSl9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdy1mdWxsIG1heC13LTJ4bCBtYXgtaC1bODV2aF0gcm91bmRlZC0zeGwgc2hhZG93LTJ4bCBmbGV4IGZsZXgtY29sIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgei0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+PFdhbmQyIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDBcIiAvPiBQcmV2aWV3IEhhc2lsIFJldmlzaSBBSSAoe2J1bGtSZXZpc2VQcmV2aWV3Lmxlbmd0aH0gc29hbCk8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldEJ1bGtSZXZpc2VQcmV2aWV3T3BlbihmYWxzZSl9IGNsYXNzTmFtZT1cInAtMSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBjdXJzb3ItcG9pbnRlclwiPjxYIHNpemU9ezE4fSAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC01IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtidWxrUmV2aXNlUHJldmlldy5tYXAoKHsgaWR4LCBvcmlnaW5hbCwgcmV2aXNlZCB9KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5Tb2FsICN7aWR4ICsgMX0g4oCUIE9yaWdpbmFsPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyB0ZXh0LXhzIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj57KG9yaWdpbmFsLnF1ZXN0aW9uIHx8ICcnKS5yZXBsYWNlKC88W14+XSo+L2csJycpfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctcHVycGxlLTUwIGRhcms6YmctcHVycGxlLTk1MC8zMCB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+SGFzaWwgUmV2aXNpIEFJPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj57KHJldmlzZWQucXVlc3Rpb24gfHwgJycpLnJlcGxhY2UoLzxbXj5dKj4vZywnJyl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBhcHBseUJ1bGtSZXZpc2VJdGVtKGlkeCwgcmV2aXNlZCk7IHNldEJ1bGtSZXZpc2VQcmV2aWV3KHByZXYgPT4gcHJldi5maWx0ZXIocCA9PiBwLmlkeCAhPT0gaWR4KSk7IGlmIChidWxrUmV2aXNlUHJldmlldy5sZW5ndGggPD0gMSkgeyBzZXRCdWxrUmV2aXNlUHJldmlld09wZW4oZmFsc2UpOyBzZXRCdWxrUmV2aXNlTW9kZShmYWxzZSk7IHNob3dUb2FzdCgnUmV2aXNpIGJlcmhhc2lsIGRpdGVyYXBrYW4hJyk7IH0gfX0gY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtNzAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBjdXJzb3ItcG9pbnRlclwiPlRlcmFwa2FuPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0QnVsa1JldmlzZVByZXZpZXcocHJldiA9PiBwcmV2LmZpbHRlcihwID0+IHAuaWR4ICE9PSBpZHgpKX0gY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMFwiPkxld2F0aTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgYnVsa1JldmlzZVByZXZpZXcuZm9yRWFjaCgoeyBpZHgsIHJldmlzZWQgfSkgPT4gYXBwbHlCdWxrUmV2aXNlSXRlbShpZHgsIHJldmlzZWQpKTsgc2V0QnVsa1JldmlzZVByZXZpZXdPcGVuKGZhbHNlKTsgc2V0QnVsa1JldmlzZU1vZGUoZmFsc2UpOyBzaG93VG9hc3QoYCR7YnVsa1JldmlzZVByZXZpZXcubGVuZ3RofSBzb2FsIGJlcmhhc2lsIGRpcmV2aXNpIWApOyB9fSBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtNzAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBjdXJzb3ItcG9pbnRlclwiPlRlcmFwa2FuIFNlbXVhPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0QnVsa1JldmlzZVByZXZpZXdPcGVuKGZhbHNlKX0gY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDBcIj5UdXR1cDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIEJVRy00IEZJWDogSW4tYXBwIHVuc2F2ZWQtY2hhbmdlcyBuYXZpZ2F0aW9uIGd1YXJkIGRpYWxvZy5cbiAgICAgICAgICAgICAgICBTaG93cyB3aGVuIHRoZSB1c2VyIHRyaWVzIHRvIG5hdmlnYXRlIGF3YXkgdmlhIGEgY2xpZW50LXNpZGUgcm91dGVcbiAgICAgICAgICAgICAgICBjaGFuZ2UgKHNpZGViYXIsIGJhY2sgYnV0dG9uLCBldGMuKSB3aGlsZSBpc0RpcnR5IGlzIHRydWUuICovfVxuICAgICAgICAgICAgey8qIHtuYXZCbG9ja2VyLnN0YXRlID09PSAnYmxvY2tlZCcgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVsyMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzUwIGJhY2tkcm9wLWJsdXIteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2QmxvY2tlci5yZXNldCgpfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgbWF4LXctc20gdy1mdWxsIHNoYWRvdy0yeGwgc3BhY2UteS00IHotMTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNjAgdGV4dC1hbWJlci01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNhdmUgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGEgcGVydWJhaGFuIHlhbmcgYmVsdW0gZGlzaW1wYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlcnViYWhhbiBwYWRhIGZvcm11bGlyIGluaSBiZWx1bSBkaXNpbXBhbi4gVGluZ2dhbGthbiBoYWxhbWFuIHNla2FyYW5nIGFrYW4gbWVtYnVhbmcgc2VtdWEgcGVydWJhaGFuIHRlcnNlYnV0LlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdkJsb2NrZXIucmVzZXQoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTQgcHktMi41IGJnLXNsYXRlLTEwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhdGFsIChUZXRhcCBkaSBTaW5pKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG9rID0gYXdhaXQgaGFuZGxlU2F2ZUFsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9rKSBuYXZCbG9ja2VyLnByb2NlZWQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTQgcHktMi41IGJnLVsjMDA4OTdCXSBob3ZlcjpiZy1bIzAwNzk2Ql0gdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNpbXBhbiAmYW1wOyBLZWx1YXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZCbG9ja2VyLnByb2NlZWQoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTQgcHktMi41IGJnLXJlZC01MDAgaG92ZXI6YmctcmVkLTYwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQnVhbmcgUGVydWJhaGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfSAqL31cblxuICAgICAgICAgICAgey8qIEJVRy0zOiBDb25maXJtTW9kYWwgKHJlcGxhY2VzIHdpbmRvdy5jb25maXJtKSAqL31cbiAgICAgICAgICAgIDxDb25maXJtTW9kYWxcbiAgICAgICAgICAgIGlzT3Blbj17Y29uZmlybU1vZGFsLmlzT3Blbn1cbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldENvbmZpcm1Nb2RhbChwcmV2ID0+ICh7IC4uLnByZXYsIGlzT3BlbjogZmFsc2UgfSkpfVxuICAgICAgICAgICAgb25Db25maXJtPXtjb25maXJtTW9kYWwub25Db25maXJtfVxuICAgICAgICAgICAgdGl0bGU9e2NvbmZpcm1Nb2RhbC50aXRsZX1cbiAgICAgICAgICAgIG1lc3NhZ2U9e2NvbmZpcm1Nb2RhbC5tZXNzYWdlfVxuICAgICAgICAgICAgdmFyaWFudD17Y29uZmlybU1vZGFsLnZhcmlhbnQgfHwgJ2Rhbmdlcid9XG4gICAgICAgICAgICBjb25maXJtVGV4dD17Y29uZmlybU1vZGFsLmNvbmZpcm1UZXh0IHx8ICdZYSwgSGFwdXMnfVxuICAgICAgICAvPlxuXG4gICAgICAgICAgICB7LyogTW9kYWwgUnVtdXMgJiBLb2RlICovfVxuICAgICAgICAgICAgPE1hdGhBbmRDb2RlTW9kYWxcbiAgICAgICAgICAgICAgICBpc09wZW49e21vZGFsT3Blbn1cbiAgICAgICAgICAgICAgICBtb2RlPXttb2RhbE1vZGV9XG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBvbkluc2VydD17aGFuZGxlSW5zZXJ0RnJvbU1vZGFsfVxuICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgey8qIEFJIFF1ZXN0aW9uIEdlbmVyYXRvciBNb2RhbCAqL31cbiAgICAgICAgICAgIDxBSUdlbmVyYXRvck1vZGFsXG4gICAgICAgICAgICAgICAgaXNPcGVuPXthaU1vZGFsT3Blbn1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBaU1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgb25BZGRRdWVzdGlvbnM9e2hhbmRsZUFkZEFJUXVlc3Rpb25zfVxuICAgICAgICAgICAgICAgIGZvcm1UaXRsZT17Zm9ybT8udGl0bGUgfHwgJyd9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICB7LyogQUkgRm9ybSBCdWlsZGVyIE1vZGFsICovfVxuICAgICAgICAgICAgPEFJRm9ybUJ1aWxkZXJNb2RhbFxuICAgICAgICAgICAgICAgIGlzT3Blbj17YWlGb3JtQnVpbGRlck9wZW59XG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWlGb3JtQnVpbGRlck9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgIG9uRm9ybUNyZWF0ZWQ9eyhuZXdJZCkgPT4gbmF2aWdhdGUoYC9mb3Jtcy8ke25ld0lkfS9idWlsZGVyYCl9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICB7LyogQS0yOiBJbXBvcnQgUXVlc3Rpb25zIE1vZGFsIChQcmV2aWV3ICsgQ29tbWl0IDUgRm9ybWF0KSAqL31cbiAgICAgICAgICAgIDxJbXBvcnRRdWVzdGlvbnNNb2RhbFxuICAgICAgICAgICAgICAgIGlzT3Blbj17aW1wb3J0TW9kYWxPcGVufVxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEltcG9ydE1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgZm9ybUlkPXtpZH1cbiAgICAgICAgICAgICAgICBoYXNSZXNwb25zZXM9eyhmb3JtPy5yZXNwb25zZUNvdW50ID8/IGZvcm0/LnRvdGFsUmVzcG9uc2VzID8/IDApID4gMCA/IChmb3JtPy5yZXNwb25zZUNvdW50ID8/IGZvcm0/LnRvdGFsUmVzcG9uc2VzID8/IDApIDogbnVsbH1cbiAgICAgICAgICAgICAgICBvbkltcG9ydGVkPXtoYW5kbGVPbkltcG9ydGVkfVxuICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgey8qIExpZ2h0Ym94IE1vZGFsICovfVxuICAgICAgICAgICAgPEltYWdlTGlnaHRib3hNb2RhbFxuICAgICAgICAgICAgICAgIGlzT3Blbj17ISFsaWdodGJveEltYWdlfVxuICAgICAgICAgICAgICAgIHNyYz17bGlnaHRib3hJbWFnZT8uc3JjfVxuICAgICAgICAgICAgICAgIGFsdD17bGlnaHRib3hJbWFnZT8uYWx0fVxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldExpZ2h0Ym94SW1hZ2UobnVsbCl9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICB7LyogUXVpY2sgQWN0aW9uIFNjcm9sbCBNZW51ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BmaXhlZCBib3R0b20tNiByaWdodC02IHotNDAgZmxleCBmbGV4LWNvbCBpdGVtcy1lbmQgZ2FwLTIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2Utb3V0IHRyYW5zZm9ybSAke1xuICAgICAgICAgICAgICAgIHNjcm9sbGVkUGFzdEhlYWRlciBcbiAgICAgICAgICAgICAgICAgICAgPyAnb3BhY2l0eS0xMDAgdHJhbnNsYXRlLXktMCBzY2FsZS0xMDAgcG9pbnRlci1ldmVudHMtYXV0bycgXG4gICAgICAgICAgICAgICAgICAgIDogJ29wYWNpdHktMCB0cmFuc2xhdGUteS02IHNjYWxlLTkwIHBvaW50ZXItZXZlbnRzLW5vbmUnXG4gICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgIHtmYWJNZW51T3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtMi41IGZsZXggZmxleC1jb2wgZ2FwLTEuNSB3LTU2IGFuaW1hdGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0xNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU2F2ZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGYWJNZW51T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVTYXZlQWxsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHgtMyBweS0yIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRGlydHlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1vcmFuZ2UtNTAwIGhvdmVyOmJnLW9yYW5nZS02MDAgdGV4dC13aGl0ZSBhbmltYXRlLXB1bHNlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2F2ZSBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3NhdmluZyA/ICdNZW55aW1wYW4uLi4nIDogaXNEaXJ0eSA/ICfimqAgU2ltcGFuIFNla2FyYW5nJyA6ICdTaW1wYW4gUGVydWJhaGFuJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUHJldmlldyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGYWJNZW51T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cub3BlbihgL2YvJHtmb3JtPy5mb3JtTGlua30/cHJldmlldz10cnVlJmZvcm1JZD0ke2Zvcm0/LmlkfWAsICdfYmxhbmsnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlByZXZpZXcgUmVzcG9uZGVuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFB1Ymxpc2ggLyBEcmFmdCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGYWJNZW51T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVUb2dnbGVQdWJsaXNoKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwdWJsaXNoaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1B1Ymxpc2hlZCA/IDxMb2NrIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTUwMFwiIC8+IDogPEdsb2JlIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57cHVibGlzaGluZyA/ICdNZW1wcm9zZXMuLi4nIDogaXNQdWJsaXNoZWQgPyAnSmFkaWthbiBEcmFmJyA6ICdQdWJsaWthc2lrYW4nfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBdXRvLVNhdmUgVG9nZ2xlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEF1dG9zYXZlRW5hYmxlZChwcmV2ID0+ICFwcmV2KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2F1dG9zYXZlRW5hYmxlZCA/IDxUb2dnbGVSaWdodCBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIiAvPiA6IDxUb2dnbGVMZWZ0IHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QXV0by1TYXZlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gcHgtMS41IHB5LTAuNSByb3VuZGVkIGZvbnQtZXh0cmFib2xkICR7YXV0b3NhdmVFbmFibGVkID8gJ2JnLXRlYWwtNTAgdGV4dC10ZWFsLTcwMCBkYXJrOmJnLXRlYWwtOTUwIGRhcms6dGV4dC10ZWFsLTMwMCcgOiAnYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNTAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS00MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2F1dG9zYXZlRW5hYmxlZCA/ICdPTicgOiAnT0ZGJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG5cbnthY3RpdmVUYWIgPT09ICdxdWVzdGlvbnMnICYmIChcbiAgICA8PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtcHggYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIG15LTAuNVwiIC8+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldEZhYk1lbnVPcGVuKGZhbHNlKTsgc2V0QWlNb2RhbE9wZW4odHJ1ZSk7IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6YmctdGVhbC01MCBkYXJrOmhvdmVyOmJnLXRlYWwtOTUwLzQwIGhvdmVyOnRleHQtdGVhbC03MDAgZGFyazpob3Zlcjp0ZXh0LXRlYWwtMzAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgPlxuICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5CdWF0IGRlbmdhbiBBSTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBkYXRhLXRvdXI9XCJidWlsZGVyLWFpLXJldmlzZVwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldEZhYk1lbnVPcGVuKGZhbHNlKTsgc2V0QnVsa1JldmlzZU1vZGUocHJldiA9PiAhcHJldik7IHNldEJ1bGtSZXZpc2VTZWxlY3RlZChuZXcgU2V0KCkpOyB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXB1cnBsZS01MCBkYXJrOmhvdmVyOmJnLXB1cnBsZS05NTAvNDAgaG92ZXI6dGV4dC1wdXJwbGUtNzAwIGRhcms6aG92ZXI6dGV4dC1wdXJwbGUtMzAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgPlxuICAgICAgICAgICAgPFdhbmQyIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDAgZGFyazp0ZXh0LXB1cnBsZS00MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+e2J1bGtSZXZpc2VNb2RlID8gJ1NlbGVzYWkgUGlsaWggKFJldmlzaSknIDogJ1JldmlzaSBNYXNzYWwgQUknfTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldEZhYk1lbnVPcGVuKGZhbHNlKTsgaGFuZGxlVW5kbygpOyB9fVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2hpc3RvcnlJbmRleCA8PSAwfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgID5cbiAgICAgICAgICAgIDxVbmRvMiBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+VW5kbzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLWF1dG8gdGV4dC1bMTBweF0gZm9udC1ub3JtYWwgdGV4dC1zbGF0ZS00MDBcIj5DdHJsK1o8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRGYWJNZW51T3BlbihmYWxzZSk7IGhhbmRsZVJlZG8oKTsgfX1cbiAgICAgICAgICAgIGRpc2FibGVkPXtoaXN0b3J5SW5kZXggPj0gaGlzdG9yeS5sZW5ndGggLSAxfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgID5cbiAgICAgICAgICAgIDxSZWRvMiBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+UmVkbzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLWF1dG8gdGV4dC1bMTBweF0gZm9udC1ub3JtYWwgdGV4dC1zbGF0ZS00MDBcIj5DdHJsK1k8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRGYWJNZW51T3BlbihmYWxzZSk7IGhhbmRsZUV4cG9ydFF1ZXN0aW9ucygpOyB9fVxuICAgICAgICAgICAgZGlzYWJsZWQ9e3F1ZXN0aW9ucy5sZW5ndGggPT09IDB9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6YmctYmx1ZS01MCBkYXJrOmhvdmVyOmJnLWJsdWUtOTUwLzQwIGhvdmVyOnRleHQtYmx1ZS03MDAgZGFyazpob3Zlcjp0ZXh0LWJsdWUtMzAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgPlxuICAgICAgICAgICAgPEZpbGVEb3duIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5FeHBvcnQgU29hbCAoQ1NWKTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldEZhYk1lbnVPcGVuKGZhbHNlKTsgaGFuZGxlQ2xlYXJBbGxRdWVzdGlvbnMoKTsgfX1cbiAgICAgICAgICAgIGRpc2FibGVkPXtxdWVzdGlvbnMubGVuZ3RoID09PSAwfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAgaG92ZXI6YmctcmVkLTUwIGRhcms6aG92ZXI6YmctcmVkLTk1MC80MCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgID5cbiAgICAgICAgICAgIDxUcmFzaDIgc2l6ZT17MTR9IGNsYXNzTmFtZT1cInNocmluay0wXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPkhhcHVzIFNlbXVhIFNvYWw8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgIDwvPlxuKX1cblxuPGRpdiBjbGFzc05hbWU9XCJoLXB4IGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBteS0wLjVcIiAvPlxuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtcHggYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIG15LTAuNVwiIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU2Nyb2xsIHRvIFRvcCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGYWJNZW51T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobWFpblNjcm9sbFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFpblNjcm9sbFJlZi5jdXJyZW50LnNjcm9sbFRvKHsgdG9wOiAwLCBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oeyB0b3A6IDAsIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25VcCBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2Nyb2xsIGtlIEF0YXM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7LyogRkFCIE1haW4gQnV0dG9uICovfVxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZhYk1lbnVPcGVuKHByZXYgPT4gIXByZXYpfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJNZW51IFRpbmRha2FuIENlcGF0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIHctMTIgaC0xMiByb3VuZGVkLWZ1bGwgc2hhZG93LXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tYWxsIHRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNEaXJ0eVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1vcmFuZ2UtNTAwIHRleHQtd2hpdGUgc2hhZG93LW9yYW5nZS01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHRleHQtd2hpdGUgc2hhZG93LXRlYWwtNjAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0RpcnR5ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTEgLXJpZ2h0LTEgdy0zLjUgaC0zLjUgcm91bmRlZC1mdWxsIGJnLXJlZC01MDAgYm9yZGVyLTIgYm9yZGVyLXdoaXRlIGRhcms6Ym9yZGVyLXNsYXRlLTkwMCBhbmltYXRlLXBpbmdcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0RpcnR5ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTEgLXJpZ2h0LTEgdy0zLjUgaC0zLjUgcm91bmRlZC1mdWxsIGJnLXJlZC01MDAgYm9yZGVyLTIgYm9yZGVyLXdoaXRlIGRhcms6Ym9yZGVyLXNsYXRlLTkwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAge2ZhYk1lbnVPcGVuID8gPFggc2l6ZT17MjB9IC8+IDogPE1vcmVWZXJ0aWNhbCBzaXplPXsyMH0gLz59XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogR3VpZGVkIE9uYm9hcmRpbmcgVG91cjogRm9ybSBCdWlsZGVyIFRvdXIgKi99XG4gICAgICAgICAgICA8T25ib2FyZGluZ1RvdXJcbiAgICAgICAgICAgICAgICBpc09wZW49e2J1aWxkZXJUb3VyT3Blbn1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEJ1aWxkZXJUb3VyT3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYigncXVlc3Rpb25zJyk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBvbkNvbXBsZXRlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEJ1aWxkZXJUb3VyT3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYigncXVlc3Rpb25zJyk7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZm9ybXVwX2J1aWxkZXJfdG91cl9jb21wbGV0ZWQnLCAndHJ1ZScpO1xuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7fVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgc3RlcHM9e1tcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0b3I6ICdbZGF0YS10b3VyPVwiYnVpbGRlci10YWJzXCJdJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnTmF2aWdhc2kgVGFiIEZvcm0gQnVpbGRlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ0tlbG9sYSBmb3JtdWxpciBtZWxhbHVpIDMgdGFiIHV0YW1hOiBcIlBlcnRhbnlhYW5cIiB1bnR1ayBtZW55dXN1biBzb2FsLCBcIlBlbmdhdHVyYW5cIiB1bnR1ayBiYXRhcyB3YWt0dSBkYW4gYXR1cmFuIG1vZGUgdWppYW4sIHNlcnRhIFwiQmFnaWthblwiIHVudHVrIGxpbmsgZGFuIFFSIENvZGUuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxTbGlkZXJzIHNpemU9ezE4fSAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudDogJ2JvdHRvbScsXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWRnZTogJ05hdmlnYXNpIFV0YW1hJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbjogKCkgPT4gc2V0QWN0aXZlVGFiKCdxdWVzdGlvbnMnKVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RvcjogJ1tkYXRhLXRvdXI9XCJidWlsZGVyLWFpLWdlbmVyYXRvclwiXScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0J1YXQgU29hbCBPdG9tYXRpcyBkZW5nYW4gQUknLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICdIZW1hdCB3YWt0dSBBbmRhISBLZXRpayBtYXRlcmkgdWppYW4sIHRvcGlrIHBlbWJlbGFqYXJhbiwgYXRhdSBzaWxhYnVzIOKAlCBBSSBHZW1pbmkgRm9ybVVwIGFrYW4gbGFuZ3N1bmcgbWVyYW5jYW5nIHNvYWwsIHBpbGloYW4gZ2FuZGEsIGRhbiBrdW5jaSBqYXdhYmFuIHNlY2FyYSBpbnN0YW4uJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxTcGFya2xlcyBzaXplPXsxOH0gLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ6ICdib3R0b20nLFxuICAgICAgICAgICAgICAgICAgICAgICAgYmFkZ2U6ICdLZWNlcmRhc2FuIEFJJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbjogKCkgPT4gc2V0QWN0aXZlVGFiKCdxdWVzdGlvbnMnKVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RvcjogJ1tkYXRhLXRvdXI9XCJidWlsZGVyLWFkZC1xdWVzdGlvblwiXScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ1RhbWJhaCAmIERlc2FpbiBTb2FsIEZsZWtzaWJlbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1RhbWJhaGthbiBzb2FsIHNlY2FyYSBtYW51YWwuIEFuZGEgZGFwYXQgbWVtaWxpaCB0aXBlIFBpbGloYW4gR2FuZGEsIEVzYWksIEtvdGFrIENlbnRhbmcsIEJlbmFyL1NhbGFoLCBtZW55aXNpcGthbiBnYW1iYXIgJiBhdWRpbyBzb2FsLCBoaW5nZ2EgcnVtdXMgbWF0ZW1hdGlrYSBLYVRlWC4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPFBsdXMgc2l6ZT17MTh9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50OiAndG9wJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlOiAnRWRpdG9yIFNvYWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uOiAoKSA9PiBzZXRBY3RpdmVUYWIoJ3F1ZXN0aW9ucycpXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdG9yOiAnW2RhdGEtdG91cj1cImJ1aWxkZXItcXVlc3Rpb24tcmV2aXNlXCJdJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnUmV2aXNpIFNvYWwgZGVuZ2FuIEFJJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnR3VuYWthbiBpa29uIFdhbmQgdW50dWsgbWVyZXZpc2kgc2F0dSBzb2FsIGF0YXUgYWt0aWZrYW4gUmV2aXNpIE1hc3NhbCBBSS4gTW9kZWwgZGFuIGluc3RydWtzaSByZXZpc2kgc2VrYXJhbmcgdGVyc2VkaWEgbGFuZ3N1bmcgZGkgcGFuZWwgZmxvYXRpbmcga2FuYW4uJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxXYW5kMiBzaXplPXsxOH0gLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ6ICdsZWZ0JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlOiAnUmV2aXNpIEFJJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbjogKCkgPT4gc2V0QWN0aXZlVGFiKCdxdWVzdGlvbnMnKVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RvcjogJ1tkYXRhLXRvdXI9XCJ0YWItc2V0dGluZ3NcIl0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdQZW5nYXR1cmFuIFdha3R1ICYgTW9kZSBVamlhbiBBbnRpLUN1cmFuZycsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ0RpIHRhYiBpbmksIEFuZGEgZGFwYXQgbWVuZ2FrdGlma2FuIE1vZGUgVWppYW4gKGthbWVyYSBwcm9jdG9yaW5nICYgcGVyaW5nYXRhbiBnYW50aSB0YWIpLCBtZW55ZXRlbCBiYXRhcyB3YWt0dSBwZW5nZXJqYWFuICh0aW1lciBvdG9tYXRpcyksIGRhbiBtZW5nYWNhayB1cnV0YW4gc29hbC4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPFNoaWVsZEFsZXJ0IHNpemU9ezE4fSAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudDogJ2JvdHRvbScsXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWRnZTogJ0tlYW1hbmFuIFVqaWFuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbjogKCkgPT4gc2V0QWN0aXZlVGFiKCdzZXR0aW5ncycpXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdG9yOiAnW2RhdGEtdG91cj1cInRhYi1zaGFyZVwiXScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0JhZ2lrYW4gTGluayAmIFVuZHVoIFFSIENvZGUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICdEYXBhdGthbiB0YXV0YW4gcHVibGlrIHVuaWsgdW50dWsgcmVzcG9uZGVuIGF0YXUgdW5kdWggbGVtYmFyIFFSIENvZGUgcmVzbWkgYmVya3VhbGl0YXMgdGluZ2dpIHVudHVrIGRpY2V0YWsgZGkgcnVhbmcga2VsYXMgZGFuIHVqaWFuIG9mZmxpbmUuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxTaGFyZTIgc2l6ZT17MTh9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50OiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlOiAnRGlzdHJpYnVzaScsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb246ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVUYWIoJ3NoYXJlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlTG9hZFNoYXJlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdG9yOiAnW2RhdGEtdG91cj1cImJ1aWxkZXItcHJldmlldy1idG5cIl0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdQcmF0aW5qYXUgVGFtcGlsYW4gUmVzcG9uZGVuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVWppIGRhbiBwYXN0aWthbiB0YW1waWxhbiBrdWlzIEFuZGEgbnlhbWFuIGRpbGloYXQgYmFpayBkaSBsYXlhciBzbWFydHBob25lIG1hdXB1biBrb21wdXRlciBkZXNrdG9wIHNlYmVsdW0gZGlzZWJhcmthbiBrZSBzaXN3YSBhdGF1IHJlc3BvbmRlbi4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPEV5ZSBzaXplPXsxOH0gLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ6ICdib3R0b20nLFxuICAgICAgICAgICAgICAgICAgICAgICAgYmFkZ2U6ICdTaW11bGFzaSdcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0b3I6ICdbZGF0YS10b3VyPVwiYnVpbGRlci1zYXZlLWJ0blwiXScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ1BlbnlpbXBhbmFuICYgRml0dXIgQXV0by1TYXZlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnU2ltcGFuIHBlcnViYWhhbiBrYXBhbiBzYWphLiBBbmRhIGp1Z2EgYmlzYSBtZW5nYWt0aWZrYW4gb3BzaSBBdXRvLVNhdmUgYWdhciBwcm9ncmVzIHBlbmdldGlrYW4gdGVyc2ltcGFuIHNlY2FyYSBvdG9tYXRpcyBzZXRpYXAga2FsaSBBbmRhIG1lbmdlZGl0LicsXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8U2F2ZSBzaXplPXsxOH0gLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ6ICdib3R0b20nLFxuICAgICAgICAgICAgICAgICAgICAgICAgYmFkZ2U6ICdDbG91ZCBTeW5jJ1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RvcjogJ1tkYXRhLXRvdXI9XCJidWlsZGVyLXB1Ymxpc2gtYnRuXCJdJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnUHVibGlrYXNpa2FuIEZvcm11bGlyIEFuZGEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICdTZXRlbGFoIHNlbXVhIHNvYWwgZGFuIGF0dXJhbiBzaWFwLCBrbGlrIHRvbWJvbCBQdWJsaWthc2lrYW4gYWdhciBmb3JtIGxhbmdzdW5nIGFrdGlmIGRhbiBkYXBhdCBkaWlzaSBvbGVoIHNpYXBhIHNhamEgeWFuZyBtZW5lcmltYSBsaW5rIScsXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8R2xvYmUgc2l6ZT17MTh9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50OiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlOiAnR28gTGl2ZSdcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF19XG4gICAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuIl19