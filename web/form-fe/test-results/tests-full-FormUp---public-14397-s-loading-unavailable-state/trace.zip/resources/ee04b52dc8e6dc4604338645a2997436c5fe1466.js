import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/OfflineBanner.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { WifiOff, RefreshCw } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/OfflineBanner.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function OfflineBanner() {
	_s();
	const [isOnline, setIsOnline] = useState(() => typeof navigator !== "undefined" ? navigator.onLine : true);
	useEffect(() => {
		const handleOnline = () => setIsOnline(true);
		const handleOffline = () => setIsOnline(false);
		window.addEventListener("online", handleOnline);
		window.addEventListener("offline", handleOffline);
		return () => {
			window.removeEventListener("online", handleOnline);
			window.removeEventListener("offline", handleOffline);
		};
	}, []);
	if (isOnline) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed top-0 left-0 right-0 z-50 bg-amber-600 text-white text-xs font-bold px-4 py-2 flex items-center justify-between shadow-md transition-all animate-fadeIn",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ _jsxDEV(WifiOff, { size: 15 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Koneksi terputus. Beberapa fitur memerlukan jaringan internet untuk bekerja." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			onClick: () => window.location.reload(),
			className: "px-2.5 py-1 bg-amber-700 hover:bg-amber-800 rounded-lg text-[11px] font-extrabold flex items-center gap-1 cursor-pointer",
			children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { size: 12 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 17
			}, this), " Coba Hubungkan"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 9
	}, this);
}
_s(OfflineBanner, "npQhEIe4yWUHYXCX0NKOIHM8iUU=");
_c = OfflineBanner;
var _c;
$RefreshReg$(_c, "OfflineBanner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/OfflineBanner.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/OfflineBanner.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/OfflineBanner.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/OfflineBanner.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLFNBQVMsaUJBQWlCOzs7O0FBRW5DLGVBQWUsU0FBUyxnQkFBZ0I7O0NBQ3BDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsZUFDNUIsT0FBTyxjQUFjLGNBQWMsVUFBVSxTQUFTLElBQzFEO0NBRUEsZ0JBQWdCO0VBQ1osTUFBTSxxQkFBcUIsWUFBWSxJQUFJO0VBQzNDLE1BQU0sc0JBQXNCLFlBQVksS0FBSztFQUU3QyxPQUFPLGlCQUFpQixVQUFVLFlBQVk7RUFDOUMsT0FBTyxpQkFBaUIsV0FBVyxhQUFhO0VBRWhELGFBQWE7R0FDVCxPQUFPLG9CQUFvQixVQUFVLFlBQVk7R0FDakQsT0FBTyxvQkFBb0IsV0FBVyxhQUFhO0VBQ3ZEO0NBQ0osR0FBRyxDQUFDLENBQUM7Q0FFTCxJQUFJLFVBQVUsT0FBTztDQUVyQixPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDSSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0ksd0JBQUMsU0FBRCxFQUFTLE1BQU0sR0FBSzs7OzthQUNwQix3QkFBQyxRQUFELFlBQU0sK0VBQWtGOzs7O1dBQ3ZGOzs7OztZQUNMLHdCQUFDLFVBQUQ7R0FDSSxNQUFLO0dBQ0wsZUFBZSxPQUFPLFNBQVMsT0FBTztHQUN0QyxXQUFVO2FBSGQsQ0FLSSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O2FBQUMsaUJBQ25COzs7OztVQUNQOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJPZmZsaW5lQmFubmVyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgV2lmaU9mZiwgUmVmcmVzaEN3IH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gT2ZmbGluZUJhbm5lcigpIHtcbiAgICBjb25zdCBbaXNPbmxpbmUsIHNldElzT25saW5lXSA9IHVzZVN0YXRlKCgpID0+XG4gICAgICAgIHR5cGVvZiBuYXZpZ2F0b3IgIT09ICd1bmRlZmluZWQnID8gbmF2aWdhdG9yLm9uTGluZSA6IHRydWVcbiAgICApO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgaGFuZGxlT25saW5lID0gKCkgPT4gc2V0SXNPbmxpbmUodHJ1ZSk7XG4gICAgICAgIGNvbnN0IGhhbmRsZU9mZmxpbmUgPSAoKSA9PiBzZXRJc09ubGluZShmYWxzZSk7XG5cbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ29ubGluZScsIGhhbmRsZU9ubGluZSk7XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdvZmZsaW5lJywgaGFuZGxlT2ZmbGluZSk7XG5cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdvbmxpbmUnLCBoYW5kbGVPbmxpbmUpO1xuICAgICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ29mZmxpbmUnLCBoYW5kbGVPZmZsaW5lKTtcbiAgICAgICAgfTtcbiAgICB9LCBbXSk7XG5cbiAgICBpZiAoaXNPbmxpbmUpIHJldHVybiBudWxsO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtMCBsZWZ0LTAgcmlnaHQtMCB6LTUwIGJnLWFtYmVyLTYwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHB4LTQgcHktMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGFuaW1hdGUtZmFkZUluXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFdpZmlPZmYgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+S29uZWtzaSB0ZXJwdXR1cy4gQmViZXJhcGEgZml0dXIgbWVtZXJsdWthbiBqYXJpbmdhbiBpbnRlcm5ldCB1bnR1ayBiZWtlcmphLjwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSBiZy1hbWJlci03MDAgaG92ZXI6YmctYW1iZXItODAwIHJvdW5kZWQtbGcgdGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgc2l6ZT17MTJ9IC8+IENvYmEgSHVidW5na2FuXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdfQ==