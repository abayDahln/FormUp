import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/VerifyRegister.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import { verifyRegistration } from "/src/services/apiService.js";
import { FileText, ArrowRight, User, Mail, Lock, Calendar, Loader2, Eye, EyeOff } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/VerifyRegister.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const VerifyRegister = () => {
	_s();
	const [otp, setOtp] = useState("");
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(false);
	const location = useLocation();
	const navigate = useNavigate();
	// Menangkap data dari halaman Register
	const userData = location.state;
	// Jika tidak ada data (user langsung tembak URL /verify), kembalikan ke register
	useEffect(() => {
		if (!userData) {
			navigate("/register");
		}
	}, [userData, navigate]);
	const handleVerify = async (e) => {
		e.preventDefault();
		setError("");
		setLoading(true);
		const result = await verifyRegistration(userData.fullname, userData.username, userData.email, userData.password, userData.birthdate, otp);
		setLoading(false);
		// Cek sukses verifikasi
		if (result.ok && result.data?.token) {
			navigate("/login");
		} else {
			setError(result.message || "Verifikasi OTP gagal. Coba lagi.");
		}
	};
	if (!userData) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "h-screen max-h-screen w-full bg-[#004D4E] flex items-center justify-center p-4 sm:p-6 lg:p-12 relative overflow-hidden select-none touch-none",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute inset-0 pointer-events-none",
				style: { background: "linear-gradient(200deg, #2ED8C3 0%, #0FA89E 35%, #018081 75%, #004D4E 100%)" }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute pointer-events-none rounded-full",
				style: {
					width: "clamp(350px, 45vw, 750px)",
					height: "clamp(350px, 45vw, 750px)",
					top: "-10%",
					left: "-10%",
					background: "linear-gradient(-143deg, #2ED8C3 0%, rgba(10, 95, 110, 0.7) 100%)",
					opacity: .6,
					zIndex: 1
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute pointer-events-none rounded-full",
				style: {
					width: "clamp(350px, 45vw, 750px)",
					height: "clamp(350px, 45vw, 750px)",
					bottom: "-10%",
					right: "-10%",
					background: "linear-gradient(135deg, #2ED8C3 0%, rgba(10, 29, 93, 0.7) 100%)",
					opacity: .8,
					zIndex: 1
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative z-10 w-full max-w-md my-auto",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "w-full bg-black/40 backdrop-blur-[20px] border border-white/10 rounded-[28px] p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-2xl sm:text-[28px] font-bold text-white tracking-tight",
								children: "Verifikasi Email"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 93,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs sm:text-sm font-medium text-white/70",
								children: ["Masukkan 6 digit kode OTP yang dikirim ke ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[#2ED8C3] font-semibold",
									children: userData?.email
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 97,
									columnNumber: 67
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 17
						}, this),
						error && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-red-500/20 border border-red-500/30 rounded-xl",
							children: /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold text-red-300 text-center",
								children: error
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 25
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleVerify,
							className: "space-y-6",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "123456",
								value: otp,
								onChange: (e) => setOtp(e.target.value.replace(/\D/g, "")),
								required: true,
								maxLength: 6,
								className: "w-full px-4 py-3.5 sm:py-4 rounded-xl border border-white/10 bg-black/30 text-white placeholder:text-white/30 font-mono tracking-[0.5em] text-center focus:outline-none focus:bg-black/50 focus:border-[#2ED8C3] focus:ring-1 focus:ring-[#2ED8C3] transition-all text-lg sm:text-xl shadow-inner"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 25
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								disabled: loading,
								className: "w-full py-3.5 px-6 bg-[#0FA89E] hover:bg-[#0d968d] active:scale-[0.98] disabled:opacity-60 text-white font-bold rounded-full shadow-[0_6px_20px_rgba(15,168,158,0.4)] transition-all duration-200 text-xs sm:text-sm tracking-wide cursor-pointer disabled:cursor-not-allowed flex items-center justify-center gap-2",
								children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
									size: 16,
									className: "animate-spin"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Memverifikasi..." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 33
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 126,
									columnNumber: 29
								}, this) : /* @__PURE__ */ _jsxDEV("span", { children: "Verifikasi & Lanjutkan" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 29
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 13
	}, this);
};
_s(VerifyRegister, "8nqfRD32EzPs+NGtHl2JXwSCZgM=", false, function() {
	return [useLocation, useNavigate];
});
_c = VerifyRegister;
export default VerifyRegister;
var _c;
$RefreshReg$(_c, "VerifyRegister");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/VerifyRegister.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/VerifyRegister.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/VerifyRegister.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/auth/VerifyRegister.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLGFBQWEsbUJBQW1CO0FBQ3pDLFNBQVMsMEJBQTBCO0FBQ25DLFNBQVMsVUFBVSxZQUFZLE1BQU0sTUFBTSxNQUFNLFVBQVUsU0FBUyxLQUFLLGNBQWM7Ozs7QUFHdkYsTUFBTSx1QkFBdUI7O0NBQ3pCLE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBUyxFQUFFO0NBQ2pDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBRTVDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sV0FBVyxZQUFZOztDQUc3QixNQUFNLFdBQVcsU0FBUzs7Q0FHMUIsZ0JBQWdCO0VBQ1osSUFBSSxDQUFDLFVBQVU7R0FDWCxTQUFTLFdBQVc7RUFDeEI7Q0FDSixHQUFHLENBQUMsVUFBVSxRQUFRLENBQUM7Q0FFdkIsTUFBTSxlQUFlLE9BQU8sTUFBTTtFQUM5QixFQUFFLGVBQWU7RUFDakIsU0FBUyxFQUFFO0VBQ1gsV0FBVyxJQUFJO0VBRWYsTUFBTSxTQUFTLE1BQU0sbUJBQ2pCLFNBQVMsVUFDVCxTQUFTLFVBQ1QsU0FBUyxPQUNULFNBQVMsVUFDVCxTQUFTLFdBQ1QsR0FDSjtFQUNBLFdBQVcsS0FBSzs7RUFHaEIsSUFBSSxPQUFPLE1BQU0sT0FBTyxNQUFNLE9BQU87R0FDakMsU0FBUyxRQUFRO0VBQ3JCLE9BQU87R0FDSCxTQUFTLE9BQU8sV0FBVyxrQ0FBa0M7RUFDakU7Q0FDSjtDQUVBLElBQUksQ0FBQyxVQUFVLE9BQU87Q0FFdEIsT0FDUSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUosd0JBQUMsT0FBRDtJQUNJLFdBQVU7SUFDVixPQUFPLEVBQ0gsWUFBWSw4RUFDaEI7R0FDSDs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQ0ksV0FBVTtJQUNWLE9BQU87S0FDSCxPQUFPO0tBQ1AsUUFBUTtLQUNSLEtBQUs7S0FDTCxNQUFNO0tBQ04sWUFBWTtLQUNaLFNBQVM7S0FDVCxRQUFRO0lBQ1o7R0FDSDs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQ0ksV0FBVTtJQUNWLE9BQU87S0FDSCxPQUFPO0tBQ1AsUUFBUTtLQUNSLFFBQVE7S0FDUixPQUFPO0tBQ1AsWUFBWTtLQUNaLFNBQVM7S0FDVCxRQUFRO0lBQ1o7R0FDSDs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNYLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUE4RDtPQUV4RTs7OztpQkFDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYixDQUE0RCw4Q0FDZCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0MsVUFBVTtRQUFZOzs7O2dCQUNqSDs7Ozs7ZUFDRjs7Ozs7O01BRUosU0FDRyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBOEM7T0FBUzs7Ozs7TUFDbkU7Ozs7O01BR1Qsd0JBQUMsUUFBRDtPQUFNLFVBQVU7T0FBYyxXQUFVO2lCQUF4QyxDQUNJLHdCQUFDLE9BQUQsWUFDSSx3QkFBQyxTQUFEO1FBQ0ksTUFBSztRQUNMLGFBQVk7UUFDWixPQUFPO1FBQ1AsV0FBVyxNQUFNLE9BQU8sRUFBRSxPQUFPLE1BQU0sUUFBUSxPQUFPLEVBQUUsQ0FBQztRQUN6RDtRQUNBLFdBQVc7UUFDWCxXQUFVO09BQ2I7Ozs7Z0JBQ0E7Ozs7aUJBRUwsd0JBQUMsVUFBRDtRQUNJLE1BQUs7UUFDTCxVQUFVO1FBQ1YsV0FBVTtrQkFFVCxVQUNHLGdEQUNJLHdCQUFDLFNBQUQ7U0FBUyxNQUFNO1NBQUksV0FBVTtRQUFnQjs7OztrQkFDN0Msd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztnQkFDOUI7Ozs7bUJBRUYsd0JBQUMsUUFBRCxZQUFNLHlCQUE0Qjs7Ozs7T0FFbEM7Ozs7ZUFDTjs7Ozs7O0tBRUw7Ozs7OztHQUNKOzs7OztFQUNKOzs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlZlcmlmeVJlZ2lzdGVyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB2ZXJpZnlSZWdpc3RyYXRpb24gfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IEZpbGVUZXh0LCBBcnJvd1JpZ2h0LCBVc2VyLCBNYWlsLCBMb2NrLCBDYWxlbmRhciwgTG9hZGVyMiwgRXllLCBFeWVPZmYgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5cbmNvbnN0IFZlcmlmeVJlZ2lzdGVyID0gKCkgPT4ge1xuICAgIGNvbnN0IFtvdHAsIHNldE90cF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIFxuICAgIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgXG4gICAgLy8gTWVuYW5na2FwIGRhdGEgZGFyaSBoYWxhbWFuIFJlZ2lzdGVyXG4gICAgY29uc3QgdXNlckRhdGEgPSBsb2NhdGlvbi5zdGF0ZTtcblxuICAgIC8vIEppa2EgdGlkYWsgYWRhIGRhdGEgKHVzZXIgbGFuZ3N1bmcgdGVtYmFrIFVSTCAvdmVyaWZ5KSwga2VtYmFsaWthbiBrZSByZWdpc3RlclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghdXNlckRhdGEpIHtcbiAgICAgICAgICAgIG5hdmlnYXRlKCcvcmVnaXN0ZXInKTtcbiAgICAgICAgfVxuICAgIH0sIFt1c2VyRGF0YSwgbmF2aWdhdGVdKTtcblxuICAgIGNvbnN0IGhhbmRsZVZlcmlmeSA9IGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgc2V0RXJyb3IoJycpO1xuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHZlcmlmeVJlZ2lzdHJhdGlvbihcbiAgICAgICAgICAgIHVzZXJEYXRhLmZ1bGxuYW1lLFxuICAgICAgICAgICAgdXNlckRhdGEudXNlcm5hbWUsXG4gICAgICAgICAgICB1c2VyRGF0YS5lbWFpbCxcbiAgICAgICAgICAgIHVzZXJEYXRhLnBhc3N3b3JkLFxuICAgICAgICAgICAgdXNlckRhdGEuYmlydGhkYXRlLFxuICAgICAgICAgICAgb3RwXG4gICAgICAgICk7XG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuXG4gICAgICAgIC8vIENlayBzdWtzZXMgdmVyaWZpa2FzaVxuICAgICAgICBpZiAocmVzdWx0Lm9rICYmIHJlc3VsdC5kYXRhPy50b2tlbikge1xuICAgICAgICAgICAgbmF2aWdhdGUoJy9sb2dpbicpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0RXJyb3IocmVzdWx0Lm1lc3NhZ2UgfHwgJ1ZlcmlmaWthc2kgT1RQIGdhZ2FsLiBDb2JhIGxhZ2kuJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKCF1c2VyRGF0YSkgcmV0dXJuIG51bGw7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLXNjcmVlbiBtYXgtaC1zY3JlZW4gdy1mdWxsIGJnLVsjMDA0RDRFXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgc206cC02IGxnOnAtMTIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHNlbGVjdC1ub25lIHRvdWNoLW5vbmVcIj4gXG4gICAgICAgIHsvKiBCYWNrZ3JvdW5kIEdyYWRpZW4gVXRhbWEgKi99XG4gICAgICAgIDxkaXYgXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHBvaW50ZXItZXZlbnRzLW5vbmVcIlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDIwMGRlZywgIzJFRDhDMyAwJSwgIzBGQTg5RSAzNSUsICMwMTgwODEgNzUlLCAjMDA0RDRFIDEwMCUpJ1xuICAgICAgICAgICAgfX1cbiAgICAgICAgLz5cblxuICAgICAgICB7LyogQnVsYXRhbiBHcmFkaWVuIEtpcmkgQXRhcyAqL31cbiAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcG9pbnRlci1ldmVudHMtbm9uZSByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICB3aWR0aDogJ2NsYW1wKDM1MHB4LCA0NXZ3LCA3NTBweCknLFxuICAgICAgICAgICAgICAgIGhlaWdodDogJ2NsYW1wKDM1MHB4LCA0NXZ3LCA3NTBweCknLFxuICAgICAgICAgICAgICAgIHRvcDogJy0xMCUnLFxuICAgICAgICAgICAgICAgIGxlZnQ6ICctMTAlJyxcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KC0xNDNkZWcsICMyRUQ4QzMgMCUsIHJnYmEoMTAsIDk1LCAxMTAsIDAuNykgMTAwJSknLFxuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuNixcbiAgICAgICAgICAgICAgICB6SW5kZXg6IDFcbiAgICAgICAgICAgIH19XG4gICAgICAgIC8+XG5cbiAgICAgICAgey8qIEJ1bGF0YW4gR3JhZGllbiBLYW5hbiBCYXdhaCAqL31cbiAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcG9pbnRlci1ldmVudHMtbm9uZSByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICB3aWR0aDogJ2NsYW1wKDM1MHB4LCA0NXZ3LCA3NTBweCknLFxuICAgICAgICAgICAgICAgIGhlaWdodDogJ2NsYW1wKDM1MHB4LCA0NXZ3LCA3NTBweCknLFxuICAgICAgICAgICAgICAgIGJvdHRvbTogJy0xMCUnLFxuICAgICAgICAgICAgICAgIHJpZ2h0OiAnLTEwJScsXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCgxMzVkZWcsICMyRUQ4QzMgMCUsIHJnYmEoMTAsIDI5LCA5MywgMC43KSAxMDAlKScsXG4gICAgICAgICAgICAgICAgb3BhY2l0eTogMC44LFxuICAgICAgICAgICAgICAgIHpJbmRleDogMVxuICAgICAgICAgICAgfX1cbiAgICAgICAgLz5cblxuICAgICAgICB7LyogQ2FyZCBWZXJpZmlrYXNpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgdy1mdWxsIG1heC13LW1kIG15LWF1dG9cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWJsYWNrLzQwIGJhY2tkcm9wLWJsdXItWzIwcHhdIGJvcmRlciBib3JkZXItd2hpdGUvMTAgcm91bmRlZC1bMjhweF0gcC02IHNtOnAtOCBzaGFkb3ctWzBfOHB4XzMycHhfMF9yZ2JhKDAsMCwwLDAuMzcpXSBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgc206dGV4dC1bMjhweF0gZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFZlcmlmaWthc2kgRW1haWxcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUvNzBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIE1hc3Vra2FuIDYgZGlnaXQga29kZSBPVFAgeWFuZyBkaWtpcmltIGtlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyMyRUQ4QzNdIGZvbnQtc2VtaWJvbGRcIj57dXNlckRhdGE/LmVtYWlsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1yZWQtNTAwLzIwIGJvcmRlciBib3JkZXItcmVkLTUwMC8zMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXJlZC0zMDAgdGV4dC1jZW50ZXJcIj57ZXJyb3J9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVZlcmlmeX0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIxMjM0NTZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvdHB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRPdHAoZS50YXJnZXQudmFsdWUucmVwbGFjZSgvXFxEL2csICcnKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezZ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMy41IHNtOnB5LTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIGJnLWJsYWNrLzMwIHRleHQtd2hpdGUgcGxhY2Vob2xkZXI6dGV4dC13aGl0ZS8zMCBmb250LW1vbm8gdHJhY2tpbmctWzAuNWVtXSB0ZXh0LWNlbnRlciBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6YmctYmxhY2svNTAgZm9jdXM6Ym9yZGVyLVsjMkVEOEMzXSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzJFRDhDM10gdHJhbnNpdGlvbi1hbGwgdGV4dC1sZyBzbTp0ZXh0LXhsIHNoYWRvdy1pbm5lclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMuNSBweC02IGJnLVsjMEZBODlFXSBob3ZlcjpiZy1bIzBkOTY4ZF0gYWN0aXZlOnNjYWxlLVswLjk4XSBkaXNhYmxlZDpvcGFjaXR5LTYwIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQtZnVsbCBzaGFkb3ctWzBfNnB4XzIwcHhfcmdiYSgxNSwxNjgsMTU4LDAuNCldIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCB0ZXh0LXhzIHNtOnRleHQtc20gdHJhY2tpbmctd2lkZSBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsxNn0gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+TWVtdmVyaWZpa2FzaS4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VmVyaWZpa2FzaSAmIExhbmp1dGthbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFZlcmlmeVJlZ2lzdGVyOyJdfQ==