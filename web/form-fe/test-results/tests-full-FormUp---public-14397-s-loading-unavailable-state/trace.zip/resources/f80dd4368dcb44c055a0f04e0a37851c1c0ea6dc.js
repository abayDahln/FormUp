import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboard/userDashboard/myForms.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f73b8454";
import Sidebar from "/src/components/layout/Sidebar.jsx";
import Topbar from "/src/components/layout/Topbar.jsx";
import ConfirmModal from "/src/components/ui/ConfirmModal.jsx";
import AIFormBuilderModal from "/src/components/ui/AIFormBuilderModal.jsx";
import { Plus, MoreVertical, MessageSquare, Calendar, Edit3, Eye, Trash2, CheckCircle2, FileText, ChevronLeft, ChevronRight, ChevronDown, Square, CheckSquare, Copy, Sparkles, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
import { getMyForms, deleteForm, clearSession, assetUrl, createForm, bulkDeleteForms, getQuestions, saveQuestions } from "/src/services/apiService.js";
import useDebounce from "/src/hooks/useDebounce.js";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/myForms.jsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
const ITEMS_PER_PAGE = 7;
const MyForms = () => {
	_s();
	const navigate = useNavigate();
	const [activeTab, setActiveTab] = useState("All");
	const [myForms, setMyForms] = useState([]);
	const [loading, setLoading] = useState(true);
	const [openMenuId, setOpenMenuId] = useState(null);
	const [actionLoading, setActionLoading] = useState(null);
	const [searchQuery, setSearchQuery] = useState("");
	const debouncedSearch = useDebounce(searchQuery, 350);
	const [currentPage, setCurrentPage] = useState(1);
	const [creatingForm, setCreatingForm] = useState(false);
	const menuRef = useRef(null);
	const createMenuRef = useRef(null);
	const [showCreateMenu, setShowCreateMenu] = useState(false);
	// Multi-select state
	const [selectedIds, setSelectedIds] = useState(new Set());
	const [selectMode, setSelectMode] = useState(false);
	const [confirmModal, setConfirmModal] = useState({
		isOpen: false,
		title: "",
		message: "",
		variant: "danger",
		confirmText: "Ya, Hapus",
		formId: null,
		isBulk: false
	});
	// AI Form Builder
	const [aiFormBuilderOpen, setAiFormBuilderOpen] = useState(false);
	// FEAT-10b: Duplicate form state
	const [duplicatingId, setDuplicatingId] = useState(null);
	useEffect(() => {
		const fetchMyForms = async () => {
			try {
				setLoading(true);
				const result = await getMyForms();
				if (result.status === 401) {
					clearSession();
					navigate("/login");
					return;
				}
				if (result.ok && Array.isArray(result.data)) {
					setMyForms(result.data);
				}
			} catch (err) {
				console.error("Error fetching forms:", err);
			} finally {
				setLoading(false);
			}
		};
		fetchMyForms();
	}, [navigate]);
	useEffect(() => {
		const handleClickOutside = (e) => {
			if (menuRef.current && !menuRef.current.contains(e.target)) {
				setOpenMenuId(null);
			}
			if (createMenuRef.current && !createMenuRef.current.contains(e.target)) {
				setShowCreateMenu(false);
			}
		};
		document.addEventListener("mousedown", handleClickOutside);
		return () => document.removeEventListener("mousedown", handleClickOutside);
	}, []);
	const handleCreateNewForm = async () => {
		if (creatingForm) return;
		setCreatingForm(true);
		try {
			const res = await createForm({
				title: "Formulir Tanpa Judul",
				description: ""
			});
			if (res.status === 401) {
				clearSession();
				navigate("/login");
				return;
			}
			if (res.ok && res.data?.id) {
				navigate(`/forms/${res.data.id}/edit`);
			} else {
				navigate("/create-form");
			}
		} catch (err) {
			console.error("Error creating form:", err);
			navigate("/create-form");
		} finally {
			setCreatingForm(false);
		}
	};
	const toggleSelect = (id) => {
		setSelectedIds((prev) => {
			const next = new Set(prev);
			if (next.has(id)) next.delete(id);
			else next.add(id);
			return next;
		});
	};
	const toggleSelectAll = () => {
		if (selectedIds.size === pagedForms.length) {
			setSelectedIds(new Set());
		} else {
			setSelectedIds(new Set(pagedForms.map((f) => f.id)));
		}
	};
	const triggerBulkDelete = () => {
		if (selectedIds.size === 0) return;
		setConfirmModal({
			isOpen: true,
			title: `Hapus ${selectedIds.size} Formulir?`,
			message: `Apakah Anda yakin ingin menghapus ${selectedIds.size} formulir yang dipilih? Tindakan ini tidak dapat dibatalkan.`,
			variant: "danger",
			confirmText: `Hapus ${selectedIds.size} Formulir`,
			formId: null,
			isBulk: true
		});
	};
	const triggerDelete = (formId) => {
		setOpenMenuId(null);
		setConfirmModal({
			isOpen: true,
			title: "Hapus Formulir?",
			message: "Apakah Anda yakin ingin menghapus formulir ini? Tindakan ini tidak dapat dibatalkan.",
			variant: "danger",
			confirmText: "Ya, Hapus",
			formId,
			isBulk: false
		});
	};
	const executeDelete = async () => {
		if (confirmModal.isBulk) {
			const ids = [...selectedIds];
			setActionLoading("bulk");
			try {
				const result = await bulkDeleteForms(ids);
				if (result.ok) {
					setMyForms((prev) => prev.filter((f) => !ids.includes(f.id)));
					setSelectedIds(new Set());
					setSelectMode(false);
				}
			} catch (err) {
				console.error("Bulk delete error:", err);
			} finally {
				setActionLoading(null);
				setConfirmModal((prev) => ({
					...prev,
					isOpen: false
				}));
			}
		} else {
			const formId = confirmModal.formId;
			if (!formId) return;
			setActionLoading(formId);
			try {
				const result = await deleteForm(formId);
				if (result.ok) {
					setMyForms((prev) => prev.filter((f) => f.id !== formId));
					setSelectedIds((prev) => {
						const n = new Set(prev);
						n.delete(formId);
						return n;
					});
				}
			} catch (err) {
				console.error("Delete form error:", err);
			} finally {
				setActionLoading(null);
				setConfirmModal((prev) => ({
					...prev,
					isOpen: false,
					formId: null
				}));
			}
		}
	};
	// FEAT-10b: Duplicate form
	const handleDuplicateForm = async (formId, formTitle) => {
		setOpenMenuId(null);
		setDuplicatingId(formId);
		try {
			const qRes = await getQuestions(formId);
			const createRes = await createForm({
				title: `Salinan dari ${formTitle || "Formulir"}`,
				description: ""
			});
			if (!createRes.ok || !createRes.data?.id) {
				setDuplicatingId(null);
				return;
			}
			const newId = createRes.data.id;
			if (qRes.ok && Array.isArray(qRes.data) && qRes.data.length > 0) {
				const payload = qRes.data.map((q, i) => ({
					id: undefined,
					typeId: q.typeId,
					question: q.question || "",
					questionFormat: q.questionFormat || "text",
					questionOrder: i + 1,
					isRequired: !!q.isRequired,
					correctAnswer: q.correctAnswer || null,
					points: q.points || null,
					questionImage: null,
					questionAudio: null,
					options: (q.options || []).map((o) => ({
						optionText: o.optionText || "",
						isCorrect: !!o.isCorrect
					}))
				}));
				await saveQuestions(newId, payload);
			}
			navigate(`/forms/${newId}/edit`);
		} catch (err) {
			console.error("Duplicate form error:", err);
		} finally {
			setDuplicatingId(null);
		}
	};
	const publishedForms = myForms.filter((f) => f.status?.toLowerCase() === "published");
	const draftForms = myForms.filter((f) => f.status?.toLowerCase() === "draft");
	const totalResponses = myForms.reduce((acc, f) => acc + (f.responseCount ?? 0), 0);
	const filteredForms = useMemo(() => {
		return myForms.filter((form) => {
			const s = form.status?.toLowerCase() ?? "draft";
			if (activeTab === "Published" && s !== "published") return false;
			if (activeTab === "Draft" && s !== "draft") return false;
			if (debouncedSearch.trim()) {
				const q = debouncedSearch.toLowerCase();
				return form.title && form.title.toLowerCase().includes(q) || form.description && form.description.toLowerCase().includes(q) || form.status && form.status.toLowerCase().includes(q);
			}
			return true;
		});
	}, [
		myForms,
		activeTab,
		debouncedSearch
	]);
	// Reset to page 1 on search or tab switch
	useEffect(() => {
		setCurrentPage(1);
	}, [activeTab, debouncedSearch]);
	const totalPages = Math.max(1, Math.ceil(filteredForms.length / ITEMS_PER_PAGE));
	const pagedForms = useMemo(() => {
		const start = (currentPage - 1) * ITEMS_PER_PAGE;
		return filteredForms.slice(start, start + ITEMS_PER_PAGE);
	}, [filteredForms, currentPage]);
	const tabs = [
		{
			id: "All",
			label: `Semua (${myForms.length})`
		},
		{
			id: "Published",
			label: `Dipublikasikan (${publishedForms.length})`
		},
		{
			id: "Draft",
			label: `Draf (${draftForms.length})`
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex h-screen w-full bg-[#F8FAFC] dark:bg-slate-950 font-sans antialiased text-slate-800 dark:text-slate-100 overflow-hidden transition-colors",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 274,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col h-full min-w-0 overflow-y-auto",
				children: /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 w-full p-4 sm:p-6 lg:p-8 space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV(Topbar, {
							searchQuery,
							onSearchChange: setSearchQuery,
							placeholder: "Cari formulir Anda..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 280,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight",
								children: "Formulir Saya"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium mt-1",
								children: "Kelola dan pantau seluruh koleksi formulir Anda."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 290,
								columnNumber: 29
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "w-full sm:w-auto grid grid-cols-3 sm:flex items-center bg-slate-200/60 dark:bg-slate-800/80 p-1 rounded-2xl border border-slate-200/80 dark:border-slate-700/60 gap-1",
								children: tabs.map((tab) => /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setActiveTab(tab.id),
									className: `w-full px-2 sm:px-4 py-2 rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer text-center whitespace-nowrap ${activeTab === tab.id ? "bg-white dark:bg-slate-900 text-teal-700 dark:text-teal-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
									children: tab.label
								}, tab.id, false, {
									fileName: _jsxFileName,
									lineNumber: 297,
									columnNumber: 29
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 295,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 287,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-[#005B52] dark:bg-teal-950/70 rounded-2xl p-4 sm:p-5 text-white shadow-xs relative overflow-hidden border border-teal-800/30 flex flex-col justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "relative z-10",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-teal-200/90 font-bold text-[10px] uppercase tracking-wider mb-1",
										children: "Total Respons"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 316,
										columnNumber: 33
									}, this), /* @__PURE__ */ _jsxDEV("h2", {
										className: "text-2xl sm:text-3xl font-extrabold tracking-tight",
										children: totalResponses.toLocaleString("id-ID")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 33
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 315,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("div", { className: "absolute -right-6 -bottom-6 w-24 sm:w-28 h-24 sm:h-28 bg-white/10 rounded-full blur-xl pointer-events-none" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 319,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 314,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs flex flex-col justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400 dark:text-slate-500 font-bold text-[10px] uppercase tracking-wider mb-1",
									children: "Formulir Aktif"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 324,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("h2", {
									className: "text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight",
									children: publishedForms.length
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 33
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 323,
									columnNumber: 29
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[#00897B] dark:text-teal-400 flex items-center text-[10px] sm:text-xs font-bold mt-2",
									children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 mr-1 shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 328,
										columnNumber: 33
									}, this), " Aktif & menerima"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 313,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									if (!selectMode) {
										setSelectMode(true);
									} else {
										toggleSelectAll();
									}
								},
								className: `flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold border-2 transition-all cursor-pointer ${selectMode ? "bg-teal-500 text-white border-teal-500 shadow-sm" : "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700 hover:border-teal-500 dark:hover:border-teal-400"}`,
								children: [selectMode && selectedIds.size === pagedForms.length ? /* @__PURE__ */ _jsxDEV(CheckSquare, {
									size: 18,
									className: "text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 33
								}, this) : /* @__PURE__ */ _jsxDEV(Square, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 352,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: !selectMode ? "Pilih Beberapa" : selectedIds.size === pagedForms.length ? "Batal Pilih Semua" : "Pilih Semua" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 354,
									columnNumber: 29
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 25
							}, this), selectMode && /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setSelectMode(false);
									setSelectedIds(new Set());
								},
								className: "text-xs sm:text-sm font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white bg-slate-200/60 dark:bg-slate-800 px-3.5 py-2 rounded-xl transition-colors cursor-pointer",
								children: "Selesai"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 364,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 21
						}, this),
						selectMode && selectedIds.size > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "fixed bottom-5 left-4 right-4 sm:left-1/2 sm:-translate-x-1/2 sm:max-w-md z-50 bg-slate-900/95 dark:bg-slate-800/95 text-white backdrop-blur-lg px-5 py-3.5 rounded-2xl shadow-2xl border border-slate-700 flex items-center justify-between gap-4 animate-in fade-in slide-in-from-bottom-5 duration-200",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-teal-400 animate-pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 380,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs sm:text-sm font-semibold text-slate-200",
									children: [/* @__PURE__ */ _jsxDEV("strong", {
										className: "text-white font-extrabold text-sm sm:text-base",
										children: selectedIds.size
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 382,
										columnNumber: 37
									}, this), " dipilih"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 381,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 379,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: triggerBulkDelete,
								disabled: actionLoading === "bulk",
								className: "flex items-center gap-2 bg-rose-600 hover:bg-rose-500 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl transition-all cursor-pointer shadow-md active:scale-95 disabled:opacity-60",
								children: [/* @__PURE__ */ _jsxDEV(Trash2, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 391,
									columnNumber: 33
								}, this), "Hapus Formulir"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 386,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 378,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4",
							ref: menuRef,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								ref: createMenuRef,
								className: "bg-white dark:bg-slate-900 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl min-h-[240px] flex flex-col items-center justify-center hover:border-[#00897B] dark:hover:border-teal-400 hover:bg-teal-50/10 dark:hover:bg-teal-950/10 transition-all group p-6 text-center relative",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-12 h-12 bg-teal-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform text-[#00897B] dark:text-teal-400 border border-teal-200/60 dark:border-slate-700",
										children: /* @__PURE__ */ _jsxDEV(Plus, { className: "w-6 h-6" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 405,
											columnNumber: 33
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 404,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-slate-900 dark:text-white font-bold text-sm mb-1",
										children: "Buat Formulir Baru"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 407,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-400 dark:text-slate-500 text-xs font-medium max-w-[170px] mb-4",
										children: "Pilih cara pembuatan formulir Anda"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 410,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: (e) => {
											e.stopPropagation();
											setShowCreateMenu(!showCreateMenu);
										},
										className: "flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-white hover:border-teal-500 hover:text-teal-600 dark:hover:bg-slate-900 dark:hover:text-teal-400 transition-all cursor-pointer",
										children: [
											/* @__PURE__ */ _jsxDEV(Plus, { size: 13 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 418,
												columnNumber: 33
											}, this),
											" Pilih Cara Buat",
											/* @__PURE__ */ _jsxDEV(ChevronDown, {
												size: 13,
												className: `transition-transform ${showCreateMenu ? "rotate-180" : ""}`
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 419,
												columnNumber: 33
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 413,
										columnNumber: 29
									}, this),
									showCreateMenu && /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-56 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden z-30 animate-in fade-in slide-in-from-bottom-2 duration-150",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												setShowCreateMenu(false);
												handleCreateNewForm();
											},
											disabled: creatingForm,
											className: "w-full px-4 py-3 text-left border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-60",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300",
													children: /* @__PURE__ */ _jsxDEV(Edit3, { size: 15 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 432,
														columnNumber: 49
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 431,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs font-extrabold text-slate-900 dark:text-white",
													children: creatingForm ? "Menyiapkan..." : "Buat Manual"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 435,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400 dark:text-slate-500 font-medium",
													children: "Susun soal dari awal"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 438,
													columnNumber: 49
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 434,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 430,
												columnNumber: 41
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 424,
											columnNumber: 37
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												setShowCreateMenu(false);
												setAiFormBuilderOpen(true);
											},
											className: "w-full px-4 py-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-950/40 flex items-center justify-center text-teal-600 dark:text-teal-400 border border-teal-100 dark:border-teal-900/40",
													children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 15 }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 451,
														columnNumber: 49
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 450,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs font-extrabold text-slate-900 dark:text-white",
													children: "Buat dengan AI"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 454,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400 dark:text-slate-500 font-medium",
													children: "Deskripsikan, AI susun soal"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 457,
													columnNumber: 49
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 453,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 449,
												columnNumber: 41
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 444,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 423,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 400,
								columnNumber: 25
							}, this), loading ? /* @__PURE__ */ _jsxDEV("div", {
								className: "col-span-full py-16 text-center text-slate-400 dark:text-slate-500 text-sm font-medium",
								children: "Memuat formulir..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 468,
								columnNumber: 29
							}, this) : filteredForms.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "col-span-full py-16 text-center text-slate-400 dark:text-slate-500 text-sm font-medium",
								children: debouncedSearch ? `Tidak ada formulir yang cocok dengan "${debouncedSearch}".` : "Belum ada formulir pada tab ini."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 472,
								columnNumber: 29
							}, this) : pagedForms.map((form) => {
								const status = typeof form.status === "string" ? form.status : "draft";
								const isPublished = status.toLowerCase() === "published";
								const responseCount = form.responseCount ?? 0;
								const isActing = actionLoading === form.id;
								const createdDate = form.createdAt ? new Date(form.createdAt).toLocaleDateString("id-ID", {
									month: "short",
									day: "numeric",
									year: "numeric"
								}) : "Baru saja";
								const isSelected = selectedIds.has(form.id);
								return /* @__PURE__ */ _jsxDEV("div", {
									onClick: () => selectMode && toggleSelect(form.id),
									className: `bg-white dark:bg-slate-900 border rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between group ${isActing ? "opacity-60 pointer-events-none" : ""} ${selectMode ? "cursor-pointer" : ""} ${isSelected ? "border-[#00897B] ring-2 ring-[#00897B]/30" : "border-slate-200/80 dark:border-slate-800"}`,
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "h-32 bg-slate-100 dark:bg-slate-800/60 relative p-3 flex items-start justify-between border-b border-slate-100 dark:border-slate-800 overflow-hidden",
										children: [
											form.bannerImage ? /* @__PURE__ */ _jsxDEV("img", {
												src: assetUrl(form.bannerImage),
												alt: form.title,
												className: "absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 495,
												columnNumber: 49
											}, this) : /* @__PURE__ */ _jsxDEV("div", {
												className: "absolute inset-0 flex items-center justify-center bg-gradient-to-br from-teal-50/40 to-slate-100 dark:from-slate-800 dark:to-slate-900",
												children: /* @__PURE__ */ _jsxDEV(FileText, {
													size: 32,
													className: "text-[#00897B]/25 dark:text-teal-400/25"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 502,
													columnNumber: 53
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 501,
												columnNumber: 49
											}, this),
											selectMode && /* @__PURE__ */ _jsxDEV("div", {
												className: "absolute top-2.5 left-2.5 z-20",
												onClick: (e) => {
													e.stopPropagation();
													toggleSelect(form.id);
												},
												children: isSelected ? /* @__PURE__ */ _jsxDEV(CheckSquare, {
													size: 18,
													className: "text-[#00897B] bg-white rounded-md shadow-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 510,
													columnNumber: 59
												}, this) : /* @__PURE__ */ _jsxDEV(Square, {
													size: 18,
													className: "text-slate-400 bg-white/90 rounded-md shadow-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 511,
													columnNumber: 59
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 508,
												columnNumber: 49
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: `relative z-10 px-2.5 py-1 rounded-lg text-[10px] font-bold tracking-wide shadow-xs ${selectMode ? "ml-6" : ""} ${isPublished ? "bg-emerald-600 text-white" : "bg-slate-800/80 text-white backdrop-blur-md"}`,
												children: isPublished ? "Dipublikasikan" : "Draf"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 516,
												columnNumber: 45
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "relative z-10 ml-auto",
												children: [/* @__PURE__ */ _jsxDEV("button", {
													onClick: () => setOpenMenuId(openMenuId === form.id ? null : form.id),
													className: "p-1.5 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md rounded-lg text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-700 shadow-xs transition-all cursor-pointer",
													children: /* @__PURE__ */ _jsxDEV(MoreVertical, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 529,
														columnNumber: 53
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 525,
													columnNumber: 49
												}, this), openMenuId === form.id && /* @__PURE__ */ _jsxDEV("div", {
													className: "absolute right-0 top-8 w-40 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 z-50 py-1 overflow-hidden",
													children: [/* @__PURE__ */ _jsxDEV("button", {
														onClick: () => handleDuplicateForm(form.id, form.title),
														disabled: duplicatingId === form.id,
														className: "w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors cursor-pointer disabled:opacity-60",
														children: [duplicatingId === form.id ? /* @__PURE__ */ _jsxDEV(Loader2, { className: "w-3.5 h-3.5 animate-spin" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 540,
															columnNumber: 90
														}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 540,
															columnNumber: 141
														}, this), duplicatingId === form.id ? "Menduplikasi..." : "Duplikat Form"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 535,
														columnNumber: 57
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														onClick: () => triggerDelete(form.id),
														className: "w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer",
														children: [/* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 547,
															columnNumber: 61
														}, this), " Hapus"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 543,
														columnNumber: 57
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 534,
													columnNumber: 53
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 524,
												columnNumber: 45
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 493,
										columnNumber: 41
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 flex flex-col flex-1 space-y-3",
										children: [
											/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-sm font-bold text-slate-900 dark:text-white leading-snug line-clamp-1 group-hover:text-[#00897B] dark:group-hover:text-teal-400 transition-colors",
												children: form.title || "Formulir Tanpa Judul"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 555,
												columnNumber: 45
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-3 text-xs font-medium text-slate-400 dark:text-slate-500",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-3.5 h-3.5 shrink-0" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 561,
															columnNumber: 53
														}, this),
														" ",
														responseCount
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 560,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 shrink-0" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 564,
															columnNumber: 53
														}, this),
														" ",
														createdDate
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 563,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 559,
												columnNumber: 45
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "mt-auto flex gap-2 pt-3 border-t border-slate-100 dark:border-slate-800",
												children: [/* @__PURE__ */ _jsxDEV("button", {
													onClick: () => navigate(`/forms/${form.id}/edit`),
													className: "flex-1 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-700/80 border border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold py-1.5 rounded-xl flex items-center justify-center gap-1.5 text-xs transition-colors cursor-pointer",
													children: [/* @__PURE__ */ _jsxDEV(Edit3, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 573,
														columnNumber: 53
													}, this), " Edit"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 569,
													columnNumber: 49
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													onClick: () => navigate(`/forms/${form.id}/responses`),
													className: "flex-1 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-700/80 border border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold py-1.5 rounded-xl flex items-center justify-center gap-1.5 text-xs transition-colors cursor-pointer",
													children: [/* @__PURE__ */ _jsxDEV(Eye, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 579,
														columnNumber: 53
													}, this), " Respons"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 575,
													columnNumber: 49
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 568,
												columnNumber: 45
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 554,
										columnNumber: 41
									}, this)]
								}, form.id, true, {
									fileName: _jsxFileName,
									lineNumber: 488,
									columnNumber: 37
								}, this);
							})]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 398,
							columnNumber: 21
						}, this),
						totalPages > 1 && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-200/80 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400 font-medium",
								children: [
									"Menampilkan halaman ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-900 dark:text-white",
										children: currentPage
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 593,
										columnNumber: 53
									}, this),
									" dari ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-900 dark:text-white",
										children: totalPages
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 593,
										columnNumber: 138
									}, this),
									" (total ",
									filteredForms.length,
									" formulir)"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 592,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCurrentPage((prev) => Math.max(prev - 1, 1)),
										disabled: currentPage === 1,
										className: "p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer",
										title: "Halaman Sebelumnya",
										children: /* @__PURE__ */ _jsxDEV(ChevronLeft, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 602,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 596,
										columnNumber: 33
									}, this),
									Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCurrentPage(pageNum),
										className: `w-8 h-8 rounded-xl text-xs font-bold transition-all cursor-pointer ${currentPage === pageNum ? "bg-[#00897B] text-white shadow-xs" : "border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"}`,
										children: pageNum
									}, pageNum, false, {
										fileName: _jsxFileName,
										lineNumber: 605,
										columnNumber: 37
									}, this)),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCurrentPage((prev) => Math.min(prev + 1, totalPages)),
										disabled: currentPage === totalPages,
										className: "p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer",
										title: "Halaman Selanjutnya",
										children: /* @__PURE__ */ _jsxDEV(ChevronRight, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 623,
											columnNumber: 37
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 617,
										columnNumber: 33
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 595,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 591,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 278,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 276,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(ConfirmModal, {
				isOpen: confirmModal.isOpen,
				onClose: () => setConfirmModal((prev) => ({
					...prev,
					isOpen: false
				})),
				onConfirm: executeDelete,
				title: confirmModal.title,
				message: confirmModal.message,
				variant: confirmModal.variant,
				confirmText: confirmModal.confirmText,
				isLoading: actionLoading !== null
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 632,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(AIFormBuilderModal, {
				isOpen: aiFormBuilderOpen,
				onClose: () => setAiFormBuilderOpen(false),
				onFormCreated: (newId) => navigate(`/forms/${newId}/edit`)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 644,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 272,
		columnNumber: 9
	}, this);
};
_s(MyForms, "mLohntrzL0F/uXpl5ItstKC8JiY=", false, function() {
	return [useNavigate, useDebounce];
});
_c = MyForms;
export default MyForms;
var _c;
$RefreshReg$(_c, "MyForms");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/dashboard/userDashboard/myForms.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/myForms.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/myForms.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/features/dashboard/userDashboard/myForms.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsUUFBUSxlQUFlO0FBQ3JELFNBQVMsbUJBQW1CO0FBQzVCLE9BQU8sYUFBYTtBQUNwQixPQUFPLFlBQVk7QUFDbkIsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyx3QkFBd0I7QUFDL0IsU0FDSSxNQUFNLGNBQWMsZUFBZSxVQUNuQyxPQUFPLEtBQUssUUFBUSxjQUFjLFVBQ2xDLGFBQWEsY0FBYyxhQUFhLFFBQVEsYUFBYSxNQUFNLFVBQVUsZUFDMUU7QUFDUCxTQUFTLFlBQVksWUFBWSxjQUFjLFVBQVUsWUFBWSxpQkFBaUIsY0FBYyxxQkFBcUI7QUFDekgsT0FBTyxpQkFBaUI7Ozs7QUFFeEIsTUFBTSxpQkFBaUI7QUFFdkIsTUFBTSxnQkFBZ0I7O0NBQ2xCLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLENBQUMsQ0FBQztDQUN6QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxJQUFJO0NBQ2pELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLElBQUk7Q0FDdkQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLGtCQUFrQixZQUFZLGFBQWEsR0FBRztDQUNwRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxDQUFDO0NBQ2hELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxVQUFVLE9BQU8sSUFBSTtDQUMzQixNQUFNLGdCQUFnQixPQUFPLElBQUk7Q0FFakMsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxLQUFLOztDQUcxRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxJQUFJLElBQUksQ0FBQztDQUN4RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBRWxELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTO0VBQzdDLFFBQVE7RUFDUixPQUFPO0VBQ1AsU0FBUztFQUNULFNBQVM7RUFDVCxhQUFhO0VBQ2IsUUFBUTtFQUNSLFFBQVE7Q0FDWixDQUFDOztDQUdELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsS0FBSzs7Q0FHaEUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsSUFBSTtDQUV2RCxnQkFBZ0I7RUFDWixNQUFNLGVBQWUsWUFBWTtHQUM3QixJQUFJO0lBQ0EsV0FBVyxJQUFJO0lBQ2YsTUFBTSxTQUFTLE1BQU0sV0FBVztJQUVoQyxJQUFJLE9BQU8sV0FBVyxLQUFLO0tBQ3ZCLGFBQWE7S0FDYixTQUFTLFFBQVE7S0FDakI7SUFDSjtJQUVBLElBQUksT0FBTyxNQUFNLE1BQU0sUUFBUSxPQUFPLElBQUksR0FBRztLQUN6QyxXQUFXLE9BQU8sSUFBSTtJQUMxQjtHQUNKLFNBQVMsS0FBSztJQUNWLFFBQVEsTUFBTSx5QkFBeUIsR0FBRztHQUM5QyxVQUFVO0lBQ04sV0FBVyxLQUFLO0dBQ3BCO0VBQ0o7RUFFQSxhQUFhO0NBQ2pCLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FFYixnQkFBZ0I7RUFDWixNQUFNLHNCQUFzQixNQUFNO0dBQzlCLElBQUksUUFBUSxXQUFXLENBQUMsUUFBUSxRQUFRLFNBQVMsRUFBRSxNQUFNLEdBQUc7SUFDeEQsY0FBYyxJQUFJO0dBQ3RCO0dBQ0EsSUFBSSxjQUFjLFdBQVcsQ0FBQyxjQUFjLFFBQVEsU0FBUyxFQUFFLE1BQU0sR0FBRztJQUNwRSxrQkFBa0IsS0FBSztHQUMzQjtFQUNKO0VBQ0EsU0FBUyxpQkFBaUIsYUFBYSxrQkFBa0I7RUFDekQsYUFBYSxTQUFTLG9CQUFvQixhQUFhLGtCQUFrQjtDQUM3RSxHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sc0JBQXNCLFlBQVk7RUFDcEMsSUFBSSxjQUFjO0VBQ2xCLGdCQUFnQixJQUFJO0VBQ3BCLElBQUk7R0FDQSxNQUFNLE1BQU0sTUFBTSxXQUFXO0lBQ3pCLE9BQU87SUFDUCxhQUFhO0dBQ2pCLENBQUM7R0FDRCxJQUFJLElBQUksV0FBVyxLQUFLO0lBQ3BCLGFBQWE7SUFDYixTQUFTLFFBQVE7SUFDakI7R0FDSjtHQUNBLElBQUksSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJO0lBQ3hCLFNBQVMsVUFBVSxJQUFJLEtBQUssR0FBRyxNQUFNO0dBQ3pDLE9BQU87SUFDSCxTQUFTLGNBQWM7R0FDM0I7RUFDSixTQUFTLEtBQUs7R0FDVixRQUFRLE1BQU0sd0JBQXdCLEdBQUc7R0FDekMsU0FBUyxjQUFjO0VBQzNCLFVBQVU7R0FDTixnQkFBZ0IsS0FBSztFQUN6QjtDQUNKO0NBRUEsTUFBTSxnQkFBZ0IsT0FBTztFQUN6QixnQkFBZSxTQUFRO0dBQ25CLE1BQU0sT0FBTyxJQUFJLElBQUksSUFBSTtHQUN6QixJQUFJLEtBQUssSUFBSSxFQUFFLEdBQUcsS0FBSyxPQUFPLEVBQUU7UUFBUSxLQUFLLElBQUksRUFBRTtHQUNuRCxPQUFPO0VBQ1gsQ0FBQztDQUNMO0NBRUEsTUFBTSx3QkFBd0I7RUFDMUIsSUFBSSxZQUFZLFNBQVMsV0FBVyxRQUFRO0dBQ3hDLGVBQWUsSUFBSSxJQUFJLENBQUM7RUFDNUIsT0FBTztHQUNILGVBQWUsSUFBSSxJQUFJLFdBQVcsS0FBSSxNQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7RUFDckQ7Q0FDSjtDQUVBLE1BQU0sMEJBQTBCO0VBQzVCLElBQUksWUFBWSxTQUFTLEdBQUc7RUFDNUIsZ0JBQWdCO0dBQ1osUUFBUTtHQUNSLE9BQU8sU0FBUyxZQUFZLEtBQUs7R0FDakMsU0FBUyxxQ0FBcUMsWUFBWSxLQUFLO0dBQy9ELFNBQVM7R0FDVCxhQUFhLFNBQVMsWUFBWSxLQUFLO0dBQ3ZDLFFBQVE7R0FDUixRQUFRO0VBQ1osQ0FBQztDQUNMO0NBRUEsTUFBTSxpQkFBaUIsV0FBVztFQUM5QixjQUFjLElBQUk7RUFDbEIsZ0JBQWdCO0dBQ1osUUFBUTtHQUNSLE9BQU87R0FDUCxTQUFTO0dBQ1QsU0FBUztHQUNULGFBQWE7R0FDTDtHQUNSLFFBQVE7RUFDWixDQUFDO0NBQ0w7Q0FFQSxNQUFNLGdCQUFnQixZQUFZO0VBQzlCLElBQUksYUFBYSxRQUFRO0dBQ3JCLE1BQU0sTUFBTSxDQUFDLEdBQUcsV0FBVztHQUMzQixpQkFBaUIsTUFBTTtHQUN2QixJQUFJO0lBQ0EsTUFBTSxTQUFTLE1BQU0sZ0JBQWdCLEdBQUc7SUFDeEMsSUFBSSxPQUFPLElBQUk7S0FDWCxZQUFXLFNBQVEsS0FBSyxRQUFPLE1BQUssQ0FBQyxJQUFJLFNBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQztLQUN4RCxlQUFlLElBQUksSUFBSSxDQUFDO0tBQ3hCLGNBQWMsS0FBSztJQUN2QjtHQUNKLFNBQVMsS0FBSztJQUNWLFFBQVEsTUFBTSxzQkFBc0IsR0FBRztHQUMzQyxVQUFVO0lBQ04saUJBQWlCLElBQUk7SUFDckIsaUJBQWdCLFVBQVM7S0FBRSxHQUFHO0tBQU0sUUFBUTtJQUFNLEVBQUU7R0FDeEQ7RUFDSixPQUFPO0dBQ0gsTUFBTSxTQUFTLGFBQWE7R0FDNUIsSUFBSSxDQUFDLFFBQVE7R0FDYixpQkFBaUIsTUFBTTtHQUN2QixJQUFJO0lBQ0EsTUFBTSxTQUFTLE1BQU0sV0FBVyxNQUFNO0lBQ3RDLElBQUksT0FBTyxJQUFJO0tBQ1gsWUFBVyxTQUFRLEtBQUssUUFBTyxNQUFLLEVBQUUsT0FBTyxNQUFNLENBQUM7S0FDcEQsZ0JBQWUsU0FBUTtNQUFFLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSTtNQUFHLEVBQUUsT0FBTyxNQUFNO01BQUcsT0FBTztLQUFHLENBQUM7SUFDbkY7R0FDSixTQUFTLEtBQUs7SUFDVixRQUFRLE1BQU0sc0JBQXNCLEdBQUc7R0FDM0MsVUFBVTtJQUNOLGlCQUFpQixJQUFJO0lBQ3JCLGlCQUFnQixVQUFTO0tBQUUsR0FBRztLQUFNLFFBQVE7S0FBTyxRQUFRO0lBQUssRUFBRTtHQUN0RTtFQUNKO0NBQ0o7O0NBR0EsTUFBTSxzQkFBc0IsT0FBTyxRQUFRLGNBQWM7RUFDckQsY0FBYyxJQUFJO0VBQ2xCLGlCQUFpQixNQUFNO0VBQ3ZCLElBQUk7R0FDQSxNQUFNLE9BQU8sTUFBTSxhQUFhLE1BQU07R0FDdEMsTUFBTSxZQUFZLE1BQU0sV0FBVztJQUFFLE9BQU8sZ0JBQWdCLGFBQWE7SUFBYyxhQUFhO0dBQUcsQ0FBQztHQUN4RyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUMsVUFBVSxNQUFNLElBQUk7SUFDdEMsaUJBQWlCLElBQUk7SUFDckI7R0FDSjtHQUNBLE1BQU0sUUFBUSxVQUFVLEtBQUs7R0FDN0IsSUFBSSxLQUFLLE1BQU0sTUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxTQUFTLEdBQUc7SUFDN0QsTUFBTSxVQUFVLEtBQUssS0FBSyxLQUFLLEdBQUcsT0FBTztLQUNyQyxJQUFJO0tBQ0osUUFBUSxFQUFFO0tBQ1YsVUFBVSxFQUFFLFlBQVk7S0FDeEIsZ0JBQWdCLEVBQUUsa0JBQWtCO0tBQ3BDLGVBQWUsSUFBSTtLQUNuQixZQUFZLENBQUMsQ0FBQyxFQUFFO0tBQ2hCLGVBQWUsRUFBRSxpQkFBaUI7S0FDbEMsUUFBUSxFQUFFLFVBQVU7S0FDcEIsZUFBZTtLQUNmLGVBQWU7S0FDZixVQUFVLEVBQUUsV0FBVyxDQUFDLEVBQUMsQ0FBRSxLQUFJLE9BQU07TUFBRSxZQUFZLEVBQUUsY0FBYztNQUFJLFdBQVcsQ0FBQyxDQUFDLEVBQUU7S0FBVSxFQUFFO0lBQ3RHLEVBQUU7SUFDRixNQUFNLGNBQWMsT0FBTyxPQUFPO0dBQ3RDO0dBQ0EsU0FBUyxVQUFVLE1BQU0sTUFBTTtFQUNuQyxTQUFTLEtBQUs7R0FDVixRQUFRLE1BQU0seUJBQXlCLEdBQUc7RUFDOUMsVUFBVTtHQUNOLGlCQUFpQixJQUFJO0VBQ3pCO0NBQ0o7Q0FFQSxNQUFNLGlCQUFpQixRQUFRLFFBQU8sTUFBSyxFQUFFLFFBQVEsWUFBWSxNQUFNLFdBQVc7Q0FDbEYsTUFBTSxhQUFhLFFBQVEsUUFBTyxNQUFLLEVBQUUsUUFBUSxZQUFZLE1BQU0sT0FBTztDQUMxRSxNQUFNLGlCQUFpQixRQUFRLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRSxpQkFBaUIsSUFBSSxDQUFDO0NBRWpGLE1BQU0sZ0JBQWdCLGNBQWM7RUFDaEMsT0FBTyxRQUFRLFFBQVEsU0FBUztHQUM1QixNQUFNLElBQUksS0FBSyxRQUFRLFlBQVksS0FBSztHQUN4QyxJQUFJLGNBQWMsZUFBZSxNQUFNLGFBQWEsT0FBTztHQUMzRCxJQUFJLGNBQWMsV0FBVyxNQUFNLFNBQVMsT0FBTztHQUVuRCxJQUFJLGdCQUFnQixLQUFLLEdBQUc7SUFDeEIsTUFBTSxJQUFJLGdCQUFnQixZQUFZO0lBQ3RDLE9BQ0ssS0FBSyxTQUFTLEtBQUssTUFBTSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDakQsS0FBSyxlQUFlLEtBQUssWUFBWSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FDN0QsS0FBSyxVQUFVLEtBQUssT0FBTyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUM7R0FFNUQ7R0FFQSxPQUFPO0VBQ1gsQ0FBQztDQUNMLEdBQUc7RUFBQztFQUFTO0VBQVc7Q0FBZSxDQUFDOztDQUd4QyxnQkFBZ0I7RUFDWixlQUFlLENBQUM7Q0FDcEIsR0FBRyxDQUFDLFdBQVcsZUFBZSxDQUFDO0NBRS9CLE1BQU0sYUFBYSxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssY0FBYyxTQUFTLGNBQWMsQ0FBQztDQUMvRSxNQUFNLGFBQWEsY0FBYztFQUM3QixNQUFNLFNBQVMsY0FBYyxLQUFLO0VBQ2xDLE9BQU8sY0FBYyxNQUFNLE9BQU8sUUFBUSxjQUFjO0NBQzVELEdBQUcsQ0FBQyxlQUFlLFdBQVcsQ0FBQztDQUUvQixNQUFNLE9BQU87RUFDVDtHQUFFLElBQUk7R0FBTyxPQUFPLFVBQVUsUUFBUSxPQUFPO0VBQUc7RUFDaEQ7R0FBRSxJQUFJO0dBQWEsT0FBTyxtQkFBbUIsZUFBZSxPQUFPO0VBQUc7RUFDdEU7R0FBRSxJQUFJO0dBQVMsT0FBTyxTQUFTLFdBQVcsT0FBTztFQUFHO0NBQ3hEO0NBRUEsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUksd0JBQUMsU0FBRCxDQUFVOzs7OztHQUVWLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBRVgsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEI7TUFFSSx3QkFBQyxRQUFEO09BQ2lCO09BQ2IsZ0JBQWdCO09BQ2hCLGFBQVk7TUFDZjs7Ozs7TUFHRCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBb0Y7T0FBaUI7Ozs7aUJBQ25ILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUF5RTtPQUVuRjs7OztlQUNGOzs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNkLEtBQUssS0FBSyxRQUNQLHdCQUFDLFVBQUQ7U0FFSSxlQUFlLGFBQWEsSUFBSSxFQUFFO1NBQ2xDLFdBQVcsb0lBQ1AsY0FBYyxJQUFJLEtBQ1osMEVBQ0E7bUJBR1QsSUFBSTtRQUNELEdBVEMsSUFBSTs7OztlQVNMLENBQ1g7T0FDQTs7OztlQUNBOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0ksd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDSSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBdUU7U0FBZ0I7Ozs7bUJBQ3BHLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFzRCxlQUFlLGVBQWUsT0FBTztTQUFNOzs7O2lCQUM5Rzs7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxFQUFLLFdBQVUsNkdBQThHOzs7O2dCQUM1SDs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlGO1FBQWlCOzs7O2tCQUN2SCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBcUYsZUFBZTtRQUFXOzs7O2dCQUM1SDs7OztrQkFDTCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYixDQUNJLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDRCQUE2Qjs7OzttQkFBQyxtQkFDdkQ7Ozs7O2dCQUNGOzs7OztlQUNKOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFVBQUQ7UUFDSSxlQUFlO1NBQ1gsSUFBSSxDQUFDLFlBQVk7VUFDYixjQUFjLElBQUk7U0FDdEIsT0FBTztVQUNILGdCQUFnQjtTQUNwQjtRQUNKO1FBQ0EsV0FBVyxzSEFDUCxhQUNNLHFEQUNBO2tCQVhkLENBY0ssY0FBYyxZQUFZLFNBQVMsV0FBVyxTQUMzQyx3QkFBQyxhQUFEO1NBQWEsTUFBTTtTQUFJLFdBQVU7UUFBYzs7OzttQkFFL0Msd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7OztrQkFFdkIsd0JBQUMsUUFBRCxZQUNLLENBQUMsYUFDSSxtQkFDQSxZQUFZLFNBQVMsV0FBVyxTQUNoQyxzQkFDQSxjQUNKOzs7O2dCQUNGOzs7OztpQkFFUCxjQUNHLHdCQUFDLFVBQUQ7UUFDSSxlQUFlO1NBQ1gsY0FBYyxLQUFLO1NBQ25CLGVBQWUsSUFBSSxJQUFJLENBQUM7UUFDNUI7UUFDQSxXQUFVO2tCQUNiO09BRU87Ozs7ZUFFWDs7Ozs7O01BR0osY0FBYyxZQUFZLE9BQU8sS0FDOUIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHFEQUFzRDs7OztrQkFDdEUsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0ksd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQWtELFlBQVk7U0FBYTs7OzttQkFBQyxVQUM1Rjs7Ozs7Z0JBQ0w7Ozs7O2lCQUVMLHdCQUFDLFVBQUQ7UUFDSSxTQUFTO1FBQ1QsVUFBVSxrQkFBa0I7UUFDNUIsV0FBVTtrQkFIZCxDQUtJLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7a0JBQUMsZ0JBRWhCOzs7OztlQUNQOzs7Ozs7TUFJVCx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUFzRSxLQUFLO2lCQUExRixDQUVJLHdCQUFDLE9BQUQ7UUFDSSxLQUFLO1FBQ0wsV0FBVTtrQkFGZDtTQUlJLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNYLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7O1NBQzFCOzs7OztTQUNMLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUF3RDtTQUVsRTs7Ozs7U0FDSix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBNEU7U0FFdEY7Ozs7O1NBQ0gsd0JBQUMsVUFBRDtVQUNJLE1BQUs7VUFDTCxVQUFVLE1BQU07V0FBRSxFQUFFLGdCQUFnQjtXQUFHLGtCQUFrQixDQUFDLGNBQWM7VUFBRztVQUMzRSxXQUFVO29CQUhkO1dBS0ksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7V0FBQztXQUNsQix3QkFBQyxhQUFEO1lBQWEsTUFBTTtZQUFJLFdBQVcsd0JBQXdCLGlCQUFpQixlQUFlO1dBQU87Ozs7O1VBQzdGOzs7Ozs7U0FFUCxrQkFDRyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNJLHdCQUFDLFVBQUQ7V0FDSSxNQUFLO1dBQ0wsZUFBZTtZQUFFLGtCQUFrQixLQUFLO1lBQUcsb0JBQW9CO1dBQUc7V0FDbEUsVUFBVTtXQUNWLFdBQVU7cUJBRVYsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFDWCx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztZQUNqQjs7OztzQkFDTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQ1IsZUFBZSxrQkFBa0I7WUFDbkM7Ozs7c0JBQ0gsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZEO1lBRXZFOzs7O29CQUNGOzs7O29CQUNKOzs7Ozs7VUFDRDs7OztvQkFDUix3QkFBQyxVQUFEO1dBQ0ksTUFBSztXQUNMLGVBQWU7WUFBRSxrQkFBa0IsS0FBSztZQUFHLHFCQUFxQixJQUFJO1dBQUc7V0FDdkUsV0FBVTtxQkFFVix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUNYLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O1lBQ3BCOzs7O3NCQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBd0Q7WUFFbEU7Ozs7c0JBQ0gsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZEO1lBRXZFOzs7O29CQUNGOzs7O29CQUNKOzs7Ozs7VUFDRDs7OztrQkFDUDs7Ozs7O1FBRVI7Ozs7O2lCQUVKLFVBQ0csd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQXlGO09BRW5HOzs7O2tCQUNMLGNBQWMsV0FBVyxJQUN6Qix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDVixrQkFBa0IseUNBQXlDLGdCQUFnQixNQUFNO09BQ2pGOzs7O2tCQUVMLFdBQVcsS0FBSyxTQUFTO1FBQ3JCLE1BQU0sU0FBUyxPQUFPLEtBQUssV0FBVyxXQUFXLEtBQUssU0FBUztRQUMvRCxNQUFNLGNBQWMsT0FBTyxZQUFZLE1BQU07UUFDN0MsTUFBTSxnQkFBZ0IsS0FBSyxpQkFBaUI7UUFDNUMsTUFBTSxXQUFXLGtCQUFrQixLQUFLO1FBQ3hDLE1BQU0sY0FBYyxLQUFLLFlBQ25CLElBQUksS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLG1CQUFtQixTQUFTO1NBQUUsT0FBTztTQUFTLEtBQUs7U0FBVyxNQUFNO1FBQVUsQ0FBQyxJQUN4RztRQUVOLE1BQU0sYUFBYSxZQUFZLElBQUksS0FBSyxFQUFFO1FBRTFDLE9BQ0ksd0JBQUMsT0FBRDtTQUVJLGVBQWUsY0FBYyxhQUFhLEtBQUssRUFBRTtTQUNqRCxXQUFXLDhJQUE4SSxXQUFXLG1DQUFtQyxHQUFHLEdBQUcsYUFBYSxtQkFBbUIsR0FBRyxHQUFHLGFBQWEsOENBQThDO21CQUhsVCxDQUtJLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0ssS0FBSyxjQUNGLHdCQUFDLE9BQUQ7WUFDSSxLQUFLLFNBQVMsS0FBSyxXQUFXO1lBQzlCLEtBQUssS0FBSztZQUNWLFdBQVU7V0FDYjs7OztzQkFFRCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDWCx3QkFBQyxVQUFEO2FBQVUsTUFBTTthQUFJLFdBQVU7WUFBMkM7Ozs7O1dBQ3hFOzs7OztXQUlSLGNBQ0csd0JBQUMsT0FBRDtZQUFLLFdBQVU7WUFBaUMsVUFBUyxNQUFLO2FBQUUsRUFBRSxnQkFBZ0I7YUFBRyxhQUFhLEtBQUssRUFBRTtZQUFHO3NCQUN2RyxhQUNLLHdCQUFDLGFBQUQ7YUFBYSxNQUFNO2FBQUksV0FBVTtZQUFnRDs7Ozt1QkFDakYsd0JBQUMsUUFBRDthQUFRLE1BQU07YUFBSSxXQUFVO1lBQW1EOzs7OztXQUVwRjs7Ozs7V0FHVCx3QkFBQyxRQUFEO1lBQU0sV0FBVyxzRkFBc0YsYUFBYSxTQUFTLEdBQUcsR0FDNUgsY0FDTSw4QkFDQTtzQkFFTCxjQUFjLG1CQUFtQjtXQUNoQzs7Ozs7V0FFTix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLFVBQUQ7YUFDSSxlQUFlLGNBQWMsZUFBZSxLQUFLLEtBQUssT0FBTyxLQUFLLEVBQUU7YUFDcEUsV0FBVTt1QkFFVix3QkFBQyxjQUFELEVBQWMsV0FBVSxVQUFXOzs7OztZQUMvQjs7OztzQkFHUCxlQUFlLEtBQUssTUFDakIsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDSSx3QkFBQyxVQUFEO2NBQ0ksZUFBZSxvQkFBb0IsS0FBSyxJQUFJLEtBQUssS0FBSztjQUN0RCxVQUFVLGtCQUFrQixLQUFLO2NBQ2pDLFdBQVU7d0JBSGQsQ0FLSyxrQkFBa0IsS0FBSyxLQUFLLHdCQUFDLFNBQUQsRUFBUyxXQUFVLDJCQUE0Qjs7Ozt5QkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O3dCQUM5RyxrQkFBa0IsS0FBSyxLQUFLLG9CQUFvQixlQUM3Qzs7Ozs7dUJBQ1Isd0JBQUMsVUFBRDtjQUNJLGVBQWUsY0FBYyxLQUFLLEVBQUU7Y0FDcEMsV0FBVTt3QkFGZCxDQUlJLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7d0JBQUMsUUFDOUI7Ozs7O3FCQUNQOzs7OztvQkFFUjs7Ozs7O1VBQ0o7Ozs7O21CQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0ksd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1QsS0FBSyxTQUFTO1dBQ2Y7Ozs7O1dBRUosd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FDSSx3QkFBQyxlQUFELEVBQWUsV0FBVSx1QkFBd0I7Ozs7O2NBQUM7Y0FBRTthQUNsRDs7Ozs7c0JBQ04sd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCO2NBQ0ksd0JBQUMsVUFBRCxFQUFVLFdBQVUsdUJBQXdCOzs7OztjQUFDO2NBQUU7YUFDN0M7Ozs7O29CQUNMOzs7Ozs7V0FFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNJLHdCQUFDLFVBQUQ7YUFDSSxlQUFlLFNBQVMsVUFBVSxLQUFLLEdBQUcsTUFBTTthQUNoRCxXQUFVO3VCQUZkLENBSUksd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7Ozt1QkFBQyxPQUM3Qjs7Ozs7c0JBQ1Isd0JBQUMsVUFBRDthQUNJLGVBQWUsU0FBUyxVQUFVLEtBQUssR0FBRyxXQUFXO2FBQ3JELFdBQVU7dUJBRmQsQ0FJSSx3QkFBQyxLQUFELEVBQUssV0FBVSxjQUFlOzs7O3VCQUFDLFVBQzNCOzs7OztvQkFDUDs7Ozs7O1VBQ0o7Ozs7O2lCQUNKO1dBOUZJLEtBQUs7Ozs7ZUE4RlQ7T0FFYixDQUFDLENBRUo7Ozs7OztNQUdKLGFBQWEsS0FDVix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQXNFO1NBQzlDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE0QztTQUFrQjs7Ozs7U0FBQztTQUFNLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE0QztTQUFpQjs7Ozs7U0FBQztTQUFTLGNBQWM7U0FBTztRQUN0Tjs7Ozs7aUJBQ0gsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDSSx3QkFBQyxVQUFEO1VBQ0ksZUFBZSxnQkFBZSxTQUFRLEtBQUssSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO1VBQzNELFVBQVUsZ0JBQWdCO1VBQzFCLFdBQVU7VUFDVixPQUFNO29CQUVOLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O1NBQ3BCOzs7OztTQUNQLE1BQU0sS0FBSyxFQUFFLFFBQVEsV0FBVyxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUksWUFDckQsd0JBQUMsVUFBRDtVQUVJLGVBQWUsZUFBZSxPQUFPO1VBQ3JDLFdBQVcsc0VBQ1AsZ0JBQWdCLFVBQ1Ysc0NBQ0E7b0JBR1Q7U0FDRyxHQVRDOzs7O2dCQVNELENBQ1g7U0FDRCx3QkFBQyxVQUFEO1VBQ0ksZUFBZSxnQkFBZSxTQUFRLEtBQUssSUFBSSxPQUFPLEdBQUcsVUFBVSxDQUFDO1VBQ3BFLFVBQVUsZ0JBQWdCO1VBQzFCLFdBQVU7VUFDVixPQUFNO29CQUVOLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O1NBQ3JCOzs7OztRQUNQOzs7OztlQUNKOzs7Ozs7S0FHUDs7Ozs7O0dBQ0w7Ozs7O0dBRUwsd0JBQUMsY0FBRDtJQUNJLFFBQVEsYUFBYTtJQUNyQixlQUFlLGlCQUFnQixVQUFTO0tBQUUsR0FBRztLQUFNLFFBQVE7SUFBTSxFQUFFO0lBQ25FLFdBQVc7SUFDWCxPQUFPLGFBQWE7SUFDcEIsU0FBUyxhQUFhO0lBQ3RCLFNBQVMsYUFBYTtJQUN0QixhQUFhLGFBQWE7SUFDMUIsV0FBVyxrQkFBa0I7R0FDaEM7Ozs7O0dBR0Qsd0JBQUMsb0JBQUQ7SUFDSSxRQUFRO0lBQ1IsZUFBZSxxQkFBcUIsS0FBSztJQUN6QyxnQkFBZ0IsVUFBVSxTQUFTLFVBQVUsTUFBTSxNQUFNO0dBQzVEOzs7OztFQUNBOzs7Ozs7QUFFYjs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm15Rm9ybXMuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgU2lkZWJhciBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2xheW91dC9TaWRlYmFyJztcbmltcG9ydCBUb3BiYXIgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9sYXlvdXQvVG9wYmFyJztcbmltcG9ydCBDb25maXJtTW9kYWwgZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Db25maXJtTW9kYWwnO1xuaW1wb3J0IEFJRm9ybUJ1aWxkZXJNb2RhbCBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0FJRm9ybUJ1aWxkZXJNb2RhbCc7XG5pbXBvcnQge1xuICAgIFBsdXMsIE1vcmVWZXJ0aWNhbCwgTWVzc2FnZVNxdWFyZSwgQ2FsZW5kYXIsXG4gICAgRWRpdDMsIEV5ZSwgVHJhc2gyLCBDaGVja0NpcmNsZTIsIEZpbGVUZXh0LFxuICAgIENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQsIENoZXZyb25Eb3duLCBTcXVhcmUsIENoZWNrU3F1YXJlLCBDb3B5LCBTcGFya2xlcywgTG9hZGVyMlxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgZ2V0TXlGb3JtcywgZGVsZXRlRm9ybSwgY2xlYXJTZXNzaW9uLCBhc3NldFVybCwgY3JlYXRlRm9ybSwgYnVsa0RlbGV0ZUZvcm1zLCBnZXRRdWVzdGlvbnMsIHNhdmVRdWVzdGlvbnMgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB1c2VEZWJvdW5jZSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VEZWJvdW5jZSc7XG5cbmNvbnN0IElURU1TX1BFUl9QQUdFID0gNzsgLy8gNyBmb3JtIGNhcmRzICsgMSBjcmVhdGUgY2FyZCA9IDggY2FyZHMgb24gcGFnZSAxXG5cbmNvbnN0IE15Rm9ybXMgPSAoKSA9PiB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZSgnQWxsJyk7XG4gICAgY29uc3QgW215Rm9ybXMsIHNldE15Rm9ybXNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICAgIGNvbnN0IFtvcGVuTWVudUlkLCBzZXRPcGVuTWVudUlkXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFthY3Rpb25Mb2FkaW5nLCBzZXRBY3Rpb25Mb2FkaW5nXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IGRlYm91bmNlZFNlYXJjaCA9IHVzZURlYm91bmNlKHNlYXJjaFF1ZXJ5LCAzNTApO1xuICAgIGNvbnN0IFtjdXJyZW50UGFnZSwgc2V0Q3VycmVudFBhZ2VdID0gdXNlU3RhdGUoMSk7XG4gICAgY29uc3QgW2NyZWF0aW5nRm9ybSwgc2V0Q3JlYXRpbmdGb3JtXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBtZW51UmVmID0gdXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IGNyZWF0ZU1lbnVSZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgICBjb25zdCBbc2hvd0NyZWF0ZU1lbnUsIHNldFNob3dDcmVhdGVNZW51XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIC8vIE11bHRpLXNlbGVjdCBzdGF0ZVxuICAgIGNvbnN0IFtzZWxlY3RlZElkcywgc2V0U2VsZWN0ZWRJZHNdID0gdXNlU3RhdGUobmV3IFNldCgpKTtcbiAgICBjb25zdCBbc2VsZWN0TW9kZSwgc2V0U2VsZWN0TW9kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICBjb25zdCBbY29uZmlybU1vZGFsLCBzZXRDb25maXJtTW9kYWxdID0gdXNlU3RhdGUoe1xuICAgICAgICBpc09wZW46IGZhbHNlLFxuICAgICAgICB0aXRsZTogJycsXG4gICAgICAgIG1lc3NhZ2U6ICcnLFxuICAgICAgICB2YXJpYW50OiAnZGFuZ2VyJyxcbiAgICAgICAgY29uZmlybVRleHQ6ICdZYSwgSGFwdXMnLFxuICAgICAgICBmb3JtSWQ6IG51bGwsXG4gICAgICAgIGlzQnVsazogZmFsc2UsXG4gICAgfSk7XG5cbiAgICAvLyBBSSBGb3JtIEJ1aWxkZXJcbiAgICBjb25zdCBbYWlGb3JtQnVpbGRlck9wZW4sIHNldEFpRm9ybUJ1aWxkZXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIC8vIEZFQVQtMTBiOiBEdXBsaWNhdGUgZm9ybSBzdGF0ZVxuICAgIGNvbnN0IFtkdXBsaWNhdGluZ0lkLCBzZXREdXBsaWNhdGluZ0lkXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgZmV0Y2hNeUZvcm1zID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGdldE15Rm9ybXMoKTtcblxuICAgICAgICAgICAgICAgIGlmIChyZXN1bHQuc3RhdHVzID09PSA0MDEpIHtcbiAgICAgICAgICAgICAgICAgICAgY2xlYXJTZXNzaW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChyZXN1bHQub2sgJiYgQXJyYXkuaXNBcnJheShyZXN1bHQuZGF0YSkpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0TXlGb3JtcyhyZXN1bHQuZGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgZm9ybXM6JywgZXJyKTtcbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgZmV0Y2hNeUZvcm1zKCk7XG4gICAgfSwgW25hdmlnYXRlXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBoYW5kbGVDbGlja091dHNpZGUgPSAoZSkgPT4ge1xuICAgICAgICAgICAgaWYgKG1lbnVSZWYuY3VycmVudCAmJiAhbWVudVJlZi5jdXJyZW50LmNvbnRhaW5zKGUudGFyZ2V0KSkge1xuICAgICAgICAgICAgICAgIHNldE9wZW5NZW51SWQobnVsbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY3JlYXRlTWVudVJlZi5jdXJyZW50ICYmICFjcmVhdGVNZW51UmVmLmN1cnJlbnQuY29udGFpbnMoZS50YXJnZXQpKSB7XG4gICAgICAgICAgICAgICAgc2V0U2hvd0NyZWF0ZU1lbnUoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xuICAgICAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcbiAgICB9LCBbXSk7XG5cbiAgICBjb25zdCBoYW5kbGVDcmVhdGVOZXdGb3JtID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoY3JlYXRpbmdGb3JtKSByZXR1cm47XG4gICAgICAgIHNldENyZWF0aW5nRm9ybSh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNyZWF0ZUZvcm0oe1xuICAgICAgICAgICAgICAgIHRpdGxlOiAnRm9ybXVsaXIgVGFucGEgSnVkdWwnLFxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSkge1xuICAgICAgICAgICAgICAgIGNsZWFyU2Vzc2lvbigpO1xuICAgICAgICAgICAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocmVzLm9rICYmIHJlcy5kYXRhPy5pZCkge1xuICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvZm9ybXMvJHtyZXMuZGF0YS5pZH0vZWRpdGApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZSgnL2NyZWF0ZS1mb3JtJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgY3JlYXRpbmcgZm9ybTonLCBlcnIpO1xuICAgICAgICAgICAgbmF2aWdhdGUoJy9jcmVhdGUtZm9ybScpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0Q3JlYXRpbmdGb3JtKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCB0b2dnbGVTZWxlY3QgPSAoaWQpID0+IHtcbiAgICAgICAgc2V0U2VsZWN0ZWRJZHMocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2KTtcbiAgICAgICAgICAgIGlmIChuZXh0LmhhcyhpZCkpIG5leHQuZGVsZXRlKGlkKTsgZWxzZSBuZXh0LmFkZChpZCk7XG4gICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IHRvZ2dsZVNlbGVjdEFsbCA9ICgpID0+IHtcbiAgICAgICAgaWYgKHNlbGVjdGVkSWRzLnNpemUgPT09IHBhZ2VkRm9ybXMubGVuZ3RoKSB7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZElkcyhuZXcgU2V0KCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWRJZHMobmV3IFNldChwYWdlZEZvcm1zLm1hcChmID0+IGYuaWQpKSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgdHJpZ2dlckJ1bGtEZWxldGUgPSAoKSA9PiB7XG4gICAgICAgIGlmIChzZWxlY3RlZElkcy5zaXplID09PSAwKSByZXR1cm47XG4gICAgICAgIHNldENvbmZpcm1Nb2RhbCh7XG4gICAgICAgICAgICBpc09wZW46IHRydWUsXG4gICAgICAgICAgICB0aXRsZTogYEhhcHVzICR7c2VsZWN0ZWRJZHMuc2l6ZX0gRm9ybXVsaXI/YCxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGBBcGFrYWggQW5kYSB5YWtpbiBpbmdpbiBtZW5naGFwdXMgJHtzZWxlY3RlZElkcy5zaXplfSBmb3JtdWxpciB5YW5nIGRpcGlsaWg/IFRpbmRha2FuIGluaSB0aWRhayBkYXBhdCBkaWJhdGFsa2FuLmAsXG4gICAgICAgICAgICB2YXJpYW50OiAnZGFuZ2VyJyxcbiAgICAgICAgICAgIGNvbmZpcm1UZXh0OiBgSGFwdXMgJHtzZWxlY3RlZElkcy5zaXplfSBGb3JtdWxpcmAsXG4gICAgICAgICAgICBmb3JtSWQ6IG51bGwsXG4gICAgICAgICAgICBpc0J1bGs6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCB0cmlnZ2VyRGVsZXRlID0gKGZvcm1JZCkgPT4ge1xuICAgICAgICBzZXRPcGVuTWVudUlkKG51bGwpO1xuICAgICAgICBzZXRDb25maXJtTW9kYWwoe1xuICAgICAgICAgICAgaXNPcGVuOiB0cnVlLFxuICAgICAgICAgICAgdGl0bGU6ICdIYXB1cyBGb3JtdWxpcj8nLFxuICAgICAgICAgICAgbWVzc2FnZTogJ0FwYWthaCBBbmRhIHlha2luIGluZ2luIG1lbmdoYXB1cyBmb3JtdWxpciBpbmk/IFRpbmRha2FuIGluaSB0aWRhayBkYXBhdCBkaWJhdGFsa2FuLicsXG4gICAgICAgICAgICB2YXJpYW50OiAnZGFuZ2VyJyxcbiAgICAgICAgICAgIGNvbmZpcm1UZXh0OiAnWWEsIEhhcHVzJyxcbiAgICAgICAgICAgIGZvcm1JZDogZm9ybUlkLFxuICAgICAgICAgICAgaXNCdWxrOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGV4ZWN1dGVEZWxldGUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmIChjb25maXJtTW9kYWwuaXNCdWxrKSB7XG4gICAgICAgICAgICBjb25zdCBpZHMgPSBbLi4uc2VsZWN0ZWRJZHNdO1xuICAgICAgICAgICAgc2V0QWN0aW9uTG9hZGluZygnYnVsaycpO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBidWxrRGVsZXRlRm9ybXMoaWRzKTtcbiAgICAgICAgICAgICAgICBpZiAocmVzdWx0Lm9rKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldE15Rm9ybXMocHJldiA9PiBwcmV2LmZpbHRlcihmID0+ICFpZHMuaW5jbHVkZXMoZi5pZCkpKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJZHMobmV3IFNldCgpKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0TW9kZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignQnVsayBkZWxldGUgZXJyb3I6JywgZXJyKTtcbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgc2V0QWN0aW9uTG9hZGluZyhudWxsKTtcbiAgICAgICAgICAgICAgICBzZXRDb25maXJtTW9kYWwocHJldiA9PiAoeyAuLi5wcmV2LCBpc09wZW46IGZhbHNlIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm1JZCA9IGNvbmZpcm1Nb2RhbC5mb3JtSWQ7XG4gICAgICAgICAgICBpZiAoIWZvcm1JZCkgcmV0dXJuO1xuICAgICAgICAgICAgc2V0QWN0aW9uTG9hZGluZyhmb3JtSWQpO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkZWxldGVGb3JtKGZvcm1JZCk7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3VsdC5vaykge1xuICAgICAgICAgICAgICAgICAgICBzZXRNeUZvcm1zKHByZXYgPT4gcHJldi5maWx0ZXIoZiA9PiBmLmlkICE9PSBmb3JtSWQpKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJZHMocHJldiA9PiB7IGNvbnN0IG4gPSBuZXcgU2V0KHByZXYpOyBuLmRlbGV0ZShmb3JtSWQpOyByZXR1cm4gbjsgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRGVsZXRlIGZvcm0gZXJyb3I6JywgZXJyKTtcbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgc2V0QWN0aW9uTG9hZGluZyhudWxsKTtcbiAgICAgICAgICAgICAgICBzZXRDb25maXJtTW9kYWwocHJldiA9PiAoeyAuLi5wcmV2LCBpc09wZW46IGZhbHNlLCBmb3JtSWQ6IG51bGwgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIEZFQVQtMTBiOiBEdXBsaWNhdGUgZm9ybVxuICAgIGNvbnN0IGhhbmRsZUR1cGxpY2F0ZUZvcm0gPSBhc3luYyAoZm9ybUlkLCBmb3JtVGl0bGUpID0+IHtcbiAgICAgICAgc2V0T3Blbk1lbnVJZChudWxsKTtcbiAgICAgICAgc2V0RHVwbGljYXRpbmdJZChmb3JtSWQpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcVJlcyA9IGF3YWl0IGdldFF1ZXN0aW9ucyhmb3JtSWQpO1xuICAgICAgICAgICAgY29uc3QgY3JlYXRlUmVzID0gYXdhaXQgY3JlYXRlRm9ybSh7IHRpdGxlOiBgU2FsaW5hbiBkYXJpICR7Zm9ybVRpdGxlIHx8ICdGb3JtdWxpcid9YCwgZGVzY3JpcHRpb246ICcnIH0pO1xuICAgICAgICAgICAgaWYgKCFjcmVhdGVSZXMub2sgfHwgIWNyZWF0ZVJlcy5kYXRhPy5pZCkge1xuICAgICAgICAgICAgICAgIHNldER1cGxpY2F0aW5nSWQobnVsbCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgbmV3SWQgPSBjcmVhdGVSZXMuZGF0YS5pZDtcbiAgICAgICAgICAgIGlmIChxUmVzLm9rICYmIEFycmF5LmlzQXJyYXkocVJlcy5kYXRhKSAmJiBxUmVzLmRhdGEubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSBxUmVzLmRhdGEubWFwKChxLCBpKSA9PiAoe1xuICAgICAgICAgICAgICAgICAgICBpZDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICB0eXBlSWQ6IHEudHlwZUlkLFxuICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbjogcS5xdWVzdGlvbiB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25Gb3JtYXQ6IHEucXVlc3Rpb25Gb3JtYXQgfHwgJ3RleHQnLFxuICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbk9yZGVyOiBpICsgMSxcbiAgICAgICAgICAgICAgICAgICAgaXNSZXF1aXJlZDogISFxLmlzUmVxdWlyZWQsXG4gICAgICAgICAgICAgICAgICAgIGNvcnJlY3RBbnN3ZXI6IHEuY29ycmVjdEFuc3dlciB8fCBudWxsLFxuICAgICAgICAgICAgICAgICAgICBwb2ludHM6IHEucG9pbnRzIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uSW1hZ2U6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uQXVkaW86IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IChxLm9wdGlvbnMgfHwgW10pLm1hcChvID0+ICh7IG9wdGlvblRleHQ6IG8ub3B0aW9uVGV4dCB8fCAnJywgaXNDb3JyZWN0OiAhIW8uaXNDb3JyZWN0IH0pKSxcbiAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgYXdhaXQgc2F2ZVF1ZXN0aW9ucyhuZXdJZCwgcGF5bG9hZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBuYXZpZ2F0ZShgL2Zvcm1zLyR7bmV3SWR9L2VkaXRgKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdEdXBsaWNhdGUgZm9ybSBlcnJvcjonLCBlcnIpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0RHVwbGljYXRpbmdJZChudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBwdWJsaXNoZWRGb3JtcyA9IG15Rm9ybXMuZmlsdGVyKGYgPT4gZi5zdGF0dXM/LnRvTG93ZXJDYXNlKCkgPT09ICdwdWJsaXNoZWQnKTtcbiAgICBjb25zdCBkcmFmdEZvcm1zID0gbXlGb3Jtcy5maWx0ZXIoZiA9PiBmLnN0YXR1cz8udG9Mb3dlckNhc2UoKSA9PT0gJ2RyYWZ0Jyk7XG4gICAgY29uc3QgdG90YWxSZXNwb25zZXMgPSBteUZvcm1zLnJlZHVjZSgoYWNjLCBmKSA9PiBhY2MgKyAoZi5yZXNwb25zZUNvdW50ID8/IDApLCAwKTtcblxuICAgIGNvbnN0IGZpbHRlcmVkRm9ybXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgcmV0dXJuIG15Rm9ybXMuZmlsdGVyKChmb3JtKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBzID0gZm9ybS5zdGF0dXM/LnRvTG93ZXJDYXNlKCkgPz8gJ2RyYWZ0JztcbiAgICAgICAgICAgIGlmIChhY3RpdmVUYWIgPT09ICdQdWJsaXNoZWQnICYmIHMgIT09ICdwdWJsaXNoZWQnKSByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICBpZiAoYWN0aXZlVGFiID09PSAnRHJhZnQnICYmIHMgIT09ICdkcmFmdCcpIHJldHVybiBmYWxzZTtcblxuICAgICAgICAgICAgaWYgKGRlYm91bmNlZFNlYXJjaC50cmltKCkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBxID0gZGVib3VuY2VkU2VhcmNoLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgKGZvcm0udGl0bGUgJiYgZm9ybS50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKSB8fFxuICAgICAgICAgICAgICAgICAgICAoZm9ybS5kZXNjcmlwdGlvbiAmJiBmb3JtLmRlc2NyaXB0aW9uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkpIHx8XG4gICAgICAgICAgICAgICAgICAgIChmb3JtLnN0YXR1cyAmJiBmb3JtLnN0YXR1cy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9KTtcbiAgICB9LCBbbXlGb3JtcywgYWN0aXZlVGFiLCBkZWJvdW5jZWRTZWFyY2hdKTtcblxuICAgIC8vIFJlc2V0IHRvIHBhZ2UgMSBvbiBzZWFyY2ggb3IgdGFiIHN3aXRjaFxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHNldEN1cnJlbnRQYWdlKDEpO1xuICAgIH0sIFthY3RpdmVUYWIsIGRlYm91bmNlZFNlYXJjaF0pO1xuXG4gICAgY29uc3QgdG90YWxQYWdlcyA9IE1hdGgubWF4KDEsIE1hdGguY2VpbChmaWx0ZXJlZEZvcm1zLmxlbmd0aCAvIElURU1TX1BFUl9QQUdFKSk7XG4gICAgY29uc3QgcGFnZWRGb3JtcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCBzdGFydCA9IChjdXJyZW50UGFnZSAtIDEpICogSVRFTVNfUEVSX1BBR0U7XG4gICAgICAgIHJldHVybiBmaWx0ZXJlZEZvcm1zLnNsaWNlKHN0YXJ0LCBzdGFydCArIElURU1TX1BFUl9QQUdFKTtcbiAgICB9LCBbZmlsdGVyZWRGb3JtcywgY3VycmVudFBhZ2VdKTtcblxuICAgIGNvbnN0IHRhYnMgPSBbXG4gICAgICAgIHsgaWQ6ICdBbGwnLCBsYWJlbDogYFNlbXVhICgke215Rm9ybXMubGVuZ3RofSlgIH0sXG4gICAgICAgIHsgaWQ6ICdQdWJsaXNoZWQnLCBsYWJlbDogYERpcHVibGlrYXNpa2FuICgke3B1Ymxpc2hlZEZvcm1zLmxlbmd0aH0pYCB9LFxuICAgICAgICB7IGlkOiAnRHJhZnQnLCBsYWJlbDogYERyYWYgKCR7ZHJhZnRGb3Jtcy5sZW5ndGh9KWAgfSxcbiAgICBdO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtc2NyZWVuIHctZnVsbCBiZy1bI0Y4RkFGQ10gZGFyazpiZy1zbGF0ZS05NTAgZm9udC1zYW5zIGFudGlhbGlhc2VkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgb3ZlcmZsb3ctaGlkZGVuIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxTaWRlYmFyIC8+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgaC1mdWxsIG1pbi13LTAgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgey8qIEZ1bGwgV2lkdGggTGF5b3V0IC0gVGFucGEgbWF4LXctN3hsIGFnYXIgdGlkYWsga29zb25nIGthbmFuIGtpcmkgKi99XG4gICAgICAgICAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIHctZnVsbCBwLTQgc206cC02IGxnOnAtOCBzcGFjZS15LTZcIj5cblxuICAgICAgICAgICAgICAgICAgICA8VG9wYmFyIFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoUXVlcnk9e3NlYXJjaFF1ZXJ5fSBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2hhbmdlPXtzZXRTZWFyY2hRdWVyeX0gXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNhcmkgZm9ybXVsaXIgQW5kYS4uLlwiIFxuICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgJiBUYWJzICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5Gb3JtdWxpciBTYXlhPC9oMT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bSBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEtlbG9sYSBkYW4gcGFudGF1IHNlbHVydWgga29sZWtzaSBmb3JtdWxpciBBbmRhLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gZ3JpZCBncmlkLWNvbHMtMyBzbTpmbGV4IGl0ZW1zLWNlbnRlciBiZy1zbGF0ZS0yMDAvNjAgZGFyazpiZy1zbGF0ZS04MDAvODAgcC0xIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMC82MCBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3RhYnMubWFwKCh0YWIpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dGFiLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIodGFiLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTIgc206cHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC1bMTFweF0gc206dGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgdGV4dC1jZW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gdGFiLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC00MDAgc2hhZG93LXhzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFiLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogU3RhdHMgR3JpZCAtIERpc2V0IGdyaWQtY29scy0yIHVudHVrIG1vYmlsZSBhZ2FyIDEgYmFyaXMgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtMyBzbTpnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bIzAwNUI1Ml0gZGFyazpiZy10ZWFsLTk1MC83MCByb3VuZGVkLTJ4bCBwLTQgc206cC01IHRleHQtd2hpdGUgc2hhZG93LXhzIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXRlYWwtODAwLzMwIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGVhbC0yMDAvOTAgZm9udC1ib2xkIHRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+VG90YWwgUmVzcG9uczwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIHNtOnRleHQtM3hsIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0XCI+e3RvdGFsUmVzcG9uc2VzLnRvTG9jYWxlU3RyaW5nKCdpZC1JRCcpfTwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtcmlnaHQtNiAtYm90dG9tLTYgdy0yNCBzbTp3LTI4IGgtMjQgc206aC0yOCBiZy13aGl0ZS8xMCByb3VuZGVkLWZ1bGwgYmx1ci14bCBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgc206cC01IHNoYWRvdy14cyBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIHRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+Rm9ybXVsaXIgQWt0aWY8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj57cHVibGlzaGVkRm9ybXMubGVuZ3RofTwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwIGZsZXggaXRlbXMtY2VudGVyIHRleHQtWzEwcHhdIHNtOnRleHQteHMgZm9udC1ib2xkIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBtci0xIHNocmluay0wXCIgLz4gQWt0aWYgJiBtZW5lcmltYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogU2VsZWN0aW9uIENvbnRyb2xzIC0gTGViaWggQmVzYXIgJiBKZWxhcyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFzZWxlY3RNb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RNb2RlKHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9nZ2xlU2VsZWN0QWxsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMi41IHJvdW5kZWQteGwgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtYm9sZCBib3JkZXItMiB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RNb2RlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy10ZWFsLTUwMCB0ZXh0LXdoaXRlIGJvcmRlci10ZWFsLTUwMCBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci10ZWFsLTUwMCBkYXJrOmhvdmVyOmJvcmRlci10ZWFsLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0TW9kZSAmJiBzZWxlY3RlZElkcy5zaXplID09PSBwYWdlZEZvcm1zLmxlbmd0aCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrU3F1YXJlIHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3F1YXJlIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshc2VsZWN0TW9kZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnUGlsaWggQmViZXJhcGEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNlbGVjdGVkSWRzLnNpemUgPT09IHBhZ2VkRm9ybXMubGVuZ3RoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdCYXRhbCBQaWxpaCBTZW11YSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ1BpbGloIFNlbXVhJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdE1vZGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0TW9kZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZElkcyhuZXcgU2V0KCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIGJnLXNsYXRlLTIwMC82MCBkYXJrOmJnLXNsYXRlLTgwMCBweC0zLjUgcHktMiByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVzYWlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBGbG9hdGluZyBCb3R0b20gQmFyIC0gTGViaWggVGViYWwgJiBKZWxhcyAqL31cbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdE1vZGUgJiYgc2VsZWN0ZWRJZHMuc2l6ZSA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNSBsZWZ0LTQgcmlnaHQtNCBzbTpsZWZ0LTEvMiBzbTotdHJhbnNsYXRlLXgtMS8yIHNtOm1heC13LW1kIHotNTAgYmctc2xhdGUtOTAwLzk1IGRhcms6Ymctc2xhdGUtODAwLzk1IHRleHQtd2hpdGUgYmFja2Ryb3AtYmx1ci1sZyBweC01IHB5LTMuNSByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBhbmltYXRlLWluIGZhZGUtaW4gc2xpZGUtaW4tZnJvbS1ib3R0b20tNSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMi41IGgtMi41IHJvdW5kZWQtZnVsbCBiZy10ZWFsLTQwMCBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNtIHNtOnRleHQtYmFzZVwiPntzZWxlY3RlZElkcy5zaXplfTwvc3Ryb25nPiBkaXBpbGloXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17dHJpZ2dlckJ1bGtEZWxldGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXthY3Rpb25Mb2FkaW5nID09PSAnYnVsayd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXJvc2UtNjAwIGhvdmVyOmJnLXJvc2UtNTAwIHRleHQtd2hpdGUgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtYm9sZCBweC00IHB5LTIuNSByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHNoYWRvdy1tZCBhY3RpdmU6c2NhbGUtOTUgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBIYXB1cyBGb3JtdWxpclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIENhcmRzIEdyaWQgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNCBnYXAtNFwiIHJlZj17bWVudVJlZn0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogVW5pZmllZCBDcmVhdGUgRm9ybSBDYXJkIHdpdGggZHJvcGRvd24gb3B0aW9ucyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWY9e2NyZWF0ZU1lbnVSZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBtaW4taC1bMjQwcHhdIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGhvdmVyOmJvcmRlci1bIzAwODk3Ql0gZGFyazpob3Zlcjpib3JkZXItdGVhbC00MDAgaG92ZXI6YmctdGVhbC01MC8xMCBkYXJrOmhvdmVyOmJnLXRlYWwtOTUwLzEwIHRyYW5zaXRpb24tYWxsIGdyb3VwIHAtNiB0ZXh0LWNlbnRlciByZWxhdGl2ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctdGVhbC01MCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItMyBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gdGV4dC1bIzAwODk3Ql0gZGFyazp0ZXh0LXRlYWwtNDAwIGJvcmRlciBib3JkZXItdGVhbC0yMDAvNjAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQtc20gbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdWF0IEZvcm11bGlyIEJhcnVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgdGV4dC14cyBmb250LW1lZGl1bSBtYXgtdy1bMTcwcHhdIG1iLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGlsaWggY2FyYSBwZW1idWF0YW4gZm9ybXVsaXIgQW5kYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4geyBlLnN0b3BQcm9wYWdhdGlvbigpOyBzZXRTaG93Q3JlYXRlTWVudSghc2hvd0NyZWF0ZU1lbnUpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTQgcHktMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHRleHQteHMgZm9udC1ib2xkIGhvdmVyOmJnLXdoaXRlIGhvdmVyOmJvcmRlci10ZWFsLTUwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC10ZWFsLTQwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGx1cyBzaXplPXsxM30gLz4gUGlsaWggQ2FyYSBCdWF0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uRG93biBzaXplPXsxM30gY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi10cmFuc2Zvcm0gJHtzaG93Q3JlYXRlTWVudSA/ICdyb3RhdGUtMTgwJyA6ICcnfWB9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd0NyZWF0ZU1lbnUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS1mdWxsIGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgbWItMiB3LTU2IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIHNoYWRvdy14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgb3ZlcmZsb3ctaGlkZGVuIHotMzAgYW5pbWF0ZS1pbiBmYWRlLWluIHNsaWRlLWluLWZyb20tYm90dG9tLTIgZHVyYXRpb24tMTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRTaG93Q3JlYXRlTWVudShmYWxzZSk7IGhhbmRsZUNyZWF0ZU5ld0Zvcm0oKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y3JlYXRpbmdGb3JtfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgdGV4dC1sZWZ0IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1sZyBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEVkaXQzIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NyZWF0aW5nRm9ybSA/ICdNZW55aWFwa2FuLi4uJyA6ICdCdWF0IE1hbnVhbCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3VzdW4gc29hbCBkYXJpIGF3YWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFNob3dDcmVhdGVNZW51KGZhbHNlKTsgc2V0QWlGb3JtQnVpbGRlck9wZW4odHJ1ZSk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyB0ZXh0LWxlZnQgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1sZyBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgYm9yZGVyIGJvcmRlci10ZWFsLTEwMCBkYXJrOmJvcmRlci10ZWFsLTkwMC80MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQnVhdCBkZW5nYW4gQUlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGRhcms6dGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZXNrcmlwc2lrYW4sIEFJIHN1c3VuIHNvYWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLWZ1bGwgcHktMTYgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1lbXVhdCBmb3JtdWxpci4uLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IGZpbHRlcmVkRm9ybXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tZnVsbCBweS0xNiB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwIHRleHQtc20gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2RlYm91bmNlZFNlYXJjaCA/IGBUaWRhayBhZGEgZm9ybXVsaXIgeWFuZyBjb2NvayBkZW5nYW4gXCIke2RlYm91bmNlZFNlYXJjaH1cIi5gIDogJ0JlbHVtIGFkYSBmb3JtdWxpciBwYWRhIHRhYiBpbmkuJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFnZWRGb3Jtcy5tYXAoKGZvcm0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3RhdHVzID0gdHlwZW9mIGZvcm0uc3RhdHVzID09PSAnc3RyaW5nJyA/IGZvcm0uc3RhdHVzIDogJ2RyYWZ0JztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNQdWJsaXNoZWQgPSBzdGF0dXMudG9Mb3dlckNhc2UoKSA9PT0gJ3B1Ymxpc2hlZCc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlQ291bnQgPSBmb3JtLnJlc3BvbnNlQ291bnQgPz8gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNBY3RpbmcgPSBhY3Rpb25Mb2FkaW5nID09PSBmb3JtLmlkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjcmVhdGVkRGF0ZSA9IGZvcm0uY3JlYXRlZEF0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGZvcm0uY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2lkLUlEJywgeyBtb250aDogJ3Nob3J0JywgZGF5OiAnbnVtZXJpYycsIHllYXI6ICdudW1lcmljJyB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnQmFydSBzYWphJztcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRJZHMuaGFzKGZvcm0uaWQpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtmb3JtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNlbGVjdE1vZGUgJiYgdG9nZ2xlU2VsZWN0KGZvcm0uaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXhzIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBncm91cCAke2lzQWN0aW5nID8gJ29wYWNpdHktNjAgcG9pbnRlci1ldmVudHMtbm9uZScgOiAnJ30gJHtzZWxlY3RNb2RlID8gJ2N1cnNvci1wb2ludGVyJyA6ICcnfSAke2lzU2VsZWN0ZWQgPyAnYm9yZGVyLVsjMDA4OTdCXSByaW5nLTIgcmluZy1bIzAwODk3Ql0vMzAnIDogJ2JvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0zMiBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAvNjAgcmVsYXRpdmUgcC0zIGZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybS5iYW5uZXJJbWFnZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXthc3NldFVybChmb3JtLmJhbm5lckltYWdlKX0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtmb3JtLnRpdGxlfSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS10ZWFsLTUwLzQwIHRvLXNsYXRlLTEwMCBkYXJrOmZyb20tc2xhdGUtODAwIGRhcms6dG8tc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IHNpemU9ezMyfSBjbGFzc05hbWU9XCJ0ZXh0LVsjMDA4OTdCXS8yNSBkYXJrOnRleHQtdGVhbC00MDAvMjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENoZWNrYm94IE92ZXJsYXkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RNb2RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIuNSBsZWZ0LTIuNSB6LTIwXCIgb25DbGljaz17ZSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IHRvZ2dsZVNlbGVjdChmb3JtLmlkKTsgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyA8Q2hlY2tTcXVhcmUgc2l6ZT17MTh9IGNsYXNzTmFtZT1cInRleHQtWyMwMDg5N0JdIGJnLXdoaXRlIHJvdW5kZWQtbWQgc2hhZG93LXhzXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiA8U3F1YXJlIHNpemU9ezE4fSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBiZy13aGl0ZS85MCByb3VuZGVkLW1kIHNoYWRvdy14c1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcmVsYXRpdmUgei0xMCBweC0yLjUgcHktMSByb3VuZGVkLWxnIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0cmFja2luZy13aWRlIHNoYWRvdy14cyAke3NlbGVjdE1vZGUgPyAnbWwtNicgOiAnJ30gJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzUHVibGlzaGVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNjAwIHRleHQtd2hpdGUnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTgwMC84MCB0ZXh0LXdoaXRlIGJhY2tkcm9wLWJsdXItbWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1B1Ymxpc2hlZCA/ICdEaXB1Ymxpa2FzaWthbicgOiAnRHJhZid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgbWwtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW5NZW51SWQob3Blbk1lbnVJZCA9PT0gZm9ybS5pZCA/IG51bGwgOiBmb3JtLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBiZy13aGl0ZS85MCBkYXJrOmJnLXNsYXRlLTgwMC85MCBiYWNrZHJvcC1ibHVyLW1kIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNb3JlVmVydGljYWwgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1lbnUgRHJvcGRvd24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3Blbk1lbnVJZCA9PT0gZm9ybS5pZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIHRvcC04IHctNDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCBzaGFkb3cteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHotNTAgcHktMSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRHVwbGljYXRlRm9ybShmb3JtLmlkLCBmb3JtLnRpdGxlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkdXBsaWNhdGluZ0lkID09PSBmb3JtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDAgaG92ZXI6YmctYmx1ZS01MCBkYXJrOmhvdmVyOmJnLWJsdWUtOTUwLzQwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZHVwbGljYXRpbmdJZCA9PT0gZm9ybS5pZCA/IDxMb2FkZXIyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IGFuaW1hdGUtc3BpblwiIC8+IDogPENvcHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkdXBsaWNhdGluZ0lkID09PSBmb3JtLmlkID8gJ01lbmR1cGxpa2FzaS4uLicgOiAnRHVwbGlrYXQgRm9ybSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0cmlnZ2VyRGVsZXRlKGZvcm0uaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1yb3NlLTYwMCBkYXJrOnRleHQtcm9zZS00MDAgaG92ZXI6Ymctcm9zZS01MCBkYXJrOmhvdmVyOmJnLXJvc2UtOTUwLzQwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IEhhcHVzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBmbGV4IGZsZXgtY29sIGZsZXgtMSBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLXNudWcgbGluZS1jbGFtcC0xIGdyb3VwLWhvdmVyOnRleHQtWyMwMDg5N0JdIGRhcms6Z3JvdXAtaG92ZXI6dGV4dC10ZWFsLTQwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm0udGl0bGUgfHwgJ0Zvcm11bGlyIFRhbnBhIEp1ZHVsJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVzc2FnZVNxdWFyZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBzaHJpbmstMFwiIC8+IHtyZXNwb25zZUNvdW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgc2hyaW5rLTBcIiAvPiB7Y3JlYXRlZERhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtYXV0byBmbGV4IGdhcC0yIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2Zvcm1zLyR7Zm9ybS5pZH0vZWRpdGApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1zbGF0ZS01MCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAvODAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAvODAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHB5LTEuNSByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEVkaXQzIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gRWRpdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9mb3Jtcy8ke2Zvcm0uaWR9L3Jlc3BvbnNlc2ApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1zbGF0ZS01MCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAvODAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAvODAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHB5LTEuNSByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV5ZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IFJlc3BvbnNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogUGFnaW5hdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgICAge3RvdGFsUGFnZXMgPiAxICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWVuYW1waWxrYW4gaGFsYW1hbiA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e2N1cnJlbnRQYWdlfTwvc3Bhbj4gZGFyaSA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3RvdGFsUGFnZXN9PC9zcGFuPiAodG90YWwge2ZpbHRlcmVkRm9ybXMubGVuZ3RofSBmb3JtdWxpcilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRQYWdlKHByZXYgPT4gTWF0aC5tYXgocHJldiAtIDEsIDEpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50UGFnZSA9PT0gMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiSGFsYW1hbiBTZWJlbHVtbnlhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25MZWZ0IHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge0FycmF5LmZyb20oeyBsZW5ndGg6IHRvdGFsUGFnZXMgfSwgKF8sIGkpID0+IGkgKyAxKS5tYXAocGFnZU51bSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtwYWdlTnVtfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRQYWdlKHBhZ2VOdW0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctOCBoLTggcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50UGFnZSA9PT0gcGFnZU51bVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctWyMwMDg5N0JdIHRleHQtd2hpdGUgc2hhZG93LXhzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BhZ2VOdW19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRQYWdlKHByZXYgPT4gTWF0aC5taW4ocHJldiArIDEsIHRvdGFsUGFnZXMpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50UGFnZSA9PT0gdG90YWxQYWdlc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiSGFsYW1hbiBTZWxhbmp1dG55YVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICA8L21haW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPENvbmZpcm1Nb2RhbCBcbiAgICAgICAgICAgICAgICBpc09wZW49e2NvbmZpcm1Nb2RhbC5pc09wZW59XG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0Q29uZmlybU1vZGFsKHByZXYgPT4gKHsgLi4ucHJldiwgaXNPcGVuOiBmYWxzZSB9KSl9XG4gICAgICAgICAgICAgICAgb25Db25maXJtPXtleGVjdXRlRGVsZXRlfVxuICAgICAgICAgICAgICAgIHRpdGxlPXtjb25maXJtTW9kYWwudGl0bGV9XG4gICAgICAgICAgICAgICAgbWVzc2FnZT17Y29uZmlybU1vZGFsLm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgdmFyaWFudD17Y29uZmlybU1vZGFsLnZhcmlhbnR9XG4gICAgICAgICAgICAgICAgY29uZmlybVRleHQ9e2NvbmZpcm1Nb2RhbC5jb25maXJtVGV4dH1cbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2FjdGlvbkxvYWRpbmcgIT09IG51bGx9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICB7LyogQUktMTogQUkgRm9ybSBCdWlsZGVyIE1vZGFsICovfVxuICAgICAgICAgICAgPEFJRm9ybUJ1aWxkZXJNb2RhbFxuICAgICAgICAgICAgICAgIGlzT3Blbj17YWlGb3JtQnVpbGRlck9wZW59XG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWlGb3JtQnVpbGRlck9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgIG9uRm9ybUNyZWF0ZWQ9eyhuZXdJZCkgPT4gbmF2aWdhdGUoYC9mb3Jtcy8ke25ld0lkfS9lZGl0YCl9XG4gICAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTXlGb3JtczsiXX0=