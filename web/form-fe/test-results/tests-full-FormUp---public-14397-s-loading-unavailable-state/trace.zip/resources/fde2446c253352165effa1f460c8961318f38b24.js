import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/InteractiveQuizOfferCard.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=72837b22";
import { CheckCircle2, RotateCcw, X } from "/node_modules/.vite/deps/lucide-react.js?v=d542a33e";
var _jsxFileName = "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/InteractiveQuizOfferCard.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=72837b22";
var _s = $RefreshSig$();
export default function InteractiveQuizOfferCard({ quizId, questions = [], onClose }) {
	_s();
	const key = `formup_interactive_quiz_${quizId}`;
	const [open, setOpen] = useState(false);
	const [state, setState] = useState(() => {
		try {
			return JSON.parse(localStorage.getItem(key)) || {};
		} catch {
			return {};
		}
	});
	const quizQuestions = questions.length ? questions : [{
		question: "Apa konsep utama yang perlu Anda latih?",
		options: [
			"Konsep A",
			"Konsep B",
			"Konsep C",
			"Konsep D"
		],
		correctIndex: 0
	}];
	const choose = (q, index) => {
		const next = {
			...state,
			[q]: index
		};
		setState(next);
		localStorage.setItem(key, JSON.stringify(next));
	};
	const reset = () => {
		setState({});
		localStorage.removeItem(key);
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
		className: "pt-2 border-t border-slate-100 dark:border-slate-800",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "p-3 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 space-y-2",
			children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs font-bold text-teal-800 dark:text-teal-200",
				children: "Mau melatih pemahaman dengan kuis interaktif?"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => setOpen(true),
				className: "px-3 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold",
				children: "Buka Kuis Interaktif"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 9
	}, this), open && /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 bg-slate-900/60",
			onClick: () => setOpen(false)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 91
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative z-10 bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto space-y-4",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-between items-center",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-extrabold text-sm",
						children: "Kuis Interaktif"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 351
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setOpen(false),
						children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 21,
							columnNumber: 463
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 410
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 300
				}, this),
				quizQuestions.map((item, qi) => /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs font-bold",
						children: [
							qi + 1,
							". ",
							item.question
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 562
					}, this), item.options.map((option, oi) => {
						const selected = state[qi] === oi;
						const answered = state[qi] != null;
						const correct = oi === item.correctIndex;
						return /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => !answered && choose(qi, oi),
							className: `w-full text-left p-2 rounded-lg border text-xs ${answered && correct ? "border-emerald-500 bg-emerald-50" : answered && selected ? "border-red-500 bg-red-50" : "border-slate-200 dark:border-slate-700"}`,
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [
								String.fromCharCode(65 + oi),
								". ",
								option
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 21,
								columnNumber: 1071
							}, this), answered && selected && /* @__PURE__ */ _jsxDEV("span", {
								className: "ml-2 font-bold",
								children: correct ? "Benar" : "Salah"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 21,
								columnNumber: 1149
							}, this)]
						}, oi, true, {
							fileName: _jsxFileName,
							lineNumber: 21,
							columnNumber: 780
						}, this);
					})]
				}, qi, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 526
				}, this)),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: reset,
					className: "inline-flex items-center gap-1 text-xs font-bold text-teal-600",
					children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 13 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 1354
					}, this), " Ulangi Kuis"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 1241
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-[10px] text-slate-400 flex items-center gap-1",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 12 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 1466
					}, this), " Latihan ini tidak memengaruhi Responses atau skor form."]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 1398
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 171
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 18
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 12
	}, this);
}
_s(InteractiveQuizOfferCard, "sx4Srnyyo9GfkMgZcdEOeVf2BiQ=");
_c = InteractiveQuizOfferCard;
var _c;
$RefreshReg$(_c, "InteractiveQuizOfferCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/InteractiveQuizOfferCard.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/InteractiveQuizOfferCard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/InteractiveQuizOfferCard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/karllo/Projects/FormUp/web/form-fe/src/components/ui/InteractiveQuizOfferCard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGNBQWMsV0FBVyxTQUFTOzs7O0FBRTNDLGVBQWUsU0FBUyx5QkFBeUIsRUFBRSxRQUFRLFlBQVksQ0FBQyxHQUFHLFdBQVc7O0NBQ2xGLE1BQU0sTUFBTSwyQkFBMkI7Q0FDdkMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxDQUFDLE9BQU8sWUFBWSxlQUFlO0VBQUUsSUFBSTtHQUFFLE9BQU8sS0FBSyxNQUFNLGFBQWEsUUFBUSxHQUFHLENBQUMsS0FBSyxDQUFDO0VBQUcsUUFBUTtHQUFFLE9BQU8sQ0FBQztFQUFHO0NBQUUsQ0FBQztDQUM3SCxNQUFNLGdCQUFnQixVQUFVLFNBQVMsWUFBWSxDQUFDO0VBQUUsVUFBVTtFQUEyQyxTQUFTO0dBQUM7R0FBWTtHQUFZO0dBQVk7RUFBVTtFQUFHLGNBQWM7Q0FBRSxDQUFDO0NBQ3pMLE1BQU0sVUFBVSxHQUFHLFVBQVU7RUFDekIsTUFBTSxPQUFPO0dBQUUsR0FBRztJQUFRLElBQUk7RUFBTTtFQUNwQyxTQUFTLElBQUk7RUFBRyxhQUFhLFFBQVEsS0FBSyxLQUFLLFVBQVUsSUFBSSxDQUFDO0NBQ2xFO0NBQ0EsTUFBTSxjQUFjO0VBQUUsU0FBUyxDQUFDLENBQUM7RUFBRyxhQUFhLFdBQVcsR0FBRztDQUFHO0NBQ2xFLE9BQU8sZ0RBQ0gsd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDWCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0ksd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBcUQ7R0FBZ0Q7Ozs7YUFDbEgsd0JBQUMsVUFBRDtJQUFRLE1BQUs7SUFBUyxlQUFlLFFBQVEsSUFBSTtJQUFHLFdBQVU7Y0FBZ0U7R0FBNEI7Ozs7V0FDeko7Ozs7OztDQUNKOzs7O1dBQ0osUUFBUSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQXlFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQWdDLGVBQWUsUUFBUSxLQUFLO0VBQUk7Ozs7WUFBQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQWlJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FBbUQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXlCO0tBQW1COzs7O2VBQUMsd0JBQUMsVUFBRDtNQUFRLE1BQUs7TUFBUyxlQUFlLFFBQVEsS0FBSztnQkFBRyx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztLQUFTOzs7O2FBQU07Ozs7OztJQUFFLGNBQWMsS0FBSyxNQUFNLE9BQU8sd0JBQUMsT0FBRDtLQUFjLFdBQVU7ZUFBeEIsQ0FBb0Msd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FBa0MsS0FBSztPQUFFO09BQUcsS0FBSztNQUFZOzs7OztlQUFFLEtBQUssUUFBUSxLQUFLLFFBQVEsT0FBTztNQUFFLE1BQU0sV0FBVyxNQUFNLFFBQVE7TUFBSSxNQUFNLFdBQVcsTUFBTSxPQUFPO01BQU0sTUFBTSxVQUFVLE9BQU8sS0FBSztNQUFjLE9BQU8sd0JBQUMsVUFBRDtPQUFpQixNQUFLO09BQVMsZUFBZSxDQUFDLFlBQVksT0FBTyxJQUFJLEVBQUU7T0FBRyxXQUFXLGtEQUFrRCxZQUFZLFVBQVUscUNBQXFDLFlBQVksV0FBVyw2QkFBNkI7aUJBQXZQLENBQW1TLHdCQUFDLFFBQUQ7UUFBTyxPQUFPLGFBQWEsS0FBSyxFQUFFO1FBQUU7UUFBRztPQUFhOzs7O2lCQUFFLFlBQVksWUFBWSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBa0IsVUFBVSxVQUFVO09BQWM7Ozs7ZUFBVTtTQUFsYjs7OzthQUFrYjtLQUFHLENBQUMsQ0FBTztPQUE5ckI7Ozs7V0FBOHJCLENBQUM7SUFBRSx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFNBQVM7S0FBTyxXQUFVO2VBQWhELENBQWlILHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7ZUFBQyxjQUFvQjs7Ozs7O0lBQUMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUFvRSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O2VBQUMsMERBQTZEOzs7Ozs7R0FBTTs7Ozs7VUFBTTs7Ozs7U0FDdGhEOzs7OztBQUNOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkludGVyYWN0aXZlUXVpek9mZmVyQ2FyZC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IENoZWNrQ2lyY2xlMiwgUm90YXRlQ2N3LCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW50ZXJhY3RpdmVRdWl6T2ZmZXJDYXJkKHsgcXVpeklkLCBxdWVzdGlvbnMgPSBbXSwgb25DbG9zZSB9KSB7XG4gICAgY29uc3Qga2V5ID0gYGZvcm11cF9pbnRlcmFjdGl2ZV9xdWl6XyR7cXVpeklkfWA7XG4gICAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtzdGF0ZSwgc2V0U3RhdGVdID0gdXNlU3RhdGUoKCkgPT4geyB0cnkgeyByZXR1cm4gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpKSB8fCB7fTsgfSBjYXRjaCB7IHJldHVybiB7fTsgfSB9KTtcbiAgICBjb25zdCBxdWl6UXVlc3Rpb25zID0gcXVlc3Rpb25zLmxlbmd0aCA/IHF1ZXN0aW9ucyA6IFt7IHF1ZXN0aW9uOiAnQXBhIGtvbnNlcCB1dGFtYSB5YW5nIHBlcmx1IEFuZGEgbGF0aWg/Jywgb3B0aW9uczogWydLb25zZXAgQScsICdLb25zZXAgQicsICdLb25zZXAgQycsICdLb25zZXAgRCddLCBjb3JyZWN0SW5kZXg6IDAgfV07XG4gICAgY29uc3QgY2hvb3NlID0gKHEsIGluZGV4KSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHQgPSB7IC4uLnN0YXRlLCBbcV06IGluZGV4IH07XG4gICAgICAgIHNldFN0YXRlKG5leHQpOyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KG5leHQpKTtcbiAgICB9O1xuICAgIGNvbnN0IHJlc2V0ID0gKCkgPT4geyBzZXRTdGF0ZSh7fSk7IGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGtleSk7IH07XG4gICAgcmV0dXJuIDw+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC14bCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXRlYWwtODAwIGRhcms6dGV4dC10ZWFsLTIwMFwiPk1hdSBtZWxhdGloIHBlbWFoYW1hbiBkZW5nYW4ga3VpcyBpbnRlcmFrdGlmPzwvcD5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfSBjbGFzc05hbWU9XCJweC0zIHB5LTIgYmctdGVhbC02MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkXCI+QnVrYSBLdWlzIEludGVyYWt0aWY8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge29wZW4gJiYgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+PGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLXNsYXRlLTkwMC82MFwiIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oZmFsc2UpfSAvPjxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTN4bCBwLTYgbWF4LXctbGcgdy1mdWxsIG1heC1oLVs5MHZoXSBvdmVyZmxvdy15LWF1dG8gc3BhY2UteS00XCI+PGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj48aDMgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbVwiPkt1aXMgSW50ZXJha3RpZjwvaDM+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0T3BlbihmYWxzZSl9PjxYIHNpemU9ezE4fSAvPjwvYnV0dG9uPjwvZGl2PntxdWl6UXVlc3Rpb25zLm1hcCgoaXRlbSwgcWkpID0+IDxkaXYga2V5PXtxaX0gY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+PHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGRcIj57cWkgKyAxfS4ge2l0ZW0ucXVlc3Rpb259PC9wPntpdGVtLm9wdGlvbnMubWFwKChvcHRpb24sIG9pKSA9PiB7IGNvbnN0IHNlbGVjdGVkID0gc3RhdGVbcWldID09PSBvaTsgY29uc3QgYW5zd2VyZWQgPSBzdGF0ZVtxaV0gIT0gbnVsbDsgY29uc3QgY29ycmVjdCA9IG9pID09PSBpdGVtLmNvcnJlY3RJbmRleDsgcmV0dXJuIDxidXR0b24ga2V5PXtvaX0gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+ICFhbnN3ZXJlZCAmJiBjaG9vc2UocWksIG9pKX0gY2xhc3NOYW1lPXtgdy1mdWxsIHRleHQtbGVmdCBwLTIgcm91bmRlZC1sZyBib3JkZXIgdGV4dC14cyAke2Fuc3dlcmVkICYmIGNvcnJlY3QgPyAnYm9yZGVyLWVtZXJhbGQtNTAwIGJnLWVtZXJhbGQtNTAnIDogYW5zd2VyZWQgJiYgc2VsZWN0ZWQgPyAnYm9yZGVyLXJlZC01MDAgYmctcmVkLTUwJyA6ICdib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCd9YH0+PHNwYW4+e1N0cmluZy5mcm9tQ2hhckNvZGUoNjUgKyBvaSl9LiB7b3B0aW9ufTwvc3Bhbj57YW5zd2VyZWQgJiYgc2VsZWN0ZWQgJiYgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LWJvbGRcIj57Y29ycmVjdCA/ICdCZW5hcicgOiAnU2FsYWgnfTwvc3Bhbj59PC9idXR0b24+OyB9KX08L2Rpdj4pfTxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e3Jlc2V0fSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyBmb250LWJvbGQgdGV4dC10ZWFsLTYwMFwiPjxSb3RhdGVDY3cgc2l6ZT17MTN9IC8+IFVsYW5naSBLdWlzPC9idXR0b24+PGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPjxDaGVja0NpcmNsZTIgc2l6ZT17MTJ9IC8+IExhdGloYW4gaW5pIHRpZGFrIG1lbWVuZ2FydWhpIFJlc3BvbnNlcyBhdGF1IHNrb3IgZm9ybS48L2Rpdj48L2Rpdj48L2Rpdj59XG4gICAgPC8+O1xufVxuIl19